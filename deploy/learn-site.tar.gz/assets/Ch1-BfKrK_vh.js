import{j as e}from"./index-BdVncPlI.js";import{L as n,S as o}from"./Summary-Baiwq3-G.js";import{K as c}from"./KeyIdea-Cnr-5ipR.js";import{C as s}from"./Callout-BRUKkrb4.js";import{C as t}from"./CodeBlock-DCdshbU5.js";import{E as r}from"./Example-phQ905Fb.js";const i=`<script>
// 选项式 API：同一个「搜索」逻辑被拆散到三个选项里
export default {
  data() {
    return {
      keyword: '',          // 状态在 data
      results: [],
    }
  },
  computed: {
    hasResult() {           // 派生在 computed
      return this.results.length > 0
    },
  },
  methods: {
    search() {              // 行为在 methods
      this.results = doSearch(this.keyword)
    },
  },
  mounted() {               // 生命周期又在别处
    this.search()
  },
}
<\/script>`,d=`<script setup>
// 组合式 API：同一个逻辑关注点聚到一起
import { ref, computed, onMounted } from 'vue'

const keyword = ref('')
const results = ref([])

const hasResult = computed(() => results.value.length > 0)

function search() {
  results.value = doSearch(keyword.value)
}

onMounted(search)
<\/script>`,l=`<script>
import { ref } from 'vue'

export default {
  setup() {
    const count = ref(0)
    function increment() {
      count.value++
    }
    // 必须显式 return，模板才能用到 count 和 increment
    return { count, increment }
  },
}
<\/script>`,h=`<script setup>
import { ref } from 'vue'

// 顶层声明的变量与函数「自动」暴露给模板，无需 return
const count = ref(0)
function increment() {
  count.value++
}
<\/script>

<template>
  <button @click="increment">点击了 {{ count }} 次</button>
</template>`,u=`import { ref } from 'vue'

const count = ref(0)

// 在 JS / <script> 里，必须通过 .value 读写
console.log(count.value)   // 0
count.value++
console.log(count.value)   // 1

// 在 <template> 里，Vue 自动解包，直接写 count 即可
// <span>{{ count }}</span>  ——  不用写 count.value`,a=`import { reactive } from 'vue'

const user = reactive({
  name: 'Ada',
  age: 30,
  address: { city: 'Hangzhou' },
})

// 直接像普通对象一样读写，不需要 .value
user.age++
user.address.city = 'Shanghai'   // 嵌套对象也是响应式的（深层代理）`,x=`import { reactive } from 'vue'

let state = reactive({ count: 0 })

// 坑一：整体替换会丢响应性
// 下面这行让 state 指向一个全新的普通对象，原代理被丢弃，
// 模板仍引用着旧代理，界面不再更新
state = { count: 100 }   // 错误做法

// 坑二：解构会丢响应性
const { count } = state  // count 只是一个普通数字 0 的拷贝
// 之后改 count 不会触发更新，改 state.count 也不会反映到 count`,j=`import { reactive, toRefs, toRef } from 'vue'

const state = reactive({ count: 0, name: 'Ada' })

// toRefs：把 reactive 对象的每个属性都转成 ref，
// 解构后仍与源对象保持「双向」的响应式连接
const { count, name } = toRefs(state)
count.value++            // 等价于 state.count++
console.log(state.count) // 1

// toRef：只取单个属性，转成一个与源相连的 ref
const onlyCount = toRef(state, 'count')
onlyCount.value = 5
console.log(state.count) // 5`,p=`<script setup>
import { ref, computed } from 'vue'

const count = ref(0)
const double = computed(() => count.value * 2)

function increment() {
  count.value++
}
function reset() {
  count.value = 0
}
<\/script>

<template>
  <p>当前：{{ count }}，翻倍：{{ double }}</p>
  <button @click="increment">+1</button>
  <button @click="reset">重置</button>
</template>`,f=`<script setup>
import { reactive, toRefs } from 'vue'

const user = reactive({
  name: 'Ada',
  age: 30,
  profile: { city: 'Hangzhou', bio: '前端工程师' },
})

function haveBirthday() {
  user.age++                 // 直接改属性，响应式保留
}
function moveTo(city) {
  user.profile.city = city   // 嵌套属性同样响应
}

// 需要在模板里解构使用时，用 toRefs 保住响应性
const { name, age } = toRefs(user)
<\/script>

<template>
  <p>{{ name }}（{{ age }} 岁）住在 {{ user.profile.city }}</p>
  <button @click="haveBirthday">过生日</button>
  <button @click="moveTo('Shanghai')">搬到上海</button>
</template>`;function b(){return e.jsxs("article",{children:[e.jsxs(n,{children:["Vue 3 带来的最大变化之一，是引入了",e.jsx("strong",{children:"组合式 API（Composition API）"}),"。 它不是要取代你熟悉的选项式 API，而是给出另一种组织组件逻辑的方式——按「逻辑关注点」 聚合，而不是按「选项种类」拆散。这一章我们从「它到底解决了什么问题」讲起， 把 ",e.jsx("code",{children:"setup"}),"、",e.jsx("code",{children:"<script setup>"})," 语法糖、以及两块响应式基石",e.jsx("code",{children:"ref"})," 与 ",e.jsx("code",{children:"reactive"})," 一次讲透，再用计数器和用户对象两个例子落到代码上。"]}),e.jsx("h2",{children:"一、组合式 API 解决了什么问题"}),e.jsxs("p",{children:["在选项式 API 里，一个组件被切成 ",e.jsx("code",{children:"data"}),"、",e.jsx("code",{children:"methods"}),"、",e.jsx("code",{children:"computed"}),"、",e.jsx("code",{children:"watch"}),"、生命周期钩子等若干「选项」。代码",e.jsx("strong",{children:"按种类"}),"归类：所有状态堆在 ",e.jsx("code",{children:"data"}),"，所有方法堆在 ",e.jsx("code",{children:"methods"}),"。组件小的时候很清晰， 可一旦逻辑变多，同一个功能的碎片就会被强行打散到好几个选项里。"]}),e.jsxs("p",{children:["想象一个组件同时管「搜索」和「分页」两件事。选项式写法下，搜索用到的状态、计算属性、方法、 生命周期会分别落进 ",e.jsx("code",{children:"data"})," / ",e.jsx("code",{children:"computed"})," / ",e.jsx("code",{children:"methods"})," /",e.jsx("code",{children:"mounted"}),"；分页的那一套也一样。结果是：要读懂「搜索」这一个功能，你的视线得在 文件里上下跳好几次。功能越多，跳得越远。"]}),e.jsx(t,{lang:"vue",title:"选项式：一个逻辑被拆到四个选项",code:i}),e.jsxs(c,{children:["组合式 API 的核心主张是：",e.jsx("strong",{children:"按逻辑关注点（logical concern）组织代码，而非按选项种类。"}),"同一个功能用到的状态、派生、方法、副作用可以写在一起、挨在一起读， 还能整段抽成可复用的函数（组合式函数 / composable）在多个组件间共享。"]}),e.jsxs("p",{children:["把上面的例子换成组合式写法，「搜索」相关的一切就聚成连续的一段，读起来是顺的； 如果项目里别处也要用，把这段抽成一个 ",e.jsx("code",{children:"useSearch()"})," 函数即可直接复用—— 这是选项式时代靠 mixin 很难干净做到的事（mixin 容易命名冲突、来源不清）。"]}),e.jsx(t,{lang:"vue",title:"组合式：同一逻辑聚在一起",code:d}),e.jsxs("h2",{children:["二、setup 与 ","<script setup>"," 语法糖"]}),e.jsxs("p",{children:["组合式 API 的代码要写在一个叫 ",e.jsx("code",{children:"setup"})," 的入口里。最原始的形态是在选项对象里写一个",e.jsx("code",{children:"setup()"})," 函数：在里面创建响应式状态、定义函数，最后",e.jsx("strong",{children:"显式 return"}),"一个对象，模板才能用到这些东西。"]}),e.jsx(t,{lang:"vue",title:"原始 setup()：必须手动 return",code:l}),e.jsxs("p",{children:["这种写法有个明显的累赘：每加一个变量或函数，都得记着去 ",e.jsx("code",{children:"return"})," 里补一笔， 否则模板里用不到。于是 Vue 提供了编译期语法糖 ",e.jsx("code",{children:"<script setup>"}),"—— 在 ",e.jsx("code",{children:"<script setup>"})," 块里，",e.jsx("strong",{children:"顶层声明的变量、函数、import 进来的组件， 统统自动暴露给模板"}),"，再也不用写 return。"]}),e.jsx(t,{lang:"vue",title:"<script setup>：顶层声明自动暴露",code:h}),e.jsxs(s,{variant:"tip",title:"实战默认用 <script setup>",children:["除非有特殊需要，单文件组件里几乎总是用 ",e.jsx("code",{children:"<script setup>"}),"：代码更少、 类型推断更好、运行时开销更小。本课程后续示例若无特别说明，都默认这种写法。"]}),e.jsx("h2",{children:"三、ref：包装任意值"}),e.jsxs("p",{children:[e.jsx("code",{children:"ref"})," 接收一个值，返回一个带 ",e.jsx("code",{children:".value"})," 属性的",e.jsx("strong",{children:"响应式引用对象"}),"。 它能包装任意类型——数字、字符串、布尔、对象、数组都行。规则只有一条但很关键： 在 JS / ",e.jsx("code",{children:"<script>"})," 里读写要带 ",e.jsx("code",{children:".value"}),"，而在",e.jsx("code",{children:"<template>"})," 里 Vue 会",e.jsx("strong",{children:"自动解包"}),"，直接写名字即可。"]}),e.jsx(t,{lang:"js",title:"ref 的读写规则",code:u}),e.jsxs("p",{children:["为什么是 ",e.jsx("code",{children:".value"})," 这么个略显啰嗦的设计？因为 JavaScript 的基本类型值 （数字、字符串等）是",e.jsx("strong",{children:"按值传递"}),"的，没法被代理、也无法在被传来传去时还保持 「同一个响应式源」。Vue 的办法是：用一个对象把值「装」进去，对这个对象的",e.jsx("code",{children:".value"})," 的读取与赋值就能被拦截，从而建立依赖追踪与触发更新。"]}),e.jsxs(c,{children:["基本类型必须用 ",e.jsx("code",{children:"ref"}),"，正是因为 ",e.jsx("code",{children:"reactive"})," 底层依赖 ES6 的",e.jsx("code",{children:"Proxy"}),"，而 ",e.jsx("code",{children:"Proxy"})," ",e.jsx("strong",{children:"只能代理对象"}),"，无法代理 数字、字符串这类原始值。",e.jsx("code",{children:"ref"})," 用「对象包一层 + 拦截 .value」绕开了这个限制。"]}),e.jsx("h2",{children:"四、reactive：代理对象"}),e.jsxs("p",{children:[e.jsx("code",{children:"reactive"})," 接收一个对象（或数组、Map、Set），返回它的",e.jsx("strong",{children:"响应式代理"}),"。 访问代理上的属性时不需要 ",e.jsx("code",{children:".value"}),"，直接像普通对象一样读写；嵌套的对象也会被 递归地转成响应式（深层代理）。"]}),e.jsx(t,{lang:"js",title:"reactive 代理一个对象",code:a}),e.jsxs("p",{children:["但 ",e.jsx("code",{children:"reactive"})," 有两个新手必踩的坑，根源都在于「响应性绑定在那个代理对象上」："]}),e.jsx(t,{lang:"js",title:"reactive 的两个坑：整体替换 & 解构",code:x}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"不能整体替换"}),"：给变量重新赋一个新对象，会让它指向一个全新的普通对象， 原来的代理被丢弃，而模板还引用着旧代理，界面便不再更新。要批量更新，应改属性 （如 ",e.jsx("code",{children:"Object.assign(state, newData)"}),"）而不是替换整个引用。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"解构会丢响应性"}),"：解构等于把属性当前的值拷贝出来，拷贝出的基本类型变量 和源代理之间再无联系，改谁都不影响对方。"]})]}),e.jsx("h2",{children:"五、toRef / toRefs：解决解构丢响应"}),e.jsxs("p",{children:["既想解构得到简洁的变量名、又不想丢响应性，就用 ",e.jsx("code",{children:"toRefs"})," 和 ",e.jsx("code",{children:"toRef"}),"。 它们把 ",e.jsx("code",{children:"reactive"})," 对象的属性「转成 ref」，而这些 ref 与源对象之间保持着",e.jsx("strong",{children:"双向连接"}),"：改 ref 的 ",e.jsx("code",{children:".value"})," 会反映到源，改源也会反映到 ref。"]}),e.jsx(t,{lang:"js",title:"toRefs 与 toRef 保住响应性",code:j}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"toRefs(obj)"}),"：把整个对象的每个属性都转成 ref，适合「解构整组属性」。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"toRef(obj, key)"}),"：只取单个属性转成 ref，适合「只想拎出一个」。"]})]}),e.jsxs(s,{variant:"info",title:"转成 ref 后记得带 .value",children:["被 ",e.jsx("code",{children:"toRefs"})," / ",e.jsx("code",{children:"toRef"})," 转出来的就是 ref 了，在 JS 里读写同样要带",e.jsx("code",{children:".value"}),"；在模板里依旧自动解包。它们没有「复制值」，而是建立了一条通向源属性的引用。"]}),e.jsx("h2",{children:"六、ref vs reactive：怎么选"}),e.jsx("p",{children:"两者都能做响应式状态，实战中如何取舍？下面这张表把差异摆清楚："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"ref"}),e.jsx("th",{children:"reactive"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"能包装的类型"}),e.jsx("td",{children:"任意值（含基本类型、对象）"}),e.jsx("td",{children:"仅对象 / 数组 / Map / Set"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"JS 里访问"}),e.jsxs("td",{children:["需 ",e.jsx("code",{children:".value"})]}),e.jsx("td",{children:"直接访问属性"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"模板里访问"}),e.jsx("td",{children:"自动解包，直接用"}),e.jsx("td",{children:"直接用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"整体替换"}),e.jsxs("td",{children:["可以（",e.jsx("code",{children:"x.value = 新值"}),"）"]}),e.jsx("td",{children:"不可，会丢响应性"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"解构"}),e.jsx("td",{children:"本身就是引用，安全"}),e.jsxs("td",{children:["会丢响应性，需 ",e.jsx("code",{children:"toRefs"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"底层机制"}),e.jsx("td",{children:"对象包一层 + 拦截 .value"}),e.jsx("td",{children:"Proxy 代理"})]})]})]}),e.jsxs("p",{children:["一个简单可用的经验法则：",e.jsxs("strong",{children:["默认用 ",e.jsx("code",{children:"ref"})]}),"。它能装任意类型， 整体替换和解构都不踩坑，心智负担最小。当你确实有一组紧密相关的属性、希望像普通对象那样 成组操作时，再考虑 ",e.jsx("code",{children:"reactive"}),"，并记得解构时配 ",e.jsx("code",{children:"toRefs"}),"。"]}),e.jsx("h2",{children:"七、动手：两个例子"}),e.jsx(r,{title:"例一：计数器（ref + computed）",children:e.jsxs("p",{children:["最经典的入门例子。",e.jsx("code",{children:"count"})," 是基本类型用 ",e.jsx("code",{children:"ref"}),"；",e.jsx("code",{children:"double"})," 是从 ",e.jsx("code",{children:"count"})," 派生出来的值，用 ",e.jsx("code",{children:"computed"}),"（下一章细讲）。注意在 ",e.jsx("code",{children:"<script setup>"})," 里改 ",e.jsx("code",{children:"count"})," 要带",e.jsx("code",{children:".value"}),"，模板里直接写名字。"]})}),e.jsx(t,{lang:"vue",title:"计数器组件",code:p}),e.jsx(r,{title:"例二：用户对象（reactive + toRefs）",children:e.jsxs("p",{children:["一组相关属性（姓名、年龄、嵌套的 profile）放进一个 ",e.jsx("code",{children:"reactive"})," 对象， 直接改属性即可触发更新；嵌套的 ",e.jsx("code",{children:"profile.city"})," 也是响应式的。 需要在模板里用解构出来的名字时，用 ",e.jsx("code",{children:"toRefs"})," 保住响应性。"]})}),e.jsx(t,{lang:"vue",title:"用户对象组件",code:f}),e.jsx("h2",{children:"八、小结与下一步"}),e.jsxs("p",{children:["这一章我们建立了组合式 API 的世界观：它按逻辑关注点组织代码、便于复用；",e.jsx("code",{children:"<script setup>"})," 让顶层声明自动暴露给模板；",e.jsx("code",{children:"ref"})," 能装任意值 （JS 里带 ",e.jsx("code",{children:".value"}),"，模板自动解包），",e.jsx("code",{children:"reactive"})," 代理对象 （不能整体替换、解构会丢响应），而 ",e.jsx("code",{children:"toRef"})," / ",e.jsx("code",{children:"toRefs"})," 专治解构丢响应。 下一章我们把目光转向「派生与侦听」——",e.jsx("code",{children:"computed"})," 与 ",e.jsx("code",{children:"watch"}),"。"]}),e.jsx(o,{points:["组合式 API 按「逻辑关注点」聚合代码，解决了选项式把同一功能拆散到 data/methods/computed 的痛点，且整段可抽成 composable 复用。","setup 是组合式入口；原始 setup() 必须显式 return，<script setup> 语法糖让顶层变量与函数自动暴露给模板。","ref 可包装任意值：JS / <script> 里读写需 .value，模板里自动解包；基本类型必须用 ref，因为 Proxy 无法代理原始值。","reactive 用 Proxy 代理对象，直接访问属性即可；但不能整体替换（会丢代理）、解构会丢响应性。","toRefs 把整个 reactive 对象的属性转成与源相连的 ref，toRef 只取单个属性，专治「解构丢响应」。","取舍法则：默认用 ref（任意类型、替换解构都安全）；一组紧密相关属性想成组操作时用 reactive，并配 toRefs 解构。"]})]})}export{b as default};
