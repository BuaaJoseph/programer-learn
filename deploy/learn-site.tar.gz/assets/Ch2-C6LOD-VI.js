import{j as e}from"./index-BdVncPlI.js";import{L as d,S as n}from"./Summary-Baiwq3-G.js";import{K as t}from"./KeyIdea-Cnr-5ipR.js";import{C as s}from"./Callout-BRUKkrb4.js";import{C as c}from"./CodeBlock-DCdshbU5.js";import{E as i}from"./Example-phQ905Fb.js";const r=`# 用官方脚手架创建一个 Vue 工程（基于 Vite）
npm create vue@latest

# 它会问你项目名，以及要不要 Router、Pinia、TypeScript、测试等
# 全部可按需勾选；初学先一路默认 / 不勾附加项即可

cd my-vue-app      # 进入刚创建的目录
npm install        # 安装依赖
npm run dev        # 启动开发服务器，终端会打印本地访问地址`,l=`my-vue-app/
├─ index.html          # 唯一的 HTML 入口，里面有 <div id="app">
├─ package.json
├─ vite.config.js      # Vite 配置
└─ src/
   ├─ main.js          # 应用入口：createApp(App).mount('#app')
   ├─ App.vue          # 根组件（单文件组件）
   └─ components/      # 你自己写的组件放这里`,o=`<!-- HelloWorld.vue —— 单文件组件的三段式结构 -->

<template>
  <!-- 1) 模板：描述视图长什么样 -->
  <p class="greeting">{{ message }}</p>
</template>

<script setup>
// 2) 脚本：组件的逻辑、状态、导入
import { ref } from 'vue'
const message = ref('你好，单文件组件！')
<\/script>

<style scoped>
/* 3) 样式：只作用于本组件的 CSS */
.greeting {
  color: #42b883;
  font-weight: bold;
}
</style>`,h=`// src/main.js —— 应用的入口与挂载链路
import { createApp } from 'vue'
import App from './App.vue'   // 引入根组件
import './style.css'          // 全局样式（可选）

// createApp(根组件) 创建应用实例，再 .mount 到页面上的某个节点
createApp(App).mount('#app')`,x=`<!-- index.html —— 挂载点就在这里 -->
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <title>My Vue App</title>
  </head>
  <body>
    <!-- createApp(App).mount('#app') 会把根组件渲染进这个 div -->
    <div id="app"></div>
    <script type="module" src="/src/main.js"><\/script>
  </body>
</html>`,p=`<!-- Counter.vue —— 组合式 API + script setup（本课主用写法） -->

<template>
  <div class="counter">
    <p>当前计数：{{ count }}</p>
    <button @click="increment">加一</button>
    <button @click="count = 0">归零</button>
  </div>
</template>

<script setup>
import { ref } from 'vue'

// ref 创建一个响应式的数字
const count = ref(0)

// 在脚本里改 count 要用 .value；模板里则自动解包，直接写 count
function increment() {
  count.value++
}
<\/script>

<style scoped>
.counter button {
  margin-right: 8px;
}
</style>`,j=`<!-- 同一个计数器，用选项式 API（Options API）写 —— 作对照 -->

<template>
  <div class="counter">
    <p>当前计数：{{ count }}</p>
    <button @click="increment">加一</button>
    <button @click="count = 0">归零</button>
  </div>
</template>

<script>
export default {
  // data 返回组件的响应式状态
  data() {
    return { count: 0 }
  },
  // methods 里放方法，this 指向组件实例
  methods: {
    increment() {
      this.count++
    }
  }
}
<\/script>`,u=`<style scoped>
/* scoped 让这段 CSS 只对当前组件生效，不会泄漏到别的组件 */
.title { color: tomato; }
</style>

<!-- 编译后，Vue 会给元素加上独有的属性标记，
     并把选择器改写成类似 .title[data-v-xxxxxx] 的形式，
     从而把样式「圈」在本组件内 -->`;function f(){return e.jsxs("article",{children:[e.jsxs(d,{children:["上一章我们建立了 Vue 的心智模型，这一章正式动手。我们会用官方脚手架基于",e.jsx("strong",{children:"Vite"})," 创建一个真正的工程，认识 Vue 开发的基本单位——",e.jsxs("strong",{children:["单文件组件（SFC，",e.jsx("code",{children:".vue"})," 文件）"]}),"，搞清楚应用是怎么从",e.jsx("code",{children:"main.js"})," 一路挂载到页面上的，最后亲手写一个会动的计数器， 并用组合式与选项式两种写法对照，理解我们为什么主用前者。"]}),e.jsx("h2",{children:"一、用 Vite 创建 Vue 工程"}),e.jsxs("p",{children:["现代 Vue 开发的标准起点是 ",e.jsx("strong",{children:"Vite"}),"——一个由尤雨溪团队打造的极快的前端构建工具。 它利用浏览器原生的 ES 模块实现近乎瞬时的开发服务器启动与热更新（HMR）， 体验比传统打包工具流畅得多。官方脚手架 ",e.jsx("code",{children:"create-vue"})," 就是基于 Vite 的， 一行命令就能把工程骨架搭好。"]}),e.jsx(c,{lang:"vue",title:"创建并启动一个 Vue 工程",code:r}),e.jsxs("p",{children:["执行后进入目录、安装依赖、启动开发服务器，终端会打印一个本地地址（通常是",e.jsx("code",{children:"http://localhost:5173"}),"），打开就能看到初始页面。之后你改任何源码， 页面会即时刷新。脚手架生成的目录大致如下："]}),e.jsx(c,{lang:"vue",title:"典型的工程目录结构",code:l}),e.jsxs(s,{variant:"note",title:"为什么是 Vite 而不是别的",children:["Vite 启动快、热更新快，且与 Vue 同源、配合无缝，已是 Vue 官方推荐的默认构建工具。 老项目里你可能见过基于 Webpack 的 Vue CLI，但新项目一律推荐 ",e.jsx("code",{children:"npm create vue@latest"}),"。"]}),e.jsx("h2",{children:"二、单文件组件（SFC）：三段式结构"}),e.jsxs("p",{children:["Vue 开发的基本单位是",e.jsx("strong",{children:"单文件组件"}),"，文件后缀是 ",e.jsx("code",{children:".vue"}),"。 它的精妙之处在于：把一个组件相关的「结构、逻辑、样式」三件事， 放进同一个文件的三个区块里，彼此邻近又职责分明。"]}),e.jsxs(t,{children:["一个 ",e.jsx("code",{children:".vue"})," 文件由三段构成：",e.jsx("code",{children:"<template>"})," 写视图结构、",e.jsx("code",{children:"<script setup>"})," 写逻辑与状态、",e.jsx("code",{children:"<style scoped>"})," 写只属于本组件的样式。 关注点集中而不混乱，这是 Vue 组织代码的核心方式。"]}),e.jsx(c,{lang:"vue",title:"单文件组件的三段式",code:o}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"区块"}),e.jsx("th",{children:"职责"}),e.jsx("th",{children:"说明"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"<template>"})}),e.jsx("td",{children:"视图结构"}),e.jsx("td",{children:"类 HTML，支持插值与指令"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"<script setup>"})}),e.jsx("td",{children:"逻辑与状态"}),e.jsx("td",{children:"组合式 API 的现代写法"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"<style scoped>"})}),e.jsx("td",{children:"组件样式"}),e.jsx("td",{children:"scoped 让 CSS 只作用于本组件"})]})]})]}),e.jsxs(s,{variant:"tip",title:"script setup 是什么",children:[e.jsx("code",{children:"<script setup>"})," 是组合式 API 的语法糖：在这个块里顶层声明的变量、函数、 导入的组件，会",e.jsx("strong",{children:"自动暴露"}),"给模板使用，不用再手写 ",e.jsx("code",{children:"return"}),"。 它是目前 Vue 3 最简洁、最推荐的组件写法，本课全程使用它。"]}),e.jsx("h2",{children:"三、挂载链路：从 main.js 到页面"}),e.jsxs("p",{children:["组件写好了，应用是怎么「跑起来」并出现在页面上的？这条链路只有三个环节，但很值得看清楚。 起点是 ",e.jsx("code",{children:"index.html"}),"，它是整个应用唯一的 HTML 文件，里面有一个空的挂载点",e.jsx("code",{children:'<div id="app">'}),"，还引入了入口脚本 ",e.jsx("code",{children:"main.js"}),"。"]}),e.jsx(c,{lang:"vue",title:"index.html：挂载点所在",code:x}),e.jsxs("p",{children:["入口脚本 ",e.jsx("code",{children:"main.js"})," 做三件事：引入根组件 ",e.jsx("code",{children:"App.vue"}),"、 用 ",e.jsx("code",{children:"createApp(App)"})," 创建一个应用实例、再用",e.jsx("code",{children:".mount('#app')"})," 把它挂到 ",e.jsx("code",{children:"index.html"})," 里那个 ",e.jsx("code",{children:"#app"})," 节点上。 挂载完成后，Vue 接管这个节点，把 ",e.jsx("code",{children:"App.vue"})," 及其所有子组件渲染进去。"]}),e.jsx(c,{lang:"vue",title:"main.js：创建应用并挂载",code:h}),e.jsx(i,{title:"一句话串起整条链路",children:e.jsxs("p",{children:[e.jsx("code",{children:"index.html"})," 提供空容器 ",e.jsx("code",{children:"#app"})," → "," ",e.jsx("code",{children:"main.js"})," 里 ",e.jsx("code",{children:"createApp(App)"})," 造出应用"," → "," ",e.jsx("code",{children:".mount('#app')"})," 把根组件 ",e.jsx("code",{children:"App.vue"})," 渲染进那个容器。 一个 Vue 应用通常只有",e.jsx("strong",{children:"一个根组件、一次 mount"}),"，其余都是它的子组件。"]})}),e.jsx("h2",{children:"四、写第一个组件：一个会动的计数器"}),e.jsxs("p",{children:["现在把前面的知识落到一个最小但完整的交互组件上——计数器。它要做的事很简单： 显示一个数字，点「加一」按钮数字加一，点「归零」按钮数字清零。 我们用",e.jsxs("strong",{children:["组合式 API + ",e.jsx("code",{children:"<script setup>"})]}),"来写。"]}),e.jsx(c,{lang:"vue",title:"Counter.vue：组合式 API 写法",code:p}),e.jsx("p",{children:"拆解一下这个组件用到的几件事："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"ref(0)"})}),"：创建一个初始值为 0 的响应式数据 ",e.jsx("code",{children:"count"}),"。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:["模板插值 ",e.jsx("code",{children:"{{ count }}"})]}),"：把 ",e.jsx("code",{children:"count"})," 显示到页面上；它变，显示就变。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"@click"})}),"：监听按钮点击，",e.jsx("code",{children:'@click="increment"'})," 绑定方法，",e.jsx("code",{children:'@click="count = 0"'})," 直接写内联表达式。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"count.value++"})}),"：在脚本里改 ",e.jsx("code",{children:"ref"})," 必须通过 ",e.jsx("code",{children:".value"}),"； 但模板里 Vue 自动解包，所以模板写 ",e.jsx("code",{children:"count"})," 即可。"]})]}),e.jsxs(s,{variant:"warn",title:"别忘了 .value",children:["新手最常见的坑：在 ",e.jsx("code",{children:"<script>"})," 里直接写 ",e.jsx("code",{children:"count++"})," 而漏掉",e.jsx("code",{children:".value"}),"。脚本中操作 ",e.jsx("code",{children:"ref"})," 一律要带 ",e.jsx("code",{children:".value"}),"， 只有模板里才自动解包。改的是数据，视图会自己更新——这正是上一章「改数据→视图更新」的承诺在起作用。"]}),e.jsxs("h2",{children:["五、","<style scoped>"," 的作用"]}),e.jsxs("p",{children:["计数器里那段 ",e.jsx("code",{children:"<style scoped>"})," 看着普通，但 ",e.jsx("code",{children:"scoped"})," 这个词很关键。 默认情况下，CSS 是",e.jsx("strong",{children:"全局"}),"的——一个组件里写的 ",e.jsx("code",{children:".button { ... }"}),"会影响到页面上所有 ",e.jsx("code",{children:".button"}),"，组件一多就容易样式互相污染。"]}),e.jsxs("p",{children:["加上 ",e.jsx("code",{children:"scoped"})," 后，Vue 会在编译时给本组件的元素打上一个独有的属性标记， 并把你的选择器改写成「带这个标记」的形式，于是这段样式",e.jsx("strong",{children:"只作用于当前组件"}),"， 不会泄漏出去，也不会被外部误伤。"]}),e.jsx(c,{lang:"vue",title:"scoped 把样式圈在组件内",code:u}),e.jsxs(s,{variant:"tip",title:"一个组件一份样式",children:["有了 ",e.jsx("code",{children:"scoped"}),"，你可以放心地在每个组件里用简短、语义化的类名， 不必担心和别处冲突。这让「组件自带样式」变得安全且自然。"]}),e.jsx("h2",{children:"六、两种风格对照：组合式 vs 选项式"}),e.jsxs("p",{children:["Vue 3 支持两种组织组件逻辑的风格。上面用的是",e.jsx("strong",{children:"组合式 API（Composition API）"}),"， 把状态和逻辑用 ",e.jsx("code",{children:"ref"}),"、函数等自由组合在 ",e.jsx("code",{children:"<script setup>"})," 里。 而 Vue 2 时代的主流是",e.jsx("strong",{children:"选项式 API（Options API）"}),"， 把组件拆成 ",e.jsx("code",{children:"data"}),"、",e.jsx("code",{children:"methods"})," 等固定的「选项」。同一个计数器，选项式这样写："]}),e.jsx(c,{lang:"vue",title:"同一个计数器：选项式 API 写法",code:j}),e.jsxs("p",{children:["对照着看：选项式里状态放进 ",e.jsx("code",{children:"data()"})," 返回的对象，方法放进 ",e.jsx("code",{children:"methods"}),"， 访问状态要用 ",e.jsx("code",{children:"this.count"}),"，而且",e.jsx("strong",{children:"不需要"})," ",e.jsx("code",{children:".value"}),"； 组合式里则用 ",e.jsx("code",{children:"ref"})," 声明、用 ",e.jsx("code",{children:".value"})," 读写，没有 ",e.jsx("code",{children:"this"})," 的概念。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"组合式 API（script setup）"}),e.jsx("th",{children:"选项式 API"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"状态声明"}),e.jsx("td",{children:e.jsx("code",{children:"const count = ref(0)"})}),e.jsx("td",{children:e.jsx("code",{children:"data() { return { count: 0 } }"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"访问状态"}),e.jsxs("td",{children:[e.jsx("code",{children:"count.value"}),"（模板里 ",e.jsx("code",{children:"count"}),"）"]}),e.jsx("td",{children:e.jsx("code",{children:"this.count"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"方法"}),e.jsx("td",{children:"普通函数，顶层声明即可"}),e.jsxs("td",{children:["放进 ",e.jsx("code",{children:"methods"})," 选项"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"逻辑组织"}),e.jsx("td",{children:"按「关注点」自由组合，易复用"}),e.jsx("td",{children:"按「选项类型」分块"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"适用"}),e.jsx("td",{children:"大组件、逻辑复用、现代项目"}),e.jsx("td",{children:"简单组件、Vue 2 习惯、教学入门"})]})]})]}),e.jsxs(t,{children:["本课全程主用",e.jsxs("strong",{children:["组合式 API + ",e.jsx("code",{children:"<script setup>"})]}),"。 它在大型组件里能把相关逻辑聚到一起、便于抽取复用，是 Vue 3 官方推荐的现代写法。 选项式依然完全可用，了解它能帮你读懂大量存量代码，但我们以组合式为主线。"]}),e.jsx("h2",{children:"七、本章小结与下一步"}),e.jsxs("p",{children:["到这里你已经能创建工程、看懂单文件组件、理解挂载链路，并写出一个会动的组件。 这是从「知道 Vue 是什么」到「能用 Vue 干活」的关键一跃。接下来的章节， 我们会深入响应式（",e.jsx("code",{children:"ref"})," / ",e.jsx("code",{children:"reactive"})," / ",e.jsx("code",{children:"computed"})," / ",e.jsx("code",{children:"watch"}),"）、 模板语法与指令、组件通信等核心主题，逐步把这个心智模型填充成扎实的工程能力。"]}),e.jsx(s,{variant:"tip",children:"动手建议：把本章的计数器亲手敲一遍跑起来，再试着加一个「减一」按钮， 体会「只改数据、不碰 DOM」的开发手感。"}),e.jsx(n,{points:["用 npm create vue@latest 基于 Vite 创建工程：进目录、npm install、npm run dev 即可启动。","单文件组件（.vue）三段式：<template> 写结构、<script setup> 写逻辑、<style scoped> 写本组件样式。",'挂载链路：index.html 提供 #app 空容器 → main.js 用 createApp(App) 创建应用 → .mount("#app") 渲染根组件。',"第一个计数器：ref(0) 建响应式数据，模板插值 {{ count }} 显示，@click 绑定交互，脚本里改要用 .value。","scoped 让样式只作用于当前组件，编译期加属性标记改写选择器，避免全局污染。","组合式 API（本课主用）按关注点组织、便于复用，用 ref + .value，无 this；选项式用 data/methods + this，适合入门与读旧代码。"]})]})}export{f as default};
