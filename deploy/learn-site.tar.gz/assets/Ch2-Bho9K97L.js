import{j as e}from"./index-qtIRnDEm.js";import{L as n,S as c}from"./Summary-D7M9FdYM.js";import{K as o}from"./KeyIdea-C5mX38F7.js";import{C as s}from"./Callout-Bvq_rfqV.js";import{C as r}from"./CodeBlock-DsDQiuPI.js";import{E as p}from"./Example-Ba1iSJHN.js";const i=`my-monorepo/
├── package.json            # 根 package.json：管工具链与公共脚本，private: true
├── pnpm-workspace.yaml     # 声明哪些目录是 workspace 成员
├── turbo.json              # Turborepo 任务编排配置
├── apps/                   # 可独立部署的应用
│   ├── web/                #   官网（依赖 packages/ui、packages/utils）
│   │   └── package.json
│   └── admin/              #   后台
│       └── package.json
└── packages/               # 被复用的内部包（库 / 配置 / 组件）
    ├── ui/                 #   共享组件库
    │   └── package.json
    ├── utils/              #   共享工具函数
    │   └── package.json
    └── tsconfig/           #   共享 TS 配置`,t=`# pnpm-workspace.yaml —— 告诉 pnpm 哪些目录是工作区成员
packages:
  - "apps/*"
  - "packages/*"
  # 也可以排除：
  # - "!**/test/**"`,d=`{
  "name": "my-monorepo",
  "private": true,
  "packageManager": "pnpm@9.7.0",
  "scripts": {
    "build": "turbo run build",
    "dev": "turbo run dev",
    "test": "turbo run test",
    "lint": "turbo run lint"
  },
  "devDependencies": {
    "turbo": "^2.1.0",
    "typescript": "^5.5.0"
  }
}`,l=`// apps/web/package.json —— 应用引用内部包
{
  "name": "web",
  "dependencies": {
    "@myorg/ui": "workspace:*",     // 永远用工作区里的本地版本，不去 registry 找
    "@myorg/utils": "workspace:*",
    "react": "^18.3.1"
  }
}

// packages/ui/package.json —— 被引用的内部包
{
  "name": "@myorg/ui",
  "version": "0.1.0",
  "main": "src/index.ts"
}`,a=`// apps/web/src/App.tsx
// 像引用任何 npm 包一样引用本地内部包 —— pnpm 已把它符号链接进 node_modules
import { Button } from '@myorg/ui'
import { formatDate } from '@myorg/utils'

export function App() {
  return <Button>{formatDate(Date.now())}</Button>
}`,h=`{
  "$schema": "https://turbo.build/schema.json",
  "tasks": {
    "build": {
      "dependsOn": ["^build"],          // ^ 表示「先构建本包的依赖包」=> 拓扑顺序
      "outputs": ["dist/**", ".next/**"] // 声明产物路径，供缓存命中后直接还原
    },
    "test": {
      "dependsOn": ["build"]            // 测试前先构建（同一个包内）
    },
    "lint": {},
    "dev": {
      "cache": false,                   // dev 是长任务，不缓存
      "persistent": true
    }
  }
}`,j=`# 全量：按拓扑顺序构建所有包，命中缓存的直接跳过
turbo run build

# 只跑「受改动影响」的包及其下游（基于 git diff）
turbo run build --filter="...[origin/main]"

# 只构建某个应用及其依赖链
turbo run build --filter=web

# 远程缓存：把构建产物上传/下载共享，CI 与同事之间复用
turbo run build --remote-only`;function w(){return e.jsxs("article",{children:[e.jsxs(n,{children:["当一个项目长大到「官网 + 后台 + 移动端 + 一堆共享组件和工具」，你会面临一个组织问题： 是把它们拆成一个个独立仓库（polyrepo），还是塞进同一个仓库统一管理（monorepo）？ 这一章讲清 Monorepo 是什么、值不值得，再手把手用 ",e.jsx("strong",{children:"pnpm workspace"})," 把多个包组织起来， 用 ",e.jsx("strong",{children:"Turborepo"})," 解决「这么多包，怎么高效地只构建该构建的」。"]}),e.jsx("h2",{children:"一、Monorepo 是什么"}),e.jsxs(o,{children:["Monorepo（单一仓库）= ",e.jsx("strong",{children:"一个 git 仓库里管理多个包 / 应用"}),"。它不是把代码乱堆在一起， 而是有清晰边界的多个包共处一仓，彼此可直接引用、统一工具链、一次提交就能跨包改动。"]}),e.jsxs("p",{children:["注意 Monorepo 和「巨型单体应用（monolith）」是两回事。Monolith 指一坨没有内部边界的大代码； Monorepo 恰恰相反，仓库里是",e.jsx("strong",{children:"多个边界分明的包"}),"，只是住在同一个仓库里。 Google、Meta 这类公司用超大型 Monorepo 管理几乎全部代码，前端世界里 React、Vue、Babel 等知名项目也都是 Monorepo。"]}),e.jsx("h2",{children:"二、好处与代价"}),e.jsx("p",{children:"Monorepo 流行不是赶时髦，它实打实解决了多包协作的几个痛点；但它也不是免费的， 代价主要落在「仓库变大」和「需要工具来编排」。"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"好处"}),e.jsx("th",{children:"说明"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"代码共享零成本"}),e.jsx("td",{children:"共享组件 / 工具直接以本地包形式被引用，改了立刻生效，不必发版再安装"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"原子提交"}),e.jsx("td",{children:"一次跨多个包的改动（比如改接口同时改所有调用方）能在一个 commit / PR 里完成，永不版本错位"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"统一工具链"}),e.jsx("td",{children:"ESLint、TS 配置、CI、依赖版本全仓统一，新人一次配置处处可用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"可见性"}),e.jsx("td",{children:"谁用了哪个包、改它会影响谁，一目了然，重构有底气"})]})]})]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"代价"}),e.jsx("th",{children:"说明"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"仓库体积大"}),e.jsx("td",{children:"所有代码挤在一起，clone / 拉取变重，超大规模还需 sparse-checkout 等手段"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"需要任务编排"}),e.jsx("td",{children:"「构建全部」会重复跑很多活，必须有工具按依赖顺序、只跑受影响的包，并复用缓存"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"权限 / CI 更复杂"}),e.jsx("td",{children:"谁能改哪个包、CI 如何只测改动相关部分，都需要额外设计"})]})]})]}),e.jsx("h3",{children:"polyrepo vs monorepo 怎么选"}),e.jsxs("p",{children:[e.jsx("strong",{children:"polyrepo"}),"（每个包一个仓库）的优点是边界天然、权限好分、仓库轻；代价是跨包改动要发版 + 升级 + 联调，依赖版本极易错位，「改一处牵动多仓」非常痛苦。",e.jsx("strong",{children:"monorepo"})," 反过来：跨包改动顺滑、共享省心，代价是要工具撑起编排与缓存。 经验法则：",e.jsx("strong",{children:"包之间耦合紧、需要频繁联动改动"}),"，选 monorepo；",e.jsx("strong",{children:"各自独立、由不同团队拥有、发布节奏完全不同"}),"，polyrepo 更省心。"]}),e.jsx("h2",{children:"三、用 pnpm workspace 组织 Monorepo"}),e.jsxs("p",{children:["pnpm 对 workspace 的支持体验最好（也正因为上一章讲的严格依赖结构）。它要的东西很少： 一个 ",e.jsx("code",{children:"pnpm-workspace.yaml"})," 声明成员目录，一个根 ",e.jsx("code",{children:"package.json"})," 管工具链， 各个包用 ",e.jsx("code",{children:"workspace:*"})," 协议互相引用。"]}),e.jsx("h3",{children:"典型目录结构：apps/* + packages/*"}),e.jsxs("p",{children:["最常见的约定是两层：",e.jsx("code",{children:"apps/"})," 放可独立部署的应用，",e.jsx("code",{children:"packages/"}),"放被复用的内部包（组件库、工具函数、共享配置）。应用引用包，包之间也可以互相引用。"]}),e.jsx(r,{lang:"bash",title:"一个典型的 Monorepo 目录",code:i}),e.jsx("h3",{children:"pnpm-workspace.yaml：声明成员"}),e.jsxs("p",{children:["这个文件告诉 pnpm：哪些目录下的 ",e.jsx("code",{children:"package.json"})," 算工作区成员。pnpm 会把它们当作 一个整体来解析依赖、做提升与链接。"]}),e.jsx(r,{lang:"json",title:"pnpm-workspace.yaml",code:t}),e.jsx("h3",{children:"根 package.json：工具链与公共脚本"}),e.jsxs("p",{children:["根包通常标 ",e.jsx("code",{children:"private: true"}),"（它不发布），集中放公共 devDependencies（如 turbo、typescript）， 并把全仓脚本统一委托给 Turborepo。",e.jsx("code",{children:"packageManager"})," 字段把团队锁定到同一个 pnpm 版本。"]}),e.jsx(r,{lang:"json",title:"根 package.json",code:d}),e.jsx("h3",{children:"workspace:* 协议：让本地包互相引用"}),e.jsxs(o,{children:[e.jsx("code",{children:"workspace:*"})," 是 Monorepo 的黏合剂：在某个包的依赖里写",e.jsx("code",{children:'"@myorg/ui": "workspace:*"'}),"，意思是「用工作区里那个本地的 @myorg/ui， 别去 npm registry 下载」。pnpm 会把本地包",e.jsx("strong",{children:"符号链接"}),"进 node_modules， 改了源码立刻生效，无需发版。"]}),e.jsx(r,{lang:"json",title:"用 workspace:* 引用本地包",code:l}),e.jsx("p",{children:"引用之后，在应用代码里就像引用任何 npm 包一样 import 它——这正是「代码共享零成本」的由来。"}),e.jsx(r,{lang:"bash",title:"在应用里 import 本地包",code:a}),e.jsxs(s,{variant:"note",title:"发布时 workspace:* 会被自动改写",children:["如果某个内部包要发布到 npm，发布工具（如 pnpm publish / changesets）会在打包时把",e.jsx("code",{children:"workspace:*"})," 替换成真实的版本号（如 ",e.jsx("code",{children:"^0.1.0"}),"）， 所以下游用户拿到的是正常的版本范围，不会看到 ",e.jsx("code",{children:"workspace:"})," 这种本地协议。"]}),e.jsx("h2",{children:"四、用 Turborepo 做任务编排"}),e.jsxs("p",{children:["包多了之后，「构建全部」会遇到三个真问题：① 顺序——@myorg/ui 必须先于依赖它的 web 构建； ② 重复——没改过的包不该重复构建；③ 范围——改了一个包，没必要把全仓都重跑一遍。",e.jsx("strong",{children:"Turborepo"})," 就是来解决这三件事的任务编排器。"]}),e.jsx("h3",{children:"拓扑顺序：dependsOn 与 ^"}),e.jsxs("p",{children:["Turborepo 读各包的依赖关系建出一张",e.jsx("strong",{children:"依赖图"}),"，据此决定任务执行顺序。",e.jsx("code",{children:"turbo.json"})," 里 ",e.jsx("code",{children:"dependsOn"})," 中的 ",e.jsx("code",{children:"^"})," 前缀是关键：",e.jsx("code",{children:'"dependsOn": ["^build"]'})," 表示「在构建本包前，先构建本包的所有依赖包」—— 这就保证了",e.jsx("strong",{children:"拓扑顺序"}),"，且互不依赖的包还能",e.jsx("strong",{children:"并行"}),"构建。"]}),e.jsx(r,{lang:"json",title:"turbo.json",code:h}),e.jsx("h3",{children:"增量缓存：算过的别再算"}),e.jsxs("p",{children:["Turborepo 给每个任务算一个",e.jsx("strong",{children:"哈希指纹"}),"（基于输入文件、依赖、环境变量、配置）。 指纹没变，说明输入没变，输出必然一样——于是它",e.jsx("strong",{children:"跳过执行，直接还原上次缓存的产物与日志"}),"， 这就是「命中缓存」。这要求你在 ",e.jsx("code",{children:"outputs"})," 里如实声明产物路径，缓存才知道要存 / 还原什么。 日常开发中，「只改了一个包」往往让大半个仓库的 build 秒级命中缓存。"]}),e.jsx("h3",{children:"只跑受影响的包：--filter"}),e.jsxs("p",{children:[e.jsx("code",{children:"--filter"})," 让你按依赖图裁剪要跑的范围。最常用的是基于 git 的",e.jsx("code",{children:'--filter="...[origin/main]"'}),"：只跑相对某分支有改动的包",e.jsx("strong",{children:"以及依赖它们的下游包"}),"， 其余一概不碰。CI 里这一招能把「全量跑一小时」压到「只跑改动相关的几分钟」。"]}),e.jsx(r,{lang:"bash",title:"Turborepo 常用命令",code:j}),e.jsx("h3",{children:"远程缓存：团队与 CI 之间复用"}),e.jsxs("p",{children:["本地缓存只惠及你自己；",e.jsx("strong",{children:"远程缓存"}),"把任务产物上传到共享存储，于是同事、CI 之间能互相复用： CI 构建过的产物，你本地拉下来直接命中；你构建过的，CI 也能用。对中大型团队，这往往是 Turborepo 提速最显著的一环——「别人已经构建过的，整个团队都不必再构建第二次」。"]}),e.jsxs(p,{title:"一次改动在 Turborepo 下的真实流程",children:[e.jsxs("p",{children:["你只改了 ",e.jsx("code",{children:"packages/utils"})," 里一个函数，跑 ",e.jsx("code",{children:"turbo run build test"}),"："]}),e.jsx("p",{children:"① Turborepo 算指纹，发现 utils 变了；"}),e.jsxs("p",{children:["② 受影响的是 utils 本身、以及依赖它的 web、admin；packages/ui 没依赖 utils，",e.jsx("strong",{children:"命中缓存跳过"}),"；"]}),e.jsx("p",{children:"③ 按拓扑顺序构建 utils → 再并行构建 web、admin；"}),e.jsx("p",{children:"④ 没受影响的任务全部秒过。一个改动只触发了真正必要的工作。"})]}),e.jsx(s,{variant:"note",title:"Turborepo 与 Nx 一句话",children:"Nx 是另一套主流 Monorepo 工具，能力更全（代码生成器、插件体系、模块边界约束、可视化依赖图等）， 更「重」也更体系化；Turborepo 走极简路线，配置少、上手快，专注任务编排与缓存。 小到中型前端 Monorepo 多选 Turborepo，需要强治理与生成器能力时考虑 Nx。"}),e.jsx("h2",{children:"五、边界与实务建议"}),e.jsxs("p",{children:["几个常见坑：",e.jsx("strong",{children:"outputs 没声明全"}),"会导致缓存命中后产物缺失，构建「看似成功实则不全」， 务必把所有产物目录写进 ",e.jsx("code",{children:"turbo.json"}),"；",e.jsx("strong",{children:"带副作用 / 随机性的任务不要缓存"}),"（如 dev、deploy），给它们设 ",e.jsx("code",{children:'"cache": false'}),"；",e.jsx("strong",{children:"环境变量影响产物"}),"时 要在配置里声明进哈希，否则换了环境却命中了旧缓存。最后，Monorepo 不是越大越好—— 如果包之间根本不联动、由完全独立的团队拥有，硬塞进一个仓库只会徒增 CI 与权限的复杂度。"]}),e.jsxs(s,{variant:"tip",children:["组合拳就此成型：",e.jsx("strong",{children:"pnpm workspace"})," 负责「把多个包组织进一个仓、用 workspace:* 互相引用」，",e.jsx("strong",{children:"Turborepo"})," 负责「按拓扑顺序、只跑受影响的、最大化复用缓存」。 前者解决结构，后者解决效率，二者相加就是现代前端 Monorepo 的主流方案。"]}),e.jsx(c,{points:["Monorepo = 一个仓库管多个有边界的包/应用（区别于无边界的 monolith），带来代码共享、原子提交、统一工具链。","代价是仓库变大、必须有任务编排与缓存、CI/权限更复杂；包间耦合紧选 monorepo，各自独立选 polyrepo。","pnpm workspace 三件套：pnpm-workspace.yaml 声明成员、根 package.json（private + packageManager）管工具链、workspace:* 协议引用本地包。","workspace:* 让本地包以符号链接被引用，改了立刻生效、无需发版；发布时会被自动改写成真实版本号。","Turborepo 做任务编排：dependsOn 的 ^ 保证拓扑顺序并行构建、指纹哈希实现增量缓存、--filter 只跑受影响的包、远程缓存让团队与 CI 复用产物。","实务：outputs 要声明全、dev/deploy 设 cache:false、影响产物的环境变量要入哈希；Nx 更重更全，中小前端 Monorepo 多用 Turborepo。"]})]})}export{w as default};
