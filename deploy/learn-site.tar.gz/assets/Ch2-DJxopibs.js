import{j as e}from"./index-CBMe5udE.js";import{L as s,S as i}from"./Summary-CEfAQ4SZ.js";import{K as n}from"./KeyIdea-K3hFePn1.js";import{C as r}from"./Callout-3wJQ5WDp.js";import{C as t}from"./CodeBlock-D4LRiuTl.js";import{E as d}from"./Example-CFOi3F9j.js";const c=`<!-- Counter.vue：我们要测试的目标组件 -->
<script setup>
import { ref } from 'vue'

const props = defineProps({ start: { type: Number, default: 0 } })
const count = ref(props.start)

function increment() {
  count.value++
}
<\/script>

<template>
  <div>
    <span class="count">{{ count }}</span>
    <button @click="increment">加一</button>
  </div>
</template>`,l=`// Counter.spec.js —— 用 Vitest + Vue Test Utils 测试 Counter 组件
import { describe, it, expect } from 'vitest'
import { mount } from '@vue/test-utils'
import Counter from './Counter.vue'

describe('Counter', () => {
  it('默认从 0 开始渲染', () => {
    const wrapper = mount(Counter)            // mount：完整挂载组件
    expect(wrapper.find('.count').text()).toBe('0')
  })

  it('接受 start prop 作为初始值', () => {
    const wrapper = mount(Counter, {
      props: { start: 10 },                   // 通过挂载选项传 props
    })
    expect(wrapper.find('.count').text()).toBe('10')
  })

  it('点击按钮后计数加一', async () => {
    const wrapper = mount(Counter)
    // trigger 触发事件；它返回 Promise，await 它以等 DOM 更新完成
    await wrapper.find('button').trigger('click')
    expect(wrapper.find('.count').text()).toBe('1')

    await wrapper.find('button').trigger('click')
    expect(wrapper.find('.count').text()).toBe('2')  // 断言渲染结果
  })
})`,o=`// findComponent / shallowMount 常用法
import { mount, shallowMount } from '@vue/test-utils'
import Parent from './Parent.vue'
import Child from './Child.vue'

// shallowMount：把子组件「打桩」成占位符，只测当前组件自身逻辑，
// 不连带渲染整棵子树——隔离性更好、更快。
const wrapper = shallowMount(Parent)

// findComponent：按组件查找子组件实例，比按 CSS 选择器更稳
const child = wrapper.findComponent(Child)
expect(child.exists()).toBe(true)
expect(child.props('title')).toBe('你好')

// emitted：断言子组件触发了某个自定义事件
await child.vm.$emit('submit', { id: 1 })
expect(wrapper.emitted('submit')).toBeTruthy()`,h=`// 测 composable：它就是个普通函数，直接调、断言返回值即可
import { describe, it, expect } from 'vitest'
import { useCounter } from './useCounter'

it('useCounter 能自增', () => {
  const { count, inc } = useCounter()
  inc()
  expect(count.value).toBe(1)
})

// 测 Pinia store：在测试里 setActivePinia(createPinia()) 后照常用 store
import { setActivePinia, createPinia } from 'pinia'
import { useCartStore } from './cart'

it('购物车能加商品', () => {
  setActivePinia(createPinia())   // 每个测试给一个干净的 Pinia 实例
  const cart = useCartStore()
  cart.add({ id: 1 })
  expect(cart.items.length).toBe(1)
})`,x=`// Vue 2 → Vue 3：应用入口的破坏性变更
// —— Vue 2：用全局构造函数 new Vue
import Vue from 'vue'
import App from './App.vue'
new Vue({ render: h => h(App) }).$mount('#app')

// —— Vue 3：用 createApp，全局 API 挂在「应用实例」上而非全局 Vue
import { createApp } from 'vue'
import App from './App.vue'
const app = createApp(App)
app.use(router)          // 插件、指令、组件都注册到 app 上
app.mount('#app')`,j=`<!-- 迁移思路：选项式 API 仍可用，但推荐逐步转向组合式 API -->
<!-- Vue 2 选项式：逻辑被拆进 data / methods -->
<script>
export default {
  data: () => ({ count: 0 }),
  methods: { inc() { this.count++ } },
}
<\/script>

<!-- Vue 3 组合式：相关逻辑聚在一起，更易复用 -->
<script setup>
import { ref } from 'vue'
const count = ref(0)
const inc = () => count.value++
<\/script>`;function f(){return e.jsxs("article",{children:[e.jsxs(s,{children:["恭喜你走到了最后一章。前面我们把 Vue 3 从语法、响应式、组件，一路讲到了路由、状态管理、 SSR 与 Nuxt。这一章是",e.jsx("strong",{children:"收束卷"}),"：先补上工程化里绕不开的一块——",e.jsx("strong",{children:"测试"}),"，让你写的组件「可被验证」；再讲 ",e.jsx("strong",{children:"Vue 2 → Vue 3 迁移"}),"， 帮你看懂老项目；最后给出一张",e.jsx("strong",{children:"Vue 生态地图"}),"和一条进阶学习路径，把整门课 串成一个完整的知识网络。"]}),e.jsx("h2",{children:"一、前端测试金字塔"}),e.jsxs("p",{children:["「测试」不是一种东西，而是一组层次。经典的",e.jsx("strong",{children:"测试金字塔"}),"从下往上把测试分成三层， 越往下越多、越快、越便宜；越往上越少、越慢、越接近真实用户。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"层级"}),e.jsx("th",{children:"测什么"}),e.jsx("th",{children:"数量 / 速度"}),e.jsx("th",{children:"典型工具"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("strong",{children:"单元测试"}),"（底层，最多）"]}),e.jsx("td",{children:"单个函数 / composable / 组件的逻辑"}),e.jsx("td",{children:"大量、毫秒级、最便宜"}),e.jsx("td",{children:"Vitest + Vue Test Utils"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("strong",{children:"集成测试"}),"（中层）"]}),e.jsx("td",{children:"多个组件 / 模块协作是否正确"}),e.jsx("td",{children:"中等"}),e.jsx("td",{children:"Vitest + VTU"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("strong",{children:"端到端测试 E2E"}),"（顶层，最少）"]}),e.jsx("td",{children:"真浏览器里走完整用户流程"}),e.jsx("td",{children:"少量、秒级、最贵"}),e.jsx("td",{children:"Playwright / Cypress"})]})]})]}),e.jsxs(n,{children:["测试金字塔的指导思想是：",e.jsx("strong",{children:"把绝大多数测试放在便宜、快速的底层（单元测试）， 顶层昂贵的 E2E 只覆盖最关键的几条用户主流程"}),"。倒过来写成「冰淇淋筒」 （E2E 一大堆、单测寥寥）会让测试套件又慢又脆，得不偿失。"]}),e.jsx("h2",{children:"二、用 Vitest + Vue Test Utils 测组件"}),e.jsxs("p",{children:["在 Vue 生态里，单元测试的黄金组合是 ",e.jsx("strong",{children:"Vitest"}),"（测试运行器，与 Vite 共享配置、原生支持 ESM 和 TypeScript、启动飞快）加上 ",e.jsx("strong",{children:"Vue Test Utils（VTU）"}),"（官方组件测试库，提供挂载组件、查询 DOM、触发事件的工具）。先看要测的组件："]}),e.jsx(t,{lang:"vue",title:"Counter.vue：被测组件",code:c}),e.jsx("p",{children:"VTU 的核心 API 不多，记住这几个就能覆盖大部分场景："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"mount"}),"：完整挂载组件（连同子组件一起渲染），返回一个",e.jsx("code",{children:"wrapper"})," 包装对象。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"shallowMount"}),"：浅挂载，把子组件「打桩」成占位符，只测当前组件自身——隔离更彻底、更快。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"wrapper.find('.count')"})," / ",e.jsx("code",{children:"findComponent"}),"：按 CSS 选择器 / 按组件查找节点或子组件。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"trigger('click')"}),"：触发 DOM 事件；它返回 Promise，要 ",e.jsx("code",{children:"await"})," 它以等待 DOM 更新。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"text()"})," / ",e.jsx("code",{children:"props()"})," / ",e.jsx("code",{children:"emitted()"}),"：读取渲染文本、读 props、断言触发过的自定义事件。"]})]}),e.jsx(t,{lang:"js",title:"用 mount + trigger 测计数器组件",code:l}),e.jsxs(r,{variant:"warn",title:"trigger 之后一定要 await",children:["Vue 的 DOM 更新是",e.jsx("strong",{children:"异步"}),"的。调用 ",e.jsx("code",{children:"trigger"})," 改了状态后， DOM 不会立刻更新。必须 ",e.jsx("code",{children:"await wrapper.find('button').trigger('click')"}),"（或 ",e.jsx("code",{children:"await wrapper.vm.$nextTick()"}),"）等一帧，再去断言渲染结果—— 忘了 await 是新手最常见的「测试明明对了却报错」的原因。"]}),e.jsx(t,{lang:"js",title:"shallowMount 与 findComponent",code:o}),e.jsx("h3",{children:"测 composable 与 Pinia store"}),e.jsxs("p",{children:[e.jsx("strong",{children:"composable 本质就是普通函数"}),"，直接调用、断言它返回的 ",e.jsx("code",{children:"ref"}),"/ 方法即可，不必挂载组件；测 ",e.jsx("strong",{children:"Pinia store"})," 时，先在测试里",e.jsx("code",{children:"setActivePinia(createPinia())"})," 装一个干净的 Pinia 实例，再像平时一样 用 store 的 state、getter、action 做断言。"]}),e.jsx(t,{lang:"js",title:"测 composable 与 Pinia store（各一例）",code:h}),e.jsx("h3",{children:"端到端测试（E2E）一句话"}),e.jsxs("p",{children:["当你需要验证「真用户在真浏览器里点一遍流程」是否走得通，就用",e.jsx("strong",{children:"Playwright"})," 或 ",e.jsx("strong",{children:"Cypress"}),"——它们启动真实浏览器、 模拟点击输入、断言页面跳转与最终结果，覆盖单测够不着的整链路，但慢且贵，所以只留给关键主流程。"]}),e.jsx("h2",{children:"三、Vue 2 → Vue 3 迁移要点"}),e.jsxs("p",{children:["你接手的老项目很可能还是 Vue 2。Vue 3 总体兼容选项式 API，迁移不必推倒重来，但有几处",e.jsx("strong",{children:"破坏性变更"}),"必须心里有数。最该先掌握的方向，是从选项式逐步转向",e.jsx("strong",{children:"组合式 API"}),"——逻辑按「关心点」聚合，复用更顺。"]}),e.jsx(t,{lang:"vue",title:"迁移方向：选项式 → 组合式 API",code:j}),e.jsx("p",{children:"下面是迁移时最常撞上的破坏性变更清单："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"主题"}),e.jsx("th",{children:"Vue 2"}),e.jsx("th",{children:"Vue 3"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"应用创建"}),e.jsxs("td",{children:[e.jsx("code",{children:"new Vue(...)"})," 全局构造"]}),e.jsxs("td",{children:[e.jsx("code",{children:"createApp(App)"}),"，全局 API 挂到应用实例"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"v-model"}),e.jsxs("td",{children:["默认 prop ",e.jsx("code",{children:"value"})," + 事件 ",e.jsx("code",{children:"input"})]}),e.jsxs("td",{children:["默认 prop ",e.jsx("code",{children:"modelValue"})," + 事件 ",e.jsx("code",{children:"update:modelValue"}),"，支持多个 v-model"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"过滤器 filters"}),e.jsx("td",{children:e.jsx("code",{children:"{{ msg | capitalize }}"})}),e.jsxs("td",{children:[e.jsx("strong",{children:"已移除"}),"，改用方法或计算属性"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"生命周期改名"}),e.jsxs("td",{children:[e.jsx("code",{children:"beforeDestroy"})," / ",e.jsx("code",{children:"destroyed"})]}),e.jsxs("td",{children:[e.jsx("code",{children:"beforeUnmount"})," / ",e.jsx("code",{children:"unmounted"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"状态管理"}),e.jsx("td",{children:"Vuex"}),e.jsxs("td",{children:["推荐 ",e.jsx("strong",{children:"Pinia"}),"（更简洁、TS 友好、无 mutation）"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"多根节点"}),e.jsx("td",{children:"模板只能有一个根节点"}),e.jsxs("td",{children:["支持",e.jsx("strong",{children:"多根节点"}),"（Fragment）"]})]})]})]}),e.jsx(t,{lang:"js",title:"入口写法的破坏性变更：new Vue → createApp",code:x}),e.jsxs(r,{variant:"tip",title:"迁移建议：渐进而非重写",children:["Vue 官方提供「迁移构建版本」可在 Vue 3 里兼容大量 Vue 2 写法，让你",e.jsx("strong",{children:"逐文件"}),"升级而不是一次性重写。务实顺序是：先升到能跑起来 → 逐个修破坏性变更（filters、生命周期名、 v-model）→ 把 Vuex 迁到 Pinia → 最后按需把选项式重构成组合式。别追求一步到位。"]}),e.jsx("h2",{children:"四、Vue 生态地图"}),e.jsx("p",{children:"我们这门课走过的工具，可以拼成一张「Vue 全家桶」地图。每个方向都有一两个事实标准， 记住它们，你就知道「遇到某类需求该去找谁」。"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方向"}),e.jsx("th",{children:"事实标准 / 推荐"}),e.jsx("th",{children:"解决什么"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"构建工具"}),e.jsx("td",{children:e.jsx("strong",{children:"Vite"})}),e.jsx("td",{children:"极速开发服务器、打包、HMR"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"状态管理"}),e.jsx("td",{children:e.jsx("strong",{children:"Pinia"})}),e.jsx("td",{children:"跨组件共享状态，Vuex 的官方继任者"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"路由"}),e.jsx("td",{children:e.jsx("strong",{children:"Vue Router"})}),e.jsx("td",{children:"单页应用的页面导航"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"全栈 / SSR"}),e.jsx("td",{children:e.jsx("strong",{children:"Nuxt"})}),e.jsx("td",{children:"服务端渲染、文件路由、全栈能力"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"UI 组件库"}),e.jsxs("td",{children:[e.jsx("strong",{children:"Element Plus"})," / Naive UI / Vuetify"]}),e.jsx("td",{children:"现成的高质量组件，少造轮子"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"测试"}),e.jsxs("td",{children:[e.jsx("strong",{children:"Vitest + Vue Test Utils"}),"；E2E 用 ",e.jsx("strong",{children:"Playwright"})]}),e.jsx("td",{children:"单元 / 组件测试与端到端测试"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"实用工具集"}),e.jsx("td",{children:e.jsx("strong",{children:"VueUse"})}),e.jsx("td",{children:"上百个开箱即用的组合式工具函数"})]})]})]}),e.jsx(d,{title:"把地图当「查询表」用",children:e.jsxs("p",{children:["实战中遇到需求，先在地图上定位：要做后台管理界面 → Element Plus； 要共享登录态 → Pinia；要监听鼠标 / 防抖 / 本地存储 → 先翻 VueUse 有没有现成的； 要给组件加测试 → Vitest + VTU；要做能被收录的官网 → Nuxt。",e.jsx("strong",{children:"先找生态里的事实标准，再考虑自己造轮子"}),"，是 Vue 工程化的基本素养。"]})}),e.jsx("h2",{children:"五、一条进阶学习路径"}),e.jsx("p",{children:"学完这门课，下一步往哪走？给你一条务实的递进路线："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"第一步，夯实基本功"}),"：把组合式 API、响应式原理（",e.jsx("code",{children:"ref"})," /",e.jsx("code",{children:"reactive"})," / ",e.jsx("code",{children:"computed"})," / ",e.jsx("code",{children:"watch"}),"）和组件通信彻底练熟， 这是一切的地基。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"第二步，吃透工程化全家桶"}),"：在真实项目里把 Vite + Vue Router + Pinia 串起来，配上 VueUse 提效。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"第三步，补齐质量与类型"}),"：给组件写 Vitest + VTU 测试，全程用 TypeScript， 养成「可验证、可维护」的习惯。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"第四步，进军全栈与 SSR"}),"：用 Nuxt 做一个需要 SEO 的真实站点， 理解 SSR / SSG / 注水的取舍。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"第五步，深入与回馈"}),"：读 Vue 源码或官方 RFC 理解设计取舍， 尝试给开源库提 issue / PR，把「使用者」升级成「贡献者」。"]})]}),e.jsxs(r,{variant:"tip",title:"最重要的一条",children:["框架会更新、工具会更替，但",e.jsx("strong",{children:"组件化思维、响应式数据流、声明式 UI"}),"这些核心心智是稳定的。把原理学透，换任何框架你都能快速上手——这也是这门课从头到尾 想传递给你的东西。"]}),e.jsx("h2",{children:"六、全课收束"}),e.jsxs("p",{children:["从第一卷的模板语法，到响应式系统、组件与组合式 API，再到路由、状态管理、SSR / Nuxt， 最后是测试与迁移——你已经拥有了一套",e.jsx("strong",{children:"完整的 Vue 3 现代开发能力"}),"。 剩下的，就是去写、去踩坑、去查文档、去读别人的代码。祝你写得开心。"]}),e.jsx(i,{points:["测试金字塔：底层单元测试最多最快（Vitest + Vue Test Utils），顶层 E2E 最少最贵（Playwright / Cypress），别写成头重脚轻的「冰淇淋筒」。","Vitest + VTU 测组件核心 API：mount / shallowMount 挂载、find / findComponent 查询、trigger 触发事件（记得 await）、text / props / emitted 断言。","composable 是普通函数直接调用断言；测 Pinia store 先 setActivePinia(createPinia()) 给干净实例再照常用。","Vue 2 → 3 破坏性变更：createApp 取代 new Vue、v-model 改用 modelValue/update:modelValue、filters 移除、生命周期改名（beforeUnmount/unmounted）、Vuex 迁 Pinia；推荐渐进迁移并转向组合式 API。","Vue 生态地图：构建 Vite、状态 Pinia、路由 Vue Router、全栈 Nuxt、UI 库 Element Plus/Naive/Vuetify、测试 Vitest+VTU/Playwright、工具集 VueUse。","进阶路径：夯实组合式 API 与响应式 → 工程化全家桶 → 测试与 TS → Nuxt 全栈 → 读源码与回馈社区；核心心智（组件化、响应式、声明式 UI）比具体框架更值得长期投资。"]})]})}export{f as default};
