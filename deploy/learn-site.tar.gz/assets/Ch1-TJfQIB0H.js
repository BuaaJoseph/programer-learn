import{r as x,j as e}from"./index-DL563RIm.js";import{L as h,S as p}from"./Summary-BrgLcNDp.js";import{K as g}from"./KeyIdea-exK4GrdK.js";import{E as y}from"./Example-HxOmIesu.js";import{P as j}from"./Practice-r6liJb9j.js";import{C as o}from"./Callout-B-8nslAm.js";import{C as n}from"./CodeBlock-DkVyd3P6.js";import{F as m}from"./Figure-Ueosrsuu.js";const a=[{id:"wechat",name:"微信支付",desc:"调用微信 SDK 完成支付"},{id:"alipay",name:"支付宝",desc:"调用支付宝 SDK 完成支付"},{id:"card",name:"银行卡",desc:"走银联网关完成支付"}];function f(){const[i,c]=x.useState("alipay"),l=a.find(t=>t.id===i),d=e.jsxs(e.Fragment,{children:[a.map(t=>e.jsx("button",{className:`fig-btn ${i===t.id?"active":""}`,onClick:()=>c(t.id),children:t.name},t.id)),e.jsx("span",{className:"fig-note",children:"运行时切换策略，无 if-else"})]});return e.jsx(m,{caption:"策略模式：把一族可互换的算法各自封装成独立类，运行时按需选择，用多态消灭一长串 if-else。支付方式、促销规则、排序算法都适合。配合工厂/Map 注册可彻底去掉分支。",controls:d,children:e.jsxs("svg",{viewBox:"0 0 460 170",width:"460",role:"img","aria-label":"策略模式",children:[e.jsx("rect",{x:"20",y:"56",width:"100",height:"40",rx:"9",fill:"var(--accent)"}),e.jsx("text",{x:"70",y:"80",textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"12",fontWeight:"700",fill:"#ffffff",children:"PayContext"}),e.jsx("rect",{x:"170",y:"56",width:"110",height:"40",rx:"9",fill:"var(--violet)",fillOpacity:"0.14",stroke:"var(--violet)"}),e.jsx("text",{x:"225",y:"74",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"10",fontWeight:"700",fill:"var(--violet)",children:"PayStrategy"}),e.jsx("text",{x:"225",y:"88",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:"var(--ink-soft)",children:"接口"}),e.jsx("line",{x1:"120",y1:"76",x2:"170",y2:"76",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#st-a)"}),a.map((t,s)=>{const r=t.id===i;return e.jsxs("g",{children:[e.jsx("rect",{x:"330",y:20+s*44,width:"110",height:"34",rx:"7",fill:r?"var(--green)":"var(--green-soft)",stroke:"var(--green-line)",strokeWidth:r?2:1}),e.jsx("text",{x:"385",y:41+s*44,textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"11",fontWeight:r?"700":"400",fill:r?"#ffffff":"var(--green)",children:t.name}),e.jsx("line",{x1:"280",y1:"76",x2:"330",y2:37+s*44,stroke:r?"var(--green)":"var(--border-strong)",strokeWidth:r?2:1,strokeDasharray:r?"0":"4 3",markerEnd:"url(#st-a)"})]},t.id)}),e.jsx("defs",{children:e.jsx("marker",{id:"st-a",markerWidth:"8",markerHeight:"8",refX:"5",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L5,3 L0,6 Z",fill:"var(--ink-faint)"})})}),e.jsx("rect",{x:"20",y:"124",width:"420",height:"40",rx:"8",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsxs("text",{x:"32",y:"148",fontFamily:"var(--sans)",fontSize:"12",fill:"var(--ink)",children:["当前策略：",e.jsx("tspan",{fontWeight:"700",fill:"var(--accent-strong)",children:l.name})," — ",l.desc,"（换策略只需注入不同实现，Context 代码不变）"]})]})})}const S=`// 反例：所有分支挤在一个方法里，每加一种支付方式就要改这里
public class PayService {

    public void pay(String type, long amount) {
        if ("alipay".equals(type)) {
            // 调支付宝 SDK
            System.out.println("支付宝支付 " + amount);
        } else if ("wechat".equals(type)) {
            // 调微信 SDK
            System.out.println("微信支付 " + amount);
        } else if ("unionpay".equals(type)) {
            // 调银联 SDK
            System.out.println("银联支付 " + amount);
        } else {
            throw new IllegalArgumentException("不支持的支付方式: " + type);
        }
    }
}`,u=`// 1. 策略接口：把一族可互换的算法抽象成同一个契约
public interface PayStrategy {
    String type();              // 该策略对应的支付方式标识
    void pay(long amount);      // 真正的算法
}

// 2. 具体策略：每种支付方式各自一个类，互不干扰
public class AlipayStrategy implements PayStrategy {
    public String type() { return "alipay"; }
    public void pay(long amount) {
        System.out.println("支付宝支付 " + amount);
    }
}

public class WechatStrategy implements PayStrategy {
    public String type() { return "wechat"; }
    public void pay(long amount) {
        System.out.println("微信支付 " + amount);
    }
}

// 3. 上下文 Context：用 Map 注册并路由，彻底消灭 if-else
public class PayService {

    private final Map<String, PayStrategy> registry = new HashMap<>();

    // 构造时把所有策略注入进来（Spring 里可直接注入 List 或 Map）
    public PayService(List<PayStrategy> strategies) {
        for (PayStrategy s : strategies) {
            registry.put(s.type(), s);
        }
    }

    public void pay(String type, long amount) {
        PayStrategy strategy = registry.get(type);
        if (strategy == null) {
            throw new IllegalArgumentException("不支持的支付方式: " + type);
        }
        strategy.pay(amount);   // 多态调用，新增支付方式无需改这里
    }
}`,v=`// Spring 风格：让容器自动收集所有策略，连手动注册都省了
@Component
public class AlipayStrategy implements PayStrategy {
    public String type() { return "alipay"; }
    public void pay(long amount) { /* ... */ }
}

@Service
public class PayService {

    private final Map<String, PayStrategy> registry = new HashMap<>();

    // 构造时 Spring 自动把所有 PayStrategy 实现注入成 List
    public PayService(List<PayStrategy> strategies) {
        for (PayStrategy s : strategies) {
            registry.put(s.type(), s);
        }
    }
    // 也可直接注入 Map<String, PayStrategy>，key 默认是 beanName

    public void pay(String type, long amount) {
        registry.get(type).pay(amount);   // 新增策略 = 加一个 @Component，主流程零改动
    }
}`,b=`// 函数式写法：策略只有一个方法时，可以直接用 Lambda/方法引用充当策略
// 把策略表注册成 Map<String, Consumer<Long>>，省掉一堆策略类

Map<String, LongConsumer> strategies = Map.of(
    "alipay",   amount -> System.out.println("支付宝支付 " + amount),
    "wechat",   amount -> System.out.println("微信支付 " + amount),
    "unionpay", amount -> System.out.println("银联支付 " + amount)
);

strategies.get("wechat").accept(100L);

// 这正是 JDK 里 Comparator / Runnable 的用法本质：函数式策略`;function A(){return e.jsxs(e.Fragment,{children:[e.jsx(h,{children:e.jsxs("p",{children:["一个支付方法里塞满了「如果是支付宝就……否则如果是微信就……」，每接入一种新渠道就要回来改这个方法， 越改越长、越改越怕。策略模式（",e.jsx("em",{children:"Strategy"}),"）做的事只有一句话：把这一族「可以互相替换的算法」 各自封装成独立的类，运行时再挑一个用，从而用",e.jsx("strong",{children:"多态"}),"替代成片的 if-else。"]})}),e.jsx("h2",{children:"它到底解决什么问题"}),e.jsxs("p",{children:["当一段逻辑会随「类型」分出很多分支，而每个分支内部又是一套相对独立的算法时，把它们写在一起就埋了三颗雷： 方法越来越臃肿、改一个分支可能误伤别的分支、新增分支必须修改老代码（违反",e.jsx("em",{children:"开闭原则"}),"）。 策略模式把每个分支抽成一个类，让它们实现同一个接口，调用方只面向接口编程，至于具体用哪个，留到运行时再决定。"]}),e.jsxs("p",{children:["用 GoF 的话说，策略模式的意图是：",e.jsx("strong",{children:"定义一系列算法，把它们各自封装起来，并使它们可以互相替换"}),"， 让算法的变化独立于使用它的客户端。它直接落地了两条核心原则——",e.jsx("strong",{children:"开闭原则"}),"（加算法不改老代码）和",e.jsx("strong",{children:"合成复用原则"}),"（Context 用组合持有策略，而非继承一堆子类）。 判断「该不该上策略」有个简单信号：当你发现一段 ",e.jsx("code",{children:"if-else"}),"/",e.jsx("code",{children:"switch"}),"是在",e.jsx("strong",{children:"按类型选择「做同一件事的不同做法」"}),"时，它就是策略的候选。"]}),e.jsx("h3",{children:"三个角色"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"策略接口（Strategy）"}),"：定义这一族算法的统一契约，比如",e.jsx("code",{children:"pay(amount)"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"具体策略（Concrete Strategy）"}),"：接口的各个实现，一种算法一个类，比如支付宝、微信、银联各一个。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"上下文（Context）"}),"：持有一个策略引用，对外提供入口，把实际工作委托给当前选中的策略。"]})]}),e.jsxs(y,{title:"把 if-else 改成策略",children:[e.jsx("p",{children:"先看一段典型的「随类型分支」的代码，它的问题不在于现在不能跑，而在于每次扩展都得动它："}),e.jsx(n,{lang:"java",title:"反例：if-else 堆叠",code:S}),e.jsx("p",{children:"注意这里的坏味道：方法承担了「判断用哪种」和「具体怎么付」两件事，分支越多耦合越重。 策略模式的思路就是把后者拆出去，让前者退化成一次简单的查表。"})]}),e.jsx(f,{}),e.jsx(g,{title:"如何彻底去掉 if-else：用 Map 路由",children:e.jsxs("p",{children:["很多人以为「策略模式 = 把分支拆成类」，于是写了一堆策略类，却仍在 Context 里用 if-else 决定 new 哪个， 等于白拆。真正消灭 if-else 的关键是",e.jsx("strong",{children:"用 Map 把「类型」映射到「策略实例」"}),"：调用时",e.jsx("code",{children:"registry.get(type)"})," 直接拿到对象再多态调用。在 Spring 里更省事—— 把策略接口的所有实现声明为 Bean，直接注入 ",e.jsx("code",{children:"List<PayStrategy>"})," 或",e.jsx("code",{children:"Map<String, PayStrategy>"}),"，容器会自动收集，新增策略只要加一个 Bean，主流程一行不改。"]})}),e.jsx("h2",{children:"Spring 与函数式：策略的两种现代写法"}),e.jsxs("p",{children:["在 Spring 里，策略模式几乎是「零样板」的：把每个策略声明为 Bean， Context 直接注入 ",e.jsx("code",{children:"List"})," 或 ",e.jsx("code",{children:"Map"}),"，容器自动收集所有实现。 以后新增渠道，只是多加一个 ",e.jsx("code",{children:"@Component"}),"，主流程一行不动："]}),e.jsx(n,{lang:"java",title:"Spring 自动收集策略",code:v}),e.jsxs("p",{children:["而当策略接口",e.jsx("strong",{children:"只有一个方法"}),"（函数式接口）时，连「一种算法一个类」都可以省掉—— 直接用 Lambda 或方法引用充当策略，把策略表做成 ",e.jsx("code",{children:"Map<String, 函数>"}),"："]}),e.jsx(n,{lang:"java",title:"函数式策略（Lambda）",code:b}),e.jsxs("p",{children:["这也解释了为什么 JDK 里 ",e.jsx("code",{children:"Comparator"}),"、",e.jsx("code",{children:"Runnable"}),"、 Stream 的各种 ",e.jsx("code",{children:"Function"}),"/",e.jsx("code",{children:"Predicate"})," 本质都是策略—— 它们就是「把一个可替换的算法当参数传进去」。简单场景用 Lambda， 策略内部状态复杂、需要依赖注入时才用完整的策略类。"]}),e.jsx(o,{variant:"warn",title:"别和状态模式搞混",children:e.jsxs("p",{children:["策略模式和状态模式（",e.jsx("em",{children:"State"}),"）结构几乎一样，都是「接口 + 多个实现 + 上下文委托」，区别在",e.jsx("strong",{children:"意图"}),"： 策略模式里各算法是平等、互斥的，由",e.jsx("strong",{children:"外部"}),"选择一个，彼此之间不会互相切换； 状态模式里各状态有先后流转关系，是",e.jsx("strong",{children:"状态自己"}),"决定下一步切到哪个状态（如订单：待支付 → 已支付 → 已发货）。 一句话：策略是「让你挑一个」，状态是「它自己会变」。"]})}),e.jsx("h2",{children:"策略 vs 相近模式速辨"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"模式"}),e.jsx("th",{children:"结构"}),e.jsx("th",{children:"关键区别"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"策略"}),e.jsx("td",{children:"接口 + 多实现 + Context 委托"}),e.jsx("td",{children:"算法互斥平等，外部选一个"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"状态"}),e.jsx("td",{children:"同上"}),e.jsx("td",{children:"状态间有流转，自己切换下一个"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"工厂方法"}),e.jsx("td",{children:"接口 + 多实现 + 工厂"}),e.jsx("td",{children:"解决「造哪个对象」，不是「执行哪个算法」"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"模板方法"}),e.jsx("td",{children:"抽象类 + 子类填步骤"}),e.jsx("td",{children:"用继承复用流程骨架，策略用组合换算法"})]})]})]}),e.jsx(o,{variant:"warn",title:"策略模式的两个常见坑",children:e.jsxs("p",{children:["其一，",e.jsx("strong",{children:"策略数量爆炸"}),"：如果只有两三个分支、且几乎不变，硬拆成策略类反而比 if-else 更难读， 这是过度设计。其二，",e.jsx("strong",{children:"策略的选择逻辑没真正消灭"}),"：很多人拆了策略类， 却还在 Context 里写 ",e.jsx("code",{children:"if(type==a) new A() else new B()"}),"，等于白拆—— 真正的关键是用 Map 路由或交给容器收集，把「选哪个」也变成查表。"]})}),e.jsx("h2",{children:"常见应用与「面试怎么答」"}),e.jsxs("p",{children:["策略模式在真实代码里随处可见：",e.jsx("strong",{children:"多种支付方式"}),"、",e.jsx("strong",{children:"多种促销规则"}),"（满减、打折、赠品）、",e.jsx("strong",{children:"不同下单渠道"}),"（App、小程序、第三方），以及最常被忽视的—— JDK 里的 ",e.jsx("code",{children:"Comparator"}),"，给 ",e.jsx("code",{children:"Collections.sort"})," 传不同的比较器，本质就是传入不同的排序策略。"]}),e.jsxs("p",{children:["面试被问到时，建议这样组织回答：先一句话点意图（封装一族可互换的算法，运行时选择，用多态替代 if-else）， 再说三个角色，接着主动抛出加分项——「我会用 Map 或 Spring 把策略注册起来，从而连选择分支的 if-else 也一起消灭」， 最后用「和状态模式的区别」收尾，体现你能区分相似模式。能举出 ",e.jsx("code",{children:"Comparator"})," 这种 JDK 例子会更稳。"]}),e.jsxs(j,{title:"用 Map 注册路由实现一族支付策略",children:[e.jsxs("p",{children:["自己动手写一遍：定义 ",e.jsx("code",{children:"PayStrategy"})," 接口，给出至少两个具体策略，再在 Context 里用",e.jsx("code",{children:"Map"})," 注册并路由。重点体会：新增一种支付方式时，你只需要加一个类、注册一次，",e.jsx("code",{children:"pay"})," 方法完全不用动。"]}),e.jsx(n,{lang:"java",title:"StrategyDemo.java",code:u}),e.jsxs("p",{children:["进阶练习：把构造里的手动注册改成 Spring 风格——给每个策略加 ",e.jsx("code",{children:"@Component"}),"， Context 里直接注入 ",e.jsx("code",{children:"List<PayStrategy>"})," 后在构造里转成 Map，体会容器自动收集的爽快。"]})]}),e.jsx(p,{points:["策略模式：把一族可互换的算法各自封装成类，运行时选择其一，用多态替代成片的 if-else。","三个角色：策略接口（统一契约）、具体策略（一种算法一个类）、上下文 Context（持有并委托给当前策略）。","彻底去掉 if-else 的关键是用 Map<类型, 策略> 路由，或让 Spring 把策略注入成 List/Map 自动收集。","典型应用：支付方式、促销规则、不同渠道，以及 JDK 的 Comparator 排序。","与状态模式结构相同但意图不同：策略是外部挑一个且互斥，状态是自身按流转规则切换。","Spring 里把策略声明为 Bean、注入 List/Map 自动收集；策略接口只有一个方法时可用 Lambda 代替策略类。","两个坑：分支少且不变时硬拆是过度设计；拆了类却仍用 if-else 选 new 等于白拆，要用 Map/容器路由。","扩展时只加新类、注册一次，主流程不改，天然符合开闭原则。"]})]})}export{A as default};
