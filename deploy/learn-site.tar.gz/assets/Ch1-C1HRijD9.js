import{j as e}from"./index-B0-Um9Xw.js";import{L as s,C as r,a as n,P as i,S as o}from"./Summary-CRXglwZ1.js";import{K as c}from"./KeyIdea-zCCzkW7I.js";import{E as l}from"./Example-Djk5fvs9.js";const t=`// 没有 Spring 的年代：对象自己 new 自己的依赖
public class UserController {
    // Controller 亲自决定用哪个实现、怎么造它
    private UserService userService = new UserServiceImpl();

    public String getUser(Long id) {
        return userService.findById(id);
    }
}
// 痛点：换实现要改源码、UserServiceImpl 的依赖也得自己 new、
// 测试时没法塞一个假的 userService 进来`,d=`@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;

    // 构造器注入：依赖通过构造参数传入，由容器负责传
    // 字段可以声明成 final，对象一建好就不可变
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public String findById(Long id) {
        return userRepository.selectName(id);
    }
}`,x=`@Configuration
public class AppConfig {

    // 用 @Bean 把第三方类或自己装配的对象交给容器管理
    @Bean
    public UserService userService(UserRepository userRepository) {
        return new UserServiceImpl(userRepository);
    }

    @Bean
    public UserRepository userRepository() {
        return new JdbcUserRepository();
    }
}

// 取用：容器会自动把依赖装配好
ApplicationContext ctx =
        new AnnotationConfigApplicationContext(AppConfig.class);
UserService service = ctx.getBean(UserService.class);`;function g(){return e.jsxs(e.Fragment,{children:[e.jsx(s,{children:e.jsxs("p",{children:["学 Spring，绕不开的第一个词是 ",e.jsx("em",{children:"IoC"}),"。它听起来玄乎，其实只回答一个问题： 一个对象需要的依赖，到底由",e.jsx("strong",{children:"谁"}),"来创建、由",e.jsx("strong",{children:"谁"}),"来塞进去。 在传统写法里，是对象自己动手 ",e.jsx("code",{children:"new"}),"；在 Spring 里，这件事被交给了「容器」。 这个「交出去」的动作，就是控制反转。"]})}),e.jsx("h2",{children:"什么是 IoC，什么是 DI"}),e.jsxs("p",{children:[e.jsx("em",{children:"IoC"}),"（Inversion of Control，控制反转）说的是：对象的创建权和依赖管理权， 从对象自己手里「反转」给了容器。原来是「我要用什么，我自己造」，现在变成「我要用什么，容器给我」。 控制方向掉了个头，所以叫「反转」。"]}),e.jsxs("p",{children:[e.jsx("em",{children:"DI"}),"（Dependency Injection，依赖注入）则是 IoC 的",e.jsx("strong",{children:"具体实现方式"}),"。 IoC 是一种思想、一个目标；DI 是落地手段——容器在创建对象时，把它需要的依赖「注入」进去。 换句话说：你描述「我依赖谁」，容器负责「把谁递给你」。两者关系记一句话就够： IoC 是思想，DI 是手段。"]}),e.jsxs(l,{title:"Controller 依赖 Service，不再自己 new",children:[e.jsx("p",{children:"先看没有 Spring 时，对象是怎么「亲力亲为」的："}),e.jsx(r,{lang:"java",title:"UserController.java（传统写法）",code:t}),e.jsxs("p",{children:["问题很明显：",e.jsx("code",{children:"UserController"})," 和 ",e.jsx("code",{children:"UserServiceImpl"})," 被焊死在一起。 想换个实现、想在测试里塞个假对象，都得动源码。交给容器后，Controller 只需要声明 「我需要一个 ",e.jsx("code",{children:"UserService"}),"」，至于是哪个实现、怎么造出来，全由容器决定。"]})]}),e.jsx(c,{title:"IoC 到底好在哪",children:e.jsxs("p",{children:["把控制权交给容器，换来三样东西：",e.jsx("strong",{children:"解耦"}),"（调用方只依赖接口，不依赖具体实现）、",e.jsx("strong",{children:"可替换"}),"（换实现只改配置，不改业务代码）、",e.jsx("strong",{children:"易测试"}),"（测试时能轻松注入 mock 或 stub）。 这三点是后面所有 Spring 特性的地基。"]})}),e.jsx("h2",{children:"三种注入方式：构造器、setter、字段"}),e.jsx("p",{children:"DI 在代码里有三种落地姿势，面试常被追问优劣："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"构造器注入"}),"（推荐）：依赖通过构造参数传入，字段可声明为 ",e.jsx("code",{children:"final"}),"， 保证依赖",e.jsx("strong",{children:"不可变"}),"且",e.jsx("strong",{children:"不为空"}),"；对象一旦建成就是完整可用的。 循环依赖在构造器注入下会直接报错，反而能帮你早点发现设计问题。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"setter 注入"}),"：通过 setter 方法注入，适合",e.jsx("strong",{children:"可选依赖"}),"或需要在运行期重新配置的场景。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"字段注入"}),"：直接在字段上写 ",e.jsx("code",{children:"@Autowired"}),"，写起来最省事， 但依赖被藏在内部、无法用 ",e.jsx("code",{children:"final"}),"、脱离容器难以单测， 因此",e.jsx("strong",{children:"不推荐"}),"在生产代码里大量使用。"]})]}),e.jsxs(n,{variant:"warn",title:"@Autowired 和 @Resource 别记混",children:[e.jsx("p",{children:"这是高频考点，区别就两点："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"@Autowired"}),"：Spring 提供，默认按",e.jsx("strong",{children:"类型"}),"（byType）装配。 当同一类型有多个 Bean 时会冲突，需要配合 ",e.jsx("code",{children:'@Qualifier("beanName")'})," 按名字指定。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"@Resource"}),"：JDK（JSR-250）提供，默认按",e.jsx("strong",{children:"名字"}),"（byName）装配， 找不到对应名字时才退回按类型找。"]})]}),e.jsx("p",{children:"一句话：@Autowired 先看类型，@Resource 先看名字。"})]}),e.jsx("h2",{children:"BeanFactory 与 ApplicationContext"}),e.jsxs("p",{children:["容器有两层接口。",e.jsx("em",{children:"BeanFactory"})," 是最底层的容器，只提供最基础的 Bean 获取能力，采用",e.jsx("strong",{children:"懒加载"}),"（用到时才创建）。",e.jsx("em",{children:"ApplicationContext"})," 继承自 BeanFactory，是我们实际开发用的「企业级容器」， 额外提供了国际化、事件发布、注解支持、AOP 集成等能力，并且默认在",e.jsx("strong",{children:"启动时"}),"就把单例 Bean 都创建好。简单记：BeanFactory 是地基，ApplicationContext 是精装修后的成品。"]}),e.jsx("h3",{children:"Bean 的作用域"}),e.jsxs("p",{children:["容器管理的对象叫 ",e.jsx("em",{children:"Bean"}),"，它有不同的「作用域」（scope），决定容器给你的是同一个实例还是新实例："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"singleton"}),"（默认）：整个容器只有一个实例，所有人共享。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"prototype"}),"：每次获取都新建一个实例。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"request"}),"：每个 HTTP 请求一个实例（仅 Web 环境）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"session"}),"：每个 HTTP 会话一个实例（仅 Web 环境）。"]})]}),e.jsx("p",{children:"注意单例 Bean 无状态使用最安全；如果往单例 Bean 里塞了可变的成员变量， 多线程下就可能出问题——这也是面试官爱挖的坑。"}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsx("p",{children:"被问到「什么是 IoC 和 DI」，别背定义堆术语，按这个顺序讲最稳：先点出痛点 （对象自己 new 依赖导致紧耦合、难替换、难测试），再说 IoC 把创建权反转给容器、 DI 是它的实现手段，最后落到三个好处（解耦、可替换、易测试）。 如果还有时间，补一句「构造器注入是首选，因为依赖不可变、不为空、对单测友好」， 基本就稳了。"}),e.jsxs(i,{title:"用构造器注入 + Java 配置装配一组 Bean",children:[e.jsx("p",{children:"先写一个用构造器注入的 Service，让依赖通过构造参数传入："}),e.jsx(r,{lang:"java",title:"UserServiceImpl.java",code:d}),e.jsxs("p",{children:["再用 ",e.jsx("code",{children:"@Configuration"})," + ",e.jsx("code",{children:"@Bean"})," 把对象交给容器， 观察容器如何自动把 ",e.jsx("code",{children:"UserRepository"})," 装配进 ",e.jsx("code",{children:"UserService"}),"："]}),e.jsx(r,{lang:"java",title:"AppConfig.java",code:x}),e.jsxs("p",{children:["试着把 ",e.jsx("code",{children:"JdbcUserRepository"})," 换成另一个实现，体会一下「只改配置、不动业务代码」的快感； 再把某个 Bean 改成 ",e.jsx("code",{children:'@Scope("prototype")'}),"，连续 ",e.jsx("code",{children:"getBean"})," 两次比较是不是同一个对象。"]})]}),e.jsx(o,{points:["IoC（控制反转）是把对象的创建权和依赖管理权交给容器的思想；DI（依赖注入）是它的实现手段。","交给容器后换来三大好处：解耦、可替换、易测试，这是 Spring 所有特性的地基。","注入有构造器、setter、字段三种；构造器注入最推荐，依赖不可变、不为空、对单测友好。","@Autowired 默认按类型装配（多实现时配 @Qualifier），@Resource 默认按名字装配。","BeanFactory 是懒加载的底层容器，ApplicationContext 继承它并在启动时创建单例、提供企业级能力。","Bean 作用域有 singleton（默认）/prototype/request/session，单例 Bean 应避免可变成员以防线程安全问题。"]})]})}export{g as default};
