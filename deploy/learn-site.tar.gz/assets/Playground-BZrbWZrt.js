import{r as o,j as e,P as l}from"./index-bcw1GFOG.js";import{P as s}from"./PyRunner-BGOcbGvn.js";const t=[{id:"hello",label:"Hello World",code:`# 你的第一行 Python：把内容打印出来
print("你好，Python！")
print("1 + 2 =", 1 + 2)`},{id:"var",label:"变量与类型",code:`name = "小明"
age = 18
height = 1.75
print(f"{name} 今年 {age} 岁，身高 {height} 米")
print("age 的类型是：", type(age))`},{id:"loop",label:"循环：九九乘法表",code:`for i in range(1, 10):
    row = ""
    for j in range(1, i + 1):
        row += f"{j}x{i}={i*j}\\t"
    print(row)`},{id:"list",label:"列表与推导式",code:`nums = [3, 1, 4, 1, 5, 9, 2, 6]
print("原始：", nums)
print("排序：", sorted(nums))
print("去重：", sorted(set(nums)))

# 列表推导式：取出所有偶数的平方
evens = [n * n for n in nums if n % 2 == 0]
print("偶数的平方：", evens)`},{id:"func",label:"函数",code:`def fib(n):
    """返回斐波那契数列的前 n 项"""
    a, b = 0, 1
    result = []
    for _ in range(n):
        result.append(a)
        a, b = b, a + b
    return result

print(fib(10))`},{id:"dict",label:"字典：词频统计",code:`text = "apple banana apple cherry banana apple"
count = {}
for word in text.split():
    count[word] = count.get(word, 0) + 1

for word, n in sorted(count.items(), key=lambda x: -x[1]):
    print(f"{word}: {n}")`},{id:"oop",label:"面向对象",code:`class Account:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount
        return self.balance

    def __str__(self):
        return f"{self.owner} 的账户余额：{self.balance}"

acc = Account("小红")
acc.deposit(100)
acc.deposit(50)
print(acc)`},{id:"input",label:"读取输入",code:`name = input("请输入你的名字：")
print(f"欢迎你，{name}！")
n = int(input("输入一个整数："))
print(f"{n} 的平方是 {n * n}")`}];function p(){const[r,i]=o.useState("hello"),a=t.find(n=>n.id===r)||t[0];return e.jsx(l,{children:e.jsxs("div",{className:"container playground",children:[e.jsx("h1",{className:"browse-h1",children:"Python 在线运行"}),e.jsx("p",{className:"section-desc",children:"在下面的编辑器里直接写 Python 并点「运行」，结果就在页面上显示——完全在你的浏览器里执行， 无需安装任何环境。第一次运行会从 CDN 加载运行环境（约几秒，仅一次）。"}),e.jsxs("div",{className:"playground-presets",children:[e.jsx("span",{className:"playground-presets-label",children:"示例："}),t.map(n=>e.jsx("button",{className:`playground-chip ${n.id===r?"active":""}`,onClick:()=>i(n.id),children:n.label},n.id))]}),e.jsx(s,{initialCode:a.code,title:`示例 · ${a.label}`,minLines:8},a.id),e.jsxs("div",{className:"playground-note",children:["想系统学 Python？去看"," ",e.jsx("a",{href:"/course/python-tutorial",children:"《Python 教程：从入门到 Agent 开发》"}),"， 每节都配可运行的小例子。"]})]})})}export{p as default};
