import{r as o,j as e,C as me,u as Oe,P as Re}from"./index-DraKZMSn.js";import{r as Le,f as te,l as $e,g as Ee,S as Me,b as Te,c as Ae,a as Ue,d as De}from"./api-CLSbU1Eq.js";const oe=[{id:"two-sum-ii",title:"两数之和 II（有序数组）",difficulty:"中等",tags:["数组","双指针"],statement:`给定一个已按升序排列的整数数组 numbers 和目标值 target，请找出两个数使它们相加之和等于 target，返回这两个数的下标（从 1 开始），要求空间复杂度 O(1)。

输入：第一行为目标值 target，第二行为以空格分隔的有序数组。
输出：两个下标，空格分隔。`,sampleInput:`9
2 7 11 15`,sampleOutput:"1 2"},{id:"longest-substring",title:"无重复字符的最长子串",difficulty:"中等",tags:["滑动窗口","哈希"],statement:`给定一个字符串 s，找出其中不含重复字符的最长子串的长度。

输入：一行字符串 s。
输出：最长无重复子串的长度。`,sampleInput:"abcabcbb",sampleOutput:"3"},{id:"add-two-numbers",title:"两个大数相加（字符串）",difficulty:"中等",tags:["字符串","模拟"],statement:`给定两个用字符串表示的非负大整数 a、b（可能超过 long 范围），返回它们之和（字符串）。

输入：两行，分别为 a 和 b。
输出：a + b。`,sampleInput:`99999999999999999999
1`,sampleOutput:"100000000000000000000"},{id:"lru-cache",title:"LRU 缓存机制",difficulty:"中等",tags:["设计","哈希","双向链表"],statement:`设计并实现一个 LRU（最近最少使用）缓存，支持 get 和 put，容量满时淘汰最久未使用的项，均要求 O(1)。

输入：第一行为容量 cap 与操作数 n；接下来 n 行，每行形如 "put 1 1" 或 "get 1"。
输出：每个 get 操作的返回值（未命中输出 -1），空格分隔在一行。`,sampleInput:`2 5
put 1 1
put 2 2
get 1
put 3 3
get 2`,sampleOutput:"1 -1"},{id:"longest-palindrome",title:"最长回文子串",difficulty:"中等",tags:["字符串","动态规划"],statement:`给定字符串 s，返回它的最长回文子串。

输入：一行字符串 s。
输出：最长回文子串（若有多个，输出任意一个）。`,sampleInput:"babad",sampleOutput:"bab"},{id:"three-sum",title:"三数之和",difficulty:"中等",tags:["数组","双指针"],statement:`给定数组 nums，找出所有和为 0 且不重复的三元组，按升序输出。

输入：一行以空格分隔的整数数组。
输出：每行一个三元组（升序、空格分隔）；无解输出空。`,sampleInput:"-1 0 1 2 -1 -4",sampleOutput:`-1 -1 2
-1 0 1`},{id:"container-water",title:"盛最多水的容器",difficulty:"中等",tags:["双指针","贪心"],statement:`给定 n 个非负整数表示柱子高度，找出两条柱子使其与 x 轴构成的容器能盛最多的水，输出最大面积。

输入：一行以空格分隔的高度数组。
输出：最大面积。`,sampleInput:"1 8 6 2 5 4 8 3 7",sampleOutput:"49"},{id:"coin-change",title:"零钱兑换",difficulty:"中等",tags:["动态规划"],statement:`给定硬币面额数组 coins 和总金额 amount，求凑成总金额所需最少硬币数；无法凑成输出 -1。

输入：第一行 amount；第二行硬币面额（空格分隔）。
输出：最少硬币数。`,sampleInput:`11
1 2 5`,sampleOutput:"3"},{id:"word-break",title:"单词拆分",difficulty:"中等",tags:["动态规划","字符串"],statement:`给定字符串 s 和单词字典 wordDict，判断 s 是否能被空格拆分成字典中的单词序列。

输入：第一行 s；第二行字典单词（空格分隔）。
输出：true 或 false。`,sampleInput:`leetcode
leet code`,sampleOutput:"true"},{id:"num-islands",title:"岛屿数量",difficulty:"中等",tags:["DFS","BFS","并查集"],statement:`给定由 '1'（陆地）和 '0'（水）组成的二维网格，计算岛屿数量。岛屿由相邻（上下左右）陆地连接。

输入：第一行 m n；接下来 m 行，每行 n 个 0/1（空格分隔）。
输出：岛屿数量。`,sampleInput:`3 3
1 1 0
0 1 0
0 0 1`,sampleOutput:"2"},{id:"course-schedule",title:"课程表（拓扑排序）",difficulty:"中等",tags:["图","拓扑排序"],statement:`共有 numCourses 门课，先修关系给定为 [a, b]（学 a 前必须先学 b）。判断能否完成所有课程。

输入：第一行 numCourses 与边数 m；接下来 m 行每行两个数 a b。
输出：true 或 false。`,sampleInput:`2 1
1 0`,sampleOutput:"true"},{id:"kth-largest",title:"数组中的第 K 个最大元素",difficulty:"中等",tags:["堆","快速选择"],statement:`在未排序数组中找到第 k 个最大的元素。

输入：第一行 k；第二行数组（空格分隔）。
输出：第 k 大的元素。`,sampleInput:`2
3 2 1 5 6 4`,sampleOutput:"5"},{id:"merge-intervals",title:"合并区间",difficulty:"中等",tags:["排序","区间"],statement:`给定若干区间，合并所有重叠区间。

输入：第一行区间数 n；接下来 n 行每行两个数 start end。
输出：合并后的区间，每行两个数（按起点升序）。`,sampleInput:`4
1 3
2 6
8 10
15 18`,sampleOutput:`1 6
8 10
15 18`},{id:"rotate-image",title:"旋转图像",difficulty:"中等",tags:["数组","矩阵"],statement:`给定 n×n 矩阵，将其原地顺时针旋转 90 度。

输入：第一行 n；接下来 n 行每行 n 个数。
输出：旋转后的矩阵。`,sampleInput:`3
1 2 3
4 5 6
7 8 9`,sampleOutput:`7 4 1
8 5 2
9 6 3`},{id:"subsets",title:"子集",difficulty:"中等",tags:["回溯","位运算"],statement:`给定一个不含重复元素的整数数组 nums，返回其所有可能的子集（幂集）。

输入：一行数组（空格分隔）。
输出：每行一个子集（空格分隔，含空行表示空集），顺序不限。`,sampleInput:"1 2 3",sampleOutput:`
1
2
1 2
3
1 3
2 3
1 2 3`},{id:"permutations",title:"全排列",difficulty:"中等",tags:["回溯"],statement:`给定不含重复数字的数组 nums，返回其所有全排列。

输入：一行数组（空格分隔）。
输出：每行一个排列（空格分隔），顺序不限。`,sampleInput:"1 2 3",sampleOutput:`1 2 3
1 3 2
2 1 3
2 3 1
3 1 2
3 2 1`},{id:"search-rotated",title:"搜索旋转排序数组",difficulty:"中等",tags:["二分查找"],statement:`整数数组 nums 升序排列后在某个未知点旋转，给定 target，存在则返回下标，否则返回 -1，要求 O(log n)。

输入：第一行 target；第二行数组。
输出：下标或 -1。`,sampleInput:`0
4 5 6 7 0 1 2`,sampleOutput:"4"},{id:"product-except-self",title:"除自身以外数组的乘积",difficulty:"中等",tags:["数组","前缀积"],statement:`给定数组 nums，返回数组 answer，其中 answer[i] 等于 nums 中除 nums[i] 之外其余元素的乘积，不能使用除法，O(n)。

输入：一行数组。
输出：结果数组（空格分隔）。`,sampleInput:"1 2 3 4",sampleOutput:"24 12 8 6"},{id:"daily-temperatures",title:"每日温度（单调栈）",difficulty:"中等",tags:["单调栈"],statement:`给定每日温度数组，返回数组 answer，answer[i] 表示第 i 天之后要等多少天才会有更高温度；若不存在则为 0。

输入：一行温度数组。
输出：结果数组（空格分隔）。`,sampleInput:"73 74 75 71 69 72 76 73",sampleOutput:"1 1 4 2 1 1 0 0"},{id:"min-path-sum",title:"最小路径和",difficulty:"中等",tags:["动态规划","矩阵"],statement:`给定 m×n 非负网格，从左上走到右下，每次只能向右或向下，求路径上数字和的最小值。

输入：第一行 m n；接下来 m 行每行 n 个数。
输出：最小路径和。`,sampleInput:`3 3
1 3 1
1 5 1
4 2 1`,sampleOutput:"7"},{id:"unique-paths",title:"不同路径",difficulty:"中等",tags:["动态规划","组合数学"],statement:`m×n 网格，机器人从左上到右下，每次只能向右或向下，求不同路径总数。

输入：一行 m n。
输出：路径数。`,sampleInput:"3 7",sampleOutput:"28"},{id:"max-subarray",title:"最大子数组和",difficulty:"中等",tags:["动态规划","分治"],statement:`给定整数数组 nums，找到具有最大和的连续子数组，返回其和。

输入：一行数组。
输出：最大子数组和。`,sampleInput:"-2 1 -3 4 -1 2 1 -5 4",sampleOutput:"6"},{id:"group-anagrams",title:"字母异位词分组",difficulty:"中等",tags:["哈希","字符串"],statement:`给定字符串数组，把字母异位词组合在一起。

输入：一行若干单词（空格分隔）。
输出：每行一组异位词（空格分隔），组内与组间顺序不限。`,sampleInput:"eat tea tan ate nat bat",sampleOutput:`eat tea ate
tan nat
bat`},{id:"spiral-matrix",title:"螺旋矩阵",difficulty:"中等",tags:["矩阵","模拟"],statement:`给定 m×n 矩阵，按顺时针螺旋顺序返回所有元素。

输入：第一行 m n；接下来 m 行每行 n 个数。
输出：螺旋顺序的所有元素（空格分隔，一行）。`,sampleInput:`3 3
1 2 3
4 5 6
7 8 9`,sampleOutput:"1 2 3 6 9 8 7 4 5"},{id:"jump-game",title:"跳跃游戏",difficulty:"中等",tags:["贪心"],statement:`给定非负整数数组 nums，初始位于下标 0，每个元素代表在该位置可跳跃的最大长度，判断能否到达最后一个下标。

输入：一行数组。
输出：true 或 false。`,sampleInput:"2 3 1 1 4",sampleOutput:"true"},{id:"longest-consecutive",title:"最长连续序列",difficulty:"中等",tags:["哈希","并查集"],statement:`给定未排序数组 nums，找出数字连续的最长序列长度，要求 O(n)。

输入：一行数组。
输出：最长连续序列长度。`,sampleInput:"100 4 200 1 3 2",sampleOutput:"4"},{id:"top-k-frequent",title:"前 K 个高频元素",difficulty:"中等",tags:["堆","哈希"],statement:`给定整数数组 nums 和整数 k，返回出现频率前 k 高的元素（按频率从高到低）。

输入：第一行 k；第二行数组。
输出：前 k 个高频元素（空格分隔）。`,sampleInput:`2
1 1 1 2 2 3`,sampleOutput:"1 2"},{id:"decode-ways",title:"解码方法",difficulty:"中等",tags:["动态规划","字符串"],statement:`数字到字母的映射为 '1'->A ... '26'->Z。给定只含数字的字符串 s，计算它有多少种解码方法。

输入：一行数字字符串 s。
输出：解码方法数。`,sampleInput:"226",sampleOutput:"3"},{id:"validate-bst",title:"验证二叉搜索树",difficulty:"中等",tags:["树","DFS"],statement:`给定二叉树的层序遍历（null 表示空节点），判断它是否是有效的二叉搜索树。

输入：一行层序遍历，节点值或 null，空格分隔。
输出：true 或 false。`,sampleInput:"5 1 4 null null 3 6",sampleOutput:"false"},{id:"gas-station",title:"加油站",difficulty:"中等",tags:["贪心"],statement:`环路上有 n 个加油站，gas[i] 为可加油量，cost[i] 为到下一站的耗油。从某站出发绕一圈，返回可行的起始站下标，无解返回 -1。

输入：第一行 gas 数组；第二行 cost 数组。
输出：起始站下标或 -1。`,sampleInput:`1 2 3 4 5
3 4 5 1 2`,sampleOutput:"3"},{id:"partition-equal",title:"分割等和子集",difficulty:"中等",tags:["动态规划","背包"],statement:`给定只含正整数的非空数组 nums，判断能否将其分割成两个和相等的子集。

输入：一行数组。
输出：true 或 false。`,sampleInput:"1 5 11 5",sampleOutput:"true"},{id:"house-robber-ii",title:"打家劫舍 II（环形）",difficulty:"中等",tags:["动态规划"],statement:`房屋围成一圈，相邻两间不能同时偷。给定每间金额数组 nums，求能偷到的最高金额。

输入：一行数组。
输出：最高金额。`,sampleInput:"2 3 2",sampleOutput:"3"},{id:"find-duplicate",title:"寻找重复数",difficulty:"中等",tags:["双指针","快慢指针"],statement:`给定 n+1 个整数的数组 nums，数字都在 [1, n] 内，存在且仅存在一个重复数，找出它（不修改数组、O(1) 空间）。

输入：一行数组。
输出：重复的数字。`,sampleInput:"1 3 4 2 2",sampleOutput:"2"},{id:"min-window",title:"最小覆盖子串",difficulty:"困难",tags:["滑动窗口","哈希"],statement:`给定字符串 s 和 t，返回 s 中涵盖 t 所有字符的最小子串；不存在则返回空串。

输入：第一行 s；第二行 t。
输出：最小覆盖子串。`,sampleInput:`ADOBECODEBANC
ABC`,sampleOutput:"BANC"},{id:"trapping-rain",title:"接雨水",difficulty:"困难",tags:["双指针","单调栈"],statement:`给定 n 个非负整数表示柱子高度图，计算下雨后能接多少雨水。

输入：一行高度数组。
输出：能接的雨水总量。`,sampleInput:"0 1 0 2 1 0 1 3 2 1 2 1",sampleOutput:"6"},{id:"edit-distance",title:"编辑距离",difficulty:"困难",tags:["动态规划"],statement:`给定两个单词 word1 和 word2，返回将 word1 转换成 word2 所使用的最少操作数（插入/删除/替换）。

输入：两行，分别为 word1 和 word2。
输出：最少操作数。`,sampleInput:`horse
ros`,sampleOutput:"3"},{id:"lis",title:"最长递增子序列",difficulty:"中等",tags:["动态规划","二分"],statement:`给定整数数组 nums，找到其中最长严格递增子序列的长度。

输入：一行数组。
输出：最长递增子序列长度。`,sampleInput:"10 9 2 5 3 7 101 18",sampleOutput:"4"}],Y={python:`import sys

def solve(data):
    # data 是按行切分的输入列表；在这里实现你的逻辑并 print 结果
    pass

def main():
    data = sys.stdin.read().split('\\n')
    solve(data)

if __name__ == '__main__':
    main()
`,java:`import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // 在这里读取输入、实现逻辑并 System.out.println 输出结果
        // String line = br.readLine();
    }
}
`};function ce(){const s=Math.floor(Math.random()*oe.length);return oe[s]}const Pe={python:["print(","input(","len(","range(","int(","str(","float(","list(","dict(","set(","tuple(","sorted(","reversed(","enumerate(","zip(","map(","filter(","sum(","min(","max(","abs(","round(","any(","all(","isinstance(","append(","extend(","insert(","pop(","remove(","sort(","split(","join(","strip(","replace(","startswith(","endswith(","find(","format(","keys(","values(","items(","get(","setdefault(","def ","class ","return ","import ","from ","for ","while ","if ","elif ","else:","try:","except ","finally:","with ","lambda ","yield ","global ","collections","defaultdict(","Counter(","deque(","heapq","heappush(","heappop(","heapify(","bisect","bisect_left(","bisect_right(","itertools","functools","lru_cache","math","sys.stdin","sys.stdin.read("],java:["public ","private ","protected ","static ","final ","void ","class ","interface ","extends ","implements ","return ","new ","import ","package ","if ","else ","for ","while ","switch ","case ","break;","continue;","try ","catch ","finally ","throw ","throws ","int ","long ","double ","float ","boolean ","char ","byte ","short ","String ","Integer","Long","Double","Boolean","Character","Math.","System.out.println(","System.out.print(","System.out.printf(","List<","ArrayList<","LinkedList<","Map<","HashMap<","TreeMap<","Set<","HashSet<","TreeSet<","Queue<","Deque<","ArrayDeque<","PriorityQueue<","Stack<","Collections.","Arrays.","Arrays.sort(","Arrays.asList(","StringBuilder","append(","toString()","length()","size()","add(","get(","put(","getOrDefault(","containsKey(","contains(","remove(","poll(","offer(","peek(","push(","pop(","BufferedReader","InputStreamReader","readLine()","split(","Integer.parseInt(","Long.parseLong(","String.valueOf(","Math.max(","Math.min(","Math.abs("]};function de(s,n){const a=s.slice(0,n).match(/[A-Za-z_.][A-Za-z0-9_.]*$/);return a?a[0]:""}function ze({initialLang:s="python",onSubmit:n}){const[i,a]=o.useState(s),[u,h]=o.useState({python:Y.python,java:Y.java}),[d,w]=o.useState(""),[k,S]=o.useState(""),[g,p]=o.useState(!1),[l,x]=o.useState(!1),[j,N]=o.useState({open:!1,items:[],index:0}),U=o.useRef(null),R=u[i],E=r=>h(m=>({...m,[i]:r})),P=o.useMemo(()=>Pe[i]||[],[i]),O=(r,m)=>{const C=de(r,m);if(C.length<1){N({open:!1,items:[],index:0});return}const c=C.toLowerCase(),L=P.filter(I=>I.toLowerCase().startsWith(c)&&I.toLowerCase()!==c).slice(0,8);N(L.length?{open:!0,items:L,index:0}:{open:!1,items:[],index:0})},_=r=>{const m=U.current;if(!m)return;const C=m.selectionStart,c=de(R,C),L=C-c.length,I=R.slice(0,L)+r+R.slice(C);E(I);const M=L+r.length;N({open:!1,items:[],index:0}),requestAnimationFrame(()=>{m.focus(),m.selectionStart=m.selectionEnd=M})},K=r=>{E(r.target.value),O(r.target.value,r.target.selectionStart)},z=r=>{if(j.open){if(r.key==="ArrowDown"){r.preventDefault(),N(m=>({...m,index:(m.index+1)%m.items.length}));return}if(r.key==="ArrowUp"){r.preventDefault(),N(m=>({...m,index:(m.index-1+m.items.length)%m.items.length}));return}if(r.key==="Enter"||r.key==="Tab"){r.preventDefault(),_(j.items[j.index]);return}if(r.key==="Escape"){N({open:!1,items:[],index:0});return}}if(r.key==="Tab"){r.preventDefault();const m=r.target,C=m.selectionStart,c=m.selectionEnd,L=R.slice(0,C)+"    "+R.slice(c);E(L),requestAnimationFrame(()=>{m.selectionStart=m.selectionEnd=C+4})}r.key==="Enter"&&(r.ctrlKey||r.metaKey)&&(r.preventDefault(),l||B())},B=async()=>{x(!0),p(!1),S("正在执行…");try{const r=await Le({language:i,source:R,stdin:d}),m=r.output||r.stdout||"",C=r.stderr||"",c=[m,C].filter(Boolean).join(`
`);p(!!C&&!m),S(c||"（没有任何输出）")}catch(r){p(!0),S(String((r==null?void 0:r.message)||r))}finally{x(!1)}},G=()=>E(Y[i]),D=Math.max(14,R.split(`
`).length+1);return e.jsxs("div",{className:"code-editor",children:[e.jsxs("div",{className:"ce-tabs",children:[["python","java"].map(r=>e.jsx("button",{className:`ce-tab ${r===i?"active":""}`,onClick:()=>{a(r),N({open:!1,items:[],index:0})},children:r==="python"?"Python":"Java"},r)),e.jsxs("div",{className:"ce-tab-actions",children:[e.jsx("button",{className:"btn btn-ghost ce-small",onClick:G,disabled:l,children:"重置模板"}),e.jsx("button",{className:"btn btn-primary ce-small",onClick:B,disabled:l,children:l?"执行中…":"▶ 运行"})]})]}),e.jsxs("div",{className:"ce-editor-wrap",children:[e.jsx("textarea",{ref:U,className:"ce-textarea",value:R,onChange:K,onKeyDown:z,onBlur:()=>setTimeout(()=>N({open:!1,items:[],index:0}),120),spellCheck:!1,rows:D,"aria-label":"代码编辑器"}),j.open&&e.jsx("ul",{className:"ce-suggest",children:j.items.map((r,m)=>e.jsx("li",{className:m===j.index?"active":"",onMouseDown:C=>{C.preventDefault(),_(r)},children:r},r))})]}),e.jsxs("div",{className:"ce-io",children:[e.jsxs("div",{className:"ce-io-col",children:[e.jsx("label",{className:"ce-label",children:"标准输入（stdin，可留空）"}),e.jsx("textarea",{className:"ce-stdin",value:d,onChange:r=>w(r.target.value),spellCheck:!1,rows:4,placeholder:"把样例输入粘到这里，运行时会作为程序的标准输入"})]}),e.jsxs("div",{className:"ce-io-col",children:[e.jsx("label",{className:"ce-label",children:"运行结果"}),e.jsx("pre",{className:`ce-output${g?" is-error":""}`,children:k||"（点击「运行」查看输出）"})]})]}),e.jsxs("div",{className:"ce-bottom",children:[e.jsx("span",{className:"ce-hint",children:"提示：输入时会出现基础库联想（↑↓ 选择，Enter/Tab 补全）；Ctrl/⌘ + Enter 运行。"}),n&&e.jsx("button",{className:"btn btn-primary",onClick:()=>n({language:i,source:R}),children:"提交给面试官点评"})]})]})}function Be(){return me.map(s=>({slug:s.meta.slug,title:s.meta.title,desc:s.meta.shortTitle||s.meta.subtitle||"",cat:`${s.meta.categoryId}/${s.meta.subCategoryId||""}`}))}function ue(s){return`${typeof window<"u"?window.location.origin:""}/course/${s}`}function pe(s){return me.find(n=>n.meta.slug===s)||null}const Ve={A:{label:"A · 非常满意",color:"#0e835a",desc:"语言表达、项目、技术与 Coding 近乎完美，正是公司需要的人才（极难获得）"},B:{label:"B · 优秀人才",color:"#2563eb",desc:"整体优秀，个别方面略有差距，强烈推荐给后续面试官"},C:{label:"C · 通过面试",color:"#b26a09",desc:"项目与技术基础扎实，可继续推进，但缺少特别亮眼的表现"},D:{label:"D · 未通过（可荐他岗）",color:"#c0344d",desc:"部分方面欠缺，本岗位不再推进，其他岗位可继续面试"},E:{label:"E · 不可行",color:"#7a1326",desc:"一个或多个方面表现很差，短期内不建议推进其他岗位"}};function H(s){return Ve[s]||{label:s,color:"#454c59",desc:""}}function He(s){const n=te(s.position),i=Be().map(a=>`${a.slug} | ${a.title}`).join(`
`);return`面试到此结束。现在请你切换为「面试评估官」，基于上面完整的面试对话记录，对这位「${n?n.title:s.position}」候选人做一次严谨、客观的综合评估打分。

# 评分等级（必须从中选一个）
- A：非常满意。语言表达、项目考察、技术技能和 Coding 都基本做到完美，正是公司需要的人才（极难获得）。
- B：优秀人才。在 A 的基础上个别方面有差距，但仍优秀，会强烈推荐给后续面试官。
- C：通过面试。项目考察、技术基础都比较扎实，可继续推进；没有特别亮眼或打动面试官的表现一般定为此级。
- D：未通过，但可推荐其他岗位。综合评估有所欠缺，本岗位不再推进，其他岗位可继续面试。
- E：完全不可行。一个或多个方面表现很差（如项目说不清、追问细节或基础知识基本不了解），短期内不建议推进其他岗位。

# 评估要求
1. 必须「结合面试中的具体问答实例」给出理由，好的与不足的地方都要引用候选人实际说过的话或表现，不能空口无凭。
2. 分维度评估：语言表达、项目考察、技术基础、AI/LLM 编程、Coding 编码。每个维度给 1-5 分并附结合实例的点评。
3. 给出后续需要加强的知识/技能清单，并尽量从下面的「本站课程清单」中挑选相关课程推荐（用 slug）。

# 本站课程清单（slug | 课程名）
${i}

# 输出格式（务必只输出一个 JSON，不要任何额外文字或 markdown 代码块标记）
{
  "grade": "A|B|C|D|E",
  "gradeReason": "为什么定这个等级（结合整体表现，2-4句）",
  "overallSummary": "整体评价（150字左右）",
  "dimensions": [
    {"name": "语言表达", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "项目考察", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "技术基础", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "AI/LLM 编程", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "Coding 编码", "score": 1-5, "comment": "结合实例的点评"}
  ],
  "strengths": [{"point": "亮点", "example": "面试中的具体实例"}],
  "weaknesses": [{"point": "不足", "example": "面试中的具体实例"}],
  "improvements": [{"topic": "需加强的知识/技能", "detail": "具体建议", "courseSlugs": ["相关课程slug"]}],
  "recommendedCourses": [{"slug": "课程slug", "reason": "推荐理由"}]
}`}function _e(s){if(!s)throw new Error("评估结果为空");let n=s.trim();const i=n.match(/```(?:json)?\s*([\s\S]*?)```/);i&&(n=i[1].trim());const a=n.indexOf("{"),u=n.lastIndexOf("}");return a>=0&&u>a&&(n=n.slice(a,u+1)),JSON.parse(n)}const y=s=>String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");function Ke(s){const n=Math.max(0,Math.min(5,Number(s)||0));return"★".repeat(n)+"☆".repeat(5-n)}function qe(s,n){const i=te(n.position),a=H(s.grade),u=new Date,h=`${u.getFullYear()}-${String(u.getMonth()+1).padStart(2,"0")}-${String(u.getDate()).padStart(2,"0")} ${String(u.getHours()).padStart(2,"0")}:${String(u.getMinutes()).padStart(2,"0")}`,d=(s.dimensions||[]).map(l=>`<tr>
        <td class="dim-name">${y(l.name)}</td>
        <td class="dim-score"><span class="stars">${Ke(l.score)}</span> <b>${y(l.score)}</b>/5</td>
        <td class="dim-comment">${y(l.comment)}</td>
      </tr>`).join(""),w=(s.strengths||[]).map(l=>`<li><div class="pt good">✔ ${y(l.point)}</div>${l.example?`<div class="ex">实例：${y(l.example)}</div>`:""}</li>`).join(""),k=(s.weaknesses||[]).map(l=>`<li><div class="pt bad">✘ ${y(l.point)}</div>${l.example?`<div class="ex">实例：${y(l.example)}</div>`:""}</li>`).join(""),S=(s.improvements||[]).map(l=>{const x=(l.courseSlugs||[]).map(j=>{const N=pe(j);return N?`<a class="course-link" href="${y(ue(j))}" target="_blank" rel="noopener">📘 ${y(N.meta.title)}</a>`:""}).filter(Boolean).join("");return`<li><div class="imp-topic">${y(l.topic)}</div><div class="imp-detail">${y(l.detail)}</div>${x?`<div class="imp-links">${x}</div>`:""}</li>`}).join(""),g=(s.recommendedCourses||[]).map(l=>{const x=pe(l.slug);return x?`<a class="rec-card" href="${y(ue(l.slug))}" target="_blank" rel="noopener">
        <div class="rec-cover">${y(x.meta.cover||"📘")}</div>
        <div class="rec-body"><div class="rec-title">${y(x.meta.title)}</div><div class="rec-reason">${y(l.reason||x.meta.shortTitle||"")}</div></div>
      </a>`:""}).filter(Boolean).join(""),p=(n.skills||[]).map(y).join("、");return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>面试评估报告 · ${y(i?i.title:"")}</title>
<style>
  :root { --ink:#14171f; --soft:#454c59; --faint:#878e9c; --border:#e6e8ec; --bg:#fff; --sub:#f6f7f9; --accent:#4f46e5; }
  * { box-sizing: border-box; }
  body { margin:0; background:#eef0f4; color:var(--ink); font-family:-apple-system,'Segoe UI','Noto Sans SC',system-ui,sans-serif; line-height:1.7; }
  .sheet { max-width:880px; margin:32px auto; background:var(--bg); border-radius:16px; box-shadow:0 12px 40px rgba(20,23,31,.12); overflow:hidden; }
  .head { padding:34px 40px; background:linear-gradient(120deg,#4f46e5,#7c3aed); color:#fff; }
  .head h1 { margin:0 0 6px; font-size:1.6rem; }
  .head .meta { font-size:.9rem; opacity:.9; }
  .body { padding:32px 40px; }
  .grade-box { display:flex; align-items:center; gap:24px; padding:22px 26px; border-radius:14px; background:var(--sub); border:1px solid var(--border); margin-bottom:28px; }
  .grade-badge { width:92px; height:92px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:3rem; font-weight:800; color:#fff; flex-shrink:0; }
  .grade-info .glabel { font-size:1.2rem; font-weight:700; }
  .grade-info .gdesc { color:var(--soft); font-size:.92rem; margin-top:4px; }
  .grade-info .greason { margin-top:10px; font-size:.92rem; }
  h2 { font-size:1.15rem; margin:30px 0 12px; padding-left:12px; border-left:4px solid var(--accent); }
  .summary { background:var(--sub); border-radius:10px; padding:16px 18px; font-size:.95rem; }
  table { width:100%; border-collapse:collapse; font-size:.92rem; }
  th,td { text-align:left; padding:10px 12px; border-bottom:1px solid var(--border); vertical-align:top; }
  th { background:var(--sub); font-size:.82rem; color:var(--soft); }
  .dim-name { font-weight:700; white-space:nowrap; }
  .dim-score { white-space:nowrap; } .stars { color:#f5a623; letter-spacing:1px; }
  ul.list { list-style:none; padding:0; margin:0; }
  ul.list li { padding:12px 0; border-bottom:1px dashed var(--border); }
  .pt { font-weight:700; } .pt.good { color:#0e835a; } .pt.bad { color:#c0344d; }
  .ex { color:var(--soft); font-size:.9rem; margin-top:4px; padding-left:18px; border-left:2px solid var(--border); }
  .imp-topic { font-weight:700; }
  .imp-detail { color:var(--soft); font-size:.92rem; margin:4px 0; }
  .imp-links, .recs { display:flex; flex-wrap:wrap; gap:8px; margin-top:6px; }
  .course-link { display:inline-block; padding:5px 12px; background:#eef0fe; color:#4338ca; border:1px solid #c7cbf7; border-radius:999px; font-size:.84rem; text-decoration:none; }
  .course-link:hover { background:#4f46e5; color:#fff; }
  .recs { margin-top:12px; }
  .rec-card { display:flex; gap:12px; align-items:center; width:calc(50% - 6px); padding:12px 14px; border:1px solid var(--border); border-radius:12px; text-decoration:none; color:inherit; }
  .rec-card:hover { border-color:var(--accent); box-shadow:0 4px 14px rgba(20,23,31,.08); }
  .rec-cover { font-size:1.8rem; } .rec-title { font-weight:700; font-size:.95rem; } .rec-reason { color:var(--soft); font-size:.84rem; }
  .foot { padding:20px 40px; color:var(--faint); font-size:.82rem; border-top:1px solid var(--border); text-align:center; }
  @media print { body{background:#fff;} .sheet{box-shadow:none; margin:0;} }
  @media (max-width:640px){ .rec-card{width:100%;} .body,.head,.foot{padding-left:20px;padding-right:20px;} }
</style>
</head>
<body>
  <div class="sheet">
    <div class="head">
      <h1>面试评估报告</h1>
      <div class="meta">岗位：${y(i?i.title:n.position)} ｜ 考察技能：${p||"—"} ｜ 生成时间：${y(h)}</div>
    </div>
    <div class="body">
      <div class="grade-box">
        <div class="grade-badge" style="background:${a.color}">${y(s.grade)}</div>
        <div class="grade-info">
          <div class="glabel" style="color:${a.color}">${y(a.label)}</div>
          <div class="gdesc">${y(a.desc)}</div>
          <div class="greason">${y(s.gradeReason)}</div>
        </div>
      </div>

      <h2>整体评价</h2>
      <div class="summary">${y(s.overallSummary)}</div>

      <h2>分维度评估</h2>
      <table><thead><tr><th>维度</th><th>评分</th><th>结合实例的点评</th></tr></thead><tbody>${d}</tbody></table>

      <h2>亮点</h2>
      <ul class="list">${w||"<li>（无）</li>"}</ul>

      <h2>不足</h2>
      <ul class="list">${k||"<li>（无）</li>"}</ul>

      <h2>后续需要加强的知识 / 技能</h2>
      <ul class="list">${S||"<li>（无）</li>"}</ul>

      ${g?`<h2>推荐课程</h2><div class="recs">${g}</div>`:""}
    </div>
    <div class="foot">本报告由「编程学习站 · 面试模拟」基于本次面试问答自动生成，仅供学习参考。</div>
  </div>
</body>
</html>`}function Fe(s,n="面试评估报告.html"){const i=new Blob([s],{type:"text/html;charset=utf-8"}),a=URL.createObjectURL(i),u=document.createElement("a");u.href=a,u.download=n,document.body.appendChild(u),u.click(),document.body.removeChild(u),setTimeout(()=>URL.revokeObjectURL(a),2e3)}function Je(s){const n=new Blob([s],{type:"text/html;charset=utf-8"}),i=URL.createObjectURL(n);window.open(i,"_blank"),setTimeout(()=>URL.revokeObjectURL(i),6e4)}function Qe(){return typeof window<"u"&&!!(window.SpeechRecognition||window.webkitSpeechRecognition)}function V(){return typeof window<"u"&&!!window.speechSynthesis}function Ge({lang:s="zh-CN",onResult:n,onError:i,onEnd:a}={}){const u=window.SpeechRecognition||window.webkitSpeechRecognition;if(!u)return null;const h=new u;return h.lang=s,h.continuous=!0,h.interimResults=!0,h.onresult=d=>{let w="",k="";for(let S=d.resultIndex;S<d.results.length;S++){const g=d.results[S];g.isFinal?k+=g[0].transcript:w+=g[0].transcript}k?n&&n(k,!0):w&&n&&n(w,!1)},h.onerror=d=>i&&i(d),h.onend=()=>a&&a(),h}function fe(s){return String(s).split(new RegExp("(?<=[。！？.!?；;\\n])")).map(n=>n.trim()).filter(Boolean)}const We=[[/\bJVM\b/gi,"J V M"],[/\bJDK\b/gi,"J D K"],[/\bJRE\b/gi,"J R E"],[/\bGC\b/gi,"G C"],[/\bJIT\b/gi,"J I T"],[/\bAOP\b/gi,"A O P"],[/\bIOC\b/gi,"I O C"],[/\bRPC\b/gi,"R P C"],[/\bMQ\b/gi,"M Q"],[/\bSQL\b/gi,"S Q L"],[/\bNIO\b/gi,"N I O"],[/\bBIO\b/gi,"B I O"],[/\bXML\b/gi,"X M L"],[/\bHTTPS\b/gi,"H T T P S"],[/\bHTTP\b/gi,"H T T P"],[/\bTCP\b/gi,"T C P"],[/\bUDP\b/gi,"U D P"],[/\bDNS\b/gi,"D N S"],[/\bCDN\b/gi,"C D N"],[/\bAPI\b/gi,"A P I"],[/\bSDK\b/gi,"S D K"],[/\bCSS\b/gi,"C S S"],[/\bDOM\b/gi,"D O M"],[/\bJWT\b/gi,"J W T"],[/\bORM\b/gi,"O R M"],[/\bMVC\b/gi,"M V C"],[/\bMVVM\b/gi,"M V V M"],[/\bMVCC\b/gi,"M V C C"],[/\bWAL\b/gi,"W A L"],[/\bLRU\b/gi,"L R U"],[/\bLFU\b/gi,"L F U"],[/\bFIFO\b/gi,"fai fo"],[/\bQPS\b/gi,"Q P S"],[/\bTPS\b/gi,"T P S"],[/\bOOM\b/gi,"O O M"],[/\bCPU\b/gi,"C P U"],[/\bGPU\b/gi,"G P U"],[/\bAQS\b/gi,"A Q S"],[/\bCAS\b/gi,"C A S"],[/\bLLM\b/gi,"L L M"],[/\bRAG\b/gi,"拉格"],[/\bSFT\b/gi,"S F T"],[/\bRLHF\b/gi,"R L H F"],[/\bLoRA\b/gi,"楼拉"],[/\bKV\b/gi,"K V"],[/\bHTML\b/gi,"H T M L"],[/\bACID\b/gi,"A C I D"],[/\bCAP\b/gi,"C A P"],[/\bRedis\b/gi,"瑞迪斯"],[/\bMySQL\b/gi,"My S Q L"],[/\bNginx\b/gi,"Engine X"],[/\bKafka\b/gi,"卡夫卡"],[/\bRabbitMQ\b/gi,"Rabbit M Q"],[/\bNetty\b/gi,"奈提"],[/\bZooKeeper\b/gi,"Zoo Keeper"],[/\bElasticSearch\b/gi,"Elastic Search"],[/\bTomcat\b/gi,"汤姆Cat"],[/\bLinux\b/gi,"里纳克斯"],[/\bPython\b/gi,"派森"],[/\bThreadLocal\b/gi,"Thread Local"],[/\bArrayList\b/gi,"Array List"],[/\bHashMap\b/gi,"Hash Map"],[/\bB\+?Tree\b/gi,"B 加 Tree"]];function Ze(s){let n=s;for(const[i,a]of We)n=n.replace(i,a);return n}function Xe(s,n){const i=(s.name||"").toLowerCase();let a=0;return s.lang&&s.lang.toLowerCase().startsWith(n.split("-")[0])&&(a+=10),s.localService===!1&&(a+=5),/google/.test(i)&&(a+=4),/(natural|neural|premium|enhanced|online)/.test(i)&&(a+=4),/(tingting|mei-?jia|sin-?ji|yue|yu-?shu|huihui|kangkang|xiaoxiao|yunyang|yunxi)/.test(i)&&(a+=3),a}function Ye(){return typeof window>"u"||!window.speechSynthesis?[]:(window.speechSynthesis.getVoices()||[]).filter(s=>s.lang&&s.lang.toLowerCase().startsWith("zh")).map(s=>({name:s.name,voiceURI:s.voiceURI,lang:s.lang,local:s.localService}))}function ee({lang:s="zh-CN",rate:n=1,pitch:i=1}={}){const a=typeof window<"u"?window.speechSynthesis:null;let u=!0,h=[],d=!1,w=null;function k(){if(!a)return null;const g=a.getVoices()||[];if(w){const x=g.find(j=>j.voiceURI===w);if(x)return x}let p=null,l=-1;for(const x of g){const j=Xe(x,s);j>l&&(p=x,l=j)}return l>=10?p:null}function S(){if(!a||d||h.length===0)return;const g=h.shift();if(!g.trim()){S();return}const p=new SpeechSynthesisUtterance(Ze(g));p.lang=s,p.rate=n,p.pitch=i;const l=k();l&&(p.voice=l),p.onend=()=>{d=!1,S()},p.onerror=()=>{d=!1,S()},d=!0,a.speak(p)}return{kind:"browser",speak(g){if(!a||!u||!g)return;const p=fe(g);h.push(...p.length?p:[g]),S()},stop(){h=[],d=!1,a&&a.cancel()},setEnabled(g){u=g,g||this.stop()},setVoiceURI(g){w=g||null},get enabled(){return u}}}function et({synthesize:s,onUnavailable:n}){let i=!0,a=[],u=0,h=!1,d=null,w=null,k=!1,S=!1;async function g(){for(h=!0;u<a.length;){const p=a[u];let l=null;try{l=await p.promise}catch{l=null}if(!i)break;if(l&&l.byteLength){k=!0;const x=URL.createObjectURL(new Blob([l],{type:"audio/mpeg"}));w=x;const j=new Audio(x);d=j,await new Promise(N=>{j.onended=N,j.onerror=N,j.play().catch(()=>N())}),w&&(URL.revokeObjectURL(w),w=null),d=null}else!k&&!S&&(S=!0,n&&n());u++}h=!1}return{kind:"cloud",speak(p){if(!(!i||!p)){for(const l of fe(p)){const x=new AbortController;a.push({promise:s(l,x.signal),ac:x})}h||g()}},stop(){for(const p of a)try{p.ac.abort()}catch{}if(a=[],u=0,h=!1,d){try{d.pause()}catch{}d=null}w&&(URL.revokeObjectURL(w),w=null)},setEnabled(p){i=p,p||this.stop()},setVoiceURI(){},get enabled(){return i}}}function tt(s){const n=String(Math.floor(s/60)).padStart(2,"0"),i=String(s%60).padStart(2,"0");return`${n}:${i}`}function it(){const s=Oe(),n=$e(),[i,a]=o.useState([]),[u,h]=o.useState(""),[d,w]=o.useState(!1),[k,S]=o.useState(""),[g,p]=o.useState(""),[l,x]=o.useState(0),[j,N]=o.useState(0),[U,R]=o.useState(!1),[E,P]=o.useState(!1),[O,_]=o.useState((n==null?void 0:n.voice)!==!1),[K,z]=o.useState("browser"),[B,G]=o.useState([]),[D,r]=o.useState(()=>localStorage.getItem("interview.voiceURI")||""),[m,C]=o.useState(!1),[c,L]=o.useState(null),[I,M]=o.useState("idle"),[T,ge]=o.useState(null),[se,be]=o.useState(""),[he,W]=o.useState(""),b=o.useRef(null),Z=o.useRef(null),A=o.useRef(""),q=o.useRef(null),F=o.useRef(null),ne=o.useRef(O),X=o.useRef(D),ve=()=>{if(!V())return;try{b.current&&b.current.stop()}catch{}const t=ee({lang:"zh-CN"});t.setEnabled(ne.current),X.current&&t.setVoiceURI(X.current),b.current=t,z("browser")};o.useEffect(()=>{n||s("/interview",{replace:!0})},[]),o.useEffect(()=>{let t=!1;return Ee().then(f=>{t||(f!=null&&f.ttsConfigured?(b.current=et({synthesize:De,onUnavailable:ve}),z("cloud")):V()&&(b.current=ee({lang:"zh-CN"}),z("browser")),b.current&&(b.current.setEnabled(O),D&&b.current.setVoiceURI(D)))}).catch(()=>{t||V()&&(b.current=ee({lang:"zh-CN"}),b.current.setEnabled(O))}),()=>{t=!0,b.current&&b.current.stop()}},[]),o.useEffect(()=>{var f,v;if(!V())return;const t=()=>G(Ye());return t(),(v=(f=window.speechSynthesis).addEventListener)==null||v.call(f,"voiceschanged",t),()=>{var $,Q;return(Q=($=window.speechSynthesis).removeEventListener)==null?void 0:Q.call($,"voiceschanged",t)}},[]),o.useEffect(()=>{ne.current=O,b.current&&b.current.setEnabled(O)},[O]);const xe=t=>{r(t),X.current=t,localStorage.setItem("interview.voiceURI",t||""),b.current&&b.current.setVoiceURI(t)};o.useEffect(()=>{if(!U)return;const t=setInterval(()=>N(f=>f+1),1e3);return()=>clearInterval(t)},[U]),o.useEffect(()=>{q.current&&(q.current.scrollTop=q.current.scrollHeight)},[i,u]);const ye=t=>{if(!O||!b.current)return;A.current+=t;const f=A.current,v=f.match(/^[\s\S]*[。！？.!?；;\n]/);v&&(b.current.speak(v[0]),A.current=f.slice(v[0].length))},we=()=>{O&&b.current&&A.current.trim()&&b.current.speak(A.current),A.current=""},ie=async t=>{w(!0),S(""),h(""),A.current="";const f=new AbortController;F.current=f;try{const v=await Ue({messages:t},$=>{h(Q=>Q+$),ye($)},f.signal);we(),a([...t,{role:"assistant",content:v}]),h("")}catch(v){(v==null?void 0:v.name)!=="AbortError"&&S(String((v==null?void 0:v.message)||v)),h("")}finally{w(!1),F.current=null}},Se=async()=>{const t={role:"system",content:Te(n)};R(!0),await ie([t])},J=async t=>{const f=(t??g).trim();if(!f||d)return;b.current&&b.current.stop(),p("");const v=[...i,{role:"user",content:f}];a(v),await ie(v)},je=()=>{if(!Qe()){S("当前浏览器不支持语音识别，请用 Chrome / Edge，或直接打字作答");return}if(E){Z.current&&Z.current.stop();return}b.current&&b.current.stop();const t=Ge({lang:"zh-CN",onResult:(f,v)=>{v&&p($=>($?$+" ":"")+f)},onError:()=>P(!1),onEnd:()=>P(!1)});t&&(Z.current=t,t.start(),P(!0))},ae=()=>{c||L(ce()),C(!0),x(4)},Ne=async({language:t,source:f})=>{const v=`（编程环节）题目：${c==null?void 0:c.title}
我用 ${t==="java"?"Java":"Python"} 作答，代码如下：

\`\`\`${t}
${f}
\`\`\`

请点评我的思路、时间/空间复杂度和边界处理，并指出可以改进的地方。`;await J(v)},Ce=async()=>{await J("面试官您好，本次面试到这里，麻烦您对我今天的整体表现做一个总结评价：包括优点、不足，以及针对性的提升建议。")},ke=()=>{F.current&&F.current.abort(),b.current&&b.current.stop()},re=async()=>{if(b.current&&b.current.stop(),i.filter(t=>t.role!=="system").length<2){W("面试内容太少，请先进行面试再生成报告"),M("error");return}M("loading"),W("");try{const t=[...i,{role:"user",content:He(n)}],f=await Ae({messages:t}),v=_e(f),$=qe(v,n);ge(v),be($),M("ready")}catch(t){W("生成报告失败："+String((t==null?void 0:t.message)||t)),M("error")}};if(!n)return null;const le=te(n.position),Ie=i.filter(t=>t.role!=="system");return e.jsx(Re,{children:e.jsxs("div",{className:"container iv-session",children:[e.jsxs("div",{className:"iv-bar",children:[e.jsxs("div",{className:"iv-bar-left",children:[e.jsxs("span",{className:"iv-bar-title",children:["模拟面试 · ",le?le.title:""]}),e.jsxs("span",{className:"iv-timer",children:["⏱ ",tt(j)]})]}),e.jsxs("div",{className:"iv-bar-right",children:[(K==="cloud"||V())&&e.jsx("button",{className:`iv-pill ${O?"on":""}`,onClick:()=>_(t=>!t),title:"面试官语音朗读",children:O?"🔊 语音开":"🔇 语音关"}),K==="cloud"?e.jsx("span",{className:"iv-pill on",title:"使用云端神经语音",children:"✨ 自然语音"}):O&&B.length>0&&e.jsxs("select",{className:"iv-voice-select",value:D,onChange:t=>xe(t.target.value),title:"选择语音音色（建议选带 Google/在线/Natural 的更自然）",children:[e.jsx("option",{value:"",children:"默认音色（自动挑最优）"}),B.map(t=>e.jsxs("option",{value:t.voiceURI,children:[t.name,t.local?"（本地）":"（在线）"]},t.voiceURI))]}),e.jsx("button",{className:"btn btn-ghost ce-small",onClick:()=>s("/interview"),children:"退出"})]})]}),e.jsx("div",{className:"iv-stages",children:Me.map((t,f)=>e.jsxs("button",{className:`iv-stage ${f===l?"active":""} ${f<l?"done":""}`,onClick:()=>{x(f),t.id==="coding"&&ae()},title:`${t.desc} · 约${t.minutes}分钟`,children:[e.jsx("span",{className:"iv-stage-no",children:f+1}),e.jsx("span",{className:"iv-stage-name",children:t.title}),e.jsxs("span",{className:"iv-stage-min",children:[t.minutes,"min"]})]},t.id))}),e.jsxs("div",{className:`iv-main ${m?"with-code":""}`,children:[e.jsx("div",{className:"iv-chat-col",children:U?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"iv-messages",ref:q,children:[Ie.map((t,f)=>e.jsxs("div",{className:`iv-msg ${t.role}`,children:[e.jsx("div",{className:"iv-msg-who",children:t.role==="assistant"?"面试官":"我"}),e.jsx("div",{className:"iv-msg-body",children:t.content})]},f)),u&&e.jsxs("div",{className:"iv-msg assistant",children:[e.jsx("div",{className:"iv-msg-who",children:"面试官"}),e.jsxs("div",{className:"iv-msg-body",children:[u,e.jsx("span",{className:"iv-caret",children:"▍"})]})]}),d&&!u&&e.jsxs("div",{className:"iv-msg assistant",children:[e.jsx("div",{className:"iv-msg-who",children:"面试官"}),e.jsx("div",{className:"iv-msg-body iv-thinking",children:"思考中…"})]})]}),k&&e.jsx("div",{className:"iv-error",children:k}),e.jsxs("div",{className:"iv-input-area",children:[e.jsx("textarea",{className:"iv-answer",value:g,onChange:t=>p(t.target.value),onKeyDown:t=>{t.key==="Enter"&&(t.ctrlKey||t.metaKey)&&(t.preventDefault(),J())},placeholder:E?"正在聆听，请说话…（识别结果会填到这里）":"输入你的回答，或点麦克风语音作答（Ctrl/⌘+Enter 发送）",rows:3,disabled:d}),e.jsxs("div",{className:"iv-input-actions",children:[e.jsx("button",{className:`iv-mic ${E?"on":""}`,onClick:je,disabled:d,title:"语音作答",children:E?"● 停止录音":"🎤 语音"}),e.jsx("div",{className:"iv-spacer"}),d&&e.jsx("button",{className:"btn btn-ghost ce-small",onClick:ke,children:"停止"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>J(),disabled:d||!g.trim(),children:"发送"})]}),e.jsxs("div",{className:"iv-quick",children:[e.jsx("button",{className:"iv-quick-btn",onClick:ae,disabled:d,children:"进入编程环节 ⌨️"}),e.jsx("button",{className:"iv-quick-btn",onClick:Ce,disabled:d,children:"请面试官总结评价"}),e.jsx("button",{className:"iv-quick-btn primary",onClick:re,disabled:d||I==="loading",children:I==="loading"?"正在生成报告…":"结束并生成评分报告 📄"})]})]})]}):e.jsxs("div",{className:"iv-prestart",children:[e.jsx("p",{children:"准备好了吗？点击下方按钮，面试官将先做自我介绍并请你介绍自己。"}),e.jsx("p",{className:"iv-sub",children:"全程约 1 小时，建议在安静环境、用 Chrome/Edge 浏览器以获得最佳语音体验。"}),e.jsx("button",{className:"btn btn-primary iv-start",onClick:Se,disabled:d,children:d?"面试官准备中…":"开始面试"})]})}),m&&e.jsxs("div",{className:"iv-code-col",children:[e.jsxs("div",{className:"iv-problem",children:[e.jsxs("div",{className:"iv-problem-head",children:[e.jsxs("h3",{children:[c==null?void 0:c.title," ",e.jsx("span",{className:`iv-diff ${c==null?void 0:c.difficulty}`,children:c==null?void 0:c.difficulty})]}),e.jsx("button",{className:"iv-quick-btn",onClick:()=>L(ce()),children:"换一题"})]}),e.jsx("div",{className:"iv-problem-tags",children:((c==null?void 0:c.tags)||[]).map(t=>e.jsx("span",{className:"iv-tag",children:t},t))}),e.jsx("pre",{className:"iv-problem-body",children:c==null?void 0:c.statement}),(c==null?void 0:c.sampleInput)!=null&&e.jsxs("div",{className:"iv-sample",children:[e.jsxs("div",{children:[e.jsx("strong",{children:"示例输入"}),e.jsx("pre",{children:c.sampleInput})]}),e.jsxs("div",{children:[e.jsx("strong",{children:"示例输出"}),e.jsx("pre",{children:c.sampleOutput})]})]})]}),e.jsx(ze,{initialLang:"python",onSubmit:Ne},c==null?void 0:c.id)]})]}),(I==="ready"||I==="error"||I==="loading")&&e.jsx("div",{className:"iv-modal-mask",onClick:()=>I!=="loading"&&M("idle"),children:e.jsxs("div",{className:"iv-modal",onClick:t=>t.stopPropagation(),children:[I==="loading"&&e.jsxs("div",{className:"iv-modal-loading",children:[e.jsx("div",{className:"iv-spin"}),e.jsx("p",{children:"面试评估官正在结合本次问答为你打分、撰写报告…"})]}),I==="error"&&e.jsxs("div",{className:"iv-modal-body",children:[e.jsx("h3",{children:"生成失败"}),e.jsx("div",{className:"iv-error",children:he}),e.jsxs("div",{className:"iv-modal-actions",children:[e.jsx("button",{className:"btn btn-ghost",onClick:()=>M("idle"),children:"关闭"}),e.jsx("button",{className:"btn btn-primary",onClick:re,children:"重试"})]})]}),I==="ready"&&T&&e.jsxs("div",{className:"iv-modal-body",children:[e.jsxs("div",{className:"iv-report-grade",children:[e.jsx("div",{className:"iv-grade-badge",style:{background:H(T.grade).color},children:T.grade}),e.jsxs("div",{children:[e.jsx("div",{className:"iv-grade-label",style:{color:H(T.grade).color},children:H(T.grade).label}),e.jsx("div",{className:"iv-grade-desc",children:H(T.grade).desc})]})]}),e.jsx("p",{className:"iv-report-reason",children:T.gradeReason}),e.jsx("p",{className:"iv-report-summary",children:T.overallSummary}),e.jsx("p",{className:"iv-sub",children:"完整报告（含分维度评分、结合实例的亮点与不足、提升建议与课程推荐）可下载或在新窗口查看："}),e.jsxs("div",{className:"iv-modal-actions",children:[e.jsx("button",{className:"btn btn-ghost",onClick:()=>M("idle"),children:"关闭"}),e.jsx("button",{className:"btn btn-ghost",onClick:()=>Je(se),children:"在新窗口打开"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>Fe(se,`面试评估报告_${T.grade}.html`),children:"下载 HTML 报告"})]})]})]})})]})})}export{it as default};
