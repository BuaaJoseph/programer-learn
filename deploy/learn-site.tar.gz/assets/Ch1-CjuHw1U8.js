import{j as e}from"./index-I8-WI4LI.js";import{L as i,S as c}from"./Summary-BMIdTn04.js";import{K as t}from"./KeyIdea-Xbvwo63C.js";import{C as n}from"./Callout-ZgrsOCpc.js";import{C as s}from"./CodeBlock-CK6ncc4Q.js";import{E as r}from"./Example-CPIFvVrE.js";const d=`# .github/workflows/ci.yml —— 触发部分
name: CI

on:
  push:
    branches: [main]            # 推到 main 时跑
  pull_request:
    branches: [main]            # 针对 main 开 / 更新 PR 时跑
  workflow_dispatch:            # 也允许在 Actions 页面手动点一下触发`,l=`jobs:
  verify:                       # job 的 id，自取
    runs-on: ubuntu-latest      # 在哪个 runner 上跑
    steps:
      - name: 检出代码
        uses: actions/checkout@v4

      - name: 安装 Node
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm            # 自动缓存 ~/.npm，命中后装依赖快得多

      - name: 安装依赖
        run: npm ci             # ci 比 install 更适合流水线：严格按 lock 文件、可复现

      - name: Lint
        run: npm run lint

      - name: 类型检查
        run: npm run typecheck

      - name: 单元测试
        run: npm test

      - name: 构建
        run: npm run build`,o=`      - name: 上传构建产物
        uses: actions/upload-artifact@v4
        with:
          name: dist            # 制品名
          path: dist/           # 要打包上传的目录
          retention-days: 7     # 保留 7 天后自动清理`,h=`jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false          # 一个组合挂了，别急着取消其它组合
      matrix:
        node: [18, 20, 22]      # 同一套步骤，在 3 个 Node 版本上各跑一遍
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: \${{ matrix.node }}
          cache: npm
      - run: npm ci
      - run: npm test`,j=`jobs:
  lint:                         # 这三个 job 没有 needs，会并行起跑
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci
      - run: npm run lint

  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci
      - run: npm test

  build:
    needs: [lint, test]         # 必须 lint 和 test 都绿了才开始 build
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci
      - run: npm run build`,x=`      - name: 上报覆盖率
        run: npx codecov
        env:
          CODECOV_TOKEN: \${{ secrets.CODECOV_TOKEN }}  # 敏感值放 仓库 Settings → Secrets，绝不写进代码`,a=`# .github/workflows/ci.yml —— 一条完整可用的前端 CI
name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

# 同一分支新推送时，自动取消上一次还没跑完的运行，省额度
concurrency:
  group: ci-\${{ github.ref }}
  cancel-in-progress: true

jobs:
  quality:                      # 第一关：质量门禁，并行跑 lint / typecheck / test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm run lint
      - run: npm run typecheck
      - run: npm test -- --coverage

  build:                        # 第二关：质量过了才构建并产出制品
    needs: quality
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm run build
      - uses: actions/upload-artifact@v4
        with:
          name: dist
          path: dist/
          retention-days: 7`;function f(){return e.jsxs("article",{children:[e.jsxs(i,{children:["写完代码、跑过本地测试、推上去——然后呢？在团队协作里，光靠「我本地是好的」远远不够： 别人的机器环境不同、有人忘了跑 lint、某次合并悄悄引入了类型错误。",e.jsx("strong",{children:"CI（持续集成）"}),"就是用来堵住这些缝隙的：每一次提交都由一台干净的机器 自动把检查、测试、构建从头跑一遍，绿了才让合并。这一章我们把 CI/CD 的概念讲透， 再用 GitHub Actions 亲手搭一条能用的前端流水线。"]}),e.jsx("h2",{children:"一、先分清三个词：CI、持续交付、持续部署"}),e.jsx("p",{children:"这三个词常被混着说，但指的是流水线上不同的「自动化深度」。理解它们的差别， 才知道自己的项目要做到哪一步。"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"持续集成（Continuous Integration, CI）"}),"：每次提交 / PR 都自动验证——装依赖、跑 lint、类型检查、测试、构建。目标是",e.jsx("strong",{children:"尽早发现问题"}),"， 让「能不能合并」有客观依据，而不是靠人肉 review 猜。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"持续交付（Continuous Delivery, CD）"}),"：在 CI 之上，自动把验证通过的代码",e.jsx("strong",{children:"打包成随时可上线的制品"}),"，但最后「要不要发布」由人点一下确认。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"持续部署（Continuous Deployment, CD）"}),"：再进一步，连那一下确认都省了—— 只要主干绿，",e.jsx("strong",{children:"自动上线到生产"}),"。这要求测试覆盖足够可信。"]})]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"能力"}),e.jsx("th",{children:"自动验证"}),e.jsx("th",{children:"自动产出制品"}),e.jsx("th",{children:"自动上线生产"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"持续集成 CI"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"否 / 可选"}),e.jsx("td",{children:"否"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"持续交付"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"否（人工点确认）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"持续部署"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"是"})]})]})]}),e.jsx(t,{children:"CI 解决的是「我的改动会不会弄坏别人 / 别人的改动会不会弄坏我」。 它把「在干净环境里从头验证一遍」这件事自动化、强制化， 让代码质量不再依赖每个人的自觉与记忆。"}),e.jsx("h2",{children:"二、为什么非要 CI 不可"}),e.jsx("p",{children:"小项目一个人写，似乎本地跑跑就够了。但只要协作规模一上来，没有 CI 的代价会迅速放大："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"早发现问题"}),"：错误越晚被发现，定位和修复成本越高。CI 在每次提交时就拦下问题， 而不是等到上线前甚至上线后才暴雷。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"统一环境"}),"：CI 永远在一台",e.jsx("strong",{children:"干净、可复现"}),"的机器上跑， 根治「在我电脑上是好的」——因为参照系不再是某个人的电脑，而是这台标准机器。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"质量门禁"}),"：把 lint / 类型 / 测试 / 构建变成合并的",e.jsx("strong",{children:"硬性前置条件"}),"， 没绿就合不进去。质量标准从「靠自觉」升级为「靠机器强制」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"解放 review"}),"：机器能查的（格式、类型、用例）交给机器， 人就能专注看真正需要判断的设计与逻辑。"]})]}),e.jsx("h2",{children:"三、GitHub Actions 的心智模型"}),e.jsxs("p",{children:["GitHub Actions 是 GitHub 内置的 CI/CD 平台，配置就是仓库里",e.jsx("code",{children:".github/workflows/"})," 下的 YAML 文件。它的层级从大到小是："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"workflow（工作流）"}),"：一个 YAML 文件就是一条流水线，由某些事件触发。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"job（任务）"}),"：一条流水线里的并列单元，各自跑在独立的 runner（虚拟机）上，默认",e.jsx("strong",{children:"并行"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"step（步骤）"}),"：job 内部按顺序执行的一步，要么 ",e.jsx("code",{children:"run"})," 一条命令，要么 ",e.jsx("code",{children:"uses"})," 一个现成 action。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"action"}),"：可复用的步骤封装，比如 ",e.jsx("code",{children:"actions/checkout"}),"（检出代码）、",e.jsx("code",{children:"actions/setup-node"}),"（装 Node）。"]})]}),e.jsxs(n,{variant:"info",title:"job 之间默认不共享文件",children:["每个 job 在",e.jsx("strong",{children:"全新的虚拟机"}),"上启动，互相之间硬盘是隔离的。 所以 job A 装的依赖、build 的产物，job B 看不到——要么各自重装， 要么通过 artifact / cache 显式传递。同一个 job 内的 step 才共享同一个工作目录。"]}),e.jsx("h2",{children:"四、触发：什么时候跑"}),e.jsxs("p",{children:[e.jsx("code",{children:"on"})," 字段定义触发条件。前端 CI 最常用两个事件：",e.jsx("code",{children:"push"}),"（推送到指定分支）和 ",e.jsx("code",{children:"pull_request"}),"（开 / 更新 PR）。 前者守护主干，后者在合并前就把关。"]}),e.jsx(s,{lang:"yaml",title:"触发条件 on",code:d}),e.jsx("h2",{children:"五、一个 job 跑通整条检查链"}),e.jsxs("p",{children:["最朴素的做法是把所有步骤塞进一个 job，按顺序跑：检出 → 装 Node → 装依赖 → lint → 类型检查 → 测试 → 构建。注意装依赖用 ",e.jsx("code",{children:"npm ci"})," 而不是",e.jsx("code",{children:"npm install"}),"——前者严格依据 ",e.jsx("code",{children:"package-lock.json"})," 安装，结果可复现，正是 CI 想要的。"]}),e.jsx(s,{lang:"yaml",title:"单 job 完成检出 / 安装 / 检查 / 构建",code:l}),e.jsxs("p",{children:["其中 ",e.jsx("code",{children:"setup-node"})," 的 ",e.jsx("code",{children:"cache: npm"})," 是关键加速点：它把 npm 的下载缓存 按 lock 文件做哈希存起来，下次只要依赖没变就直接命中，省下大量重复下载时间。 依赖缓存往往能把一次 CI 从几分钟压到几十秒。"]}),e.jsx("h2",{children:"六、产出制品 artifact"}),e.jsxs("p",{children:["构建出来的 ",e.jsx("code",{children:"dist/"})," 在 job 结束时会随虚拟机一起销毁。如果想把它留下来—— 给后续 job 用、给人下载、或交给部署步骤——就用 ",e.jsx("code",{children:"actions/upload-artifact"})," 上传成制品。"]}),e.jsx(s,{lang:"yaml",title:"把 dist 上传为 artifact",code:o}),e.jsxs("p",{children:["制品可以在那次运行的页面下载，也能被同一 workflow 里的其它 job 用",e.jsx("code",{children:"actions/download-artifact"})," 取回。这是「构建一次、到处复用」的基础。"]}),e.jsx("h2",{children:"七、并行 job 与矩阵 matrix"}),e.jsxs("p",{children:["既然 job 默认并行，就可以把彼此独立的检查拆开同时跑，缩短总时长； 再用 ",e.jsx("code",{children:"needs"})," 表达依赖关系，让有先后的环节排好队。"]}),e.jsx(s,{lang:"yaml",title:"并行 job + needs 表达依赖",code:j}),e.jsxs("p",{children:["而当你想用",e.jsx("strong",{children:"同一套步骤"}),"覆盖",e.jsx("strong",{children:"多种环境组合"}),"（比如多个 Node 版本、 多个操作系统）时，不必复制粘贴——用 ",e.jsx("code",{children:"strategy.matrix"})," 让 GitHub 自动展开成多个并行 job。"]}),e.jsx(s,{lang:"yaml",title:"矩阵 matrix：一套步骤跑多版本",code:h}),e.jsxs(n,{variant:"tip",title:"fail-fast 的取舍",children:[e.jsx("code",{children:"fail-fast: true"}),"（默认）会在任一组合失败时立刻取消其余组合，省时间但少信息； 设成 ",e.jsx("code",{children:"false"})," 则让所有组合都跑完，便于一次看清「到底哪些版本挂了」。 调试兼容性问题时常关掉它。"]}),e.jsx("h2",{children:"八、合并门禁：分支保护 + 必需检查"}),e.jsxs("p",{children:["CI 跑出绿勾只是第一步，真正的「门禁」要靠仓库设置来强制。在",e.jsx("strong",{children:"Settings → Branches → Branch protection rules"})," 里给 ",e.jsx("code",{children:"main"})," 加保护："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Require status checks to pass"}),"：把 CI 的 job 设为",e.jsx("strong",{children:"必需检查"}),"，没绿就禁止合并。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Require branches to be up to date"}),"：要求 PR 先同步主干最新代码再合，避免「各自都绿、合到一起却坏」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Require pull request reviews"}),"：要求至少一个人 approve，把机器把关和人工 review 叠加。"]})]}),e.jsx("p",{children:"配好之后，红勾的 PR 连「Merge」按钮都点不动——质量标准就此变成不可绕过的硬约束。"}),e.jsx("h2",{children:"九、Secrets：敏感信息怎么传"}),e.jsxs("p",{children:["部署 token、第三方服务密钥这类敏感值，绝不能写进仓库。把它们存到",e.jsx("strong",{children:"Settings → Secrets and variables → Actions"}),"，在 YAML 里用",e.jsx("code",{children:"${{ secrets.XXX }}"})," 引用即可，GitHub 会在日志里自动打码。"]}),e.jsx(s,{lang:"yaml",title:"通过 secrets 注入敏感值",code:x}),e.jsx("h2",{children:"十、一份完整可用的前端 CI"}),e.jsxs("p",{children:["把上面的要点收拢成一条真正能跑的流水线：质量门禁（lint / typecheck / test）先并行成关， 过了再 build 并上传制品；外加 ",e.jsx("code",{children:"concurrency"})," 自动取消同分支的旧运行省额度。"]}),e.jsx(s,{lang:"yaml",title:"完整的 .github/workflows/ci.yml",code:a}),e.jsx(r,{title:"一次 PR 在 CI 里的旅程",children:e.jsxs("p",{children:["你开了一个 PR：① GitHub 检测到 ",e.jsx("code",{children:"pull_request"})," 事件，触发 workflow； ② ",e.jsx("code",{children:"quality"})," job 在干净机器上 ",e.jsx("code",{children:"npm ci"})," 后跑 lint / typecheck / test； ③ 全绿则 ",e.jsx("code",{children:"build"})," job 接力构建并上传 ",e.jsx("code",{children:"dist"})," 制品； ④ 两个 job 都绿，PR 页面显示必需检查通过，「Merge」按钮亮起； ⑤ 若任一步红了，按钮置灰，你修完再推，CI 自动重跑。"]})}),e.jsx("h2",{children:"十一、流水线阶段一览"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"阶段"}),e.jsx("th",{children:"命令 / action"}),e.jsx("th",{children:"拦住什么"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"检出"}),e.jsx("td",{children:e.jsx("code",{children:"actions/checkout"})}),e.jsx("td",{children:"—（取到代码）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"装环境 + 缓存"}),e.jsxs("td",{children:[e.jsx("code",{children:"actions/setup-node"}),"（",e.jsx("code",{children:"cache: npm"}),"）"]}),e.jsx("td",{children:"环境不一致 / 重复下载"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"装依赖"}),e.jsx("td",{children:e.jsx("code",{children:"npm ci"})}),e.jsx("td",{children:"依赖漂移、lock 不一致"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Lint"}),e.jsx("td",{children:e.jsx("code",{children:"npm run lint"})}),e.jsx("td",{children:"风格问题、可疑写法"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"类型检查"}),e.jsx("td",{children:e.jsx("code",{children:"npm run typecheck"})}),e.jsx("td",{children:"类型错误"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"测试"}),e.jsx("td",{children:e.jsx("code",{children:"npm test"})}),e.jsx("td",{children:"逻辑回归"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"构建"}),e.jsx("td",{children:e.jsx("code",{children:"npm run build"})}),e.jsx("td",{children:"构建期错误、产物异常"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"制品"}),e.jsx("td",{children:e.jsx("code",{children:"actions/upload-artifact"})}),e.jsx("td",{children:"—（产出可部署的 dist）"})]})]})]}),e.jsx("h2",{children:"十二、边界与常见坑"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"本地能过、CI 挂了"}),"：八成是环境差异——本地装了全局工具、Node 版本不同、 或 lock 文件没提交。让本地尽量贴近 CI（同版本、用 ",e.jsx("code",{children:"npm ci"}),"）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"CI 太慢"}),"：先上依赖缓存；再把独立检查拆成并行 job； 用 ",e.jsx("code",{children:"concurrency"})," 取消同分支旧运行，别让排队堆积。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"不稳定的测试（flaky test）"}),"：偶尔红偶尔绿会摧毁团队对 CI 的信任， 要么修稳定、要么隔离，绝不能用「重跑一次」糊弄过去。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"把秘密写进 YAML"}),"：任何 token / 密钥都走 secrets， 一旦明文进过仓库历史，等同泄露，必须立即吊销重置。"]})]}),e.jsxs(n,{variant:"tip",children:["下一章我们顺着这条流水线往后走：制品有了，接下来就是",e.jsx("strong",{children:"部署"}),"—— 静态托管平台怎么零运维上线、自托管怎么用 Nginx + Docker、CDN 缓存怎么配， 以及如何把 CI 和部署接成一条自动化的链路。"]}),e.jsx(c,{points:["CI（持续集成）= 每次提交自动验证；持续交付 = 再自动产出可上线制品；持续部署 = 连上线都自动化。","CI 的价值：早发现问题、统一可复现环境、把检查变成不可绕过的质量门禁、解放人工 review。","GitHub Actions 层级：workflow（一个 YAML）→ job（并行、各自独立虚拟机）→ step（顺序执行，run 或 uses）。","一条前端流水线：checkout → setup-node（cache: npm 加速）→ npm ci → lint → typecheck → test → build → upload-artifact。","用并行 job + needs 表达依赖、用 strategy.matrix 一套步骤覆盖多 Node 版本；用 concurrency 取消同分支旧运行。","分支保护把 CI 设为必需检查 = 合并门禁；敏感值走 secrets，用 ${{ secrets.X }} 引用，绝不明文进仓库。"]})]})}export{f as default};
