import{j as e}from"./index-Bkb6eOY7.js";import{L as l,S as o}from"./Summary-Dj-Y5ESD.js";import{K as n}from"./KeyIdea-N6HVLWjp.js";import{C as d}from"./Callout-FpvHzM97.js";import{C as i}from"./CodeBlock-BQqVtp_3.js";import{E as r}from"./Example-iLfTRUEi.js";const c=`// Column：子项从上到下纵向排列
Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(8.dp), // 子项之间留 8dp
    horizontalAlignment = Alignment.CenterHorizontally // 子项水平居中
) {
    Text("第一行")
    Text("第二行")
}

// Row：子项从左到右横向排列
Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween, // 两端对齐、中间均分空白
    verticalAlignment = Alignment.CenterVertically
) {
    Text("左")
    Text("右")
}

// Box：子项相互层叠（类似 FrameLayout），用 align 决定每个子项落在哪
Box(modifier = Modifier.size(120.dp)) {
    Text("左上", modifier = Modifier.align(Alignment.TopStart))
    Text("正中", modifier = Modifier.align(Alignment.Center))
    Text("右下", modifier = Modifier.align(Alignment.BottomEnd))
}`,s=`// weight：按比例瓜分主轴上的剩余空间
Row(modifier = Modifier.fillMaxWidth()) {
    // 1 : 2 : 1 三段，中间那段占一半宽
    Box(Modifier.weight(1f).height(48.dp).background(Color.Red))
    Box(Modifier.weight(2f).height(48.dp).background(Color.Green))
    Box(Modifier.weight(1f).height(48.dp).background(Color.Blue))
}

// fill = false：先按内容量好，再去分剩余空间，自身不被强行撑满
Row {
    Text("标题", modifier = Modifier.weight(1f, fill = false))
    Icon(Icons.Default.Star, contentDescription = null)
}`,t=`// 同样的两个 Modifier，顺序不同，结果完全不同！

// A：先 padding 再 background
//   先内缩出 16dp 空白，再在“内缩后”的区域上色
//   => 边缘留出一圈未上色的空白
Box(
    Modifier
        .padding(16.dp)
        .background(Color.Yellow)
        .size(100.dp)
)

// B：先 background 再 padding
//   先在整块区域上色，再向内留 16dp 空白
//   => 整块都是黄色，padding 变成“色块内部的内边距”
Box(
    Modifier
        .background(Color.Yellow)
        .padding(16.dp)
        .size(100.dp)
)`,h=`Modifier
    .fillMaxWidth()              // 宽度撑满父容器（fillMaxWidth(0.5f) 占一半）
    .padding(horizontal = 16.dp) // 内边距：在尺寸“之内”留白
    .size(width = 200.dp, height = 80.dp) // 固定尺寸
    .clip(RoundedCornerShape(12.dp))      // 裁剪成圆角（影响之后的绘制与点击区域）
    .background(Color(0xFFEEEEEE))        // 背景色 / 背景画刷
    .clickable { onClick() }              // 让任意组件可点击，自带涟漪反馈`,a=`data class Product(val id: Int, val name: String, val price: Int)

@Composable
fun ProductList(products: List<Product>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),        // 列表整体内边距
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 单个固定项：标题
        item {
            Text("热销商品", style = MaterialTheme.typography.titleLarge)
        }
        // 一批数据项：key 让 Compose 在增删/重排时精准复用
        items(products, key = { it.id }) { product ->
            ProductRow(product)
        }
    }
}

@Composable
fun ProductRow(product: Product) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF5F5F5))
            .clickable { /* 打开详情 */ }
            .padding(16.dp),                  // 注意：padding 在 background 之后 => 留白在色块内
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(product.name)
        Text("¥\${product.price}")
    }
}`,x=`// LazyRow：横向可回收列表（横向滑动的卡片条）
LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    items(banners, key = { it.id }) { banner -> BannerCard(banner) }
}

// LazyVerticalGrid：网格，按需渲染
LazyVerticalGrid(
    columns = GridCells.Fixed(2),          // 固定 2 列；也可 GridCells.Adaptive(minSize = 120.dp)
    contentPadding = PaddingValues(12.dp),
    horizontalArrangement = Arrangement.spacedBy(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
) {
    items(products, key = { it.id }) { product -> ProductCard(product) }
}`;function y(){return e.jsxs("article",{children:[e.jsxs(l,{children:["界面是「摆出来的」。在 Jetpack Compose 里，摆放靠两样东西：一是",e.jsx("strong",{children:"布局容器"}),"（Column / Row / Box）决定子项怎么排，二是",e.jsx("strong",{children:"Modifier"}),"（修饰符）决定每个组件的尺寸、内外边距、背景、点击等行为。 这一章我们先讲清三大布局与对齐、排布、weight，再把 Modifier 的链式顺序为何影响结果讲透， 最后用 LazyColumn / LazyRow / LazyVerticalGrid 做出能流畅滑动上万条的「可回收长列表」。"]}),e.jsx("h2",{children:"一、三大基础布局：Column / Row / Box"}),e.jsx("p",{children:"Compose 的布局不靠 XML，而是把容器写成可组合函数，子项写在它的尾随 lambda 里。 最常用的三个容器各管一个方向："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Column"}),"：子项",e.jsx("strong",{children:"纵向"}),"从上到下排列（对标 XML 里的垂直 LinearLayout）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Row"}),"：子项",e.jsx("strong",{children:"横向"}),"从左到右排列（水平 LinearLayout）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Box"}),"：子项",e.jsx("strong",{children:"相互层叠"}),"，后写的盖在先写的上面（对标 FrameLayout），常用来做角标、浮层、居中。"]})]}),e.jsx(i,{lang:"kotlin",title:"Column / Row / Box 三种排法",code:c}),e.jsx("h3",{children:"对齐（Alignment）与排布（Arrangement）别搞混"}),e.jsxs("p",{children:["每个容器都有两个维度需要安排：沿着排列方向（",e.jsx("strong",{children:"主轴"}),"）怎么分布，垂直于排列方向 （",e.jsx("strong",{children:"交叉轴"}),"）怎么对齐。Compose 把它们拆成两个不同参数："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Arrangement（排布）"}),"管",e.jsx("strong",{children:"主轴"}),"：子项之间和两端的空白怎么分。 Column 用 ",e.jsx("code",{children:"verticalArrangement"}),"，Row 用 ",e.jsx("code",{children:"horizontalArrangement"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Alignment（对齐）"}),"管",e.jsx("strong",{children:"交叉轴"}),"：子项在另一方向上靠哪边。 Column 用 ",e.jsx("code",{children:"horizontalAlignment"}),"，Row 用 ",e.jsx("code",{children:"verticalAlignment"}),"。"]})]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"容器"}),e.jsx("th",{children:"主轴（Arrangement）"}),e.jsx("th",{children:"交叉轴（Alignment）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"Column（纵向）"}),e.jsx("td",{children:e.jsx("code",{children:"verticalArrangement"})}),e.jsx("td",{children:e.jsx("code",{children:"horizontalAlignment"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Row（横向）"}),e.jsx("td",{children:e.jsx("code",{children:"horizontalArrangement"})}),e.jsx("td",{children:e.jsx("code",{children:"verticalAlignment"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Box（层叠）"}),e.jsxs("td",{colSpan:2,children:["用子项上的 ",e.jsx("code",{children:"Modifier.align(Alignment.X)"})," 单独定位，或容器的 ",e.jsx("code",{children:"contentAlignment"})," 设默认"]})]})]})]}),e.jsxs("p",{children:["常见的 Arrangement 值：",e.jsx("code",{children:"spacedBy(8.dp)"}),"（子项间固定间隔）、",e.jsx("code",{children:"SpaceBetween"}),"（两端贴边、中间均分）、",e.jsx("code",{children:"SpaceAround"}),"、",e.jsx("code",{children:"SpaceEvenly"}),"、",e.jsx("code",{children:"Center"}),"、",e.jsx("code",{children:"Top"})," / ",e.jsx("code",{children:"Bottom"})," / ",e.jsx("code",{children:"Start"})," / ",e.jsx("code",{children:"End"}),"。"]}),e.jsx("h3",{children:"weight：按比例瓜分剩余空间"}),e.jsxs("p",{children:["想让某个子项「占满剩下的空间」或几个子项「按 1:2:1 分」，用",e.jsx("code",{children:"Modifier.weight(...)"}),"。它只在 Row / Column 内部生效，作用是把主轴上",e.jsx("strong",{children:"固定尺寸子项占完后的剩余空间"}),"按权重分配。这正是对标 XML 里",e.jsx("code",{children:"layout_weight"})," 的能力。"]}),e.jsx(i,{lang:"kotlin",title:"用 weight 做比例布局",code:s}),e.jsx("h2",{children:"二、Modifier 是什么"}),e.jsxs(n,{children:["Modifier 是一条",e.jsx("strong",{children:"有序的修饰链"}),"。你用 ",e.jsx("code",{children:".padding().background().clickable()"}),"把一系列「装饰 / 行为」串起来挂到组件上，Compose ",e.jsx("strong",{children:"按书写顺序从外到内"}),"逐层应用。 因此 Modifier 的顺序不是风格问题，而是",e.jsx("strong",{children:"会改变最终结果"}),"的语义。"]}),e.jsxs("p",{children:["在传统 View 体系里，尺寸、内边距、背景、点击监听是散落在 XML 属性和 Java/Kotlin 调用里的。 Compose 把这些统一收进 Modifier：它是一个不可变对象，每调用一个修饰方法就返回一个",e.jsx("strong",{children:"新的、更长的"}),"修饰链。把它传给组件的 ",e.jsx("code",{children:"modifier"})," 参数，组件在测量、布局、 绘制、处理输入时会依次走过这条链。"]}),e.jsx("h3",{children:"为什么顺序会影响结果"}),e.jsxs("p",{children:["关键在于：链上靠前的修饰符",e.jsx("strong",{children:"先拿到约束、先包住后面的一切"}),"。 以 ",e.jsx("code",{children:"padding"})," 和 ",e.jsx("code",{children:"background"})," 为例——padding 会「内缩」可用区域，background 则给「当前可用区域」上色。谁在前，谁就决定另一个作用在多大的范围上："]}),e.jsx(i,{lang:"kotlin",title:"同样两个修饰符，顺序不同结果不同",code:t}),e.jsxs(r,{title:"一句话记住 padding 与 background 的顺序",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"先 padding 再 background"}),"：留白在色块",e.jsx("strong",{children:"外面"}),"，边缘有一圈透明空白。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"先 background 再 padding"}),"：留白在色块",e.jsx("strong",{children:"里面"}),"，整块都上了色， padding 变成内容到色块边缘的内边距。"]}),e.jsxs("p",{children:["同理，",e.jsx("code",{children:"clickable"})," 放在 ",e.jsx("code",{children:"padding"})," 前后，决定「点击的热区是否包含那圈内边距」—— 想让 padding 也可点，就把 ",e.jsx("code",{children:"clickable"})," 写在 ",e.jsx("code",{children:"padding"})," ",e.jsx("strong",{children:"之前"}),"。"]})]}),e.jsxs(d,{variant:"warn",title:"顺序是 bug 的高发区",children:["排查「为什么点不到 / 背景缺了一块 / 圆角没裁干净」时，第一反应应该是去看 Modifier 链的顺序。",e.jsx("code",{children:"clip"})," 要在 ",e.jsx("code",{children:"background"})," 之前才能把背景也裁圆；想让整行可点又要有内边距， 就把 ",e.jsx("code",{children:"clickable"})," 放在 ",e.jsx("code",{children:"padding"})," 之前。"]}),e.jsx("h3",{children:"常用 Modifier 速查"}),e.jsx(i,{lang:"kotlin",title:"高频 Modifier",code:h}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Modifier"}),e.jsx("th",{children:"作用"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"padding(...)"})}),e.jsx("td",{children:"内边距，在尺寸之内留白；可分边设置"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"size / width / height"})}),e.jsxs("td",{children:["固定尺寸；",e.jsx("code",{children:"fillMaxWidth/Height/Size"})," 撑满父容器"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"fillMaxWidth(fraction)"})}),e.jsxs("td",{children:["按比例占父宽，",e.jsx("code",{children:"fillMaxWidth(0.5f)"})," 占一半"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsxs("code",{children:["clickable ","{}"]})}),e.jsx("td",{children:"让任意组件可点击，自带涟漪反馈"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"background(...)"})}),e.jsx("td",{children:"给当前可用区域填充颜色或画刷"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"clip(shape)"})}),e.jsx("td",{children:"按形状裁剪绘制内容与点击区域"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"weight(...)"})}),e.jsx("td",{children:"仅 Row / Column 内，按比例分主轴剩余空间"})]})]})]}),e.jsx("h3",{children:"约束与自适应：一句话"}),e.jsxs("p",{children:["Compose 布局是",e.jsx("strong",{children:"单遍测量"}),"：父容器把「约束（最小 / 最大宽高）」往下传，子项在约束内量出 自己的尺寸再报上去——所以同一段 UI 能在不同尺寸下自适应，靠的就是这套约束传递，而非写死像素。"]}),e.jsx("h2",{children:"三、长列表：LazyColumn 与按需渲染"}),e.jsxs("p",{children:["如果用普通 ",e.jsx("code",{children:"Column"})," 放 1 万个子项，Compose 会",e.jsx("strong",{children:"一次性全部创建"}),"，内存和性能直接崩。 正确做法是用 ",e.jsx("strong",{children:"Lazy 系列"}),"容器：它们只渲染",e.jsx("strong",{children:"当前屏幕可见（外加少量缓冲）"}),"的项， 滑出去的项被回收复用——这就是对标传统 ",e.jsx("code",{children:"RecyclerView"})," 的「可回收列表」，而且不用写 Adapter / ViewHolder。"]}),e.jsxs(n,{children:["Lazy 容器（LazyColumn / LazyRow / LazyVerticalGrid）",e.jsx("strong",{children:"按需渲染"}),"：只为可见区域构建组件， 滑动时复用。它们的内容不是普通 children，而是一个 ",e.jsx("strong",{children:"DSL 作用域"}),"，你在里面用",e.jsxs("code",{children:["item ","{}"]})," 加单项、用 ",e.jsxs("code",{children:["items(list) ","{}"]})," 批量加一组数据项。"]}),e.jsx(i,{lang:"kotlin",title:"一个商品列表的 LazyColumn",code:a}),e.jsx("h3",{children:"key 为什么重要"}),e.jsxs("p",{children:["给 ",e.jsxs("code",{children:["items(list, key = ","{ it.id }",")"]})," 传一个稳定的 ",e.jsx("strong",{children:"key"}),"，是性能与正确性的关键。 没有 key 时，Compose 默认按",e.jsx("strong",{children:"位置"}),"识别项；一旦列表头部插入 / 删除 / 重排，所有后续项的位置都变了， Compose 会误以为「内容全变了」而大面积重组，还可能让滚动位置和动画错乱。 有了基于数据 id 的 key，Compose 能精确识别「哪个数据项还是同一个」，从而",e.jsx("strong",{children:"精准复用"}),"、 保住滚动位置、让增删动画顺滑。"]}),e.jsxs(d,{variant:"tip",title:"key 选数据的唯一标识",children:["key 应取数据的稳定唯一标识（如 ",e.jsx("code",{children:"id"}),"），",e.jsx("strong",{children:"不要"}),"用列表下标当 key——下标会随增删变化， 等于没给 key。"]}),e.jsx("h3",{children:"LazyRow 与 LazyVerticalGrid"}),e.jsxs("p",{children:["横向滑动的卡片条用 ",e.jsx("strong",{children:"LazyRow"}),"；需要网格（如图库、商品宫格）用",e.jsx("strong",{children:"LazyVerticalGrid"}),"，通过 ",e.jsx("code",{children:"columns"})," 指定列数：",e.jsx("code",{children:"GridCells.Fixed(n)"}),"固定 n 列，",e.jsx("code",{children:"GridCells.Adaptive(minSize)"})," 则按可用宽度自动决定列数（自适应）。 它们的 item / items DSL 与 key 规则和 LazyColumn 完全一致。"]}),e.jsx(i,{lang:"kotlin",title:"LazyRow 与 LazyVerticalGrid",code:x}),e.jsx("h2",{children:"四、对照：Modifier 顺序如何改变同一个列表行"}),e.jsxs(r,{title:"一个列表行的两种修饰顺序",children:[e.jsxs("p",{children:["上面的 ",e.jsx("code",{children:"ProductRow"})," 写的是",e.jsxs("code",{children:["clip(...).background(...).clickable ","{}",".padding(16.dp)"]}),"："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"clip"})," 在最前 => 圆角能裁住背景，色块四角是圆的。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"clickable"})," 在 ",e.jsx("code",{children:"padding"})," 前 => 整块（含将要内缩的区域）都可点。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"padding"})," 在最后 => 16dp 留白在色块",e.jsx("strong",{children:"内部"}),"，文字不贴边。"]})]}),e.jsxs("p",{children:["若错写成 ",e.jsx("code",{children:"padding(16.dp).clip(...).background(...)"}),"，则色块会",e.jsx("strong",{children:"缩小一圈"}),"（padding 先把区域内缩），行与行之间凭空多出空白，点击热区也变小——这正是顺序带来的实质差异。"]})]}),e.jsx(d,{variant:"tip",children:"下一章我们给这些列表与卡片「穿上统一的衣服」：用 Material 3 的 ColorScheme / Typography / Shape 定义主题，再用 animate*AsState、AnimatedVisibility 让状态变化与进出场动起来。"}),e.jsx(o,{points:["三大布局：Column 纵排、Row 横排、Box 层叠；Box 子项用 Modifier.align 定位。","Arrangement 管主轴间距分布，Alignment 管交叉轴对齐，二者分属不同方向不要混淆。","weight 仅在 Row / Column 内生效，按比例瓜分主轴剩余空间，对标 XML 的 layout_weight。","Modifier 是有序修饰链，按书写顺序从外到内应用；padding 与 background 的先后会改变留白在色块内还是外。","常用 Modifier：padding / size / fillMaxWidth / clickable / background / clip；clip 要在 background 前才能裁住背景。","LazyColumn / LazyRow / LazyVerticalGrid 按需渲染、可回收，对标 RecyclerView；用 item / items 加项，并以数据 id 作 key 实现精准复用。"]})]})}export{y as default};
