import{j as e}from"./index-I8-WI4LI.js";import{L as t,S as i}from"./Summary-BMIdTn04.js";import{K as n}from"./KeyIdea-Xbvwo63C.js";import{C as r}from"./Callout-ZgrsOCpc.js";import{C as s}from"./CodeBlock-CK6ncc4Q.js";import{E as d}from"./Example-CPIFvVrE.js";const c=`import { writeFile, mkdir } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import type { Tool } from './types.js'

// write：把内容写入文件（覆盖写），需要的父目录会自动创建。这是会改状态的写工具。
export const writeTool: Tool = {
  name: 'write',
  description:
    '把内容写入文件（整文件覆盖写）。父目录不存在会自动创建。用于新建文件或整体替换。改动已有文件的局部请优先用 edit。',
  readOnly: false,
  inputSchema: {
    type: 'object',
    properties: {
      path: { type: 'string', description: '目标文件路径。' },
      content: { type: 'string', description: '要写入的完整内容。' },
    },
    required: ['path', 'content'],
  },
  async execute(input, ctx) {
    const path = String(input.path)
    const content = String(input.content ?? '')
    const abs = resolve(ctx.cwd, path)
    try {
      await mkdir(dirname(abs), { recursive: true })
      await writeFile(abs, content, 'utf8')
      return { output: \`已写入 \${path}（\${content.length} 字符）\` }
    } catch (err) {
      return { output: \`写入失败：\${(err as Error).message}\`, isError: true }
    }
  },
}`,l=`import { readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import type { Tool } from './types.js'

// edit：精确字符串替换。要求 oldString 在文件中唯一，避免误改——这是写工具里最常用的一个。
export const editTool: Tool = {
  name: 'edit',
  description:
    '对已有文件做精确替换：把 oldString 替换成 newString。oldString 必须在文件中唯一出现（否则报错），所以请带上足够的上下文行。用于局部修改代码。',
  readOnly: false,
  inputSchema: {
    type: 'object',
    properties: {
      path: { type: 'string', description: '要修改的文件路径。' },
      oldString: { type: 'string', description: '要被替换的原文（需唯一）。' },
      newString: { type: 'string', description: '替换后的新文本。' },
    },
    required: ['path', 'oldString', 'newString'],
  },
  async execute(input, ctx) {
    const path = String(input.path)
    const oldString = String(input.oldString)
    const newString = String(input.newString)
    const abs = resolve(ctx.cwd, path)
    try {
      const text = await readFile(abs, 'utf8')
      if (oldString === newString) {
        return { output: 'oldString 与 newString 相同，无需修改。', isError: true }
      }
      const first = text.indexOf(oldString)
      if (first === -1) {
        return { output: '未找到 oldString，文件未改动。请确认原文（含缩进/空白）完全一致。', isError: true }
      }
      if (text.indexOf(oldString, first + 1) !== -1) {
        return { output: 'oldString 在文件中出现多次，无法确定改哪一处。请加入更多上下文使其唯一。', isError: true }
      }
      const next = text.slice(0, first) + newString + text.slice(first + oldString.length)
      await writeFile(abs, next, 'utf8')
      return { output: \`已修改 \${path}\` }
    } catch (err) {
      return { output: \`修改失败：\${(err as Error).message}\`, isError: true }
    }
  },
}`,o=`import { exec } from 'node:child_process'
import { promisify } from 'node:util'
import type { Tool } from './types.js'

const execAsync = promisify(exec)

// bash：执行一条 shell 命令，把 stdout/stderr 收回来。这是最强大也最危险的写工具。
// 后续「安全与人在回路」卷会在它前面加权限闸门；这里先把执行能力做出来。
export const bashTool: Tool = {
  name: 'bash',
  description:
    '在工作目录下执行一条 shell 命令，返回合并后的标准输出与错误输出。用于运行测试、构建、git 等。命令有 60 秒超时。',
  readOnly: false,
  inputSchema: {
    type: 'object',
    properties: {
      command: { type: 'string', description: '要执行的 shell 命令。' },
    },
    required: ['command'],
  },
  async execute(input, ctx) {
    const command = String(input.command)
    try {
      const { stdout, stderr } = await execAsync(command, {
        cwd: ctx.cwd,
        timeout: 60_000,
        maxBuffer: 1024 * 1024,
      })
      const out = (stdout + stderr).trim()
      return { output: out || '(命令执行完毕，无输出)' }
    } catch (err) {
      // 非零退出码会走到这里：把输出和退出信息一并如实回灌，让模型据此纠错。
      const e = err as { stdout?: string; stderr?: string; message: string }
      const out = ((e.stdout ?? '') + (e.stderr ?? '')).trim()
      return { output: \`\${out}\\n[命令失败] \${e.message}\`.trim(), isError: true }
    }
  },
}`,h=`// 直接 writeFile 不是原子的：写到一半进程被杀，文件就「半写」了——
// 内容截断、甚至损坏。原子写的标准套路是「先写临时文件，再 rename 覆盖」。

import { writeFile, rename } from 'node:fs/promises'

async function atomicWrite(abs: string, content: string) {
  const tmp = abs + '.tmp-' + process.pid + '-' + Date.now()
  await writeFile(tmp, content, 'utf8')
  // rename 在同一文件系统内是原子操作：要么旧文件、要么新文件，
  // 永远不会出现「半个文件」的中间态。
  await rename(tmp, abs)
}

// forge 本卷的 write 用的是朴素 writeFile（够清楚），
// 但你要知道生产级写工具为什么常常多这一步。`,x=`// edit 的「唯一性约束」之外，业界还有几种定位被改位置的方案，各有取舍：

// 方案 A（forge 采用）：唯一字符串匹配
//   优点：简单、无需行号、对模型友好（带上下文即可）
//   缺点：oldString 必须逐字符精确（含空白），模型偶尔会因空格对不上而失败

// 方案 B：按行号替换  edit(path, startLine, endLine, newText)
//   优点：定位明确
//   缺点：文件一改行号全乱，模型基于旧行号的后续编辑会错位；对空白不敏感反而易误伤

// 方案 C：unified diff（像 git patch）
//   优点：能一次表达多处改动、信息最紧凑
//   缺点：模型生成的 diff 上下文行经常对不上，应用失败率高，还得写 patch 解析器

// 结论：A 在「实现复杂度 / 模型成功率 / 误伤风险」三者间最平衡，所以最流行。`;function f(){return e.jsxs(e.Fragment,{children:[e.jsx(t,{children:e.jsxs("p",{children:["到上一章为止，forge 还是个「只会看、不会动」的旁观者：它能 ",e.jsx("code",{children:"read"}),"、能 ",e.jsx("code",{children:"grep"}),"、能",e.jsx("code",{children:"ls"}),"，把你的项目摸得门儿清，但一个字节都改不了。这一章，我们给它装上一双",e.jsx("strong",{children:"手"}),"—— 三个 ",e.jsx("code",{children:"readOnly: false"})," 的写工具：",e.jsx("code",{children:"write"})," 整文件覆盖、",e.jsx("code",{children:"edit"})," 精确替换、",e.jsx("code",{children:"bash"})," 执行命令。从这三个工具落地的这一刻起，forge 才真正算「能干活」：它能新建文件、能改你的代码、 能跑测试看自己改得对不对。这是从「玩具」迈向「生产级」的关键一步，也是最该小心的一步。"]})}),e.jsx("h2",{children:"写工具：会改变世界状态的那一类"}),e.jsxs("p",{children:["回忆上一章那个 ",e.jsx("code",{children:"readOnly"})," 标志。读工具（read/ls/grep）有一个共同的安全特性： 无论调多少次、并发调、顺序乱了，结果都一样，世界纹丝不动——这叫",e.jsx("strong",{children:"幂等、无副作用"}),"。 写工具恰恰相反：它们会",e.jsx("strong",{children:"改变磁盘上的真实状态"}),"。写一次文件，文件就变了； 跑一次 ",e.jsx("code",{children:"rm"}),"，东西就没了。这个差别不是哲学，它直接决定了三件工程上的事："]}),e.jsxs("ol",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"必须串行执行。"}),"两个写操作如果并发，谁先谁后、会不会互相覆盖都说不准。 上一章 ",e.jsx("code",{children:"runTools"})," 已经埋了伏笔——只读并行、写串行。下一章讲调度时会把这件事抠到底。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"是「权限与人在回路」要重点设防的对象。"}),"读错了顶多浪费一次调用； 写错了可能删库、可能 ",e.jsx("code",{children:"git push --force"}),"。卷 3 会专门在写工具前面架一道权限闸门。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"本章只管「能力」，不管「安全」。"}),"我们先把执行能力老老实实做出来、跑通闭环， 安全闸门是后面单独的一整卷。先有手，再谈给手戴上手套。"]})]}),e.jsx(n,{title:"写工具 = 能力，安全闸门 = 后置",children:e.jsxs("p",{children:["一个清醒的认知：",e.jsx("strong",{children:"能力和安全是两件事，要分两步做。"}),"本章造出来的三个写工具，是「裸」的—— 它们能毫无阻拦地覆盖任何文件、执行任何命令。这",e.jsx("strong",{children:"不是"}),"疏忽，而是刻意的分层： 先让 Agent 具备「改变世界」的执行能力（本章），再在卷 3 给这份能力套上「权限确认 / 人在回路」的缰绳。 颠倒过来——还没有能力就先纠结安全——只会让你寸步难行。所以本章请放心大胆地把手做出来， 但心里记牢：现在这双手",e.jsx("strong",{children:"没有闸门"}),"，只该在你不怕弄坏的测试目录里挥舞。"]})}),e.jsx("h2",{children:"write：整文件覆盖写"}),e.jsxs("p",{children:["最简单的写工具：给一个路径和一段内容，把内容",e.jsx("strong",{children:"整个"}),"写进去（已有内容直接覆盖）。 下面是 forge 仓库里 ",e.jsx("code",{children:"src/tools/write.ts"})," 的逐字内容。"]}),e.jsx(s,{lang:"ts",title:"src/tools/write.ts",code:c}),e.jsx("p",{children:"实现上有两个点值得说："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"覆盖写。"}),e.jsx("code",{children:"writeFile"})," 默认就是覆盖——文件存在就整个替换，不存在就新建。 它不做任何「合并」「追加」，给什么就是什么。这也意味着：如果你只想改文件里的一行，用 write 就得把",e.jsx("strong",{children:"整份内容"}),"重新生成一遍，既浪费 token 又容易把别处改坏。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"自动建父目录。"}),"写 ",e.jsx("code",{children:"src/a/b/c.ts"})," 时，如果 ",e.jsx("code",{children:"src/a/b"})," 还不存在， 直接 ",e.jsx("code",{children:"writeFile"})," 会报 ",e.jsx("code",{children:"ENOENT"}),"。所以我们先 ",e.jsx("code",{children:"mkdir(dirname(abs), { recursive: true })"}),"把整条父目录链建出来（",e.jsx("code",{children:"recursive"})," 让它逐级创建、且目录已存在也不报错），再写。 这样模型新建一个深层目录里的文件时，不必先手动 ",e.jsx("code",{children:"mkdir"}),"。"]})]}),e.jsxs("p",{children:[e.jsx("strong",{children:"什么时候用 write，什么时候用 edit？"}),"记一句话：",e.jsx("strong",{children:"新建文件、或整体替换"}),"用 write；",e.jsx("strong",{children:"改已有文件的一小块"}),"用 edit。 前者一锤子；后者外科手术。下面就是那把手术刀。"]}),e.jsxs(r,{variant:"note",title:"覆盖写不是原子的——生产级 write 多一步「临时文件 + rename」",children:[e.jsxs("p",{children:[e.jsx("code",{children:"writeFile"})," 把内容写进文件这件事，看着是「一下子」，其实在底层是分多次系统调用完成的。 如果进程在写到一半时被杀（崩溃、断电、被 ",e.jsx("code",{children:"kill"}),"），文件就会停在",e.jsx("strong",{children:"「半写」"}),"状态—— 内容被截断、甚至结构损坏。对源码文件这是灾难。生产级写工具因此常用",e.jsx("strong",{children:"原子写"}),"套路： 先把完整内容写进一个临时文件，再用 ",e.jsx("code",{children:"rename"})," 把临时文件「改名」成目标文件。 同一文件系统内的 ",e.jsx("code",{children:"rename"})," 是",e.jsx("strong",{children:"原子"}),"的——任一时刻，目标路径要么是完整的旧文件、要么是完整的新文件，绝不会是半个。"]}),e.jsx(s,{lang:"ts",title:"原子写：先写临时文件，再 rename 覆盖",code:h}),e.jsxs("p",{children:["forge 本卷的 write 用朴素的 ",e.jsx("code",{children:"writeFile"}),"（为了把主干讲清楚），但你要知道为什么真实工具往往多这一步。"]})]}),e.jsx("h2",{children:"edit：精确字符串替换"}),e.jsxs("p",{children:[e.jsx("code",{children:"edit"})," 是写工具里",e.jsx("strong",{children:"最常用、也最讲究"}),"的一个。绝大多数「改代码」的动作—— 改一个函数名、调一个参数、补一行 import——都不该重写整个文件，而是精确地把",e.jsx("strong",{children:"一小段旧文本换成新文本"}),"。 下面是 ",e.jsx("code",{children:"src/tools/edit.ts"})," 的逐字内容。"]}),e.jsx(s,{lang:"ts",title:"src/tools/edit.ts",code:l}),e.jsxs("p",{children:["它的核心就一件事：在文件里找到 ",e.jsx("code",{children:"oldString"}),"，把它换成 ",e.jsx("code",{children:"newString"}),"。但魔鬼在三道校验里："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"防呆：oldString === newString。"}),"如果新旧文本一模一样，这次替换毫无意义—— 多半是模型搞错了。直接报错返回，别让它误以为「改成功了」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"找不到就报错。"}),e.jsx("code",{children:"indexOf"})," 返回 ",e.jsx("code",{children:"-1"})," 说明文件里压根没有这段原文。 常见原因是缩进、空白、引号没对齐。这时",e.jsx("strong",{children:"绝不"}),"瞎改，原样退回并提示「请确认原文完全一致」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"出现多次也报错（唯一性约束）。"}),"这是 edit 最关键的设计。 从第一次命中的位置 ",e.jsx("code",{children:"+1"})," 处再 ",e.jsx("code",{children:"indexOf"})," 一次，如果还能找到，说明 ",e.jsx("code",{children:"oldString"}),"在文件里",e.jsx("strong",{children:"不止一处"}),"——那到底改哪一个？无法确定，于是拒绝执行，要求模型「加入更多上下文使其唯一」。"]})]}),e.jsxs("p",{children:["三道关全过了，才用 ",e.jsx("code",{children:"slice + slice"})," 拼出替换后的全文，写回磁盘。 注意拼接用的是",e.jsx("strong",{children:"字符串切片"}),"而非 ",e.jsx("code",{children:"replace"}),"：因为我们已经精确锁定了唯一的那个位置， 切片只动那一处，干净利落、没有「不小心 replace 多个」的风险。"]}),e.jsx(r,{variant:"tip",title:"为什么「唯一性约束」是精确编辑的灵魂",children:e.jsxs("p",{children:["表面看，「oldString 必须唯一」像是个吹毛求疵的限制；实际上，它是逼模型「带足上下文」的精妙杠杆。 假设文件里有三行 ",e.jsx("code",{children:"count++"}),"，模型只发来 ",e.jsx("code",{children:'oldString: "count++"'}),"——该改哪一行？无解。 唯一性约束把这种",e.jsx("strong",{children:"歧义"}),"直接判为错误，于是模型被迫多带几行上下文， 比如连同上一行 ",e.jsx("code",{children:"if (found)"})," 一起发来，使这段原文在全文中独一无二。这样改动才是",e.jsx("strong",{children:"确定的"}),"， 不会误伤另外两处。这恰好",e.jsx("strong",{children:"呼应上一章 read 给每行加行号"}),"的设计：read 让模型读到的内容自带定位信息， edit 让模型用这些上下文构造出唯一的 oldString——一读一写两个工具，在「精确」这件事上严丝合缝地配合。"]})}),e.jsx("h3",{children:"唯一性约束是「一种取舍」，不是唯一解"}),e.jsxs("p",{children:["把唯一性约束讲成「灵魂」之后，得补一句公道话：它不是定位被改位置的",e.jsx("strong",{children:"唯一"}),"方案，而是几种方案里",e.jsx("strong",{children:"取舍最划算"}),"的那个。 了解它的替代品，你才能理解 forge 为什么这么选，也才知道它的",e.jsx("strong",{children:"代价"}),"在哪："]}),e.jsx(s,{lang:"ts",title:"定位被改位置的三种方案对比",code:x}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方案"}),e.jsx("th",{children:"对模型的难度"}),e.jsx("th",{children:"误伤风险"}),e.jsx("th",{children:"主要代价"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"唯一字符串（forge）"}),e.jsx("td",{children:"低（带上下文即可）"}),e.jsx("td",{children:"低（唯一才改）"}),e.jsx("td",{children:"oldString 须逐字符精确，空白对不上就失败"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"行号替换"}),e.jsx("td",{children:"中"}),e.jsx("td",{children:"高（行号易错位）"}),e.jsx("td",{children:"文件一改行号全乱，后续编辑连锁出错"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"unified diff"}),e.jsx("td",{children:"高（要生成合法 patch）"}),e.jsx("td",{children:"中"}),e.jsx("td",{children:"上下文对不上时应用失败率高，需 patch 解析器"})]})]})]}),e.jsxs("p",{children:["唯一性方案",e.jsx("strong",{children:"自己也有代价"}),"：模型必须把 ",e.jsx("code",{children:"oldString"})," 一个字符不差地复刻出来（包括缩进、空格、引号）， 稍有偏差就 ",e.jsx("code",{children:"indexOf"})," 返回 -1、改不动。这就是为什么实践中 edit 偶尔会「找不到原文」而需要重试—— 它把「歧义」这个更危险的问题，换成了「精确度」这个更可控的问题。在「实现复杂度 / 模型成功率 / 误伤风险」三角里， 它是当下最平衡的一点，所以成了主流 Agent 的标配。"]}),e.jsx(r,{variant:"tip",title:"再看那句 oldString === newString 的防呆",children:e.jsxs("p",{children:["代码里「新旧文本相同就报错」看着多余，其实拦的是一类真实的模型失误：模型有时会「以为自己改了」， 但发来的 newString 和 oldString 一模一样（脑补了一次本不存在的改动）。若不拦，edit 会返回「已修改」， 模型于是",e.jsx("strong",{children:"误以为任务推进了"}),"、接着往下走——而文件其实纹丝没动。把这种「空改动」显式判为错误， 是在帮模型",e.jsx("strong",{children:"对齐它的认知和现实"}),"，免得它基于一个假的「已完成」继续推理。"]})}),e.jsx("h2",{children:"bash：执行一条 shell 命令"}),e.jsxs("p",{children:["最后一个，也是",e.jsx("strong",{children:"最强大、最危险"}),"的写工具。",e.jsx("code",{children:"bash"})," 让 Agent 能跑任意 shell 命令—— 运行测试、执行构建、调 git、装依赖……有了它，forge 才能",e.jsx("strong",{children:"自己验证"}),"刚才改得对不对。 下面是 ",e.jsx("code",{children:"src/tools/bash.ts"})," 的逐字内容。"]}),e.jsx(s,{lang:"ts",title:"src/tools/bash.ts",code:o}),e.jsx("p",{children:"几个实现要点："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"promisify(exec)。"}),"Node 的 ",e.jsx("code",{children:"exec"})," 是回调式的， 用 ",e.jsx("code",{children:"promisify"})," 包成 Promise 才能 ",e.jsx("code",{children:"await"}),"。它会起一个 shell 来跑整条命令字符串 （所以管道、重定向、",e.jsx("code",{children:"&&"})," 都能用）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"cwd / timeout / maxBuffer 三个护栏。"}),e.jsx("code",{children:"cwd"})," 指定在哪个目录执行（来自",e.jsx("code",{children:"ToolContext"}),"，跟其他工具同源）；",e.jsx("code",{children:"timeout: 60_000"})," 给命令 60 秒上限， 防止某条命令卡死把整个 Agent 拖住；",e.jsx("code",{children:"maxBuffer"})," 限制收集的输出大小，避免一条狂吐日志的命令把内存撑爆。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"合并 stdout + stderr 回灌。"}),"模型既要看正常输出，也要看错误信息（测试失败的报错往往在 stderr）。 所以我们把两者拼到一起 ",e.jsx("code",{children:"trim"})," 后整个回传，不做区分。空输出时给一句「无输出」，免得模型对着空字符串犯迷糊。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"非零退出码会抛异常——而 catch 里要如实回灌。"}),"这是最容易踩坑的一点： 命令以非零码退出（比如测试没过、编译报错）时，",e.jsx("code",{children:"execAsync"})," 不是正常返回，而是",e.jsx("strong",{children:"抛异常"}),"。 但「测试失败」恰恰是模型",e.jsx("strong",{children:"最需要知道"}),"的信息！所以 catch 块里我们从异常对象上把",e.jsx("code",{children:"stdout/stderr"})," 抠出来、连同 ",e.jsx("code",{children:"message"})," 一起拼好回传，并标 ",e.jsx("code",{children:"isError: true"}),"。 模型拿到这段真实的失败输出，才能据此判断下一步怎么改。"]})]}),e.jsxs("p",{children:["这呼应了上一章反复强调的原则：",e.jsx("strong",{children:"出错也要如实回传，让模型自己纠错"}),"。 bash 把这条原则用到了极致——它把命令的失败现场原封不动地端给模型，模型据此调整、再试，形成闭环。"]}),e.jsx(r,{variant:"warn",title:"现在的 bash 是「无闸门」的——它能跑 rm -rf",children:e.jsxs("p",{children:["盯着这段代码想清楚一件事：它对命令",e.jsx("strong",{children:"不做任何检查"}),"。模型发来什么就执行什么。 这意味着如果模型（被诱导、或单纯犯傻）发来 ",e.jsx("code",{children:"rm -rf /"}),"、",e.jsx("code",{children:"git push --force"}),"、",e.jsx("code",{children:"curl 某脚本 | sh"}),"，forge 会",e.jsx("strong",{children:"毫不犹豫地照办"}),"。现在这双手没有任何保险。 所以本章及之后、卷 3 加上权限确认",e.jsx("strong",{children:"之前"}),"，请只在",e.jsx("strong",{children:"你不怕弄坏的测试目录"}),"里玩 bash—— 别在你的真项目、更别在带着重要文件的目录里直接放它跑。 卷 3 会给写工具（尤其 bash）加上「人在回路」的确认闸门：危险命令执行前先问你一声。 但那是后话；现在，你的责任是把它关在沙盒里。"]})}),e.jsx("h3",{children:"bash 为什么是「风险等级独一档」的工具"}),e.jsxs("p",{children:["write 和 edit 危险，但它们的危险",e.jsx("strong",{children:"有边界"}),"：write 最多改一个文件、edit 最多动一处文本， 都局限在「文件系统、工作目录内」。bash 不一样——它把",e.jsx("strong",{children:"整台机器的能力"}),"一股脑交给了模型。 同一个工具，可以装依赖、跑测试，也可以删库、发网络请求、改系统配置、把数据偷传出去。 三个维度的失控都集中在它身上："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"风险维度"}),e.jsx("th",{children:"具体表现"}),e.jsx("th",{children:"forge 当前的护栏"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"破坏性"}),e.jsxs("td",{children:[e.jsx("code",{children:"rm -rf"}),"、",e.jsx("code",{children:"git push --force"}),"、覆盖配置"]}),e.jsx("td",{children:"无（卷 3 才加确认闸门）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"资源耗尽"}),e.jsx("td",{children:"死循环、狂吐日志、占满磁盘"}),e.jsx("td",{children:"timeout 60s + maxBuffer 1MB"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"越权 / 外泄"}),e.jsxs("td",{children:[e.jsx("code",{children:"curl 脚本 | sh"}),"、读密钥外传"]}),e.jsx("td",{children:"无（依赖沙盒目录隔离）"})]})]})]}),e.jsxs("p",{children:["看清楚：",e.jsx("code",{children:"timeout"})," 和 ",e.jsx("code",{children:"maxBuffer"})," 挡住的只是「",e.jsx("strong",{children:"资源耗尽"}),"」这一类——防止一条命令卡死或撑爆内存把 Agent 拖垮。 但对「破坏性」和「越权外泄」，当前的 bash ",e.jsx("strong",{children:"毫无防御"}),"。这不是疏忽，是分层：能力先做出来，缰绳卷 3 再套。"]}),e.jsx(r,{variant:"warn",title:"一个反直觉但重要的点：别在 bash 里做「命令黑名单」",children:e.jsxs("p",{children:["很多人加固 bash 的第一反应是「拦掉危险命令」——禁 ",e.jsx("code",{children:"rm"}),"、禁 ",e.jsx("code",{children:"curl"}),"。这条路",e.jsx("strong",{children:"基本走不通"}),"， 因为 shell 的表达能力让黑名单形同虚设：",e.jsx("code",{children:"rm"})," 可以写成 ",e.jsx("code",{children:"r''m"}),"、",e.jsx("code",{children:"$(echo rm)"}),"、",e.jsx("code",{children:"eval $(...)"}),"、藏在一个脚本文件里再执行……你永远列不全。真正可靠的不是「过滤字符串」，而是",e.jsx("strong",{children:"收紧执行环境本身"}),"： 在受限权限下跑（不给删关键目录的权限）、在容器/沙盒里跑、或者卷 3 那样",e.jsx("strong",{children:"由人确认每一条"}),"命令再放行。 「与其猜命令安不安全，不如让它跑在一个就算危险也伤不到你的环境里」——这是处理 bash 这类工具的正解。"]})}),e.jsxs(d,{title:"一次真实的改码闭环",children:[e.jsxs("p",{children:["三个写工具单看平平无奇，但拼到一起、再配上上一章的读工具，就能跑出 Agent 最迷人的能力：",e.jsx("strong",{children:"自己改、自己验、自己纠"}),"。设想你对 forge 说「把工具超时从 60 秒改成 30 秒」，它可能这样走："]}),e.jsxs("ol",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"grep 定位。"}),"先 ",e.jsx("code",{children:"grep"})," 搜 ",e.jsx("code",{children:"timeout"}),"，发现命中在 ",e.jsx("code",{children:"src/tools/bash.ts"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"read 读上下文。"}),e.jsx("code",{children:"read"})," 那个文件，借着行号看清 ",e.jsx("code",{children:"timeout: 60_000"})," 周围的代码， 好构造一段",e.jsx("strong",{children:"唯一"}),"的 oldString。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"edit 精确替换。"}),"带上足够上下文，把 ",e.jsx("code",{children:"timeout: 60_000"})," 换成 ",e.jsx("code",{children:"timeout: 30_000"}),"。 唯一性约束保证只改这一处。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"bash 跑测试。"}),"执行 ",e.jsx("code",{children:"npm test"}),"，看改动有没有破坏什么。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"失败就看输出再 edit。"}),"假如某个测试断言写的是 60_000，现在挂了—— bash 把失败的报错原样回灌，模型一看「哦还有个测试要同步改」，再 ",e.jsx("code",{children:"edit"})," 那个测试文件。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"再 bash，直到通过。"}),"重新 ",e.jsx("code",{children:"npm test"}),"，绿了，模型才汇报「改完且测试通过」。"]})]}),e.jsxs("p",{children:["关键在于第 5、6 步那个",e.jsx("strong",{children:"回环"}),"：没有写工具，Agent 只能「猜一个改法然后祈祷」； 有了 write/edit + bash，它能",e.jsx("strong",{children:"动手改、再亲眼验证、错了再改"}),"，把「闭环验证」变成现实。 这正是「能干活的 Agent」和「会聊天的机器人」之间那道分水岭。"]})]}),e.jsx(i,{points:["本章给 forge 装上三个 readOnly:false 的写工具——write / edit / bash——它从此能真正改动你的项目，迈出从玩具到生产级的关键一步。","写工具会改变磁盘真实状态（非幂等、有副作用），所以必须串行执行（下一章细讲调度），也是卷 3「权限与人在回路」要重点设防的对象。","能力与安全分两步：本章只做执行能力，安全闸门后置到卷 3——现在这双手是「裸」的，只该在测试目录里玩。","write 是整文件覆盖写，用 mkdir recursive 自动建父目录；适合新建或整体替换，改局部应优先用 edit。","edit 做精确字符串替换，核心是「唯一性约束」：oldString 找不到报错、出现多次也报错，逼模型带足上下文、避免误改；另有 oldString===newString 的防呆。","唯一性约束呼应上一章 read 给每行加行号——read 让模型读到带定位的上下文，edit 让它据此构造唯一的 oldString，一读一写在「精确」上严丝合缝。","bash 用 promisify(exec) 跑命令，配 cwd/timeout/maxBuffer 三道护栏，合并 stdout+stderr 回灌；非零退出码会抛异常，故 catch 里也要把输出与失败信息如实回灌让模型纠错。","bash 现在无闸门、能跑 rm -rf——卷 3 才加权限确认，当下务必只在不怕弄坏的沙盒目录里使用。","write/edit/bash 配上读工具，造就「grep 定位 → read 读上下文 → edit 替换 → bash 验证 → 失败再改」的闭环验证，这是能干活的 Agent 的分水岭。"]})]})}export{f as default};
