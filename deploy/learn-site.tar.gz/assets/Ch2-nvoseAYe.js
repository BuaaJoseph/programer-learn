import{r as j,j as e}from"./index-C4u1Qi4f.js";import{L as p,C as l,a as P,P as B,S as m}from"./Summary-DjSaQefZ.js";import{K as u}from"./KeyIdea-BS4xPn0s.js";import{E as g}from"./Example-DNWIRw6O.js";import{F as f}from"./Figure-D2qsSgWq.js";const r=[{name:"实例化",desc:"通过构造器/工厂反射创建 Bean 的原始对象(此时属性还是空的)。"},{name:"属性填充",desc:"依赖注入：把 @Autowired/配置的依赖设置进去(populateBean)。"},{name:"Aware 回调",desc:"若实现了 BeanNameAware/ApplicationContextAware 等，回调注入容器相关资源。"},{name:"初始化前",desc:"BeanPostProcessor.postProcessBeforeInitialization；@PostConstruct 也在这附近执行。"},{name:"初始化",desc:"执行 InitializingBean.afterPropertiesSet 与自定义 init-method。"},{name:"初始化后",desc:"postProcessAfterInitialization——AOP 代理就在这一步把目标对象包成代理对象返回！"},{name:"使用",desc:"Bean 就绪，被注入到别处、对外提供服务。"},{name:"销毁",desc:"容器关闭时执行 @PreDestroy / DisposableBean.destroy / destroy-method。"}];function S(){const[t,d]=j.useState(0),o=r[t],h=e.jsxs(e.Fragment,{children:[e.jsx("button",{className:"fig-btn",onClick:()=>d(i=>Math.min(i+1,r.length-1)),children:"下一步 ▸"}),e.jsx("button",{className:"fig-btn",onClick:()=>d(0),children:"重来"}),e.jsx("span",{className:"fig-note",children:`第 ${t+1}/${r.length} 步 · ${o.name}`})]});return e.jsx(f,{caption:"一个 Bean 从无到有要经历这几步。两个高频考点：① AOP 代理是在「初始化后(postProcessAfterInitialization)」织入的；② BeanPostProcessor 是 Spring 扩展的核心钩子。",controls:h,children:e.jsxs("svg",{viewBox:"0 0 460 200",width:"460",role:"img","aria-label":"Bean 生命周期",children:[r.map((i,n)=>{const s=n===t,x=n<t,c=16+n%4*110,a=30+Math.floor(n/4)*46;return e.jsxs("g",{children:[e.jsx("rect",{x:c,y:a,width:"98",height:"36",rx:"8",fill:s?"var(--accent)":x?"var(--accent-soft)":"var(--bg-subtle)",stroke:s?"var(--accent-strong)":"var(--border-strong)",strokeWidth:s?2:1}),e.jsxs("text",{x:c+49,y:a+16,textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"11",fontWeight:"700",fill:s?"#ffffff":"var(--ink)",children:[n+1,". ",i.name]}),e.jsx("text",{x:c+49,y:a+29,textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"7",fill:s?"#ffffff":"var(--ink-faint)",children:n===5?"AOP 在此":""})]},n)}),e.jsx("rect",{x:"16",y:"128",width:"432",height:"58",rx:"8",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsx("foreignObject",{x:"24",y:"132",width:"416",height:"52",children:e.jsxs("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"12px var(--sans)",color:"var(--ink)",lineHeight:1.4},children:[e.jsxs("strong",{style:{color:"var(--accent-strong)"},children:[o.name,"："]}),o.desc]})})]})})}const A=`@Component
public class CacheLoader {

    @Autowired
    private DataSource dataSource;

    public CacheLoader() {
        // 此刻 dataSource 还是 null！构造器执行时依赖尚未注入
        System.out.println("构造器：dataSource = " + dataSource);
    }

    @PostConstruct
    public void init() {
        // 到这里属性已经填充完成，dataSource 可以放心使用
        System.out.println("初始化：dataSource = " + dataSource);
    }
}`,v=`// 同时实现两个初始化入口，观察执行顺序
@Component
public class OrderService implements InitializingBean {

    @PostConstruct                       // 1. 最先执行
    public void postConstruct() {
        System.out.println("1 @PostConstruct");
    }

    @Override                            // 2. 其次执行
    public void afterPropertiesSet() {
        System.out.println("2 InitializingBean.afterPropertiesSet");
    }
}

// 配合自定义 init-method（3 最后执行）：
@Bean(initMethod = "myInit")
public OrderService orderService() {
    return new OrderService();
}`,y=`@Component
public class TimingBeanPostProcessor implements BeanPostProcessor {

    @Override   // 初始化方法执行之前回调（每个 Bean 都会经过）
    public Object postProcessBeforeInitialization(Object bean, String name) {
        System.out.println("BPP 前置：" + name);
        return bean;
    }

    @Override   // 初始化方法执行之后回调，AOP 代理正是在这里织入
    public Object postProcessAfterInitialization(Object bean, String name) {
        System.out.println("BPP 后置：" + name);
        return bean;   // 这里可以返回一个代理对象替换原始 Bean
    }
}`;function z(){return e.jsxs(e.Fragment,{children:[e.jsx(p,{children:e.jsx("p",{children:"一个 Bean 从「一团内存」到「能干活的对象」，中间要走一条固定的流水线： 先被造出来，再被填上依赖，接着接受各种回调和加工，最后才交到你手上用； 容器关闭时还要走一遍销毁。把这条流水线记牢，不仅面试能答， 更能解释清楚「为什么构造器里拿不到依赖」「AOP 代理到底在哪一步生成」这类实战难题。"})}),e.jsx("h2",{children:"完整的生命周期流程"}),e.jsx("p",{children:"以单例 Bean 为例，从创建到销毁大致经过这几步："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"实例化"}),"（Instantiation）：容器通过构造器把对象 new 出来，此时只是个空壳，依赖还没注入。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"属性填充"}),"（Populate）：把依赖注入进去，也就是 DI 真正发生的地方。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Aware 回调"}),"：如果 Bean 实现了 ",e.jsx("code",{children:"BeanNameAware"}),"、",e.jsx("code",{children:"ApplicationContextAware"}),"等接口，容器会回调它们，把容器内部的资源（如 Bean 名字、容器本身）告诉这个 Bean。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"BeanPostProcessor 前置处理"}),"：调用所有 ",e.jsx("em",{children:"BeanPostProcessor"})," 的",e.jsx("code",{children:"postProcessBeforeInitialization"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"初始化"}),"：依次执行 ",e.jsx("code",{children:"@PostConstruct"})," → ",e.jsx("code",{children:"InitializingBean.afterPropertiesSet"}),"→ 自定义 ",e.jsx("code",{children:"init-method"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"BeanPostProcessor 后置处理"}),"：调用 ",e.jsx("code",{children:"postProcessAfterInitialization"}),"，",e.jsx("strong",{children:"AOP 代理就在这一步织入"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"使用"}),"：Bean 准备就绪，放进容器供你取用。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"销毁"}),"：容器关闭时执行 ",e.jsx("code",{children:"@PreDestroy"})," → ",e.jsx("code",{children:"DisposableBean.destroy"}),"→ 自定义 ",e.jsx("code",{children:"destroy-method"}),"。"]})]}),e.jsxs(g,{title:"@PostConstruct 何时执行",children:[e.jsx("p",{children:"很多人第一反应是「在构造器里就能用注入的依赖」，这是错的。看下面这段代码："}),e.jsx(l,{lang:"java",title:"CacheLoader.java",code:A}),e.jsxs("p",{children:["运行结果是：构造器里 ",e.jsx("code",{children:"dataSource"})," 为 ",e.jsx("code",{children:"null"}),"， 而 ",e.jsx("code",{children:"@PostConstruct"})," 标注的 ",e.jsx("code",{children:"init()"})," 里 ",e.jsx("code",{children:"dataSource"})," 已经可用。 原因就在流水线顺序上——",e.jsx("strong",{children:"实例化（构造器）在前，属性填充和初始化在后"}),"。 所以一切「需要依赖已就位」的初始化逻辑，都该放进 ",e.jsx("code",{children:"@PostConstruct"}),"，而不是构造器。"]})]}),e.jsx(S,{}),e.jsxs(u,{title:"两个必考的考点",children:[e.jsxs("p",{children:["第一，",e.jsx("strong",{children:"AOP 代理在 BeanPostProcessor 的后置处理里织入"}),"： Spring 用一个特殊的后置处理器（",e.jsx("code",{children:"AnnotationAwareAspectJAutoProxyCreator"}),"）， 在 ",e.jsx("code",{children:"postProcessAfterInitialization"})," 里把原始 Bean 包成代理对象返回， 于是容器里最终存的是代理，而不是你写的那个原始对象。"]}),e.jsxs("p",{children:["第二，",e.jsx("strong",{children:"BeanPostProcessor 是 Spring 的扩展核心"}),"：它能在每个 Bean 初始化前后插一脚，AOP、",e.jsx("code",{children:"@Autowired"})," 注解的处理、",e.jsx("code",{children:"@Async"})," 等 大量功能都是靠它实现的。理解了 BPP，就理解了 Spring 是怎么「无侵入」地增强你的 Bean 的。"]})]}),e.jsx(P,{variant:"warn",title:"单例 Bean 什么时候被创建",children:e.jsxs("p",{children:["默认情况下，",e.jsx("strong",{children:"单例 Bean 在容器启动时就全部创建并初始化好"}),"（即「预实例化」）， 而不是等到第一次 ",e.jsx("code",{children:"getBean"})," 才造。好处是启动时就能暴露配置错误（快速失败）， 坏处是启动会慢一点。想让某个单例延迟到首次使用才创建，可以加 ",e.jsx("code",{children:"@Lazy"}),"。 而 prototype 作用域的 Bean 则相反，每次获取时才新建，且容器",e.jsx("strong",{children:"不负责销毁"}),"它。"]})}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["被问「Bean 的生命周期」，按四段式背最清楚：",e.jsx("strong",{children:"实例化 → 属性填充 → 初始化 → 销毁"}),"， 然后在「初始化」前后补上 Aware 回调和 BeanPostProcessor 的前置／后置， 再点出两个亮点——「AOP 代理在 BPP 后置织入」「BeanPostProcessor 是扩展核心」。 如果面试官追问初始化方法的执行顺序，记住：",e.jsx("code",{children:"@PostConstruct"})," 早于 ",e.jsx("code",{children:"InitializingBean"})," 早于 ",e.jsx("code",{children:"init-method"}),"。"]}),e.jsxs(B,{title:"实现 InitializingBean 与 BeanPostProcessor 观察顺序",children:[e.jsxs("p",{children:["先在一个 Bean 上同时挂 ",e.jsx("code",{children:"@PostConstruct"}),"、",e.jsx("code",{children:"InitializingBean"})," 和 ",e.jsx("code",{children:"init-method"}),"， 打印各自的执行顺序："]}),e.jsx(l,{lang:"java",title:"OrderService.java",code:v}),e.jsxs("p",{children:["再写一个自定义的 ",e.jsx("code",{children:"BeanPostProcessor"}),"，在前置和后置方法里打印 Bean 名字， 直观感受它在每个 Bean 初始化前后被调用："]}),e.jsx(l,{lang:"java",title:"TimingBeanPostProcessor.java",code:y}),e.jsxs("p",{children:["启动容器，按打印顺序串一遍整条流水线； 再给某个 Bean 加上 ",e.jsx("code",{children:"@Transactional"}),"，用 ",e.jsx("code",{children:"getClass()"}),"打印它的真实类型，你会看到类名里多了 ",e.jsx("code",{children:"$$EnhancerBySpringCGLIB"}),"——这就是后置处理织入的代理。"]})]}),e.jsx(m,{points:["Bean 生命周期主线：实例化 → 属性填充（DI）→ Aware 回调 → BPP 前置 → 初始化 → BPP 后置 → 使用 → 销毁。","初始化方法执行顺序：@PostConstruct → InitializingBean.afterPropertiesSet → 自定义 init-method。","构造器执行时依赖还没注入，需要依赖的初始化逻辑要放进 @PostConstruct 而非构造器。","AOP 代理在 BeanPostProcessor 的后置处理（postProcessAfterInitialization）里织入，容器最终存的是代理对象。","BeanPostProcessor 是 Spring 的扩展核心，AOP、@Autowired、@Async 等都靠它在 Bean 初始化前后插手。","单例 Bean 默认在容器启动时就预先创建（可用 @Lazy 延迟），prototype Bean 每次获取才新建且不被容器销毁。"]})]})}export{z as default};
