import{j as e}from"./index-CNCQ9D3g.js";import{L as c,S as t}from"./Summary-B81QYNtK.js";import{K as i}from"./KeyIdea-CJu1AmJK.js";import{C as n}from"./Callout-DBjCLF-u.js";import{C as s}from"./CodeBlock-B4ANG3D_.js";import{E as d}from"./Example-C7EXHAW5.js";const r=`function whoAmI() {
  return this
}

// 独立调用（不挂在任何对象上）
// 非严格模式：this 指向全局对象（浏览器里是 window）
// 严格模式：this 是 undefined
'use strict'
function strictCheck() {
  console.log(this) // undefined（严格模式下的默认绑定）
}
strictCheck()`,h=`const user = {
  name: '小明',
  greet() {
    // 谁“点”调用了我，this 就指向谁
    console.log('我是 ' + this.name)
  },
}

user.greet() // 我是 小明  —— this 指向点号左边的 user

// 只看“调用那一刻点号左边是谁”，跟函数定义在哪无关
const admin = { name: '管理员', greet: user.greet }
admin.greet() // 我是 管理员 —— 同一个函数，this 却变了`,l=`function introduce(city, job) {
  console.log(this.name + ' 来自 ' + city + '，职业 ' + job)
}

const p = { name: '小红' }

// call：参数逐个传
introduce.call(p, '杭州', '工程师') // 小红 来自 杭州，职业 工程师

// apply：参数用数组传
introduce.apply(p, ['北京', '设计师']) // 小红 来自 北京，职业 设计师

// bind：不立即执行，返回一个“this 被永久绑定”的新函数
const boundIntro = introduce.bind(p, '广州')
boundIntro('产品经理') // 小红 来自 广州，职业 产品经理`,o=`function Person(name) {
  // new 调用时，this 指向新创建的空对象
  this.name = name
  // 不写 return，构造函数默认返回这个新对象
}

const a = new Person('小李')
console.log(a.name) // 小李

// new 做了四件事：
// 1) 创建一个新空对象
// 2) 把它的原型指向 Person.prototype
// 3) 让函数体内的 this 指向这个新对象
// 4) 若函数没返回对象，则返回这个新对象`,j=`const user = {
  name: '小明',
  greet() {
    console.log(this.name)
  },
}

// 坑一：把方法赋值出来，丢了点号左边的对象
const fn = user.greet
fn() // undefined（或报错）—— 退化成默认绑定，this 不再是 user

// 坑二：作为回调传出去，同样丢失
setTimeout(user.greet, 100) // undefined —— 内部是独立调用 greet()

// 修复：用 bind 锁住 this
setTimeout(user.greet.bind(user), 100) // 小明`,x=`const timer = {
  seconds: 0,
  start() {
    // 箭头函数没有自己的 this，捕获外层 start 的 this（即 timer）
    setInterval(() => {
      this.seconds += 1 // 这里的 this 正确指向 timer
      console.log(this.seconds)
    }, 1000)
  },
}
timer.start() // 1, 2, 3, ...

// 反例：普通函数作回调，this 在调用时退化为默认绑定，拿不到 timer`,a=`const obj = {
  name: '小明',
  // 反例：用箭头函数当对象方法
  greet: () => {
    // 箭头函数捕获“定义时外层”的 this，而对象字面量不构成函数作用域，
    // 这里的 this 是模块/全局的 this，而不是 obj
    console.log(this.name)
  },
}
obj.greet() // undefined —— 箭头函数不适合做对象方法`,p=`// 手写一个简化版 bind
Function.prototype.myBind = function (context, ...presetArgs) {
  const fn = this // this 是被调用 myBind 的那个原函数
  return function (...laterArgs) {
    // 用 apply 在调用时把 this 固定为 context，并合并两批参数
    return fn.apply(context, [...presetArgs, ...laterArgs])
  }
}

function say(greeting, punctuation) {
  return greeting + ', ' + this.name + punctuation
}
const bound = say.myBind({ name: '小红' }, '你好')
console.log(bound('！')) // 你好, 小红！`;function w(){return e.jsxs("article",{children:[e.jsxs(c,{children:[e.jsx("code",{children:"this"})," 大概是 JavaScript 里最让初学者头疼的关键字。它的难点在于一个反直觉的事实：",e.jsxs("strong",{children:[e.jsx("code",{children:"this"})," 的值不是在函数定义时确定的，而是在函数被调用时、由“调用方式”决定的"]}),"。 同一个函数，换种方式调用，",e.jsx("code",{children:"this"})," 就指向不同的东西。这一章我们用四条绑定规则 把 ",e.jsx("code",{children:"this"})," 彻底讲清，再讲 ",e.jsx("code",{children:"call"})," / ",e.jsx("code",{children:"apply"})," / ",e.jsx("code",{children:"bind"})," 如何手动控制它， 以及箭头函数为什么是个特例。"]}),e.jsx("h2",{children:"一、核心心法：看“调用方式”，不看“定义位置”"}),e.jsxs(i,{children:["判断 ",e.jsx("code",{children:"this"})," 指向，",e.jsx("strong",{children:"永远先问一句：这个函数是“怎么被调用的”？"}),"而不是“它定义在哪里”。调用方式一共归纳为四条绑定规则，按优先级排序即可得出答案。"]}),e.jsxs("p",{children:["很多人习惯从“函数写在哪个对象里”去猜 ",e.jsx("code",{children:"this"}),"，这恰恰是错误的起点。 在普通函数中，",e.jsx("code",{children:"this"})," 是一个在",e.jsx("strong",{children:"调用那一刻"}),"才被填入的“隐式参数”。 下面四条规则覆盖了所有调用形态。"]}),e.jsx("h2",{children:"二、四条绑定规则"}),e.jsx("h3",{children:"规则 1：默认绑定（独立调用）"}),e.jsxs("p",{children:["函数被“光秃秃”地直接调用（前面没有点号、没有 ",e.jsx("code",{children:"call"})," 之类），适用默认绑定。 此时",e.jsx("strong",{children:"非严格模式"}),"下 ",e.jsx("code",{children:"this"})," 指向全局对象（浏览器是 ",e.jsx("code",{children:"window"}),"），",e.jsx("strong",{children:"严格模式"}),"下 ",e.jsx("code",{children:"this"})," 是 ",e.jsx("code",{children:"undefined"}),"。"]}),e.jsx(s,{lang:"js",title:"默认绑定",code:r}),e.jsx("h3",{children:"规则 2：隐式绑定（obj.fn）"}),e.jsxs("p",{children:["当函数作为某个对象的方法、通过 ",e.jsx("code",{children:"对象.方法()"})," 形式调用时，",e.jsx("code",{children:"this"})," 指向",e.jsx("strong",{children:"点号左边的那个对象"}),"。记住关键词：看调用那一刻“点号左边是谁”。"]}),e.jsx(s,{lang:"js",title:"隐式绑定",code:h}),e.jsx("h3",{children:"规则 3：显式绑定（call / apply / bind）"}),e.jsxs("p",{children:["通过 ",e.jsx("code",{children:"call"}),"、",e.jsx("code",{children:"apply"}),"、",e.jsx("code",{children:"bind"})," 把 ",e.jsx("code",{children:"this"}),e.jsx("strong",{children:"手动指定"}),"为你给的对象。这是最“强势”的一种，详见第四节。"]}),e.jsx(s,{lang:"js",title:"显式绑定",code:l}),e.jsx("h3",{children:"规则 4：new 绑定（构造调用）"}),e.jsxs("p",{children:["用 ",e.jsx("code",{children:"new"})," 调用一个函数时，引擎会创建一个全新的对象，并把函数体内的 ",e.jsx("code",{children:"this"}),"指向这个新对象。这是构造函数的工作原理。"]}),e.jsx(s,{lang:"js",title:"new 绑定",code:o}),e.jsx("h2",{children:"三、四规则的优先级与判定流程"}),e.jsxs("p",{children:["当多条规则看似都适用时，按优先级裁决：",e.jsx("strong",{children:"new 绑定 > 显式绑定 > 隐式绑定 > 默认绑定"}),"。 实用的判定流程是“从高往低问四个问题”："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"优先级"}),e.jsx("th",{children:"规则"}),e.jsx("th",{children:"调用形态"}),e.jsx("th",{children:"this 指向"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"1（最高）"}),e.jsx("td",{children:"new 绑定"}),e.jsx("td",{children:e.jsx("code",{children:"new Fn()"})}),e.jsx("td",{children:"新创建的对象"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"2"}),e.jsx("td",{children:"显式绑定"}),e.jsxs("td",{children:[e.jsx("code",{children:"fn.call(o)"})," / ",e.jsx("code",{children:"fn.apply(o)"})," / ",e.jsx("code",{children:"fn.bind(o)"})]}),e.jsx("td",{children:"传入的 o"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"3"}),e.jsx("td",{children:"隐式绑定"}),e.jsx("td",{children:e.jsx("code",{children:"obj.fn()"})}),e.jsx("td",{children:"点号左边的 obj"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"4（最低）"}),e.jsx("td",{children:"默认绑定"}),e.jsx("td",{children:e.jsx("code",{children:"fn()"})}),e.jsx("td",{children:"全局对象 / 严格模式下 undefined"})]})]})]}),e.jsxs(d,{title:"用流程图心法判断 this",children:[e.jsx("p",{children:"拿到一个调用，依次自问："}),e.jsxs("p",{children:["① 是 ",e.jsx("code",{children:"new fn()"})," 吗？是 → ",e.jsx("code",{children:"this"})," 是新对象。"]}),e.jsxs("p",{children:["② 是 ",e.jsx("code",{children:"fn.call/apply/bind(o)"})," 吗？是 → ",e.jsx("code",{children:"this"})," 是 ",e.jsx("code",{children:"o"}),"。"]}),e.jsxs("p",{children:["③ 是 ",e.jsx("code",{children:"obj.fn()"})," 吗？是 → ",e.jsx("code",{children:"this"})," 是 ",e.jsx("code",{children:"obj"}),"。"]}),e.jsxs("p",{children:["④ 都不是 → 默认绑定（全局对象，严格模式下 ",e.jsx("code",{children:"undefined"}),"）。"]})]}),e.jsx("h2",{children:"四、隐式丢失：this 最常见的“走失”"}),e.jsxs(i,{children:[e.jsx("strong",{children:"隐式丢失"}),"指的是：一个本该靠隐式绑定拿到对象的方法，因为被“赋值出来”或 “作为回调传出去”，调用时丢掉了点号左边的对象，于是退化成默认绑定，",e.jsx("code",{children:"this"})," 不再是你期望的那个对象。"]}),e.jsxs("p",{children:["这是实战里最高频的 ",e.jsx("code",{children:"this"})," bug。一旦你把 ",e.jsx("code",{children:"obj.method"})," 取出来单独存或者 当参数传走，那个“点号左边的 obj”就没了，调用时只剩一个孤零零的函数引用。"]}),e.jsx(s,{lang:"js",title:"隐式丢失与用 bind 修复",code:j}),e.jsxs(n,{variant:"warn",title:"传方法当回调时务必小心",children:["把对象方法直接传给 ",e.jsx("code",{children:"setTimeout"}),"、事件监听、数组的 ",e.jsx("code",{children:"map"})," / ",e.jsx("code",{children:"forEach"}),"等接受回调的 API 时，",e.jsx("code",{children:"this"})," 极易丢失。常见解法：用 ",e.jsx("code",{children:"bind"})," 锁定， 或用箭头函数包一层（",e.jsx("code",{children:"() => obj.method()"}),"）保留正确的调用形态。"]}),e.jsx("h2",{children:"五、箭头函数：没有自己的 this"}),e.jsxs(i,{children:["箭头函数",e.jsxs("strong",{children:["没有自己的 ",e.jsx("code",{children:"this"})]}),"。它内部的 ",e.jsx("code",{children:"this"})," 不由调用方式决定， 而是",e.jsxs("strong",{children:["捕获定义时所在外层作用域的 ",e.jsx("code",{children:"this"})]}),"（词法 this）。 上面那四条规则对箭头函数统统不适用。"]}),e.jsxs("p",{children:["正因如此，箭头函数特别适合做",e.jsx("strong",{children:"回调"}),"：它会忠实地沿用外层的 ",e.jsx("code",{children:"this"}),"， 不会在被异步调用时“走失”。下面这个计时器是经典正例："]}),e.jsx(s,{lang:"js",title:"箭头函数作回调：this 不丢失",code:x}),e.jsxs("p",{children:["但反过来，箭头函数",e.jsx("strong",{children:"不适合当对象方法"}),"。因为对象字面量并不构成函数作用域， 写在对象里的箭头函数捕获的是更外层（模块 / 全局）的 ",e.jsx("code",{children:"this"}),"，而不是这个对象。"]}),e.jsx(s,{lang:"js",title:"反例：箭头函数当对象方法会拿错 this",code:a}),e.jsxs(n,{variant:"tip",title:"一句话口诀",children:[e.jsx("strong",{children:"对象的方法用普通函数，回调用箭头函数。"}),"前者要靠隐式绑定拿到对象本身，后者要的是“继承外层 this 而不被调用方式干扰”。"]}),e.jsx("h2",{children:"六、call / apply / bind 的区别"}),e.jsxs("p",{children:["这三者都用来",e.jsxs("strong",{children:["显式指定 ",e.jsx("code",{children:"this"})]}),"，区别在于“是否立即执行”和“怎么传参”："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方法"}),e.jsx("th",{children:"是否立即执行"}),e.jsx("th",{children:"传参方式"}),e.jsx("th",{children:"返回值"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"call"})}),e.jsx("td",{children:"立即执行"}),e.jsx("td",{children:"参数逐个列出"}),e.jsx("td",{children:"函数的返回值"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"apply"})}),e.jsx("td",{children:"立即执行"}),e.jsx("td",{children:"参数放一个数组"}),e.jsx("td",{children:"函数的返回值"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"bind"})}),e.jsx("td",{children:"不执行，返回新函数"}),e.jsx("td",{children:"可预置部分参数"}),e.jsx("td",{children:"this 被绑定的新函数"})]})]})]}),e.jsxs("p",{children:["记忆法：",e.jsx("code",{children:"call"})," 和 ",e.jsx("code",{children:"apply"})," 只差在传参——",e.jsx("strong",{children:"c"}),"all 对应 ",e.jsx("strong",{children:"逗号"}),"分隔，",e.jsx("strong",{children:"a"}),"pply 对应 ",e.jsx("strong",{children:"数组"}),"（array）。 而 ",e.jsx("code",{children:"bind"})," 不调用，只是“先把 ",e.jsx("code",{children:"this"})," 焊死”，返回一个新函数留着以后调用。"]}),e.jsx(d,{title:"手写一个简化版 bind",children:e.jsxs("p",{children:["理解 ",e.jsx("code",{children:"bind"})," 的最好方式是亲手实现一遍。核心就两点：① 用闭包记住原函数和要绑定的",e.jsx("code",{children:"this"}),"；② 返回一个新函数，调用时用 ",e.jsx("code",{children:"apply"})," 把 ",e.jsx("code",{children:"this"}),"固定下来，并把“预置参数”和“后续参数”拼接起来。"]})}),e.jsx(s,{lang:"js",title:"myBind 实现",code:p}),e.jsx("h2",{children:"七、事件处理器里的 this"}),e.jsxs("p",{children:["在 DOM 事件处理中，",e.jsx("code",{children:"this"})," 也遵循同样的规则。用",e.jsxs("code",{children:["el.addEventListener('click', function () ","{...}",")"]})," 时， 浏览器以隐式绑定的形态调用回调，",e.jsx("strong",{children:"普通函数"}),"里的 ",e.jsx("code",{children:"this"})," 指向 触发事件的那个 DOM 元素（",e.jsx("code",{children:"el"}),"）。但如果回调写成",e.jsx("strong",{children:"箭头函数"}),"，",e.jsx("code",{children:"this"})," 就变成外层作用域的 ",e.jsx("code",{children:"this"}),"，不再是元素本身。"]}),e.jsxs(n,{variant:"warn",title:"在类组件 / 对象里绑事件的常见坑",children:["如果把一个对象 / 类的方法直接作为事件回调传进去，又是隐式丢失的重灾区——",e.jsx("code",{children:"this"})," 会指向触发事件的 DOM 元素或 ",e.jsx("code",{children:"undefined"}),"，而不是你的对象实例。 解决办法照旧：在传入前 ",e.jsx("code",{children:"bind(this)"}),"，或用箭头函数包一层把调用形态留住。"]}),e.jsxs(n,{variant:"tip",children:["把这一章和上一章连起来看：闭包关心“函数记住了哪些",e.jsx("strong",{children:"变量"}),"”（由定义位置决定，词法的）， 而 ",e.jsx("code",{children:"this"})," 关心“函数被谁",e.jsx("strong",{children:"调用"}),"”（由调用方式决定，动态的）。 唯一的例外是箭头函数——它的 ",e.jsx("code",{children:"this"})," 也变成了词法的，于是和闭包一脉相承。"]}),e.jsx(t,{points:["this 的值由“函数怎么被调用”决定，不看定义位置；判断 this 永远先问调用方式。","四条绑定规则：默认绑定（独立调用 fn()，严格模式 undefined）、隐式绑定（obj.fn() 指向点号左边）、显式绑定（call/apply/bind 手动指定）、new 绑定（指向新建对象）。","优先级：new 绑定 > 显式绑定 > 隐式绑定 > 默认绑定。","隐式丢失：把方法赋值出来或作回调传走，会丢掉点号左边的对象而退化成默认绑定；用 bind 或箭头函数包裹修复。","箭头函数没有自己的 this，捕获外层词法 this：适合做回调，不适合当对象方法。","call/apply 立即执行（前者逐个传参、后者传数组），bind 返回 this 被绑定的新函数；事件处理器里普通函数的 this 指向触发元素，箭头函数则取外层 this。"]})]})}export{w as default};
