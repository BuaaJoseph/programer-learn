import{j as e}from"./index-hdw1-ZnZ.js";import{L as o,S as n}from"./Summary-BvjHGSZd.js";import{K as s}from"./KeyIdea-C9IzdosI.js";import{C as r}from"./Callout-W3CFPRAs.js";import{C as t}from"./CodeBlock-DEowrgWb.js";import{E as c}from"./Example-DLVeeCKM.js";const d=`// 1) 对象字面量：最常用，直接写出键值对
const point = { x: 1, y: 2 }

// 2) 构造函数 + new：用一个函数当模板批量造对象
function Person(name) {
  this.name = name
}
const p = new Person('Ada')

// 3) Object.create：显式指定新对象的原型
const base = { greet() { return 'hi' } }
const obj = Object.create(base)   // obj 的原型就是 base
console.log(obj.greet())          // 'hi'（greet 是从 base 继承来的）`,i=`const arr = [1, 2, 3]

// 读取一个对象的原型，推荐用 Object.getPrototypeOf
Object.getPrototypeOf(arr) === Array.prototype   // true

// 历史遗留的访问器：__proto__（能用，但不推荐在代码里直接写）
arr.__proto__ === Array.prototype                // true

// 数组的原型链：arr -> Array.prototype -> Object.prototype -> null
Object.getPrototypeOf(Array.prototype) === Object.prototype  // true
Object.getPrototypeOf(Object.prototype) === null             // true`,l=`function Dog(name) {
  this.name = name
}
// 给「原型对象」加方法，所有实例共享同一份
Dog.prototype.bark = function () {
  return this.name + ': woof'
}

const d = new Dog('Rex')

// 关键三角关系：
d.__proto__ === Dog.prototype              // true（实例的原型 = 构造函数的 prototype）
Dog.prototype.constructor === Dog          // true（prototype 自带 constructor 指回构造函数）
d.constructor === Dog                      // true（d 自己没有 constructor，沿原型链找到了）

d.bark()                                   // 'Rex: woof'（方法在原型上，被实例共享）`,j=`// new Dog('Rex') 在底层大致等价于这四步：
function fakeNew(Ctor, ...args) {
  // 1) 创建一个新空对象，并把它的原型链接到 Ctor.prototype
  const obj = Object.create(Ctor.prototype)
  // 2) 把构造函数里的 this 绑定到这个新对象，执行构造逻辑
  const ret = Ctor.apply(obj, args)
  // 3) 如果构造函数显式返回了一个对象，就用那个；否则返回新建的 obj
  return (typeof ret === 'object' && ret !== null) ? ret : obj
}

const d = fakeNew(Dog, 'Rex')   // 与 new Dog('Rex') 行为一致`,h=`function Animal() {}
Animal.prototype.kind = 'animal'

const a = new Animal()
a.name = 'Tom'      // 自有属性

// 查找 a.name：a 自己有 -> 直接返回 'Tom'
// 查找 a.kind：a 自己没有 -> 沿原型链到 Animal.prototype 找到 'animal'
// 查找 a.toString：一路找到 Object.prototype.toString
// 查找 a.nope：找到 null 仍没有 -> 返回 undefined

console.log(a.name)        // 'Tom'
console.log(a.kind)        // 'animal'
console.log(a.nope)        // undefined`,p=`function Animal() {}
Animal.prototype.kind = 'animal'

const a = new Animal()
a.name = 'Tom'

a.hasOwnProperty('name')   // true（自有属性）
a.hasOwnProperty('kind')   // false（继承来的，不是自有）
'kind' in a                // true（in 运算符会顺着原型链一起查）

// 更稳妥的写法（避免对象自己覆盖了 hasOwnProperty）：
Object.prototype.hasOwnProperty.call(a, 'name')   // true
Object.hasOwn(a, 'name')                          // true（ES2022 新增，推荐）`,x=`// 用原型链实现「继承」的本质：把子类型的原型对象，
// 指向一个以父类型原型为原型的对象。
function Animal(name) {
  this.name = name
}
Animal.prototype.eat = function () {
  return this.name + ' is eating'
}

function Dog(name) {
  Animal.call(this, name)        // 借父构造函数初始化自有属性
}
// 让 Dog.prototype 的原型 = Animal.prototype，从而继承 eat
Dog.prototype = Object.create(Animal.prototype)
Dog.prototype.constructor = Dog  // 修回 constructor，否则指向 Animal
Dog.prototype.bark = function () {
  return this.name + ': woof'
}

const d = new Dog('Rex')
d.bark()   // 'Rex: woof'（Dog.prototype 上）
d.eat()    // 'Rex is eating'（沿链到 Animal.prototype 上）
// 原型链：d -> Dog.prototype -> Animal.prototype -> Object.prototype -> null`;function O(){return e.jsxs("article",{children:[e.jsxs(o,{children:["JavaScript 的对象系统与 Java、C++ 那种「先有类、再由类造对象」的模型不同：它的底层只有 一种机制——",e.jsx("strong",{children:"原型（prototype）"}),"。每个对象都偷偷链着另一个对象，找不到的属性 就顺着这条链往上问，直到尽头。理解了这条「原型链」，你就理解了 JS 里继承、共享方法、",e.jsx("code",{children:"new"}),"、乃至后面 class 语法的全部底层真相。这一章我们从对象怎么创建讲起， 一路把原型链拆到底。"]}),e.jsx("h2",{children:"一、对象是怎么创建出来的"}),e.jsxs("p",{children:["在 JS 里造一个对象有三条主要路径，它们的差别不在「造出来的是不是对象」，而在",e.jsx("strong",{children:"新对象的原型被设成了什么"}),"。"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"对象字面量"})," ",e.jsx("code",{children:"{ ... }"}),"：最常用，原型默认是 ",e.jsx("code",{children:"Object.prototype"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"构造函数 + new"}),"：把一个函数当模板批量造对象，原型是该函数的 ",e.jsx("code",{children:"prototype"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Object.create(proto)"}),"：最直接，明明白白告诉引擎「新对象的原型就是 proto」。"]})]}),e.jsx(t,{lang:"js",title:"三种创建对象的方式",code:d}),e.jsxs(s,{children:["不管用哪种方式创建，结果都是一个对象，并且这个对象内部都挂着一个指向「另一个对象（或 null）」的隐藏链接——这就是它的",e.jsx("strong",{children:"原型"}),"。对象的能力，一半来自它自己，一半来自 它的原型。"]}),e.jsx("h2",{children:"二、每个对象都有内部 [[Prototype]]"}),e.jsxs("p",{children:["规范里，每个对象都有一个内部槽位叫 ",e.jsx("code",{children:"[[Prototype]]"}),"，它要么指向另一个对象， 要么是 ",e.jsx("code",{children:"null"}),"。这个槽位本身看不见，但 JS 给了两种方式去访问它："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:["标准方法 ",e.jsx("code",{children:"Object.getPrototypeOf(obj)"}),"——读取原型，推荐使用； 对应的设置方法是 ",e.jsx("code",{children:"Object.setPrototypeOf(obj, proto)"}),"。"]}),e.jsxs("li",{children:["历史遗留访问器 ",e.jsx("code",{children:"obj.__proto__"}),"——能读能写，但它是早期浏览器的产物， 标准里只为兼容而保留，",e.jsx("strong",{children:"正式代码里别直接用"}),"，理解原理时用它讲解很方便。"]})]}),e.jsx(t,{lang:"js",title:"访问一个对象的原型",code:i}),e.jsx(r,{variant:"warn",title:"区分两个容易混淆的名字",children:e.jsxs("p",{children:[e.jsx("code",{children:"__proto__"})," 是",e.jsx("strong",{children:"实例对象"}),"上的访问器，指向「我的原型」； 而 ",e.jsx("code",{children:"prototype"})," 是",e.jsx("strong",{children:"函数"}),"才有的普通属性，指向「将来用 new 调我时， 新实例的原型」。一个挂在实例上，一个挂在函数上，名字像但完全不是一回事。"]})}),e.jsx("h2",{children:"三、函数的 prototype 与实例的关系"}),e.jsxs("p",{children:["在 JS 里，",e.jsx("strong",{children:"函数"}),"是个特别的存在：每个普通函数被定义时，引擎都会顺手给它配一个",e.jsx("code",{children:"prototype"})," 属性，指向一个对象（称为「原型对象」）。这个原型对象天生带一个",e.jsx("code",{children:"constructor"})," 属性，指回函数本身。当你用 ",e.jsx("code",{children:"new"})," 调用这个函数时， 新造出来的实例的 ",e.jsx("code",{children:"[[Prototype]]"})," 就会被设成这个 ",e.jsx("code",{children:"prototype"})," 对象。"]}),e.jsx(t,{lang:"js",title:"构造函数、prototype、实例三者的关系",code:l}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"名字"}),e.jsx("th",{children:"挂在谁身上"}),e.jsx("th",{children:"指向什么"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"Dog.prototype"})}),e.jsx("td",{children:"构造函数 Dog"}),e.jsx("td",{children:"原型对象（实例将共享它）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"d.__proto__"})}),e.jsx("td",{children:"实例 d"}),e.jsxs("td",{children:["就是 ",e.jsx("code",{children:"Dog.prototype"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"Dog.prototype.constructor"})}),e.jsx("td",{children:"原型对象"}),e.jsxs("td",{children:["指回构造函数 ",e.jsx("code",{children:"Dog"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"d.constructor"})}),e.jsx("td",{children:"实例自己没有"}),e.jsxs("td",{children:["沿链找到 ",e.jsx("code",{children:"Dog"})]})]})]})]}),e.jsx(c,{title:"把方法放原型上，为什么省内存",children:e.jsxs("p",{children:["如果在构造函数里写 ",e.jsx("code",{children:"this.bark = function(){...}"}),"，那每造一个实例都复制一份 函数；造一万个实例就有一万份相同的函数。把方法放到 ",e.jsx("code",{children:"Dog.prototype.bark"})," 上， 一万个实例",e.jsx("strong",{children:"共享同一份"})," bark——它们调用时只是沿原型链找到了同一个函数。 这就是「数据放实例、方法放原型」的经典分工。"]})}),e.jsx("h2",{children:"四、new 到底做了什么"}),e.jsxs("p",{children:[e.jsx("code",{children:"new Dog('Rex')"})," 看着像魔法，其实就是四个固定动作。把它拆开你就再也不会被",e.jsx("code",{children:"this"})," 指向问题困住："]}),e.jsxs("ol",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"创建"}),"一个全新的空对象。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"链接原型"}),"：把这个新对象的 ",e.jsx("code",{children:"[[Prototype]]"})," 设为 ",e.jsx("code",{children:"Dog.prototype"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"绑定 this"}),"：以新对象为 ",e.jsx("code",{children:"this"})," 执行构造函数体（于是 ",e.jsx("code",{children:"this.name = ..."})," 写到了新对象上）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"返回"}),"：若构造函数没有显式返回一个对象，就自动返回这个新对象。"]})]}),e.jsx(t,{lang:"js",title:"手写一个 new 来理解它的四步",code:j}),e.jsx(r,{variant:"tip",title:"构造函数返回值的小坑",children:e.jsxs("p",{children:["构造函数若 ",e.jsx("code",{children:"return"})," 一个",e.jsx("strong",{children:"对象"}),"，",e.jsx("code",{children:"new"})," 的结果就是那个对象， 新建的实例被丢弃；若返回的是原始值（数字、字符串等）或什么都不返回，",e.jsx("code",{children:"new"}),"照常返回新建的实例。绝大多数情况下，构造函数不写 return 即可。"]})}),e.jsx("h2",{children:"五、属性查找沿原型链向上"}),e.jsxs("p",{children:["读取 ",e.jsx("code",{children:"obj.x"})," 时，引擎的算法是：先看 ",e.jsx("code",{children:"obj"})," 自己有没有 ",e.jsx("code",{children:"x"}),"； 没有就去它的原型上找；还没有就去原型的原型……一层层往上，",e.jsxs("strong",{children:["直到遇到",e.jsx("code",{children:"null"})," 为止"]}),"。整条链都没有，结果就是 ",e.jsx("code",{children:"undefined"}),"，而不会报错。"]}),e.jsx(t,{lang:"js",title:"属性查找：从自身到原型链顶端",code:h}),e.jsxs("p",{children:["这条链的",e.jsxs("strong",{children:["顶端几乎总是 ",e.jsx("code",{children:"Object.prototype"})]}),"，再往上就是 ",e.jsx("code",{children:"null"}),"。 正因为如此，几乎所有对象都能调用 ",e.jsx("code",{children:"toString()"}),"、",e.jsx("code",{children:"hasOwnProperty()"}),"—— 它们都定义在 ",e.jsx("code",{children:"Object.prototype"})," 上，被整个对象世界共享。"]}),e.jsx(r,{variant:"warn",title:"赋值不走原型链",children:e.jsxs("p",{children:["注意：",e.jsx("strong",{children:"查找"}),"会沿原型链向上，但",e.jsx("strong",{children:"赋值"})," ",e.jsx("code",{children:"obj.x = v"})," 通常只会 在 ",e.jsx("code",{children:"obj"})," 自己身上创建（或修改）属性，而不会去改原型上的同名属性。也就是说， 给实例赋值会「遮蔽」（shadow）原型上的同名属性，而非覆盖它。"]})}),e.jsx("h2",{children:"六、原型链顶端：Object.prototype"}),e.jsx("p",{children:"把前面的例子串起来，一条典型的原型链长这样（用文字图表示，箭头表示「的原型是」）："}),e.jsx(t,{lang:"js",title:"一条原型链的文字图",code:`d                       // 实例：{ name: 'Rex' }
  │  __proto__
  ▼
Dog.prototype           // { bark, constructor: Dog }
  │  __proto__
  ▼
Object.prototype        // { toString, hasOwnProperty, ... }
  │  __proto__
  ▼
null                    // 链的尽头，到此为止`}),e.jsxs("p",{children:["如果想造一个",e.jsx("strong",{children:"完全没有原型"}),"的「纯净」对象（连 ",e.jsx("code",{children:"toString"})," 都没有）， 可以用 ",e.jsx("code",{children:"Object.create(null)"}),"，它的 ",e.jsx("code",{children:"[[Prototype]]"})," 直接是",e.jsx("code",{children:"null"}),"，常用于当作干净的字典 / 哈希表，避免与继承属性冲突。"]}),e.jsx("h2",{children:"七、hasOwnProperty：区分自有与继承"}),e.jsxs("p",{children:["既然属性可能来自自身、也可能来自原型链，那就需要一个办法判断「这个属性到底是不是它自己 的」。这就是 ",e.jsx("code",{children:"hasOwnProperty"})," 的职责：只看自有属性，不顺着原型链找。 与之相对，",e.jsx("code",{children:"in"})," 运算符会连原型链一起查。"]}),e.jsx(t,{lang:"js",title:"hasOwnProperty、in 与 Object.hasOwn",code:p}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"判断方式"}),e.jsx("th",{children:"查自有属性"}),e.jsx("th",{children:"查原型链"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"obj.hasOwnProperty(k)"})}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"否"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"Object.hasOwn(obj, k)"})}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"否（ES2022，推荐）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"k in obj"})}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"是"})]})]})]}),e.jsx(r,{variant:"tip",title:"为什么推荐 Object.hasOwn",children:e.jsxs("p",{children:["如果对象自己定义了一个叫 ",e.jsx("code",{children:"hasOwnProperty"})," 的属性，或它是",e.jsx("code",{children:"Object.create(null)"})," 造的没有原型的对象，直接调 ",e.jsx("code",{children:"obj.hasOwnProperty()"}),"可能出错。ES2022 的 ",e.jsx("code",{children:"Object.hasOwn(obj, k)"})," 不依赖原型链，是更安全的现代写法。"]})}),e.jsx("h2",{children:"八、原型链实现继承的本质"}),e.jsxs("p",{children:["所谓「继承」，在 JS 里没有任何额外魔法：无非是让子类型实例的原型链上，",e.jsx("strong",{children:"串进父类型的 原型对象"}),"。子类型实例找不到的方法，自然就沿链找到父类型原型上去了。"]}),e.jsx(t,{lang:"js",title:"用原型链手写继承（class 出现前的经典写法）",code:x}),e.jsxs("p",{children:["这段代码里有两个关键动作：① ",e.jsx("code",{children:"Animal.call(this, name)"})," 在子构造里借父构造函数初始化",e.jsx("strong",{children:"自有属性"}),"；② ",e.jsx("code",{children:"Dog.prototype = Object.create(Animal.prototype)"})," 把",e.jsx("strong",{children:"方法继承"}),"这条链接好。这两步合起来，就是下一章 ",e.jsx("code",{children:"class ... extends"}),"在底层替你做的事——class 只是把这套样板代码包装成了更顺手的语法。"]}),e.jsxs(r,{variant:"tip",children:["下一章我们看 ",e.jsx("code",{children:"class"})," 语法：它读起来像传统面向对象的「类」，但骨子里仍是这一章讲的 原型继承。把这一章的原型链印在脑子里，再看 class 你会发现「原来不过如此」。"]}),e.jsx(n,{points:["对象有三种创建方式：字面量、构造函数 + new、Object.create；区别在于新对象的原型被设成了什么。","每个对象都有内部 [[Prototype]]，可用 Object.getPrototypeOf 读取（__proto__ 是遗留访问器，仅用于讲解）。","函数的 prototype 是「将来实例的原型」；实例的 __proto__ 就指向构造函数的 prototype；prototype.constructor 指回构造函数。","new 做四件事：创建新对象、把原型链接到构造函数的 prototype、以新对象为 this 执行构造体、返回该对象。","属性查找沿原型链向上直到 null；顶端通常是 Object.prototype；赋值只作用于对象自身（遮蔽而非覆盖原型）。","hasOwnProperty / Object.hasOwn 只看自有属性，in 连原型链一起查；继承的本质就是把父类型原型串进子类型实例的原型链。"]})]})}export{O as default};
