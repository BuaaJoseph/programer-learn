import{j as e}from"./index-hdw1-ZnZ.js";import{L as t,S as r}from"./Summary-BvjHGSZd.js";import{K as i}from"./KeyIdea-C9IzdosI.js";import{C as s}from"./Callout-W3CFPRAs.js";import{C as n}from"./CodeBlock-DEowrgWb.js";import{E as d}from"./Example-DLVeeCKM.js";const c=`// interface 描述一个对象应该长什么样（它的「形状」）
interface User {
  id: number
  name: string
  email?: string          // 可选属性：可有可无
  readonly createdAt: Date // 只读属性：初始化后不可再改
  greet(): string         // 方法
}

const u: User = {
  id: 1,
  name: "阿杜",
  createdAt: new Date(),
  greet() { return "hi" },
}
u.id = 2          // ✅ 可以改
u.createdAt = new Date()  // ❌ readonly，不允许重新赋值`,l=`// 索引签名：键名不固定、但都符合某种类型
interface StringMap {
  [key: string]: string   // 任意 string 键，值都是 string
}
const dict: StringMap = { a: "1", b: "2" }

// 继承：用 extends 在已有接口上扩展
interface Animal {
  name: string
}
interface Dog extends Animal {  // Dog 拥有 name，再加自己的
  bark(): void
}`,h=`// 声明合并：同名 interface 会自动合并成一个
interface Box {
  width: number
}
interface Box {
  height: number
}
// 最终 Box 同时拥有 width 和 height
const b: Box = { width: 10, height: 20 }`,x=`// type 类型别名：给「任意类型」起个名字
type ID = number | string          // 联合
type Point = { x: number; y: number }  // 对象
type Pair = [string, number]       // 元组
type Name = string                 // 给原始类型起别名

// 交叉类型 &：把多个类型「合并」成一个，必须同时满足
type Named = { name: string }
type Aged = { age: number }
type Person = Named & Aged         // 同时拥有 name 和 age
const p: Person = { name: "阿杜", age: 34 }`,o=`// 函数类型标注：参数与返回值
function add(a: number, b: number): number {
  return a + b
}

// 可选参数 ?、默认参数 =、剩余参数 ...
function build(name: string, prefix = "Mr.", suffix?: string, ...tags: string[]): string {
  return prefix + name + (suffix ?? "")
}

// 把「函数本身」的类型写成别名
type BinaryOp = (a: number, b: number) => number
const mul: BinaryOp = (a, b) => a * b   // 参数类型可由 BinaryOp 推断出来`,j=`// 不用泛型：要么写死类型，要么退化成 any（丢掉类型信息）
function identityAny(x: any): any { return x }
const a = identityAny("hi")   // a 的类型是 any —— 类型没了

// 用泛型：T 是一个「类型变量」，调用时按实参自动确定
function identity<T>(x: T): T {
  return x
}
const s = identity("hi")      // T 推断为 string，s 的类型是 string
const n = identity(42)        // T 推断为 number，n 的类型是 number
// 既保留了完整类型，又对所有类型通用 —— 这就是泛型胜过 any 的地方`,a=`// 泛型容器：一个能装「任意但确定」类型的栈
class Stack<T> {
  private items: T[] = []

  push(item: T): void {
    this.items.push(item)
  }

  pop(): T | undefined {
    return this.items.pop()
  }

  get size(): number {
    return this.items.length
  }
}

const numStack = new Stack<number>()
numStack.push(1)
numStack.push(2)
const top = numStack.pop()    // top 的类型是 number | undefined
numStack.push("x")            // ❌ 只接受 number`,g=`// 泛型约束 extends：限制 T 至少要有某些能力
function longest<T extends { length: number }>(a: T, b: T): T {
  return a.length >= b.length ? a : b   // 因为约束保证了 .length 存在
}
longest("abcd", "ab")     // ✅ string 有 length
longest([1, 2], [3])      // ✅ 数组有 length
longest(1, 2)             // ❌ number 没有 length

// 默认类型参数：调用时不传也有兜底
interface ApiResponse<T = unknown> {
  code: number
  data: T
}
const r1: ApiResponse = { code: 0, data: "随便" }       // T 默认 unknown
const r2: ApiResponse<number> = { code: 0, data: 200 }   // 显式指定 T`;function T(){return e.jsxs("article",{children:[e.jsxs(t,{children:["上一章我们认识了基础类型，但真实程序里数据大多是「一团对象」。 这一章先学怎么用 ",e.jsx("code",{children:"interface"})," 和 ",e.jsx("code",{children:"type"})," 给对象和函数 描述「形状」，搞清这两者的取舍；再正式进入 TS 里威力最大、也最值得花时间的 特性——",e.jsx("strong",{children:"泛型"}),"，理解它凭什么比 ",e.jsx("code",{children:"any"})," 强得多。"]}),e.jsx("h2",{children:"一、interface：描述对象的形状"}),e.jsxs("p",{children:[e.jsx("code",{children:"interface"}),"（接口）用来声明一个对象应该有哪些属性、各是什么类型、 有哪些方法。它是 TS 里描述数据结构最常用的工具。"]}),e.jsx(n,{lang:"ts",title:"interface 基础：属性、可选、只读、方法",code:c}),e.jsx("p",{children:"这段代码里出现了几个关键修饰："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsxs("strong",{children:["可选属性 ",e.jsx("code",{children:"?"})]}),"：属性名后加 ",e.jsx("code",{children:"?"})," 表示「可有可无」， 如 ",e.jsx("code",{children:"email?: string"}),"。不写也合法，写了就必须是对应类型。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:["只读属性 ",e.jsx("code",{children:"readonly"})]}),"：加了 ",e.jsx("code",{children:"readonly"})," 的属性 初始化后不能再被赋值，适合表达「一旦确定就不该改」的字段，如创建时间。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"方法"}),"：接口里也能声明方法签名，如 ",e.jsx("code",{children:"greet(): string"}),"， 表示实现这个接口的对象必须提供一个返回字符串的 ",e.jsx("code",{children:"greet"})," 方法。"]})]}),e.jsx("h3",{children:"索引签名与继承"}),e.jsxs("p",{children:["当对象的键名事先不固定（比如一个字典），用",e.jsx("strong",{children:"索引签名"}),e.jsx("code",{children:"[key: string]: string"})," 描述「任意 string 键，值都是 string」。 接口之间还能用 ",e.jsx("code",{children:"extends"})," ",e.jsx("strong",{children:"继承"}),"，在已有形状上叠加新字段。"]}),e.jsx(n,{lang:"ts",title:"索引签名与 extends 继承",code:l}),e.jsx("h3",{children:"声明合并"}),e.jsxs("p",{children:["interface 有个 type 没有的特性：",e.jsx("strong",{children:"声明合并"}),"——同名的多个",e.jsx("code",{children:"interface"})," 会被自动合并成一个。这在给第三方库「补充类型」时很有用 （比如往全局对象上挂自己的字段）。"]}),e.jsx(n,{lang:"ts",title:"同名 interface 自动合并",code:h}),e.jsx("h2",{children:"二、type：类型别名"}),e.jsxs("p",{children:[e.jsx("code",{children:"type"})," 给",e.jsx("strong",{children:"任意类型"}),"起一个名字，不限于对象。它能表达 联合、交叉、原始、元组、函数等几乎所有类型——这点比 interface 更灵活。"]}),e.jsx(n,{lang:"ts",title:"type 类型别名的各种用法",code:x}),e.jsxs("p",{children:["其中",e.jsx("strong",{children:"交叉类型"})," ",e.jsx("code",{children:"&"})," 值得留意：它把多个类型「合并」， 结果必须",e.jsx("strong",{children:"同时满足"}),"所有成员。它常用来组合多个小形状， 和联合类型 ",e.jsx("code",{children:"|"}),"（满足其一即可）正好相对。"]}),e.jsx("h2",{children:"三、interface vs type：怎么选"}),e.jsx("p",{children:"两者大量场景可以互换。下表是常见取舍依据："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"能力 / 场景"}),e.jsx("th",{children:"interface"}),e.jsx("th",{children:"type"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"描述对象 / 类的形状"}),e.jsx("td",{children:"✅ 擅长"}),e.jsx("td",{children:"✅ 可以"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["联合类型 ",e.jsx("code",{children:"A | B"})]}),e.jsx("td",{children:"❌ 不支持"}),e.jsx("td",{children:"✅ 支持"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["交叉类型 ",e.jsx("code",{children:"A & B"})]}),e.jsx("td",{children:"用 extends 近似"}),e.jsx("td",{children:"✅ 直接 &"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"给原始 / 元组 / 函数起别名"}),e.jsx("td",{children:"❌"}),e.jsx("td",{children:"✅"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"声明合并（同名自动合并）"}),e.jsx("td",{children:"✅ 支持"}),e.jsx("td",{children:"❌ 不支持"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"extends 继承"}),e.jsx("td",{children:"✅ 原生"}),e.jsx("td",{children:"用 & 模拟"})]})]})]}),e.jsxs(s,{variant:"tip",title:"一个简单的选择原则",children:[e.jsxs("strong",{children:["描述对象 / 类的形状、或要被外部扩展时，优先 ",e.jsx("code",{children:"interface"})]}),"（可继承、可声明合并，报错信息也更友好）；",e.jsxs("strong",{children:["需要联合、交叉、给原始类型或函数起别名时，用 ",e.jsx("code",{children:"type"})]}),"。 团队里保持一致即可，不必纠结。"]}),e.jsx("h2",{children:"四、函数类型标注"}),e.jsxs("p",{children:["函数的参数和返回值都能标注。除了普通参数，TS 还支持可选参数 ",e.jsx("code",{children:"?"}),"、 默认参数 ",e.jsx("code",{children:"="}),"、剩余参数 ",e.jsx("code",{children:"..."}),"。你也能把「函数本身的类型」 抽成一个别名，写成 ",e.jsx("code",{children:"(a: number, b: number) => number"})," 这样的形式。"]}),e.jsx(n,{lang:"ts",title:"参数、返回值、可选 / 默认 / 剩余",code:o}),e.jsxs(s,{variant:"note",title:"可选参数必须在必选参数之后",children:["和默认参数一样，带 ",e.jsx("code",{children:"?"})," 的可选参数只能排在必选参数后面， 剩余参数 ",e.jsx("code",{children:"..."})," 必须放在最末位。注意函数类型里的箭头",e.jsx("code",{children:"=>"})," 表示「返回」，别和箭头函数的 ",e.jsx("code",{children:"=>"})," 混为一谈 （虽然长得一样，一个在类型位置、一个在值位置）。"]}),e.jsx("h2",{children:"五、泛型：给类型也加上「参数」"}),e.jsxs(i,{children:["泛型（generics）就是「",e.jsx("strong",{children:"类型的参数"}),"」。你先用一个类型变量 （习惯写作 ",e.jsx("code",{children:"<T>"}),"）占位，等到真正调用 / 实例化时， 再由实际传入的值",e.jsx("strong",{children:"自动确定"})," T 是什么。这样一段代码就能对 多种类型通用，",e.jsx("strong",{children:"同时完整保留类型信息"}),"。"]}),e.jsx("h3",{children:"泛型函数：类型安全的 identity"}),e.jsxs("p",{children:["最经典的例子是 ",e.jsx("code",{children:"identity"}),"（原样返回传入的值）。看看不用泛型会怎样、 用了泛型又好在哪："]}),e.jsx(n,{lang:"ts",title:"identity：any 丢类型 vs 泛型保类型",code:j}),e.jsxs("p",{children:["关键对比：",e.jsx("code",{children:"identityAny"})," 用 ",e.jsx("code",{children:"any"}),"，返回值类型变成",e.jsx("code",{children:"any"}),"——调用后你完全不知道拿到的是什么，类型检查形同虚设。 而泛型版本里，",e.jsx("code",{children:"identity<T>(x: T): T"})," 把「入参类型」和「返回类型」 用同一个 ",e.jsx("code",{children:"T"})," 绑定起来：传字符串就推断 ",e.jsx("code",{children:"T"})," 为 string， 返回值也精确是 string。这就是",e.jsx("strong",{children:"泛型为什么比 any 好"}),"—— any 是「放弃类型」，泛型是「让类型流动」。"]}),e.jsx("h3",{children:"泛型类 / 接口：一个类型安全的栈"}),e.jsxs("p",{children:["泛型不只用于函数，类和接口也能带类型参数。下面实现一个泛型栈",e.jsx("code",{children:"Stack<T>"}),"，它能装某种确定的元素类型，push / pop 全程类型安全。"]}),e.jsx(n,{lang:"ts",title:"泛型容器 Stack<T>",code:a}),e.jsxs("p",{children:[e.jsx("code",{children:"new Stack<number>()"})," 把 ",e.jsx("code",{children:"T"})," 定为 number 后，",e.jsx("code",{children:"push"})," 只接受数字、",e.jsx("code",{children:"pop"})," 返回 ",e.jsx("code",{children:"number | undefined"}),"， 往里塞字符串会被直接拒绝。同一份 ",e.jsx("code",{children:"Stack"})," 代码可以服务",e.jsx("code",{children:"Stack<string>"}),"、",e.jsx("code",{children:"Stack<User>"})," 等任意类型，且各自类型独立、安全。"]}),e.jsx("h3",{children:"泛型约束与默认类型参数"}),e.jsxs("p",{children:["有时你需要对类型变量加点限制——比如「",e.jsx("code",{children:"T"})," 必须有 ",e.jsx("code",{children:"length"})," 属性」， 这用 ",e.jsxs("strong",{children:["约束 ",e.jsx("code",{children:"extends"})]})," 表达：",e.jsx("code",{children:"<T extends { length: number }>"}),"。 还能给类型参数设",e.jsx("strong",{children:"默认值"}),"，调用时不指定就用兜底类型。"]}),e.jsx(n,{lang:"ts",title:"约束 extends 与默认类型参数",code:g}),e.jsx(d,{title:"泛型约束读法",children:e.jsxs("p",{children:[e.jsx("code",{children:"<T extends { length: number }>"})," 读作「T 是任何",e.jsx("strong",{children:"带 length 数值属性"}),"的类型」。正因为有这个保证，函数体里访问 ",e.jsx("code",{children:"a.length"})," 才不会报错。 约束是「在保持通用的同时，要求 T 至少具备某种能力」——比无约束泛型更精确， 又比写死具体类型更灵活。"]})}),e.jsxs(s,{variant:"warn",title:"别一遇到不确定就写 any",children:["新手常见的坏习惯是：拿不准类型就写 ",e.jsx("code",{children:"any"}),"，让红线消失。但这等于关掉了 TS。 绝大多数「想用 any」的场景，正确解法是",e.jsx("strong",{children:"泛型"}),"（让类型由调用方决定） 或 ",e.jsx("strong",{children:"unknown + 收窄"}),"（先证明类型再用）。把这两招用熟， 你的代码会既灵活又安全。"]}),e.jsx(r,{points:["interface 描述对象 / 类的形状：支持可选 ?、只读 readonly、方法、索引签名、extends 继承，以及同名自动声明合并。","type 是类型别名，能给联合、交叉、原始、元组、函数等任意类型起名；交叉类型 & 表示「同时满足」。","interface vs type：描述对象 / 要被扩展用 interface；要联合 / 交叉 / 给原始类型或函数起别名用 type，团队内保持一致即可。","函数类型可标注参数与返回值，支持可选 ?、默认 =、剩余 ... 参数；函数类型里的 => 表示返回值类型。","泛型是「类型的参数」：用类型变量占位、调用时自动确定，既通用又完整保留类型信息。","泛型支持约束 extends（要求 T 具备某能力）和默认类型参数；它比 any 强——any 是放弃类型，泛型是让类型流动。"]})]})}export{T as default};
