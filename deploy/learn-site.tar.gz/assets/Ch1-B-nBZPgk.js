import{j as e}from"./index-CVHWXZpb.js";import{L as r,S as n}from"./Summary-CJTCDEeZ.js";import{K as i}from"./KeyIdea-XVLVSS4B.js";import{C as t}from"./Callout-DCq22jZW.js";import{C as s}from"./CodeBlock-ljkh5ShG.js";import{E as c}from"./Example-BSuN_UvG.js";import{P as d}from"./Practice-D2QRX8ZH.js";const o=`# requests 不是内置库，先安装
pip install requests`,l=`import requests

# 最简单的 GET 请求：去一个测试 API 取数据
resp = requests.get("https://httpbin.org/get")

print(resp.status_code)   # 状态码：200 表示成功
print(resp.json())        # 把返回的 JSON 解析成 Python 字典`,h=`200
{'args': {}, 'headers': {...}, 'url': 'https://httpbin.org/get'}`,x=`import requests

# GET 带查询参数：用 params 传字典，自动拼成 ?key=value
resp = requests.get(
    "https://httpbin.org/get",
    params={"city": "杭州", "days": 3},
)

print(resp.url)                  # 看看最终请求的完整地址
print(resp.json()["args"])       # 服务器收到的参数`,a=`https://httpbin.org/get?city=%E6%9D%AD%E5%B7%9E&days=3
{'city': '杭州', 'days': '3'}`,j=`import requests

# POST 带 JSON：用 json= 传字典，requests 自动序列化并设好请求头
resp = requests.post(
    "https://httpbin.org/post",
    json={"name": "小明", "age": 18},
)

data = resp.json()
print(data["json"])      # 服务器收到的 JSON 内容`,p="{'name': '小明', 'age': 18}",u=`import requests

# 设置请求头：常用于带认证 token、声明数据格式
headers = {
    "Authorization": "Bearer sk-你的token",
    "User-Agent": "my-app/1.0",
}
resp = requests.get("https://httpbin.org/headers", headers=headers)
print(resp.json()["headers"]["User-Agent"])`,g="my-app/1.0",m=`import requests

resp = requests.get("https://httpbin.org/status/404")

print(resp.status_code)        # 404
print(resp.ok)                 # status_code < 400 时为 True

# 常见状态码：
# 200 成功   201 创建成功   400 请求错误
# 401 未认证  403 禁止访问   404 找不到   500 服务器错误`,P=`404
False`,y=`import requests

try:
    # timeout：超过 5 秒没响应就放弃，避免程序卡死
    resp = requests.get("https://httpbin.org/delay/10", timeout=5)
    resp.raise_for_status()        # 状态码 >= 400 时主动抛异常
    print(resp.json())
except requests.exceptions.Timeout:
    print("请求超时了！")
except requests.exceptions.HTTPError as e:
    print("服务器返回了错误状态：", e)
except requests.exceptions.RequestException as e:
    print("请求出错：", e)`,T="请求超时了！",q=`import requests

# 调用一个公开 API：随机获取一条"猫咪小知识"（无需 key）
def get_cat_fact():
    url = "https://catfact.ninja/fact"
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()        # 4xx/5xx 直接抛异常
        data = resp.json()             # 解析 JSON 为字典
        return data["fact"]            # 取出我们要的字段
    except requests.exceptions.RequestException as e:
        return f"请求失败：{e}"

if __name__ == "__main__":
    print("今日猫咪冷知识：")
    print(get_cat_fact())`,_=`今日猫咪冷知识：
Cats can jump up to six times their length.`;function R(){return e.jsxs("article",{children:[e.jsxs(r,{children:['到这里，我们的程序终于要"上网"了。绝大多数有用的服务——天气、翻译、地图， 当然还有大模型——都通过 ',e.jsx("strong",{children:"HTTP API"})," 对外提供。这一章学会用 Python 最流行的",e.jsx("code",{children:"requests"})," 库发请求：GET 取数据、POST 提交数据、带参数和请求头、 看状态码、处理超时和异常，最后调一个真实的公开 API 跑通完整流程。"]}),e.jsx("h2",{children:"一、什么是 HTTP"}),e.jsxs("p",{children:['HTTP 是浏览器、App 和服务器之间约定好的"对话规则"。你的程序作为',e.jsx("strong",{children:"客户端"}),"发出一个",e.jsx("strong",{children:"请求"}),"，服务器返回一个",e.jsx("strong",{children:"响应"}),"。请求里有："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"方法"}),"：最常见 ",e.jsx("code",{children:"GET"}),"（取数据）和 ",e.jsx("code",{children:"POST"}),"（提交数据）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"URL"}),"：要访问的地址。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"请求头（headers）"}),"：附加信息，如认证 token、数据格式。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"请求体（body）"}),"：POST 时携带的数据，通常是 JSON。"]})]}),e.jsxs("p",{children:["响应里则有",e.jsx("strong",{children:"状态码"}),"（成功还是失败）和",e.jsx("strong",{children:"响应体"}),"（返回的数据，多为 JSON）。"]}),e.jsxs(i,{children:["调 API 的本质就是：",e.jsx("strong",{children:"按规则发一个请求，拿回一个响应，从响应里取出你要的数据"}),"。 后面调大模型 API，无非是请求体里装对话内容、响应里取回复——同一套流程。"]}),e.jsx("h2",{children:"二、安装 requests"}),e.jsxs("p",{children:["Python 内置也能发请求，但 ",e.jsx("code",{children:"requests"})," 库更简单好用，是事实标准。"]}),e.jsx(s,{lang:"bash",title:"安装 requests",code:o}),e.jsx("h2",{children:"三、GET 请求：取数据"}),e.jsx(s,{lang:"python",title:"最简单的 GET",code:l}),e.jsx(s,{lang:"text",title:"运行结果",code:h}),e.jsxs("p",{children:[e.jsx("code",{children:"resp.status_code"})," 是状态码，",e.jsx("code",{children:"resp.json()"})," 把返回的 JSON 直接解析成 Python 字典——这是最常用的两个操作。"]}),e.jsx("h3",{children:"带查询参数"}),e.jsxs("p",{children:["GET 常带参数（如查哪个城市的天气）。用 ",e.jsx("code",{children:"params"})," 传一个字典， requests 会自动拼成 ",e.jsx("code",{children:"?city=杭州&days=3"})," 这样的形式，连中文转码都帮你做了。"]}),e.jsx(s,{lang:"python",title:"GET 带参数",code:x}),e.jsx(s,{lang:"text",title:"运行结果",code:a}),e.jsx("h2",{children:"四、POST 请求：提交数据"}),e.jsxs("p",{children:["提交数据用 POST。最常见的是发 JSON——用 ",e.jsx("code",{children:"json="})," 传字典， requests 自动把它序列化成 JSON 字符串，并设好对应的请求头。"]}),e.jsx(s,{lang:"python",title:"POST 带 JSON",code:j}),e.jsx(s,{lang:"text",title:"运行结果",code:p}),e.jsxs(t,{variant:"tip",title:"json= 和 data= 的区别",children:["发 JSON 用 ",e.jsx("code",{children:"json=字典"}),"（自动序列化 + 设头）；发表单用 ",e.jsx("code",{children:"data=字典"}),"。 调大模型 API 几乎都用 ",e.jsx("code",{children:"json="}),"。"]}),e.jsx("h2",{children:"五、设置请求头"}),e.jsxs("p",{children:["请求头携带附加信息。最常见的是 ",e.jsx("code",{children:"Authorization"}),"——很多 API（包括大模型） 靠它来验证你的身份（带上 API Key / token）。"]}),e.jsx(s,{lang:"python",title:"设置 headers",code:u}),e.jsx(s,{lang:"text",title:"运行结果",code:g}),e.jsx("h2",{children:"六、看懂状态码"}),e.jsxs("p",{children:["状态码告诉你请求成功还是失败。",e.jsx("code",{children:"2xx"})," 成功，",e.jsx("code",{children:"4xx"})," 是你的请求有问题，",e.jsx("code",{children:"5xx"})," 是服务器出错。"]}),e.jsx(s,{lang:"python",title:"检查状态码",code:m}),e.jsx(s,{lang:"text",title:"运行结果",code:P}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"状态码"}),e.jsx("th",{children:"含义"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"200 / 201"}),e.jsx("td",{children:"成功 / 创建成功"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"400"}),e.jsx("td",{children:"请求格式错误"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"401 / 403"}),e.jsx("td",{children:"未认证（key 错） / 被禁止"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"404"}),e.jsx("td",{children:"地址找不到"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"429"}),e.jsx("td",{children:"请求太频繁（限流）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"500"}),e.jsx("td",{children:"服务器内部错误"})]})]})]}),e.jsx("h2",{children:"七、超时与异常处理"}),e.jsxs("p",{children:["网络随时可能出问题：服务器半天不回、地址错了、断网了。一定要设",e.jsx("strong",{children:"超时"}),"，并用 ",e.jsx("code",{children:"try-except"})," 兜住异常，否则程序可能卡死或崩溃。"]}),e.jsx(s,{lang:"python",title:"超时 + 异常处理",code:y}),e.jsx(s,{lang:"text",title:"运行结果",code:T}),e.jsxs(t,{variant:"warn",title:"永远设 timeout",children:["不设 ",e.jsx("code",{children:"timeout"}),"，一旦对方不响应，你的程序会",e.jsx("strong",{children:"无限期卡住"}),"。 任何真实的网络请求都应该带超时。"]}),e.jsxs("p",{children:[e.jsx("code",{children:"resp.raise_for_status()"})," 是个好习惯：状态码 ≥ 400 时它会主动抛",e.jsx("code",{children:"HTTPError"}),"，让你在 except 里统一处理失败，而不用每次手动判断状态码。"]}),e.jsx("h2",{children:"八、完整实例：调一个公开 API"}),e.jsx("p",{children:"把前面所有要点串起来，调用一个无需 key 的公开 API（随机猫咪冷知识）， 包含超时、状态检查、JSON 解析、异常处理——这就是一个标准、健壮的 API 调用函数。"}),e.jsx(s,{lang:"python",title:"get_cat_fact.py",code:q}),e.jsx(s,{lang:"text",title:"运行结果",code:_}),e.jsxs(c,{title:"这个函数的标准套路",children:[e.jsxs("ul",{children:[e.jsxs("li",{children:["请求统一带 ",e.jsx("code",{children:"timeout"}),"，防卡死。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"raise_for_status()"})," 把 HTTP 错误转成异常，集中处理。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"resp.json()"})," 解析，再按字段名取出需要的数据。"]}),e.jsxs("li",{children:["用 ",e.jsx("code",{children:"except RequestException"})," 兜住所有 requests 相关的网络异常。"]})]}),e.jsx("p",{children:"记住这套模板，下一章调大模型 API 时，你会发现结构几乎一模一样。"})]}),e.jsxs(d,{title:"练一练",children:["把 ",e.jsx("code",{children:"get_cat_fact"})," 改成调用 ",e.jsx("code",{children:"https://api.ipify.org?format=json"}),"（返回你的公网 IP），取出 ",e.jsx("code",{children:'data["ip"]'})," 打印。注意保留 timeout 和异常处理。"]}),e.jsx(n,{points:["HTTP 调用 = 客户端发请求、服务器回响应；请求含方法/URL/headers/body，响应含状态码和数据。","pip install requests；GET 取数据用 requests.get，POST 提交用 requests.post。","GET 带参数用 params=字典；POST 发 JSON 用 json=字典（自动序列化并设头）。","headers 携带附加信息，认证常用 Authorization 带 token / API Key。","resp.status_code 看状态（200 成功、401 认证失败、404 找不到、429 限流、500 服务器错），resp.json() 解析返回。","务必设 timeout 防卡死，用 try-except 兜住 RequestException，raise_for_status 把 HTTP 错误转异常——这套模板下一章调大模型 API 照用。"]})]})}export{R as default};
