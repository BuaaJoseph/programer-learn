import{j as s}from"./index-D-xLQIFq.js";import{L as e,S as i}from"./Summary-YJHOQU45.js";import{K as r}from"./KeyIdea-D9fwNcvs.js";import{E as n}from"./Example-JUHxJgjQ.js";import{C as t}from"./Callout-Bp0vMJus.js";import{C as d}from"./CodeBlock-DX_K20PW.js";import{T as o}from"./TreeFigure-Fd6ZcN7d.js";import{G as c}from"./GraphFigure-wbQAk2FQ.js";import"./AlgoPlayer-CyXq93eH.js";import"./Figure-BR5aUEEr.js";const l=`# 递归版（用系统调用栈）
def dfs(node, visited):
    if node in visited:
        return
    visited.add(node)
    visit(node)
    for nxt in graph[node]:      # 沿每个未访问的邻居深入
        dfs(nxt, visited)

# 显式栈版（手动维护栈，等价于上面）
def dfs_iter(start):
    visited, stack = set(), [start]
    while stack:
        node = stack.pop()       # 取栈顶——最近压入的，所以「最深」优先
        if node in visited:
            continue
        visited.add(node)
        visit(node)
        for nxt in graph[node]:
            if nxt not in visited:
                stack.append(nxt)`;function F(){return s.jsxs(s.Fragment,{children:[s.jsx(e,{children:s.jsxs("p",{children:["走迷宫时有一种最朴素的策略：选一条路一直往前走，走到死胡同就",s.jsx("em",{children:"退回"}),"上一个岔路口，换一条没走过的路接着走。 这就是",s.jsx("strong",{children:"深度优先搜索（DFS）"}),"的全部精神——",s.jsx("strong",{children:"不撞南墙不回头，一条路扎到底再回退"}),"。 它既能走树，也能走图，是无数算法的骨架。"]})}),s.jsx("h2",{children:"DFS 的引擎是「栈」"}),s.jsxs("p",{children:["「走到底再回退」这个动作，靠的正是第一卷讲的",s.jsx("strong",{children:"栈"}),"（后进先出）。 每深入一个节点，就把它记到栈里；遇到死路，就从栈顶弹出、回到上一个节点。 实现上有两种等价写法：用",s.jsx("em",{children:"递归"}),"（借助系统的调用栈，最简洁），或用一个",s.jsx("em",{children:"显式栈"}),"自己维护。 本质都一样：",s.jsx("strong",{children:"总是优先处理「最近遇到」的那个节点"}),"。"]}),s.jsx(d,{lang:"python",title:"dfs.py",code:l}),s.jsx("h2",{children:"先在树上看：一条路走到底"}),s.jsxs("p",{children:["下面这棵树用栈实现 DFS。盯住它的轨迹：从根 1 出发，一头扎进左边 1→2→4，走到叶子 4 这个「死胡同」后",s.jsx("em",{children:"回退"}),"， 再去 5；左边整条线走完才回头去右边的 3→6→7。下方的栈记录着「还没走完的岔路口」。"]}),s.jsx(o,{order:"dfs",caption:"树上的 DFS：用栈实现，一条路深入到底再回退。橙=当前，绿=已访问，下方=栈（后进先出）。"}),s.jsx("h2",{children:"再到图上：多了一件事——记录「访问过没」"}),s.jsxs("p",{children:["树没有环，不会走回头路。但图",s.jsx("strong",{children:"可能有环"}),"（A→B→C→A），如果不加防范就会无限绕圈。 所以图的 DFS 多了一个关键动作：用一个 ",s.jsx("code",{children:"visited"})," 集合",s.jsx("strong",{children:"标记访问过的节点，绝不重复进入"}),"。 除此之外，思路和树上完全一样——沿第一个没去过的邻居深入，无路可走就回退。"]}),s.jsx(c,{mode:"dfs",start:"A",caption:"图上的 DFS：沿未访问邻居深入，遇到访问过的就跳过（防止成环死循环），无路可走则回退。"}),s.jsx(t,{variant:"note",title:"时间复杂度：每个点、每条边各看一次",children:s.jsxs("p",{children:["DFS 会访问每个顶点一次、检查每条边一次，所以是 ",s.jsx("strong",{children:"O(V + E)"}),"（V 是顶点数、E 是边数）。 这是图遍历的「标准价格」，BFS 也是同样的复杂度——区别只在",s.jsx("em",{children:"访问顺序"}),"，不在快慢。"]})}),s.jsx(n,{title:"DFS 能解决哪些问题",children:s.jsxs("p",{children:[s.jsx("strong",{children:"连通性 / 找连通块"}),"（一个点能到达哪些点）、",s.jsx("strong",{children:"走迷宫 / 路径搜索"}),"、",s.jsx("strong",{children:"检测有没有环"}),"、",s.jsx("strong",{children:"拓扑排序"}),"（任务依赖的执行顺序，基于后序）、",s.jsx("strong",{children:"岛屿数量"}),"这类网格题……都是 DFS 的主场。凡是「顺着一条线索深入挖掘、不行再回退」的问题，先想 DFS。"]})}),s.jsx(r,{title:"一句话记住 DFS",children:s.jsxs("p",{children:["深度优先 = 一条路走到底，死胡同再回退，引擎是",s.jsx("strong",{children:"栈"}),"（递归或显式栈）。 在图上务必用 ",s.jsx("code",{children:"visited"})," 防止成环死循环。复杂度 O(V+E)，用于连通块、路径、环检测、拓扑排序。"]})}),s.jsx(i,{points:["DFS 像走迷宫：沿一条路深入到底，遇到死胡同就回退换路。","它的引擎是栈——可用递归（系统调用栈）或显式栈实现，总是优先处理最近遇到的节点。","在图上必须用 visited 集合标记已访问，避免在环里无限打转。","复杂度 O(V+E)，是连通块、路径搜索、环检测、拓扑排序等问题的通用骨架。"]})]})}export{F as default};
