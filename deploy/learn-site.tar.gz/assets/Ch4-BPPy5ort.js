import{j as e}from"./index-Bs06kW3a.js";import{L as t,S as n}from"./Summary-CLAN1smq.js";import{K as i}from"./KeyIdea-iVczm-9t.js";import{C as s}from"./Callout-BCaSeUge.js";import{C as r}from"./CodeBlock-BUaxuxwl.js";import{E as c}from"./Example-XOtO_AMb.js";const l=`import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import type { Tool } from './types.js'

// read：读取一个文本文件的内容。这是 Agent 的「眼睛」之一——只读、安全、可并行。
export const readTool: Tool = {
  name: 'read',
  description:
    '读取一个文本文件并返回其内容。返回的每一行都带行号，方便后续用 edit 工具精确定位。用于查看源码、配置、日志等。',
  readOnly: true,
  inputSchema: {
    type: 'object',
    properties: {
      path: { type: 'string', description: '文件路径，相对路径以工作目录为基准。' },
    },
    required: ['path'],
  },
  async execute(input, ctx) {
    const path = String(input.path)
    const abs = resolve(ctx.cwd, path)
    try {
      const text = await readFile(abs, 'utf8')
      const numbered = text
        .split('\\n')
        .map((line, i) => \`\${String(i + 1).padStart(5)}\\t\${line}\`)
        .join('\\n')
      return { output: numbered || '(空文件)' }
    } catch (err) {
      return { output: \`读取失败：\${(err as Error).message}\`, isError: true }
    }
  },
}`,o=`import { readdir } from 'node:fs/promises'
import { resolve } from 'node:path'
import type { Tool } from './types.js'

// list：列出一个目录下的条目，目录名带 / 后缀。只读、可并行。
export const listTool: Tool = {
  name: 'list',
  description: '列出指定目录下的文件和子目录（不递归）。目录会以 / 结尾标记。用于了解项目结构。',
  readOnly: true,
  inputSchema: {
    type: 'object',
    properties: {
      path: { type: 'string', description: '目录路径，默认为工作目录。' },
    },
  },
  async execute(input, ctx) {
    const path = input.path ? String(input.path) : '.'
    const abs = resolve(ctx.cwd, path)
    try {
      const entries = await readdir(abs, { withFileTypes: true })
      if (entries.length === 0) return { output: '(空目录)' }
      const lines = entries
        .filter((e) => !e.name.startsWith('.'))
        .sort((a, b) => Number(b.isDirectory()) - Number(a.isDirectory()) || a.name.localeCompare(b.name))
        .map((e) => (e.isDirectory() ? \`\${e.name}/\` : e.name))
      return { output: lines.join('\\n') || '(只有隐藏文件)' }
    } catch (err) {
      return { output: \`列目录失败：\${(err as Error).message}\`, isError: true }
    }
  },
}`,d=`import { readdir } from 'node:fs/promises'
import { join, relative } from 'node:path'

// 递归遍历目录，跳过常见的噪声目录，返回所有文件的相对路径。
// glob / grep 共用它，避免各写一遍遍历逻辑。
const IGNORE = new Set(['node_modules', '.git', 'dist', 'build', '.next', 'coverage'])

export async function walkFiles(root: string): Promise<string[]> {
  const out: string[] = []
  async function recur(dir: string): Promise<void> {
    let entries
    try {
      entries = await readdir(dir, { withFileTypes: true })
    } catch {
      return
    }
    for (const e of entries) {
      if (e.name.startsWith('.') || IGNORE.has(e.name)) continue
      const full = join(dir, e.name)
      if (e.isDirectory()) {
        await recur(full)
      } else if (e.isFile()) {
        out.push(relative(root, full))
      }
    }
  }
  await recur(root)
  return out
}

// 把简化版 glob（支持 * 和 **）编译成正则。
// *  匹配除 / 外的任意字符；** 匹配任意（含 /）。
export function globToRegExp(pattern: string): RegExp {
  let re = ''
  for (let i = 0; i < pattern.length; i++) {
    const c = pattern[i]
    if (c === '*') {
      if (pattern[i + 1] === '*') {
        re += '.*'
        i++
        if (pattern[i + 1] === '/') i++
      } else {
        re += '[^/]*'
      }
    } else if ('.+^\${}()|[]\\\\'.includes(c)) {
      re += '\\\\' + c
    } else if (c === '?') {
      re += '[^/]'
    } else {
      re += c
    }
  }
  return new RegExp('^' + re + '$')
}`,h=`import { resolve } from 'node:path'
import type { Tool } from './types.js'
import { walkFiles, globToRegExp } from './walk.js'

// glob：按文件名模式查找文件，比如 "src/**/*.ts"。只读、可并行。
export const globTool: Tool = {
  name: 'glob',
  description:
    '按 glob 模式查找文件路径，支持 * 与 **，例如 "src/**/*.ts"。返回匹配的相对路径列表。用于「这个项目里所有 X 文件在哪」。',
  readOnly: true,
  inputSchema: {
    type: 'object',
    properties: {
      pattern: { type: 'string', description: 'glob 模式，如 **/*.json' },
    },
    required: ['pattern'],
  },
  async execute(input, ctx) {
    const pattern = String(input.pattern)
    const root = resolve(ctx.cwd)
    const re = globToRegExp(pattern)
    const files = await walkFiles(root)
    const matched = files.filter((f) => re.test(f)).sort()
    if (matched.length === 0) return { output: \`没有匹配 \${pattern} 的文件\` }
    const head = matched.slice(0, 200)
    const more = matched.length > head.length ? \`\\n…还有 \${matched.length - head.length} 个\` : ''
    return { output: head.join('\\n') + more }
  },
}`,x=`import { readFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import type { Tool } from './types.js'
import { walkFiles, globToRegExp } from './walk.js'

// grep：在文件内容里按正则搜索。只读、可并行。
export const grepTool: Tool = {
  name: 'grep',
  description:
    '在项目文件内容中按正则表达式搜索，返回命中行（含文件名和行号）。可用 include 限定文件范围（glob）。用于「哪里用到了某个函数/字符串」。',
  readOnly: true,
  inputSchema: {
    type: 'object',
    properties: {
      pattern: { type: 'string', description: '正则表达式。' },
      include: { type: 'string', description: '可选，只搜匹配此 glob 的文件，如 "*.ts"。' },
    },
    required: ['pattern'],
  },
  async execute(input, ctx) {
    const pattern = String(input.pattern)
    const root = resolve(ctx.cwd)
    let re: RegExp
    try {
      re = new RegExp(pattern)
    } catch (err) {
      return { output: \`正则非法：\${(err as Error).message}\`, isError: true }
    }
    const includeRe = input.include ? globToRegExp(String(input.include)) : null
    let files = await walkFiles(root)
    if (includeRe) files = files.filter((f) => includeRe.test(f))

    const hits: string[] = []
    for (const f of files) {
      if (hits.length >= 200) break
      let text: string
      try {
        text = await readFile(join(root, f), 'utf8')
      } catch {
        continue
      }
      const lines = text.split('\\n')
      for (let i = 0; i < lines.length; i++) {
        if (re.test(lines[i])) {
          hits.push(\`\${f}:\${i + 1}: \${lines[i].trim()}\`)
          if (hits.length >= 200) break
        }
      }
    }
    if (hits.length === 0) return { output: \`没有命中 /\${pattern}/\` }
    return { output: hits.join('\\n') }
  },
}`,j=`// glob 元字符的编译规则（globToRegExp 的核心）：
//
//   glob 写法        编译成正则      含义
//   *                [^/]*           匹配任意字符，但「不跨目录」
//   **               .*              匹配任意字符，「可跨任意层目录」
//   ?                [^/]            匹配单个非分隔符字符
//   .  +  ( ) 等      \\. \\+ \\( ...   正则元字符被转义成「字面量」
//
// 几个例子（pattern -> 能否匹配）：
//   src/*.ts      匹配 src/a.ts          ；不匹配 src/x/a.ts（* 不跨目录）
//   src/**/*.ts   匹配 src/a.ts、src/x/y/a.ts（** 跨目录）
//   *.test.ts     匹配 a.test.ts         ；那个点是字面量，不会匹配 "axtestxts"`,a=`// 同一轮里读三个文件，串行 vs 并行的墙钟时间差距：

// 串行：一个 await 完再下一个，时间是三者之和
const a = await read('a.ts')   // ~30ms
const b = await read('b.ts')   // ~30ms
const c = await read('c.ts')   // ~30ms
// 总耗时 ≈ 90ms

// 并行：一起发出去、一起等齐，时间约等于最慢的那一个
const [a2, b2, c2] = await Promise.all([
  read('a.ts'), read('b.ts'), read('c.ts'),
])
// 总耗时 ≈ 30ms —— I/O 等待是重叠的，不是叠加的`;function w(){return e.jsxs(e.Fragment,{children:[e.jsx(t,{children:e.jsxs("p",{children:["上一章我们把主循环跑通了，但那个 Agent 现在是个「睁眼瞎」：它有心跳、会转圈， 却什么也看不见——你问它「这项目用什么测试框架」，它只能凭空瞎猜。 这一章我们给它装上第一组感官：",e.jsx("strong",{children:"四个只读工具"}),"——",e.jsx("code",{children:"read"})," 读文件、",e.jsx("code",{children:"list"})," 列目录、",e.jsx("code",{children:"glob"})," 找文件、",e.jsx("code",{children:"grep"})," 搜内容。 它们让 Agent 在动手改任何东西之前，先把现场",e.jsx("strong",{children:"看清楚"}),"。 四个工具都很短，逻辑也朴素，但它们合起来就是 Agent 的「探索能力」，是后面一切动作的前提。"]})}),e.jsx("h2",{children:"动手之前，先看清楚"}),e.jsxs("p",{children:["想象一个靠谱的工程师接手一个陌生项目：他不会上来就改代码。他会先 ",e.jsx("code",{children:"ls"})," 看看目录长啥样、 打开几个关键文件读一读、搜一下某个函数在哪儿被调用——",e.jsx("strong",{children:"先建立认知，再动手"}),"。 Agent 也一样。这一组只读工具，给的就是这种「先侦察」的能力："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"read"}),"：读取一个文件的完整内容（带行号）。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"list"}),"：列出一个目录下有哪些文件和子目录。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"glob"}),"：按文件名模式（如 ",e.jsx("code",{children:"src/**/*.ts"}),"）找出一批文件。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"grep"}),"：在文件",e.jsx("strong",{children:"内容"}),"里按正则搜索，定位某段代码在哪。"]})]}),e.jsxs("p",{children:["它们有一个共同的、至关重要的属性：",e.jsx("strong",{children:"只读"}),"。它们只看、不改。这个属性不是细节，而是整组工具的设计地基。"]}),e.jsx(i,{title:"只读 = 安全 + 可并行，是 Agent「先看后做」的基础设施",children:e.jsxs("p",{children:["每个只读工具都标了 ",e.jsx("code",{children:"readOnly: true"}),"，这一个布尔值换来两样东西。 第一是",e.jsx("strong",{children:"安全"}),"：只读操作不改变世界，跑错了、跑多了，最坏也就是浪费一点时间， 不会删掉文件、不会破坏状态，所以 Agent 可以",e.jsx("strong",{children:"放心大胆地探索"}),"——读十个文件来确认一件事，没有任何副作用。 第二是",e.jsx("strong",{children:"可并行"}),"：正因为互不影响，上一章的 ",e.jsx("code",{children:"runTools"})," 才能把它们用 ",e.jsx("code",{children:"Promise.all"})," 一起跑， 一口气读五个文件不必排队等。安全让 Agent 敢探索，并行让探索快—— 这两点合起来，构成了「先看清楚、再动手」这条纪律的底层基础设施。 所有会改变世界的「写工具」（下一章讲）都建立在「先用只读工具看明白」的前提之上。"]})}),e.jsx("h2",{children:"read：Agent 的眼睛"}),e.jsxs("p",{children:["从最基础的开始：把一个文件的内容读出来交给模型。下面是 forge 仓库里",e.jsx("code",{children:"src/tools/read.ts"})," 的",e.jsx("strong",{children:"逐字"}),"内容。"]}),e.jsx(r,{lang:"ts",title:"src/tools/read.ts",code:l}),e.jsx("p",{children:"代码很短，但有三处设计值得逐一讲透："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"为什么给每一行加行号。"})," 注意 ",e.jsx("code",{children:"numbered"})," 那段：把文件按 ",e.jsx("code",{children:"\\n"})," 切成行， 每行前面补上一个右对齐的行号（",e.jsx("code",{children:"padStart(5)"}),"）和一个制表符。这不是为了好看—— 而是为了",e.jsx("strong",{children:"给后面的 edit 工具铺路"}),"。下一章的 edit 要精确地「把第 42 行改成 XX」， 模型必须先知道哪行是第几行。read 在此就把行号一并喂给模型，让它「看见」的内容自带坐标。 这是 read 和 edit 之间一个隐形的契约。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:[e.jsx("code",{children:"resolve(ctx.cwd, path)"})," 把相对路径锚定到工作目录。"]}),"模型给的路径往往是相对的（比如 ",e.jsx("code",{children:"src/index.ts"}),"），但进程的「当前目录」未必就是用户的项目目录。 所以我们用 ",e.jsx("code",{children:"ctx.cwd"}),"（上一章 Agent 构造时传入、包进 ",e.jsx("code",{children:"ToolContext"})," 的工作目录）作为基准， 把相对路径解析成绝对路径。这样无论 forge 进程在哪儿启动，工具操作的",e.jsx("strong",{children:"永远是用户那个项目"}),"。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:["出错返回 ",e.jsx("code",{children:"isError"})," 而不是抛异常。"]})," 文件不存在、没权限——这些都很常见。 我们用 ",e.jsx("code",{children:"try/catch"})," 兜住，把错误信息塞进 ",e.jsx("code",{children:"output"}),"、置 ",e.jsx("code",{children:"isError: true"})," 返回，",e.jsx("strong",{children:"而不是 throw"}),"。回想上一章 ",e.jsx("code",{children:"execOne"}),"：这条带 isError 的结果会被如实回灌给模型， 模型看到「读取失败：no such file」就能自己换条路（比如先 list 看看文件到底叫啥）。 工具的职责是「如实汇报」，不是「替模型崩溃」。"]})]}),e.jsx("h2",{children:"list：看清目录结构"}),e.jsxs("p",{children:["read 要先知道文件名才能读，可一开始模型对项目一无所知。",e.jsx("code",{children:"list"})," 就是用来「探路」的—— 列出一个目录里有什么。看 ",e.jsx("code",{children:"src/tools/list.ts"})," 的",e.jsx("strong",{children:"逐字"}),"内容："]}),e.jsx(r,{lang:"ts",title:"src/tools/list.ts",code:o}),e.jsx("p",{children:"同样三处小心思："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"过滤隐藏文件。"})," ",e.jsx("code",{children:"filter((e) => !e.name.startsWith('.'))"})," 把",e.jsx("code",{children:".git"}),"、",e.jsx("code",{children:".env"}),"、",e.jsx("code",{children:".DS_Store"})," 这类点开头的条目滤掉。 它们大多是工具的元数据，对「了解项目结构」是噪声，列出来只会浪费模型的注意力和上下文。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:["目录排前面，并加 ",e.jsx("code",{children:"/"})," 后缀。"]})," 排序键先比 ",e.jsx("code",{children:"isDirectory()"}),"（目录排前），同类再按名字字母序。展示时目录名拼上 ",e.jsx("code",{children:"/"}),"（如 ",e.jsx("code",{children:"src/"}),"）。 这样模型一眼就能区分「这是能继续往里钻的目录」还是「这是能 read 的文件」， 省得它再为每一项去猜类型。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"默认列工作目录。"})," ",e.jsx("code",{children:"path"})," 在 schema 里不是必填—— 模型不传时默认用 ",e.jsx("code",{children:"'.'"}),"（经 resolve 后即 ",e.jsx("code",{children:"ctx.cwd"}),"）。 所以模型探索一个新项目的第一步，常常就是一句不带参数的 ",e.jsx("code",{children:"list"}),"，先看根目录全貌。"]})]}),e.jsx("h2",{children:"共享遍历器：walk.ts"}),e.jsxs("p",{children:["接下来的 glob 和 grep 都需要",e.jsx("strong",{children:"递归"}),"地走遍整个项目目录——glob 要遍历所有文件名来匹配， grep 要遍历所有文件内容来搜索。与其在两个文件里各写一遍遍历逻辑，不如抽成一个共享模块。 这就是 ",e.jsx("code",{children:"src/tools/walk.ts"})," 的",e.jsx("strong",{children:"逐字"}),"内容："]}),e.jsx(r,{lang:"ts",title:"src/tools/walk.ts",code:d}),e.jsx("p",{children:"这个文件导出两个函数，是 glob 和 grep 共同的地基："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsxs("strong",{children:[e.jsx("code",{children:"walkFiles"}),"：递归遍历，跳过噪声目录。"]})," 顶上的",e.jsx("code",{children:"IGNORE"})," 集合列了 ",e.jsx("code",{children:"node_modules"}),"、",e.jsx("code",{children:".git"}),"、",e.jsx("code",{children:"dist"})," 等目录。 想想 ",e.jsx("code",{children:"node_modules"})," 里动辄几万个文件——如果不跳过，每次 glob/grep 都要爬完它们， 慢得令人发指，还会用一堆第三方代码的命中淹没真正有用的结果。 所以遍历时遇到这些目录（以及任何点开头的隐藏目录）直接 ",e.jsx("code",{children:"continue"})," 不进去。 注意 ",e.jsx("code",{children:"readdir"})," 外层那个 ",e.jsx("code",{children:"try/catch"}),"：碰到读不了的目录就静默 ",e.jsx("code",{children:"return"})," 跳过， 一个权限问题不该让整次遍历崩掉。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:[e.jsx("code",{children:"globToRegExp"}),"：把 glob 模式编译成正则。"]})," 这是 glob/grep 共用的「翻译器」。 它逐字符扫描模式串，核心是两条规则：单个 ",e.jsx("code",{children:"*"})," 编译成 ",e.jsx("code",{children:"[^/]*"}),"（匹配除路径分隔符外的任意字符， 即「不跨目录」）；连续的 ",e.jsx("code",{children:"**"})," 编译成 ",e.jsx("code",{children:".*"}),"（匹配任意字符，",e.jsx("strong",{children:"含"})," ",e.jsx("code",{children:"/"}),"，即「可以跨任意层目录」）。 这正是 ",e.jsx("code",{children:"src/**/*.ts"})," 能匹配 ",e.jsx("code",{children:"src/a/b/c.ts"})," 的原因。 其余的正则元字符（",e.jsx("code",{children:"."}),"、",e.jsx("code",{children:"+"}),"、",e.jsx("code",{children:"("})," 等）则被转义成字面量， 免得用户模式里一个普通的点被当成「匹配任意字符」。最后用 ",e.jsx("code",{children:"^...$"})," 锚定，要求整条路径完整匹配。"]})]}),e.jsxs("p",{children:["这套「单星不跨目录、双星跨目录」的规则不是 forge 拍脑袋定的，而是",e.jsx("strong",{children:"沿袭了 Unix shell 和 .gitignore 的通行约定"}),"， 模型在训练语料里见过海量这样的 glob，所以它写 ",e.jsx("code",{children:"src/**/*.ts"})," 几乎不会出错。把这套语义对齐成「大家都熟的那套」， 本身就是降低模型出错率的设计。具体编译规则和例子列在下表："]}),e.jsx(r,{lang:"ts",title:"glob 元字符的编译规则与匹配示例",code:j}),e.jsx(s,{variant:"warn",title:"为什么必须用 ^...$ 锚定，又为什么转义元字符？",children:e.jsxs("p",{children:["两处细节，漏了任何一处都会出微妙的 bug。",e.jsx("strong",{children:"其一，锚定。"}),"正则默认是「子串匹配」——",e.jsx("code",{children:"/a\\.ts/"})," 能在 ",e.jsx("code",{children:"xax.tsy"})," 里命中。但 glob 的语义是「整条路径完整匹配」， 所以编译结果两头要加 ",e.jsx("code",{children:"^"})," 和 ",e.jsx("code",{children:"$"}),"，否则 ",e.jsx("code",{children:"*.ts"})," 会误中 ",e.jsx("code",{children:"a.tsx"})," 这种。",e.jsx("strong",{children:"其二，转义。"}),"用户模式里的 ",e.jsx("code",{children:"."})," 在 glob 语义里是个普通字符（文件名里的点）， 但在正则里 ",e.jsx("code",{children:"."})," 是「匹配任意字符」。不转义，",e.jsx("code",{children:"*.ts"})," 就会把 ",e.jsx("code",{children:"axts"})," 也算进来。 所以 ",e.jsx("code",{children:"globToRegExp"})," 里那一长串 ",e.jsx("code",{children:".+^${}()|[]"})," 的转义判断，是在",e.jsx("strong",{children:"把正则的「魔法」按住"}),"， 只放行我们想要的 ",e.jsx("code",{children:"*"})," / ",e.jsx("code",{children:"**"})," / ",e.jsx("code",{children:"?"})," 三种通配。"]})}),e.jsx("h3",{children:"遍历性能：为什么 IGNORE 这个集合是「省命」级别的优化"}),e.jsxs("p",{children:[e.jsx("code",{children:"walkFiles"})," 看着平平无奇，但它的性能完全取决于「跳过了什么」。设想一个普通的前端项目： 源码可能就几百个文件，",e.jsx("code",{children:"node_modules"})," 里却轻松上",e.jsx("strong",{children:"十万"}),"个文件。如果不跳过它："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"遍历本身慢得吓人"}),"：每次 glob/grep 都要 ",e.jsx("code",{children:"readdir"})," 上万个目录、",e.jsx("code",{children:"stat"})," 几十万个条目，几秒钟就这么没了。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"grep 还要读每个文件的内容"}),"：在十万个第三方文件里逐行跑正则，CPU 和磁盘 I/O 直接拉满。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"结果被噪声淹没"}),"：你搜一个函数名，命中里九成是某个依赖包里的同名符号，真正有用的那条反而被挤出 200 条上限之外。"]})]}),e.jsxs("p",{children:["所以那个不起眼的 ",e.jsx("code",{children:"IGNORE"})," 集合（外加「点开头目录一律跳过」），同时解决了",e.jsx("strong",{children:"速度"}),"和",e.jsx("strong",{children:"信噪比"}),"两个问题。 这也是为什么真实工具（ripgrep、fd 等）默认都尊重 ",e.jsx("code",{children:".gitignore"}),"——「该忽略的东西」和「版本控制忽略的东西」高度重合。 forge 这里用一个硬编码的小集合做了最朴素的近似，够用；要做得更讲究，下一步就是去解析项目的 ",e.jsx("code",{children:".gitignore"}),"。"]}),e.jsx(s,{variant:"note",title:"一个隐藏的健壮性细节：readdir 外层的 try/catch",children:e.jsxs("p",{children:["注意 ",e.jsx("code",{children:"walkFiles"})," 里 ",e.jsx("code",{children:"readdir"})," 套了个 ",e.jsx("code",{children:"try/catch"}),"，读不了的目录直接 ",e.jsx("code",{children:"return"})," 跳过。 为什么要这样？因为大目录树里",e.jsx("strong",{children:"难免有读不了的角落"}),"——权限不足的目录、悬空的符号链接、 挂载点失效的路径。如果不兜住，一个读不了的子目录就会让整次遍历抛异常、前功尽弃。 「局部失败不应该让整体崩溃」是遍历这类操作的通用纪律：跳过坏点，继续走完能走的。"]})}),e.jsx("h2",{children:"glob：按模式找文件"}),e.jsxs("p",{children:["有了 walk，glob 就只剩薄薄一层。看 ",e.jsx("code",{children:"src/tools/glob.ts"})," 的",e.jsx("strong",{children:"逐字"}),"内容："]}),e.jsx(r,{lang:"ts",title:"src/tools/glob.ts",code:h}),e.jsxs("p",{children:["逻辑一目了然：用 ",e.jsx("code",{children:"globToRegExp"})," 把模式编成正则 → ",e.jsx("code",{children:"walkFiles"})," 拿到所有文件的相对路径 →",e.jsx("code",{children:"filter"})," 出能匹配的、排个序。它回答的是「这项目里所有 X 文件都在哪」这类问题， 比如「找出所有测试文件 ",e.jsx("code",{children:"**/*.test.ts"}),"」。"]}),e.jsxs("p",{children:["重点看结尾的",e.jsx("strong",{children:"截断"}),"：",e.jsx("code",{children:"matched.slice(0, 200)"}),"。一个大仓库 ",e.jsx("code",{children:"**/*.ts"})," 可能命中几千个文件， 要是全部塞回给模型，既烧光上下文又毫无意义——模型根本读不过来。所以只回前 200 条， 多出来的用一句「…还有 N 个」提示模型「结果太多了，请把模式写得更精确」。 这是一种对模型注意力的保护。"]}),e.jsx("h2",{children:"grep：按内容搜"}),e.jsxs("p",{children:["glob 找的是文件",e.jsx("strong",{children:"名"}),"，grep 找的是文件",e.jsx("strong",{children:"内容"}),"。这是探索里最强的一招—— 「哪里用到了 ",e.jsx("code",{children:"readTool"})," 这个符号？」一搜便知。看 ",e.jsx("code",{children:"src/tools/grep.ts"})," 的",e.jsx("strong",{children:"逐字"}),"内容："]}),e.jsx(r,{lang:"ts",title:"src/tools/grep.ts",code:x}),e.jsx("p",{children:"grep 比前几个工具多扛了几件事，逐个讲："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"正则非法要友好报错。"})," 模型传来的 ",e.jsx("code",{children:"pattern"})," 直接 ",e.jsx("code",{children:"new RegExp"})," 可能抛异常 （比如未闭合的括号 ",e.jsx("code",{children:"("}),"）。我们用 ",e.jsx("code",{children:"try/catch"})," 把它兜住，回一条",e.jsx("code",{children:"isError: true"})," 的「正则非法」结果。模型看到后会自己修正模式重试，而不是让工具崩在这。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:[e.jsx("code",{children:"include"})," 用 glob 限定文件范围。"]})," 全仓搜往往太宽。 可选的 ",e.jsx("code",{children:"include"})," 参数（一个 glob，如 ",e.jsx("code",{children:"*.ts"}),"）会被同样编译成正则， 先把候选文件 ",e.jsx("code",{children:"filter"})," 一遍，只在符合范围的文件里搜。 「只在 TS 文件里找这个函数」就是靠它——又快又准。注意这里复用了 walk.ts 的",e.jsx("code",{children:"globToRegExp"}),"，一个翻译器两处用，这正是上面抽出共享模块的回报。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"命中行带「文件:行号」。"})," 每条命中拼成",e.jsx("code",{children:"`${f}:${i + 1}: ${lines[i].trim()}`"}),"——文件相对路径、冒号、行号、冒号、那一行内容（去掉首尾空白）。 这个格式和编辑器/终端里 grep 的输出一致，模型一看就懂， 而且",e.jsx("strong",{children:"行号让它能顺势接 read/edit"})," 去那个位置查看或修改，又一次工具间的接力。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"整体截断到 200 命中。"})," 注意这里有",e.jsx("strong",{children:"双重"}),"检查：外层循环每开一个文件前",e.jsx("code",{children:"if (hits.length >= 200) break"}),"，内层逐行匹配时再 ",e.jsx("code",{children:"break"})," 一次。 一旦凑够 200 条立刻收手，不再白读后面的文件——既省时间，也守住「回灌内容要节制」的底线。"]})]}),e.jsx(s,{variant:"tip",title:"200 条上限：回灌给模型的内容也要节制",children:e.jsxs("p",{children:["你会发现 glob 和 grep 都硬性卡了 ",e.jsx("strong",{children:"200 条"}),"上限。这不是随手写的魔法数字，背后是个真问题： 工具的输出会原样",e.jsx("strong",{children:"回灌进 messages 历史"}),"，而历史每长一截，下一轮 API 调用就更贵、更慢， 甚至可能撑爆上下文窗口。一次返回三千行搜索结果，模型既读不过来，又白白烧掉大量上下文预算。 所以「探索能力强」不等于「一次吐得越多越好」——恰恰相反，",e.jsx("strong",{children:"克制"}),"才是对的。 截断 + 一句「还有 N 个」的提示，等于在告诉模型：「结果太多了，把你的查询缩小一点再来。」 这是一种把模型往「精确提问」引导的设计。给工具的输出设上限，是生产级 Agent 的常规纪律，read 也一样 （超大文件同理需要节制，这里我们留作练习）。"]})}),e.jsxs(c,{title:"模型会怎么连用它们",children:[e.jsxs("p",{children:["单个工具看着平平无奇，威力在于",e.jsx("strong",{children:"串起来"}),"用。假设你问 forge： 「项目里 ",e.jsx("code",{children:"readFile"})," 都用在哪些地方，逻辑对吗？」模型很可能这样探索一遍："]}),e.jsxs("ol",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"list"})," 看根目录结构，发现源码在 ",e.jsx("code",{children:"src/"})," 下，于是对项目布局有了大致概念。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"glob"})," ",e.jsx("code",{children:"src/**/*.ts"})," 拿到所有 TS 文件的清单，知道总共有哪些文件可看。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"grep"})," ",e.jsx("code",{children:"readFile"}),"（用 ",e.jsx("code",{children:'include: "*.ts"'})," 限定范围）， 一下子拿到所有命中行，每条都带「文件:行号」，精确指向用到它的位置。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"read"})," 命中最多的那几个文件（带行号），把上下文完整看清，再回答你的问题。"]})]}),e.jsxs("p",{children:["关键是后半句：因为这四个调用",e.jsx("strong",{children:"全是只读"}),"，模型完全可以在",e.jsx("strong",{children:"同一轮"}),"里",e.jsx("strong",{children:"并行"}),"发出 （比如一口气 read 三个命中文件）——上一章的 ",e.jsx("code",{children:"runTools"})," 会用 ",e.jsx("code",{children:"Promise.all"})," 把它们一起跑掉， 不必一个等一个。「只读 = 可并行」在这里落了地：探索得既全面又快。 至于这套并行调度的更多细节，正是下一章要细抠的内容。"]})]}),e.jsx("h2",{children:"「只读」也不等于「绝对安全」：路径逃逸这道暗坎"}),e.jsxs("p",{children:["前面反复强调只读工具「安全」，但要把话说精确：它们的安全指的是",e.jsx("strong",{children:"不改变状态"}),"， 而不是「读什么都行」。这里藏着一个生产级 Agent 必须正视的问题——",e.jsx("strong",{children:"路径逃逸"}),"。 模型给的 ",e.jsx("code",{children:"path"})," 是不可信输入，如果它发来 ",e.jsx("code",{children:"../../etc/passwd"})," 或一个绝对路径 ",e.jsx("code",{children:"/etc/shadow"}),"，",e.jsx("code",{children:"resolve(ctx.cwd, path)"})," 会老老实实算出工作目录",e.jsx("strong",{children:"之外"}),"的路径，read 就真的把它读出来回灌给模型了。"]}),e.jsxs("p",{children:["本卷的 forge 为保持主干清爽，",e.jsx("strong",{children:"暂未"}),"做这层防护——它信任「在沙盒目录里跑」这个前提。但你要清楚正确的做法长什么样： 解析出绝对路径后，校验它",e.jsxs("strong",{children:["仍在 ",e.jsx("code",{children:"ctx.cwd"})," 之内"]}),"（比如 ",e.jsx("code",{children:"abs.startsWith(resolve(ctx.cwd))"}),"， 并小心符号链接绕过），否则拒绝。这和卷 3 的「权限闸门」是一脉相承的安全话题，只不过那里管的是写工具、这里管的是读工具的「读取范围」。"]}),e.jsx(s,{variant:"warn",title:"只读 ≠ 无害：把模型输入当攻击面来对待",children:e.jsxs("p",{children:["一个被恶意 prompt 注入引导的模型，可能试图用 read/grep 去",e.jsx("strong",{children:"窃取"}),"工作目录外的敏感文件 （",e.jsx("code",{children:".env"}),"、SSH 私钥、系统配置），再把内容回灌进对话——这本身就是一种数据泄露。 所以「只读」省掉的是「写坏东西」的风险，但",e.jsx("strong",{children:"没有"}),"省掉「读了不该读的东西」的风险。 生产级 Agent 对读工具同样要设范围边界：限定在工作目录内、显式排除敏感文件。本卷把它列为已知简化，留作进阶练习。"]})}),e.jsx("h2",{children:"并行的收益，到底有多大？"}),e.jsxs("p",{children:["「只读可并行」不是一句口号，它带来的速度差是",e.jsx("strong",{children:"实打实、肉眼可见"}),"的。关键在于：read/glob/grep 这类操作的耗时， 绝大部分是",e.jsx("strong",{children:"等 I/O"}),"（等磁盘把文件读出来、等目录列完），而不是 CPU 在算。等待是可以",e.jsx("strong",{children:"重叠"}),"的—— 三个文件一起发起读取，磁盘和操作系统会并发处理，总时间约等于最慢的那一个，而不是三者相加："]}),e.jsx(r,{lang:"ts",title:"串行 vs 并行：I/O 等待是重叠的，不是叠加的",code:a}),e.jsxs("p",{children:["模型探索一个陌生项目时，一轮里发出三五个 read/grep 是常态。串行跑，用户要干等好几个来回； 并行跑，几乎是一瞬间齐活。这就是上一章 ",e.jsx("code",{children:"runTools"})," 把只读工具塞进 ",e.jsx("code",{children:"Promise.all"})," 的全部理由—— 而它",e.jsx("strong",{children:"敢"}),"这么做的前提，正是这些工具被诚实地标了 ",e.jsx("code",{children:"readOnly: true"}),"、彼此真的互不影响。 「安全让 Agent 敢探索，并行让探索快」——两句话在这里合成了一句可量化的结论。"]}),e.jsx(n,{points:["本章给 Agent 装上四个只读工具：read 读文件、list 列目录、glob 按名找文件、grep 按内容搜——这是 Agent「先看后做」的探索能力。","四个工具都标 readOnly: true，换来两件事：安全（不改变世界，可放心探索）和可并行（互不影响，runTools 能用 Promise.all 一起跑）。","read 给每行加行号，是为后续 edit 精确定位铺路；用 resolve(ctx.cwd, path) 把相对路径锚定到工作目录；出错返回 isError 而非抛异常。","list 过滤隐藏文件、目录排前并加 / 后缀、默认列工作目录，让模型一眼看懂结构。","glob 和 grep 共用 walk.ts：walkFiles 递归遍历并跳过 node_modules/.git 等噪声目录，globToRegExp 把 * 编成 [^/]*、** 编成 .* 来支持跨目录匹配。","glob 按模式找文件、截断到 200 条防爆；grep 按正则搜内容，非法正则友好报错、include 限定范围、命中行带「文件:行号」、整体截断到 200 命中。","200 条上限是对模型注意力和上下文预算的保护——回灌内容要节制，截断 + 提示反而引导模型精确提问。","威力在于串用：list 看结构 → glob 找文件 → grep 搜符号 → read 读命中文件，而这些只读调用可在同一轮并行发出（呼应下一章的调度）。"]})]})}export{w as default};
