import{j as e}from"./index-I8-WI4LI.js";import{L as t,S as c}from"./Summary-BMIdTn04.js";import{K as r}from"./KeyIdea-Xbvwo63C.js";import{C as d}from"./Callout-ZgrsOCpc.js";import{C as l}from"./CodeBlock-CK6ncc4Q.js";import{E as s}from"./Example-CPIFvVrE.js";const i=`<template>
  <!-- 这一行 v-model -->
  <input v-model="text" />

  <!-- 完全等价于下面这一行（:value 绑值 + @input 回写） -->
  <input :value="text" @input="text = $event.target.value" />
</template>

<script setup>
import { ref } from 'vue'
const text = ref('')
<\/script>`,n=`<template>
  <!-- 文本框 / 文本域：绑 value，监听 input -->
  <input v-model="name" />
  <textarea v-model="bio"></textarea>

  <!-- 单选框 radio：绑 value，监听 change，结果是被选中那项的 value -->
  <label><input type="radio" value="男" v-model="gender" /> 男</label>
  <label><input type="radio" value="女" v-model="gender" /> 女</label>

  <!-- 单个复选框：绑 checked，结果是布尔值 -->
  <label><input type="checkbox" v-model="agree" /> 同意条款</label>

  <!-- 下拉选择：绑 value，监听 change -->
  <select v-model="city">
    <option value="hz">杭州</option>
    <option value="bj">北京</option>
  </select>
</template>

<script setup>
import { ref } from 'vue'
const name = ref('')
const bio = ref('')
const gender = ref('男')
const agree = ref(false)
const city = ref('hz')
<\/script>`,o=`<template>
  <!-- .lazy：改为监听 change 而非 input，即失焦/回车后才同步 -->
  <input v-model.lazy="msg" />

  <!-- .number：自动把输入转成数字（转不了则保留原值） -->
  <input v-model.number="age" />

  <!-- .trim：自动去掉首尾空白 -->
  <input v-model.trim="username" />

  <!-- 修饰符可以叠加 -->
  <input v-model.lazy.trim="title" />
</template>

<script setup>
import { ref } from 'vue'
const msg = ref('')
const age = ref(0)
const username = ref('')
const title = ref('')
<\/script>`,a=`<template>
  <!-- 多个复选框共享同一个【数组】，选中项的 value 会进数组 -->
  <label><input type="checkbox" value="vue" v-model="skills" /> Vue</label>
  <label><input type="checkbox" value="react" v-model="skills" /> React</label>
  <label><input type="checkbox" value="node" v-model="skills" /> Node</label>

  <p>已选：{{ skills.join('、') }}</p>
</template>

<script setup>
import { ref } from 'vue'
// 初值是数组，勾选哪个就把它的 value 推进来
const skills = ref([])
<\/script>`,h=`<!-- 子组件 MyInput.vue：用 defineModel 实现自定义 v-model -->
<template>
  <input :value="model" @input="model = $event.target.value" />
</template>

<script setup>
// defineModel 返回一个可读写的 ref，读它就是父级传入的值，
// 写它就会自动 emit update:modelValue 通知父级。
const model = defineModel()
<\/script>`,m=`<!-- 父组件：像用原生 input 一样用子组件 -->
<template>
  <MyInput v-model="keyword" />
  <p>父级看到的值：{{ keyword }}</p>
</template>

<script setup>
import { ref } from 'vue'
import MyInput from './MyInput.vue'
const keyword = ref('')
<\/script>`,x=`<!-- 不用 defineModel 时，v-model 的「手动」等价实现 -->
<template>
  <input
    :value="modelValue"
    @input="$emit('update:modelValue', $event.target.value)"
  />
</template>

<script setup>
// 组件上的 v-model 本质：父传 modelValue 这个 prop，
// 子通过 emit('update:modelValue', 新值) 回写。
defineProps(['modelValue'])
defineEmits(['update:modelValue'])
<\/script>`,p=`<template>
  <form class="login" @submit.prevent="onSubmit">
    <div>
      <label>用户名</label>
      <input v-model.trim="form.username" />
      <small v-if="errors.username">{{ errors.username }}</small>
    </div>

    <div>
      <label>密码</label>
      <input type="password" v-model="form.password" />
      <small v-if="errors.password">{{ errors.password }}</small>
    </div>

    <div>
      <label>年龄</label>
      <input type="number" v-model.number="form.age" />
    </div>

    <label>
      <input type="checkbox" v-model="form.agree" /> 我已阅读并同意条款
    </label>

    <button type="submit" :disabled="!form.agree">注册</button>
  </form>
</template>

<script setup>
import { reactive } from 'vue'

const form = reactive({
  username: '',
  password: '',
  age: null,
  agree: false,
})

const errors = reactive({ username: '', password: '' })

function validate() {
  errors.username = form.username.length < 3 ? '用户名至少 3 个字符' : ''
  errors.password = form.password.length < 6 ? '密码至少 6 位' : ''
  return !errors.username && !errors.password
}

function onSubmit() {
  if (!validate()) return
  console.log('提交：', { ...form })
  // 这里发起真正的注册请求……
}
<\/script>`;function y(){return e.jsxs("article",{children:[e.jsxs(t,{children:["表单是绝大多数应用都绕不开的交互：登录、注册、搜索、设置……Vue 用一个指令",e.jsx("code",{children:"v-model"})," 把「读取输入框的值」和「把值写回数据」这件来回的苦差事抹平成了一行。 这一章我们先拆穿 ",e.jsx("code",{children:"v-model"})," 的语法糖本质，再看它在各类表单控件上分别绑什么、 三个常用修饰符、多选 checkbox 绑数组的技巧，最后讲如何用 ",e.jsx("code",{children:"defineModel"}),"给自定义组件也装上 ",e.jsx("code",{children:"v-model"}),"，并附一个登录 / 注册表单的完整例子。"]}),e.jsx("h2",{children:"一、v-model 的本质：一段语法糖"}),e.jsxs(r,{children:[e.jsx("code",{children:"v-model"})," 不是什么新机制，它就是",e.jsxs("strong",{children:[e.jsx("code",{children:"v-bind"}),"（绑值）+ ",e.jsx("code",{children:"v-on"}),"（监听事件回写）"]}),"的组合简写。它替你把「把数据显示到控件上」和「用户一改就把新值存回数据」这两半连了起来， 形成",e.jsx("strong",{children:"双向绑定"}),"。"]}),e.jsx("p",{children:"看下面这组对照，上下两种写法在文本框上完全等价："}),e.jsx(l,{lang:"vue",title:"v-model 展开后的样子",code:i}),e.jsxs("p",{children:["理解这一点很关键：既然 ",e.jsx("code",{children:"v-model"})," 只是 ",e.jsx("code",{children:":value"})," 加上一个事件监听， 那么它在不同控件上「绑什么属性、听什么事件」自然就不一样——因为不同控件表达「当前值」的 方式本就不同。"]}),e.jsx("h2",{children:"二、v-model 在各类控件上分别绑什么"}),e.jsxs("p",{children:["Vue 会根据控件类型自动选择正确的属性和事件，你只管写 ",e.jsx("code",{children:"v-model"})," 就行。 但心里要清楚它背后做了什么："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"控件"}),e.jsx("th",{children:"绑定的属性"}),e.jsx("th",{children:"监听的事件"}),e.jsx("th",{children:"得到的值"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"text / textarea"}),e.jsx("td",{children:e.jsx("code",{children:"value"})}),e.jsx("td",{children:e.jsx("code",{children:"input"})}),e.jsx("td",{children:"字符串"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"checkbox（单个）"}),e.jsx("td",{children:e.jsx("code",{children:"checked"})}),e.jsx("td",{children:e.jsx("code",{children:"change"})}),e.jsx("td",{children:"布尔值"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"checkbox（多个）"}),e.jsx("td",{children:e.jsx("code",{children:"checked"})}),e.jsx("td",{children:e.jsx("code",{children:"change"})}),e.jsx("td",{children:"数组"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"radio"}),e.jsx("td",{children:e.jsx("code",{children:"checked"})}),e.jsx("td",{children:e.jsx("code",{children:"change"})}),e.jsx("td",{children:"被选项的 value"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"select（单选）"}),e.jsx("td",{children:e.jsx("code",{children:"value"})}),e.jsx("td",{children:e.jsx("code",{children:"change"})}),e.jsx("td",{children:"被选项的 value"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"select（多选）"}),e.jsx("td",{children:e.jsx("code",{children:"value"})}),e.jsx("td",{children:e.jsx("code",{children:"change"})}),e.jsx("td",{children:"数组"})]})]})]}),e.jsx(l,{lang:"vue",title:"各类控件上的 v-model",code:n}),e.jsxs(d,{variant:"info",title:"单个 checkbox 是布尔，多个是数组",children:["一个孤立的复选框，",e.jsx("code",{children:"v-model"})," 绑的是 ",e.jsx("strong",{children:"布尔值"}),"（勾上为 true）； 而当多个复选框共享同一个 ",e.jsx("code",{children:"v-model"})," 且初值为",e.jsx("strong",{children:"数组"}),"时，行为会切换成 「把选中项的 value 收集进数组」。这两种语义靠绑定值的类型区分，下一节专门演示。"]}),e.jsx("h2",{children:"三、三个常用修饰符：.lazy / .number / .trim"}),e.jsxs("p",{children:[e.jsx("code",{children:"v-model"})," 自带三个能省去手工处理的修饰符："]}),e.jsx(l,{lang:"vue",title:"v-model 修饰符",code:o}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:".lazy"}),"：把同步时机从 ",e.jsx("code",{children:"input"}),"（每次敲键）改成 ",e.jsx("code",{children:"change"}),"（失焦或回车后）。适合不想随每次按键都触发计算 / 校验的场景。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:".number"}),"：自动把输入字符串转成数字。表单里数字输入框几乎必加，否则你拿到的 是 ",e.jsx("code",{children:'"18"'})," 这样的字符串而非 ",e.jsx("code",{children:"18"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:".trim"}),"：自动去掉首尾空白，避免「用户名末尾多了个空格」这类隐蔽 bug。"]})]}),e.jsxs(d,{variant:"tip",title:"修饰符可叠加",children:["修饰符能链式组合，如 ",e.jsx("code",{children:"v-model.lazy.trim"}),"：失焦后同步、并去掉首尾空格。顺序不影响结果。"]}),e.jsx("h2",{children:"四、多选 checkbox 绑数组"}),e.jsxs("p",{children:["当你想让一组复选框收集成「选了哪些」的列表时，让它们共享同一个 ",e.jsx("code",{children:"v-model"}),"， 并把该数据初始化成",e.jsx("strong",{children:"数组"}),"。勾选某项就把它的 ",e.jsx("code",{children:"value"})," 推入数组， 取消勾选则移除。"]}),e.jsx(l,{lang:"vue",title:"多选复选框收集成数组",code:a}),e.jsx(s,{title:"为什么初值必须是数组",children:e.jsxs("p",{children:[e.jsx("code",{children:"v-model"})," 是靠绑定值的类型来决定行为的：初值是",e.jsx("code",{children:"ref(false)"})," 这种布尔，它就当单个开关；初值是",e.jsx("code",{children:"ref([])"})," 这种数组，它才进入「收集 value」模式。所以多选场景一定要把初值写成",e.jsx("code",{children:"[]"}),"，否则会退化成布尔语义、行为全乱。"]})}),e.jsx("h2",{children:"五、给自定义组件装上 v-model"}),e.jsxs("p",{children:[e.jsx("code",{children:"v-model"})," 不止能用在原生控件上，也能用在你自己写的组件上，实现父子组件之间的 双向绑定。它的约定是：父组件传入一个名为 ",e.jsx("code",{children:"modelValue"})," 的 prop，子组件通过",e.jsx("code",{children:"emit('update:modelValue', 新值)"})," 把变化通知回去。"]}),e.jsx(l,{lang:"vue",title:"手动实现：modelValue + update:modelValue",code:x}),e.jsxs("p",{children:["Vue 3.4 起提供了 ",e.jsx("code",{children:"defineModel"})," 宏，把上面这套样板代码压缩成一行。它返回一个 可读写的 ref：读它拿到的是父级传入的值，写它会自动触发对应的 ",e.jsx("code",{children:"update"})," 事件。"]}),e.jsx(l,{lang:"vue",title:"推荐写法：defineModel（子组件）",code:h}),e.jsx(l,{lang:"vue",title:"父组件像用原生控件一样使用它",code:m}),e.jsxs(d,{variant:"info",title:"defineModel 与手动写法的关系",children:[e.jsx("code",{children:"defineModel()"})," 本质上仍是 ",e.jsx("code",{children:"modelValue"})," prop 加",e.jsx("code",{children:"update:modelValue"})," 事件，只是把声明 prop、声明 emit、读写转发这三步合并掉了。 理解底层约定，遇到旧代码或需要自定义事件名时才不会懵。"]}),e.jsx("h2",{children:"六、受控思想与表单校验"}),e.jsxs(r,{children:["Vue 的表单是",e.jsx("strong",{children:"受控"}),"的：控件显示什么，永远以数据（如",e.jsx("code",{children:"form.username"}),"）为准；用户的每次输入都先经过 ",e.jsx("code",{children:"v-model"})," 写回数据， 再由数据驱动界面。换句话说，",e.jsx("strong",{children:"数据是唯一真相源"}),"，校验、联动、回填都围着它转。"]}),e.jsxs("p",{children:["正因为数据是唯一真相源，表单校验就变得直接：在提交前（或输入时）读这些响应式数据、 判断是否合规、把错误信息写进另一组响应式状态，模板用 ",e.jsx("code",{children:"v-if"})," 显示出来即可。"]}),e.jsx("h2",{children:"七、综合实战：登录 / 注册表单"}),e.jsxs("p",{children:["下面这个表单把本章要点全用上了：",e.jsx("code",{children:"v-model.trim"})," 处理用户名、",e.jsx("code",{children:"v-model.number"})," 处理年龄、单个 checkbox 绑布尔控制按钮可用性、",e.jsx("code",{children:"@submit.prevent"})," 阻止默认刷新、提交前做校验并用 ",e.jsx("code",{children:"v-if"})," 显示错误。"]}),e.jsx(l,{lang:"vue",title:"可运行的登录 / 注册表单",code:p}),e.jsxs(s,{title:"读懂这个表单的设计",children:[e.jsxs("p",{children:["1. 用 ",e.jsx("code",{children:"reactive"})," 把整个表单收进一个对象 ",e.jsx("code",{children:"form"}),"，提交时",e.jsx("code",{children:"{ ...form }"})," 一把取走，比一堆散落的 ref 更整洁。"]}),e.jsxs("p",{children:["2. 年龄用 ",e.jsx("code",{children:".number"}),"，确保后端拿到的是数字而非字符串。"]}),e.jsxs("p",{children:["3. ",e.jsx("code",{children:':disabled="!form.agree"'})," 让「同意条款」直接驱动按钮可用性——数据驱动 UI 的典型。"]}),e.jsxs("p",{children:["4. 校验失败时把信息写进 ",e.jsx("code",{children:"errors"}),"，模板用 ",e.jsx("code",{children:"v-if"})," 渲染，是受控表单的标准做法。"]})]}),e.jsxs(d,{variant:"warn",title:"前端校验不能替代后端校验",children:["前端校验是为了体验（即时反馈），但它",e.jsx("strong",{children:"可被绕过"}),"。任何安全相关的规则 （唯一性、权限、防注入）都必须在后端再校验一遍，前端校验只是第一道而非唯一一道防线。"]}),e.jsx(c,{points:["v-model 是 v-bind 绑值加 v-on 监听回写的语法糖，本质就是双向绑定的简写。","不同控件 v-model 绑的属性 / 事件不同：text 绑 value 听 input，checkbox/radio 绑 checked 听 change，select 绑 value 听 change。","单个 checkbox 得到布尔值，多个 checkbox 共享数组型 v-model 则收集选中项的 value。","三个修饰符：.lazy 改为 change 时机同步，.number 转数字，.trim 去首尾空白，且可叠加。","组件上的 v-model 约定是 modelValue prop 加 update:modelValue 事件；defineModel 把这套样板压成一行。","Vue 表单是受控的，数据是唯一真相源，校验围绕响应式数据展开，用 v-if 显示错误信息。","前端校验只为体验，可被绕过，安全相关规则必须在后端再次校验。"]})]})}export{y as default};
