import{j as e}from"./index-I8-WI4LI.js";import{L as s,S as r}from"./Summary-BMIdTn04.js";import{K as l}from"./KeyIdea-Xbvwo63C.js";import{C as c}from"./Callout-ZgrsOCpc.js";import{C as t}from"./CodeBlock-CK6ncc4Q.js";import{E as n}from"./Example-CPIFvVrE.js";const d=`<script setup>
import { ref, computed } from 'vue'

const firstName = ref('Ada')
const lastName = ref('Lovelace')

// computed 接收一个 getter，返回一个只读的 ref
const fullName = computed(() => {
  console.log('计算 fullName')   // 只在依赖变化时才打印
  return firstName.value + ' ' + lastName.value
})
<\/script>

<template>
  <!-- 模板里自动解包，直接写 fullName -->
  <p>{{ fullName }} / {{ fullName }} / {{ fullName }}</p>
</template>`,o=`import { ref, computed } from 'vue'

const n = ref(2)
const square = computed(() => {
  console.log('squaring')
  return n.value * n.value
})

// 多次访问，但依赖 n 没变 —— getter 只执行一次，其余命中缓存
console.log(square.value)  // 打印 "squaring"，得 4
console.log(square.value)  // 不打印，直接返回缓存 4
console.log(square.value)  // 不打印，直接返回缓存 4

n.value = 3                // 依赖变了，缓存失效
console.log(square.value)  // 再次打印 "squaring"，得 9`,i=`// 对比：用方法实现「派生」没有缓存
function squareFn() {
  console.log('squaring')   // 每次调用都执行
  return n.value * n.value
}
// 模板里 {{ squareFn() }} 写三次，就执行三次

// computed 则只在依赖变化时重算一次，之后命中缓存`,a=`<script setup>
import { ref, computed } from 'vue'

const firstName = ref('Ada')
const lastName = ref('Lovelace')

// 可写计算属性：同时提供 get 与 set
const fullName = computed({
  get() {
    return firstName.value + ' ' + lastName.value
  },
  set(value) {
    // 给 fullName 赋值时，反向拆解到两个源 ref
    const [first, last] = value.split(' ')
    firstName.value = first
    lastName.value = last
  },
})

fullName.value = 'Grace Hopper'   // 触发 set
console.log(firstName.value)      // 'Grace'
<\/script>`,h=`<script setup>
import { ref, watch } from 'vue'

const count = ref(0)

// watch(源, 回调)：源变化时，回调拿到 (新值, 旧值)
watch(count, (newVal, oldVal) => {
  console.log(\`count 从 \${oldVal} 变成了 \${newVal}\`)
})

// 默认是「惰性」的：定义时不执行回调，只有 count 真正变化才触发
count.value++   // 打印 "count 从 0 变成了 1"
<\/script>`,x=`import { ref, watch } from 'vue'

const x = ref(0)
const y = ref(0)

// 侦听单个 ref
watch(x, (val) => console.log('x =', val))

// 侦听 getter（来自 reactive 的属性，或任意表达式）
watch(() => x.value + y.value, (sum) => console.log('和 =', sum))

// 侦听多个源：新旧值都是数组
watch([x, y], ([nx, ny], [ox, oy]) => {
  console.log(\`x: \${ox}->\${nx}, y: \${oy}->\${ny}\`)
})`,u=`import { ref, watch } from 'vue'

const userId = ref(1)

// immediate: true —— 定义时立即执行一次回调（旧值为 undefined）
watch(userId, (id) => {
  fetchUser(id)
}, { immediate: true })`,j=`<script setup>
import { ref, watchEffect } from 'vue'

const a = ref(1)
const b = ref(2)

// watchEffect：立即执行一次，并自动收集回调里用到的响应式依赖
watchEffect(() => {
  // 这里读了 a 和 b，于是它们成为依赖；任一变化都会重跑
  console.log('a + b =', a.value + b.value)
})

a.value = 10   // 自动重跑，打印 "a + b = 12"
<\/script>`,p=`import { ref, watch } from 'vue'

const count = ref(0)

// flush 控制回调相对「DOM 更新」的时机
watch(count, cb, { flush: 'pre' })   // 默认：DOM 更新「之前」
watch(count, cb, { flush: 'post' })  // DOM 更新「之后」，能拿到最新 DOM
watch(count, cb, { flush: 'sync' })  // 同步触发，每次变更都立即执行（慎用）`,m=`import { ref, watch } from 'vue'

const id = ref(1)

watch(id, (newId, oldId, onCleanup) => {
  const controller = new AbortController()
  fetch(\`/api/user/\${newId}\`, { signal: controller.signal })

  // 注册清理：下次回调触发前（或侦听停止时）调用，
  // 用来取消上一次还没结束的副作用，避免竞态
  onCleanup(() => controller.abort())
})`,f=`import { reactive, ref, watch } from 'vue'

const state = reactive({ nested: { count: 0 } })

// 坑：直接侦听 reactive 对象，Vue 会「隐式」深度侦听，
// 但此时新值和旧值是「同一个引用」，oldVal === newVal
watch(state, (newVal, oldVal) => {
  // newVal 与 oldVal 指向同一个对象，拿不到真正的旧值
})

// 侦听一个对象型的 ref / getter 时，默认「浅」，
// 改内部属性不会触发；要 deep 才会深入比对
watch(() => state.nested, (n) => {
  // 改 state.nested.count 不触发，除非加 { deep: true }
}, { deep: true })`,w=`<script setup>
import { ref, watch } from 'vue'

const keyword = ref('')
const results = ref([])

watch(keyword, (newKeyword, oldKeyword, onCleanup) => {
  // 空输入直接清空，不发请求
  if (!newKeyword.trim()) {
    results.value = []
    return
  }

  // 防抖：300ms 内若关键词又变了，先取消这次定时器
  const timer = setTimeout(async () => {
    const controller = new AbortController()
    // 同时用 onCleanup 取消还在飞的请求，避免「旧请求后到」覆盖新结果
    onCleanup(() => controller.abort())

    const res = await fetch(
      \`/api/search?q=\${encodeURIComponent(newKeyword)}\`,
      { signal: controller.signal },
    )
    results.value = await res.json()
  }, 300)

  // 关键：清理上一次的定时器，实现防抖
  onCleanup(() => clearTimeout(timer))
})
<\/script>

<template>
  <input v-model="keyword" placeholder="输入关键词搜索" />
  <ul>
    <li v-for="item in results" :key="item.id">{{ item.title }}</li>
  </ul>
</template>`;function b(){return e.jsxs("article",{children:[e.jsxs(s,{children:["有了 ",e.jsx("code",{children:"ref"})," 和 ",e.jsx("code",{children:"reactive"})," 这两块响应式基石，接下来要解决两类常见需求：",e.jsx("strong",{children:"从现有状态派生出新值"}),"，以及",e.jsx("strong",{children:"在状态变化时执行副作用"}),"。 前者交给 ",e.jsx("code",{children:"computed"}),"，后者交给 ",e.jsx("code",{children:"watch"})," / ",e.jsx("code",{children:"watchEffect"}),"。 这一章讲透三者的差异、缓存机制、侦听时机与副作用清理，并用一个「根据搜索词防抖请求」的 例子把它们串起来。"]}),e.jsx("h2",{children:"一、computed：带缓存的派生值"}),e.jsxs("p",{children:[e.jsx("code",{children:"computed"})," 接收一个 getter 函数，返回一个",e.jsx("strong",{children:"只读的响应式 ref"}),"。 它的值由 getter 算出，并且会随 getter 里用到的响应式依赖自动更新。模板里用它和用普通 ref 一样，自动解包。"]}),e.jsx(t,{lang:"vue",title:"computed 基本用法",code:d}),e.jsxs(l,{children:[e.jsx("code",{children:"computed"})," 最关键的特性是",e.jsx("strong",{children:"缓存"}),"：只要它依赖的响应式数据没变， 无论你访问它多少次，getter 都",e.jsx("strong",{children:"只执行一次"}),"，其余访问直接返回上一次的结果。 依赖变化时，缓存才失效、下次访问时重算。"]}),e.jsx(t,{lang:"js",title:"缓存：依赖不变就不重算",code:o}),e.jsxs("p",{children:["这正是 ",e.jsx("code",{children:"computed"})," 区别于「普通方法」的地方。如果你在模板里写",e.jsx("code",{children:"{{ squareFn() }}"}),"，那么模板每渲染一次就调用一次函数，没有任何缓存； 而 ",e.jsx("code",{children:"computed"})," 在依赖不变时直接吃缓存，对于开销大的派生计算能省下大量重复运算。"]}),e.jsx(t,{lang:"js",title:"对比：方法没有缓存",code:i}),e.jsx("h2",{children:"二、可写的 computed"}),e.jsxs("p",{children:[e.jsx("code",{children:"computed"})," 默认只读，但当你确实需要「写回去」时，可以传一个含",e.jsx("code",{children:"get"})," 与 ",e.jsx("code",{children:"set"})," 的对象。读取走 ",e.jsx("code",{children:"get"}),"，赋值走 ",e.jsx("code",{children:"set"}),"， 在 ",e.jsx("code",{children:"set"})," 里把值反向拆解到底层源。"]}),e.jsx(t,{lang:"vue",title:"可写计算属性（get / set）",code:a}),e.jsxs(c,{variant:"info",title:"可写 computed 的典型场景",children:["最常见的是配合 ",e.jsx("code",{children:"v-model"}),"：让一个绑定值在读取时做格式化、在写入时做反向解析， 或把一个全局状态适配成本地可双向绑定的形态。但别滥用——多数派生值是只读的。"]}),e.jsx("h2",{children:"三、watch：显式侦听"}),e.jsxs("p",{children:[e.jsx("code",{children:"watch"})," 用来",e.jsx("strong",{children:"显式"}),"指定「侦听什么、变化了做什么」。它接收一个侦听源 和一个回调，源变化时回调被调用，并拿到",e.jsx("strong",{children:"新值与旧值"}),"。"]}),e.jsx(t,{lang:"vue",title:"watch 基本用法",code:h}),e.jsxs("p",{children:[e.jsx("code",{children:"watch"})," 默认是",e.jsx("strong",{children:"惰性"}),"的：定义时",e.jsx("em",{children:"不会"}),"立即执行回调， 只有侦听源真正发生变化才触发。侦听源可以有多种形态："]}),e.jsx(t,{lang:"js",title:"watch 的多种侦听源",code:x}),e.jsxs("ul",{children:[e.jsx("li",{children:"一个 ref：直接传它本身。"}),e.jsx("li",{children:"一个 getter 函数：用于侦听 reactive 的某个属性，或任意计算表达式。"}),e.jsx("li",{children:"一个由源组成的数组：侦听多个源，回调的新旧值也是对应的数组。"})]}),e.jsxs("p",{children:["如果希望「定义时就先跑一次」，传 ",e.jsx("code",{children:"{ immediate: true }"}),"——这在 「组件一挂载就要按当前参数拉数据」的场景非常常用。"]}),e.jsx(t,{lang:"js",title:"immediate：定义时立即执行一次",code:u}),e.jsx("h2",{children:"四、watchEffect：自动收集依赖、立即执行"}),e.jsxs("p",{children:[e.jsx("code",{children:"watchEffect"})," 是另一种侦听方式：你",e.jsx("strong",{children:"不显式声明源"}),"， 而是直接写一个副作用函数；Vue 会",e.jsx("strong",{children:"立即执行它一次"}),"，并在执行过程中",e.jsx("strong",{children:"自动收集"}),"用到的所有响应式依赖，之后任一依赖变化都会重跑该函数。"]}),e.jsx(t,{lang:"vue",title:"watchEffect 自动追踪依赖",code:j}),e.jsxs(c,{variant:"warn",title:"watchEffect 拿不到旧值",children:["因为没有显式声明源，",e.jsx("code",{children:"watchEffect"})," 的回调",e.jsx("strong",{children:"拿不到新旧值"}),"； 它也总是立即执行（无法惰性）。需要对比新旧值、或想精确控制只在某个源变化时触发，就用",e.jsx("code",{children:"watch"}),"。"]}),e.jsx("h2",{children:"五、三者怎么选：computed vs watch vs watchEffect"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"computed"}),e.jsx("th",{children:"watch"}),e.jsx("th",{children:"watchEffect"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"用途"}),e.jsx("td",{children:"派生出新值"}),e.jsx("td",{children:"变化时跑副作用"}),e.jsx("td",{children:"变化时跑副作用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"有返回值"}),e.jsx("td",{children:"有（只读 ref）"}),e.jsx("td",{children:"无"}),e.jsx("td",{children:"无"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"缓存"}),e.jsx("td",{children:"有"}),e.jsx("td",{children:"—"}),e.jsx("td",{children:"—"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"声明依赖"}),e.jsx("td",{children:"自动（读哪个算哪个）"}),e.jsx("td",{children:"显式指定源"}),e.jsx("td",{children:"自动收集"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能拿新旧值"}),e.jsx("td",{children:"—"}),e.jsx("td",{children:"能"}),e.jsx("td",{children:"不能"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"是否立即执行"}),e.jsx("td",{children:"惰性求值"}),e.jsx("td",{children:"默认否（可 immediate）"}),e.jsx("td",{children:"是"})]})]})]}),e.jsxs("p",{children:["经验法则：",e.jsxs("strong",{children:["要算出一个值用 ",e.jsx("code",{children:"computed"})]}),"（尤其是会被多处反复读取、 或计算偏重的派生）；",e.jsxs("strong",{children:["要在状态变化时做事（请求、写 localStorage、操作 DOM）用",e.jsx("code",{children:"watch"})]}),"，并且需要对比新旧值或惰性触发时优先选它；",e.jsxs("strong",{children:["副作用依赖多个源、懒得一一列出、且不关心旧值时用 ",e.jsx("code",{children:"watchEffect"})]}),"。"]}),e.jsx("h2",{children:"六、flush 时机与清理副作用"}),e.jsxs("p",{children:["侦听回调相对「组件 DOM 更新」的执行时机由 ",e.jsx("code",{children:"flush"})," 选项控制："]}),e.jsx(t,{lang:"js",title:"flush：pre / post / sync",code:p}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"'pre'"}),"（默认）：在组件 DOM 更新",e.jsx("strong",{children:"之前"}),"触发。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"'post'"}),"：在 DOM 更新",e.jsx("strong",{children:"之后"}),"触发，回调里能读到最新的 DOM。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"'sync'"}),"：每次响应式数据变化就",e.jsx("strong",{children:"同步"}),"触发，频繁变化时开销大，慎用。"]})]}),e.jsxs("p",{children:["当回调里启动了异步操作（请求、定时器、订阅），就要考虑",e.jsx("strong",{children:"清理"}),"：在下一次回调触发前， 把上一次还没结束的副作用取消掉，否则会出现「旧请求晚于新请求返回、用旧数据覆盖新数据」的竞态。 回调的第三个参数 ",e.jsx("code",{children:"onCleanup"})," 就是为此而生。"]}),e.jsx(t,{lang:"js",title:"onCleanup：取消上一次的副作用",code:m}),e.jsx("h2",{children:"七、深度侦听 deep 与对象的坑"}),e.jsx("p",{children:"当侦听源是对象时，行为有几处容易踩坑，需要单独说清："}),e.jsx(t,{lang:"js",title:"对象侦听的两个坑",code:f}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"直接侦听 reactive 对象会隐式深度侦听"}),"，但此时回调里的新值和旧值",e.jsx("strong",{children:"指向同一个引用"}),"（",e.jsx("code",{children:"newVal === oldVal"}),"），拿不到真正的旧值。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"侦听一个返回对象的 getter 时默认是「浅」的"}),"：只在该对象引用整体被替换时触发， 改它的内部属性不会触发。要响应内部变化，得显式加 ",e.jsx("code",{children:"{ deep: true }"}),"。"]})]}),e.jsxs(c,{variant:"warn",title:"deep 不是免费的",children:[e.jsx("code",{children:"deep: true"})," 会递归遍历对象的每一层来建立依赖，",e.jsx("strong",{children:"对大对象开销不小"}),"。 能精确侦听到具体属性（用 getter 指到 ",e.jsx("code",{children:"state.a.b"}),"）时，就别盲目开 deep。"]}),e.jsx("h2",{children:"八、动手：根据搜索词防抖请求"}),e.jsxs("p",{children:["把本章的概念串起来：侦听搜索词 ",e.jsx("code",{children:"keyword"}),"，用户停止输入 300ms 后才真正发请求 （防抖），同时用 ",e.jsx("code",{children:"onCleanup"})," 在新输入到来时取消上一次的定时器和还在飞的请求， 从而既减少无谓请求，又避免旧响应覆盖新结果的竞态。"]}),e.jsx(n,{title:"防抖搜索：watch + onCleanup",children:e.jsxs("p",{children:["关键有三处：① 空输入直接清空、不发请求；② ",e.jsx("code",{children:"setTimeout"})," 实现 300ms 防抖； ③ 两个 ",e.jsx("code",{children:"onCleanup"})," 分别负责「清掉上一次的定时器」和「中止上一次还没回来的请求」。"]})}),e.jsx(t,{lang:"vue",title:"防抖搜索组件",code:w}),e.jsxs("p",{children:["这个例子里 ",e.jsx("code",{children:"watch"})," 的优势体现得淋漓尽致：它惰性触发（不输入就不动）、能拿到新值 去发请求、还能用 ",e.jsx("code",{children:"onCleanup"})," 干净地收拾上一轮副作用——这些都是",e.jsx("code",{children:"computed"})," 做不到、",e.jsx("code",{children:"watchEffect"})," 做起来别扭的事。"]}),e.jsx("h2",{children:"九、小结"}),e.jsxs("p",{children:["这一章我们把 Vue 3 的「派生与侦听」三件套讲全了：",e.jsx("code",{children:"computed"})," 算值且带缓存，",e.jsx("code",{children:"watch"})," 显式侦听、能拿新旧值、惰性可 immediate，",e.jsx("code",{children:"watchEffect"}),"自动收集依赖并立即执行。再加上 ",e.jsx("code",{children:"flush"})," 时机、",e.jsx("code",{children:"onCleanup"})," 清理、 以及 ",e.jsx("code",{children:"deep"})," 与对象侦听的坑，你已经能从容应对绝大多数「状态变了之后该怎么办」的场景。"]}),e.jsx(r,{points:["computed 是带缓存的派生值：依赖不变时 getter 只执行一次、多次访问命中缓存，优于无缓存的普通方法。","computed 默认只读，传 get/set 即可写，常配合 v-model 做格式化 / 反向解析。","watch 显式侦听一个或多个源，能拿到新旧值，默认惰性（不立即执行），加 immediate 才在定义时先跑一次。","watchEffect 立即执行并自动收集回调里用到的依赖，但拿不到新旧值、无法惰性。","flush 控制回调时机（pre 默认 / post 拿最新 DOM / sync 同步慎用）；onCleanup 取消上一次副作用以避免竞态。","深度侦听：直接侦 reactive 会隐式深度但新旧值同引用；侦对象 getter 默认浅、需 deep: true，而 deep 对大对象开销不小。"]})]})}export{b as default};
