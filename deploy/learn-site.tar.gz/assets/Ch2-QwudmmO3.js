import{j as e}from"./index-D-xLQIFq.js";import{L as o,S as r}from"./Summary-YJHOQU45.js";import{K as t}from"./KeyIdea-D9fwNcvs.js";import{C as n}from"./Callout-Bp0vMJus.js";import{C as s}from"./CodeBlock-DX_K20PW.js";import{E as i}from"./Example-JUHxJgjQ.js";import{P as c}from"./Practice-Cvuj-BXK.js";const l=`# 大模型 API 的核心是一个"对话消息列表"
messages = [
    {"role": "system", "content": "你是一个简洁的中文助手。"},   # 设定人设
    {"role": "user", "content": "用一句话介绍 Python。"},          # 用户说的话
]
# 模型会读完整个列表，然后续上一条 {"role": "assistant", "content": "..."}`,a=`# 百炼提供 OpenAI 兼容接口，所以直接用官方 openai SDK 即可
pip install openai`,d=`# 把 API Key 存进环境变量，绝不写进代码！
export DASHSCOPE_API_KEY="sk-你的真实密钥"

# 验证一下（Linux / macOS）
echo $DASHSCOPE_API_KEY`,p=`import os
from openai import OpenAI

# 用环境变量读 key；base_url 指向百炼的 OpenAI 兼容端点
client = OpenAI(
    api_key=os.environ["DASHSCOPE_API_KEY"],
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
)

resp = client.chat.completions.create(
    model="qwen-plus",
    messages=[
        {"role": "system", "content": "你是一个简洁的中文助手。"},
        {"role": "user", "content": "用一句话介绍 Python。"},
    ],
)

# 取出模型回复的文本
print(resp.choices[0].message.content)`,h="Python 是一门语法简洁、易学好用的通用编程语言，广泛用于数据分析、人工智能和 Web 开发。",x=`# 回复藏在 choices[0].message.content 里
reply = resp.choices[0].message.content
print(reply)

# 还能看本次用了多少 token（用来估算费用）
print("输入 token:", resp.usage.prompt_tokens)
print("输出 token:", resp.usage.completion_tokens)`,m=`import os

# 正确：从环境变量读取，代码里看不到密钥
api_key = os.environ["DASHSCOPE_API_KEY"]

# 更稳妥：用 os.getenv，没设置时返回 None 而不是直接报错
api_key = os.getenv("DASHSCOPE_API_KEY")
if not api_key:
    raise RuntimeError("请先设置环境变量 DASHSCOPE_API_KEY")`,j=`# 千万别这样！硬编码密钥，一旦提交到 Git 就泄露了
client = OpenAI(api_key="sk-1234567890abcdef")   # ❌ 危险`,g=`import os
from openai import OpenAI

client = OpenAI(
    api_key=os.environ["DASHSCOPE_API_KEY"],
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
)

# 维护一个 messages 列表，就是"多轮对话"的全部秘密
messages = [
    {"role": "system", "content": "你是一个友好的中文助手，回答简洁。"},
]

def ask(question):
    messages.append({"role": "user", "content": question})   # 1. 加入用户提问
    resp = client.chat.completions.create(
        model="qwen-plus",
        messages=messages,                                    # 2. 把完整历史发过去
    )
    answer = resp.choices[0].message.content
    messages.append({"role": "assistant", "content": answer}) # 3. 把回复也存回历史
    return answer

print(ask("我叫小明，今年 18 岁。"))
print(ask("我多大了？"))     # 模型能记住，因为历史里有上一轮`,u=`你好小明！很高兴认识你。
你今年 18 岁。`,y=`import os
from openai import OpenAI

client = OpenAI(
    api_key=os.environ["DASHSCOPE_API_KEY"],
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
)

messages = [{"role": "system", "content": "你是一个友好的中文助手。"}]

print("开始聊天（输入 q 退出）")
while True:
    user_input = input("你：")
    if user_input == "q":
        break
    messages.append({"role": "user", "content": user_input})
    try:
        resp = client.chat.completions.create(model="qwen-plus", messages=messages)
        answer = resp.choices[0].message.content
        messages.append({"role": "assistant", "content": answer})
        print("助手：", answer)
    except Exception as e:
        print("出错了：", e)`;function O(){return e.jsxs("article",{children:[e.jsxs(o,{children:["上一章学会了发 HTTP 请求，这一章就用它来做一件激动人心的事：",e.jsx("strong",{children:"调用大模型"}),"。 我们用阿里云百炼（Qwen）作后端，借助它的 OpenAI 兼容接口，几行代码就能和大模型对话。 本章讲清楚：大模型 API 长什么样、如何用环境变量安全保管密钥、怎么发一次对话、 怎么维护一个 ",e.jsx("code",{children:"messages"})," 列表实现",e.jsx("strong",{children:"多轮对话"}),"——全程给可运行的完整代码。"]}),e.jsx("h2",{children:"一、大模型 API 长什么样"}),e.jsxs("p",{children:["大模型对话 API 的核心，是一个",e.jsx("strong",{children:"消息列表"}),"。每条消息有 ",e.jsx("code",{children:"role"}),"（角色） 和 ",e.jsx("code",{children:"content"}),"（内容）。你把对话历史发过去，模型读完后续上一条它的回复。"]}),e.jsx(s,{lang:"python",title:"messages 的结构",code:l}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"role"}),e.jsx("th",{children:"含义"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"system"})}),e.jsx("td",{children:"系统设定，定义助手的人设、风格、规则（放在最前）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"user"})}),e.jsx("td",{children:"用户说的话"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"assistant"})}),e.jsx("td",{children:"模型之前的回复（多轮时要带上）"})]})]})]}),e.jsxs(t,{children:["记住这一点：和大模型对话，本质就是",e.jsx("strong",{children:"不断往 messages 列表里追加消息，再整个发过去"}),'。 模型本身不"记得"任何东西——它的"记忆"全靠你每次把历史一起带上。']}),e.jsx("h2",{children:"二、准备工作"}),e.jsx("h3",{children:"安装 SDK"}),e.jsxs("p",{children:["百炼兼容 OpenAI 接口，所以直接用官方 ",e.jsx("code",{children:"openai"})," 库最省事。"]}),e.jsx(s,{lang:"bash",title:"安装 openai",code:a}),e.jsx("h3",{children:"安全保管 API Key"}),e.jsxs("p",{children:["从百炼控制台拿到 API Key 后，",e.jsx("strong",{children:"存进环境变量"}),"，代码里只读环境变量。 这样密钥不会出现在源码中，也不会被误提交到 Git。"]}),e.jsx(s,{lang:"bash",title:"导出环境变量",code:d}),e.jsxs(n,{variant:"warn",title:"绝对不要硬编码密钥",children:["把 ",e.jsx("code",{children:"sk-"})," 开头的密钥直接写进代码、提交到 Git，是最常见也最危险的错误—— 一旦泄露，别人可以盗刷你的额度。永远用环境变量。"]}),e.jsx(s,{lang:"python",title:"反面教材（别学）",code:j}),e.jsxs("p",{children:["正确做法是用 ",e.jsx("code",{children:"os.getenv"})," 读取，并在缺失时给出友好提示："]}),e.jsx(s,{lang:"python",title:"安全读取密钥",code:m}),e.jsx("h2",{children:"三、发出第一次对话"}),e.jsxs("p",{children:["下面是一段完整、可直接运行的代码。它把 ",e.jsx("code",{children:"base_url"})," 指向百炼端点，发一条消息并打印回复。"]}),e.jsx(s,{lang:"python",title:"first_chat.py",code:p}),e.jsx(s,{lang:"text",title:"运行结果",code:h}),e.jsx(i,{title:"逐行看懂",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"OpenAI(api_key=..., base_url=...)"}),"：创建客户端。",e.jsx("code",{children:"base_url"})," 是把请求转向百炼的关键，结尾 ",e.jsx("code",{children:"/v1"})," 不能少。"]}),e.jsxs("li",{children:[e.jsx("code",{children:'model="qwen-plus"'}),"：选用的模型。想更强用 ",e.jsx("code",{children:"qwen-max"}),"，更快更省用 ",e.jsx("code",{children:"qwen-turbo"}),"。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"messages=[...]"}),"：本次对话的消息列表，system 设人设、user 是提问。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"resp.choices[0].message.content"}),"：模型回复就藏在这里。"]})]})}),e.jsx("h2",{children:"四、读取回复"}),e.jsxs("p",{children:["回复永远在 ",e.jsx("code",{children:"choices[0].message.content"}),"。",e.jsx("code",{children:"choices"})," 是个列表 （API 允许一次返回多个候选回复），通常取第 0 个。",e.jsx("code",{children:"usage"})," 里还能看到 token 用量。"]}),e.jsx(s,{lang:"python",title:"取回复与 token 用量",code:x}),e.jsx("h2",{children:"五、多轮对话：维护 messages 列表"}),e.jsxs("p",{children:['模型不会自己记住上一句。要让它"记得"，每次请求都得把',e.jsx("strong",{children:"完整的对话历史"}),"带上。 做法就是：把用户提问和模型回复，都",e.jsx("strong",{children:"追加进同一个 messages 列表"}),"。"]}),e.jsx(s,{lang:"python",title:"multi_turn.py",code:g}),e.jsx(s,{lang:"text",title:"运行结果",code:u}),e.jsx(t,{children:'多轮对话的三步循环：① 把用户输入 append 进 messages；② 整个 messages 发给模型； ③ 把模型回复也 append 回 messages。下一轮历史就完整了，模型自然"记得"前文。'}),e.jsx(n,{variant:"note",title:"历史会越来越长",children:"消息越积越多，token 用量（和费用）也会上涨，太长还可能超出模型上限。 真实应用里常需要裁剪或总结旧历史——这是后话，先理解机制。"}),e.jsx("h2",{children:"六、做一个能聊天的小程序"}),e.jsxs("p",{children:["把多轮逻辑放进一个 ",e.jsx("code",{children:"while"})," 循环，就是一个命令行聊天机器人了。 加上异常处理，网络抖动也不至于直接崩溃。"]}),e.jsx(s,{lang:"python",title:"chat_bot.py",code:y}),e.jsxs("p",{children:["运行后你就能在终端里和 Qwen 连续对话，输入 ",e.jsx("code",{children:"q"})," 退出。 这短短二十几行，已经是一个完整可用的对话程序了。"]}),e.jsxs(c,{title:"练一练",children:["给上面的聊天程序加一个命令：当用户输入 ",e.jsx("code",{children:"clear"}),' 时， 把 messages 重置成只剩 system 那一条（即"清空对话历史，重新开始"），并提示"已清空"。']}),e.jsxs(n,{variant:"tip",title:"承上启下",children:['现在你已经能自如地调用大模型了。但目前模型只能"说"，不能"做事"——它没法查天气、算数、查数据库。 下一卷我们会让模型学会',e.jsx("strong",{children:"调用工具"}),'，从一个"会聊天的模型"进化成一个"会办事的 Agent"。']}),e.jsx(r,{points:["大模型对话 API 的核心是 messages 列表，每条含 role（system/user/assistant）和 content；模型读完历史续上 assistant 回复。",'模型本身无记忆，"记忆"靠你每次把完整历史一起发过去。',"pip install openai；用环境变量 DASHSCOPE_API_KEY 保管密钥，os.getenv 读取，绝不硬编码进代码。","base_url 指向百炼 OpenAI 兼容端点 https://dashscope.aliyuncs.com/compatible-mode/v1（结尾 /v1 必带），model 用 qwen-plus。","回复在 resp.choices[0].message.content；resp.usage 看 token 用量。","多轮对话三步：用户输入 append 进 messages → 整体发给模型 → 回复 append 回 messages，循环即得聊天机器人。"]})]})}export{O as default};
