import{j as e}from"./index-DL563RIm.js";import{L as s,S as d}from"./Summary-BrgLcNDp.js";import{K as i}from"./KeyIdea-exK4GrdK.js";import{C as r}from"./Callout-B-8nslAm.js";import{C as t}from"./CodeBlock-DkVyd3P6.js";import{E as n}from"./Example-HxOmIesu.js";const o=`<!-- 子组件 UserCard.vue -->
<script setup>
// defineProps 是编译宏，不用 import，直接用
// 字符串数组写法：最简，但没有类型与默认值约束
const props = defineProps(['title', 'count'])
<\/script>

<template>
  <div class="card">
    <h3>{{ props.title }}</h3>
    <p>共 {{ props.count }} 条</p>
  </div>
</template>`,p=`<script setup>
// 对象写法：可声明类型、是否必填、默认值、校验器
const props = defineProps({
  title: {
    type: String,
    required: true,          // 父组件必须传，否则开发期告警
  },
  count: {
    type: Number,
    default: 0,              // 父组件没传时用这个值
  },
  tags: {
    type: Array,
    // 对象 / 数组的默认值必须用工厂函数返回，避免多实例共享同一引用
    default: () => [],
  },
  status: {
    type: String,
    default: 'idle',
    validator: (v) => ['idle', 'loading', 'done'].includes(v),
  },
})
<\/script>`,c=`<script setup lang="ts">
// 纯类型声明：把类型写进泛型参数里，Vue 编译期识别
interface Props {
  title: string
  count?: number          // 加 ? 表示可选
  tags?: string[]
}

// withDefaults 给可选 prop 补默认值
const props = withDefaults(defineProps<Props>(), {
  count: 0,
  tags: () => [],         // 同样：数组默认值用工厂函数
})
<\/script>`,l=`<script setup>
const props = defineProps({ count: Number })

function bad() {
  // 禁止！直接改 props 会触发警告，且下次父组件重渲染会把你的改动冲掉
  props.count++
}

import { ref, computed } from 'vue'

// 正解一：把 prop 当“初始值”，复制到本地 ref
const localCount = ref(props.count)

// 正解二：基于 prop 派生只读值，用 computed
const doubled = computed(() => props.count * 2)
<\/script>`,h=`<!-- 子组件 SearchBox.vue -->
<script setup>
const props = defineProps({ keyword: String })

// 声明本组件会向外发出哪些事件
const emit = defineEmits(['search', 'clear'])

function onSubmit() {
  // 第一个参数是事件名，后面是携带的载荷
  emit('search', props.keyword)
}
function onClear() {
  emit('clear')
}
<\/script>

<template>
  <input :value="keyword" />
  <button @click="onSubmit">搜索</button>
  <button @click="onClear">清空</button>
</template>`,a=`<!-- 父组件 -->
<script setup>
import { ref } from 'vue'
import SearchBox from './SearchBox.vue'

const kw = ref('')
function handleSearch(value) {
  console.log('父组件收到搜索词：', value)
}
<\/script>

<template>
  <!-- @事件名="处理函数"，子组件 emit 时父组件这里被调用 -->
  <SearchBox :keyword="kw" @search="handleSearch" @clear="kw = ''" />
</template>`,j=`<script setup lang="ts">
// 类型化的 emit：声明每个事件名与其载荷类型
const emit = defineEmits<{
  (e: 'search', keyword: string): void
  (e: 'clear'): void
}>()
<\/script>`,m=`<!-- 子组件 MyInput.vue：让 v-model 用在自定义组件上 -->
<script setup>
// 约定：prop 名叫 modelValue，事件名叫 update:modelValue
defineProps(['modelValue'])
const emit = defineEmits(['update:modelValue'])
<\/script>

<template>
  <input
    :value="modelValue"
    @input="emit('update:modelValue', $event.target.value)"
  />
</template>`,u=`<!-- Vue 3.4+ 推荐写法：defineModel 宏，自动处理 prop + emit -->
<script setup>
const text = defineModel()    // 返回一个可读可写的 ref
<\/script>

<template>
  <input v-model="text" />
</template>

<!-- 父组件直接：<MyInput v-model="someRef" /> -->`,x=`<!-- 祖先组件 App.vue -->
<script setup>
import { provide, ref } from 'vue'

const theme = ref('dark')

// provide(key, value)：把数据“注入”到整棵子树
provide('theme', theme)              // 提供响应式 ref，后代能感知变化
provide('appName', '后台管理系统')   // 也可提供普通值
<\/script>`,v=`<!-- 任意深度的后代组件 DeepButton.vue -->
<script setup>
import { inject } from 'vue'

// inject(key, 默认值)：取出祖先提供的数据，不必逐层透传 props
const theme = inject('theme', 'light')   // 没人提供时用默认值 'light'
const appName = inject('appName')
<\/script>

<template>
  <button :class="theme">{{ appName }}</button>
</template>`,f=`<!-- 祖先：提供数据 + 修改方法，让后代既能读又能改 -->
<script setup>
import { provide, ref, readonly } from 'vue'

const count = ref(0)
function increment() {
  count.value++
}

// readonly 包一层：后代只能读，不能直接改，修改只能走 increment
provide('counter', {
  count: readonly(count),
  increment,
})
<\/script>`,g=`<!-- 透传 attrs：父组件传了但子组件没在 props 里声明的属性 -->
<!-- 父：<MyButton type="submit" class="big" data-id="42" /> -->

<!-- 子 MyButton.vue：未声明的 type / class / data-id 会自动落到根元素上 -->
<script setup>
defineProps(['label'])   // 只声明了 label
<\/script>

<template>
  <!-- type、class、data-id 自动“透传”到这个 button 上 -->
  <button>{{ label }}</button>
</template>`,y=`<script setup>
// 关闭自动透传：当根元素不该收这些属性，或有多个根元素时
defineOptions({ inheritAttrs: false })

import { useAttrs } from 'vue'
const attrs = useAttrs()   // 拿到全部透传属性，自己决定绑到哪个元素
<\/script>

<template>
  <div class="wrapper">
    <!-- 手动用 v-bind 把 attrs 绑到真正该接收的元素上 -->
    <input v-bind="attrs" />
  </div>
</template>`,b=`<!-- ====== 综合例子：父子 + 跨层 provide/inject ====== -->

<!-- App.vue（祖先）：provide 主题，渲染父级面板 -->
<script setup>
import { provide, ref, readonly } from 'vue'
import OrderPanel from './OrderPanel.vue'

const theme = ref('dark')
provide('theme', { theme: readonly(theme), toggle: () => {
  theme.value = theme.value === 'dark' ? 'light' : 'dark'
} })
<\/script>

<template>
  <OrderPanel />
</template>


<!-- OrderPanel.vue（父）：用 props 向下、监听 emit 向上 -->
<script setup>
import { ref } from 'vue'
import OrderRow from './OrderRow.vue'

const orders = ref([
  { id: 1, name: '键盘', done: false },
  { id: 2, name: '显示器', done: true },
])

function handleToggle(id) {
  const o = orders.value.find((x) => x.id === id)
  if (o) o.done = !o.done
}
<\/script>

<template>
  <!-- props 向下传数据，@toggle 接收子组件向上发的事件 -->
  <OrderRow
    v-for="o in orders"
    :key="o.id"
    :order="o"
    @toggle="handleToggle"
  />
</template>


<!-- OrderRow.vue（子 + 深层 inject）：emit 向上，inject 跨层拿主题 -->
<script setup>
import { inject } from 'vue'

defineProps({ order: { type: Object, required: true } })
const emit = defineEmits(['toggle'])

// 不必经 OrderPanel 逐层透传，直接从 App 注入
const { theme } = inject('theme')
<\/script>

<template>
  <div :class="theme">
    <span>{{ order.name }}</span>
    <button @click="emit('toggle', order.id)">
      {{ order.done ? '已完成' : '待办' }}
    </button>
  </div>
</template>`;function A(){return e.jsxs("article",{children:[e.jsx(s,{children:"组件拆开了，下一个问题就来了：它们之间怎么说话？父组件想把数据递给子组件、子组件想告诉父组件 “我这儿出事了”、隔了好几层的祖孙又想共享同一份配置——这些都是组件通信要解决的。 Vue 3 给出了一套清晰、各司其职的方案：props 向下、emit 向上、v-model 双向、 provide/inject 跨层。这一章我们把它们逐个讲透，并理清各自的适用边界。"}),e.jsx("h2",{children:"一、贯穿全章的原则：单向数据流"}),e.jsxs(i,{children:["Vue 组件间的数据流动是",e.jsx("strong",{children:"单向"}),"的：数据通过 props 从父",e.jsx("strong",{children:"向下"}),"流到子； 子组件想影响父组件，不是去改父给的数据，而是通过事件（emit）向",e.jsx("strong",{children:"上"}),"通知， 由父组件自己决定怎么改。向下传数据、向上发事件——记住这条主线，后面所有 API 都是它的具体落地。"]}),e.jsxs("p",{children:["为什么要这样设计？因为单向流让数据的“源头”始终唯一且可追踪。一份状态归谁管，谁就负责改它； 别人只能读、或者发信号请求它改。一旦允许子组件随手改父组件的数据，状态就会变得到处都能动， 出了 bug 你根本不知道是谁、在哪一步把它改坏了。单向流牺牲了一点“随手就改”的便利， 换来的是",e.jsx("strong",{children:"可预测性"}),"——这正是大型应用最需要的东西。"]}),e.jsx("h2",{children:"二、props：父组件向子组件传数据"}),e.jsxs("p",{children:["props 是父组件传给子组件的“入参”。在 ",e.jsx("code",{children:"<script setup>"})," 里，我们用编译宏",e.jsx("code",{children:"defineProps"})," 来声明本组件接收哪些 props。它是编译宏，",e.jsx("strong",{children:"不需要"})," import， 编译器会在编译期处理掉它。"]}),e.jsx(t,{lang:"vue",title:"defineProps 最简写法（字符串数组）",code:o}),e.jsxs("p",{children:["字符串数组写法最快，但没有任何约束。实战里更推荐",e.jsx("strong",{children:"对象写法"}),"，可以声明类型、是否必填、 默认值，甚至自定义校验器："]}),e.jsx(t,{lang:"vue",title:"defineProps 对象写法（类型 / 必填 / 默认值 / 校验）",code:p}),e.jsxs(r,{variant:"warn",title:"对象 / 数组的默认值必须用工厂函数",children:["如果默认值是对象或数组，必须写成 ",e.jsx("code",{children:"default: () => []"})," 这种工厂函数形式， 而不能直接写 ",e.jsx("code",{children:"default: []"}),"。否则这个组件的所有实例会共享同一个引用， 一个实例改了，其他实例跟着变——这是非常隐蔽的 bug。"]}),e.jsx("h3",{children:"用 TypeScript 声明 props 类型"}),e.jsxs("p",{children:["如果用 TS（",e.jsx("code",{children:'<script setup lang="ts">'}),"），可以把类型直接写进",e.jsx("code",{children:"defineProps"})," 的泛型参数里，再用 ",e.jsx("code",{children:"withDefaults"})," 给可选 prop 补默认值， 类型与默认值分离，读起来更清爽："]}),e.jsx(t,{lang:"vue",title:"TS 类型声明 + withDefaults",code:c}),e.jsx("h3",{children:"为什么不能直接改 props"}),e.jsxs("p",{children:["props 是",e.jsx("strong",{children:"只读"}),"的。在子组件里直接写 ",e.jsx("code",{children:"props.count++"})," 会触发开发期警告， 而且毫无意义——下次父组件重新渲染时，它会用自己的数据把你的改动覆盖掉，因为父才是这份数据的“源头”。 这正是单向数据流的体现：子组件没有权力擅自修改向下流来的数据。"]}),e.jsx("p",{children:"那如果确实需要在子组件内“基于 prop 做点变化”，怎么办？有两条正路："}),e.jsxs("ul",{children:[e.jsxs("li",{children:["把 prop 当作",e.jsx("strong",{children:"初始值"}),"，复制到本地 ",e.jsx("code",{children:"ref"}),"，之后改本地副本。"]}),e.jsxs("li",{children:["基于 prop 派生一个",e.jsx("strong",{children:"只读"}),"的 ",e.jsx("code",{children:"computed"}),"，prop 变它自动跟着变。"]}),e.jsx("li",{children:"如果是真的想“改父的数据”，那就该用 emit 通知父组件去改（见下一节）。"})]}),e.jsx(t,{lang:"vue",title:"不要改 props，要复制或派生",code:l}),e.jsx("h2",{children:"三、emit：子组件向父组件通信"}),e.jsxs("p",{children:["子组件不能直接改父的数据，但可以“喊一声”——发出一个",e.jsx("strong",{children:"自定义事件"}),"，把信息向上传递， 父组件监听到后自己处理。我们用编译宏 ",e.jsx("code",{children:"defineEmits"})," 声明本组件会发出哪些事件， 它返回一个 ",e.jsx("code",{children:"emit"})," 函数用来真正触发事件。"]}),e.jsx(t,{lang:"vue",title:"子组件用 defineEmits 声明并触发事件",code:h}),e.jsxs("p",{children:["父组件这边，用 ",e.jsx("code",{children:'@事件名="处理函数"'})," 来监听。子组件每 ",e.jsx("code",{children:"emit"})," 一次， 父组件对应的处理函数就被调用一次，",e.jsx("code",{children:"emit"})," 时携带的载荷会作为参数传进来："]}),e.jsx(t,{lang:"vue",title:"父组件监听子组件发出的事件",code:a}),e.jsx("p",{children:"同样地，TS 项目里可以给 emit 加类型，明确每个事件名对应的载荷类型，调用错了编译期就报错："}),e.jsx(t,{lang:"vue",title:"类型化的 defineEmits",code:j}),e.jsx("h2",{children:"四、v-model：props + emit 的双向语法糖（回顾）"}),e.jsxs("p",{children:["我们在表单那一卷见过 ",e.jsx("code",{children:"v-model"}),"。它其实不是什么新机制，而是",e.jsx("strong",{children:"“传一个 prop + 监听一个 update 事件”"})," 的语法糖。组件上的",e.jsx("code",{children:"v-model"})," 默认对应名为 ",e.jsx("code",{children:"modelValue"})," 的 prop 和名为",e.jsx("code",{children:"update:modelValue"})," 的事件。"]}),e.jsx(t,{lang:"vue",title:"手动实现组件 v-model（理解原理）",code:m}),e.jsxs("p",{children:[e.jsx("code",{children:'<MyInput v-model="x" />'})," 等价于",e.jsx("code",{children:'<MyInput :modelValue="x" @update:modelValue="x = $event" />'}),"。 理解这一点后，你就明白 v-model 完全建立在前面两节的 props / emit 之上，没有任何魔法。 从 Vue 3.4 起，更推荐用 ",e.jsx("code",{children:"defineModel"})," 宏，它自动帮你处理好那对 prop 和 emit："]}),e.jsx(t,{lang:"vue",title:"Vue 3.4+ 用 defineModel 宏",code:u}),e.jsx("h2",{children:"五、provide / inject：跨层级注入"}),e.jsxs("p",{children:["props 一层层向下传很清晰，但当层级很深时会很痛苦：A 要把数据给到 D，可中间隔着 B、C， 而 B、C 自己根本用不到这份数据，却被迫帮忙“接力传递”。这种现象叫",e.jsx("strong",{children:"prop 逐层透传（prop drilling）"}),"，又啰嗦又脆弱。"]}),e.jsxs(i,{children:[e.jsx("code",{children:"provide / inject"})," 让祖先组件“提供”数据，任意深度的后代直接“注入”取用， 中间层完全不必参与。祖先 ",e.jsx("code",{children:"provide(key, value)"}),"，后代",e.jsx("code",{children:"inject(key)"}),"，一供一取，跨越多少层都无所谓。"]}),e.jsx(t,{lang:"vue",title:"祖先 provide 提供数据",code:x}),e.jsx(t,{lang:"vue",title:"深层后代 inject 取用数据",code:v}),e.jsxs("p",{children:["关键点：如果 ",e.jsx("code",{children:"provide"})," 的是一个",e.jsx("strong",{children:"响应式"}),"的值（比如 ",e.jsx("code",{children:"ref"}),"）， 那么祖先改它时，所有 inject 它的后代都会自动更新——这就是",e.jsx("strong",{children:"响应式 provide"}),"。 若 provide 的只是个普通字符串 / 数字，则后代拿到的是一次性快照，祖先后续改动后代感知不到。"]}),e.jsx("h3",{children:"让后代能“请求修改”而不直接改"}),e.jsxs("p",{children:["为了不破坏单向流，常见做法是：祖先把",e.jsx("strong",{children:"只读的数据 + 修改方法"}),"一起 provide 下去， 后代要改时调用方法，由祖先执行真正的修改。用 ",e.jsx("code",{children:"readonly"})," 把数据包一层， 后代就无法（也不应）直接改它："]}),e.jsx(t,{lang:"vue",title:"provide 只读数据 + 修改方法",code:f}),e.jsx("h2",{children:"六、attrs 透传与 inheritAttrs"}),e.jsxs("p",{children:["还有一种“隐式”的传递：父组件写在子组件标签上、但子组件没在 ",e.jsx("code",{children:"defineProps"})," 里声明的属性 （以及事件监听器），会被自动收集为 ",e.jsx("strong",{children:"透传 attributes（fallthrough attrs）"}),"， 默认",e.jsx("strong",{children:"自动落到子组件的根元素"}),"上。这让你能给封装组件传 ",e.jsx("code",{children:"class"}),"、",e.jsx("code",{children:"id"}),"、",e.jsx("code",{children:"data-*"})," 等原生属性而不必一个个声明。"]}),e.jsx(t,{lang:"vue",title:"未声明的属性自动透传到根元素",code:g}),e.jsxs("p",{children:["当根元素不该接收这些属性，或组件有多个根元素时，自动透传就需要手动接管。用",e.jsx("code",{children:"inheritAttrs: false"})," 关闭自动透传，再用 ",e.jsx("code",{children:"useAttrs()"})," 拿到全部透传属性， 自己 ",e.jsx("code",{children:"v-bind"})," 到真正该接收的那个元素上："]}),e.jsx(t,{lang:"vue",title:"关闭自动透传并手动绑定",code:y}),e.jsx("h2",{children:"七、各通信方式适用场景对比"}),e.jsx("p",{children:"四种主要方式各有定位，选错了就会别扭。下面这张表帮你快速对号入座："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方式"}),e.jsx("th",{children:"方向"}),e.jsx("th",{children:"典型场景"}),e.jsx("th",{children:"注意点"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"props"}),e.jsx("td",{children:"父 -> 子"}),e.jsx("td",{children:"父把数据 / 配置传给子"}),e.jsx("td",{children:"只读，子不能直接改"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"emit"}),e.jsx("td",{children:"子 -> 父"}),e.jsx("td",{children:"子通知父“发生了某事”"}),e.jsx("td",{children:"需先 defineEmits 声明"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"v-model"}),e.jsx("td",{children:"父 <-> 子"}),e.jsx("td",{children:"表单类组件的双向绑定"}),e.jsx("td",{children:"本质是 props + emit 语法糖"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"provide / inject"}),e.jsx("td",{children:"祖先 -> 任意后代"}),e.jsx("td",{children:"跨多层共享主题 / 配置 / 服务"}),e.jsx("td",{children:"避免逐层透传；建议配 readonly"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"状态库（Pinia）"}),e.jsx("td",{children:"任意 <-> 任意"}),e.jsx("td",{children:"跨远房组件的全局共享状态"}),e.jsx("td",{children:"无直接关系的组件用它，见后续卷"})]})]})]}),e.jsx(r,{variant:"tip",title:"选择口诀",children:"直接父子关系优先 props / emit；表单双向用 v-model； “中间层根本用不到却要帮忙传”的深层共享用 provide / inject； 毫无关系的远房组件共享状态，再上 Pinia。能用近的就别用远的，作用域越小越好维护。"}),e.jsx("h2",{children:"八、综合例子：父子 + 跨层 provide/inject"}),e.jsxs("p",{children:["把这一章的几种方式串进一个例子：",e.jsx("code",{children:"App"})," 跨层 provide 主题；",e.jsx("code",{children:"OrderPanel"})," 作为父，用 props 把每条订单向下传给 ",e.jsx("code",{children:"OrderRow"}),"， 并监听子组件 emit 的 ",e.jsx("code",{children:"toggle"})," 事件；",e.jsx("code",{children:"OrderRow"})," 作为最深一层， 既向上 emit，又直接 inject 拿到 App 提供的主题——完全不经过中间的 OrderPanel 透传。"]}),e.jsx(t,{lang:"vue",title:"父子 props/emit + 跨层 provide/inject 综合示例",code:b}),e.jsxs(n,{title:"顺着数据流走一遍",children:[e.jsxs("p",{children:["用户点 OrderRow 里的按钮，子组件 ",e.jsx("code",{children:"emit('toggle', id)"})," 向上发事件； 父组件 OrderPanel 的 ",e.jsx("code",{children:"handleToggle"})," 被调用，它去修改自己持有的 ",e.jsx("code",{children:"orders"}),"（数据源头在父这里）；orders 是响应式的，变化后对应的 OrderRow 自动重渲染。 全程子组件没有碰过父的数据，只是“喊了一声”。"]}),e.jsxs("p",{children:["与此同时，主题 ",e.jsx("code",{children:"theme"})," 由最顶层的 App 提供，OrderRow 直接 inject 取用—— 中间隔着的 OrderPanel 既不需要声明 theme 这个 prop，也不需要往下转传，干净利落。"]})]}),e.jsx("h2",{children:"九、边界与易错点"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"不要把 inject 当全局变量乱用"}),"：provide/inject 适合“一个子树共享的上下文”， 如果两个毫无关系的组件要共享状态，那是 Pinia 的活，别硬塞进 provide。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"inject 的 key 建议用常量 / Symbol"}),"：字符串 key 容易拼错且会撞名， 大型项目里用 ",e.jsx("code",{children:"Symbol"})," 做 key 更安全。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"provide 普通值不响应"}),"：想让后代感知变化，provide 的必须是响应式数据（ref / reactive）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"emit 事件名要声明"}),"：没在 ",e.jsx("code",{children:"defineEmits"})," 里声明的事件虽然也能发， 但声明后类型、文档、透传行为都更清晰，养成声明的习惯。"]})]}),e.jsx(r,{variant:"tip",children:"下一章我们换个角度看组件组合：除了“传数据”，父组件还能往子组件里“填内容”——这就是插槽。 同时我们会讲清组件从创建到销毁的生命周期钩子，知道该在哪个时机做取数、初始化与清理。"}),e.jsx(d,{points:["单向数据流是总原则：数据经 props 从父向下流，子组件想影响父只能通过 emit 向上发事件，由父自己改。","props 用 defineProps 声明，推荐对象写法（类型 / 必填 / 默认值 / 校验）；TS 用泛型声明 + withDefaults 补默认值；对象/数组默认值必须用工厂函数。","props 只读，不能直接改；要变化就复制到本地 ref、或用 computed 派生，真要改父数据则 emit 通知父。","emit 用 defineEmits 声明事件，子组件 emit(事件名, 载荷) 向上通信，父组件用 @事件名 监听。","v-model 是 props（modelValue）+ emit（update:modelValue）的语法糖；Vue 3.4+ 推荐用 defineModel 宏。","provide/inject 让祖先注入、任意后代取用，避免 prop 逐层透传；provide 响应式值才能让后代感知变化，常配 readonly + 修改方法。","未声明的属性自动透传到根元素（fallthrough attrs），需要时用 inheritAttrs:false + useAttrs() 手动接管。","选择口诀：父子用 props/emit，表单用 v-model，深层共享用 provide/inject，远房共享上 Pinia。"]})]})}export{A as default};
