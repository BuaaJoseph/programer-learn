import{r as x,j as e}from"./index-C4u1Qi4f.js";import{L as g,a as j,C as a,P as p,S as m}from"./Summary-DjSaQefZ.js";import{K as f}from"./KeyIdea-BS4xPn0s.js";import{E as u}from"./Example-DNWIRw6O.js";import{F as A}from"./Figure-D2qsSgWq.js";const r=[{key:"think",label:"思考",desc:"模型决定下一步做什么：要查天气",color:"var(--accent)"},{key:"act",label:"行动",desc:"调用工具 get_weather(city=北京)",color:"var(--violet)"},{key:"observe",label:"观察",desc:"工具返回：北京 26°C，晴",color:"var(--green)"}];function k(){const[i,o]=x.useState(0),s=i%3,d=Math.floor(i/3)+1,h=e.jsxs(e.Fragment,{children:[e.jsx("button",{className:"fig-btn",onClick:()=>o(n=>n+1),children:"下一步 ▸"}),e.jsx("button",{className:"fig-btn",onClick:()=>o(0),children:"重来"}),e.jsxs("span",{className:"fig-note",children:["第 ",d," 轮 · 当前：",r[s].label]})]}),l=[110,300,205],c=[70,70,160];return e.jsx(A,{caption:"ReAct 让模型在思考、行动、观察之间循环，每一轮都用上一步的观察结果，直到任务完成。",controls:h,children:e.jsxs("svg",{viewBox:"0 0 410 220",width:"410",role:"img","aria-label":"ReAct 循环",children:[e.jsx("defs",{children:e.jsx("marker",{id:"arrow",markerWidth:"8",markerHeight:"8",refX:"6",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L6,3 L0,6 Z",fill:"var(--ink-faint)"})})}),e.jsx("path",{d:"M150 70 L260 70",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#arrow)",fill:"none"}),e.jsx("path",{d:"M290 95 L225 140",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#arrow)",fill:"none"}),e.jsx("path",{d:"M180 140 L120 95",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#arrow)",fill:"none"}),r.map((n,t)=>e.jsxs("g",{children:[e.jsx("circle",{cx:l[t],cy:c[t],r:"34",fill:t===s?n.color:"var(--bg)",stroke:n.color,strokeWidth:"2"}),e.jsx("text",{x:l[t],y:c[t]+5,textAnchor:"middle",fontFamily:"var(--display)",fontSize:"15",fontWeight:"700",fill:t===s?"#ffffff":n.color,children:n.label})]},n.key)),e.jsx("rect",{x:"20",y:"190",width:"370",height:"26",rx:"7",fill:"var(--bg-sunken)"}),e.jsx("text",{x:"32",y:"207",fontFamily:"var(--mono)",fontSize:"11",fill:"var(--ink-soft)",children:r[s].desc})]})})}const v=`# 原始 ReAct：靠纯文本提示，让模型按固定格式输出，再用代码解析
SYSTEM = '''你可以使用工具来回答问题。请严格按以下格式逐步输出：
Thought: 你的思考
Action: 工具名
Action Input: 参数
（系统会返回 Observation，你再继续 Thought/Action）
当你已经能回答时，输出：
Final Answer: 最终答复
'''

import re

def parse(text):
    if 'Final Answer:' in text:
        return ('final', text.split('Final Answer:')[-1].strip())
    action = re.search(r'Action:\\s*(.+)', text)
    inp = re.search(r'Action Input:\\s*(.+)', text)
    return ('action', action.group(1).strip(), inp.group(1).strip())

# 缺点：模型一旦格式跑偏，正则就崩；这正是原生 function-calling 想解决的问题`,_=`import json
from openai import OpenAI

client = OpenAI()

def run_react(question, tools, registry, max_iterations=8):
    messages = [{'role': 'user', 'content': question}]
    seen_calls = set()          # 记录已执行过的 (工具名, 参数) 组合，防重复

    for step in range(max_iterations):
        resp = client.chat.completions.create(
            model='gpt-4o-mini', messages=messages, tools=tools,
        )
        msg = resp.choices[0].message
        messages.append(msg)

        # 停止条件 1：模型不再请求工具 → 它给出了最终答复
        if not msg.tool_calls:
            return msg.content

        for call in msg.tool_calls:
            name = call.function.name
            raw_args = call.function.arguments
            signature = (name, raw_args)

            # 重复检测：同样的工具 + 同样的参数已经调过，别再调一次
            if signature in seen_calls:
                observation = {'error': f'你已用相同参数调用过 {name}，请换思路或直接给出答复'}
            else:
                seen_calls.add(signature)
                fn = registry.get(name)
                if fn is None:
                    observation = {'error': f'没有名为 {name} 的工具'}
                else:
                    try:
                        observation = fn(**json.loads(raw_args))
                    except Exception as e:
                        observation = {'error': f'{name} 执行失败：{e}'}

            # 把观察结果回灌，进入下一轮「思考」
            messages.append({
                'role': 'tool',
                'tool_call_id': call.id,
                'content': json.dumps(observation, ensure_ascii=False),
            })

    # 停止条件 2：到达上限仍未收敛 → 兜底，避免无限循环烧钱
    return '已达到最大迭代次数，未能得到最终答复'`;function F(){return e.jsxs(e.Fragment,{children:[e.jsx(g,{children:e.jsxs("p",{children:["单次工具调用只够回答「北京几度」这种一步问题。但「订一张明天去上海、价格最低的高铁票」要查车次、 比价、再下单——得调好几次工具，每次都要先想一步、做一步、看结果再想下一步。这种",e.jsx("strong",{children:"思考（Reason）→ 行动（Act）→ 观察（Observe）"}),"反复交替的模式，就是 ",e.jsx("em",{children:"ReAct"})," 循环， 是几乎所有 Agent 的运转骨架。"]})}),e.jsx("h2",{children:"循环是怎么转起来的"}),e.jsxs("p",{children:["ReAct 的每一轮都做三件事：模型",e.jsx("strong",{children:"思考"}),"下一步该干嘛、产出一个工具调用去",e.jsx("strong",{children:"行动"}),"、 你的代码执行后把结果作为",e.jsx("strong",{children:"观察"}),"回灌。观察进入对话历史后，模型带着新信息再思考下一步—— 如此循环，直到它认为信息够了，不再请求工具、直接给出最终答复，循环才结束。"]}),e.jsx(k,{}),e.jsxs("p",{children:["注意一个关键点：驱动循环前进的，是不断",e.jsx("strong",{children:"累积的对话历史"}),"（常叫 ",e.jsx("em",{children:"transcript"}),"）。 第 N 轮调用模型时，你喂进去的不只是最初的问题，而是「问题 + 前面每一轮的思考、工具调用、工具结果」全都带上。 模型没有记忆，它能「连贯地推进任务」纯粹是因为你每轮都把完整历史重新喂给它。"]}),e.jsxs(j,{variant:"warn",title:"transcript 越滚越长，token 成本是非线性的",children:[e.jsxs("p",{children:["因为每一轮都要把",e.jsx("strong",{children:"全部历史"}),"重新发给模型，第 5 轮发送的内容远多于第 1 轮。 假设每轮新增的内容差不多，那么到第 N 轮，累计发送的 token 量大致正比于 ",e.jsx("code",{children:"1 + 2 + ... + N"}),"， 也就是 ",e.jsx("strong",{children:"O(N²)"})," 量级——轮数翻倍，成本不是翻倍，而是翻四倍左右。"]}),e.jsxs("ul",{children:[e.jsx("li",{children:"所以「让 Agent 多想几步」绝不是免费的，max_iterations 既是安全阀，也是成本阀。"}),e.jsx("li",{children:"长任务要考虑截断/摘要历史、只保留关键观察，否则后期每一轮都在为前面的啰嗦买单。"})]})]}),e.jsx("h3",{children:"循环控制：四件必须做对的事"}),e.jsx("p",{children:"一个能上线的 ReAct 循环，控制逻辑比「调模型」本身更要紧："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"停止条件"}),"——必须能识别「模型给出了最终答复」（原生 function-calling 里就是",e.jsx("code",{children:"tool_calls"})," 为空）。这是循环正常退出的出口。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"max_iterations 上限"}),"——模型可能陷入「查了又查、就是不收尾」。设一个硬上限， 到了就兜底退出，防止无限循环把钱烧光。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"防止重复调用同一工具"}),"——记录「工具名 + 参数」的指纹，发现模型用一模一样的参数又调一遍， 就回灌一句提示让它换思路，而不是傻傻再执行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"区分「最终答复」与「工具调用」"}),"——别把模型一段带 Thought 的文本误当成答复， 也别把答复误当成还要执行工具。原生 function-calling 把这两者用结构区分开，省去了猜。"]})]}),e.jsxs(u,{title:"两种实现风格：原始 ReAct vs 原生 function-calling",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"原始 ReAct"}),"（论文里的做法）：没有专门的工具接口，全靠提示词约定一套",e.jsx("code",{children:"Thought / Action / Observation"})," 文本格式，模型按格式输出，你用正则去解析。 灵活、任何模型都能用，但",e.jsx("strong",{children:"脆"}),"——模型格式稍跑偏，解析就崩。"]}),e.jsx(a,{lang:"python",title:"raw_react.py",code:v}),e.jsxs("p",{children:[e.jsx("strong",{children:"原生 function-calling"}),"（如今主流）：模型把工具调用作为",e.jsx("strong",{children:"结构化字段"}),"（",e.jsx("code",{children:"tool_calls"}),"）返回，你不用解析文本，直接读字段；模型也被专门训练过更少出格。 代价是依赖支持该能力的模型与 API。两者思想完全一致，区别只在「靠文本约定」还是「靠结构契约」。"]})]}),e.jsx(f,{title:"Agent = 一个被精心控制的 while 循环",children:e.jsxs("p",{children:["去掉花哨的包装，绝大多数 Agent 框架的内核就是一个 while 循环：调模型、看它要不要用工具、用就执行并回灌、 不用就返回。真正的工程难度不在这个骨架，而在",e.jsx("strong",{children:"循环控制"}),"——什么时候停、超限怎么办、 重复了怎么办、历史太长怎么压缩。把这些想清楚，你不用任何框架也能写出可靠的 Agent。"]})}),e.jsx("h2",{children:"这对做 Agent / 工程实践意味着什么"}),e.jsxs("p",{children:["别一上来就抄一个庞大的 Agent 框架。先自己写这个 while 循环，你会真正理解每一轮在 messages 里加了什么、 token 为什么越烧越快、循环为什么会卡住。",e.jsx("strong",{children:"能观测、能调试、能掐断"}),"的循环，远比一个黑盒框架可靠。 等你把控制逻辑摸透了，再决定要不要上框架，那时框架对你只是省代码，而不是省思考。"]}),e.jsxs(p,{title:"带 max_iterations 和重复检测的 ReAct 循环",children:[e.jsx("p",{children:"下面是一个生产味儿的 ReAct 循环：用原生 function-calling，包含两个停止条件（模型不再调工具、到达迭代上限）、 重复调用检测（同名同参直接拦下并提示模型换思路）、以及工具执行的异常兜底（把错误作为观察回灌，而不是让程序崩）。"}),e.jsx(a,{lang:"python",title:"react_loop.py",code:_}),e.jsx("p",{children:"挑战：给它一个故意会绕圈的问题，观察重复检测有没有把它从死循环里救出来；再打印每一轮 messages 的长度， 亲眼看看 transcript 是怎么非线性膨胀的。"})]}),e.jsx(m,{points:["ReAct 循环 = 思考 → 行动 → 观察 反复交替，是多步 Agent 的运转骨架。","驱动循环的是不断累积的对话历史 transcript：模型无记忆，靠你每轮重喂完整历史来连贯推进。","因为每轮都重发全部历史，到第 N 轮累计 token 约 O(N²)，多想几步的成本是非线性增长的。","循环控制四件事：识别最终答复（停止条件）、max_iterations 上限、重复调用检测、区分答复与工具调用。","两种实现风格：原始 ReAct 靠文本格式 + 正则解析（脆）；原生 function-calling 靠结构化字段（稳，主流）。","Agent 内核就是一个被精心控制的 while 循环，难点不在骨架而在控制——先自己写，再考虑用框架。"]})]})}export{F as default};
