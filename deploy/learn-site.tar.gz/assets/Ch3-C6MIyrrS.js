import{j as s}from"./index-I8-WI4LI.js";import{L as o,S as r}from"./Summary-BMIdTn04.js";import{K as t}from"./KeyIdea-Xbvwo63C.js";import{E as i}from"./Example-CPIFvVrE.js";import{P as l}from"./Practice-Cum9V7VB.js";import{C as e}from"./Callout-ZgrsOCpc.js";import{C as n}from"./CodeBlock-CK6ncc4Q.js";const c=`# 对比：有无 CoT 的 prompt
# 同一道题，加一句「一步步想」往往就能把对错翻过来

question = (
    '一家店周一卖了 23 个杯子，周二卖的是周一的 2 倍，'
    '周三比周二少卖 9 个。三天一共卖了多少个？'
)

# 直接要答案：模型容易在一步里算错
prompt_direct = question + '\\n只输出最终数字。'

# zero-shot CoT：加一句引导，让它把推理过程写出来
prompt_cot = question + '\\n让我们一步一步地想，最后单独给出答案。'

# few-shot CoT：先给一个带推理过程的范例，再问新题
prompt_few_shot = (
    '问：小明有 5 个苹果，又买了 3 袋，每袋 4 个，一共多少个？\\n'
    '答：先算买的：3 乘 4 等于 12；再加原有的 5；12 加 5 等于 17。答案：17。\\n\\n'
    '问：' + question + '\\n答：'
)`,h=`# self-consistency：对同一道题多次采样，取多数答案
import re
from collections import Counter
from openai import OpenAI

client = OpenAI()

def ask_once(question, temperature=0.7):
    resp = client.chat.completions.create(
        model='gpt-4o-mini',
        messages=[{
            'role': 'user',
            'content': question + '\\n一步步推理，最后用「答案：N」给出整数。',
        }],
        temperature=temperature,   # 调高一点，制造多样的推理路径
    )
    return resp.choices[0].message.content

def extract_answer(text):
    m = re.findall(r'答案[:：]\\s*(-?\\d+)', text)
    return m[-1] if m else None     # 取最后一个，通常是最终答案

def self_consistency(question, n=5):
    answers = []
    for _ in range(n):
        ans = extract_answer(ask_once(question))
        if ans is not None:
            answers.append(ans)
    if not answers:
        return None, {}
    votes = Counter(answers)
    best, _ = votes.most_common(1)[0]
    return best, dict(votes)

if __name__ == '__main__':
    q = '一家店周一卖了 23 个杯子，周二是周一的 2 倍，周三比周二少卖 9 个。三天共卖多少个？'
    final, votes = self_consistency(q, n=5)
    print('投票分布:', votes)
    print('最终答案:', final)`;function C(){return s.jsxs(s.Fragment,{children:[s.jsx(o,{children:s.jsxs("p",{children:["模型一次只生成一个 token，每个 token 背后的算力是",s.jsx("strong",{children:"固定且有限"}),"的。 难题要是逼它「一步算到底」，它就得在那一步里塞下全部推理——往往算不动、就蒙一个。",s.jsx("em",{children:"思维链"}),"（chain-of-thought, CoT）的全部窍门， 就是让它把推理过程一个 token 一个 token 地",s.jsx("strong",{children:"写出来"}),"，相当于给它一张草稿纸。"]})}),s.jsx("h2",{children:"CoT 为什么有用：把算力摊开到更多 token 上"}),s.jsx("p",{children:"回顾第 1 卷：模型生成是自回归的，一次只吐一个词，而每生成一个 token 的计算量是大致恒定的。 这意味着模型在「单个 token」上能做的运算量有上限。直接问「答案是多少」， 等于要求它在生成那一个答案 token 之前，在脑子里（前向传播一次）把整道题算完——复杂题根本来不及。"}),s.jsx("p",{children:"而如果让它先写「第一步……第二步……所以……」，每一步都是新生成的 token， 又都会回流进上下文成为下一步的输入。于是："}),s.jsxs("ul",{children:[s.jsxs("li",{children:[s.jsx("strong",{children:"把难题摊成多步"}),"：每一步只需做一点点运算，难度被切碎了。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"用上下文当草稿纸"}),"：中间结果写在文本里，后面的步骤能「看到」并接着用，不必全凭一次前向传播记住。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"更多 token = 更多算力"}),"：推理过程越长，分摊到整道题上的总计算量越大。"]})]}),s.jsx("p",{children:"这就是为什么「让我们一步一步想」这种看似空洞的一句话，能实打实提高数学、逻辑题的正确率。"}),s.jsxs("p",{children:["换个更底层的说法：模型单次前向传播的「深度」是固定的（第 1 卷第 5 章，层数有限），这决定了它一步能做的",s.jsx("strong",{children:"串行推理步数"}),"有上限。 而 CoT 把推理摊到「生成很多个 token」上，每个 token 又是一次完整的前向传播——于是有效的串行计算步数，从「固定层数」扩展到了「层数 × 推理 token 数」。 这是 CoT 能突破单步算力天花板的",s.jsx("strong",{children:"结构性原因"}),"，不是玄学。"]}),s.jsxs(e,{variant:"info",title:"一个类比：心算 vs 列竖式",children:[s.jsx("p",{children:"让你直接报出「873 × 49」的得数，你多半要么算很久要么报错；但给你纸笔列竖式，一步步来，你几乎不会错。 模型也一样：直接要答案，等于逼它「心算」，单步算力不够就蒙；让它写出每一步（CoT），等于给它纸笔。"}),s.jsxs("p",{children:["这个类比还能解释一个现象：",s.jsx("strong",{children:"越难的题，CoT 的增益越大"}),"。简单题模型「心算」就够，写不写过程差别不大； 难题、多步推理题，CoT 才显出威力。所以别无脑给所有任务都加「一步步想」——对简单任务它只是白白增加 token 和延迟。"]})]}),s.jsx("h3",{children:"三种常见用法"}),s.jsxs("ul",{children:[s.jsxs("li",{children:[s.jsx("strong",{children:"zero-shot CoT"}),"：不给示例，只在问题后加一句引导，如「让我们一步一步地想」。 最省事，对许多任务立竿见影。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"few-shot CoT"}),"：先给一两个",s.jsx("strong",{children:"带完整推理过程"}),"的范例，再问新题。 示例既教了「要写推理」，也示范了推理的格式和粒度，通常比 zero-shot 更稳。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"self-consistency"}),"：对同一道题，把温度调高、采样多条不同的推理路径， 最后对它们的",s.jsx("strong",{children:"最终答案投票"}),"，取多数。不同路径可能各有各的错，但正确答案往往是「最多条路径殊途同归」的那个。"]})]}),s.jsxs("p",{children:["三者的关系是",s.jsx("strong",{children:"逐级加码"}),"：zero-shot CoT 最省（加一句话），few-shot CoT 用示例换更稳的格式和更高的正确率（多花点示例 token）， self-consistency 用「多跑几遍 + 投票」换更高的可靠性（成本翻 n 倍）。按任务的重要性和预算往上加：日常用 zero-shot， 格式要求高用 few-shot，关键且容错率低的题才上 self-consistency。"]}),s.jsx("h3",{children:"三种用法的进阶变体"}),s.jsx("p",{children:"在三种基本用法之上，还有几个值得知道的延伸："}),s.jsxs("ul",{children:[s.jsxs("li",{children:[s.jsx("strong",{children:"least-to-most"}),"（由简到繁）：先让模型把大问题",s.jsx("strong",{children:"拆成若干子问题"}),"，再逐个解决、把前一个的答案喂给后一个。 适合那种「必须分解才能下手」的复杂题，比单纯「一步步想」更有结构。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"plan-and-solve"}),"（先规划再执行）：先让它列出解题计划，再按计划执行。避免它一头扎进去算错方向。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"给推理一个固定模板"}),"：在 few-shot 示例里把推理写成固定步骤（「第一步识别已知量；第二步列关系式；第三步代入计算」）， 模型会模仿这个结构，输出更可控、更易校验。"]})]}),s.jsxs("p",{children:["共同的内核还是那一句：",s.jsx("strong",{children:"把一次性的难题，拆成模型能逐步消化的小步，并让中间结果落到文本里"}),"。 这些变体只是「怎么拆、按什么顺序拆」的不同策略。"]}),s.jsxs(i,{title:"同一道题，直接问 vs. 让它一步步想",children:[s.jsx("p",{children:"下面三个 prompt 问的是同一道题：直接要答案、zero-shot CoT、few-shot CoT。 直接要答案时模型常在「周二是周一 2 倍」这步打滑；让它写出过程后，错误率显著下降。"}),s.jsx(n,{lang:"python",title:"cot_compare.py",code:c}),s.jsx("p",{children:"正确推理是：周一 23、周二 46、周三 37，合计 106。 你会发现 CoT 版本不仅更容易答对，过程还能被你检查——错在哪一步一目了然。"})]}),s.jsx("h2",{children:"CoT 的成本与「什么时候别用」"}),s.jsx("p",{children:"CoT 不是免费的午餐，它的代价很实在："}),s.jsxs("ul",{children:[s.jsxs("li",{children:[s.jsx("strong",{children:"更费 token"}),"：推理过程本身要生成大量 token，输出长度可能翻几倍，直接推高费用。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"更慢"}),"：生成是串行的（第 1 卷），推理越长，首字到完成的时间越久，对交互式场景体验有损。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"可能「想多了」"}),"：简单题强行让它长篇推理，偶尔反而绕进死胡同、把对的想成错的。"]})]}),s.jsxs("p",{children:["所以要按场景权衡：",s.jsx("strong",{children:"难推理任务（数学、逻辑、多步规划）值得开 CoT；简单分类、抽取、格式转换则不必"}),"。 还有一个折中——让它推理但",s.jsx("strong",{children:"不输出"}),"：内部想完，最终只返回结论（或把推理放进一个会被丢弃的字段）。 这样既享受推理带来的正确率，又不让冗长的过程污染最终交付给用户的内容。"]}),s.jsxs(e,{variant:"info",title:"CoT 与结构化输出会「打架」",children:[s.jsx("p",{children:"一个高频的工程冲突：你既想让模型「先推理再答」（CoT），又想让它「只输出干净的 JSON」（结构化输出，第 4 章）。 但推理过程是自然语言，硬塞进严格 JSON 模式要么推理被压制、要么 JSON 被推理文字污染。"}),s.jsxs("p",{children:["常见解法是在 schema 里专门留一个 ",s.jsx("code",{children:"reasoning"})," 字段让它写推理，",s.jsx("code",{children:"answer"})," 字段放结论， 解析时只取 ",s.jsx("code",{children:"answer"}),"。或者分两次调用：第一次自由推理，第二次把结论整理成结构化。 知道这个冲突的存在，能帮你避开「为什么开了 JSON mode 模型就变笨了」的坑。"]})]}),s.jsx(t,{title:"推理过程就是外置的草稿纸",children:s.jsxs("p",{children:["CoT 不是让模型「变聪明」了，而是把它对单个 token 的算力限制",s.jsx("strong",{children:"绕开"}),"了： 把一道大题拆成一串小步，让每一步的中间结果落到文本里，成为下一步可读的输入。 本质上，你是在用「更多的 token」换「更强的有效计算」。这也解释了为什么专门的推理模型 会在回答前生成一大段「思考」内容——那段思考就是它的草稿纸。"]})}),s.jsxs(e,{variant:"warn",title:"unfaithful CoT：写出的理由未必是真的",children:[s.jsxs("p",{children:["有个反直觉但重要的局限：模型写出来的推理过程，",s.jsx("strong",{children:"不一定是它真正得出答案的过程"}),"。 研究发现，模型可能先「倾向于」某个答案，再编一段看起来合理的推理去圆它—— 这叫 ",s.jsx("em",{children:"unfaithful CoT"}),"（不忠实的思维链）。后果是："]}),s.jsxs("ul",{children:[s.jsx("li",{children:"推理文字读起来头头是道，结论却错；或者结论对，但中间某步其实是错的（碰巧抵消了）。"}),s.jsx("li",{children:"不能把 CoT 文本当成「模型内部真实计算的忠实记录」，更不能仅凭它来判断答案一定可信。"}),s.jsx("li",{children:"真要确保正确，得靠外部校验：让它调计算器/代码执行结果、用 self-consistency 投票、或对关键步骤做断言检查。"})]})]}),s.jsx("h2",{children:"从 CoT 到推理模型"}),s.jsxs("p",{children:["把 CoT 这个思路推到极致，就得到了近年的",s.jsx("strong",{children:"推理模型"}),"（reasoning models）。区别在于：普通模型的 CoT 要你在 prompt 里手动引导 （「一步步想」），而推理模型是",s.jsx("strong",{children:"被专门训练成「回答前先生成一大段思考」"}),"——这段思考往往很长、会自我检查、会回头纠错、 会尝试多条路径，然后才给出最终答案。本质上，它把「写草稿」这件事内化成了默认行为。"]}),s.jsxs("p",{children:["这带来一个工程上的新旋钮：",s.jsx("strong",{children:"思考预算"}),"（thinking budget / reasoning effort）。给的思考 token 越多，难题上越准，但也越慢越贵。 所以用推理模型时，要按任务难度调这个预算——简单任务调低甚至关掉，难的数学/代码/规划任务才放开。 理解了「CoT = 用 token 换计算」，你就明白推理模型为什么又强又贵：它就是在大量地用思考 token 买正确率。"]}),s.jsx(e,{variant:"info",title:"别让推理模型「再想一遍」",children:s.jsxs("p",{children:["一个常见误用：对已经内置思考的推理模型，还在 prompt 里堆「请一步步详细推理、先列出所有步骤……」。这往往多余甚至有害—— 它已经会自己想了，你的引导可能干扰它的内部推理节奏。对推理模型，prompt 反而要",s.jsx("strong",{children:"更简洁"}),"，把题目说清楚就行， 把「怎么想」交给它。这和普通模型「要手动加 CoT」的直觉正好相反，别搞混。"]})}),s.jsx("h2",{children:"这对做 Agent / 工程实践意味着什么"}),s.jsxs("p",{children:["CoT 是后面 Agent 推理范式的地基。当你把「写出推理」和「调用工具、观察结果、再推理」拼在一起， 就得到了 ",s.jsx("em",{children:"ReAct"}),"（Reason + Act）——模型先想一步（reason），决定调哪个工具（act）， 看到工具返回（observation），再接着想。这正是第 4 卷的主线。 工程上要记两点：一是 CoT 会显著增加 token 消耗和延迟，要权衡何时开； 二是别把模型自陈的推理当作可信审计日志，关键结论务必用工具或代码",s.jsx("strong",{children:"实算一遍"}),"来验证。"]}),s.jsxs(l,{title:"自己跑一遍 CoT 与 self-consistency 投票",children:[s.jsxs("p",{children:["先用上面的 ",s.jsx("code",{children:"cot_compare.py"})," 把三种 prompt 各跑几次，对比正确率和稳定性。 然后用下面的 self-consistency 脚本：把温度调到 0.7、采样 5 条路径，对最终答案投票。"]}),s.jsx(n,{lang:"python",title:"self_consistency.py",code:h}),s.jsxs("p",{children:["练习：把 ",s.jsx("code",{children:"n"})," 从 1 加到 9，观察投票分布怎么收敛； 再找一道你知道答案、但模型偶尔会错的题，看看投票能不能把偶发错误「平均掉」。 顺便留意有没有 unfaithful 的情况——某条路径过程明明错了，结论却蒙对了。"]})]}),s.jsx(r,{points:["模型一次只生成一个 token、单步算力有限；CoT 把推理写出来，等于给它一张草稿纸。","把难题摊成多步、让中间结果落进上下文、用更多 token 换更强的有效计算，是 CoT 见效的根本原因。","zero-shot CoT 加一句「一步步想」；few-shot CoT 给带推理过程的范例；self-consistency 多次采样后对答案投票。","unfaithful CoT：写出的理由未必是真实计算过程，结论与过程可能各自出错，不能当审计日志。","要保证正确，靠外部校验——工具实算、代码执行、self-consistency 投票、关键步骤断言。","CoT 是 ReAct（边推理边调工具）的地基，预告第 4 卷；工程上要权衡它带来的 token 与延迟开销。"]})]})}export{C as default};
