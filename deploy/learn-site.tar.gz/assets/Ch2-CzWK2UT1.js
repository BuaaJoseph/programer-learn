import{j as e}from"./index-CVHWXZpb.js";import{L as n,S as i}from"./Summary-CJTCDEeZ.js";import{K as d}from"./KeyIdea-XVLVSS4B.js";import{C as c}from"./Callout-DCq22jZW.js";import{C as s}from"./CodeBlock-ljkh5ShG.js";import{E as r}from"./Example-BSuN_UvG.js";const t=`{
  "name": "my-app",
  "scripts": {
    "dev": "vite",
    "build": "tsc --noEmit && vite build",   // 先类型门禁，过了再打包
    "typecheck": "tsc --noEmit",             // 只检查类型、不产出文件
    "typecheck:watch": "tsc --noEmit --watch" // 监听模式，边写边查
  }
}`,l=`{
  "scripts": {
    // Vue 单文件组件里的 <template> 也要查类型，
    // 普通 tsc 看不懂 .vue，要用 vue-tsc
    "typecheck": "vue-tsc --noEmit",
    "build": "vue-tsc --noEmit && vite build"
  }
}`,o=`// global.d.ts —— ambient（环境）声明，描述"全局已存在"的东西
// 没有 import / export 的 .d.ts 文件，其声明对全局可见

// 1) 给 Vite 注入的环境变量补类型
interface ImportMetaEnv {
  readonly VITE_API_BASE: string
  readonly VITE_FEATURE_FLAG: 'on' | 'off'
}
interface ImportMeta {
  readonly env: ImportMetaEnv
}

// 2) 让 import 静态资源不报错（Vite 会处理这些导入）
declare module '*.svg' {
  const src: string
  export default src
}

// 3) 给一个没有自带类型、也没有 @types 的老库补类型
declare module 'legacy-untyped-lib' {
  export function doThing(input: string): number
  export const VERSION: string
}`,h=`// dist/index.d.ts —— 由 tsc 自动生成的"类型说明书"
// 只有类型签名，没有任何实现

export interface FormatOptions {
  locale?: string
  currency?: string
}

export declare function formatMoney(
  value: number,
  options?: FormatOptions
): string

export declare const VERSION: string`,x=`{
  "name": "@acme/utils",
  "version": "1.2.0",
  "type": "module",
  "main": "./dist/index.js",       // 运行时入口（JS 实现）
  "types": "./dist/index.d.ts",    // 类型入口：消费者据此获得类型提示
  "exports": {
    ".": {
      "types": "./dist/index.d.ts",
      "import": "./dist/index.js"
    }
  },
  "files": ["dist"],               // 发布时把 dist（含 .d.ts）一并带上
  "scripts": {
    "build": "tsc"                 // 配合 declaration:true 同时产出 .js 与 .d.ts
  }
}`,j=`# .github/workflows/ci.yml —— 把类型检查接进 CI 流水线
name: CI
on: [push, pull_request]
jobs:
  typecheck:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm ci
      - run: npm run typecheck    # tsc --noEmit，类型有错就让这一步失败
      - run: npm run build`;function b(){return e.jsxs("article",{children:[e.jsxs(n,{children:["上一章我们配好了 ",e.jsx("code",{children:"tsconfig.json"}),"。这一章要纠正一个许多人都踩过的认知误区：",e.jsx("strong",{children:"「构建成功」不等于「类型没错」"}),"。现代构建工具（Vite / esbuild / SWC）为了快， 转译时",e.jsx("strong",{children:"根本不做类型检查"}),"。也就是说，你的代码里可能有一堆类型错误，照样能打包出包、 照样能跑——直到它在某个用户的浏览器里崩溃。本章讲清类型与构建的分工，以及如何用",e.jsx("code",{children:"tsc --noEmit"})," 和声明文件把类型这条防线补齐。"]}),e.jsx("h2",{children:"一、最关键的认知：转译 ≠ 类型检查"}),e.jsxs(d,{children:["Vite、esbuild、SWC 这类工具只负责",e.jsx("strong",{children:"转译"}),"——把 TS「删掉类型注解、把新语法降级成旧语法」， 变成能跑的 JS。它们",e.jsx("strong",{children:"故意不做类型检查"}),"，因为类型检查慢，会拖垮开发时的热更新速度。 所以类型错误",e.jsx("strong",{children:"不会"}),"让构建失败，你必须单独跑一遍 ",e.jsx("code",{children:"tsc --noEmit"})," 来把关。"]}),e.jsxs("p",{children:["为什么这些工具能「不检查类型也能转译」？因为对它们来说，TypeScript 的类型注解就是一段段",e.jsx("strong",{children:"可以直接擦除的文本"}),"。",e.jsx("code",{children:"const x: number = 1"})," 里的 ",e.jsx("code",{children:": number"}),"会被原样删掉，剩下 ",e.jsx("code",{children:"const x = 1"}),"。整个过程",e.jsx("strong",{children:"逐文件"}),"进行、不需要理解 跨文件的类型关系，所以快得惊人。但也正因为它「不理解类型」，",e.jsx("code",{children:'const x: number = "hello"'})," 这种明显的类型错误，它擦完类型后照样产出能跑的 JS， 毫不在意。"]}),e.jsxs(r,{title:"构建成功，类型却是错的",children:[e.jsxs("p",{children:["假设你写了 ",e.jsx("code",{children:"function area(r: number) { return 3.14 * r * r }"}),"， 然后在别处调用 ",e.jsx("code",{children:'area("5")'}),"（传了字符串）。"]}),e.jsxs("p",{children:["用 Vite ",e.jsx("code",{children:"build"}),"：",e.jsx("strong",{children:"构建成功"}),"，因为 esbuild 只擦类型不检查。 产物里 ",e.jsx("code",{children:'area("5")'})," 原样保留，运行时 ",e.jsx("code",{children:'"5" * "5"'})," 得到 ",e.jsx("code",{children:"NaN"}),"， 页面显示一个莫名其妙的结果。"]}),e.jsxs("p",{children:["跑 ",e.jsx("code",{children:"tsc --noEmit"}),"：",e.jsx("strong",{children:"立刻报错"}),"——「类型 string 不能赋给参数 number」。 错误在上线前就被拦住。这就是为什么不能只依赖构建工具。"]})]}),e.jsxs(c,{variant:"warn",title:"不要被「构建通过」骗了",children:["「",e.jsx("code",{children:"npm run build"})," 成功」只代表语法能转译、能打包，",e.jsx("strong",{children:"完全不代表类型正确"}),"。 真正的类型保障来自一道独立的关卡：",e.jsx("code",{children:"tsc --noEmit"}),"（Vue 项目用 ",e.jsx("code",{children:"vue-tsc --noEmit"}),"）。"]}),e.jsx("h2",{children:"二、tsc --noEmit：专职的类型门禁"}),e.jsxs("p",{children:[e.jsx("code",{children:"tsc --noEmit"})," 的意思是「只做类型检查，",e.jsx("strong",{children:"不产出"}),"（no emit）任何 JS 文件」。 它把 ",e.jsx("code",{children:"tsc"})," 默认的两件事（检查 + 转译）裁剪到只剩检查，扮演纯粹的「类型门禁」角色。 转译那一半，交给又快又好的打包器去做。"]}),e.jsxs(d,{children:["现代前端工程的标准分工是：",e.jsx("strong",{children:"转译用打包器"}),"（快、负责产物），",e.jsxs("strong",{children:["类型检查用 ",e.jsx("code",{children:"tsc --noEmit"})]}),"（慢、负责正确性）。两者各司其职，互不阻塞。"]}),e.jsx("p",{children:"放在哪里跑？分三个层次，缺一不可："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"位置"}),e.jsx("th",{children:"形式"}),e.jsx("th",{children:"作用"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"编辑器"}),e.jsx("td",{children:"VS Code 语言服务实时提示"}),e.jsx("td",{children:"边写边发现，反馈最快，但只看你打开的文件"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"构建脚本"}),e.jsx("td",{children:e.jsx("code",{children:"tsc --noEmit && vite build"})}),e.jsx("td",{children:"打包前先过类型，类型有错就不让打包"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"CI 流水线"}),e.jsxs("td",{children:[e.jsx("code",{children:"npm run typecheck"})," 作为独立步骤"]}),e.jsx("td",{children:"提交 / PR 时全量把关，谁都绕不过"})]})]})]}),e.jsxs(c,{variant:"tip",title:"为什么不在 dev 时阻塞",children:["别把类型检查塞进开发服务器的热更新链路里——它慢，会毁掉「保存即刷新」的爽快体验。 让类型错误在",e.jsx("strong",{children:"编辑器"}),"里以红波浪线提示就够了，真正的「阻塞」放到",e.jsx("strong",{children:"构建"}),"和 ",e.jsx("strong",{children:"CI"})," 这两道关卡。这样既快又安全。"]}),e.jsx("h2",{children:"三、在 npm scripts 里加 typecheck"}),e.jsxs("p",{children:["把类型门禁固化成一个可复用的命令，是工程化的第一步。约定俗成的脚本名叫 ",e.jsx("code",{children:"typecheck"}),"。"]}),e.jsx(s,{lang:"json",title:"package.json：加入 typecheck 脚本",code:t}),e.jsxs("p",{children:["其中 ",e.jsx("code",{children:"build"})," 用 ",e.jsx("code",{children:"&&"})," 把两步串起来：",e.jsx("code",{children:"tsc --noEmit"})," 先跑， 它若发现类型错误会以非零退出码结束，",e.jsx("code",{children:"&&"})," 后面的 ",e.jsx("code",{children:"vite build"})," 就不会执行—— 于是「类型不过就打不出包」。"]}),e.jsxs("p",{children:["如果项目是 Vue，",e.jsx("code",{children:".vue"})," 单文件组件里 ",e.jsx("code",{children:"<template>"})," 内的类型， 普通 ",e.jsx("code",{children:"tsc"})," 是看不懂的，要换成专门的 ",e.jsx("code",{children:"vue-tsc"}),"："]}),e.jsx(s,{lang:"json",title:"Vue 项目用 vue-tsc",code:l}),e.jsx("h2",{children:"四、把类型检查接进 CI"}),e.jsxs("p",{children:["编辑器提示只对「正在看这个文件的人」有效；要保证",e.jsx("strong",{children:"整个团队、每一次提交"}),"都不引入类型错误， 必须把 ",e.jsx("code",{children:"typecheck"})," 放进 CI，让它成为合并代码的硬性门槛。"]}),e.jsx(s,{lang:"bash",title:"CI 中的类型检查步骤（GitHub Actions）",code:j}),e.jsxs("p",{children:["关键在于把 ",e.jsx("code",{children:"npm run typecheck"})," 作为一个",e.jsx("strong",{children:"独立的、会让流水线失败的步骤"}),"。 一旦有人提交了类型错误的代码，这一步会变红，PR 无法合并，问题在进主干前就被挡住。"]}),e.jsx("h2",{children:"五、声明文件 .d.ts 是什么"}),e.jsxs(d,{children:[e.jsx("code",{children:".d.ts"}),"（declaration file，声明文件）是「",e.jsx("strong",{children:"只描述类型、没有任何实现"}),"」的文件。 它告诉编译器「某个东西",e.jsx("em",{children:"长什么样"}),"」——有哪些函数、参数和返回值是什么类型—— 但不包含这些函数",e.jsx("em",{children:"怎么实现"}),"。可以把它理解成一份「类型说明书」。"]}),e.jsxs("p",{children:["为什么需要它？因为类型信息在转译成 JS 后",e.jsx("strong",{children:"会被擦掉"}),"。一个用 TS 写的库， 发布出去的是擦掉类型的 JS（",e.jsx("code",{children:".js"}),"）；如果不额外提供 ",e.jsx("code",{children:".d.ts"}),"， 使用它的人就拿不到任何类型提示。所以 ",e.jsx("code",{children:".d.ts"})," 的作用，就是把那份被擦掉的类型信息",e.jsx("strong",{children:"单独打包随库附带"}),"，让消费者重新获得类型安全。"]}),e.jsx(s,{lang:"ts",title:"一个由 tsc 生成的 .d.ts",code:h}),e.jsxs("p",{children:["注意里面全是 ",e.jsx("code",{children:"declare"}),"、",e.jsx("code",{children:"interface"}),"、类型签名，没有一行函数体。这正是声明文件的本质： 只说「是什么」，不说「怎么做」。"]}),e.jsx("h2",{children:"六、ambient declarations 与 declare module"}),e.jsx("h3",{children:"ambient（环境）声明"}),e.jsxs("p",{children:["当一个 ",e.jsx("code",{children:".d.ts"})," 文件里",e.jsxs("strong",{children:["没有任何顶层 ",e.jsx("code",{children:"import"})," / ",e.jsx("code",{children:"export"})]})," 时， 它的声明是「环境级」的——对整个项目",e.jsx("strong",{children:"全局可见"}),"，无需导入即可使用。 典型用途是描述那些「凭空就存在」的全局变量、给静态资源导入补类型、扩展全局接口等。"]}),e.jsx("h3",{children:"declare module：给无类型的库补类型"}),e.jsxs("p",{children:["现实中总会遇到一些",e.jsxs("strong",{children:["没有自带类型、社区也没有 ",e.jsx("code",{children:"@types"})]})," 的老库。直接 import 它， TS 会报「找不到模块的声明文件」。这时可以用 ",e.jsx("code",{children:"declare module '库名'"})," 自己补一份类型。"]}),e.jsx(s,{lang:"ts",title:"ambient 声明与 declare module",code:o}),e.jsxs(c,{variant:"note",title:"declare module 也用于扩展静态资源导入",children:["像 ",e.jsx("code",{children:"import logo from './logo.svg'"})," 这种导入，本质上不是合法的 JS 模块， 是打包器在帮忙处理。所以要用 ",e.jsx("code",{children:"declare module '*.svg'"})," 告诉 TS「这种导入返回一个字符串」， 否则类型检查会报错。Vite 项目通常已自带 ",e.jsx("code",{children:"vite/client"})," 这份声明。"]}),e.jsx("h2",{children:"七、@types 与 DefinitelyTyped"}),e.jsxs("p",{children:["很多流行的纯 JS 库（如早期的 lodash、express）本身不带类型。社区为它们维护了一个庞大的仓库——",e.jsx("strong",{children:"DefinitelyTyped"}),"，里面是成千上万个 ",e.jsx("code",{children:".d.ts"}),"，以",e.jsx("code",{children:"@types/包名"})," 的形式发布到 npm。"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:["需要某个库的类型时，先看它有没有自带（package.json 里有 ",e.jsx("code",{children:"types"})," 字段就是自带）。"]}),e.jsxs("li",{children:["没自带，就试 ",e.jsx("code",{children:"npm i -D @types/库名"}),"，多半 DefinitelyTyped 已经有了。"]}),e.jsxs("li",{children:["装上后，TS 会自动从 ",e.jsx("code",{children:"node_modules/@types"})," 里捡起这些类型，无需手动 import。"]}),e.jsxs("li",{children:["连 ",e.jsx("code",{children:"@types"})," 也没有的小众 / 内部库，才轮到自己写 ",e.jsx("code",{children:"declare module"}),"。"]})]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"情况"}),e.jsx("th",{children:"处理方式"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsxs("td",{children:["库自带类型（有 ",e.jsx("code",{children:"types"})," 字段）"]}),e.jsx("td",{children:"什么都不用做，直接用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"库无类型，但 DefinitelyTyped 有"}),e.jsx("td",{children:e.jsx("code",{children:"npm i -D @types/库名"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"完全没有现成类型"}),e.jsxs("td",{children:["自己写 ",e.jsx("code",{children:"declare module"})," 补一份"]})]})]})]}),e.jsx("h2",{children:"八、给自己的库产出类型"}),e.jsxs("p",{children:["反过来，如果你",e.jsx("strong",{children:"发布"}),"一个库，就该让用它的人享受到类型提示。这需要两步：",e.jsxs("strong",{children:["生成 ",e.jsx("code",{children:".d.ts"})]}),"，并在 package.json 里用 ",e.jsxs("strong",{children:[e.jsx("code",{children:"types"})," 字段"]}),"指向它。"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:["在 tsconfig 里开 ",e.jsx("code",{children:'"declaration": true'}),"，",e.jsx("code",{children:"tsc"})," 编译时就会在产出 ",e.jsx("code",{children:".js"})," 的同时产出对应的 ",e.jsx("code",{children:".d.ts"}),"。"]}),e.jsxs("li",{children:["在 package.json 里加 ",e.jsx("code",{children:'"types": "./dist/index.d.ts"'}),"，告诉消费者类型入口在哪。"]}),e.jsxs("li",{children:["现代做法还会在 ",e.jsx("code",{children:"exports"})," 字段里也声明 ",e.jsx("code",{children:"types"})," 条件，并确保 ",e.jsx("code",{children:"files"})," 把 ",e.jsx("code",{children:"dist"})," 一起发布。"]})]}),e.jsx(s,{lang:"json",title:"库的 package.json：types 字段",code:x}),e.jsxs(c,{variant:"tip",title:"types 字段是消费者拿到提示的关键",children:["消费者安装你的库后，TS 正是顺着 package.json 的 ",e.jsx("code",{children:"types"}),"（或 ",e.jsx("code",{children:"exports"})," 里的",e.jsx("code",{children:"types"})," 条件）去找声明文件的。",e.jsx("strong",{children:"忘了配 types 字段，或忘了把 .d.ts 发布出去"}),"， 用户就只能得到一个「没有类型」的库——这是发布 TS 库最常见的疏漏。"]}),e.jsx("h2",{children:"九、把整条链路串起来"}),e.jsx("p",{children:"回到全局视角，一个成熟的 TS 项目里，类型与构建是这样分工的："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"编辑器"}),"读 tsconfig，实时给你红波浪线——反馈最快，不阻塞。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"打包器"}),"（Vite / esbuild / SWC）只转译、不检查——产物快，但对类型一无所知。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"tsc --noEmit"})}),"（或 ",e.jsx("code",{children:"vue-tsc"}),"）当独立门禁——构建脚本里前置一次，CI 里全量再来一次。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"声明文件"}),"把类型信息在库的边界上传递——消费 ",e.jsx("code",{children:"@types"}),"，产出时配好 ",e.jsx("code",{children:"types"})," 字段。"]})]}),e.jsxs("p",{children:["理解了「转译和类型检查是两件可拆开的事」，你就不会再被「构建通过」迷惑， 也能解释清楚为什么团队需要 ",e.jsx("code",{children:"typecheck"})," 脚本和 CI 门禁——它们补的，正是构建工具",e.jsx("strong",{children:"故意"}),"留下的那道缺口。"]}),e.jsx(i,{points:["Vite / esbuild / SWC 只做转译（擦类型、降语法），故意不做类型检查，所以类型错误不会让构建失败——构建成功不等于类型正确。","类型保障要靠独立的门禁 tsc --noEmit（Vue 用 vue-tsc --noEmit）：只检查、不产出，把转译交给打包器。","类型检查放三处：编辑器实时提示（不阻塞）、构建脚本前置（tsc --noEmit && vite build）、CI 独立步骤（全量把关），但不要塞进 dev 热更新拖慢速度。",".d.ts 声明文件只描述类型、无实现；没有 import/export 的是 ambient 全局声明；declare module 可给无类型的库或静态资源导入补类型。","@types 来自 DefinitelyTyped：库无自带类型时优先装 @types/库名，都没有才自己写 declare module。","发布库要让消费者有类型：开 declaration:true 生成 .d.ts，并在 package.json 的 types 字段（及 exports 的 types 条件）指向它、把 dist 一并发布。"]})]})}export{b as default};
