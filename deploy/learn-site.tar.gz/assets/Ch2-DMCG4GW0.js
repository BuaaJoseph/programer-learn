import{j as e}from"./index-qtIRnDEm.js";import{L as i,S as o}from"./Summary-D7M9FdYM.js";import{K as c}from"./KeyIdea-C5mX38F7.js";import{C as s}from"./Callout-Bvq_rfqV.js";import{C as t}from"./CodeBlock-DsDQiuPI.js";import{E as r}from"./Example-Ba1iSJHN.js";const a=`// stores/cart.js —— 购物车 store（组合式写法）
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useCartStore = defineStore('cart', () => {
  // ===== state =====
  // items：购物车里的商品列表，每项 { id, name, price, qty }
  const items = ref([])
  // loading：标记是否正在和服务端交互，用来在 UI 上禁用按钮 / 显示转圈
  const loading = ref(false)

  // ===== getters =====
  // 商品总件数：把每个商品的数量累加
  const totalCount = computed(() =>
    items.value.reduce((sum, item) => sum + item.qty, 0)
  )
  // 总价：单价 * 数量 再累加
  const totalPrice = computed(() =>
    items.value.reduce((sum, item) => sum + item.price * item.qty, 0)
  )
  // 是否为空，方便组件直接用
  const isEmpty = computed(() => items.value.length === 0)

  // 模拟一个异步接口（真实项目里换成 fetch / axios）
  function fakeApi(payload) {
    return new Promise((resolve) => setTimeout(() => resolve(payload), 400))
  }

  // ===== actions =====
  // 加入购物车：已存在则数量 +n，否则新增一项；过程中模拟调接口同步到服务端
  async function addToCart(product, n = 1) {
    loading.value = true
    try {
      const existing = items.value.find((it) => it.id === product.id)
      if (existing) {
        existing.qty += n
      } else {
        items.value.push({ ...product, qty: n })
      }
      await fakeApi({ id: product.id, qty: n }) // 模拟同步到后端
    } finally {
      loading.value = false // 无论成功失败都要复位 loading
    }
  }

  // 从购物车删除某个商品
  async function removeFromCart(id) {
    loading.value = true
    try {
      items.value = items.value.filter((it) => it.id !== id)
      await fakeApi({ id })
    } finally {
      loading.value = false
    }
  }

  // 修改数量；数量降到 0 或以下就直接删除
  async function updateQty(id, qty) {
    const target = items.value.find((it) => it.id === id)
    if (!target) return
    if (qty <= 0) {
      await removeFromCart(id)
      return
    }
    target.qty = qty
    await fakeApi({ id, qty })
  }

  // 清空购物车（演示 reset 思路）
  function clear() {
    items.value = []
  }

  return {
    items, loading,
    totalCount, totalPrice, isEmpty,
    addToCart, removeFromCart, updateQty, clear,
  }
})`,n=`<!-- components/ProductList.vue —— 商品列表组件（生产方） -->
<script setup>
import { useCartStore } from '@/stores/cart'

const cart = useCartStore()

// 一批演示商品
const products = [
  { id: 1, name: 'Vue 贴纸', price: 5 },
  { id: 2, name: 'Pinia T 恤', price: 99 },
  { id: 3, name: '组合式 API 手册', price: 49 },
]
<\/script>

<template>
  <ul>
    <li v-for="p in products" :key="p.id">
      {{ p.name }} —— ￥{{ p.price }}
      <!-- 调 action 加购；loading 时禁用按钮，避免重复提交 -->
      <button :disabled="cart.loading" @click="cart.addToCart(p)">
        {{ cart.loading ? '处理中…' : '加入购物车' }}
      </button>
    </li>
  </ul>
</template>`,d=`<!-- components/CartBadge.vue —— 购物车角标组件（消费方） -->
<script setup>
import { storeToRefs } from 'pinia'
import { useCartStore } from '@/stores/cart'

const cart = useCartStore()
// 用 storeToRefs 解构响应式的 state / getters，保持响应性
const { totalCount, totalPrice, isEmpty } = storeToRefs(cart)
// action 直接从 store 解构
const { clear } = cart
<\/script>

<template>
  <div class="badge">
    <span>🛒 {{ totalCount }} 件</span>
    <span v-if="!isEmpty">合计 ￥{{ totalPrice }}</span>
    <button v-if="!isEmpty" @click="clear">清空</button>
  </div>
</template>`,l=`// 几个常用工具方法（在 action 内部或组件里都能调）

// $reset()：把 state 重置回初始值（仅选项式 store 自带；
//   组合式 store 需自己写一个 clear/reset action，如上面的 clear）
store.$reset()

// $patch()：批量改多个 state，比一条条赋值更高效、devtools 里合并成一次记录
store.$patch({ loading: false })
store.$patch((state) => { state.items.push(newItem) })

// $subscribe()：订阅 state 变化，常用于自己手写持久化
store.$subscribe((mutation, state) => {
  localStorage.setItem('cart', JSON.stringify(state.items))
})`;function f(){return e.jsxs("article",{children:[e.jsxs(i,{children:["上一章讲清了 Pinia 的原理，这一章我们把它跑起来：搭一个完整、可运行的购物车 store， 让两个毫无父子关系的组件——商品列表和购物车角标——共享同一份状态。你会看到 state、getters、 异步 action、loading 处理、",e.jsx("code",{children:"storeToRefs"})," 如何在真实场景里各司其职， 并顺带认识 ",e.jsx("code",{children:"$reset"})," / ",e.jsx("code",{children:"$patch"})," / ",e.jsx("code",{children:"$subscribe"})," 这几个实用 API。"]}),e.jsx("h2",{children:"一、需求拆解：购物车要管什么"}),e.jsx("p",{children:"购物车是状态管理的经典案例，因为它天然满足「跨组件共享」："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"商品列表组件"}),"负责把商品加进购物车（数据的生产方）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"购物车角标组件"}),"（通常在页面顶部）要实时显示「共几件、合计多少钱」（数据的消费方）。"]}),e.jsx("li",{children:"这两个组件在组件树里往往离得很远，没有父子关系，用 props/events 几乎无法传递。"})]}),e.jsxs(c,{children:["把购物车状态放进一个 ",e.jsx("code",{children:"useCartStore"}),"，生产方和消费方各自调用它拿到",e.jsx("strong",{children:"同一个单例"}),"。 商品列表调 action 改数据，角标组件读 getters 显示数据，两者通过 store 自动联动， 完全不需要知道对方的存在。这就是状态管理解耦组件的威力。"]}),e.jsx("p",{children:"我们的 store 需要：state 存商品列表和一个 loading 标记；getters 算总件数、总价、是否为空； actions 提供加入、删除、改数量、清空，并在其中模拟调用后端接口。"}),e.jsx("h2",{children:"二、完整的购物车 store"}),e.jsxs("p",{children:["采用上一章推荐的",e.jsx("strong",{children:"组合式写法"}),"。注意几个要点：state 用 ",e.jsx("code",{children:"ref"})," 定义； getters 用 ",e.jsx("code",{children:"computed"})," 并通过 ",e.jsx("code",{children:"reduce"})," 做累加；异步 action 用",e.jsx("code",{children:"try / finally"})," 保证 loading 一定会复位；最后把所有要暴露的东西 ",e.jsx("code",{children:"return"})," 出来。"]}),e.jsx(t,{lang:"js",title:"stores/cart.js",code:a}),e.jsxs(s,{variant:"info",title:"getters 里的 reduce 会自动重算吗",children:["会，而且只在该重算时重算。",e.jsx("code",{children:"totalPrice"})," 是 ",e.jsx("code",{children:"computed"}),"，它依赖",e.jsx("code",{children:"items"}),"。只要 items 没变，多个组件反复读 totalPrice 都走缓存；一旦 items 增删改，它就自动失效并重新累加——这正是把派生值放进 getters 而非组件里手算的好处。"]}),e.jsx("h3",{children:"异步 action 与 loading 的处理"}),e.jsxs("p",{children:["真实项目里「加入购物车」往往要同步到服务端，是个异步操作。我们用 ",e.jsx("code",{children:"loading"})," 这个 state 标记进行中状态：进入 action 先置 ",e.jsx("code",{children:"true"}),"，在 ",e.jsx("code",{children:"finally"})," 里置回 ",e.jsx("code",{children:"false"}),"。 放在 finally 是关键——即便接口报错，loading 也能被复位，不会让按钮永远卡在「处理中」。"]}),e.jsx(r,{title:"为什么用 try / finally 而不是顺序赋值",children:e.jsxs("p",{children:["如果写成「",e.jsx("code",{children:"loading=true"})," → await 接口 → ",e.jsx("code",{children:"loading=false"}),"」的顺序赋值， 一旦接口抛错，",e.jsx("code",{children:"loading=false"})," 那行就被跳过了，UI 会永远停在加载态。 把复位放进 ",e.jsx("code",{children:"finally"}),"，无论成功还是抛异常都会执行，这是处理 loading 的标准姿势。"]})}),e.jsx("h2",{children:"三、生产方：商品列表组件"}),e.jsxs("p",{children:["商品列表只负责「往购物车加东西」。它调用 ",e.jsx("code",{children:"useCartStore()"})," 拿到 store，点击按钮时调用",e.jsx("code",{children:"cart.addToCart(p)"}),"。注意按钮上绑了 ",e.jsx("code",{children:':disabled="cart.loading"'}),"—— 加购在途时禁用按钮，避免用户连点造成重复提交。这里直接用 ",e.jsx("code",{children:"cart.loading"})," 访问， 在模板里访问 store 字段是响应式的，无需 storeToRefs。"]}),e.jsx(t,{lang:"vue",title:"components/ProductList.vue",code:n}),e.jsx("h2",{children:"四、消费方：购物车角标组件"}),e.jsxs("p",{children:["角标组件只负责「显示」。它同样调 ",e.jsx("code",{children:"useCartStore()"})," 拿到",e.jsx("strong",{children:"同一个"})," store 实例。 这里我们要在 ",e.jsx("code",{children:"<script setup>"})," 里把 totalCount 等取出来用，所以必须用",e.jsx("code",{children:"storeToRefs"})," 解构，才能保持响应性；而 ",e.jsx("code",{children:"clear"})," 是 action，直接从 store 解构。"]}),e.jsx(t,{lang:"vue",title:"components/CartBadge.vue",code:d}),e.jsxs(s,{variant:"warn",title:"别在 script 里直接解构 state",children:["如果这里写成 ",e.jsx("code",{children:"const { totalCount } = cart"}),"，totalCount 会变成一个普通数字， 之后购物车再变它也不会更新，角标就「定格」了。务必用 ",e.jsx("code",{children:"storeToRefs(cart)"})," 解构 state 和 getters；action（如 clear）则直接解构。这是上一章那条规则在实战里的体现。"]}),e.jsx(r,{title:"两个组件如何联动",children:e.jsxs("p",{children:["用户在 ProductList 点「加入购物车」→ 触发 ",e.jsx("code",{children:"addToCart"})," action → 修改了 store 里的",e.jsx("code",{children:"items"})," → ",e.jsx("code",{children:"totalCount"})," / ",e.jsx("code",{children:"totalPrice"})," 这两个 getter 自动重算 → CartBadge 因为用 storeToRefs 持有它们的响应式引用，界面立刻更新。 全程两个组件没有任何直接通信，全靠 store 这个中间人。"]})}),e.jsx("h2",{children:"五、几个实用 API：$reset / $patch / $subscribe"}),e.jsxs("p",{children:["store 实例上还挂着几个以 ",e.jsx("code",{children:"$"})," 开头的内置方法，实战里经常用到："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方法"}),e.jsx("th",{children:"作用"}),e.jsx("th",{children:"典型场景"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"$reset()"})}),e.jsx("td",{children:"把 state 重置回初始值"}),e.jsx("td",{children:"退出登录、清空表单（选项式 store 自带；组合式需自写 reset action）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"$patch()"})}),e.jsx("td",{children:"批量修改多个 state"}),e.jsx("td",{children:"一次改多个字段，devtools 里合并成一条记录"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"$subscribe()"})}),e.jsx("td",{children:"订阅 state 的每次变化"}),e.jsx("td",{children:"手写持久化，把变化同步进 localStorage"})]})]})]}),e.jsx(t,{lang:"js",title:"$reset / $patch / $subscribe 速览",code:l}),e.jsxs(s,{variant:"info",title:"组合式 store 没有自带 $reset",children:[e.jsx("code",{children:"$reset()"})," 依赖「初始 state 工厂函数」，这是选项式写法才有的信息。组合式 store 请像我们 cart 里的 ",e.jsx("code",{children:"clear()"})," 那样，自己写一个把各 ref 复位的 action。这点别踩坑。"]}),e.jsx("h2",{children:"六、测试 store"}),e.jsxs("p",{children:["store 是纯逻辑、不依赖 DOM，因此非常好测。测试时只需在每个用例前用",e.jsx("code",{children:"setActivePinia(createPinia())"})," 创建一个干净的 Pinia 实例，然后调",e.jsx("code",{children:"useCartStore()"}),"，像调普通对象一样断言它的 state、调它的 action、检查 getters 是否随之变化即可——这也是 Pinia 相比 Vuex 在可测试性上的一大优势。"]}),e.jsx("h2",{children:"七、小结这套写法的好处"}),e.jsxs("p",{children:["回头看这个购物车：所有数据和业务逻辑都收敛在一个文件 ",e.jsx("code",{children:"stores/cart.js"})," 里， 组件只管「调 action、读 getter、展示」，职责清晰。新增一个「侧边栏迷你购物车」组件？ 再调一次 ",e.jsx("code",{children:"useCartStore()"})," 就能接入同一份数据，零额外成本。这就是把共享状态 集中管理带来的可维护性。"]}),e.jsx(o,{points:["购物车是跨组件共享的典型：商品列表（生产方）与购物车角标（消费方）通过同一个 useCartStore 单例联动，互不直接通信。","store 用组合式写法：items/loading 是 state，totalCount/totalPrice/isEmpty 用 computed 做 getters，加入/删除/改数量是 actions。","异步 action 用 loading 标记进行中状态，并在 try/finally 的 finally 里复位 loading，保证报错时也不会卡在加载态。","消费方组件在 script 里取 state/getters 必须用 storeToRefs 保持响应性，action（如 clear）直接解构；模板里直接访问 store 字段则天然响应式。","$reset 重置 state（组合式需自写 reset action）、$patch 批量改、$subscribe 订阅变化常用于持久化。","store 是纯逻辑，测试时用 setActivePinia(createPinia()) 起干净实例再断言，可测试性优于 Vuex；状态集中后新增消费组件零成本。"]})]})}export{f as default};
