import{j as e}from"./index-BdVncPlI.js";import{L as n,S as r}from"./Summary-Baiwq3-G.js";import{K as c}from"./KeyIdea-Cnr-5ipR.js";import{C as t}from"./Callout-BRUKkrb4.js";import{C as s}from"./CodeBlock-DCdshbU5.js";import{E as l}from"./Example-phQ905Fb.js";const o=`import { useMemo } from 'react'

function ProductList({ products, query }) {
  // 只有 products 或 query 变化时才重新过滤；否则复用上次的计算结果
  const filtered = useMemo(() => {
    console.log('重新过滤（昂贵计算）')
    return products.filter((p) => p.name.includes(query))
  }, [products, query])

  return <ul>{filtered.map((p) => <li key={p.id}>{p.name}</li>)}</ul>
}`,d=`import { useCallback, memo } from 'react'

// 被 memo 包裹的子组件：props 不变就跳过重渲染
const Child = memo(function Child({ onClick }) {
  console.log('Child 渲染')
  return <button onClick={onClick}>点我</button>
})

function Parent({ id }) {
  // 没有 useCallback 的话，每次 Parent 渲染都会新建一个 handleClick 函数引用，
  // 导致 memo 的 Child 误以为 props 变了而重渲染。useCallback 缓存住这个引用。
  const handleClick = useCallback(() => {
    console.log('clicked', id)
  }, [id])

  return <Child onClick={handleClick} />
}`,i=`// useMemo 和 useCallback 本质是同一件事：缓存。下面两行完全等价
const fn = useCallback(() => doSomething(a), [a])
const fn = useMemo(() => () => doSomething(a), [a])
// useCallback(fn, deps) 就是 useMemo(() => fn, deps) 的语法糖`,u=`// 反例：给每一个普通值都套 useMemo——纯属增加成本
const sum = useMemo(() => a + b, [a, b]) // a + b 本来就极快，缓存它反而更慢
const obj = useMemo(() => ({ a, b }), [a, b]) // 若没有下游 memo 子组件消费，毫无意义

// useMemo / useCallback 本身有开销：要存上次的依赖、做比较、占内存。
// 只有当"被缓存的东西很贵"或"引用稳定性本身有意义"时，收益才大于成本。`,a=`import { useRef, useState } from 'react'

function Stopwatch() {
  const [time, setTime] = useState(0)
  const intervalRef = useRef(null) // 存一个跨渲染保持、且改它不触发重渲染的值

  function start() {
    if (intervalRef.current) return
    intervalRef.current = setInterval(() => setTime((t) => t + 1), 1000)
  }
  function stop() {
    clearInterval(intervalRef.current)
    intervalRef.current = null
  }

  return <>
    <p>{time}s</p>
    <button onClick={start}>开始</button>
    <button onClick={stop}>停止</button>
  </>
}`,h=`function TextInput() {
  const inputRef = useRef(null) // 引用一个 DOM 节点

  function focusInput() {
    inputRef.current.focus() // 命令式地操作真实 DOM
  }

  return <>
    <input ref={inputRef} />
    <button onClick={focusInput}>聚焦输入框</button>
  </>
}`,x=`import { useState, useEffect } from 'react'

// 自定义 Hook：以 use 开头，内部组合内置 hook，抽取"读写 localStorage 的有状态逻辑"
function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    // 惰性初始化：只在首次渲染时读一次 localStorage
    try {
      const stored = localStorage.getItem(key)
      return stored ? JSON.parse(stored) : initialValue
    } catch {
      return initialValue
    }
  })

  // value 变化时把它同步回 localStorage（这是与外部系统同步，正好用 effect）
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch {
      /* 忽略写入失败，如隐私模式 */
    }
  }, [key, value])

  return [value, setValue] // 返回的接口和 useState 一模一样，调用方零学习成本
}

// 使用：和 useState 用法完全一致，但值会自动持久化
function Settings() {
  const [theme, setTheme] = useLocalStorage('theme', 'light')
  return <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>
    当前主题：{theme}
  </button>
}`,j=`import { useState, useEffect } from 'react'

// 另一个常用自定义 Hook：把一个频繁变化的值"防抖"到延迟后才更新
function useDebounce(value, delay = 300) {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delay)
    return () => clearTimeout(id) // 值在 delay 内又变了就取消上一个计时，重新计时
  }, [value, delay])

  return debounced
}

// 使用：输入框每次敲键 query 都变，但 debouncedQuery 要停顿 300ms 才更新，
// 用它去触发搜索请求就能避免每敲一下都发一次请求。
function Search() {
  const [query, setQuery] = useState('')
  const debouncedQuery = useDebounce(query, 300)
  // ...用 debouncedQuery 发请求
  return <input value={query} onChange={(e) => setQuery(e.target.value)} />
}`;function S(){return e.jsxs("article",{children:[e.jsxs(n,{children:['这一章收尾几个"工具型" Hook：',e.jsx("code",{children:"useMemo"})," 和 ",e.jsx("code",{children:"useCallback"})," 用来做 性能优化（缓存计算结果和函数引用），",e.jsx("code",{children:"useRef"}),' 用来存"跨渲染保持、改动不触发 重渲染"的值或引用 DOM。最后我们学习把有状态逻辑抽成',e.jsx("strong",{children:"自定义 Hook"})," 来复用—— 这是 Hooks 真正威力的体现。"]}),e.jsx("h2",{children:"一、useMemo：缓存昂贵的计算结果"}),e.jsxs("p",{children:[e.jsx("code",{children:"useMemo(fn, deps)"})," 会缓存 ",e.jsx("code",{children:"fn"})," 的返回值，只有当依赖",e.jsx("code",{children:"deps"}),' 变化时才重新计算，否则直接返回上次的结果。它解决的是 "每次渲染都重复跑一段昂贵计算"的浪费。']}),e.jsx(s,{lang:"jsx",title:"用 useMemo 缓存过滤结果",code:o}),e.jsx("h2",{children:"二、useCallback：缓存函数引用"}),e.jsxs("p",{children:[e.jsx("code",{children:"useCallback(fn, deps)"})," 缓存的不是计算结果，而是",e.jsx("strong",{children:"函数本身的引用"}),"。 每次组件渲染，函数字面量都会被重新创建成一个新引用；如果这个函数要传给被",e.jsx("code",{children:"React.memo"})," 包裹的子组件，新引用会让子组件误以为 props 变了而重渲染。 useCallback 让引用在依赖不变时保持稳定。"]}),e.jsx(s,{lang:"jsx",title:"用 useCallback 稳定传给 memo 子组件的回调",code:d}),e.jsxs(c,{children:[e.jsx("code",{children:"useMemo"})," 和 ",e.jsx("code",{children:"useCallback"})," 本质是",e.jsx("strong",{children:"同一件事"}),"：缓存。",e.jsx("code",{children:"useCallback(fn, deps)"})," 不过是 ",e.jsx("code",{children:"useMemo(() => fn, deps)"}),"的语法糖——一个缓存值、一个缓存函数（而函数也是一种值）。"]}),e.jsx(s,{lang:"jsx",title:"两者等价关系",code:i}),e.jsx("h2",{children:"三、它们是优化，不是默认操作"}),e.jsxs("p",{children:["这是最关键、也最容易被新手做反的一点：",e.jsx("code",{children:"useMemo"})," / ",e.jsx("code",{children:"useCallback"}),"本身",e.jsx("strong",{children:"有成本"}),"——要保存上一次的依赖、每次渲染做依赖比较、占用额外内存。 给所有东西无脑套上它们，往往让代码更慢、更难读。"]}),e.jsx(s,{lang:"jsx",title:"过度使用的反例",code:u}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"真正值得缓存的场景"}),e.jsx("th",{children:"说明"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"计算确实昂贵"}),e.jsx("td",{children:"大数组的排序 / 过滤、复杂派生数据，且依赖不常变"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["配合 ",e.jsx("code",{children:"React.memo"})]}),e.jsx("td",{children:"把稳定的对象 / 函数作为 props 传给被 memo 的子组件，避免其无谓重渲染"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"作为其它 hook 的依赖"}),e.jsx("td",{children:"把对象 / 函数放进另一个 useEffect / useMemo 的依赖数组，需要它引用稳定"})]})]})]}),e.jsxs(t,{variant:"warn",title:"先测量，再优化",children:["不要凭感觉到处加 memo。性能优化应当由实际的卡顿和 Profiler 数据驱动。 对一个加减法或一次性渲染的小列表套 ",e.jsx("code",{children:"useMemo"}),"，收益可能远小于它自身的开销。"]}),e.jsx("h2",{children:"四、useRef：跨渲染不变且不触发渲染的可变值"}),e.jsxs("p",{children:[e.jsx("code",{children:"useRef"})," 返回一个 ",e.jsx("code",{children:"{ current: ... }"})," 对象，它有两个关键特性： ① 在多次渲染之间",e.jsx("strong",{children:"保持同一个对象"}),"；② 改 ",e.jsx("code",{children:"current"}),e.jsx("strong",{children:"不会触发重渲染"}),"。它有两大用途。"]}),e.jsx("h3",{children:"用途一：存一个可变值"}),e.jsx("p",{children:'适合存那些"需要跨渲染记住、但又不影响 UI"的东西，比如定时器 ID、上一次的某个值、 外部库的实例。改它不该让组件重渲染——这正是 ref 和 state 的分工。'}),e.jsx(s,{lang:"jsx",title:"用 ref 存定时器 ID",code:a}),e.jsx("h3",{children:"用途二：引用 DOM 节点"}),e.jsxs("p",{children:["把 ref 通过 ",e.jsxs("code",{children:["ref=","{inputRef}"]})," 挂到 JSX 元素上，",e.jsx("code",{children:"inputRef.current"})," 就指向真实 DOM 节点，可命令式地调用",e.jsx("code",{children:"focus()"}),"、",e.jsx("code",{children:"scrollIntoView()"})," 等。"]}),e.jsx(s,{lang:"jsx",title:"用 ref 引用并聚焦 DOM",code:h}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"对比"}),e.jsx("th",{children:"useState"}),e.jsx("th",{children:"useRef"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"改动是否触发重渲染"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"否"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"跨渲染是否保持"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"是"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"读取方式"}),e.jsx("td",{children:"直接读变量"}),e.jsxs("td",{children:["读 ",e.jsx("code",{children:".current"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"典型用途"}),e.jsx("td",{children:"影响 UI 的数据"}),e.jsx("td",{children:"定时器 ID、DOM 引用、不影响 UI 的可变值"})]})]})]}),e.jsx("h2",{children:"五、自定义 Hook：复用有状态逻辑"}),e.jsxs(c,{children:["自定义 Hook 就是一个",e.jsxs("strong",{children:["以 ",e.jsx("code",{children:"use"})," 开头"]}),"、内部",e.jsx("strong",{children:"组合了其它内置 Hook"}),'的普通函数。它的价值在于把"有状态的逻辑"抽取出来，在多个组件间复用—— 复用的是逻辑，不是状态本身（每个组件调用它都得到独立的状态）。']}),e.jsxs("p",{children:["下面写一个完整的 ",e.jsx("code",{children:"useLocalStorage"}),'：它把"读写 localStorage 并保持一个 state 与之同步" 这整套逻辑封装起来，对外暴露的接口和 ',e.jsx("code",{children:"useState"})," 完全一样，调用方几乎零学习成本。"]}),e.jsx(s,{lang:"jsx",title:"完整示例：useLocalStorage",code:x}),e.jsx(l,{title:"自定义 Hook 复用的是逻辑，不是状态",children:e.jsxs("p",{children:["如果组件 A 和组件 B 都调用 ",e.jsx("code",{children:"useLocalStorage('theme', 'light')"}),"， 它们各自得到一份",e.jsx("strong",{children:"独立"}),"的 ",e.jsx("code",{children:"value"})," / ",e.jsx("code",{children:"setValue"}),'—— 共享的只是那段"如何读写 localStorage"的逻辑代码。这和把状态提到父组件再传下去 （那是共享状态）是两回事。']})}),e.jsxs("p",{children:["再看一个高频的 ",e.jsx("code",{children:"useDebounce"}),'，它把"防抖"这一行为抽成可复用的 Hook。']}),e.jsx(s,{lang:"jsx",title:"完整示例：useDebounce",code:j}),e.jsx(t,{variant:"info",title:"自定义 Hook 的几条约定",children:e.jsxs("ul",{children:[e.jsxs("li",{children:["名字必须以 ",e.jsx("code",{children:"use"})," 开头——这样 ESLint 才知道按 Hook 规则检查它。"]}),e.jsx("li",{children:'内部可以调用任意内置或其它自定义 Hook，但同样要遵守"只在顶层调用"的规则。'}),e.jsxs("li",{children:["它返回什么由你决定：可以仿照 ",e.jsx("code",{children:"useState"})," 返回数组，也可以返回对象。"]})]})}),e.jsx("h2",{children:"六、React 19 之后：手动 memo 正在变少"}),e.jsx("p",{children:"最后展望一下趋势。React 19 带来了若干新 Hook 与编译器，正在改变上面这些手动优化的写法。"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"新东西"}),e.jsx("th",{children:"它做什么"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("strong",{children:"React Compiler"})}),e.jsxs("td",{children:["在构建时自动分析并插入 memo 化，让你大多数情况下",e.jsx("strong",{children:"不必再手写"}),e.jsx("code",{children:"useMemo"})," / ",e.jsx("code",{children:"useCallback"})," / ",e.jsx("code",{children:"React.memo"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"useOptimistic"})}),e.jsx("td",{children:'在异步操作完成前先乐观地更新 UI，提交失败再回滚，简化"先显示后确认"的体验'})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"use"})}),e.jsx("td",{children:"一个可在渲染中读取 Promise / Context 的新原语，能配合 Suspense 更顺滑地处理异步"})]})]})]}),e.jsxs(t,{variant:"tip",children:["方向很明确：随着 React Compiler 普及，手动 ",e.jsx("code",{children:"useMemo"})," / ",e.jsx("code",{children:"useCallback"}),'会越来越少出现在业务代码里。但理解它们"为什么存在、解决什么问题"依然重要—— 编译器做的正是你现在手动在做的事，懂原理才能看懂它在帮你做什么。']}),e.jsx(r,{points:["useMemo 缓存计算结果、useCallback 缓存函数引用，本质同一件事；useCallback(fn,deps) 等价于 useMemo(()=>fn,deps)。","它们是性能优化而非默认操作，自身有开销；滥用反而更慢，应在确有昂贵计算、配合 React.memo 或作为其它 hook 依赖时才用。",'useRef 存"跨渲染保持、改动不触发重渲染"的可变值（如定时器 ID），也用于引用真实 DOM 节点。',"useRef 与 useState 的分工：影响 UI 的数据用 state，不影响 UI 的可变值用 ref。","自定义 Hook 是以 use 开头、组合内置 hook 的函数，用于复用有状态逻辑（复用逻辑而非状态），如 useLocalStorage / useDebounce。","React 19 的 React Compiler 可自动 memo 化，配合 useOptimistic / use 让手动 memo 越来越少，但理解原理仍然必要。"]})]})}export{S as default};
