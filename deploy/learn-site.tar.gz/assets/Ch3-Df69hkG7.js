import{j as e}from"./index-Bs06kW3a.js";import{L as s,S as t}from"./Summary-CLAN1smq.js";import{K as n}from"./KeyIdea-iVczm-9t.js";import{E as d}from"./Example-XOtO_AMb.js";import{P as l}from"./Practice-CjxPZLe_.js";import{C as i}from"./Callout-BCaSeUge.js";import{C as r}from"./CodeBlock-BUaxuxwl.js";const a=`# 用内置 standard 分析器切中文，看看会发生什么
POST _analyze
{
  "analyzer": "standard",
  "text": "苹果手机很好用"
}`,o=`# 用 ik_smart（粗粒度）切同一句话
POST _analyze
{
  "analyzer": "ik_smart",
  "text": "苹果手机很好用"
}

# 用 ik_max_word（细粒度）切同一句话
POST _analyze
{
  "analyzer": "ik_max_word",
  "text": "苹果手机很好用"
}`,c=`# 建索引时给 text 字段指定 ik 分析器
PUT /articles
{
  "mappings": {
    "properties": {
      "title": {
        "type": "text",
        "analyzer": "ik_max_word",
        "search_analyzer": "ik_smart"
      },
      "tag": { "type": "keyword" }
    }
  }
}`,x=`# 同一字段同时建 text（全文搜）与 keyword（精确/聚合）子字段
PUT /products
{
  "mappings": {
    "properties": {
      "name": {
        "type": "text",
        "analyzer": "ik_max_word",
        "fields": {
          "raw": { "type": "keyword" }   // 用 name.raw 做聚合/排序/精确匹配
        }
      }
    }
  }
}

# 全文搜用 name，聚合用 name.raw
GET /products/_search
{
  "size": 0,
  "aggs": { "by_name": { "terms": { "field": "name.raw" } } }
}`,h=`# 自定义分析器：HTML 去标签 + ik 切词 + 自定义停用词
PUT /blog
{
  "settings": {
    "analysis": {
      "analyzer": {
        "my_cn": {
          "char_filter": ["html_strip"],
          "tokenizer": "ik_max_word",
          "filter": ["lowercase", "my_stop"]
        }
      },
      "filter": {
        "my_stop": { "type": "stop", "stopwords": ["的", "了", "和"] }
      }
    }
  }
}`;function g(){return e.jsxs(e.Fragment,{children:[e.jsx(s,{children:e.jsxs("p",{children:["上一章看到，倒排索引的 key 是分词产生的一个个 term。那么「怎么切词」就直接决定了「能不能搜到」。 负责切词的组件叫 ",e.jsx("em",{children:"analyzer"}),"（分析器）。这一章讲清它的组成、为什么建索引和查询的分词必须一致， 以及中文为什么几乎一定要装 ik 分词器——这是 ES 中文场景最容易踩的坑。"]})}),e.jsx("h2",{children:"analyzer 的三段流水线"}),e.jsx("p",{children:"一个 analyzer 由三部分按顺序组成，像一条流水线："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"character filter（字符过滤器）"}),"——在分词前对原始字符做预处理， 比如去掉 HTML 标签、替换字符。可有可无、可多个。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"tokenizer（分词器）"}),"——核心，负责把字符流切成一个个 token（词）。 有且只有一个，中文能不能切对，主要看它。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"token filter（词元过滤器）"}),"——对切出来的 token 再加工， 比如转小写、去停用词、加同义词。可有可多个。"]})]}),e.jsx("p",{children:"内置的 standard 分析器就是「无 char filter + standard tokenizer + 小写 token filter」的组合。 理解了这条流水线，你就知道想定制分词时该改哪一段：要去标签改 char filter、要换切词方式改 tokenizer、 要加同义词或停用词改 token filter。下面就是一个把三段都用上的自定义分析器。"}),e.jsx(r,{lang:"json",title:"自定义分析器：三段都用上",code:h}),e.jsx("h3",{children:"建索引分词 与 查询分词 必须一致"}),e.jsxs("p",{children:["这是最关键、也最容易被忽略的一点。文档写入时会用 analyzer 切词建倒排索引（叫",e.jsx("em",{children:"index analyzer"}),"）；用户查询时，查询词也要先被切成 term，再去倒排索引里比对（叫",e.jsx("em",{children:"search analyzer"}),"）。如果两边用了不同的切法，切出来的 term 对不上， 倒排索引里明明有数据，却",e.jsx("strong",{children:"怎么也搜不到"}),"。默认两边用同一个 analyzer， 正是为了保证一致；只有在明确知道自己要干嘛时，才单独指定 ",e.jsx("code",{children:"search_analyzer"}),"。"]}),e.jsxs("p",{children:["那为什么还要故意让两边不同？典型理由是",e.jsx("strong",{children:"「索引时细切多召回、查询时粗切保准确」"}),"： 建索引用 ik_max_word 把「苹果手机」既存「苹果」「手机」也存「苹果手机」，让更多词都能命中； 查询用 ik_smart 只切成「苹果手机」一个词，避免把「手机壳」「手机膜」这类无关结果也捞进来。 这种「不一致」是受控的、刻意为之的，前提是你清楚两个分析器切出的 term 仍有交集。"]}),e.jsxs(d,{title:"standard 切中文：按字切，灾难现场",children:[e.jsxs("p",{children:["内置 standard 分析器对英文很好用（按空格、标点切），但它",e.jsx("strong",{children:"不认识中文词"}),"， 只会把中文按单个字切开。「苹果手机很好用」会被切成："]}),e.jsx("ul",{children:e.jsxs("li",{children:[e.jsx("code",{children:"苹"}),"、",e.jsx("code",{children:"果"}),"、",e.jsx("code",{children:"手"}),"、",e.jsx("code",{children:"机"}),"、",e.jsx("code",{children:"很"}),"、",e.jsx("code",{children:"好"}),"、",e.jsx("code",{children:"用"})]})}),e.jsx("p",{children:"于是倒排索引里只有单字，没有「苹果」「手机」这种词。用户搜「华为手机」时， 「手」「机」也能命中——结果一堆不相关的文档混进来，相关性彻底崩了。这就是为什么中文必须换分词器。"})]}),e.jsx(n,{title:"中文必须装 ik",children:e.jsxs("p",{children:["ik 是最常用的中文分词器，装好后提供两个分析器：",e.jsx("strong",{children:"ik_smart"}),"（粗粒度， 一段话尽量切成最少的词，如「苹果手机 / 很 / 好用」，适合查询）和",e.jsx("strong",{children:"ik_max_word"}),"（细粒度，穷尽所有可能的词，如「苹果 / 手机 / 苹果手机 …」， 召回更全，适合建索引）。常见做法：建索引用 ",e.jsx("code",{children:"ik_max_word"})," 多切多存， 查询用 ",e.jsx("code",{children:"ik_smart"})," 少切精准，兼顾召回和准确。"]})}),e.jsx("h3",{children:"新词搜不到？扩展词典"}),e.jsxs("p",{children:["ik 内置词典里没有的新词、专有名词、品牌名（比如某个新产品型号），可能被切碎。 解决办法是配置 ik 的",e.jsx("strong",{children:"扩展词典"}),"（自定义 dict 文件），把这些词加进去， ik 就会把它们当成一个完整的词来切。停用词同理，可以用扩展停用词典过滤掉。"]}),e.jsxs("p",{children:["进一步，ik 还支持",e.jsx("strong",{children:"热更新词典"}),"（remote ext dict）：把词典放在一个 HTTP 地址， ik 定时拉取，新词上线不必重启节点。但要注意一个边界：",e.jsx("strong",{children:"改了词典，已经写进倒排索引的老文档不会重切"}),"， 只有新写入或 reindex 之后的文档才按新词典切。所以「加了词却搜不到旧数据」往往不是 bug，是没 reindex。"]}),e.jsxs(i,{variant:"warn",title:"text 与 keyword：分不分词是本质区别",children:[e.jsx("p",{children:"ES 里两种最常用的字符串类型，差别就在「要不要分词」："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"text"}),"——",e.jsx("strong",{children:"会分词"}),"，建倒排索引，用于全文检索（match 查询）。 搜「苹果手机」能命中含「苹果」「手机」的文档。但 text 字段不适合精确匹配、排序、聚合。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"keyword"}),"——",e.jsx("strong",{children:"不分词"}),"，整个值作为一个 term 存储， 用于精确匹配（term 查询）、排序、聚合。比如标签、状态、品牌名这类「整体作为一个值」的字段。"]})]}),e.jsxs("p",{children:["常见做法是给同一字段同时建 text 和 keyword 两种（",e.jsx("code",{children:"fields"})," 子字段）， 既能全文搜又能精确聚合。选错类型是新手第一大坑：拿 text 去做聚合，或拿 keyword 去做全文搜，都会出问题。 下面给出标准的 multi-field 写法。"]}),e.jsx(r,{lang:"json",title:"multi-field：同字段双类型",code:x})]}),e.jsx(i,{variant:"info",title:"为什么 text 不能直接聚合",children:e.jsxs("p",{children:["默认 text 字段没有 doc values（聚合依赖的列存结构），强行对它聚合会报错或要求打开 fielddata—— 而 fielddata 是把字段值全加载进堆内存，",e.jsx("strong",{children:"极易把节点 OOM"}),"。所以正确姿势永远是「聚合走 keyword 子字段」。 这也是上一章「倒排服务搜索、doc values 服务聚合」那句话的现实落地。"]})}),e.jsx("h2",{children:"面试怎么答"}),e.jsxs("p",{children:["被问「ES 中文分词怎么做」，按这条线说：analyzer 由 character filter → tokenizer → token filter 三段组成；内置 standard 对中文是按单字切，会导致相关性崩，所以中文要装 ik；ik 有 ik_smart（粗）和 ik_max_word（细），通常建索引用 max_word、查询用 smart；新词搜不到就配扩展词典。 最后补一刀关键点：",e.jsx("strong",{children:"建索引分词和查询分词必须一致"}),"，否则 term 对不上、明明有数据却搜不到。 再点一句 text（分词，全文搜）vs keyword（不分词，精确/聚合）的区别，就答得很完整了。"]}),e.jsx(i,{variant:"info",title:"面试追问与误区",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"「改了 mapping 的 analyzer，老数据生效吗？」"}),"——不生效，必须 reindex，因为倒排索引是写入时建好的。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"误区：以为 keyword 也会分词"}),"——keyword 整个值是一个 term，大小写敏感，搜要完全相等（可配 normalizer 做小写化）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"「ik_smart 和 ik_max_word 该用哪个？」"}),"——索引用 max_word 提召回，查询用 smart 提准确，是经典搭配。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"误区：把所有字段都设 text"}),"——状态、ID、枚举这类用 keyword，既省空间又能精确过滤和聚合。"]})]})}),e.jsxs(l,{title:"测 ik 分词、给字段指定 analyzer",children:[e.jsxs("p",{children:["先用 ",e.jsx("code",{children:"_analyze"})," 对比 standard 和 ik 切同一句中文的差异，直观感受「按字切」和「按词切」； 再建一个索引，给 text 字段显式指定 ik 分析器。"]}),e.jsx(r,{lang:"json",title:"1. standard 切中文（按字切）",code:a}),e.jsx(r,{lang:"json",title:"2. ik_smart 与 ik_max_word 对比",code:o}),e.jsx(r,{lang:"json",title:"3. mapping 中指定 analyzer",code:c}),e.jsxs("p",{children:["跑完前两步，对比一下 token 列表：standard 切出一堆单字，ik 切出「苹果手机 / 很 / 好用」这样的真词。 第三步给 ",e.jsx("code",{children:"title"})," 设了 ",e.jsx("code",{children:"analyzer: ik_max_word"}),"（建索引细切）和",e.jsx("code",{children:"search_analyzer: ik_smart"}),"（查询粗切），这正是上面说的经典搭配。 再用 multi-field 那段建个带 ",e.jsx("code",{children:"name.raw"})," 的索引，跑一次 terms 聚合，体会「搜走 text、聚合走 keyword」。"]})]}),e.jsx(t,{points:["analyzer 由 character filter → tokenizer → token filter 三段流水线组成，tokenizer 是切词核心。","想定制就对应改三段：去标签改 char filter、换切法改 tokenizer、同义/停用词改 token filter。","建索引分词与查询分词必须一致，否则切出的 term 对不上，有数据也搜不到。","受控的不一致：索引用 ik_max_word 多召回、查询用 ik_smart 保准确，是刻意为之的经典搭配。","内置 standard 把中文按单字切，会让相关性崩坏，中文场景几乎必须换分词器（ik）。","ik 支持扩展词典甚至热更新，但改词典后老文档不会重切，需 reindex 才生效。","text 会分词、用于全文检索；keyword 不分词、用于精确匹配、排序与聚合。","text 默认无 doc values，强行聚合靠 fielddata 极易 OOM，聚合永远走 keyword 子字段。","同一字段常同时建 text + keyword 子字段，既能全文搜又能精确聚合；选错类型是常见坑。"]})]})}export{g as default};
