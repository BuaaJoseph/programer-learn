import{j as e}from"./index-D-xLQIFq.js";import{L as n,S as t}from"./Summary-YJHOQU45.js";import{K as r}from"./KeyIdea-D9fwNcvs.js";import{C as s}from"./Callout-Bp0vMJus.js";import{C as i}from"./CodeBlock-DX_K20PW.js";import{E as l}from"./Example-JUHxJgjQ.js";const d=`// 苹果签名体系里几个名词的关系（概念示意，非真实代码）
//
//  开发者账号 (Apple Developer Program，¥688/年)
//        │
//        ├── Certificate（证书）── 证明「这台机器/团队」可信，分两类：
//        │        • Development  开发证书（装到调试设备）
//        │        • Distribution 分发证书（上架 / TestFlight）
//        │
//        ├── App ID ──────────── 唯一标识一个 App，绑定 Bundle ID
//        │        • com.yourcompany.MyApp（显式，需开启 capability 时用）
//        │
//        └── Provisioning Profile（描述文件）= 把上面三者绑在一起：
//                 证书 + App ID + （开发时）设备列表 + 能力(capabilities)
//                 → 决定「哪个证书、能跑哪个 App、在哪些设备/场景下合法」`,c=`// Bundle ID 是 App 的全局唯一身份，反向域名风格，一经上架不可更改
com.yourcompany.MyApp

// capabilities（能力）= App 想用的系统服务，需在 App ID 与项目里都打开，
// 例如：推送通知 (Push Notifications)、iCloud、Sign in with Apple、
//       后台模式 (Background Modes)、App Groups …
// 打开某个 capability 后，Xcode 会自动把对应权限写进 entitlements 文件`,p=`# 命令行打包（Archive → 导出 .ipa），CI 上常用
# 1) 归档：以 Release 配置构建出 .xcarchive
xcodebuild archive \\
  -scheme MyApp \\
  -configuration Release \\
  -archivePath ./build/MyApp.xcarchive \\
  -destination "generic/platform=iOS"

# 2) 导出 .ipa（需要一个 ExportOptions.plist 指定签名方式与方法)
xcodebuild -exportArchive \\
  -archivePath ./build/MyApp.xcarchive \\
  -exportOptionsPlist ExportOptions.plist \\
  -exportPath ./build/export

# GUI 等价操作：Xcode 菜单 Product ▸ Archive，
# 在 Organizer 窗口里点 Distribute App 走向导`,h=`# 把构建产物上传到 App Store Connect，有三种常见途径：
# A) Xcode Organizer：Archive 后直接「Distribute App ▸ App Store Connect ▸ Upload」
# B) Transporter.app：把导出的 .ipa 拖进去上传（适合与打包解耦）
# C) 命令行（CI 友好）：
xcrun altool --upload-app \\
  -f ./build/export/MyApp.ipa \\
  -t ios \\
  --apiKey  $ASC_KEY_ID \\
  --apiIssuer $ASC_ISSUER_ID
# 上传后构建会先经苹果「处理(Processing)」，几分钟到几十分钟后
# 才出现在 TestFlight 与「构建版本」列表里`,o=`<!-- Info.plist：凡是访问敏感数据/硬件的权限，
     都必须给「用途说明」，否则 App 一访问就崩，且审核必拒 -->
<key>NSCameraUsageDescription</key>
<string>App 需要使用相机来扫描二维码完成支付。</string>

<key>NSPhotoLibraryUsageDescription</key>
<string>App 需要访问相册，以便你选择并上传头像图片。</string>

<key>NSLocationWhenInUseUsageDescription</key>
<string>App 需要在使用期间获取你的位置，用来推荐附近的门店。</string>

<key>NSMicrophoneUsageDescription</key>
<string>App 需要使用麦克风来录制语音留言。</string>

<key>NSContactsUsageDescription</key>
<string>App 需要读取通讯录，帮你快速邀请好友。</string>`,x=`// 两个「版本号」别混淆：
// • Version (CFBundleShortVersionString)：给用户看的市场版本，如 1.2.0
// • Build  (CFBundleVersion)：每次上传必须递增的内部构建号，如 42
//
// 同一个 Version 下可以上传多个 Build（TestFlight 测试时常见），
// 但提交到 App Store 审核的是其中某一个具体 Build。`;function I(){return e.jsxs("article",{children:[e.jsxs(n,{children:["写好的 App 要走到用户手机上，中间隔着苹果一整套",e.jsx("strong",{children:"身份与分发机制"}),"：先证明 「这段代码是可信的你发布的」（签名），再经 TestFlight 让真人试用，最后通过 App Store 审核上架。 这一章把这条「从 Xcode 到 App Store」的流水线讲清楚——证书体系、Bundle ID 与能力、Archive 打包、 上传、Beta 测试、提交审核与发布策略。它也是整门 iOS 课程的收束章。"]}),e.jsx("h2",{children:"一、为什么 iOS 上架这么「重」"}),e.jsxs(r,{children:["iOS 是",e.jsx("strong",{children:"封闭分发"}),"的平台：一个 App 想装到普通用户设备上，几乎只有 App Store 一条路， 且必须经过苹果",e.jsx("strong",{children:"代码签名"}),"与",e.jsx("strong",{children:"人工审核"}),"。签名保证「代码来源可信、未被篡改」， 审核保证「内容与行为合规」。这套机制换来了平台的安全与一致体验，代价是开发者要先理解一堆证书名词。"]}),e.jsx("p",{children:"理解签名体系，本质上是理解几张「凭证」如何互相绑定。把它们的关系先摆出来，后面就不再混乱。"}),e.jsx(i,{lang:"swift",title:"签名体系的几个名词及其关系",code:d}),e.jsx("h2",{children:"二、开发者账号与证书体系"}),e.jsxs("p",{children:["一切的起点是 ",e.jsx("strong",{children:"Apple Developer Program"})," 会员资格（个人 / 公司，约 99 美元、 国区 ¥688 一年）。有了账号，才能创建证书、上架、用 TestFlight。证书体系由四件东西构成："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"概念"}),e.jsx("th",{children:"作用"}),e.jsx("th",{children:"类比"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"Certificate（证书）"}),e.jsx("td",{children:"证明「这个开发者/团队」可信，分 Development 与 Distribution 两类"}),e.jsx("td",{children:"身份证"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"App ID"}),e.jsx("td",{children:"唯一标识一个 App，绑定 Bundle ID 与可用的 capabilities"}),e.jsx("td",{children:"App 的户口"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Devices"}),e.jsx("td",{children:"开发阶段允许安装调试包的设备 UDID 列表"}),e.jsx("td",{children:"准入名单（仅开发用）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Provisioning Profile（描述文件）"}),e.jsx("td",{children:"把证书 + App ID +（开发时）设备 + 能力打包绑定，决定「合法运行的条件」"}),e.jsx("td",{children:"通行证"})]})]})]}),e.jsx("h3",{children:"自动签名 vs 手动签名"}),e.jsxs("p",{children:["Xcode 提供两种管理方式。",e.jsx("strong",{children:"自动签名（Automatically manage signing）"}),"：勾上后选好团队， Xcode 自动帮你创建并维护证书与描述文件，绝大多数项目用它就够了。",e.jsx("strong",{children:"手动签名"}),"： 自己在开发者网站创建证书 / 描述文件、再在项目里逐一指定——团队多人协作、CI 流水线、 或对证书有严格管控时才需要它。"]}),e.jsx(s,{variant:"tip",title:"新手就用自动签名",children:"个人开发与学习阶段强烈建议开自动签名，省去手动管理证书的繁琐。等到团队协作或上 CI、 遇到「证书要在多台机器共享」的问题时，再去学手动签名（以及 fastlane match 这类证书同步方案）。"}),e.jsx("h2",{children:"三、Bundle ID 与 Capabilities"}),e.jsxs("p",{children:[e.jsx("strong",{children:"Bundle ID"})," 是 App 的全局唯一身份，采用反向域名风格（如",e.jsx("code",{children:"com.yourcompany.MyApp"}),"）。它一旦随某个版本上架，",e.jsx("strong",{children:"就不能再改"}),"—— 改了等于另一个 App。",e.jsx("strong",{children:"Capabilities（能力）"}),"则是 App 想使用的系统服务， 比如推送、iCloud、Sign in with Apple、后台模式等；开启某个能力时，Xcode 会自动把对应的",e.jsx("strong",{children:"entitlements（授权）"}),"写进项目，并在 App ID 上同步打开。"]}),e.jsx(i,{lang:"bash",title:"Bundle ID 与 capabilities",code:c}),e.jsx("h2",{children:"四、Archive：打包生成可分发产物"}),e.jsxs("p",{children:["日常调试用的是 Debug 包，不能上架。上架要走 ",e.jsx("strong",{children:"Archive（归档）"}),"：以 Release 配置编译， 产出一个 ",e.jsx("code",{children:".xcarchive"}),"，再从中",e.jsx("strong",{children:"导出"}),"带分发签名的 ",e.jsx("code",{children:".ipa"}),"（iOS App 的安装包格式）。在 Xcode 里就是 ",e.jsx("code",{children:"Product ▸ Archive"}),"， 之后在 Organizer 窗口走分发向导；CI 上则用 ",e.jsx("code",{children:"xcodebuild"})," 命令完成同样的事。"]}),e.jsx(i,{lang:"bash",title:"命令行 Archive 与导出 .ipa",code:p}),e.jsxs(s,{variant:"warn",title:"Build 号每次上传都要递增",children:["注意区分两个版本号：给用户看的 ",e.jsx("strong",{children:"Version"})," 与内部 ",e.jsx("strong",{children:"Build 号"}),"。 每次上传到 App Store Connect，Build 号",e.jsx("strong",{children:"必须比上一次大"}),"，否则会被拒收。 这是新手最常踩的上传报错之一。"]}),e.jsx(i,{lang:"swift",title:"Version 与 Build 的区别",code:x}),e.jsx("h2",{children:"五、App Store Connect 与上传构建"}),e.jsxs("p",{children:[e.jsx("strong",{children:"App Store Connect"})," 是苹果的网页后台，管理 App 的全部「商店侧」信息： 创建 App 记录（填入名称、Bundle ID、SKU）、维护版本、填写商店元数据（截图、描述、关键词、 分级、隐私清单），以及发起 TestFlight 与提交审核。流程上先在这里创建 App 记录， 再把前一步导出的构建",e.jsx("strong",{children:"上传"}),"上去。"]}),e.jsx(i,{lang:"bash",title:"把构建上传到 App Store Connect",code:h}),e.jsxs("p",{children:["上传后构建不会立刻可用，要先经苹果",e.jsx("strong",{children:"处理（Processing）"}),"——做合规扫描、 生成符号等，几分钟到几十分钟不等。处理完成后，构建才会出现在 TestFlight 与版本列表里供选用。"]}),e.jsx("h2",{children:"六、TestFlight：上线前的 Beta 测试"}),e.jsxs(r,{children:["TestFlight 让真人在",e.jsx("strong",{children:"正式上架之前"}),"试用你的构建并反馈问题，是「写完到发布」之间的缓冲带。 它分两条通道：",e.jsx("strong",{children:"内部测试"}),"面向团队成员、即时可用；",e.jsx("strong",{children:"外部测试"}),"面向更广的用户、 但首个构建需经苹果一次轻量 Beta 审核。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"内部测试 (Internal)"}),e.jsx("th",{children:"外部测试 (External)"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"测试人是谁"}),e.jsx("td",{children:"App Store Connect 团队成员（有角色）"}),e.jsx("td",{children:"任意受邀用户（邮件 / 公开链接）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"人数上限"}),e.jsx("td",{children:"较少（团队成员，约 100 名）"}),e.jsx("td",{children:"多（最高约 1 万名）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"是否需 Beta 审核"}),e.jsx("td",{children:"否，上传处理完即可测"}),e.jsx("td",{children:"首个构建需一次轻量审核"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"典型用途"}),e.jsx("td",{children:"研发自测、冒烟"}),e.jsx("td",{children:"更大范围灰度、收集真实反馈"})]})]})]}),e.jsxs("p",{children:["测试者通过 ",e.jsx("strong",{children:"TestFlight App"})," 安装 Beta 构建，可直接在里面",e.jsx("strong",{children:"截屏批注、 提交反馈与崩溃日志"}),"，开发者在 App Store Connect 后台统一查看。每个 Beta 构建有 90 天有效期。用 TestFlight 把明显问题在上架前清掉，能显著降低审核被拒和上线翻车的概率。"]}),e.jsx("h2",{children:"七、提交审核：合规是硬门槛"}),e.jsxs("p",{children:["Beta 验证后，就在 App Store Connect 选定一个构建、填齐元数据，",e.jsx("strong",{children:"提交审核（Submit for Review）"}),"。 审核由苹果团队按 ",e.jsx("strong",{children:"App Review Guidelines（审核指南）"}),"逐条把关，覆盖安全、性能、商业模式、 设计、法律合规等维度。下面是新手最常踩的拒绝原因。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"常见拒绝原因"}),e.jsx("th",{children:"说明与对策"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"缺少权限用途说明"}),e.jsx("td",{children:"用了相机/相册/定位等却没在 Info.plist 写 usage description —— 补全且文案要具体"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"隐私信息不实 / 缺隐私清单"}),e.jsx("td",{children:"App 隐私（Privacy Nutrition Label）与实际收集不符，或缺隐私政策链接"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"崩溃与明显 Bug"}),e.jsx("td",{children:"审核机一启动就崩、核心功能不可用 —— 提交前务必真机过一遍主流程"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"功能太单薄 / 占位"}),e.jsx("td",{children:"更像网页套壳或半成品，缺乏原生价值"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"支付绕过内购"}),e.jsx("td",{children:"数字商品须走 App 内购买（IAP），不能引导外部支付"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"登录问题"}),e.jsx("td",{children:"提供第三方登录却未提供 Sign in with Apple；未给审核员可用测试账号"})]})]})]}),e.jsxs("p",{children:["其中「",e.jsx("strong",{children:"权限用途说明"}),"」是出现频率最高、也最容易避免的一类。任何访问敏感数据 / 硬件的能力， 都必须在 ",e.jsx("code",{children:"Info.plist"})," 里给出一句",e.jsx("strong",{children:"具体、说人话"}),"的用途说明，否则 App 一访问就直接崩溃， 审核也必拒。"]}),e.jsx(i,{lang:"bash",title:"Info.plist 权限用途说明示例",code:o}),e.jsxs(s,{variant:"warn",title:"用途说明要具体，别写废话",children:["像「App 需要相机权限」这种空话容易被拒。要写清",e.jsx("strong",{children:"为什么用、用来做什么"}),"， 例如「使用相机扫描二维码完成支付」。系统弹授权框时会原样展示这句话， 它既影响过审，也直接影响用户是否愿意点「允许」。"]}),e.jsx("h2",{children:"八、发布与分阶段发布"}),e.jsxs("p",{children:["审核通过后，App 进入「待发布」。你可以选择",e.jsx("strong",{children:"立即发布"}),"、",e.jsx("strong",{children:"定时发布"}),"， 或开启",e.jsx("strong",{children:"分阶段发布（Phased Release）"}),"——让新版本在约 7 天内按比例（1% → 2% → 5% …） 逐步推送给自动更新用户。分阶段发布能在小范围先暴露问题，万一发现严重 Bug 可随时暂停， 避免一次性铺给全量用户。"]}),e.jsx(l,{title:"一次典型上架的完整路径",children:e.jsxs("p",{children:["① 在 App ID 配好 Bundle ID 与 capabilities → ② Xcode 开自动签名、把 Build 号 +1 → ③ ",e.jsx("code",{children:"Product ▸ Archive"})," 打包 → ④ Organizer 上传到 App Store Connect → ⑤ 等处理完成，先发",e.jsx("strong",{children:"内部 TestFlight"})," 自测，再发外部 Beta → ⑥ 填齐元数据与隐私、补全 Info.plist 权限说明 → ⑦ 提交审核 → ⑧ 过审后开",e.jsx("strong",{children:"分阶段发布"}),"，观察崩溃率与反馈。"]})}),e.jsxs(s,{variant:"tip",title:"与 Android 上架的一句话差异",children:["和 Google Play 相比，iOS 的分发更",e.jsx("strong",{children:"集中且强制"}),"：几乎只有 App Store 一条正规通道、 强制代码签名、且每个版本都要过人工审核；而 Android 允许多渠道分发与侧载，审核相对更宽松更快。"]}),e.jsx("h2",{children:"九、收束：你已经走完了一整条 iOS 之路"}),e.jsxs("p",{children:["从语言与界面，到状态、数据、网络与架构，再到本卷的性能、测试与发布——你已经掌握了把一个想法 变成「真机上能跑、用户能下载、改起来有底气」的完整 iOS App 所需的全部主干能力。 接下来要做的，是用一个真实的小项目把这条链路",e.jsx("strong",{children:"从头到尾走一遍"}),"： 立项、写功能、加测试、用 Instruments 调优、过 TestFlight、提交审核上架。 工程能力是在「真的发出去一个 App」的过程里长出来的。"]}),e.jsx(t,{points:["iOS 是封闭分发平台：装到用户设备几乎只能走 App Store，且必须代码签名 + 人工审核——签名保来源可信、审核保内容合规。","签名体系四件套：Certificate（身份）、App ID（App 户口，绑 Bundle ID 与 capabilities）、Devices（开发设备）、Provisioning Profile（把它们绑在一起的通行证）；新手用自动签名即可。","上架流程主干：配好 Bundle ID/能力 → Archive 打 Release 包导出 .ipa（Build 号每次必须递增）→ 经 Xcode/Transporter 上传到 App Store Connect。","TestFlight 在上架前做 Beta：内部测试即时可用、外部测试覆盖更广但首个构建需轻量审核，测试者可直接截屏反馈与回传崩溃日志。","审核按 App Review Guidelines 把关，最常见拒绝原因是缺 Info.plist 权限用途说明、隐私不实、崩溃；用途说明要具体说人话，否则一访问就崩且必拒。","过审后可立即/定时/分阶段发布，Phased Release 按比例灰度便于及时止损；相比 Android 多渠道+宽松审核，iOS 分发更集中、强制签名、逐版本审核。"]})]})}export{I as default};
