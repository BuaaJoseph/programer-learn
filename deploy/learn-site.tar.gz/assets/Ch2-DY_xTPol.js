import{j as e}from"./index-BdVncPlI.js";import{L as r,S as c}from"./Summary-Baiwq3-G.js";import{K as s}from"./KeyIdea-Cnr-5ipR.js";import{C as i}from"./Callout-BRUKkrb4.js";import{C as n}from"./CodeBlock-DCdshbU5.js";import{E as t}from"./Example-phQ905Fb.js";import{P as o}from"./Practice-CD-79usu.js";import{P as d}from"./PyRunner-ZE-OH9QD.js";const l=`# 列表推导式：1~5 的平方
squares = [x ** 2 for x in range(1, 6)]
print("平方：", squares)

# 带条件的推导式：只要偶数
evens = [x for x in range(1, 11) if x % 2 == 0]
print("偶数：", evens)

# 字典推导式：数字 -> 立方
cubes = {x: x ** 3 for x in range(1, 5)}
print("立方字典：", cubes)

# enumerate：同时拿到下标和值
fruits = ["苹果", "香蕉", "橙子"]
for i, name in enumerate(fruits, start=1):
    print(f"第{i}个：{name}")

# zip：把两个列表配对
names = ["小明", "小红"]
ages = [18, 17]
for name, age in zip(names, ages):
    print(f"{name} 今年 {age} 岁")`,x=`# 普通写法：把 1~5 的平方收集到一个新列表
squares = []
for i in range(1, 6):
    squares.append(i * i)
print(squares)`,a="[1, 4, 9, 16, 25]",h=`# 列表推导式：一行搞定
squares = [i * i for i in range(1, 6)]
print(squares)`,j="[1, 4, 9, 16, 25]",p=`# 带条件：只要偶数的平方
even_sq = [i * i for i in range(1, 11) if i % 2 == 0]
print(even_sq)`,m="[4, 16, 36, 64, 100]",f=`names = ["  小明 ", "小红  ", " 小刚"]
clean = [n.strip() for n in names]   # 把每个名字去掉空格
print(clean)`,u="['小明', '小红', '小刚']",g=`# 字典推导式：名字 -> 名字长度
names = ["Tom", "Jerry", "Bob"]
length_map = {name: len(name) for name in names}
print(length_map)`,C="{'Tom': 3, 'Jerry': 5, 'Bob': 3}",y=`# 集合推导式：自动去重
nums = [1, 2, 2, 3, 3, 3]
squares = {n * n for n in nums}
print(squares)`,z="{1, 4, 9}",q=`fruits = ["苹果", "香蕉", "橙子"]
# 不用 enumerate：要自己维护下标
i = 0
for f in fruits:
    print(i, f)
    i += 1
print("---")
# 用 enumerate：一步拿到下标和值
for index, f in enumerate(fruits):
    print(index, f)`,v=`0 苹果
1 香蕉
2 橙子
---
0 苹果
1 香蕉
2 橙子`,O=`for num, name in enumerate(["甲", "乙", "丙"], start=1):
    print(f"第{num}名：{name}")`,b=`第1名：甲
第2名：乙
第3名：丙`,P=`names = ["小明", "小红", "小刚"]
scores = [90, 85, 95]
for name, score in zip(names, scores):   # 两个列表并排走
    print(f"{name} 考了 {score} 分")`,k=`小明 考了 90 分
小红 考了 85 分
小刚 考了 95 分`,S=`keys = ["name", "age", "city"]
values = ["小明", 18, "杭州"]
person = dict(zip(keys, values))   # 两个列表合成字典
print(person)`,_="{'name': '小明', 'age': 18, 'city': '杭州'}";function w(){return e.jsxs("article",{children:[e.jsxs(r,{children:["上一章我们用 for 循环处理数据，写起来有点啰嗦。这一章学几个让代码更短、更优雅的 Python 招牌技巧：",e.jsx("strong",{children:"推导式"}),"（一行生成列表/字典/集合）、",e.jsx("strong",{children:"enumerate"}),"（遍历时顺手拿下标）、",e.jsx("strong",{children:"zip"}),"（并排遍历多个列表）。它们都不是必须的，但用好了能让代码清爽很多。"]}),e.jsx("h2",{children:"一、列表推导式"}),e.jsx("p",{children:"先看一个常见需求：把 1 到 5 的平方收集成列表。普通 for 写法是这样："}),e.jsx(n,{lang:"python",title:"普通写法",code:x}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:a})}),e.jsxs(s,{children:["列表推导式把「创建空列表 + for 循环 + append」三步压缩成一行：",e.jsx("code",{children:"[表达式 for 变量 in 序列]"}),"。读法：「对序列里的每个变量，算出表达式，收集成列表」。"]}),e.jsx(n,{lang:"python",title:"列表推导式",code:h}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:j})}),e.jsx("h3",{children:"带条件的推导式"}),e.jsxs("p",{children:["在后面加一个 ",e.jsx("code",{children:"if"}),"，就能只保留满足条件的元素："]}),e.jsx(n,{lang:"python",title:"带 if 条件",code:p}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:m})}),e.jsx("p",{children:"表达式里也可以调用方法，比如批量清理字符串："}),e.jsx(n,{lang:"python",title:"对每个元素做处理",code:f}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:u})}),e.jsx("h2",{children:"二、字典推导式"}),e.jsxs("p",{children:["把方括号换成花括号、写成 ",e.jsx("code",{children:"{键: 值 for ...}"}),"，就能一行生成字典："]}),e.jsx(n,{lang:"python",title:"字典推导式",code:g}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:C})}),e.jsx("h2",{children:"三、集合推导式"}),e.jsx("p",{children:"花括号但只写一个表达式（没有冒号），生成的是集合，自带去重："}),e.jsx(n,{lang:"python",title:"集合推导式",code:y}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:z})}),e.jsxs(i,{variant:"tip",children:["花括号里有冒号 ",e.jsx("code",{children:"键: 值"})," 是字典推导式，没冒号是集合推导式——靠有没有冒号区分。"]}),e.jsx(i,{variant:"warn",title:"别为了炫技把推导式写得太复杂",children:"推导式适合简单的「映射 + 过滤」。如果逻辑很复杂（多重嵌套、好几个条件）， 老老实实写普通 for 循环反而更清楚易读。代码是给人看的。"}),e.jsx("h3",{children:"推导式语法小结"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"类型"}),e.jsx("th",{children:"写法"}),e.jsx("th",{children:"得到"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"列表推导式"}),e.jsx("td",{children:e.jsx("code",{children:"[x for x in 序列]"})}),e.jsx("td",{children:"列表"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"带条件"}),e.jsx("td",{children:e.jsx("code",{children:"[x for x in 序列 if 条件]"})}),e.jsx("td",{children:"过滤后的列表"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"字典推导式"}),e.jsx("td",{children:e.jsx("code",{children:"{k: v for ...}"})}),e.jsx("td",{children:"字典"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"集合推导式"}),e.jsx("td",{children:e.jsx("code",{children:"{x for ...}"})}),e.jsx("td",{children:"集合（去重）"})]})]})]}),e.jsx("h2",{children:"四、enumerate：遍历时顺带拿下标"}),e.jsxs("p",{children:["遍历列表时如果既想要元素、又想要它的下标（第几个），不用自己维护一个计数器，用 ",e.jsx("code",{children:"enumerate"})," 即可："]}),e.jsx(n,{lang:"python",title:"enumerate 对比普通写法",code:q}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:v})}),e.jsxs("p",{children:["下标默认从 0 开始，可以用 ",e.jsx("code",{children:"start"})," 改起始值，比如做排名时从 1 开始："]}),e.jsx(n,{lang:"python",title:"enumerate 指定起始值",code:O}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:b})}),e.jsx("h2",{children:"五、zip：把多个列表并排走"}),e.jsxs(s,{children:[e.jsx("code",{children:"zip"})," 像拉链一样，把多个列表「对齐配对」：第 1 个和第 1 个一组、第 2 个和第 2 个一组…… 非常适合同时遍历两个相关的列表，比如名字和成绩。"]}),e.jsx(n,{lang:"python",title:"zip 并行遍历",code:P}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:k})}),e.jsxs("p",{children:["配合 ",e.jsx("code",{children:"dict()"}),"，还能把两个列表（键列表 + 值列表）直接合成一个字典："]}),e.jsx(n,{lang:"python",title:"zip 合成字典",code:S}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:_})}),e.jsxs(i,{variant:"note",title:"zip 以最短的为准",children:["如果几个列表长度不一样，",e.jsx("code",{children:"zip"})," 会在最短的那个用完时停下，多出来的元素被忽略。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」，看看结果。"]}),e.jsx(d,{initialCode:l}),e.jsx(o,{title:"动手练一练",children:e.jsxs("ol",{children:[e.jsx("li",{children:"用列表推导式生成 1 到 20 中所有能被 3 整除的数。"}),e.jsx("li",{children:"给定一个单词列表，用字典推导式生成「单词 -> 大写形式」的映射。"}),e.jsxs("li",{children:["有 ",e.jsx("code",{children:"names"})," 和 ",e.jsx("code",{children:"ages"})," 两个等长列表，用 zip + enumerate 打印「1. 小明，18岁」这样带序号的信息。"]})]})}),e.jsx(c,{points:["列表推导式 [表达式 for x in 序列] 一行生成列表，可加 if 过滤、可对元素做处理。","字典推导式 {键: 值 for ...}、集合推导式 {表达式 for ...}（无冒号、自动去重）。","推导式适合简单映射+过滤，逻辑复杂时改用普通 for 更易读。","enumerate 遍历时同时拿下标和值，免去手动计数，可用 start 指定起始下标。","zip 把多个列表对齐配对并行遍历，配合 dict() 可把键列表+值列表合成字典。","zip 以最短列表为准，多余元素被忽略。"]})]})}export{w as default};
