import{r as d,j as e}from"./index-bcw1GFOG.js";import{L as x,S as m}from"./Summary-CzbI5rAL.js";import{K as j}from"./KeyIdea-BfDRPFR2.js";import{E as u}from"./Example-C1jxmPta.js";import{P as f}from"./Practice-DbjK1PhF.js";import{C as l}from"./Callout-Kd5ZZGSH.js";import{C as r}from"./CodeBlock-DTDRATdO.js";import{F as g}from"./Figure-DNPgTi31.js";const i={match:{label:"match",analyze:!0,exact:!1,desc:"match 会对查询词分词，再去倒排索引匹配——全文检索用它(如搜「苹果手机」会拆成「苹果」「手机」)。"},term:{label:"term",analyze:!1,exact:!0,desc:"term 不分词、精确匹配原始词项——用于 keyword、状态、ID 等(注意：对 text 字段用 term 常常搜不到)。"},bool:{label:"bool",analyze:!0,exact:!1,desc:"bool 组合多个条件：must(且/参与打分)、should(或)、filter(过滤·不打分·可缓存)、must_not(非)。"}};function p(){const[s,o]=d.useState("match"),t=i[s],n=e.jsx(e.Fragment,{children:Object.entries(i).map(([c,h])=>e.jsx("button",{className:`fig-btn ${s===c?"active":""}`,onClick:()=>o(c),children:h.label},c))}),a={match:`GET /goods/_search
{ "query": { "match": { "title": "苹果手机" } } }`,term:`GET /goods/_search
{ "query": { "term": { "status": "on_sale" } } }`,bool:`GET /goods/_search
{ "query": { "bool": {
  "must":   [ { "match": { "title": "手机" } } ],
  "filter": [ { "range": { "price": { "lte": 5000 } } } ]
} } }`};return e.jsx(g,{caption:"ES 查询用 Query DSL(JSON)。最常考的是 match(分词、全文) vs term(不分词、精确)的区别，以及 bool 如何用 must/should/filter 组合条件。选下面看差异。",controls:n,children:e.jsxs("svg",{viewBox:"0 0 460 200",width:"460",role:"img","aria-label":"ES Query DSL",children:[e.jsxs("g",{children:[e.jsx("rect",{x:"20",y:"20",width:"135",height:"30",rx:"6",fill:t.analyze?"var(--green-soft)":"var(--bg-sunken)",stroke:t.analyze?"var(--green)":"var(--border-strong)"}),e.jsx("text",{x:"87",y:"39",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"11",fill:t.analyze?"var(--green)":"var(--ink-faint)",children:t.analyze?"✓ 会分词":"✗ 不分词"}),e.jsx("rect",{x:"165",y:"20",width:"135",height:"30",rx:"6",fill:t.exact?"var(--accent-soft)":"var(--bg-sunken)",stroke:t.exact?"var(--accent)":"var(--border-strong)"}),e.jsx("text",{x:"232",y:"39",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"11",fill:t.exact?"var(--accent-strong)":"var(--ink-faint)",children:t.exact?"精确匹配":"相关性匹配"})]}),e.jsx("rect",{x:"20",y:"60",width:"420",height:"76",rx:"8",fill:"var(--bg-code)",stroke:"#2c3252"}),e.jsx("foreignObject",{x:"30",y:"66",width:"404",height:"66",children:e.jsx("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"11px var(--mono)",color:"#d8dcec",whiteSpace:"pre-wrap",lineHeight:1.4},children:a[s]})}),e.jsx("rect",{x:"20",y:"146",width:"420",height:"48",rx:"8",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsx("foreignObject",{x:"28",y:"150",width:"404",height:"42",children:e.jsxs("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"12px var(--sans)",color:"var(--ink)",lineHeight:1.35},children:[e.jsxs("strong",{style:{color:"var(--accent-strong)"},children:[t.label,"："]}),t.desc]})})]})})}const y=`# match：会对查询词分词，走全文检索
GET /books/_search
{
  "query": {
    "match": { "title": "Elasticsearch 实战" }
  }
}

# term：不分词、精确匹配。注意：对 text 字段几乎查不到！
GET /books/_search
{
  "query": {
    "term": { "title": "Elasticsearch 实战" }
  }
}`,_=`GET /books/_search
{
  "query": {
    "bool": {
      "must":   [ { "match": { "title": "Elasticsearch" } } ],
      "filter": [
        { "term":  { "status": "on_sale" } },
        { "range": { "price": { "gte": 30, "lte": 100 } } }
      ],
      "must_not": [ { "term": { "tag": "deprecated" } } ],
      "should":  [ { "match": { "intro": "入门" } } ]
    }
  },
  "sort": [ { "price": "asc" } ],
  "from": 0,
  "size": 10
}`,b=`# match 默认词之间是 OR，命中任一词即可
GET /books/_search
{ "query": { "match": { "title": "高性能 Elasticsearch" } } }

# 要求所有词都命中（更精准、召回更少）：operator=and
GET /books/_search
{
  "query": {
    "match": {
      "title": { "query": "高性能 Elasticsearch", "operator": "and" }
    }
  }
}

# 容忍错别字：fuzziness 自动按编辑距离纠错（elasticsarch -> elasticsearch）
GET /books/_search
{
  "query": {
    "match": {
      "title": { "query": "elasticsarch", "fuzziness": "AUTO" }
    }
  }
}`,v=`# 一个词同时搜多个字段，并给标题更高权重（^3）
GET /books/_search
{
  "query": {
    "multi_match": {
      "query": "性能调优",
      "fields": ["title^3", "intro", "tags"],
      "type": "best_fields"
    }
  }
}`;function G(){return e.jsxs(e.Fragment,{children:[e.jsx(x,{children:e.jsxs("p",{children:["会写 Query DSL，是面试 Elasticsearch 绕不过去的一关。它本质上就是一坨 JSON：你把「想查什么、怎么过滤、怎么排序、要第几页」描述清楚， 扔给 ",e.jsx("code",{children:"_search"})," 接口。本章把最常用的几个查询子句一次讲透，再用一个真实例子把它们拼起来。"]})}),e.jsx("h2",{children:"两种上下文：query 与 filter"}),e.jsxs("p",{children:["理解 Query DSL，第一件事是分清",e.jsx("strong",{children:"查询上下文"}),"（query context）和",e.jsx("strong",{children:"过滤上下文"}),"（filter context）。 放在 query 里的子句，会计算一个",e.jsx("em",{children:"relevance score"}),"（相关性得分，字段名 ",e.jsx("code",{children:"_score"}),"），用来回答「这条结果跟我搜的有多像」； 而放在 filter 里的子句，只回答「符不符合条件」这个是非题，",e.jsx("strong",{children:"不打分"}),"。"]}),e.jsxs("p",{children:["差别带来两个后果：一是 filter 不参与算分，开销更小；二是 filter 的结果可以被 Elasticsearch ",e.jsx("strong",{children:"缓存"}),"（filter cache， 本质是缓存「哪些文档命中」的 bitset），同样的过滤条件再来一次几乎是白嫖。所以经验法则是：凡是「精确的、不需要打分的」条件 （状态、分类、价格区间、时间范围），统统塞进 filter。"]}),e.jsx("h3",{children:"match：分词的全文检索"}),e.jsxs("p",{children:[e.jsx("em",{children:"match"})," 是最常用的全文查询。它会先把你的查询词",e.jsx("strong",{children:"分词"}),"，再拿这些词去倒排索引里找。 搜「Elasticsearch 实战」，会被切成 elasticsearch、实、战 之类的词项，命中包含这些词的文档，并按相关性打分。"]}),e.jsxs("p",{children:["match 还有几个常用旋钮值得记：默认多个词之间是 ",e.jsx("strong",{children:"OR"}),"（命中任一即可，召回大）， 想要「所有词都命中」就设 ",e.jsx("code",{children:"operator: and"}),"；想容忍用户打错字，加 ",e.jsx("code",{children:"fuzziness: AUTO"}),"， 它会按",e.jsx("strong",{children:"编辑距离"}),"（Levenshtein）自动纠错，把「elasticsarch」也匹配上。这些是把搜索体验做好的细节。"]}),e.jsx(r,{lang:"json",title:"match 的 operator 与 fuzziness",code:b}),e.jsx("h3",{children:"term：精确不分词（坑最多）"}),e.jsxs("p",{children:[e.jsx("em",{children:"term"})," 是精确匹配，",e.jsx("strong",{children:"不分词"}),"，要求字段里存的词项和你给的值",e.jsx("strong",{children:"一模一样"}),"。 它的经典坑：对 ",e.jsx("code",{children:"text"})," 类型字段用 term 往往查不到。因为 text 字段在写入时已经被分词、转小写存进了倒排索引， 而 term 拿你原样的「Elasticsearch 实战」去比，自然对不上。要精确匹配，应该用 ",e.jsx("code",{children:"keyword"})," 类型字段（比如 ",e.jsx("code",{children:"title.keyword"}),"）。"]}),e.jsxs("p",{children:["和 term 同族还有两个高频子句：",e.jsx("code",{children:"terms"}),"（一次匹配多个值，等价 SQL 的 ",e.jsx("code",{children:"IN"}),"）和 ",e.jsx("code",{children:"exists"}),"（判断某字段是否存在/非空）。它们都属于精确判断、天然适合放进 filter。"]}),e.jsx("h3",{children:"match_phrase、multi_match 与 range"}),e.jsxs("p",{children:[e.jsx("em",{children:"match_phrase"})," 是短语查询：不仅词都要在，",e.jsx("strong",{children:"顺序和相邻关系"}),"也要对（靠倒排索引里的 positions 实现）， 搜「数据 结构」不会命中「结构化数据」；还能用 ",e.jsx("code",{children:"slop"})," 允许中间隔几个词。",e.jsx("em",{children:"multi_match"})," 让一个词同时打多个字段，还能用 ",e.jsx("code",{children:"字段^权重"})," 给重要字段加权（标题命中通常比简介命中更值钱）。",e.jsx("em",{children:"range"})," 则是范围查询，配合 ",e.jsx("code",{children:"gte"}),"/",e.jsx("code",{children:"lte"}),"/",e.jsx("code",{children:"gt"}),"/",e.jsx("code",{children:"lt"})," 做数字、日期的区间过滤，是 filter 里的常客。"]}),e.jsx(r,{lang:"json",title:"multi_match 跨字段 + 字段加权",code:v}),e.jsxs(u,{title:"按标题搜 + 价格过滤 + 排序",children:[e.jsx("p",{children:"假设有个图书库，需求是：标题相关于「Elasticsearch」、价格在 30 到 100 之间、在售、按价格升序排，取第一页。 这正是 query（标题打分）和 filter（价格、状态）分工的典型场景。先看 match 和 term 的区别："}),e.jsx(r,{lang:"json",title:"match vs term",code:y}),e.jsxs("p",{children:["上面第二个 term 查询，因为 ",e.jsx("code",{children:"title"})," 是 text 字段，几乎查不到东西——这是面试和实战里最常见的翻车点。"]})]}),e.jsx(p,{}),e.jsx(j,{title:"bool 是把积木拼起来的胶水",children:e.jsxs("p",{children:["复杂查询几乎都靠 ",e.jsx("em",{children:"bool"})," 组合而成，它有四个槽：",e.jsx("strong",{children:"must"}),"（必须满足，参与打分）、",e.jsx("strong",{children:"should"}),"（满足则加分，类似 OR，可用 ",e.jsx("code",{children:"minimum_should_match"})," 规定至少命中几个）、",e.jsx("strong",{children:"filter"}),"（必须满足，不打分可缓存）、",e.jsx("strong",{children:"must_not"}),"（必须不满足，不打分）。 一句话记忆：要打分用 must/should，要过滤用 filter/must_not。"]})}),e.jsx(l,{variant:"warn",title:"term 打到 text 字段的坑",children:e.jsxs("p",{children:["最高频的事故：拿 term 去查一个 text 字段却始终空结果。排查口诀是——",e.jsx("strong",{children:"需要精确匹配，就建 keyword 字段；需要全文搜，就用 match"}),"。 如果一个字段两种都要，Elasticsearch 默认会给 text 字段加一个 ",e.jsx("code",{children:".keyword"})," 子字段，term 时记得查 ",e.jsx("code",{children:"字段名.keyword"}),"。 同理还有大小写坑：keyword 默认大小写敏感，搜 ",e.jsx("code",{children:"Acme"})," 匹配不到存的 ",e.jsx("code",{children:"acme"}),"，要么存查统一大小写，要么给 keyword 配 normalizer 做小写化。"]})}),e.jsx("h2",{children:"分页与聚合"}),e.jsxs("p",{children:["分页用 ",e.jsx("code",{children:"from"}),"（跳过多少条）和 ",e.jsx("code",{children:"size"}),"（取多少条）。注意 ",e.jsx("code",{children:"from + size"})," 不能太大， 翻到很深的页会有严重的性能和内存问题（默认 ",e.jsx("code",{children:"from+size ≤ 10000"}),"），这个「深分页」坑下一章专门讲，结论是改用 ",e.jsx("code",{children:"search_after"}),"。 至于",e.jsx("em",{children:"aggregations"}),"（聚合），是 Elasticsearch 做统计分析的能力，比如按分类算每类有多少本书、平均价多少， 相当于 SQL 的 ",e.jsx("code",{children:"GROUP BY"})," 加聚合函数，这里先知道有这么个东西即可。"]}),e.jsx(l,{variant:"info",title:"顺手记：返回里的几个关键字段",children:e.jsxs("p",{children:["看懂 ",e.jsx("code",{children:"_search"})," 的返回能帮你快速排障：",e.jsx("code",{children:"hits.total.value"})," 是命中总数（默认最多精确到 10000， 超过显示约数，要精确得加 ",e.jsx("code",{children:"track_total_hits: true"}),"）；",e.jsx("code",{children:"max_score"})," 是最高分；",e.jsx("code",{children:"took"})," 是耗时毫秒；",e.jsx("code",{children:"timed_out"})," 表示是否有分片超时。养成先看这几个字段的习惯。"]})}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["被问到「query 和 filter 有什么区别」，标准答法是三句：",e.jsx("strong",{children:"query 算相关性得分、filter 不算；filter 结果可缓存所以更快； 所以精确过滤条件应放 filter，需要相关性排序的才放 query"}),"。 再追问 match 和 term，就强调「match 分词走全文、term 不分词要精确，term 别打到 text 字段」。 能再带出 multi_match 字段加权、match 的 operator/fuzziness，就显得真在业务里调过了。"]}),e.jsx(l,{variant:"info",title:"面试追问与误区",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"「match 和 match_phrase 区别？」"}),"——match 只要求含词（默认 OR），match_phrase 还要求顺序相邻（靠 positions）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"误区：term 查 text 字段"}),"——text 已分词转小写，term 原样比对几乎查不到，精确匹配走 keyword。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"「怎么做多字段搜索并突出标题？」"}),"——multi_match + 字段^权重（如 title^3）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"误区：以为 hits.total 总是精确"}),"——默认上限 10000，要精确加 track_total_hits。"]})]})}),e.jsxs(f,{title:"拼一个完整的 bool 查询",children:[e.jsx("p",{children:"把本章学的子句组合起来：标题用 match 参与打分，价格 range、状态 term 放进 filter，排除废弃标签用 must_not， 再加一个 should 给「入门」类目加点分，最后按价格升序、取第一页。"}),e.jsx(r,{lang:"json",title:"bool + filter + sort",code:_}),e.jsxs("p",{children:["试着把 ",e.jsx("code",{children:"title"})," 的 match 改成 term，观察结果如何变空；再把 range 从 filter 挪到 must，体会 ",e.jsx("code",{children:"_score"})," 是否还有意义； 最后给 match 加上 ",e.jsx("code",{children:"operator: and"})," 或 ",e.jsx("code",{children:"fuzziness: AUTO"}),"，看命中数怎么收缩或放宽。"]})]}),e.jsx(m,{points:["query 上下文算相关性得分（_score），filter 上下文只判断是否符合、不打分且结果可缓存（bitset），精确过滤条件应放 filter。","match 会分词、走全文检索，默认词间 OR；可用 operator=and 收紧、fuzziness 容错纠错。","term 不分词要求精确，最大的坑是对 text 字段几乎查不到（需用 keyword）；同族还有 terms（IN）、exists。","match_phrase 要求词序相邻（靠 positions，可用 slop）；multi_match 跨字段并能用 字段^权重 加权。","range 配合 gte/lte 做数字、日期范围，是 filter 的常客；keyword 默认大小写敏感，注意 normalizer。","bool 用 must/should/filter/must_not 四个槽组合：要打分用 must/should，要过滤用 filter/must_not。","分页用 from/size 但深分页有性能问题（改 search_after）；聚合相当于 SQL 的 GROUP BY。","看返回先看 took/hits.total/max_score/timed_out；total 默认上限 10000，要精确加 track_total_hits。"]})]})}export{G as default};
