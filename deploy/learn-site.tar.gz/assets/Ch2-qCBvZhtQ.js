import{j as e}from"./index-B0-Um9Xw.js";import{L as s,C as r,a as i,P as n,S as c}from"./Summary-CRXglwZ1.js";import{K as l}from"./KeyIdea-zCCzkW7I.js";import{E as d}from"./Example-Djk5fvs9.js";const o=`@Service
class OrderService {

    public void createOrder() {
        // 同类内部直接调 this.saveLog()，走的是原始对象、不是代理对象，
        // @Transactional 完全不生效！
        saveLog();
    }

    @Transactional
    public void saveLog() {
        // 这里的事务注解被「绕过」了
        logMapper.insert(new Log());
        throw new RuntimeException("出错也不会回滚");
    }
}`,x=`@Service
class OrderService {
    @Autowired
    private LogService logService;

    @Transactional   // 默认 REQUIRED：加入当前事务
    public void createOrder() {
        orderMapper.insert(order);
        try {
            logService.writeLog();   // 内部开了独立事务
        } catch (Exception e) {
            // 即使写日志失败，订单事务也不被它牵连
        }
        // 这里抛异常，order 会回滚，但上面已提交的日志不受影响
    }
}

@Service
class LogService {
    // REQUIRES_NEW：挂起外层事务，开一个全新的独立事务，独立提交/回滚
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void writeLog() {
        logMapper.insert(new Log());
    }
}`;function E(){return e.jsxs(e.Fragment,{children:[e.jsx(s,{children:e.jsxs("p",{children:["声明式事务用起来只是一个 ",e.jsx("code",{children:"@Transactional"})," 注解，但面试官真正想考的是它背后的两件事：",e.jsx("em",{children:"propagation"}),"（传播行为）决定「方法之间事务怎么组合」，而",e.jsx("strong",{children:"事务失效场景"}),"则是踩坑重灾区—— 很多人写了注解却发现根本没回滚。这一章把传播行为讲透，再把失效的坑一次性列清。"]})}),e.jsx("h2",{children:"声明式事务的本质：AOP 代理"}),e.jsxs("p",{children:[e.jsx("code",{children:"@Transactional"})," 之所以能「自动开启、自动提交、出错回滚」，靠的是 Spring AOP： 容器为你的 Bean 生成一个",e.jsx("strong",{children:"代理对象"}),"，调用被注解的方法时，代理会先开启事务，方法正常返回则提交、 抛异常则回滚。理解这一点是后面所有「失效场景」的钥匙——",e.jsx("strong",{children:"只有走代理的调用，事务才生效"}),"。"]}),e.jsx("h3",{children:"七种传播行为"}),e.jsxs("p",{children:[e.jsx("em",{children:"propagation"})," 描述「当前方法的事务该如何与调用它的外层事务协作」，共七种，最常考的是前三种："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"REQUIRED（默认）"}),"：外层有事务就加入，没有就新建。两者同生共死，任一回滚则全部回滚。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"REQUIRES_NEW"}),"：无论外层有没有事务，都",e.jsx("em",{children:"挂起"}),"外层、开一个全新的独立事务，独立提交、独立回滚，互不牵连。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"NESTED"}),"：在外层事务里开一个",e.jsx("em",{children:"嵌套事务"}),"（基于 savepoint）。内层回滚只回到 savepoint，不影响外层；但外层回滚会带着内层一起回。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"SUPPORTS"}),"：有事务就用，没有就以非事务方式运行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"NOT_SUPPORTED"}),"：以非事务方式运行，有事务则挂起。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"MANDATORY"}),"：必须在已有事务中运行，否则抛异常。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"NEVER"}),"：必须在非事务中运行，存在事务则抛异常。"]})]}),e.jsxs("p",{children:["一句话记 REQUIRES_NEW 与 NESTED 的区别：前者是",e.jsx("strong",{children:"两个完全独立"}),"的事务（外层回滚不影响已提交的内层）； 后者是",e.jsx("strong",{children:"父子关系"}),"（外层回滚会连内层一起回，内层回滚只回到 savepoint）。"]}),e.jsx("h3",{children:"隔离级别"}),e.jsxs("p",{children:[e.jsx("em",{children:"isolation"})," 控制并发事务间的可见性，对应数据库的四个标准级别：",e.jsx("code",{children:"READ_UNCOMMITTED"}),"（脏读）、",e.jsx("code",{children:"READ_COMMITTED"}),"（解决脏读）、",e.jsx("code",{children:"REPEATABLE_READ"}),"（解决不可重复读，MySQL 默认）、",e.jsx("code",{children:"SERIALIZABLE"}),"（最严、解决幻读但性能最差）。 Spring 默认用 ",e.jsx("code",{children:"DEFAULT"}),"，即跟随底层数据库的隔离级别。"]}),e.jsxs(d,{title:"内部方法调用导致事务不生效",children:[e.jsxs("p",{children:["下面这段代码是最经典的「事务莫名不回滚」：",e.jsx("code",{children:"createOrder()"})," 内部直接调用了同类的",e.jsx("code",{children:"saveLog()"}),"。由于是 ",e.jsx("code",{children:"this.saveLog()"}),"，走的是",e.jsx("strong",{children:"原始对象"}),"而非代理对象， 代理织入的事务逻辑被整个绕开，",e.jsx("code",{children:"@Transactional"})," 形同虚设。"]}),e.jsx(r,{lang:"java",title:"同类自调用，事务失效",code:o}),e.jsxs("p",{children:["解法：把方法拆到另一个 Bean 里调用，或注入自身代理（",e.jsx("code",{children:"AopContext.currentProxy()"})," 或自注入）， 让调用重新经过代理。"]})]}),e.jsx(l,{title:"默认只回滚运行时异常",children:e.jsxs("p",{children:["Spring 的默认回滚策略只覆盖 ",e.jsx("em",{children:"RuntimeException"})," 和 ",e.jsx("em",{children:"Error"}),"。 也就是说，如果你的方法抛的是",e.jsx("strong",{children:"受检异常"}),"（checked exception，如 ",e.jsx("code",{children:"IOException"}),"、",e.jsx("code",{children:"SQLException"}),"），事务",e.jsx("strong",{children:"不会回滚"}),"，数据照样提交。想让受检异常也回滚， 必须显式声明 ",e.jsx("code",{children:"@Transactional(rollbackFor = Exception.class)"}),"。这是最隐蔽的失效场景之一， 因为代码没报错、注解也在，数据却悄悄落库了。"]})}),e.jsxs(i,{variant:"warn",title:"事务失效的经典场景清单",children:[e.jsx("p",{children:"记住这一串，面试和排错都够用："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"方法非 public"}),"：Spring 默认只对 public 方法织入事务，private 或 protected 不生效。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"同类内部自调用"}),"：",e.jsx("code",{children:"this.method()"})," 不走代理，事务被绕过（上面的例子）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"异常被 catch 吞掉"}),"：方法内 try-catch 后没有重新抛出，代理感知不到异常，自然不回滚。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"抛检查异常"}),"：默认只对运行时异常回滚，受检异常需配置 ",e.jsx("code",{children:"rollbackFor = Exception.class"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"多线程"}),"：事务靠 ThreadLocal 绑定连接，新开线程拿不到同一个连接，事务不共享。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"数据库引擎不支持"}),"：如 MySQL 用 MyISAM 引擎本身不支持事务，注解再多也没用（须用 InnoDB）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Bean 没被 Spring 管理"}),"：自己 new 出来的对象不是代理，注解无效。"]})]})]}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["先点出根：「声明式事务靠 ",e.jsx("strong",{children:"AOP 代理"}),"，所以一切让调用",e.jsx("em",{children:"不经过代理"}),"或让代理",e.jsx("em",{children:"感知不到异常"}),"的情况，都会导致失效。」 然后分两条线展开：传播行为重点讲清 REQUIRED / REQUIRES_NEW / NESTED 的区别；失效场景按上面的清单逐条列出， 每条都能补一句「为什么」。能讲出「ThreadLocal 绑连接、默认只回滚运行时异常需 ",e.jsx("code",{children:"rollbackFor"}),"」这种细节，会显得很扎实。"]}),e.jsxs(n,{title:"REQUIRES_NEW 示例 + 失效场景自测",children:[e.jsx("p",{children:"用 REQUIRES_NEW 实现「主业务回滚、日志照样落库」：外层订单事务失败时，内层日志事务因为独立提交而不受影响。"}),e.jsx(r,{lang:"java",title:"OrderService.java",code:x}),e.jsx("p",{children:"动手把下面每条失效场景都复现一遍，亲眼确认「没回滚」："}),e.jsxs("ul",{children:[e.jsxs("li",{children:["把 ",e.jsx("code",{children:"@Transactional"})," 方法改成 ",e.jsx("code",{children:"private"}),"，观察不再回滚。"]}),e.jsxs("li",{children:["同类里用 ",e.jsx("code",{children:"this.xxx()"})," 调用带事务的方法，确认失效。"]}),e.jsx("li",{children:"方法内 try-catch 吞掉异常，确认数据已提交。"}),e.jsxs("li",{children:["抛一个受检异常（如 ",e.jsx("code",{children:"IOException"}),"），确认默认不回滚，再加 ",e.jsx("code",{children:"rollbackFor = Exception.class"})," 后回滚。"]})]})]}),e.jsx(c,{points:["声明式事务的本质是 AOP 代理：只有经过代理的调用，@Transactional 才生效。","七种传播行为重点记三种：REQUIRED 加入当前事务，REQUIRES_NEW 挂起外层开独立事务，NESTED 基于 savepoint 的嵌套事务。","REQUIRES_NEW 是两个独立事务互不牵连；NESTED 是父子关系，外层回滚会连带内层。","隔离级别对应数据库四级，默认 DEFAULT 跟随数据库（MySQL InnoDB 默认 REPEATABLE_READ）。","失效场景：非 public、同类自调用、异常被吞、抛检查异常未配 rollbackFor、多线程、引擎不支持、Bean 未被管理。","面试落点：先讲清「靠代理」这个根，再用它推导每一种失效原因，最后给出对应解法。"]})]})}export{E as default};
