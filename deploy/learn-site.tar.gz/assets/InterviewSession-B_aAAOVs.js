import{r as d,j as e,C as oe,u as be,P as xe}from"./index-Bkb6eOY7.js";import{f as Z,l as ye,S as we,b as je}from"./session-I_q0TAi6.js";const G={},Q=((G==null?void 0:G.VITE_API_BASE)||"")+"/api";async function Se({url:t,apiKey:s,model:i,messages:l},c,u){var w,f,j,$,S,L;const r=await fetch(Q+"/interview/chat",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({url:t,apiKey:s,model:i,messages:l,stream:!0}),signal:u});if(!r.ok||!r.body){let N=`面试官服务异常 (${r.status})`;try{const k=await r.json();k!=null&&k.message&&(N=k.message)}catch{}throw new Error(N)}const O=r.body.getReader(),y=new TextDecoder("utf-8");let m="",p="";for(;;){const{value:N,done:k}=await O.read();if(k)break;m+=y.decode(N,{stream:!0});let A;for(;(A=m.indexOf(`
`))>=0;){const I=m.slice(0,A).trim();if(m=m.slice(A+1),!I||!I.startsWith("data:"))continue;const M=I.slice(5).trim();if(M!=="[DONE]")try{const T=JSON.parse(M),z=((j=(f=(w=T.choices)==null?void 0:w[0])==null?void 0:f.delta)==null?void 0:j.content)??((L=(S=($=T.choices)==null?void 0:$[0])==null?void 0:S.message)==null?void 0:L.content)??"";z&&(p+=z,c&&c(z))}catch{}}}return p}async function Ne({url:t,apiKey:s,model:i,messages:l},c){const u=await fetch(Q+"/interview/chat",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({url:t,apiKey:s,model:i,messages:l,stream:!1}),signal:c}),r=await u.json().catch(()=>null);if(!u.ok)throw new Error((r==null?void 0:r.message)||`面试官服务异常 (${u.status})`);return(r==null?void 0:r.content)||""}async function ke({language:t,source:s,stdin:i=""},l){const c=await fetch(Q+"/interview/run-code",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({language:t,source:s,stdin:i}),signal:l}),u=await c.json().catch(()=>null);if(!c.ok)throw new Error((u==null?void 0:u.message)||`代码执行服务异常 (${c.status})`);return u}const se=[{id:"two-sum-ii",title:"两数之和 II（有序数组）",difficulty:"中等",tags:["数组","双指针"],statement:`给定一个已按升序排列的整数数组 numbers 和目标值 target，请找出两个数使它们相加之和等于 target，返回这两个数的下标（从 1 开始），要求空间复杂度 O(1)。

输入：第一行为目标值 target，第二行为以空格分隔的有序数组。
输出：两个下标，空格分隔。`,sampleInput:`9
2 7 11 15`,sampleOutput:"1 2"},{id:"longest-substring",title:"无重复字符的最长子串",difficulty:"中等",tags:["滑动窗口","哈希"],statement:`给定一个字符串 s，找出其中不含重复字符的最长子串的长度。

输入：一行字符串 s。
输出：最长无重复子串的长度。`,sampleInput:"abcabcbb",sampleOutput:"3"},{id:"add-two-numbers",title:"两个大数相加（字符串）",difficulty:"中等",tags:["字符串","模拟"],statement:`给定两个用字符串表示的非负大整数 a、b（可能超过 long 范围），返回它们之和（字符串）。

输入：两行，分别为 a 和 b。
输出：a + b。`,sampleInput:`99999999999999999999
1`,sampleOutput:"100000000000000000000"},{id:"lru-cache",title:"LRU 缓存机制",difficulty:"中等",tags:["设计","哈希","双向链表"],statement:`设计并实现一个 LRU（最近最少使用）缓存，支持 get 和 put，容量满时淘汰最久未使用的项，均要求 O(1)。

输入：第一行为容量 cap 与操作数 n；接下来 n 行，每行形如 "put 1 1" 或 "get 1"。
输出：每个 get 操作的返回值（未命中输出 -1），空格分隔在一行。`,sampleInput:`2 5
put 1 1
put 2 2
get 1
put 3 3
get 2`,sampleOutput:"1 -1"},{id:"longest-palindrome",title:"最长回文子串",difficulty:"中等",tags:["字符串","动态规划"],statement:`给定字符串 s，返回它的最长回文子串。

输入：一行字符串 s。
输出：最长回文子串（若有多个，输出任意一个）。`,sampleInput:"babad",sampleOutput:"bab"},{id:"three-sum",title:"三数之和",difficulty:"中等",tags:["数组","双指针"],statement:`给定数组 nums，找出所有和为 0 且不重复的三元组，按升序输出。

输入：一行以空格分隔的整数数组。
输出：每行一个三元组（升序、空格分隔）；无解输出空。`,sampleInput:"-1 0 1 2 -1 -4",sampleOutput:`-1 -1 2
-1 0 1`},{id:"container-water",title:"盛最多水的容器",difficulty:"中等",tags:["双指针","贪心"],statement:`给定 n 个非负整数表示柱子高度，找出两条柱子使其与 x 轴构成的容器能盛最多的水，输出最大面积。

输入：一行以空格分隔的高度数组。
输出：最大面积。`,sampleInput:"1 8 6 2 5 4 8 3 7",sampleOutput:"49"},{id:"coin-change",title:"零钱兑换",difficulty:"中等",tags:["动态规划"],statement:`给定硬币面额数组 coins 和总金额 amount，求凑成总金额所需最少硬币数；无法凑成输出 -1。

输入：第一行 amount；第二行硬币面额（空格分隔）。
输出：最少硬币数。`,sampleInput:`11
1 2 5`,sampleOutput:"3"},{id:"word-break",title:"单词拆分",difficulty:"中等",tags:["动态规划","字符串"],statement:`给定字符串 s 和单词字典 wordDict，判断 s 是否能被空格拆分成字典中的单词序列。

输入：第一行 s；第二行字典单词（空格分隔）。
输出：true 或 false。`,sampleInput:`leetcode
leet code`,sampleOutput:"true"},{id:"num-islands",title:"岛屿数量",difficulty:"中等",tags:["DFS","BFS","并查集"],statement:`给定由 '1'（陆地）和 '0'（水）组成的二维网格，计算岛屿数量。岛屿由相邻（上下左右）陆地连接。

输入：第一行 m n；接下来 m 行，每行 n 个 0/1（空格分隔）。
输出：岛屿数量。`,sampleInput:`3 3
1 1 0
0 1 0
0 0 1`,sampleOutput:"2"},{id:"course-schedule",title:"课程表（拓扑排序）",difficulty:"中等",tags:["图","拓扑排序"],statement:`共有 numCourses 门课，先修关系给定为 [a, b]（学 a 前必须先学 b）。判断能否完成所有课程。

输入：第一行 numCourses 与边数 m；接下来 m 行每行两个数 a b。
输出：true 或 false。`,sampleInput:`2 1
1 0`,sampleOutput:"true"},{id:"kth-largest",title:"数组中的第 K 个最大元素",difficulty:"中等",tags:["堆","快速选择"],statement:`在未排序数组中找到第 k 个最大的元素。

输入：第一行 k；第二行数组（空格分隔）。
输出：第 k 大的元素。`,sampleInput:`2
3 2 1 5 6 4`,sampleOutput:"5"},{id:"merge-intervals",title:"合并区间",difficulty:"中等",tags:["排序","区间"],statement:`给定若干区间，合并所有重叠区间。

输入：第一行区间数 n；接下来 n 行每行两个数 start end。
输出：合并后的区间，每行两个数（按起点升序）。`,sampleInput:`4
1 3
2 6
8 10
15 18`,sampleOutput:`1 6
8 10
15 18`},{id:"rotate-image",title:"旋转图像",difficulty:"中等",tags:["数组","矩阵"],statement:`给定 n×n 矩阵，将其原地顺时针旋转 90 度。

输入：第一行 n；接下来 n 行每行 n 个数。
输出：旋转后的矩阵。`,sampleInput:`3
1 2 3
4 5 6
7 8 9`,sampleOutput:`7 4 1
8 5 2
9 6 3`},{id:"subsets",title:"子集",difficulty:"中等",tags:["回溯","位运算"],statement:`给定一个不含重复元素的整数数组 nums，返回其所有可能的子集（幂集）。

输入：一行数组（空格分隔）。
输出：每行一个子集（空格分隔，含空行表示空集），顺序不限。`,sampleInput:"1 2 3",sampleOutput:`
1
2
1 2
3
1 3
2 3
1 2 3`},{id:"permutations",title:"全排列",difficulty:"中等",tags:["回溯"],statement:`给定不含重复数字的数组 nums，返回其所有全排列。

输入：一行数组（空格分隔）。
输出：每行一个排列（空格分隔），顺序不限。`,sampleInput:"1 2 3",sampleOutput:`1 2 3
1 3 2
2 1 3
2 3 1
3 1 2
3 2 1`},{id:"search-rotated",title:"搜索旋转排序数组",difficulty:"中等",tags:["二分查找"],statement:`整数数组 nums 升序排列后在某个未知点旋转，给定 target，存在则返回下标，否则返回 -1，要求 O(log n)。

输入：第一行 target；第二行数组。
输出：下标或 -1。`,sampleInput:`0
4 5 6 7 0 1 2`,sampleOutput:"4"},{id:"product-except-self",title:"除自身以外数组的乘积",difficulty:"中等",tags:["数组","前缀积"],statement:`给定数组 nums，返回数组 answer，其中 answer[i] 等于 nums 中除 nums[i] 之外其余元素的乘积，不能使用除法，O(n)。

输入：一行数组。
输出：结果数组（空格分隔）。`,sampleInput:"1 2 3 4",sampleOutput:"24 12 8 6"},{id:"daily-temperatures",title:"每日温度（单调栈）",difficulty:"中等",tags:["单调栈"],statement:`给定每日温度数组，返回数组 answer，answer[i] 表示第 i 天之后要等多少天才会有更高温度；若不存在则为 0。

输入：一行温度数组。
输出：结果数组（空格分隔）。`,sampleInput:"73 74 75 71 69 72 76 73",sampleOutput:"1 1 4 2 1 1 0 0"},{id:"min-path-sum",title:"最小路径和",difficulty:"中等",tags:["动态规划","矩阵"],statement:`给定 m×n 非负网格，从左上走到右下，每次只能向右或向下，求路径上数字和的最小值。

输入：第一行 m n；接下来 m 行每行 n 个数。
输出：最小路径和。`,sampleInput:`3 3
1 3 1
1 5 1
4 2 1`,sampleOutput:"7"},{id:"unique-paths",title:"不同路径",difficulty:"中等",tags:["动态规划","组合数学"],statement:`m×n 网格，机器人从左上到右下，每次只能向右或向下，求不同路径总数。

输入：一行 m n。
输出：路径数。`,sampleInput:"3 7",sampleOutput:"28"},{id:"max-subarray",title:"最大子数组和",difficulty:"中等",tags:["动态规划","分治"],statement:`给定整数数组 nums，找到具有最大和的连续子数组，返回其和。

输入：一行数组。
输出：最大子数组和。`,sampleInput:"-2 1 -3 4 -1 2 1 -5 4",sampleOutput:"6"},{id:"group-anagrams",title:"字母异位词分组",difficulty:"中等",tags:["哈希","字符串"],statement:`给定字符串数组，把字母异位词组合在一起。

输入：一行若干单词（空格分隔）。
输出：每行一组异位词（空格分隔），组内与组间顺序不限。`,sampleInput:"eat tea tan ate nat bat",sampleOutput:`eat tea ate
tan nat
bat`},{id:"spiral-matrix",title:"螺旋矩阵",difficulty:"中等",tags:["矩阵","模拟"],statement:`给定 m×n 矩阵，按顺时针螺旋顺序返回所有元素。

输入：第一行 m n；接下来 m 行每行 n 个数。
输出：螺旋顺序的所有元素（空格分隔，一行）。`,sampleInput:`3 3
1 2 3
4 5 6
7 8 9`,sampleOutput:"1 2 3 6 9 8 7 4 5"},{id:"jump-game",title:"跳跃游戏",difficulty:"中等",tags:["贪心"],statement:`给定非负整数数组 nums，初始位于下标 0，每个元素代表在该位置可跳跃的最大长度，判断能否到达最后一个下标。

输入：一行数组。
输出：true 或 false。`,sampleInput:"2 3 1 1 4",sampleOutput:"true"},{id:"longest-consecutive",title:"最长连续序列",difficulty:"中等",tags:["哈希","并查集"],statement:`给定未排序数组 nums，找出数字连续的最长序列长度，要求 O(n)。

输入：一行数组。
输出：最长连续序列长度。`,sampleInput:"100 4 200 1 3 2",sampleOutput:"4"},{id:"top-k-frequent",title:"前 K 个高频元素",difficulty:"中等",tags:["堆","哈希"],statement:`给定整数数组 nums 和整数 k，返回出现频率前 k 高的元素（按频率从高到低）。

输入：第一行 k；第二行数组。
输出：前 k 个高频元素（空格分隔）。`,sampleInput:`2
1 1 1 2 2 3`,sampleOutput:"1 2"},{id:"decode-ways",title:"解码方法",difficulty:"中等",tags:["动态规划","字符串"],statement:`数字到字母的映射为 '1'->A ... '26'->Z。给定只含数字的字符串 s，计算它有多少种解码方法。

输入：一行数字字符串 s。
输出：解码方法数。`,sampleInput:"226",sampleOutput:"3"},{id:"validate-bst",title:"验证二叉搜索树",difficulty:"中等",tags:["树","DFS"],statement:`给定二叉树的层序遍历（null 表示空节点），判断它是否是有效的二叉搜索树。

输入：一行层序遍历，节点值或 null，空格分隔。
输出：true 或 false。`,sampleInput:"5 1 4 null null 3 6",sampleOutput:"false"},{id:"gas-station",title:"加油站",difficulty:"中等",tags:["贪心"],statement:`环路上有 n 个加油站，gas[i] 为可加油量，cost[i] 为到下一站的耗油。从某站出发绕一圈，返回可行的起始站下标，无解返回 -1。

输入：第一行 gas 数组；第二行 cost 数组。
输出：起始站下标或 -1。`,sampleInput:`1 2 3 4 5
3 4 5 1 2`,sampleOutput:"3"},{id:"partition-equal",title:"分割等和子集",difficulty:"中等",tags:["动态规划","背包"],statement:`给定只含正整数的非空数组 nums，判断能否将其分割成两个和相等的子集。

输入：一行数组。
输出：true 或 false。`,sampleInput:"1 5 11 5",sampleOutput:"true"},{id:"house-robber-ii",title:"打家劫舍 II（环形）",difficulty:"中等",tags:["动态规划"],statement:`房屋围成一圈，相邻两间不能同时偷。给定每间金额数组 nums，求能偷到的最高金额。

输入：一行数组。
输出：最高金额。`,sampleInput:"2 3 2",sampleOutput:"3"},{id:"find-duplicate",title:"寻找重复数",difficulty:"中等",tags:["双指针","快慢指针"],statement:`给定 n+1 个整数的数组 nums，数字都在 [1, n] 内，存在且仅存在一个重复数，找出它（不修改数组、O(1) 空间）。

输入：一行数组。
输出：重复的数字。`,sampleInput:"1 3 4 2 2",sampleOutput:"2"},{id:"min-window",title:"最小覆盖子串",difficulty:"困难",tags:["滑动窗口","哈希"],statement:`给定字符串 s 和 t，返回 s 中涵盖 t 所有字符的最小子串；不存在则返回空串。

输入：第一行 s；第二行 t。
输出：最小覆盖子串。`,sampleInput:`ADOBECODEBANC
ABC`,sampleOutput:"BANC"},{id:"trapping-rain",title:"接雨水",difficulty:"困难",tags:["双指针","单调栈"],statement:`给定 n 个非负整数表示柱子高度图，计算下雨后能接多少雨水。

输入：一行高度数组。
输出：能接的雨水总量。`,sampleInput:"0 1 0 2 1 0 1 3 2 1 2 1",sampleOutput:"6"},{id:"edit-distance",title:"编辑距离",difficulty:"困难",tags:["动态规划"],statement:`给定两个单词 word1 和 word2，返回将 word1 转换成 word2 所使用的最少操作数（插入/删除/替换）。

输入：两行，分别为 word1 和 word2。
输出：最少操作数。`,sampleInput:`horse
ros`,sampleOutput:"3"},{id:"lis",title:"最长递增子序列",difficulty:"中等",tags:["动态规划","二分"],statement:`给定整数数组 nums，找到其中最长严格递增子序列的长度。

输入：一行数组。
输出：最长递增子序列长度。`,sampleInput:"10 9 2 5 3 7 101 18",sampleOutput:"4"}],W={python:`import sys

def solve(data):
    # data 是按行切分的输入列表；在这里实现你的逻辑并 print 结果
    pass

def main():
    data = sys.stdin.read().split('\\n')
    solve(data)

if __name__ == '__main__':
    main()
`,java:`import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // 在这里读取输入、实现逻辑并 System.out.println 输出结果
        // String line = br.readLine();
    }
}
`};function ne(){const t=Math.floor(Math.random()*se.length);return se[t]}const Ce={python:["print(","input(","len(","range(","int(","str(","float(","list(","dict(","set(","tuple(","sorted(","reversed(","enumerate(","zip(","map(","filter(","sum(","min(","max(","abs(","round(","any(","all(","isinstance(","append(","extend(","insert(","pop(","remove(","sort(","split(","join(","strip(","replace(","startswith(","endswith(","find(","format(","keys(","values(","items(","get(","setdefault(","def ","class ","return ","import ","from ","for ","while ","if ","elif ","else:","try:","except ","finally:","with ","lambda ","yield ","global ","collections","defaultdict(","Counter(","deque(","heapq","heappush(","heappop(","heapify(","bisect","bisect_left(","bisect_right(","itertools","functools","lru_cache","math","sys.stdin","sys.stdin.read("],java:["public ","private ","protected ","static ","final ","void ","class ","interface ","extends ","implements ","return ","new ","import ","package ","if ","else ","for ","while ","switch ","case ","break;","continue;","try ","catch ","finally ","throw ","throws ","int ","long ","double ","float ","boolean ","char ","byte ","short ","String ","Integer","Long","Double","Boolean","Character","Math.","System.out.println(","System.out.print(","System.out.printf(","List<","ArrayList<","LinkedList<","Map<","HashMap<","TreeMap<","Set<","HashSet<","TreeSet<","Queue<","Deque<","ArrayDeque<","PriorityQueue<","Stack<","Collections.","Arrays.","Arrays.sort(","Arrays.asList(","StringBuilder","append(","toString()","length()","size()","add(","get(","put(","getOrDefault(","containsKey(","contains(","remove(","poll(","offer(","peek(","push(","pop(","BufferedReader","InputStreamReader","readLine()","split(","Integer.parseInt(","Long.parseLong(","String.valueOf(","Math.max(","Math.min(","Math.abs("]};function ae(t,s){const l=t.slice(0,s).match(/[A-Za-z_.][A-Za-z0-9_.]*$/);return l?l[0]:""}function Oe({initialLang:t="python",onSubmit:s}){const[i,l]=d.useState(t),[c,u]=d.useState({python:W.python,java:W.java}),[r,O]=d.useState(""),[y,m]=d.useState(""),[p,w]=d.useState(!1),[f,j]=d.useState(!1),[$,S]=d.useState({open:!1,items:[],index:0}),L=d.useRef(null),N=c[i],k=n=>u(o=>({...o,[i]:n})),A=d.useMemo(()=>Ce[i]||[],[i]),I=(n,o)=>{const C=ae(n,o);if(C.length<1){S({open:!1,items:[],index:0});return}const R=C.toLowerCase(),D=A.filter(U=>U.toLowerCase().startsWith(R)&&U.toLowerCase()!==R).slice(0,8);S(D.length?{open:!0,items:D,index:0}:{open:!1,items:[],index:0})},M=n=>{const o=L.current;if(!o)return;const C=o.selectionStart,R=ae(N,C),D=C-R.length,U=N.slice(0,D)+n+N.slice(C);k(U);const q=D+n.length;S({open:!1,items:[],index:0}),requestAnimationFrame(()=>{o.focus(),o.selectionStart=o.selectionEnd=q})},T=n=>{k(n.target.value),I(n.target.value,n.target.selectionStart)},z=n=>{if($.open){if(n.key==="ArrowDown"){n.preventDefault(),S(o=>({...o,index:(o.index+1)%o.items.length}));return}if(n.key==="ArrowUp"){n.preventDefault(),S(o=>({...o,index:(o.index-1+o.items.length)%o.items.length}));return}if(n.key==="Enter"||n.key==="Tab"){n.preventDefault(),M($.items[$.index]);return}if(n.key==="Escape"){S({open:!1,items:[],index:0});return}}if(n.key==="Tab"){n.preventDefault();const o=n.target,C=o.selectionStart,R=o.selectionEnd,D=N.slice(0,C)+"    "+N.slice(R);k(D),requestAnimationFrame(()=>{o.selectionStart=o.selectionEnd=C+4})}n.key==="Enter"&&(n.ctrlKey||n.metaKey)&&(n.preventDefault(),f||g())},g=async()=>{j(!0),w(!1),m("正在执行…");try{const n=await ke({language:i,source:N,stdin:r}),o=n.output||n.stdout||"",C=n.stderr||"",R=[o,C].filter(Boolean).join(`
`);w(!!C&&!o),m(R||"（没有任何输出）")}catch(n){w(!0),m(String((n==null?void 0:n.message)||n))}finally{j(!1)}},K=()=>k(W[i]),E=Math.max(14,N.split(`
`).length+1);return e.jsxs("div",{className:"code-editor",children:[e.jsxs("div",{className:"ce-tabs",children:[["python","java"].map(n=>e.jsx("button",{className:`ce-tab ${n===i?"active":""}`,onClick:()=>{l(n),S({open:!1,items:[],index:0})},children:n==="python"?"Python":"Java"},n)),e.jsxs("div",{className:"ce-tab-actions",children:[e.jsx("button",{className:"btn btn-ghost ce-small",onClick:K,disabled:f,children:"重置模板"}),e.jsx("button",{className:"btn btn-primary ce-small",onClick:g,disabled:f,children:f?"执行中…":"▶ 运行"})]})]}),e.jsxs("div",{className:"ce-editor-wrap",children:[e.jsx("textarea",{ref:L,className:"ce-textarea",value:N,onChange:T,onKeyDown:z,onBlur:()=>setTimeout(()=>S({open:!1,items:[],index:0}),120),spellCheck:!1,rows:E,"aria-label":"代码编辑器"}),$.open&&e.jsx("ul",{className:"ce-suggest",children:$.items.map((n,o)=>e.jsx("li",{className:o===$.index?"active":"",onMouseDown:C=>{C.preventDefault(),M(n)},children:n},n))})]}),e.jsxs("div",{className:"ce-io",children:[e.jsxs("div",{className:"ce-io-col",children:[e.jsx("label",{className:"ce-label",children:"标准输入（stdin，可留空）"}),e.jsx("textarea",{className:"ce-stdin",value:r,onChange:n=>O(n.target.value),spellCheck:!1,rows:4,placeholder:"把样例输入粘到这里，运行时会作为程序的标准输入"})]}),e.jsxs("div",{className:"ce-io-col",children:[e.jsx("label",{className:"ce-label",children:"运行结果"}),e.jsx("pre",{className:`ce-output${p?" is-error":""}`,children:y||"（点击「运行」查看输出）"})]})]}),e.jsxs("div",{className:"ce-bottom",children:[e.jsx("span",{className:"ce-hint",children:"提示：输入时会出现基础库联想（↑↓ 选择，Enter/Tab 补全）；Ctrl/⌘ + Enter 运行。"}),s&&e.jsx("button",{className:"btn btn-primary",onClick:()=>s({language:i,source:N}),children:"提交给面试官点评"})]})]})}function $e(){return oe.map(t=>({slug:t.meta.slug,title:t.meta.title,desc:t.meta.shortTitle||t.meta.subtitle||"",cat:`${t.meta.categoryId}/${t.meta.subCategoryId||""}`}))}function ie(t){return`${typeof window<"u"?window.location.origin:""}/course/${t}`}function re(t){return oe.find(s=>s.meta.slug===t)||null}const Ie={A:{label:"A · 非常满意",color:"#0e835a",desc:"语言表达、项目、技术与 Coding 近乎完美，正是公司需要的人才（极难获得）"},B:{label:"B · 优秀人才",color:"#2563eb",desc:"整体优秀，个别方面略有差距，强烈推荐给后续面试官"},C:{label:"C · 通过面试",color:"#b26a09",desc:"项目与技术基础扎实，可继续推进，但缺少特别亮眼的表现"},D:{label:"D · 未通过（可荐他岗）",color:"#c0344d",desc:"部分方面欠缺，本岗位不再推进，其他岗位可继续面试"},E:{label:"E · 不可行",color:"#7a1326",desc:"一个或多个方面表现很差，短期内不建议推进其他岗位"}};function _(t){return Ie[t]||{label:t,color:"#454c59",desc:""}}function Ee(t){const s=Z(t.position),i=$e().map(l=>`${l.slug} | ${l.title}`).join(`
`);return`面试到此结束。现在请你切换为「面试评估官」，基于上面完整的面试对话记录，对这位「${s?s.title:t.position}」候选人做一次严谨、客观的综合评估打分。

# 评分等级（必须从中选一个）
- A：非常满意。语言表达、项目考察、技术技能和 Coding 都基本做到完美，正是公司需要的人才（极难获得）。
- B：优秀人才。在 A 的基础上个别方面有差距，但仍优秀，会强烈推荐给后续面试官。
- C：通过面试。项目考察、技术基础都比较扎实，可继续推进；没有特别亮眼或打动面试官的表现一般定为此级。
- D：未通过，但可推荐其他岗位。综合评估有所欠缺，本岗位不再推进，其他岗位可继续面试。
- E：完全不可行。一个或多个方面表现很差（如项目说不清、追问细节或基础知识基本不了解），短期内不建议推进其他岗位。

# 评估要求
1. 必须「结合面试中的具体问答实例」给出理由，好的与不足的地方都要引用候选人实际说过的话或表现，不能空口无凭。
2. 分维度评估：语言表达、项目考察、技术基础、AI/LLM 编程、Coding 编码。每个维度给 1-5 分并附结合实例的点评。
3. 给出后续需要加强的知识/技能清单，并尽量从下面的「本站课程清单」中挑选相关课程推荐（用 slug）。

# 本站课程清单（slug | 课程名）
${i}

# 输出格式（务必只输出一个 JSON，不要任何额外文字或 markdown 代码块标记）
{
  "grade": "A|B|C|D|E",
  "gradeReason": "为什么定这个等级（结合整体表现，2-4句）",
  "overallSummary": "整体评价（150字左右）",
  "dimensions": [
    {"name": "语言表达", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "项目考察", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "技术基础", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "AI/LLM 编程", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "Coding 编码", "score": 1-5, "comment": "结合实例的点评"}
  ],
  "strengths": [{"point": "亮点", "example": "面试中的具体实例"}],
  "weaknesses": [{"point": "不足", "example": "面试中的具体实例"}],
  "improvements": [{"topic": "需加强的知识/技能", "detail": "具体建议", "courseSlugs": ["相关课程slug"]}],
  "recommendedCourses": [{"slug": "课程slug", "reason": "推荐理由"}]
}`}function Re(t){if(!t)throw new Error("评估结果为空");let s=t.trim();const i=s.match(/```(?:json)?\s*([\s\S]*?)```/);i&&(s=i[1].trim());const l=s.indexOf("{"),c=s.lastIndexOf("}");return l>=0&&c>l&&(s=s.slice(l,c+1)),JSON.parse(s)}const h=t=>String(t??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");function Le(t){const s=Math.max(0,Math.min(5,Number(t)||0));return"★".repeat(s)+"☆".repeat(5-s)}function Ae(t,s){const i=Z(s.position),l=_(t.grade),c=new Date,u=`${c.getFullYear()}-${String(c.getMonth()+1).padStart(2,"0")}-${String(c.getDate()).padStart(2,"0")} ${String(c.getHours()).padStart(2,"0")}:${String(c.getMinutes()).padStart(2,"0")}`,r=(t.dimensions||[]).map(f=>`<tr>
        <td class="dim-name">${h(f.name)}</td>
        <td class="dim-score"><span class="stars">${Le(f.score)}</span> <b>${h(f.score)}</b>/5</td>
        <td class="dim-comment">${h(f.comment)}</td>
      </tr>`).join(""),O=(t.strengths||[]).map(f=>`<li><div class="pt good">✔ ${h(f.point)}</div>${f.example?`<div class="ex">实例：${h(f.example)}</div>`:""}</li>`).join(""),y=(t.weaknesses||[]).map(f=>`<li><div class="pt bad">✘ ${h(f.point)}</div>${f.example?`<div class="ex">实例：${h(f.example)}</div>`:""}</li>`).join(""),m=(t.improvements||[]).map(f=>{const j=(f.courseSlugs||[]).map($=>{const S=re($);return S?`<a class="course-link" href="${h(ie($))}" target="_blank" rel="noopener">📘 ${h(S.meta.title)}</a>`:""}).filter(Boolean).join("");return`<li><div class="imp-topic">${h(f.topic)}</div><div class="imp-detail">${h(f.detail)}</div>${j?`<div class="imp-links">${j}</div>`:""}</li>`}).join(""),p=(t.recommendedCourses||[]).map(f=>{const j=re(f.slug);return j?`<a class="rec-card" href="${h(ie(f.slug))}" target="_blank" rel="noopener">
        <div class="rec-cover">${h(j.meta.cover||"📘")}</div>
        <div class="rec-body"><div class="rec-title">${h(j.meta.title)}</div><div class="rec-reason">${h(f.reason||j.meta.shortTitle||"")}</div></div>
      </a>`:""}).filter(Boolean).join(""),w=(s.skills||[]).map(h).join("、");return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>面试评估报告 · ${h(i?i.title:"")}</title>
<style>
  :root { --ink:#14171f; --soft:#454c59; --faint:#878e9c; --border:#e6e8ec; --bg:#fff; --sub:#f6f7f9; --accent:#4f46e5; }
  * { box-sizing: border-box; }
  body { margin:0; background:#eef0f4; color:var(--ink); font-family:-apple-system,'Segoe UI','Noto Sans SC',system-ui,sans-serif; line-height:1.7; }
  .sheet { max-width:880px; margin:32px auto; background:var(--bg); border-radius:16px; box-shadow:0 12px 40px rgba(20,23,31,.12); overflow:hidden; }
  .head { padding:34px 40px; background:linear-gradient(120deg,#4f46e5,#7c3aed); color:#fff; }
  .head h1 { margin:0 0 6px; font-size:1.6rem; }
  .head .meta { font-size:.9rem; opacity:.9; }
  .body { padding:32px 40px; }
  .grade-box { display:flex; align-items:center; gap:24px; padding:22px 26px; border-radius:14px; background:var(--sub); border:1px solid var(--border); margin-bottom:28px; }
  .grade-badge { width:92px; height:92px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:3rem; font-weight:800; color:#fff; flex-shrink:0; }
  .grade-info .glabel { font-size:1.2rem; font-weight:700; }
  .grade-info .gdesc { color:var(--soft); font-size:.92rem; margin-top:4px; }
  .grade-info .greason { margin-top:10px; font-size:.92rem; }
  h2 { font-size:1.15rem; margin:30px 0 12px; padding-left:12px; border-left:4px solid var(--accent); }
  .summary { background:var(--sub); border-radius:10px; padding:16px 18px; font-size:.95rem; }
  table { width:100%; border-collapse:collapse; font-size:.92rem; }
  th,td { text-align:left; padding:10px 12px; border-bottom:1px solid var(--border); vertical-align:top; }
  th { background:var(--sub); font-size:.82rem; color:var(--soft); }
  .dim-name { font-weight:700; white-space:nowrap; }
  .dim-score { white-space:nowrap; } .stars { color:#f5a623; letter-spacing:1px; }
  ul.list { list-style:none; padding:0; margin:0; }
  ul.list li { padding:12px 0; border-bottom:1px dashed var(--border); }
  .pt { font-weight:700; } .pt.good { color:#0e835a; } .pt.bad { color:#c0344d; }
  .ex { color:var(--soft); font-size:.9rem; margin-top:4px; padding-left:18px; border-left:2px solid var(--border); }
  .imp-topic { font-weight:700; }
  .imp-detail { color:var(--soft); font-size:.92rem; margin:4px 0; }
  .imp-links, .recs { display:flex; flex-wrap:wrap; gap:8px; margin-top:6px; }
  .course-link { display:inline-block; padding:5px 12px; background:#eef0fe; color:#4338ca; border:1px solid #c7cbf7; border-radius:999px; font-size:.84rem; text-decoration:none; }
  .course-link:hover { background:#4f46e5; color:#fff; }
  .recs { margin-top:12px; }
  .rec-card { display:flex; gap:12px; align-items:center; width:calc(50% - 6px); padding:12px 14px; border:1px solid var(--border); border-radius:12px; text-decoration:none; color:inherit; }
  .rec-card:hover { border-color:var(--accent); box-shadow:0 4px 14px rgba(20,23,31,.08); }
  .rec-cover { font-size:1.8rem; } .rec-title { font-weight:700; font-size:.95rem; } .rec-reason { color:var(--soft); font-size:.84rem; }
  .foot { padding:20px 40px; color:var(--faint); font-size:.82rem; border-top:1px solid var(--border); text-align:center; }
  @media print { body{background:#fff;} .sheet{box-shadow:none; margin:0;} }
  @media (max-width:640px){ .rec-card{width:100%;} .body,.head,.foot{padding-left:20px;padding-right:20px;} }
</style>
</head>
<body>
  <div class="sheet">
    <div class="head">
      <h1>面试评估报告</h1>
      <div class="meta">岗位：${h(i?i.title:s.position)} ｜ 考察技能：${w||"—"} ｜ 生成时间：${h(u)}</div>
    </div>
    <div class="body">
      <div class="grade-box">
        <div class="grade-badge" style="background:${l.color}">${h(t.grade)}</div>
        <div class="grade-info">
          <div class="glabel" style="color:${l.color}">${h(l.label)}</div>
          <div class="gdesc">${h(l.desc)}</div>
          <div class="greason">${h(t.gradeReason)}</div>
        </div>
      </div>

      <h2>整体评价</h2>
      <div class="summary">${h(t.overallSummary)}</div>

      <h2>分维度评估</h2>
      <table><thead><tr><th>维度</th><th>评分</th><th>结合实例的点评</th></tr></thead><tbody>${r}</tbody></table>

      <h2>亮点</h2>
      <ul class="list">${O||"<li>（无）</li>"}</ul>

      <h2>不足</h2>
      <ul class="list">${y||"<li>（无）</li>"}</ul>

      <h2>后续需要加强的知识 / 技能</h2>
      <ul class="list">${m||"<li>（无）</li>"}</ul>

      ${p?`<h2>推荐课程</h2><div class="recs">${p}</div>`:""}
    </div>
    <div class="foot">本报告由「编程学习站 · 面试模拟」基于本次面试问答自动生成，仅供学习参考。</div>
  </div>
</body>
</html>`}function De(t,s="面试评估报告.html"){const i=new Blob([t],{type:"text/html;charset=utf-8"}),l=URL.createObjectURL(i),c=document.createElement("a");c.href=l,c.download=s,document.body.appendChild(c),c.click(),document.body.removeChild(c),setTimeout(()=>URL.revokeObjectURL(l),2e3)}function Me(t){const s=new Blob([t],{type:"text/html;charset=utf-8"}),i=URL.createObjectURL(s);window.open(i,"_blank"),setTimeout(()=>URL.revokeObjectURL(i),6e4)}function Te(){return typeof window<"u"&&!!(window.SpeechRecognition||window.webkitSpeechRecognition)}function le(){return typeof window<"u"&&!!window.speechSynthesis}function ze({lang:t="zh-CN",onResult:s,onError:i,onEnd:l}={}){const c=window.SpeechRecognition||window.webkitSpeechRecognition;if(!c)return null;const u=new c;return u.lang=t,u.continuous=!0,u.interimResults=!0,u.onresult=r=>{let O="",y="";for(let m=r.resultIndex;m<r.results.length;m++){const p=r.results[m];p.isFinal?y+=p[0].transcript:O+=p[0].transcript}y?s&&s(y,!0):O&&s&&s(O,!1)},u.onerror=r=>i&&i(r),u.onend=()=>l&&l(),u}function Be({lang:t="zh-CN",rate:s=1.05,pitch:i=1}={}){const l=typeof window<"u"?window.speechSynthesis:null;let c=!0,u=[],r=!1;function O(){if(!l)return null;const m=l.getVoices()||[];return m.find(p=>p.lang===t)||m.find(p=>p.lang&&p.lang.startsWith(t.split("-")[0]))||null}function y(){if(!l||r||u.length===0)return;const m=u.shift();if(!m.trim()){y();return}const p=new SpeechSynthesisUtterance(m);p.lang=t,p.rate=s,p.pitch=i;const w=O();w&&(p.voice=w),p.onend=()=>{r=!1,y()},p.onerror=()=>{r=!1,y()},r=!0,l.speak(p)}return{speak(m){if(!l||!c||!m)return;const p=String(m).split(new RegExp("(?<=[。！？.!?；;\\n])")).map(w=>w.trim()).filter(Boolean);u.push(...p.length?p:[m]),y()},stop(){u=[],r=!1,l&&l.cancel()},setEnabled(m){c=m,m||this.stop()},get enabled(){return c}}}function Pe(t){const s=String(Math.floor(t/60)).padStart(2,"0"),i=String(t%60).padStart(2,"0");return`${s}:${i}`}function _e(){const t=be(),s=ye(),[i,l]=d.useState([]),[c,u]=d.useState(""),[r,O]=d.useState(!1),[y,m]=d.useState(""),[p,w]=d.useState(""),[f,j]=d.useState(0),[$,S]=d.useState(0),[L,N]=d.useState(!1),[k,A]=d.useState(!1),[I,M]=d.useState((s==null?void 0:s.voice)!==!1),[T,z]=d.useState(!1),[g,K]=d.useState(null),[E,n]=d.useState("idle"),[o,C]=d.useState(null),[R,D]=d.useState(""),[U,q]=d.useState(""),x=d.useRef(null),V=d.useRef(null),B=d.useRef(""),H=d.useRef(null),F=d.useRef(null);d.useEffect(()=>{s||t("/interview",{replace:!0})},[]),d.useEffect(()=>(le()&&(x.current=Be({lang:"zh-CN"})),x.current&&x.current.setEnabled(I),()=>{x.current&&x.current.stop()}),[]),d.useEffect(()=>{x.current&&x.current.setEnabled(I)},[I]),d.useEffect(()=>{if(!L)return;const a=setInterval(()=>S(v=>v+1),1e3);return()=>clearInterval(a)},[L]),d.useEffect(()=>{H.current&&(H.current.scrollTop=H.current.scrollHeight)},[i,c]);const ce=a=>{if(!I||!x.current)return;B.current+=a;const v=B.current,b=v.match(/^[\s\S]*[。！？.!?；;\n]/);b&&(x.current.speak(b[0]),B.current=v.slice(b[0].length))},de=()=>{I&&x.current&&B.current.trim()&&x.current.speak(B.current),B.current=""},Y=async a=>{O(!0),m(""),u(""),B.current="";const v=new AbortController;F.current=v;try{const b=await Se({url:s.llmUrl,apiKey:s.llmKey,model:s.llmModel,messages:a},P=>{u(ve=>ve+P),ce(P)},v.signal);de(),l([...a,{role:"assistant",content:b}]),u("")}catch(b){(b==null?void 0:b.name)!=="AbortError"&&m(String((b==null?void 0:b.message)||b)),u("")}finally{O(!1),F.current=null}},ue=async()=>{const a={role:"system",content:je(s)};N(!0),await Y([a])},J=async a=>{const v=(a??p).trim();if(!v||r)return;x.current&&x.current.stop(),w("");const b=[...i,{role:"user",content:v}];l(b),await Y(b)},me=()=>{if(!Te()){m("当前浏览器不支持语音识别，请用 Chrome / Edge，或直接打字作答");return}if(k){V.current&&V.current.stop();return}x.current&&x.current.stop();const a=ze({lang:"zh-CN",onResult:(v,b)=>{b&&w(P=>(P?P+" ":"")+v)},onError:()=>A(!1),onEnd:()=>A(!1)});a&&(V.current=a,a.start(),A(!0))},X=()=>{g||K(ne()),z(!0),j(4)},pe=async({language:a,source:v})=>{const b=`（编程环节）题目：${g==null?void 0:g.title}
我用 ${a==="java"?"Java":"Python"} 作答，代码如下：

\`\`\`${a}
${v}
\`\`\`

请点评我的思路、时间/空间复杂度和边界处理，并指出可以改进的地方。`;await J(b)},fe=async()=>{await J("面试官您好，本次面试到这里，麻烦您对我今天的整体表现做一个总结评价：包括优点、不足，以及针对性的提升建议。")},ge=()=>{F.current&&F.current.abort(),x.current&&x.current.stop()},ee=async()=>{if(x.current&&x.current.stop(),i.filter(a=>a.role!=="system").length<2){q("面试内容太少，请先进行面试再生成报告"),n("error");return}n("loading"),q("");try{const a=[...i,{role:"user",content:Ee(s)}],v=await Ne({url:s.llmUrl,apiKey:s.llmKey,model:s.llmModel,messages:a}),b=Re(v),P=Ae(b,s);C(b),D(P),n("ready")}catch(a){q("生成报告失败："+String((a==null?void 0:a.message)||a)),n("error")}};if(!s)return null;const te=Z(s.position),he=i.filter(a=>a.role!=="system");return e.jsx(xe,{children:e.jsxs("div",{className:"container iv-session",children:[e.jsxs("div",{className:"iv-bar",children:[e.jsxs("div",{className:"iv-bar-left",children:[e.jsxs("span",{className:"iv-bar-title",children:["模拟面试 · ",te?te.title:""]}),e.jsxs("span",{className:"iv-timer",children:["⏱ ",Pe($)]})]}),e.jsxs("div",{className:"iv-bar-right",children:[le()&&e.jsx("button",{className:`iv-pill ${I?"on":""}`,onClick:()=>M(a=>!a),title:"面试官语音朗读",children:I?"🔊 语音开":"🔇 语音关"}),e.jsx("button",{className:"btn btn-ghost ce-small",onClick:()=>t("/interview"),children:"退出"})]})]}),e.jsx("div",{className:"iv-stages",children:we.map((a,v)=>e.jsxs("button",{className:`iv-stage ${v===f?"active":""} ${v<f?"done":""}`,onClick:()=>{j(v),a.id==="coding"&&X()},title:`${a.desc} · 约${a.minutes}分钟`,children:[e.jsx("span",{className:"iv-stage-no",children:v+1}),e.jsx("span",{className:"iv-stage-name",children:a.title}),e.jsxs("span",{className:"iv-stage-min",children:[a.minutes,"min"]})]},a.id))}),e.jsxs("div",{className:`iv-main ${T?"with-code":""}`,children:[e.jsx("div",{className:"iv-chat-col",children:L?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"iv-messages",ref:H,children:[he.map((a,v)=>e.jsxs("div",{className:`iv-msg ${a.role}`,children:[e.jsx("div",{className:"iv-msg-who",children:a.role==="assistant"?"面试官":"我"}),e.jsx("div",{className:"iv-msg-body",children:a.content})]},v)),c&&e.jsxs("div",{className:"iv-msg assistant",children:[e.jsx("div",{className:"iv-msg-who",children:"面试官"}),e.jsxs("div",{className:"iv-msg-body",children:[c,e.jsx("span",{className:"iv-caret",children:"▍"})]})]}),r&&!c&&e.jsxs("div",{className:"iv-msg assistant",children:[e.jsx("div",{className:"iv-msg-who",children:"面试官"}),e.jsx("div",{className:"iv-msg-body iv-thinking",children:"思考中…"})]})]}),y&&e.jsx("div",{className:"iv-error",children:y}),e.jsxs("div",{className:"iv-input-area",children:[e.jsx("textarea",{className:"iv-answer",value:p,onChange:a=>w(a.target.value),onKeyDown:a=>{a.key==="Enter"&&(a.ctrlKey||a.metaKey)&&(a.preventDefault(),J())},placeholder:k?"正在聆听，请说话…（识别结果会填到这里）":"输入你的回答，或点麦克风语音作答（Ctrl/⌘+Enter 发送）",rows:3,disabled:r}),e.jsxs("div",{className:"iv-input-actions",children:[e.jsx("button",{className:`iv-mic ${k?"on":""}`,onClick:me,disabled:r,title:"语音作答",children:k?"● 停止录音":"🎤 语音"}),e.jsx("div",{className:"iv-spacer"}),r&&e.jsx("button",{className:"btn btn-ghost ce-small",onClick:ge,children:"停止"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>J(),disabled:r||!p.trim(),children:"发送"})]}),e.jsxs("div",{className:"iv-quick",children:[e.jsx("button",{className:"iv-quick-btn",onClick:X,disabled:r,children:"进入编程环节 ⌨️"}),e.jsx("button",{className:"iv-quick-btn",onClick:fe,disabled:r,children:"请面试官总结评价"}),e.jsx("button",{className:"iv-quick-btn primary",onClick:ee,disabled:r||E==="loading",children:E==="loading"?"正在生成报告…":"结束并生成评分报告 📄"})]})]})]}):e.jsxs("div",{className:"iv-prestart",children:[e.jsx("p",{children:"准备好了吗？点击下方按钮，面试官将先做自我介绍并请你介绍自己。"}),e.jsx("p",{className:"iv-sub",children:"全程约 1 小时，建议在安静环境、用 Chrome/Edge 浏览器以获得最佳语音体验。"}),e.jsx("button",{className:"btn btn-primary iv-start",onClick:ue,disabled:r,children:r?"面试官准备中…":"开始面试"})]})}),T&&e.jsxs("div",{className:"iv-code-col",children:[e.jsxs("div",{className:"iv-problem",children:[e.jsxs("div",{className:"iv-problem-head",children:[e.jsxs("h3",{children:[g==null?void 0:g.title," ",e.jsx("span",{className:`iv-diff ${g==null?void 0:g.difficulty}`,children:g==null?void 0:g.difficulty})]}),e.jsx("button",{className:"iv-quick-btn",onClick:()=>K(ne()),children:"换一题"})]}),e.jsx("div",{className:"iv-problem-tags",children:((g==null?void 0:g.tags)||[]).map(a=>e.jsx("span",{className:"iv-tag",children:a},a))}),e.jsx("pre",{className:"iv-problem-body",children:g==null?void 0:g.statement}),(g==null?void 0:g.sampleInput)!=null&&e.jsxs("div",{className:"iv-sample",children:[e.jsxs("div",{children:[e.jsx("strong",{children:"示例输入"}),e.jsx("pre",{children:g.sampleInput})]}),e.jsxs("div",{children:[e.jsx("strong",{children:"示例输出"}),e.jsx("pre",{children:g.sampleOutput})]})]})]}),e.jsx(Oe,{initialLang:"python",onSubmit:pe},g==null?void 0:g.id)]})]}),(E==="ready"||E==="error"||E==="loading")&&e.jsx("div",{className:"iv-modal-mask",onClick:()=>E!=="loading"&&n("idle"),children:e.jsxs("div",{className:"iv-modal",onClick:a=>a.stopPropagation(),children:[E==="loading"&&e.jsxs("div",{className:"iv-modal-loading",children:[e.jsx("div",{className:"iv-spin"}),e.jsx("p",{children:"面试评估官正在结合本次问答为你打分、撰写报告…"})]}),E==="error"&&e.jsxs("div",{className:"iv-modal-body",children:[e.jsx("h3",{children:"生成失败"}),e.jsx("div",{className:"iv-error",children:U}),e.jsxs("div",{className:"iv-modal-actions",children:[e.jsx("button",{className:"btn btn-ghost",onClick:()=>n("idle"),children:"关闭"}),e.jsx("button",{className:"btn btn-primary",onClick:ee,children:"重试"})]})]}),E==="ready"&&o&&e.jsxs("div",{className:"iv-modal-body",children:[e.jsxs("div",{className:"iv-report-grade",children:[e.jsx("div",{className:"iv-grade-badge",style:{background:_(o.grade).color},children:o.grade}),e.jsxs("div",{children:[e.jsx("div",{className:"iv-grade-label",style:{color:_(o.grade).color},children:_(o.grade).label}),e.jsx("div",{className:"iv-grade-desc",children:_(o.grade).desc})]})]}),e.jsx("p",{className:"iv-report-reason",children:o.gradeReason}),e.jsx("p",{className:"iv-report-summary",children:o.overallSummary}),e.jsx("p",{className:"iv-sub",children:"完整报告（含分维度评分、结合实例的亮点与不足、提升建议与课程推荐）可下载或在新窗口查看："}),e.jsxs("div",{className:"iv-modal-actions",children:[e.jsx("button",{className:"btn btn-ghost",onClick:()=>n("idle"),children:"关闭"}),e.jsx("button",{className:"btn btn-ghost",onClick:()=>Me(R),children:"在新窗口打开"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>De(R,`面试评估报告_${o.grade}.html`),children:"下载 HTML 报告"})]})]})]})})]})})}export{_e as default};
