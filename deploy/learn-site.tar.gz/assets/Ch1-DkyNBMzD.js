import{j as e}from"./index-CBMe5udE.js";import{L as i,S as l}from"./Summary-CEfAQ4SZ.js";import{K as s}from"./KeyIdea-K3hFePn1.js";import{C as r}from"./Callout-3wJQ5WDp.js";import{C as t}from"./CodeBlock-D4LRiuTl.js";import{E as n}from"./Example-CFOi3F9j.js";import{P as d}from"./Practice-DPYESI8W.js";import{P as o}from"./PyRunner-BFTa7xWi.js";const c=`# 综合：默认参数 + 多返回值
def stats(nums, label="数据"):
    total = sum(nums)
    avg = total / len(nums)
    return total, avg          # 一次返回两个值（元组）

data = [80, 90, 100, 70]
s, a = stats(data)             # 拆包接住
print("数据的总和:", s)
print("平均值:", a)

# 传入自定义 label
s2, a2 = stats([60, 60], label="成绩")
print(f"成绩总和: {s2}, 平均: {a2}")`,a=`def say_hello():
    print("你好！")

say_hello()      # 调用：让函数跑起来
say_hello()      # 可以反复调用`,x=`你好！
你好！`,h=`def greet(name):          # name 是参数
    print(f"你好，{name}")

greet("小明")             # "小明" 是传进去的参数值
greet("小红")`,j=`你好，小明
你好，小红`,g=`def add(a, b):
    return a + b          # 把结果返回给调用处

result = add(3, 5)        # 接住返回值
print(result)
print(add(10, 20) * 2)    # 返回值可以直接参与运算`,u=`8
60`,p=`def show(x):
    print(x)              # 只打印，没有 return

r = show(100)
print(r)                  # 没有 return 的函数返回 None`,m=`100
None`,f=`def min_max(nums):
    return min(nums), max(nums)   # 用逗号返回多个值（其实是一个元组）

low, high = min_max([3, 1, 4, 1, 5])   # 拆包接住
print("最小:", low)
print("最大:", high)`,y=`最小: 1
最大: 5`,C=`def greet(name, greeting="你好"):   # greeting 有默认值
    print(f"{greeting}，{name}")

greet("小明")                       # 不传 greeting，用默认
greet("小红", "早上好")              # 传了就用传的`,_=`你好，小明
早上好，小红`,b=`def info(name, age, city):
    print(f"{name}，{age}岁，来自{city}")

info("小明", 18, "杭州")                       # 按位置传
info(city="北京", name="小红", age=20)         # 按关键字传，顺序随意`,w=`小明，18岁，来自杭州
小红，20岁，来自北京`,O=`def area(width, height):
    """计算矩形面积。

    参数：
        width: 宽
        height: 高
    返回：
        面积（宽乘高）
    """
    return width * height

print(area(3, 4))
print(area.__doc__)     # 可以读出文档字符串`,v=`12
计算矩形面积。

    参数：
        width: 宽
        height: 高
    返回：
        面积（宽乘高）`,N=`x = 10            # 全局变量

def change():
    x = 99        # 这是函数内部的「局部」变量，和外面的 x 不是一个
    print("函数内:", x)

change()
print("函数外:", x)   # 外面的 x 没被改变`,P=`函数内: 99
函数外: 10`,R=`count = 0

def add_one():
    global count      # 声明：我要改的是外面那个 count
    count += 1

add_one()
add_one()
print(count)`,k="2";function q(){return e.jsxs("article",{children:[e.jsxs(i,{children:["当一段代码要反复用、或者逻辑变复杂时，我们就把它打包成一个",e.jsx("strong",{children:"函数"}),"， 起个名字，需要时一调用就行。这一章讲怎么定义函数、怎么传参数和返回结果、默认参数和关键字参数、 给函数写说明文档，以及一个新手必须搞懂的概念——变量的「作用域」。"]}),e.jsx("h2",{children:"一、定义和调用函数"}),e.jsxs(s,{children:["用 ",e.jsx("code",{children:"def"})," 关键字定义函数：",e.jsx("code",{children:"def 函数名():"}),"，下面缩进的就是函数体。 定义只是「写好备用」，要用 ",e.jsx("code",{children:"函数名()"})," 去",e.jsx("strong",{children:"调用"}),"，函数体里的代码才会真正执行。"]}),e.jsx(t,{lang:"python",title:"最简单的函数",code:a}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:x})}),e.jsx(r,{variant:"tip",children:"函数的好处：① 同一段逻辑写一次、用多次，不用复制粘贴；② 给一段代码起个有意义的名字，让程序更好读； ③ 改逻辑只要改一处。这是写出整洁代码的基础。"}),e.jsx("h2",{children:"二、参数：给函数传入数据"}),e.jsxs("p",{children:["括号里可以放",e.jsx("strong",{children:"参数"}),"，相当于函数的「输入口」。调用时把具体的值传进去："]}),e.jsx(t,{lang:"python",title:"带参数的函数",code:h}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:j})}),e.jsx("h2",{children:"三、返回值：让函数把结果交出来"}),e.jsxs("p",{children:["用 ",e.jsx("code",{children:"return"})," 把计算结果「交出来」，调用处可以接住它继续用。这是函数最常见的形态："]}),e.jsx(t,{lang:"python",title:"return 返回结果",code:g}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:u})}),e.jsxs(r,{variant:"note",title:"print 和 return 不是一回事",children:[e.jsx("code",{children:"print"})," 是把东西「显示给人看」；",e.jsx("code",{children:"return"})," 是把结果「交回给程序」继续用。 没有 ",e.jsx("code",{children:"return"})," 的函数，默认返回 ",e.jsx("code",{children:"None"}),"："]}),e.jsx(t,{lang:"python",title:"没有 return 返回 None",code:p}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:m})}),e.jsx("h2",{children:"四、返回多个值"}),e.jsxs("p",{children:[e.jsx("code",{children:"return"})," 后面用逗号隔开多个值，就能一次返回多个（本质是打包成一个元组），用拆包接住："]}),e.jsx(t,{lang:"python",title:"多返回值",code:f}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:y})}),e.jsx("h2",{children:"五、默认参数"}),e.jsxs("p",{children:["给参数设一个",e.jsx("strong",{children:"默认值"}),"，调用时不传这个参数就用默认值，传了就用传的。让函数更灵活："]}),e.jsx(t,{lang:"python",title:"默认参数",code:C}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:_})}),e.jsxs(r,{variant:"warn",title:"默认参数必须放在后面",children:["有默认值的参数必须排在没默认值的参数后面，否则报语法错误。 例如 ",e.jsx("code",{children:"def f(a, b=1)"})," 合法，",e.jsx("code",{children:"def f(a=1, b)"})," 不合法。"]}),e.jsx("h2",{children:"六、关键字参数"}),e.jsxs("p",{children:["调用时可以用 ",e.jsx("code",{children:"参数名=值"})," 的形式指定，叫",e.jsx("strong",{children:"关键字参数"}),"。好处是顺序随意、含义清晰："]}),e.jsx(t,{lang:"python",title:"关键字参数",code:b}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:w})}),e.jsx("h2",{children:"七、文档字符串"}),e.jsxs("p",{children:["在函数体第一行写一段三引号字符串，就是",e.jsx("strong",{children:"文档字符串"}),"（docstring），用来说明这个函数干什么。 它不是注释，是函数自带的说明，可以被工具读取："]}),e.jsx(t,{lang:"python",title:"文档字符串",code:O}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:v})}),e.jsx("h2",{children:"八、局部变量 vs 全局变量"}),e.jsxs(s,{children:["在函数",e.jsx("strong",{children:"内部"}),"定义的变量是",e.jsx("strong",{children:"局部变量"}),"，只在函数里有效，函数一结束就消失； 在函数",e.jsx("strong",{children:"外部"}),"定义的是",e.jsx("strong",{children:"全局变量"}),"。函数内部可以「读」全局变量， 但直接赋值会创建一个同名的局部变量，不会影响外面的。"]}),e.jsx(t,{lang:"python",title:"作用域演示",code:N}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:P})}),e.jsxs("p",{children:["如果确实想在函数里修改外面的全局变量，要用 ",e.jsx("code",{children:"global"})," 声明一下："]}),e.jsx(t,{lang:"python",title:"global 修改全局变量",code:R}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:k})}),e.jsxs(r,{variant:"tip",children:["实际开发中，",e.jsx("code",{children:"global"})," 能不用就不用——过度依赖全局变量会让代码难以维护。 更好的做法是把需要的数据用参数传进函数，用 ",e.jsx("code",{children:"return"})," 把结果传出来。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」。"]}),e.jsx(o,{initialCode:c}),e.jsx(d,{title:"动手练一练",children:e.jsxs("ol",{children:[e.jsxs("li",{children:["写一个函数 ",e.jsx("code",{children:"is_even(n)"}),"，返回 n 是否为偶数（True/False）。"]}),e.jsxs("li",{children:["写一个函数 ",e.jsx("code",{children:"describe(name, age=18)"}),"，打印一句自我介绍，age 有默认值。"]}),e.jsxs("li",{children:["写一个函数 ",e.jsx("code",{children:"stats(nums)"}),"，一次返回列表的「总和」和「平均值」两个值，并在调用处拆包打印。"]})]})}),e.jsx(l,{points:["def 定义函数，函数名() 调用；定义只是备用，调用才执行函数体。","参数是输入口，return 把结果交回给程序；没有 return 的函数返回 None。","print 给人看、return 给程序用，两者不同；return 加逗号可返回多个值（元组），用拆包接住。","默认参数让调用更灵活（必须放在无默认参数后面）；关键字参数 名=值 顺序随意、含义清晰。","函数第一行的三引号文档字符串说明函数用途，可用 函数.__doc__ 读取。","函数内是局部变量、外是全局变量；内部直接赋值不影响外部，要改全局需 global 声明（尽量少用，优先用参数+返回值）。"]})]})}export{q as default};
