import{j as e}from"./index-Bkb6eOY7.js";import{L as n,S as o}from"./Summary-Dj-Y5ESD.js";import{K as c}from"./KeyIdea-N6HVLWjp.js";import{C as t}from"./Callout-FpvHzM97.js";import{C as s}from"./CodeBlock-BQqVtp_3.js";import{E as d}from"./Example-iLfTRUEi.js";const i=`<script setup>
import { ref } from 'vue'
const open = ref(false)
<\/script>

<template>
  <button @click="open = true">打开弹窗</button>

  <!-- 无论这段写在多深的组件里，DOM 都会被渲染到 body 下 -->
  <Teleport to="body">
    <div v-if="open" class="modal-mask">
      <div class="modal">
        <h3>这是一个模态框</h3>
        <button @click="open = false">关闭</button>
      </div>
    </div>
  </Teleport>
</template>`,l=`<!-- to 接收任意 CSS 选择器或真实 DOM 节点 -->
<Teleport to="#toast-root">...</Teleport>

<!-- disabled 为真时不传送，原地渲染（可按屏幕宽度等条件切换） -->
<Teleport to="body" :disabled="isMobile">...</Teleport>`,r=`<script setup>
// 顶层 await：这个组件的 setup 变成异步的，必须由 Suspense 来等待
const res = await fetch('/api/profile')
const profile = await res.json()
<\/script>

<template>
  <h2>{{ profile.name }}</h2>
</template>`,a=`<template>
  <Suspense>
    <!-- #default 里可以是异步组件，或带顶层 await 的异步 setup 组件 -->
    <template #default>
      <AsyncProfile />
    </template>
    <!-- 等待期间显示 fallback -->
    <template #fallback>
      <p>加载中...</p>
    </template>
  </Suspense>
</template>`,x=`<template>
  <!-- 切走的组件实例被缓存，再切回来时保留滚动位置、表单输入等状态 -->
  <KeepAlive>
    <component :is="currentTab" />
  </KeepAlive>

  <!-- include / exclude 控制哪些组件被缓存（按 name 匹配） -->
  <KeepAlive :include="['TabA', 'TabB']">
    <component :is="currentTab" />
  </KeepAlive>

  <!-- max 限制最多缓存几个实例（LRU 淘汰） -->
  <KeepAlive :max="5">
    <component :is="currentTab" />
  </KeepAlive>
</template>`,p=`<script setup>
import { onActivated, onDeactivated, ref } from 'vue'

const timer = ref(null)

// 被 KeepAlive 缓存的组件不会走 onUnmounted，
// 而是用 onActivated / onDeactivated 这对钩子
onActivated(() => {
  // 每次重新进入（切回来）时触发：可在此恢复轮询、刷新数据
  timer.value = setInterval(poll, 5000)
})

onDeactivated(() => {
  // 切走（被缓存起来）时触发：清理定时器，避免后台空转
  clearInterval(timer.value)
})
<\/script>`,h=`<script setup>
// 局部自定义指令：在 <script setup> 里以 vXxx 命名即可在模板用 v-xxx
const vFocus = {
  // 元素插入 DOM 后调用
  mounted(el) {
    el.focus()
  },
}
<\/script>

<template>
  <input v-focus />
</template>`,u=`// 全局注册：app.directive('名字', 定义对象)
app.directive('focus', {
  mounted(el) {
    el.focus()
  },
})

// 一个更实用的例子：v-color 根据绑定值设置文字颜色
app.directive('color', {
  mounted(el, binding) {
    el.style.color = binding.value
  },
  updated(el, binding) {
    el.style.color = binding.value
  },
})
// 用法：<span v-color="'red'">警告</span>`,j=`// composables/useMouse.js
import { ref, onMounted, onUnmounted } from 'vue'

// 约定：组合式函数以 use 开头，把「有状态的逻辑」抽出来复用
export function useMouse() {
  const x = ref(0)
  const y = ref(0)

  function update(e) {
    x.value = e.pageX
    y.value = e.pageY
  }

  // 在 composable 里照样能用生命周期钩子，自动绑定到调用它的组件
  onMounted(() => window.addEventListener('mousemove', update))
  onUnmounted(() => window.removeEventListener('mousemove', update))

  // 返回响应式状态（和方法），由调用方解构使用
  return { x, y }
}`,m=`<script setup>
import { useMouse } from '@/composables/useMouse'

// 一行接入，多个组件都能复用同一套逻辑，各自拥有独立状态
const { x, y } = useMouse()
<\/script>

<template>
  <p>鼠标位置：{{ x }}, {{ y }}</p>
</template>`,v=`// composables/useFetch.js
import { ref, watchEffect, toValue } from 'vue'

// 接受 ref / getter / 普通值；用 toValue 统一取值，URL 变化时自动重新请求
export function useFetch(url) {
  const data = ref(null)
  const error = ref(null)
  const loading = ref(false)

  async function doFetch() {
    data.value = null
    error.value = null
    loading.value = true
    try {
      const res = await fetch(toValue(url))
      data.value = await res.json()
    } catch (e) {
      error.value = e
    } finally {
      loading.value = false
    }
  }

  // 依赖（url）变化时自动重新执行
  watchEffect(doFetch)

  return { data, error, loading }
}`,f=`<script setup>
import { ref } from 'vue'
import { useFetch } from '@/composables/useFetch'

const id = ref(1)
// 传入一个 getter，id 变了 useFetch 内部会自动重新请求
const { data, error, loading } = useFetch(() => '/api/users/' + id.value)
<\/script>

<template>
  <button @click="id++">下一个用户</button>
  <p v-if="loading">加载中...</p>
  <p v-else-if="error">出错了</p>
  <pre v-else>{{ data }}</pre>
</template>`,b=`// 旧时代：mixin 把逻辑混入组件，但来源不透明、命名易冲突
export const mouseMixin = {
  data() {
    return { x: 0, y: 0 }
  },
  mounted() {
    window.addEventListener('mousemove', this.update)
  },
  methods: {
    update(e) {
      this.x = e.pageX
      this.y = e.pageY
    },
  },
}
// 组件里 mixins: [mouseMixin] —— 但 this.x 从哪来？多个 mixin 一起用会不会撞名？看不出来`;function T(){return e.jsxs("article",{children:[e.jsxs(n,{children:["上一章谈性能，这一章谈「表达力」与「复用」。Vue 3 提供了一组进阶内置组件——",e.jsx("code",{children:"Teleport"}),"、",e.jsx("code",{children:"Suspense"}),"、",e.jsx("code",{children:"KeepAlive"}),"——分别解决 「DOM 渲染到哪里」「异步加载期间显示什么」「切走的组件状态保不保留」三类问题； 再加上",e.jsx("strong",{children:"自定义指令"}),"和",e.jsx("strong",{children:"组合式函数（composable）"}),"这两套复用机制。 其中 composable 是 Vue 3 逻辑复用的主角，相当于 Vue 版的自定义 Hook， 它优雅地取代了 Vue 2 时代的 mixin。"]}),e.jsx("h2",{children:"一、Teleport：把 DOM 渲染到别处"}),e.jsxs(c,{children:[e.jsx("code",{children:"Teleport"})," 让你在组件内书写一段模板，却把它真正渲染到 DOM 树的",e.jsx("strong",{children:"另一个位置"}),"（通常是 ",e.jsx("code",{children:"body"}),"）。逻辑上它还属于当前组件，物理上它脱离了父级的层叠与溢出约束。"]}),e.jsxs("p",{children:["模态框、通知 toast、下拉菜单这类「浮层」组件常被祖先元素的 ",e.jsx("code",{children:"overflow: hidden"})," 裁切， 或被 ",e.jsx("code",{children:"z-index"})," 层叠上下文压住。把它们用 ",e.jsx("code",{children:"Teleport"})," 传送到 ",e.jsx("code",{children:"body"})," 下， 就摆脱了父级样式的干扰，",e.jsx("strong",{children:"层级和定位都干净了"}),"，而事件、数据绑定仍按组件树正常工作。"]}),e.jsx(s,{lang:"vue",title:"用 Teleport 实现模态框",code:i}),e.jsxs("p",{children:[e.jsx("code",{children:"to"})," 接收任意 CSS 选择器或真实 DOM 节点；",e.jsx("code",{children:"disabled"})," 为真时则原地渲染、 不做传送，可用于按屏幕宽度等条件动态切换。"]}),e.jsx(s,{lang:"vue",title:"Teleport 的 to 与 disabled",code:l}),e.jsxs(t,{variant:"note",title:"目标必须已存在",children:[e.jsx("code",{children:"Teleport"})," 挂载时，目标节点（如 ",e.jsx("code",{children:"#toast-root"}),"）必须已经存在于 DOM 中， 否则会报错。",e.jsx("code",{children:"body"})," 永远存在，所以最常用。"]}),e.jsx("h2",{children:"二、Suspense：协调异步加载态"}),e.jsxs("p",{children:["上一章已见过 ",e.jsx("code",{children:"Suspense"})," 的雏形，这里讲透它「等什么」。它能等待两类异步：",e.jsx("strong",{children:"异步组件"}),"（",e.jsx("code",{children:"defineAsyncComponent"})," 加载的）与",e.jsx("strong",{children:"异步 setup"}),"（在 ",e.jsx("code",{children:"<script setup>"})," 里用了顶层 ",e.jsx("code",{children:"await"})," 的组件）。 只要它的默认插槽内有未就绪的异步，它就显示 ",e.jsx("code",{children:"#fallback"}),"；全部就绪后切到 ",e.jsx("code",{children:"#default"}),"。"]}),e.jsx(s,{lang:"vue",title:"带顶层 await 的异步 setup",code:r}),e.jsx(s,{lang:"vue",title:"Suspense 配 #default / #fallback",code:a}),e.jsxs(t,{variant:"warn",title:"Suspense 仍是实验性特性",children:["到 2026 年，",e.jsx("code",{children:"Suspense"})," 的 API 官方仍标注为",e.jsx("strong",{children:"实验性"}),"，未来可能有调整。 生产中用它处理异步组件加载态通常没问题，但要留意版本说明，别在它之上堆太复杂的依赖。"]}),e.jsx("h2",{children:"三、KeepAlive：缓存组件实例"}),e.jsxs("p",{children:["默认情况下，组件被切走（如 Tab 切换、路由离开）就会被",e.jsx("strong",{children:"销毁"}),"，再切回来要重新创建， 滚动位置、表单输入、已加载的数据全丢了。用 ",e.jsx("code",{children:"KeepAlive"})," 包裹动态组件， 切走的实例会被",e.jsx("strong",{children:"缓存而非销毁"}),"，切回来时原样恢复。"]}),e.jsx(s,{lang:"vue",title:"KeepAlive 与 include / exclude / max",code:x}),e.jsxs("p",{children:["通过 ",e.jsx("code",{children:"include"})," / ",e.jsx("code",{children:"exclude"}),"（按组件 ",e.jsx("code",{children:"name"})," 匹配）控制哪些被缓存，",e.jsx("code",{children:"max"})," 限制最多缓存几个实例（按 LRU 淘汰最久未用的）。"]}),e.jsx("h3",{children:"3.1 onActivated / onDeactivated"}),e.jsxs("p",{children:["被缓存的组件不会触发 ",e.jsx("code",{children:"onUnmounted"}),"（因为它没被销毁），所以「切走时清理、切回时恢复」 这类逻辑要改用专门的一对钩子：",e.jsx("code",{children:"onActivated"}),"（每次进入/切回时调用）与",e.jsx("code",{children:"onDeactivated"}),"（每次切走/被缓存时调用）。典型用途是定时器和轮询的启停。"]}),e.jsx(s,{lang:"vue",title:"缓存组件的激活钩子",code:p}),e.jsx("h2",{children:"四、自定义指令"}),e.jsxs("p",{children:["当你需要对",e.jsx("strong",{children:"底层 DOM 元素"}),"做可复用的直接操作（聚焦、设置样式、绑定第三方 DOM 库）， 自定义指令是合适的工具。它本质是一个带",e.jsx("strong",{children:"生命周期钩子"}),"的对象，钩子在元素的 不同阶段被调用："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"钩子"}),e.jsx("th",{children:"调用时机"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"created"})}),e.jsx("td",{children:"元素属性/事件绑定前"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"beforeMount"})}),e.jsx("td",{children:"元素插入 DOM 前"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"mounted"})}),e.jsx("td",{children:"元素插入 DOM 后（最常用）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"beforeUpdate"})}),e.jsx("td",{children:"所在组件更新前"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"updated"})}),e.jsx("td",{children:"所在组件更新后"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"beforeUnmount"})," / ",e.jsx("code",{children:"unmounted"})]}),e.jsx("td",{children:"元素卸载前 / 后"})]})]})]}),e.jsxs("p",{children:["在 ",e.jsx("code",{children:"<script setup>"})," 里，任何以 ",e.jsx("code",{children:"v"})," 开头的驼峰命名变量（如",e.jsx("code",{children:"vFocus"}),"）都会自动成为模板里可用的 ",e.jsx("code",{children:"v-focus"})," 指令； 也可以用 ",e.jsx("code",{children:"app.directive()"})," 全局注册。"]}),e.jsx(s,{lang:"vue",title:"局部自定义指令 v-focus",code:h}),e.jsx(s,{lang:"js",title:"全局注册指令（含带参数的 v-color）",code:u}),e.jsx(t,{variant:"tip",title:"优先用组件，指令用于 DOM 级操作",children:"大多数复用应该用组件或 composable 解决。只有「必须直接摸 DOM」时才用自定义指令， 比如自动聚焦、滚动到底加载、集成一个基于 DOM 节点的第三方库。"}),e.jsx("h2",{children:"五、组合式函数 composable：逻辑复用的主角"}),e.jsxs(c,{children:["组合式函数（composable）是一个",e.jsx("strong",{children:"以 use 开头的普通函数"}),"， 它内部使用组合式 API（",e.jsx("code",{children:"ref"}),"、",e.jsx("code",{children:"computed"}),"、生命周期钩子等）把",e.jsx("strong",{children:"有状态的逻辑"}),"封装起来，供多个组件复用。它就是 Vue 版的「自定义 Hook」。"]}),e.jsxs("p",{children:["关键点有三：其一，命名约定以 ",e.jsx("code",{children:"use"})," 开头，一眼可辨； 其二，它返回响应式状态（和操作方法），由调用方解构使用； 其三，每个组件调用它都会得到",e.jsx("strong",{children:"独立的一份状态"}),"，互不干扰。 composable 里照样能用 ",e.jsx("code",{children:"onMounted"})," 等生命周期钩子，它们会自动绑定到调用它的那个组件。"]}),e.jsx("h3",{children:"5.1 完整例子：useMouse"}),e.jsx("p",{children:"把「追踪鼠标坐标」这段有状态逻辑抽成 composable："}),e.jsx(s,{lang:"js",title:"composables/useMouse.js",code:j}),e.jsx(s,{lang:"vue",title:"在组件中使用 useMouse",code:m}),e.jsx("h3",{children:"5.2 完整例子：useFetch"}),e.jsxs("p",{children:["更实用的是把「发请求 + loading + error」三态封装起来。下面的 ",e.jsx("code",{children:"useFetch"})," 接受 ref / getter / 普通值，用 ",e.jsx("code",{children:"toValue"})," 统一取值，并用 ",e.jsx("code",{children:"watchEffect"}),"在 URL 变化时自动重新请求："]}),e.jsx(s,{lang:"js",title:"composables/useFetch.js",code:v}),e.jsx(s,{lang:"vue",title:"在组件中使用 useFetch",code:f}),e.jsxs(d,{title:"composable 的两大好处",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"逻辑聚合"}),"：一个功能（如鼠标追踪、数据请求）的状态、副作用、清理逻辑都集中在 一个函数里，而不是散落在 ",e.jsx("code",{children:"data"})," / ",e.jsx("code",{children:"methods"})," / ",e.jsx("code",{children:"mounted"})," 各处。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"透明复用"}),"：组件里写 ",e.jsxs("code",{children:["const ","{ x, y }"," = useMouse()"]}),"， 一眼就知道 ",e.jsx("code",{children:"x"}),"、",e.jsx("code",{children:"y"})," 从哪来。换十个组件都这么写，来源始终清晰。"]})]}),e.jsx("h2",{children:"六、为什么 composable 取代了 mixin"}),e.jsxs("p",{children:["Vue 2 时代用 ",e.jsx("strong",{children:"mixin"})," 复用逻辑：把 ",e.jsx("code",{children:"data"})," / ",e.jsx("code",{children:"methods"})," / 生命周期混入组件。它能用，但有三个老毛病："]}),e.jsx(s,{lang:"js",title:"mixin 的写法（对比用）",code:b}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"来源不透明"}),"：组件模板里用到 ",e.jsx("code",{children:"x"}),"，却看不出它来自哪个 mixin， 要翻遍所有 mixin 才知道。composable 是显式解构，来源一目了然。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"命名冲突"}),"：两个 mixin 都定义了 ",e.jsx("code",{children:"update"})," 或 ",e.jsx("code",{children:"x"}),"， 会静默互相覆盖。composable 返回的是普通变量，你解构时可随意重命名（",e.jsxs("code",{children:["const ","{ x: mouseX }"]}),"）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"难以组合"}),"：mixin 之间的依赖关系隐晦。composable 就是普通函数调用， 一个 composable 里可以再调另一个，组合关系清清楚楚。"]})]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"对比项"}),e.jsx("th",{children:"mixin（Vue 2）"}),e.jsx("th",{children:"composable（Vue 3）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"来源"}),e.jsx("td",{children:"不透明，需翻查"}),e.jsx("td",{children:"显式解构，一目了然"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"命名冲突"}),e.jsx("td",{children:"静默覆盖"}),e.jsx("td",{children:"可自由重命名，无冲突"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"组合"}),e.jsx("td",{children:"依赖隐晦"}),e.jsx("td",{children:"普通函数嵌套调用，清晰"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"类型支持"}),e.jsx("td",{children:"弱"}),e.jsx("td",{children:"天然友好（就是函数返回值）"})]})]})]}),e.jsxs(t,{variant:"note",title:"结论",children:["Vue 3 官方推荐",e.jsx("strong",{children:"用 composable 替代 mixin"}),"。新项目里基本不再写 mixin， 所有有状态的逻辑复用都交给 ",e.jsx("code",{children:"use*"})," 函数。"]}),e.jsx("h2",{children:"七、小结与边界"}),e.jsxs("p",{children:["这一章的工具各司其职：",e.jsx("code",{children:"Teleport"})," 管「渲染位置」，",e.jsx("code",{children:"Suspense"})," 管「异步加载态」，",e.jsx("code",{children:"KeepAlive"})," 管「实例缓存」，自定义指令管「DOM 级复用」， composable 管「有状态逻辑的复用」。选型时记住优先级：",e.jsx("strong",{children:"能用组件解决就用组件， 逻辑复用首选 composable，只有必须直接操作 DOM 才上自定义指令"}),"。 Teleport / Suspense / KeepAlive 则是遇到对应场景时的标准答案。"]}),e.jsx(o,{points:["Teleport 把模板渲染到 DOM 树的别处（常用 body），解决模态框/通知被父级 overflow 裁切与 z-index 层叠的问题；逻辑仍属当前组件。","Suspense 等待异步组件或带顶层 await 的异步 setup，用 #default / #fallback 两个插槽协调加载态；2026 年仍标注为实验性。","KeepAlive 缓存而非销毁切走的组件实例，保留其状态；用 include/exclude/max 控制缓存，配 onActivated / onDeactivated 做启停清理。","自定义指令是带生命周期钩子（mounted/updated 等）的对象，用于 DOM 级复用（v-focus 等）；script setup 里 vXxx 即可，或 app.directive 全局注册。","composable 是以 use 开头的函数，封装有状态逻辑供复用（Vue 版自定义 Hook）；每次调用得到独立状态，可用生命周期钩子。useMouse、useFetch 是典型例子。","composable 取代 mixin：来源透明、可重命名避免冲突、组合关系清晰、类型友好，是 Vue 3 逻辑复用的首选。"]})]})}export{T as default};
