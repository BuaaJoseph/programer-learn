import{j as e}from"./index-qtIRnDEm.js";import{L as s,S as c}from"./Summary-D7M9FdYM.js";import{K as d}from"./KeyIdea-C5mX38F7.js";import{C as n}from"./Callout-Bvq_rfqV.js";import{C as r}from"./CodeBlock-DsDQiuPI.js";import{E as i}from"./Example-Ba1iSJHN.js";const l=`import type { Agent } from './agent.js'
import { ALL_TOOLS } from './tools/index.js'
import { ClaudeProvider } from './provider/claude.js'

// 斜杠命令：以 / 开头的输入不发给 LLM，而是在本地直接处理。
// 这套系统刻意做成「注册表 + 统一派发」，加一个命令 = 往 COMMANDS 里加一项。

export interface CommandContext {
  agent: Agent
  /** 打印一行到终端。 */
  print: (s: string) => void
  /** 请求退出 REPL。 */
  quit: () => void
}

export interface SlashCommand {
  name: string
  description: string
  run(args: string, ctx: CommandContext): void
}

export const COMMANDS: SlashCommand[] = [
  {
    name: 'help',
    description: '列出所有可用命令',
    run(_args, ctx) {
      ctx.print('可用命令：')
      for (const c of COMMANDS) ctx.print(\`  /\${c.name.padEnd(8)} \${c.description}\`)
    },
  },
  {
    name: 'clear',
    description: '清空当前会话历史，从头开始',
    run(_args, ctx) {
      ctx.agent.clearHistory()
      ctx.print('（已清空会话历史）')
    },
  },
  {
    name: 'model',
    description: '查看或切换模型，例如 /model claude-opus-4-8',
    run(args, ctx) {
      const next = args.trim()
      if (!next) {
        ctx.print(\`当前模型：\${ctx.agent.model}\`)
        return
      }
      ctx.agent.setProvider(new ClaudeProvider({ model: next }))
      ctx.print(\`已切换模型：\${next}\`)
    },
  },
  {
    name: 'tools',
    description: '列出已注册的工具',
    run(_args, ctx) {
      ctx.print('已注册工具：')
      for (const t of ALL_TOOLS) {
        ctx.print(\`  \${t.name.padEnd(7)} \${t.readOnly ? '[只读]' : '[写] '} \${t.description.slice(0, 40)}…\`)
      }
    },
  },
  {
    name: 'exit',
    description: '退出 forge',
    run(_args, ctx) {
      ctx.quit()
    },
  },
]

export function isCommand(input: string): boolean {
  return input.startsWith('/')
}

export function runCommand(input: string, ctx: CommandContext): void {
  const [name, ...rest] = input.slice(1).split(/\\s+/)
  const cmd = COMMANDS.find((c) => c.name === name)
  if (!cmd) {
    ctx.print(\`未知命令 /\${name}，输入 /help 查看全部。\`)
    return
  }
  cmd.run(rest.join(' '), ctx)
}`,o=`if (isCommand(input)) {
  runCommand(input, {
    agent,
    print: (s) => console.log(s),
    quit: () => {
      quitting = true
      rl.close()
    },
  })
  if (quitting) break
  rl.prompt()
  continue
}`,t=`forge › /help
可用命令：
  /help     列出所有可用命令
  /clear    清空当前会话历史，从头开始
  /model    查看或切换模型，例如 /model claude-opus-4-8
  /tools    列出已注册的工具
  /exit     退出 forge

forge › /model
当前模型：claude-sonnet-4-6

forge › /model claude-opus-4-8
已切换模型：claude-opus-4-8

forge › /clear
（已清空会话历史）

forge › /tools
已注册工具：
  read    [只读] 读取指定文件的内容，可选行范围…
  list    [只读] 列出目录下的文件与子目录…
  bash    [写]  执行一条 shell 命令并返回 stdout/stderr…
  write   [写]  把内容写入文件，覆盖或新建…
  edit    [写]  在文件里做精确的字符串替换…

forge › /exit
再见。`,x=`// runCommand 第一行：把 "/model claude-opus-4-8" 拆成 名字 + 参数串
const [name, ...rest] = input.slice(1).split(/\\s+/)
//        ^name='model'   ^rest=['claude-opus-4-8']
// 注意这套解析的「设计边界」：按空白切，名字是第一段，其余原样 join 回去。
// 它不识别引号、不解析 --flag、不做转义——因为命令的参数交给各自的 run 去理解，
// 派发层只负责「切出名字，把剩下的整块交给命令」。`,h=`// 一个最小的命令补全器：按已输入的前缀，从 COMMANDS 里筛出候选。
// 接到 readline 的 completer 选项上，用户敲 Tab 就能补全命令名。
function completer(line: string): [string[], string] {
  if (!line.startsWith('/')) return [[], line] // 不是命令，不补全
  const prefix = line.slice(1)
  const hits = COMMANDS
    .map((c) => '/' + c.name)
    .filter((name) => name.startsWith('/' + prefix))
  // readline 约定：返回 [匹配列表, 被匹配的原串]
  return [hits.length ? hits : [], line]
}

// 用法：createInterface({ input, output, prompt, completer })`;function f(){return e.jsxs("article",{children:[e.jsxs(s,{children:["上一章我们把 REPL 的输入分成了两条路：普通文本交给 ",e.jsx("code",{children:"agent.runTurn"})," 去找模型， 以 ",e.jsx("code",{children:"/"})," 开头的输入交给 ",e.jsx("code",{children:"runCommand"})," 在本地处理。这一章，我们把那条「本地路」补全—— 实现 forge 的斜杠命令系统：",e.jsx("code",{children:"/help"}),"、",e.jsx("code",{children:"/clear"}),"、",e.jsx("code",{children:"/model"}),"、",e.jsx("code",{children:"/tools"}),"、",e.jsx("code",{children:"/exit"}),"。 这是第 2 卷的收尾，做完它，forge 就从「能跑的内核」长成了「顺手的 CLI」。"]}),e.jsx("h2",{children:"一、为什么要有斜杠命令"}),e.jsx("p",{children:"想象你正在和 agent 对话。突然你想看看现在用的是哪个模型，或者想把跑歪了的会话清空重来， 又或者只是想退出。这些操作有一个共同点：它们不是「任务」，而是「控制 forge 本身」的动作。"}),e.jsxs("p",{children:["如果把「清空会话」也发给模型，模型会一脸茫然地把它当成一句话来回答——既浪费了一次 LLM 调用， 又得不到你要的效果。这类操作应该在本地",e.jsx("strong",{children:"即时、确定地"}),"完成，连网络都不该碰。"]}),e.jsxs(d,{title:"斜杠命令 = 不经过模型的本地控制面板",children:["以 ",e.jsx("code",{children:"/"})," 开头的输入，是给 forge 自己看的元命令，不是给模型的任务。 它们在本地同步执行、立即返回，既不消耗 token，也不进入对话历史。 你可以把它想成程序的「控制面板」：调参数、看状态、清场子、关电源，全在本地按钮上完成。"]}),e.jsx("h3",{children:"命令与自然语言任务的本质区别"}),e.jsx("p",{children:"把这两类输入摆在一起对比，它们几乎在每个维度上都站在对立面——这也正是「为什么要把它们彻底分流」的根据："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"斜杠命令（/clear 等）"}),e.jsx("th",{children:"自然语言任务（交给模型）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"处理在哪"}),e.jsx("td",{children:"本地，连网络都不碰"}),e.jsx("td",{children:"发往模型，走网络往返"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"结果是否确定"}),e.jsx("td",{children:"确定、可预测、每次都一样"}),e.jsx("td",{children:"概率性、每次措辞可能不同"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"延迟"}),e.jsx("td",{children:"零延迟，同步立即返回"}),e.jsx("td",{children:"秒级，要等模型生成"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"成本"}),e.jsx("td",{children:"免费，不消耗 token"}),e.jsx("td",{children:"消耗输入/输出 token"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"是否进对话历史"}),e.jsx("td",{children:"不进，纯控制操作"}),e.jsx("td",{children:"进，累积成多轮上下文"})]})]})]}),e.jsxs("p",{children:["看清这张表，「分流」的必要性就不言而喻了：用确定、免费、零延迟的本地代码去干那些",e.jsx("strong",{children:"不需要智能"}),"的活， 把昂贵、概率性的模型调用留给真正需要思考的任务。把 ",e.jsx("code",{children:"/clear"})," 发给模型，就像为了关灯而打电话问客服怎么关—— 既慢又贵还未必关得对。"]}),e.jsx("h2",{children:"二、设计：注册表 + 统一派发"}),e.jsxs("p",{children:["最容易想到的写法，是在 REPL 里堆一长串 ",e.jsx("code",{children:"if (input === '/help') ... else if (input === '/clear') ..."}),"。 能用，但每加一个命令都要去改那坨分支，而且帮助文本、命令名、执行逻辑散落各处，很难保持同步。"]}),e.jsxs("p",{children:["forge 采用更干净的做法：把每个命令抽象成一个对象，统一放进一个数组 ",e.jsx("code",{children:"COMMANDS"}),"。 每个命令自带三样东西——名字、描述、执行函数。派发时只做一件事：按名字到数组里查表，找到就执行。"]}),e.jsxs(n,{variant:"tip",title:"为什么注册表比 if-else 好",children:[e.jsx("p",{children:"「加一个命令 = 往数组里加一项」，这是注册表设计最大的好处："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"扩展是加法"}),"：新命令是 push 一个对象，不需要去碰派发逻辑，改动是局部的、零散的。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"数据即文档"}),"：",e.jsx("code",{children:"/help"})," 直接遍历 ",e.jsx("code",{children:"COMMANDS"})," 自我列举，描述永远和实现长在一起，不会漏更新。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"派发只有一处"}),"：查表逻辑写一次，所有命令共用；未知命令的友好提示也只需要处理一次。"]})]})]}),e.jsxs("p",{children:["这背后其实是个有名字的设计取向：",e.jsx("strong",{children:"用数据驱动取代控制流分支"}),"。一长串 ",e.jsx("code",{children:"if-else"}),"把「有哪些命令」编码进了",e.jsx("strong",{children:"控制流"}),"里——命令的存在性、它的行为、它的文档全揉在分支结构中， 加一个就得动一次那段逻辑（这违反「开闭原则」：对扩展开放、对修改关闭）。而注册表把「有哪些命令」变成了一份",e.jsx("strong",{children:"数据"}),"——",e.jsx("code",{children:"COMMANDS"})," 这个数组。派发逻辑写死一次后就再也不动，要变的只是数据。 软件工程里有句老话：「能用数据表达的，就别用代码表达。」斜杠命令注册表正是这句话的一个干净样本。"]}),e.jsx("h2",{children:"三、完整的命令模块"}),e.jsxs("p",{children:["下面是 forge 真实的 ",e.jsx("code",{children:"src/commands.ts"}),"，一字未改。先通读一遍，再逐段拆解。"]}),e.jsx(r,{lang:"ts",title:"src/commands.ts",code:l}),e.jsx("h3",{children:"CommandContext：把「能力」注入给命令"}),e.jsxs("p",{children:["注意 ",e.jsx("code",{children:"run"})," 拿到的第二个参数 ",e.jsx("code",{children:"ctx"}),"。命令本身并不知道「打印」要打到哪里、「退出」该怎么退， 它只声明自己需要这两种能力，由外面注入进来："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"print(s)"}),"：打印一行。命令不关心它最终是 ",e.jsx("code",{children:"console.log"}),"、写日志文件，还是塞进测试的缓冲区。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"quit()"}),"：请求退出。命令不关心退出是设标志位、调 ",e.jsx("code",{children:"rl.close()"}),"，还是 ",e.jsx("code",{children:"process.exit"}),"。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"agent"}),"：命令操作的对象本体，用来读模型、清历史、换 provider。"]})]}),e.jsxs("p",{children:["为什么不让命令直接 ",e.jsx("code",{children:"console.log"})," / ",e.jsx("code",{children:"process.exit"}),"？因为那样命令就和「具体的终端」「具体的进程」焊死了。 注入之后，命令变成纯粹的逻辑：",e.jsx("strong",{children:"解耦"}),"（命令不依赖运行环境）、",e.jsx("strong",{children:"可测试"}),"（测试时传一个收集字符串的 ",e.jsx("code",{children:"print"}),"、一个置标志的 ",e.jsx("code",{children:"quit"}),"，就能断言命令的行为，完全不碰真实终端）。"]}),e.jsxs("p",{children:["往深一层说，",e.jsx("code",{children:"CommandContext"})," 是一份精心收窄的",e.jsx("strong",{children:"能力清单"}),"：它只暴露命令",e.jsx("strong",{children:"该有"}),"的那几样能力， 多一样都不给。命令拿不到 ",e.jsx("code",{children:"process"}),"、拿不到 ",e.jsx("code",{children:"rl"}),"、拿不到文件系统句柄——它能做的事，被这个 ",e.jsx("code",{children:"ctx"}),"的形状严格框死了。这有两重好处：一是",e.jsx("strong",{children:"安全边界清晰"}),"，命令不可能越界去干它不该干的事（比如某个命令偷偷",e.jsx("code",{children:"process.exit"})," 把进程硬杀）；二是",e.jsx("strong",{children:"替换运行环境零成本"}),"，哪天把 REPL 换成 Web 后端， 只要在那边重新实现一份 ",e.jsx("code",{children:"print"}),"（推到 WebSocket）和 ",e.jsx("code",{children:"quit"}),"（关会话），同一套命令一行不改就能跑。 这正是",e.jsx("strong",{children:"依赖注入"}),"在这个小系统里的具体收益。"]}),e.jsx("h3",{children:"SlashCommand 三件套"}),e.jsx("p",{children:"每个命令就是一个对象，三个字段各司其职："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"name"}),"：命令名，用户输入 ",e.jsx("code",{children:"/name"})," 时按它匹配。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"description"}),"：一句话说明，",e.jsx("code",{children:"/help"})," 列表里展示的就是它。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"run(args, ctx)"}),"：执行函数。",e.jsx("code",{children:"args"})," 是命令名后面的参数串，",e.jsx("code",{children:"ctx"})," 是上面那套注入的能力。"]})]}),e.jsx("h3",{children:"逐个命令"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"/help"})}),"：遍历 ",e.jsx("code",{children:"COMMANDS"})," 自我列举。它不维护任何写死的清单， 列表永远等于实际注册的命令——这正是注册表「数据即文档」的体现。",e.jsx("code",{children:"padEnd(8)"})," 把命令名对齐成一列，输出更整齐。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"/clear"})}),"：调 ",e.jsx("code",{children:"ctx.agent.clearHistory()"})," 把对话历史清空， 下一句话就是全新的开始。适合上一轮跑偏、或者想换个话题省点上下文的时候。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"/model"})}),"：无参时打印 ",e.jsx("code",{children:"ctx.agent.model"})," 看当前模型； 有参时用 ",e.jsx("code",{children:"setProvider(new ClaudeProvider({ model: next }))"})," 换一个新的 provider。 这里正好呼应第 1 卷的 Provider 解耦——换模型只是替换一个 provider 实例，主循环一行都不用动。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"/tools"})}),"：遍历 ",e.jsx("code",{children:"ALL_TOOLS"})," 列出工具表，标出每个工具是 ",e.jsx("code",{children:"[只读]"})," 还是 ",e.jsx("code",{children:"[写]"}),"， 再截一段描述。让你随时知道这个 agent 手里到底握着哪些家伙。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"/exit"})}),"：调 ",e.jsx("code",{children:"ctx.quit()"}),"。命令只表达「我要退出」这个意图， 至于怎么退，是 REPL 注入的 ",e.jsx("code",{children:"quit"})," 说了算。"]})]}),e.jsx(n,{variant:"note",title:"有状态命令 vs 无状态命令",children:e.jsxs("p",{children:["细看这五个命令，它们其实分两类。",e.jsx("code",{children:"/help"})," 和 ",e.jsx("code",{children:"/tools"})," 是",e.jsx("strong",{children:"纯查询"}),"—— 只读不写，遍历点数据打出来，跑一百遍系统状态都不变。而 ",e.jsx("code",{children:"/clear"}),"、",e.jsx("code",{children:"/model"}),"、",e.jsx("code",{children:"/exit"}),"是",e.jsx("strong",{children:"有副作用"}),"的——它们改 Agent 的历史、换 provider、要求退出。区分这两类很有用： 纯查询命令天生安全，随便点；有副作用的命令则要想清楚「改了之后会怎样」。注意一个共性—— 所有副作用都",e.jsxs("strong",{children:["通过 ",e.jsx("code",{children:"ctx"})," 这个收窄的口子发生"]}),"（改历史调 ",e.jsx("code",{children:"ctx.agent.clearHistory()"}),"、 退出调 ",e.jsx("code",{children:"ctx.quit()"}),"），命令自己不直接碰外部世界。这让「这个命令会动什么」一目了然，审计起来也方便。"]})}),e.jsx("h3",{children:"分流与派发"}),e.jsx("p",{children:"模块底部两个函数完成「认出命令」和「执行命令」："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"isCommand(input)"}),"：用 ",e.jsx("code",{children:"startsWith('/')"})," 判断这行输入是不是斜杠命令。REPL 靠它分流。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"runCommand(input, ctx)"}),"：先 ",e.jsx("code",{children:"slice(1)"})," 去掉开头的 ",e.jsx("code",{children:"/"}),"，再按空白切成",e.jsx("code",{children:"[名字, ...参数]"}),"；拿名字去 ",e.jsx("code",{children:"COMMANDS"})," 里 ",e.jsx("code",{children:"find"}),"。 命中就把剩下的参数 ",e.jsx("code",{children:"join(' ')"})," 拼回字符串交给 ",e.jsx("code",{children:"run"}),"；没命中就给一句友好提示，引导用户去看 ",e.jsx("code",{children:"/help"}),"， 而不是静默失败。"]})]}),e.jsx("h3",{children:"命令解析：这套切法的边界在哪"}),e.jsxs("p",{children:[e.jsx("code",{children:"runCommand"})," 的第一行就是整个解析的核心，简单到只有一句，但它划定的「能解析什么、不能解析什么」值得说清："]}),e.jsx(r,{lang:"ts",title:"命令解析（runCommand 首行）",code:x}),e.jsxs("p",{children:["这套解析",e.jsx("strong",{children:"故意做得很薄"}),"：按空白 ",e.jsx("code",{children:"split"}),"，第一段当命令名，剩下的 ",e.jsx("code",{children:"join"})," 回原样交给命令。 它",e.jsx("strong",{children:"不识别引号"}),"（",e.jsx("code",{children:'/cmd "a b"'})," 会被切成 ",e.jsx("code",{children:"a"})," 和 ",e.jsx("code",{children:"b"})," 两段），",e.jsxs("strong",{children:["不解析 ",e.jsx("code",{children:"--flag"})," 选项"]}),"，",e.jsx("strong",{children:"不做转义"}),"。这不是偷懒，是有意的设计取舍—— 派发层只负责「认出是哪个命令、把后面整块原样递过去」，",e.jsx("strong",{children:"怎么理解参数是每个命令自己的事"}),"。 像 ",e.jsx("code",{children:"/model"})," 直接 ",e.jsx("code",{children:"args.trim()"})," 当模型名用，根本不需要花哨的参数解析。"]}),e.jsxs("p",{children:["这个边界的好处是：派发层永远不变，复杂度被推到真正需要它的少数命令里。哪天某个命令确实要处理带空格的参数或选项， 它在自己的 ",e.jsx("code",{children:"run"})," 里引入一个小解析器就行，不会污染所有其他命令。",e.jsx("strong",{children:"把简单留在公共层、把复杂关进局部"}),"， 是这类可扩展系统反复出现的智慧。还有一个常被忽略的边界：",e.jsx("code",{children:"find"})," 用的是",e.jsx("strong",{children:"精确匹配"}),"命令名， 所以 ",e.jsx("code",{children:"/MODEL"}),"、",e.jsx("code",{children:"/mod"})," 都不会命中——大小写敏感、不做前缀模糊。这是有意为之， 确定性比「猜用户想要哪个」更重要，猜错的代价（比如把 ",e.jsx("code",{children:"/clear"})," 猜成别的）可能很难受。"]}),e.jsx(n,{variant:"note",title:"未知命令为什么不能静默失败",children:e.jsxs("p",{children:[e.jsx("code",{children:"runCommand"})," 在 ",e.jsx("code",{children:"find"})," 不到时，没有默默什么都不做，而是打一句",e.jsx("code",{children:"未知命令 /xxx，输入 /help 查看全部"}),"。这是交互式工具的基本素养：",e.jsx("strong",{children:"用户每一次输入都该得到反馈"}),"。 静默失败是最坏的体验——用户敲了 ",e.jsx("code",{children:"/quit"}),"（其实命令叫 ",e.jsx("code",{children:"/exit"}),"），程序毫无反应， 他会以为是不是卡了、是不是没生效，反复试、越试越慌。一句友好的「没这个命令，去看 /help」既纠正了错误、 又指明了出路，把一次挫败变成一次引导。注意它还",e.jsx("strong",{children:"没有把这行误输入发给模型"}),"—— 因为 ",e.jsx("code",{children:"isCommand"})," 已经认定它是命令（以 ",e.jsx("code",{children:"/"})," 开头），分流早已发生，这里只是命令内部没找到匹配项。"]})}),e.jsx("h2",{children:"四、它怎么接进 REPL"}),e.jsxs("p",{children:["回到上一章的 ",e.jsx("code",{children:"repl.ts"}),"。读到一行输入后，先用 ",e.jsx("code",{children:"isCommand"})," 分流； 是命令，就地构造 ",e.jsx("code",{children:"CommandContext"})," 调 ",e.jsx("code",{children:"runCommand"}),"，处理完直接进入下一轮，根本不碰 ",e.jsx("code",{children:"agent.runTurn"}),"。 下面这段就是那个分支，逐字摘录："]}),e.jsx(r,{lang:"ts",title:"src/repl.ts（节选）",code:o}),e.jsxs("p",{children:["看注入的两样能力怎么落地：",e.jsx("code",{children:"print"})," 就是 ",e.jsx("code",{children:"console.log"}),"，把字符串打到终端；",e.jsx("code",{children:"quit"})," 把外层的 ",e.jsx("code",{children:"quitting"})," 标志置真、并 ",e.jsx("code",{children:"rl.close()"})," 关掉 readline。 随后 ",e.jsx("code",{children:"if (quitting) break"})," 跳出主循环，否则 ",e.jsx("code",{children:"rl.prompt()"})," 重新出提示符、",e.jsx("code",{children:"continue"})," 进入下一轮。命令系统对主循环的侵入，就只有这么一小块。"]}),e.jsx("h2",{children:"五、命令与 LLM 路由的边界：谁先看到输入"}),e.jsxs("p",{children:["这一章和上一章合起来，其实定义了 forge 最关键的一条",e.jsx("strong",{children:"路由规则"}),"：每一行输入，先问 ",e.jsx("code",{children:"isCommand"}),"， 是命令走本地、不是命令才交给模型。这个顺序不能反，而且这条边界划在哪里，是个值得深想的设计问题。"]}),e.jsxs("p",{children:["forge 选的是",e.jsx("strong",{children:"语法路由"}),"——靠一个显式的 ",e.jsx("code",{children:"/"})," 前缀来区分意图，规则是机械的、零歧义的、零成本的。 另一条路是",e.jsx("strong",{children:"语义路由"}),"：不要前缀，让模型自己判断「用户这句话是想执行控制操作，还是想交代任务」。 两者各有适用场景，但对一个命令行工具来说，语法路由几乎总是更好的选择："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"语法路由（/ 前缀）"}),e.jsx("th",{children:"语义路由（让模型判断）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"判断成本"}),e.jsxs("td",{children:["一次 ",e.jsx("code",{children:"startsWith('/')"}),"，免费即时"]}),e.jsx("td",{children:"得先调一次模型来分类，慢且费 token"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"确定性"}),e.jsx("td",{children:"100% 确定，规则写死"}),e.jsx("td",{children:"概率性，可能把任务误判成命令、反之亦然"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"用户心智"}),e.jsx("td",{children:"清晰：打 / 就是控制，否则是任务"}),e.jsx("td",{children:"模糊：「清空一下」到底算不算命令？"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"可发现性"}),e.jsx("td",{children:"/help 一列就全清楚"}),e.jsx("td",{children:"用户得猜哪些话会被当成控制操作"})]})]})]}),e.jsx(d,{title:"确定性的事交给代码，含糊的事才交给模型",children:e.jsxs("p",{children:["这是贯穿整个 Agent 工程的一条准绳。「清空历史」「换模型」「退出」这些意图",e.jsx("strong",{children:"本身就清晰确定"}),"， 根本不需要语言理解——用一个 ",e.jsx("code",{children:"/"})," 前缀让用户显式声明，比花一次模型调用去「猜」要又快又准又便宜。 模型的智能很宝贵，应该花在",e.jsx("strong",{children:"真正含糊、真正需要理解和推理"}),"的地方（「帮我把这个函数重构得更易读」）， 而不是浪费在「这句话是不是想退出」这种本可以零成本判定的事上。把确定的留给代码、把含糊的留给模型—— 这条边界划得对，整个系统才会既快又省又可靠。"]})}),e.jsx("h2",{children:"六、跑起来看看"}),e.jsx(i,{title:"一次控制台交互",children:e.jsx(r,{lang:"text",title:"终端会话",code:t})}),e.jsxs("p",{children:["整段交互里，没有一次走到模型：",e.jsx("code",{children:"/help"})," 现列命令、",e.jsx("code",{children:"/model"})," 即时显示和切换、",e.jsx("code",{children:"/clear"})," 一句话清空、",e.jsx("code",{children:"/tools"})," 摊开工具表、",e.jsx("code",{children:"/exit"})," 干净退出。 全是本地的、确定的、零延迟的——这正是斜杠命令该有的手感。"]}),e.jsx("h2",{children:"七、可发现性：补全与帮助"}),e.jsxs("p",{children:["一套命令系统好不好用，一半看功能，另一半看",e.jsx("strong",{children:"用户能不能发现和记住它们"}),"。forge 已经有了 ",e.jsx("code",{children:"/help"}),"—— 这是可发现性的底线，一行就把所有命令连同描述列出来。但还有一个体验上的大提升点：",e.jsx("strong",{children:"Tab 补全"}),"。 用户敲半个 ",e.jsx("code",{children:"/mo"})," 按下 Tab，自动补成 ",e.jsx("code",{children:"/model"}),"，既省键又顺手地告诉用户「有这么个命令」。"]}),e.jsxs("p",{children:["好消息是，因为命令是",e.jsx("strong",{children:"注册表里的数据"}),"，补全器几乎不用额外信息——直接拿 ",e.jsx("code",{children:"COMMANDS"}),"按前缀筛一遍就行。",e.jsx("code",{children:"node:readline"})," 的 ",e.jsx("code",{children:"createInterface"})," 正好接受一个 ",e.jsx("code",{children:"completer"})," 选项："]}),e.jsx(r,{lang:"ts",title:"给 readline 加上命令补全（示意）",code:h}),e.jsxs("p",{children:[e.jsx("code",{children:"completer"})," 的约定很简单：拿到当前这行 ",e.jsx("code",{children:"line"}),"，返回一个二元组",e.jsx("code",{children:"[匹配列表, 被匹配的原串]"}),"，readline 会据此决定按 Tab 时怎么补。我们的实现只在 ",e.jsx("code",{children:"/"}),"开头时才工作：取出前缀，从 ",e.jsx("code",{children:"COMMANDS"})," 里挑出所有 ",e.jsx("code",{children:"name"})," 以该前缀打头的，作为候选返回。 这里再次兑现了注册表「数据即文档」的红利——",e.jsx("strong",{children:"新加的命令自动就能被补全"}),"，因为补全器读的就是那同一份",e.jsx("code",{children:"COMMANDS"}),"，你不用在任何别处再登记一次。",e.jsx("code",{children:"/help"})," 自我列举、补全自动覆盖、描述长在命令上， 三件事共享同一份真相，永远不会各说各话。"]}),e.jsx("h2",{children:"八、它天生就为扩展而生"}),e.jsxs(n,{variant:"note",title:"后续卷会往里加更多命令",children:[e.jsxs("p",{children:["这套系统的形状决定了它好扩展。后面几卷我们还会陆续往 ",e.jsx("code",{children:"COMMANDS"})," 里加："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"/resume"}),"：恢复之前保存的会话，接着之前的上下文继续聊。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"/cost"}),"：查看本次会话累计消耗的 token 与花费。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"/plan"}),"：切换到计划模式，让 agent 先规划再动手。"]})]}),e.jsx("p",{children:"每一个都只是往数组里 push 一个对象，派发逻辑、REPL 主循环全都不用动——因为它本来就是为「加一行就扩展」设计的。"})]}),e.jsxs("p",{children:["值得点一句：这套注册表的边界也有它「不该越」的地方。斜杠命令适合做",e.jsx("strong",{children:"确定的、本地的、轻量的控制操作"}),"； 一旦某个「命令」开始需要语言理解、需要多步推理、需要调工具——那它就不该是斜杠命令，而该回到自然语言、交给模型。 比如不要妄图做一个 ",e.jsx("code",{children:"/refactor <描述>"})," 去硬解析用户的重构意图，那是模型的活。把命令系统克制在它擅长的范围内， 它才一直是那个「又快又确定的控制面板」，而不会膨胀成一个蹩脚的、半吊子的自然语言解析器。"]}),e.jsx("h2",{children:"第 2 卷小结"}),e.jsx("p",{children:"三章走下来，forge 完成了一次从「内核」到「产品」的蜕变：第 1 章把一次性脚本变成可交互的 REPL 循环； 第 2 章接上流式输出，让回答逐字蹦出来；这一章补齐了本地控制命令，让你能在不打断对话的前提下操控 forge 自己。"}),e.jsx(d,{title:"从「能跑的内核」到「好用的 CLI」",children:"第 1 卷给了 forge 一颗能跑的心脏；第 2 卷给它穿上了交互的外衣——可对话、能流式、有控制面板。 到此它已经是个用起来顺手的命令行 agent 了。但「顺手」还不等于「敢用」：下一卷，我们给它加上安全与人在回路—— 工具权限、危险操作的人工确认、操作审计，让你敢把真实的文件系统和 shell 交到它手里。"}),e.jsx(c,{points:["斜杠命令是「控制 forge 本身」的本地元命令：以 / 开头，不发给模型、不进对话历史、不消耗 token。它和自然语言任务在处理位置/确定性/延迟/成本/是否进历史上几乎全维度对立。","设计成「注册表 + 统一派发」：COMMANDS 数组里每项有 name/description/run，加命令就是 push 一项，派发只查表一处。本质是「用数据驱动取代控制流分支」，遵循开闭原则——派发逻辑写死后不再改，要变的只是数据。","CommandContext 把 print/quit/agent 作为收窄的能力清单注入给命令，命令拿不到 process/rl/fs，越界不了——既划清安全边界，又让换运行环境（如换成 Web 后端）时命令零改动。解耦且可测试。","isCommand 用 startsWith('/') 分流，runCommand 解析「/名字 参数...」：按空白切、名字第一段、其余原样 join。解析故意做得薄（不识别引号/flag/转义、精确大小写匹配命令名），复杂度推给真正需要的命令自己处理。未命中给友好提示，绝不静默失败。","五个命令分纯查询（/help、/tools，只读安全）与有副作用（/clear、/model、/exit）两类，所有副作用都经 ctx 这个口子发生；/model 换 provider 呼应 Provider 解耦。","命令与 LLM 的路由边界：forge 用语法路由（/ 前缀，免费/确定/清晰）而非语义路由（让模型猜，慢/概率性/含糊）。准绳是「确定的事交给代码、含糊的事才交给模型」——把宝贵的模型智能留给真正需要理解推理的任务。","可发现性靠 /help 自我列举 + Tab 补全（readline 的 completer 直接按前缀筛 COMMANDS）：注册表「数据即文档」让新命令自动被列出、被补全，三处共享同一份真相不会脱节。","这套系统为扩展而生，后续卷会加 /resume、/cost、/plan；但要克制——需要语言理解/多步推理的意图不该做成命令，那是模型的活。第 2 卷至此把 forge 从内核打磨成了好用的 CLI。"]})]})}export{f as default};
