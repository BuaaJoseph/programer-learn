import{j as e}from"./index-Bs06kW3a.js";import{L as r,S as n}from"./Summary-CLAN1smq.js";import{K as c}from"./KeyIdea-iVczm-9t.js";import{C as t}from"./Callout-BCaSeUge.js";import{C as s}from"./CodeBlock-BUaxuxwl.js";import{E as o}from"./Example-XOtO_AMb.js";const i=`class Person {
  // 实例字段：写在类体里，每个实例各有一份
  species = 'human'

  // 构造器：new 时被调用，用来初始化实例
  constructor(name) {
    this.name = name
  }

  // 方法：注意它其实挂在 Person.prototype 上，被所有实例共享
  greet() {
    return 'Hi, I am ' + this.name
  }
}

const p = new Person('Ada')
typeof Person                                  // 'function'（class 本质是函数）
p.greet()                                      // 'Hi, I am Ada'
Object.getPrototypeOf(p) === Person.prototype  // true
p.hasOwnProperty('greet')                      // false（greet 在原型上，不是自有）`,d=`class Counter {
  static label = 'a counter'   // 静态字段：挂在类上，不在实例上
  #count = 0                   // 私有字段：以 # 开头，外部无法访问

  static create() {            // 静态方法：通过 Counter.create() 调用
    return new Counter()
  }

  inc() { this.#count++ }      // 实例方法里可以读写私有字段

  get value() { return this.#count }   // getter：像读属性一样取值
  set value(v) {                       // setter：像写属性一样赋值
    if (v < 0) throw new Error('不能为负')
    this.#count = v
  }
}

const c = Counter.create()
c.inc()
c.value            // 1（走 getter，不用写括号）
c.value = 10       // 走 setter
Counter.label      // 'a counter'（静态成员通过类名访问）
// c.#count        // 语法错误：私有字段在类外不可访问`,l=`class Animal {
  constructor(name) {
    this.name = name
  }
  speak() {
    return this.name + ' makes a sound'
  }
}

class Dog extends Animal {
  constructor(name, breed) {
    super(name)            // 必须先调 super()，才能使用 this
    this.breed = breed
  }
  speak() {                // 覆盖父类方法
    // super.speak() 调到父类的同名方法
    return super.speak() + ' (woof)'
  }
}

const d = new Dog('Rex', 'Husky')
d.speak()                  // 'Rex makes a sound (woof)'
d instanceof Dog           // true
d instanceof Animal        // true（沿原型链能找到 Animal.prototype）`,h=`// 上面的 Animal / Dog 用「function + prototype」写，等价如下：
function Animal(name) {
  this.name = name
}
Animal.prototype.speak = function () {
  return this.name + ' makes a sound'
}

function Dog(name, breed) {
  Animal.call(this, name)            // 等价于 super(name)
  this.breed = breed
}
// 把 Dog.prototype 的原型链接到 Animal.prototype（等价于 extends）
Dog.prototype = Object.create(Animal.prototype)
Dog.prototype.constructor = Dog
Dog.prototype.speak = function () {
  // 等价于 super.speak()
  return Animal.prototype.speak.call(this) + ' (woof)'
}

const d = new Dog('Rex', 'Husky')
d.speak()   // 'Rex makes a sound (woof)' —— 和 class 版完全一致`,a=`// instanceof 的本质：检查「右侧函数的 prototype」是否出现在
// 「左侧对象的原型链」上。可以手写出它的逻辑：
function myInstanceof(obj, Ctor) {
  let proto = Object.getPrototypeOf(obj)
  const target = Ctor.prototype
  while (proto !== null) {
    if (proto === target) return true   // 在链上找到了
    proto = Object.getPrototypeOf(proto)
  }
  return false                          // 找到 null 都没有
}

myInstanceof(d, Dog)      // true
myInstanceof(d, Animal)   // true
myInstanceof(d, Array)    // false`,x=`// 工厂函数 + 闭包：不靠 class / this，用闭包封装私有状态
function createCounter() {
  let count = 0                       // 闭包变量，外部完全访问不到
  return {
    inc() { count++ },
    get value() { return count },
  }
}

const c = createCounter()
c.inc()
c.value   // 1
// 没有 new、没有 this、没有原型链——简单数据 + 强封装时很顺手`;function y(){return e.jsxs("article",{children:[e.jsxs(r,{children:["ES2015 引入的 ",e.jsx("code",{children:"class"})," 关键字让 JavaScript 终于有了「看起来像传统面向对象」的写法。 但请记住一句话贯穿全章：",e.jsx("strong",{children:"class 不是新的对象模型，它只是上一章原型继承的语法糖"}),"。 你写的 class，引擎在底层仍然翻译成函数、",e.jsx("code",{children:"prototype"})," 和原型链。这一章我们逐个拆解 class 的每个部件，并始终把它和等价的 function 写法对照，让你既会用 class，也看穿它的本质。"]}),e.jsx("h2",{children:"一、class 是原型继承的语法糖"}),e.jsxs("p",{children:["第一个要打破的错觉：",e.jsx("code",{children:"class"})," 并没有引入新的类型。",e.jsx("code",{children:"typeof Person"})," 的结果是",e.jsx("code",{children:"'function'"}),"——class 声明本质上就是创建了一个函数。类里定义的方法会被自动挂到这个 函数的 ",e.jsx("code",{children:"prototype"})," 上，实例通过原型链共享它们。一切都还是上一章那套机制。"]}),e.jsx(s,{lang:"js",title:"一个最朴素的 class",code:i}),e.jsxs(c,{children:[e.jsx("code",{children:"class"})," = ",e.jsx("strong",{children:"更顺手的 function + prototype"}),"。它把「设置 prototype、挂方法、 链接继承」这些容易写错的样板代码，封装成了清晰的语法。理解 class 的最佳方式，就是随时能在 脑子里把它翻译回函数写法。"]}),e.jsx("h2",{children:"二、class 的各个部件"}),e.jsx("p",{children:"一个完整的 class 可以包含下面这些成员，逐个来看它们的语义与落点："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"构造器 constructor"}),"：",e.jsx("code",{children:"new"})," 时执行，用来初始化实例的自有属性。一个类最多一个。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"实例字段"}),"：直接写在类体里的 ",e.jsx("code",{children:"x = 1"}),"，每个实例",e.jsx("strong",{children:"各有一份"}),"，落在实例自身上。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"方法"}),"：写法像 ",e.jsxs("code",{children:["greet() ","{...}"]}),"，但实际",e.jsx("strong",{children:"挂在 prototype 上"}),"，被所有实例共享。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"静态成员 static"}),"：",e.jsx("code",{children:"static x"})," / ",e.jsx("code",{children:"static fn()"}),"，挂在",e.jsx("strong",{children:"类本身"}),"上，通过类名访问，常用于工具方法或工厂。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"getter / setter"}),"：用 ",e.jsx("code",{children:"get"})," / ",e.jsx("code",{children:"set"})," 定义访问器，让「方法调用」看起来像「读写属性」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"私有字段 #x"}),"：以 ",e.jsx("code",{children:"#"})," 开头，",e.jsx("strong",{children:"只能在类内部访问"}),"，是语言级别的真正私有，外部连读都读不到。"]})]}),e.jsx(s,{lang:"js",title:"静态成员、私有字段、getter / setter",code:d}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"成员"}),e.jsx("th",{children:"落在哪里"}),e.jsx("th",{children:"如何访问"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsxs("td",{children:["实例字段 ",e.jsx("code",{children:"x = 1"})]}),e.jsx("td",{children:"每个实例自身"}),e.jsx("td",{children:e.jsx("code",{children:"instance.x"})})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["方法 ",e.jsx("code",{children:"fn()"})]}),e.jsxs("td",{children:["类的 ",e.jsx("code",{children:"prototype"})]}),e.jsxs("td",{children:[e.jsx("code",{children:"instance.fn()"}),"（沿原型链）"]})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["静态成员 ",e.jsx("code",{children:"static fn()"})]}),e.jsx("td",{children:"类本身"}),e.jsx("td",{children:e.jsx("code",{children:"ClassName.fn()"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"getter / setter"}),e.jsxs("td",{children:[e.jsx("code",{children:"prototype"})," 上的访问器"]}),e.jsxs("td",{children:[e.jsx("code",{children:"instance.value"}),"（无括号）"]})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["私有字段 ",e.jsx("code",{children:"#x"})]}),e.jsx("td",{children:"实例自身（私有槽）"}),e.jsxs("td",{children:["仅类内部 ",e.jsx("code",{children:"this.#x"})]})]})]})]}),e.jsx(t,{variant:"warn",title:"getter / setter 不是普通属性",children:e.jsxs("p",{children:["访问器看起来像在读写一个字段，实际每次都在调用函数。所以 setter 里可以做校验 （例子里负数直接抛错），getter 里可以做派生计算。但也要小心：在 getter 里写出无限递归 （比如 ",e.jsxs("code",{children:["get value() ","{ return this.value }"]}),"）会直接把栈撑爆。"]})}),e.jsx("h2",{children:"三、extends 与 super"}),e.jsxs("p",{children:[e.jsx("code",{children:"extends"})," 建立继承关系，",e.jsx("code",{children:"super"})," 则是「访问父类」的通道。它有两种用法： 在构造器里 ",e.jsx("code",{children:"super(...)"})," 调用",e.jsx("strong",{children:"父类构造函数"}),"；在方法里",e.jsx("code",{children:"super.method(...)"})," 调用",e.jsx("strong",{children:"父类的同名方法"}),"。"]}),e.jsx(s,{lang:"js",title:"继承：Animal 与 Dog",code:l}),e.jsx(t,{variant:"warn",title:"子类构造器里 super() 必须先调用",children:e.jsxs("p",{children:["在派生类（写了 ",e.jsx("code",{children:"extends"})," 的类）的 ",e.jsx("code",{children:"constructor"})," 里，",e.jsxs("strong",{children:["访问",e.jsx("code",{children:"this"})," 之前必须先调用 ",e.jsx("code",{children:"super()"})]}),"，否则直接报",e.jsx("code",{children:"ReferenceError"}),"。原因是：派生类的实例对象由父类构造链负责创建，",e.jsx("code",{children:"super()"})," 没跑完，",e.jsx("code",{children:"this"})," 还不存在。"]})}),e.jsx("h2",{children:"四、与等价的 function + prototype 写法对照"}),e.jsxs("p",{children:["把上面的 ",e.jsx("code",{children:"Animal"})," / ",e.jsx("code",{children:"Dog"})," 用上一章的原型写法重写一遍，你会发现一一对应：",e.jsx("code",{children:"super(name)"})," 就是 ",e.jsx("code",{children:"Animal.call(this, name)"}),"；",e.jsx("code",{children:"extends"})," 就是 ",e.jsx("code",{children:"Dog.prototype = Object.create(Animal.prototype)"}),"；",e.jsx("code",{children:"super.speak()"})," 就是 ",e.jsx("code",{children:"Animal.prototype.speak.call(this)"}),"。"]}),e.jsx(s,{lang:"js",title:"class 版的等价 function 写法",code:h}),e.jsx(o,{title:"对照着看，你就懂了 super 为什么要 .call(this)",children:e.jsxs("p",{children:["父类方法里用到了 ",e.jsx("code",{children:"this.name"}),"。如果只写 ",e.jsx("code",{children:"Animal.prototype.speak()"}),"，",e.jsx("code",{children:"this"})," 就不是当前的 Dog 实例了。必须 ",e.jsx("code",{children:".call(this)"})," 把 ",e.jsx("code",{children:"this"}),"显式传进去。class 的 ",e.jsx("code",{children:"super.speak()"})," 替你自动做了这件事——这正是语法糖的价值： 省掉容易写错的细节。"]})}),e.jsx("h2",{children:"五、instanceof 的原理"}),e.jsxs("p",{children:[e.jsx("code",{children:"obj instanceof Ctor"})," 判断的不是「obj 是不是由 Ctor 造的」，而是更底层的一件事：",e.jsxs("strong",{children:[e.jsx("code",{children:"Ctor.prototype"})," 是否出现在 ",e.jsx("code",{children:"obj"})," 的原型链上"]}),"。这也是为什么",e.jsx("code",{children:"d instanceof Animal"})," 为真——虽然 d 是 ",e.jsx("code",{children:"new Dog"})," 造的，但 Animal.prototype 就在它的原型链上。"]}),e.jsx(s,{lang:"js",title:"手写 instanceof 看清它的逻辑",code:a}),e.jsxs("p",{children:["因为它查的是原型链，所以 ",e.jsx("code",{children:"instanceof"})," 会受原型链被改动的影响，跨 iframe / 跨 realm 时也可能失灵（不同窗口有各自的 ",e.jsx("code",{children:"Array.prototype"}),"）。判断数组优先用",e.jsx("code",{children:"Array.isArray()"}),"，判断更宽泛的类型用 ",e.jsx("code",{children:"typeof"})," 或鸭子类型更稳。"]}),e.jsx("h2",{children:"六、何时用 class，何时用工厂函数 / 闭包"}),e.jsxs("p",{children:["class 不是唯一的「组织对象」的方式。当你只需要封装一点私有状态、不需要继承、也不在乎",e.jsx("code",{children:"this"})," 的种种坑时，",e.jsx("strong",{children:"工厂函数 + 闭包"}),"往往更简单、更安全。"]}),e.jsx(s,{lang:"js",title:"工厂函数 + 闭包：另一种封装方式",code:x}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"场景"}),e.jsx("th",{children:"推荐"}),e.jsx("th",{children:"理由"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"有明确继承层级、要造大量实例、方法需共享"}),e.jsx("td",{children:"class"}),e.jsx("td",{children:"原型共享省内存，继承语义清晰"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"只要封装私有状态、无继承、量不大"}),e.jsx("td",{children:"工厂 + 闭包"}),e.jsx("td",{children:"无 this 之坑，私有性靠闭包天然保证"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"纯数据、无行为"}),e.jsx("td",{children:"对象字面量"}),e.jsx("td",{children:"最轻量，不必上 class"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"需要明确指定原型"}),e.jsx("td",{children:"Object.create"}),e.jsx("td",{children:"对原型链有最直接的控制"})]})]})]}),e.jsx(t,{variant:"tip",title:"class 的方法与 this",children:e.jsxs("p",{children:["class 方法里的 ",e.jsx("code",{children:"this"})," 取决于",e.jsx("strong",{children:"怎么被调用"}),"，而非定义在哪。把方法 单独取出来当回调（如 ",e.jsx("code",{children:"setTimeout(obj.fn, 0)"}),"）会丢失 ",e.jsx("code",{children:"this"}),"。解决办法： 用箭头函数包一层，或在构造器里 ",e.jsx("code",{children:"this.fn = this.fn.bind(this)"}),"，或干脆把方法写成 类字段里的箭头函数。闭包写法则天然没有这个烦恼。"]})}),e.jsx("h2",{children:"七、与 TypeScript 的衔接"}),e.jsxs("p",{children:["在 TypeScript 里，class 这一套被进一步增强：可以给字段和方法标注类型，用",e.jsx("code",{children:"public"})," / ",e.jsx("code",{children:"private"})," / ",e.jsx("code",{children:"protected"})," 访问修饰符，配合",e.jsx("code",{children:"interface"})," 与 ",e.jsx("code",{children:"implements"})," 约束结构——但运行时落地的，",e.jsx("strong",{children:"依然是这一章 讲的原型继承"}),"，TS 只是在编译期多了一层类型检查。"]}),e.jsx(t,{variant:"tip",children:"到这里，「对象与原型」这一卷的核心就通了：对象靠原型链共享与查找，class 是它的语法糖， 继承不过是把父类原型串进子类原型链。带着这套底层模型，你读任何 JS / TS 的面向对象代码 都不会再有黑盒。"}),e.jsx(n,{points:['class 是原型继承的语法糖：typeof Class === "function"，方法自动挂到 prototype 上，本质仍是上一章那套机制。',"class 成员：constructor 初始化实例、实例字段在实例自身、方法在 prototype、static 在类本身、getter/setter 是访问器、#x 是语言级私有。","extends 建立继承，super(...) 调父构造、super.method() 调父方法；派生类构造器里访问 this 前必须先调 super()。","class 可一一翻译成 function + prototype：super 等价 Parent.call(this) / Parent.prototype.m.call(this)，extends 等价 Object.create。","instanceof 的本质是查右侧 prototype 是否在左侧对象的原型链上，因此会受原型改动与跨 realm 影响。","有继承层级、需共享方法用 class；仅需封装私有状态用工厂 + 闭包；纯数据用字面量。TS 在此基础上加类型与访问修饰符，运行时仍是原型继承。"]})]})}export{y as default};
