import{j as e}from"./index-BdVncPlI.js";import{L as r,S as c}from"./Summary-Baiwq3-G.js";import{K as n}from"./KeyIdea-Cnr-5ipR.js";import{C as s}from"./Callout-BRUKkrb4.js";import{C as t}from"./CodeBlock-DCdshbU5.js";import{E as i}from"./Example-phQ905Fb.js";const d=`import { useEffect } from 'react'

function Title({ name }) {
  // 渲染提交到 DOM 之后，React 才执行这个 effect，把组件状态同步到外部世界（document.title）
  useEffect(() => {
    document.title = \`欢迎，\${name}\`
  }, [name]) // 依赖数组：只有 name 变化时才重新同步

  return <h1>你好，{name}</h1>
}`,o=`// 形态一：不传依赖数组——每次渲染后都执行（几乎总是错的，容易造成死循环）
useEffect(() => {
  console.log('每次渲染都跑')
})

// 形态二：空数组——只在组件挂载后执行一次，卸载时清理一次
useEffect(() => {
  console.log('只在挂载时跑一次')
}, [])

// 形态三：有依赖——挂载时执行，之后任一依赖变化就重新执行
useEffect(() => {
  console.log('roomId 变了就重新连接', roomId)
}, [roomId])`,l=`function ChatRoom({ roomId }) {
  useEffect(() => {
    const connection = createConnection(roomId)
    connection.connect()

    // 返回的函数就是"清理函数"：
    // 1) 组件卸载前会调用一次
    // 2) 依赖（roomId）变化、effect 即将重新执行前，也会先用"旧值"调用一次清理
    return () => {
      connection.disconnect()
    }
  }, [roomId])

  return <p>已连接到房间 {roomId}</p>
}

// roomId 从 "general" 变成 "music" 时的执行顺序：
// 用 general 断开旧连接（清理）→ 用 music 建立新连接（重跑 effect）`,f=`import { useState, useEffect } from 'react'

function WindowWidth() {
  const [width, setWidth] = useState(window.innerWidth)

  useEffect(() => {
    const onResize = () => setWidth(window.innerWidth)
    window.addEventListener('resize', onResize)

    // 必须清理：否则组件卸载后监听器还在，旧的 setWidth 还会被调用，造成内存泄漏
    return () => window.removeEventListener('resize', onResize)
  }, []) // 监听器只需建立一次

  return <p>窗口宽度：{width}px</p>
}`,h=`function SearchResults({ query }) {
  const [data, setData] = useState(null)

  useEffect(() => {
    let ignore = false // 标记本次 effect 是否已经"过期"

    fetchResults(query).then((result) => {
      // query 变化导致 effect 重跑时，旧 effect 的清理会把它的 ignore 设为 true，
      // 于是这个慢到达的旧响应就被丢弃，不会覆盖新结果
      if (!ignore) setData(result)
    })

    return () => {
      ignore = true
    }
  }, [query])

  return <pre>{JSON.stringify(data)}</pre>
}`,x=`function SearchResults({ query }) {
  const [data, setData] = useState(null)

  useEffect(() => {
    const controller = new AbortController()

    fetch(\`/api/search?q=\${query}\`, { signal: controller.signal })
      .then((r) => r.json())
      .then(setData)
      .catch((err) => {
        if (err.name !== 'AbortError') throw err // 主动取消不算错误
      })

    // 清理时直接中止上一个请求，比 ignore 标志更彻底（连网络请求都取消了）
    return () => controller.abort()
  }, [query])

  return <pre>{JSON.stringify(data)}</pre>
}`,j=`// 反例：用 effect 同步"派生状态"——多余且容易出 bug
function Form({ firstName, lastName }) {
  const [fullName, setFullName] = useState('')
  useEffect(() => {
    setFullName(firstName + ' ' + lastName) // 多触发一次渲染，纯属浪费
  }, [firstName, lastName])
}

// 正解：渲染期间直接计算即可，根本不需要 state，也不需要 effect
function Form({ firstName, lastName }) {
  const fullName = firstName + ' ' + lastName
}

// 反例：把"事件逻辑"放进 effect
useEffect(() => {
  if (submitted) sendRequest() // 提交是用户事件，应该写在事件处理函数里
}, [submitted])

// 正解：直接写在 onSubmit 里
function handleSubmit() {
  sendRequest()
}`,a=`// useEffect：在浏览器把变更"绘制到屏幕之后"异步执行——不阻塞绘制，是默认选择
useEffect(() => {
  // 这里若改 DOM 尺寸/位置，用户可能先看到旧帧、再看到新帧（闪烁）
})

// useLayoutEffect：在 DOM 变更之后、浏览器"绘制之前"同步执行——会阻塞绘制
useLayoutEffect(() => {
  // 适合：读取布局尺寸并立刻调整，避免用户看到中间状态（如测量后定位 tooltip）
  const rect = ref.current.getBoundingClientRect()
  setPosition(rect.top)
})`;function S(){return e.jsxs("article",{children:[e.jsxs(r,{children:[e.jsx("code",{children:"useEffect"}),' 是最常用也最常被误解的 Hook。很多人把它当成"生命周期回调" 来写，结果踩满了坑。这一章我们换个心智模型：effect 的本质是',e.jsx("strong",{children:'"在渲染提交后，把组件与某个外部系统同步"'}),'。理解了这一点， 依赖数组、清理函数、竞态、StrictMode 双跑，乃至"你可能并不需要 Effect"这条建议， 就都顺理成章了。']}),e.jsx("h2",{children:'一、effect 不是生命周期回调，而是"同步外部世界"'}),e.jsxs(n,{children:['别再问"组件挂载时该做什么、更新时该做什么"。换成问：',e.jsx("strong",{children:'"有哪个外部系统需要和我的组件状态保持同步？"'}),"useEffect 就是用来描述这种同步关系的——React 会在渲染提交后运行它，让外部世界 （DOM、订阅、网络、定时器）追上组件当前的状态。"]}),e.jsxs("p",{children:['所谓"外部系统"，是指任何不受 React 渲染流程管理的东西：浏览器的',e.jsx("code",{children:"document.title"}),'、一个 WebSocket 连接、一个定时器、第三方图表库的实例、 浏览器 API 的事件监听……渲染本身应当是"纯"的，不该碰这些；碰它们的活儿， 就交给 effect 在渲染提交之后做。']}),e.jsx(t,{lang:"jsx",title:"最基础的 effect：把状态同步到 document.title",code:d}),e.jsx("h2",{children:"二、依赖数组的三种形态"}),e.jsxs("p",{children:[e.jsx("code",{children:"useEffect"})," 的第二个参数——依赖数组，决定了 effect 何时重新执行。它有三种形态， 语义完全不同，是初学者最容易混淆的地方。"]}),e.jsx(t,{lang:"jsx",title:"三种依赖数组形态",code:o}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"写法"}),e.jsx("th",{children:"何时执行"}),e.jsx("th",{children:"典型用途"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"不传第二个参数"}),e.jsx("td",{children:"每次渲染提交后都执行"}),e.jsx("td",{children:"几乎用不到；常因此引发死循环"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"[]"})," 空数组"]}),e.jsx("td",{children:"仅挂载后执行一次，卸载时清理一次"}),e.jsx("td",{children:"建立一次性的订阅 / 监听 / 连接"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"[a, b]"})," 有依赖"]}),e.jsx("td",{children:"挂载时执行；之后任一依赖变化就重新执行"}),e.jsx("td",{children:"依赖某个 prop / state 的同步"})]})]})]}),e.jsxs(s,{variant:"warn",title:"依赖数组不是「性能开关」",children:['新手常把依赖数组当成"控制 effect 跑不跑"的旋钮，随意增删。其实它的唯一正确含义是：',e.jsx("strong",{children:"列出 effect 内部用到的所有响应式值"}),'。该列的不列，就会读到旧快照（上一章的闭包陷阱）； 为了"少跑几次"而故意漏写依赖，几乎一定会埋 bug。']}),e.jsx("h2",{children:"三、清理函数与它的执行时机"}),e.jsxs("p",{children:["effect 可以 ",e.jsx("code",{children:"return"})," 一个函数，这就是",e.jsx("strong",{children:"清理函数"}),"。它的作用是 撤销这个 effect 建立的副作用——断开连接、清掉定时器、移除监听器。理解它的关键是 执行时机：清理函数会在",e.jsx("strong",{children:"两个时刻"}),"被调用。"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"组件卸载前"}),"：用最后一次的值清理一次。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"effect 即将因依赖变化而重新执行前"}),"：先用",e.jsx("strong",{children:"旧值"}),"清理一次，再用新值重跑 effect。"]})]}),e.jsx(t,{lang:"jsx",title:"清理函数：聊天室连接随 roomId 切换",code:l}),e.jsx(i,{title:"为什么「先清理旧的再建立新的」很重要",children:e.jsxs("p",{children:["如果没有清理函数，",e.jsx("code",{children:"roomId"}),' 从 general 切到 music 时，旧的 general 连接 不会断开——你会同时挂着两个连接，再切几次就堆出一串泄漏的连接。清理函数保证了 "任一时刻只有一个有效连接"这个不变式。订阅、定时器、事件监听都是同理。']})}),e.jsx("h2",{children:"四、正确清理：订阅 / 定时器 / 事件监听"}),e.jsx("p",{children:'凡是 effect 里"建立了"某种持续性的东西，就一定要在清理函数里"拆掉"它。下面是事件监听的标准写法。'}),e.jsx(t,{lang:"jsx",title:"事件监听的建立与清理",code:f}),e.jsxs("p",{children:["注意一个细节：",e.jsx("code",{children:"addEventListener"})," 和 ",e.jsx("code",{children:"removeEventListener"})," 必须传",e.jsx("strong",{children:"同一个函数引用"}),"，所以要先把回调存进变量 ",e.jsx("code",{children:"onResize"}),"， 不能两边各写一个内联箭头函数（那是两个不同的引用，移除会失败）。"]}),e.jsx("h2",{children:"五、请求竞态：ignore 标志与 AbortController"}),e.jsxs("p",{children:["在 effect 里发请求有个隐蔽的坑——",e.jsx("strong",{children:"竞态（race condition）"}),"。用户快速改变",e.jsx("code",{children:"query"}),'，会连发多个请求，而它们返回的顺序不保证和发出的顺序一致。 如果一个"早发出、晚到达"的旧请求最后才返回，它会覆盖掉新请求的正确结果。']}),e.jsx(t,{lang:"jsx",title:"方案一：ignore 标志丢弃过期响应",code:h}),e.jsxs("p",{children:[e.jsx("code",{children:"ignore"})," 标志的思路是：每次 effect 重跑前，让上一次 effect 的清理把它的",e.jsx("code",{children:"ignore"})," 设为 ",e.jsx("code",{children:"true"}),"，这样旧请求即便返回了也会被丢弃。 更彻底的做法是 ",e.jsx("code",{children:"AbortController"}),"，直接在清理时中止上一个网络请求。"]}),e.jsx(t,{lang:"jsx",title:"方案二：AbortController 直接中止旧请求",code:x}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方案"}),e.jsx("th",{children:"原理"}),e.jsx("th",{children:"取舍"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"ignore 标志"}),e.jsx("td",{children:"请求照常发，只是丢弃过期响应"}),e.jsx("td",{children:"简单通用；但旧请求仍占用网络带宽"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"AbortController"}),e.jsx("td",{children:"清理时中止旧请求本身"}),e.jsx("td",{children:"更彻底、省带宽；需后端 / fetch 支持 signal"})]})]})]}),e.jsx("h2",{children:"六、StrictMode 下 effect 为什么跑两次"}),e.jsxs("p",{children:["开发环境开启 ",e.jsx("code",{children:"<React.StrictMode>"})," 时，你会发现每个 effect 在挂载时",e.jsx("strong",{children:"执行了两次"}),'（建立→清理→再建立）。这不是 bug，而是 React 故意为之的 "压力测试"。']}),e.jsxs("p",{children:["它的目的是",e.jsx("strong",{children:"逼你写出正确的清理函数"}),'。如果你的 effect 在"建立→清理→再建立" 之后行为依然正确，说明它是幂等且可重入的；如果出现了重复订阅、重复连接， 双跑会立刻暴露这个缺失清理的问题。这只发生在开发环境，生产环境只跑一次。']}),e.jsx(s,{variant:"info",title:"启示：让 effect 经得起「重跑」",children:"StrictMode 双跑给你的核心启示是——不要假设 effect 只会执行一次。只要你老老实实写了 对称的清理函数，无论 effect 被执行多少次，结果都应当一致。这本身就是健康 effect 的标志。"}),e.jsx("h2",{children:"七、你可能并不需要 Effect"}),e.jsx("p",{children:'这是 React 官方文档专门用一整页强调的建议。很多用 effect 的场景其实是误用—— effect 是为"和外部系统同步"准备的，而下面这两类逻辑根本不属于外部系统。'}),e.jsx(t,{lang:"jsx",title:"两类常见的「不该用 Effect」",code:j}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"派生状态"}),'：能由现有 props / state 直接算出来的值（如 fullName、过滤后的列表）， 应在渲染期间直接计算，不要用一个 state + effect 去"同步"——那会多触发一次渲染，还可能出现短暂的不一致。']}),e.jsxs("li",{children:[e.jsx("strong",{children:"事件逻辑"}),'：响应用户交互（点击、提交）的逻辑应写在事件处理函数里， 而不是用一个 state 标志去触发 effect。前者表达的是"用户做了某事"，后者表达的是"和外部同步"，语义不同。']})]}),e.jsxs(s,{variant:"tip",children:["判断口诀：如果这段逻辑是因为",e.jsx("strong",{children:"某个特定交互发生"}),"的，它属于事件处理函数； 如果是因为",e.jsx("strong",{children:"组件被显示在屏幕上"}),"而需要和外部世界保持一致，它才属于 effect。"]}),e.jsx("h2",{children:"八、useLayoutEffect 与 useEffect 的区别"}),e.jsxs("p",{children:["绝大多数时候你都该用 ",e.jsx("code",{children:"useEffect"}),"。但有一种特殊情况需要",e.jsx("code",{children:"useLayoutEffect"}),"：当你需要在浏览器绘制之前读取布局并立刻调整，以避免用户看到闪烁。"]}),e.jsx(t,{lang:"jsx",title:"两者的执行时机差异",code:a}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"对比项"}),e.jsx("th",{children:"useEffect"}),e.jsx("th",{children:"useLayoutEffect"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"执行时机"}),e.jsx("td",{children:"浏览器绘制之后"}),e.jsx("td",{children:"DOM 变更后、绘制之前"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"是否阻塞绘制"}),e.jsx("td",{children:"否（异步）"}),e.jsx("td",{children:"是（同步）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"典型用途"}),e.jsx("td",{children:"绝大多数副作用"}),e.jsx("td",{children:"测量布局后立刻定位，避免闪烁"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"性能影响"}),e.jsx("td",{children:"小"}),e.jsx("td",{children:"大，滥用会拖慢绘制"})]})]})]}),e.jsxs(s,{variant:"tip",children:["下一章我们看另一组 Hook：",e.jsx("code",{children:"useMemo"})," / ",e.jsx("code",{children:"useCallback"})," 做性能优化，",e.jsx("code",{children:"useRef"})," 存跨渲染不变的可变值，以及如何把有状态逻辑抽成自定义 Hook 来复用。"]}),e.jsx(c,{points:['effect 的本质是"渲染提交后把组件与外部系统同步"，不是生命周期回调；先问"要和哪个外部系统同步"。',"依赖数组三形态：不传=每次跑、空数组=只挂载跑一次、有依赖=依赖变化才重跑；依赖应完整列出 effect 用到的响应式值。","清理函数在组件卸载前、以及依赖变化导致 effect 重跑前（用旧值）执行；订阅 / 定时器 / 监听都必须对称清理。","请求竞态用 ignore 标志丢弃过期响应，或用 AbortController 直接中止旧请求。","StrictMode 开发期让 effect 跑两次，目的是逼你写出经得起重跑的对称清理函数。","派生状态与事件逻辑不该放进 effect；useLayoutEffect 在绘制前同步执行，仅用于避免布局闪烁。"]})]})}export{S as default};
