import{j as e}from"./index-DL563RIm.js";import{L as i,S as o}from"./Summary-BrgLcNDp.js";import{K as n}from"./KeyIdea-exK4GrdK.js";import{C as r}from"./Callout-B-8nslAm.js";import{C as s}from"./CodeBlock-DkVyd3P6.js";import{E as t}from"./Example-HxOmIesu.js";const l=`import { appendFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

// 审计日志：把每一次工具调用、权限裁定、确认结果，以结构化 JSONL 追加到 .forge/audit-*.jsonl。
// 事后可回放、可排查、可信任——这是 Agent 能上生产的前提之一。

export interface AuditEntry {
  ts: string
  type: 'tool_call' | 'permission' | 'confirm' | 'llm_round'
  [key: string]: unknown
}

export interface AuditLog {
  log(entry: Omit<AuditEntry, 'ts'>): void
}

// 写文件的审计实现。落在 <cwd>/.forge/ 下，按会话 id 分文件。
export class FileAuditLog implements AuditLog {
  private file: string

  constructor(cwd: string, sessionId: string) {
    const dir = join(cwd, '.forge')
    mkdirSync(dir, { recursive: true })
    this.file = join(dir, \`audit-\${sessionId}.jsonl\`)
  }

  log(entry: Omit<AuditEntry, 'ts'>): void {
    const line = JSON.stringify({ ts: new Date().toISOString(), ...entry }) + '\\n'
    try {
      appendFileSync(this.file, line, 'utf8')
    } catch {
      // 审计失败不应影响主流程，静默忽略。
    }
  }
}

// 一个什么都不做的审计实现，用于测试或关闭审计时。
export const noopAudit: AuditLog = { log() {} }`,d=`// 每轮 LLM 往返后
this.audit.log({ type: 'llm_round', model: this.provider.model, stopReason: res.stopReason, usage: res.usage })

// 权限裁定时
this.audit.log({ type: 'permission', tool: tool.name, input: call.input, decision: verdict.decision, reason: verdict.reason })

// 确认结果
this.audit.log({ type: 'confirm', tool: tool.name, reason: verdict.reason, approved })

// 工具执行后
this.audit.log({ type: 'tool_call', tool: call.name, input: call.input, isError: !!r.isError })`,c=`const sessionId = new Date().toISOString().replace(/[:.]/g, '-')
const audit = new FileAuditLog(process.cwd(), sessionId)
const agent = new Agent({
  provider,
  tools: ALL_TOOLS,
  system: SYSTEM_PROMPT,
  cwd: process.cwd(),
  audit,
})`,j=`{"ts":"2026-06-16T09:12:03.118Z","type":"llm_round","model":"claude-opus-4-8","stopReason":"tool_use","usage":{"inputTokens":1842,"outputTokens":156}}
{"ts":"2026-06-16T09:12:03.402Z","type":"permission","tool":"edit","input":{"path":"src/server.ts","old":"port = 3000","new":"port = 8080"},"decision":"ask","reason":"写入工作区文件需确认"}
{"ts":"2026-06-16T09:12:07.951Z","type":"confirm","tool":"edit","reason":"写入工作区文件需确认","approved":true}
{"ts":"2026-06-16T09:12:08.063Z","type":"tool_call","tool":"edit","input":{"path":"src/server.ts","old":"port = 3000","new":"port = 8080"},"isError":false}`,h=`// 两种记日志的方式，事后能不能查，天差地别。

// ✗ 非结构化（拼成一句人话）：好读，但机器没法筛、没法统计。
console.log(\`[\${new Date().toISOString()}] 执行了 edit src/server.ts，用户已确认\`)
//  事后想问「哪些 edit 被拒了」？只能正则去抠这行字符串，脆且不准。

// ✓ 结构化（字段化的对象）：好查、可聚合、可机读。
audit.log({ type: 'tool_call', tool: 'edit', input: { path: 'src/server.ts' }, isError: false })
//  事后 jq 一句就能筛 type=tool_call 且 isError=true 的全部记录。

// 原则：日志是写给「未来的查询」看的，不是写给「此刻的眼睛」看的。
// 先结构化存字段，要给人看时再渲染成人话——反过来就回不去了。`,x=`import { readFileSync } from 'node:fs'

// 回放：把一次会话的审计日志逐行读出来，重建「发生过什么」的时间线。
// 注意——回放的是「决策与事件」，不是「重新执行」。审计不是录像带，是飞行记录。
export function replay(file: string): void {
  const lines = readFileSync(file, 'utf8').split('\\n').filter(Boolean)
  for (const line of lines) {
    const e = JSON.parse(line)
    switch (e.type) {
      case 'llm_round':
        console.log(\`\${e.ts}  🧠 模型决定（\${e.model}，\${e.usage?.outputTokens ?? 0} tok）\`)
        break
      case 'permission':
        console.log(\`\${e.ts}  🔒 裁定 \${e.tool} → \${e.decision}：\${e.reason}\`)
        break
      case 'confirm':
        console.log(\`\${e.ts}  🙋 用户\${e.approved ? '同意' : '拒绝'}了 \${e.tool}\`)
        break
      case 'tool_call':
        console.log(\`\${e.ts}  ⚙ 执行 \${e.tool}\${e.isError ? '（失败）' : ''}\`)
        break
    }
  }
}`,a=`// 把审计事件升级成「分布式追踪」里的 span，就能接进 OpenTelemetry 之类的可观测体系。
// 关键是给每条记录补两个字段：traceId（整次会话）和 spanId（单步操作）+ 父子关系。
interface TracedEntry extends AuditEntry {
  traceId: string      // 一次会话 = 一条 trace
  spanId: string       // 一步操作 = 一个 span
  parentSpanId?: string // 谁触发了我（llm_round → permission → tool_call 形成树）
  durationMs?: number  // 这步耗时，用来画火焰图、找瓶颈
}

// 有了 trace/span，一次会话就能在 Jaeger / Tempo 里画成一棵调用树：
//   llm_round (1.2s)
//   └─ permission edit (0.3ms)
//      └─ confirm edit (4.5s ← 用户在这儿想了半天)
//         └─ tool_call edit (12ms)
// 一眼看出时间花在哪、哪步出错、模型绕了几个来回。`;function S(){return e.jsxs("article",{children:[e.jsx(i,{children:"权限能拦、确认能问，可一旦放手让它干，事后你还是想知道：它到底调了什么工具、传了什么参数、谁批准的、模型为什么这么决定。这一章，我们把 Agent 的每一步都写成结构化日志，落到磁盘——给 forge 装上黑匣子。"}),e.jsx("h2",{children:"一、为什么要审计"}),e.jsxs("p",{children:["Agent 和普通程序最大的不同，是它会",e.jsx("strong",{children:"自己动手"}),"：自己决定调哪个工具、自己拼参数、自己改文件跑命令。一切顺利时你不会在意，可一旦出了岔子——文件被改错、命令删了不该删的东西、模型莫名其妙绕了一大圈——你需要能",e.jsx("strong",{children:"复盘"}),"。"]}),e.jsx("p",{children:"复盘要回答的，无非是这几个问题："}),e.jsxs("ul",{children:[e.jsxs("li",{children:["它",e.jsx("strong",{children:"调了哪些工具"}),"、按什么顺序？"]}),e.jsxs("li",{children:["每次工具的",e.jsx("strong",{children:"参数"}),"到底是什么？（光看结果往往看不出问题，参数才是真相）"]}),e.jsxs("li",{children:["哪一步触发了确认、",e.jsx("strong",{children:"是谁批准"}),"的？"]}),e.jsxs("li",{children:["模型为什么这么决定？每轮往返的 ",e.jsx("code",{children:"stopReason"})," 和 token 消耗是多少？"]})]}),e.jsxs("p",{children:["靠 stdout 滚屏是答不了这些问题的——屏幕会清，日志会丢，事后也没法按字段筛。我们需要把这些信息",e.jsx("strong",{children:"结构化"}),"地、",e.jsx("strong",{children:"持久"}),"地存下来。"]}),e.jsx(n,{title:"审计日志 = Agent 的黑匣子",children:"飞机的黑匣子不参与飞行，但出事后能还原每一个动作。审计日志对 Agent 是同样的角色：它不影响主流程，却记录下「模型决定 → 权限裁定 → 确认 → 执行」的完整链路，让每一步都可回放、可排查、可追责。"}),e.jsxs("p",{children:["除了「出事复盘」，审计还撑起另外两件容易被低估的事。一是",e.jsx("strong",{children:"可观测性"}),"： Agent 是个黑盒，你光看它「最后改对了没」，看不出它",e.jsx("strong",{children:"为此烧了多少 token、绕了几轮、卡在哪一步"}),"。 结构化日志把这些隐藏成本量化出来——哪类任务最费钱、哪个工具最常失败、模型在哪儿反复打转， 都能从日志里聚合出来。二是",e.jsx("strong",{children:"合规与追责"}),"：在受监管的环境里（金融、医疗、企业内部）， 「一个 AI 改动了系统」这件事本身就需要留痕——谁在什么时间、授权了什么操作、改了什么， 必须有一份不可抵赖的记录备查。审计日志就是这份记录的载体。"]}),e.jsx(n,{title:"先结构化，再谈一切",children:e.jsxs("p",{children:["审计的所有价值——回放、统计、追踪、合规——都建立在一个前提上：",e.jsx("strong",{children:"日志是结构化的"}),"。 一旦你把信息拼成一句人话（「执行了 edit，用户已确认」），就再也别想干净地按字段筛选、聚合、对接工具了。 正确的方向是反过来：先按字段存成机器可读的对象，要给人看时再渲染成人话。结构化是地基， 这个顺序错了，后面全是返工。"]})}),e.jsx(s,{lang:"ts",title:"结构化 vs 非结构化：差在能不能查",code:h}),e.jsx("h2",{children:"二、为什么选 JSONL"}),e.jsx("p",{children:"我们选 JSONL（JSON Lines，每行一个独立 JSON 对象）作为格式，而不是一个大 JSON 数组，也不是纯文本。理由很实在："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"可追加"}),"：每条记录就是一行，直接 append 到文件末尾，不用把整个文件读出来再写回去——这对一个会跑很久、产生很多条记录的会话至关重要。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"可逐行处理"}),"：",e.jsx("code",{children:"grep"})," 一行、",e.jsx("code",{children:"jq"})," 一行，工具天然按行流式处理，几 GB 的日志也不用整块加载进内存。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"易解析"}),"：每行 ",e.jsx("code",{children:"JSON.parse"})," 一下就是结构化对象，崩溃中断也不会让整个文件变成废 JSON（数组格式少个 ",e.jsx("code",{children:"]"})," 就全废了）。"]})]}),e.jsxs(r,{variant:"tip",title:"JSONL 的日常用法",children:["想看这次会话调了几次 edit？",e.jsx("code",{children:`grep '"tool_call"' .forge/audit-*.jsonl | grep edit | wc -l`}),"。想统计 token 总消耗？",e.jsx("code",{children:"jq -s 'map(.usage.outputTokens // 0) | add' .forge/audit-*.jsonl"}),"。结构化 + 逐行，命令行就是你的分析器。"]}),e.jsx("h2",{children:"三、审计模块实现"}),e.jsxs("p",{children:["新建 ",e.jsx("code",{children:"src/audit.ts"}),"。它定义审计的数据结构、接口，以及两个实现："]}),e.jsx(s,{lang:"ts",title:"src/audit.ts",code:l}),e.jsx("p",{children:"逐段拆开看："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"AuditEntry"})}),"：每条记录都有 ",e.jsx("code",{children:"ts"}),"（时间戳）和 ",e.jsx("code",{children:"type"}),"（四类之一：",e.jsx("code",{children:"tool_call"})," 工具执行、",e.jsx("code",{children:"permission"})," 权限裁定、",e.jsx("code",{children:"confirm"})," 确认结果、",e.jsx("code",{children:"llm_round"})," 一轮 LLM 往返）。后面那个",e.jsx("strong",{children:"索引签名"})," ",e.jsx("code",{children:"[key: string]: unknown"})," 是关键——它允许每一类事件携带自己特有的字段（权限事件带 ",e.jsx("code",{children:"decision"}),"，往返事件带 ",e.jsx("code",{children:"usage"}),"），不必为四种类型各写一个死板的接口。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:[e.jsx("code",{children:"AuditLog"})," 接口"]}),"：只有一个 ",e.jsx("code",{children:"log()"})," 方法。面向接口而非具体类，意味着主流程不关心日志落在哪——可以是文件、可以是数据库、测试时可以是空实现。这正是依赖倒置的好处。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:[e.jsx("code",{children:"FileAuditLog"})," 构造函数"]}),"：在 ",e.jsx("code",{children:"<cwd>/.forge"})," 下建目录（",e.jsx("code",{children:"{ recursive: true }"})," 保证已存在也不报错），并按 ",e.jsx("code",{children:"sessionId"})," 拼出独立文件名。",e.jsx("strong",{children:"每个会话一个文件"}),"，互不干扰，回放时一目了然。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"log()"})}),"：把 ",e.jsx("code",{children:"ts"})," 自动补在最前面，序列化成一行再加换行符，用 ",e.jsx("code",{children:"appendFileSync"})," 追加。注意那个 ",e.jsx("code",{children:"try/catch"}),"——",e.jsx("strong",{children:"审计失败必须静默"}),"。磁盘满了、权限不够，都不能让记日志这件事把 Agent 主流程拖垮。黑匣子坏了，飞机还得能飞。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"noopAudit"})}),"：一个什么都不做的实现。单元测试里不想产生真实文件、或用户显式关闭审计时，注入它即可，主流程代码一行都不用改。"]})]}),e.jsx("h2",{children:"四、在主循环里埋点"}),e.jsxs("p",{children:["审计模块只是个能写日志的容器，真正有价值的是",e.jsx("strong",{children:"在对的地方记对的事"}),"。回到上一卷的 ",e.jsx("code",{children:"Agent"})," 主循环，在四个关键节点各埋一行："]}),e.jsx(s,{lang:"ts",title:"src/agent.ts（审计埋点）",code:d}),e.jsxs("p",{children:["这四个点不是随便挑的，它们正好串起一次操作的完整生命周期：",e.jsx("strong",{children:"模型决定"}),"（llm_round 记下模型、停止原因、token）→ ",e.jsx("strong",{children:"权限裁定"}),"（permission 记下裁定结果和理由）→ ",e.jsx("strong",{children:"（可能的）确认"}),"（confirm 记下用户批没批）→ ",e.jsx("strong",{children:"执行"}),"（tool_call 记下实际跑了什么、成没成功）。"]}),e.jsx("p",{children:"把同一会话的这几行按时间读出来，你就能完整还原：模型想干什么、系统准不准、人同不同意、最后干成没干成。"}),e.jsx("h2",{children:"五、在入口接上审计"}),e.jsxs("p",{children:["最后，在 ",e.jsx("code",{children:"src/index.ts"})," 创建审计实例并注入 ",e.jsx("code",{children:"Agent"}),"："]}),e.jsx(s,{lang:"ts",title:"src/index.ts（创建审计）",code:c}),e.jsxs("p",{children:[e.jsx("code",{children:"sessionId"})," 直接用当前时间的 ISO 字符串。但 ISO 字符串里有冒号和点（",e.jsx("code",{children:"2026-06-16T09:12:03.118Z"}),"），冒号在不少文件系统里是非法字符，于是用 ",e.jsx("code",{children:"replace(/[:.]/g, '-')"})," 把冒号和点统一换成连字符，得到 ",e.jsx("code",{children:"2026-06-16T09-12-03-118Z"})," 这样既合法、又自然按时间排序的文件名。会话一启动，",e.jsx("code",{children:".forge/audit-<时间戳>.jsonl"})," 就建好了。"]}),e.jsxs(t,{title:"一段真实的审计日志",children:[e.jsxs("p",{children:["跑一次「把端口从 3000 改成 8080」的任务，",e.jsx("code",{children:".forge/audit-*.jsonl"})," 里会长出这样四行："]}),e.jsx(s,{lang:"json",code:j}),e.jsxs("p",{children:["顺着读下来：模型决定调 edit（llm_round）→ 权限模块裁定为 ",e.jsx("code",{children:"ask"})," 需要确认（permission）→ 用户点了同意（confirm，",e.jsx("code",{children:"approved:true"}),"）→ edit 实际执行成功（tool_call，",e.jsx("code",{children:"isError:false"}),"）。一次有人参与的安全改动，前因后果全在四行里。"]})]}),e.jsx("h2",{children:"六、回放：把日志读回成时间线"}),e.jsxs("p",{children:["有了结构化的事件流，最直接的用法就是",e.jsx("strong",{children:"回放"}),"——把一次会话的日志逐行读出来， 按时间重建「到底发生了什么」。注意一个关键区分：",e.jsx("strong",{children:"回放的是「决策与事件」，不是「重新执行」"}),"。 审计不是录像带、不能倒回去重跑（重跑会再次产生副作用），它是飞机黑匣子那样的飞行记录—— 告诉你当时每一步的状态和选择，让你在脑子里把过程还原一遍。"]}),e.jsx(s,{lang:"ts",title:"一个最小的回放器",code:x}),e.jsxs("p",{children:["这段 ",e.jsx("code",{children:"replay"})," 把四类事件各渲染成一行人话，串起来就是一条清晰的时间线： 模型在 9:12:03 决定调 edit、权限裁定为 ask、用户 4 秒后点头、edit 在 12 毫秒内执行成功。 排查问题时，这条线就是你的第一手现场——比追问用户「你当时干了啥」可靠一万倍。 因为日志是结构化的，写这种回放、过滤、统计工具几乎不费力，",e.jsx("code",{children:"JSON.parse"})," 一行就拿到对象了。"]}),e.jsx("h2",{children:"七、和追踪系统集成：从日志到分布式追踪"}),e.jsxs("p",{children:["当 forge 从「本地单进程」长成「多 Agent、跨服务、长时间运行」的系统，单纯的行式日志就不够看了—— 你会想知道「这次会话总共花了多久、时间分布在哪几步、哪一步阻塞了后面」。这正是",e.jsx("strong",{children:"分布式追踪（distributed tracing）"}),"要解决的，而从 JSONL 升级过去，成本出乎意料地低： 只要给每条记录补上 ",e.jsx("code",{children:"traceId"})," / ",e.jsx("code",{children:"spanId"})," / 父子关系和耗时，审计事件就摇身变成 trace 里的 span。"]}),e.jsx(s,{lang:"ts",title:"给审计事件加上 trace/span，接进 OpenTelemetry",code:a}),e.jsxs("p",{children:["一旦事件带上了这几个字段，你就能把它们喂给 OpenTelemetry，在 Jaeger、Tempo、Datadog 这类后端里 把一次会话画成一棵调用树：哪一步耗时最长、哪一步报了错、模型来回绕了几轮，全都可视化。 前面那个 ",e.jsx("code",{children:"confirm"})," 花了 4.5 秒——回放里只是一行，在火焰图里却是一根扎眼的长条， 一眼看出「时间其实卡在等用户点头」。这就是结构化地基的复利：当初多花几分钟把字段定规整， 日后接观测、接追踪、接告警，全是顺水推舟。"]}),e.jsx(r,{variant:"tip",title:"一条日志，三种读法",children:e.jsxs("p",{children:["同一份 ",e.jsx("code",{children:".forge/audit-*.jsonl"}),"，可以被三类人 / 三种工具读出三种价值：",e.jsx("strong",{children:"开发者"}),"用 ",e.jsx("code",{children:"replay"})," 还原现场排 bug；",e.jsx("strong",{children:"运维 / SRE"}),"把它接进 OTel 看耗时、错误率、token 成本；",e.jsx("strong",{children:"合规 / 审计岗"}),"把它当作「谁授权了什么操作」的不可抵赖凭证。 这就是「先结构化」的回报——一次写入，多方复用，谁都不用迁就谁。"]})}),e.jsxs(r,{variant:"warn",title:"审计日志别提交到 git",children:["审计里塞满了敏感信息：绝对路径、执行过的命令、文件 diff 的具体内容，甚至可能间接带出密钥或内部结构。这些东西",e.jsx("strong",{children:"绝不能进版本库"}),"。好在 forge 在初始化时已经把 ",e.jsx("code",{children:".forge/"})," 写进了 ",e.jsx("code",{children:".gitignore"}),"，默认就帮你拦住了——但接手别人项目时，记得确认这一行还在。"]}),e.jsxs(r,{variant:"note",title:"这只是观测性的地基",children:["现在我们只是把日志写下来了。有了这套",e.jsx("strong",{children:"结构化"}),"的事件流，卷 7「可观测性」会在它之上继续盖楼：基于 type 的调试开关（只看权限事件 / 只看工具调用）、按 ",e.jsx("code",{children:"usage"})," 字段做成本统计、把 llm_round 串成耗时火焰图。地基打得越规整，上层越省力。"]}),e.jsx("h2",{children:"八、卷 3 小结"}),e.jsxs("p",{children:["这一卷我们围绕一个主题：",e.jsx("strong",{children:"让一个会自己动手的 Agent 变得可信"}),"。三章下来，攒齐了三件套："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"权限（deny）"}),"：危险操作直接拒，画出 Agent 绝不能越的红线。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"确认（ask）"}),"：拿不准的操作停下来问人，把最终决定权交还给你。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"审计（留痕）"}),"：每一步都写进黑匣子，事后能复盘、能追责。"]})]}),e.jsxs("p",{children:["拦得住、问得对、查得清——这三层叠在一起，forge 才从一个「看起来挺能干但不敢用」的玩具，变成一个你",e.jsx("strong",{children:"敢放手"}),"让它改代码、跑命令的工具。"]}),e.jsx(n,{title:"可信，是放手的前提",children:"权限负责「不该做的不做」，确认负责「拿不准的先问」，审计负责「做过的都留痕」。三者合一，把不可控的自动化变成可控的协作。信任不是凭感觉给的，是靠这套机制挣来的。"}),e.jsxs("p",{children:["下一卷，我们换一个战场——",e.jsx("strong",{children:"上下文工程"}),"。当对话越来越长、工具结果越来越多，如何让模型在有限的上下文窗口里始终抓住重点，是决定 Agent 聪不聪明的另一半答案。"]}),e.jsx(o,{points:["审计日志是 Agent 的黑匣子：记录「模型决定 → 权限裁定 → 确认 → 执行」全链路，不影响主流程却让每一步可回放、可排查。","选 JSONL 格式：可追加、可 grep/jq 逐行处理、易解析，崩溃也不会让整个文件作废。","src/audit.ts 用接口 AuditLog 解耦实现：FileAuditLog 按 sessionId 分文件落到 .forge/，log() 自动加 ts 并 try/catch 静默失败；noopAudit 供测试或关闭审计时注入。","在主循环四个节点埋点：llm_round、permission、confirm、tool_call，串起一次操作的完整生命周期。","审计还撑起可观测性（量化 token/轮数/失败）与合规追责（不可抵赖的授权留痕）；一切的前提是「先结构化、再渲染成人话」。","回放是把日志读回成时间线还原现场——回放的是决策与事件，不是重新执行（黑匣子，不是录像带）。","补上 traceId/spanId/耗时，审计事件就升级成分布式追踪的 span，可接 OpenTelemetry 在 Jaeger/Tempo 里画调用树、看瓶颈。","sessionId 用 ISO 时间戳并把冒号点号换成连字符，得到合法且自然按时间排序的文件名。","审计含敏感信息，.forge/ 已写进 .gitignore，绝不提交版本库。","卷 3 收官：权限(deny) + 确认(ask) + 审计(留痕) 三件套让 forge 可被信任、敢放手；下一卷进入上下文工程。"]})]})}export{S as default};
