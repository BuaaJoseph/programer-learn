import{j as e}from"./index-C4u1Qi4f.js";import{L as r,a as s,P as i,C as n,S as t}from"./Summary-DjSaQefZ.js";import{K as c}from"./KeyIdea-BS4xPn0s.js";import{E as l}from"./Example-DNWIRw6O.js";const d=`from anthropic import Anthropic

client = Anthropic()

def call(system, user):
    resp = client.messages.create(
        model='claude-sonnet-4-5',
        max_tokens=1024,
        system=system,
        messages=[{'role': 'user', 'content': user}],
    )
    return resp.content[0].text

def draft(task):
    return call('你是写作助手，直接产出答案。', task)

# 关键：critic 用「独立视角」，只挑错、不为答案辩护
CRITIC_SYS = '''你是严格的审稿人。针对给定的任务和草稿，只列出具体问题：
事实错误、遗漏的要求、逻辑漏洞、表达问题。如果确实没问题，只回复「PASS」。
不要重写答案，不要夸奖。'''

def critique(task, answer):
    return call(CRITIC_SYS, f'任务:\\n{task}\\n\\n草稿:\\n{answer}')

def revise(task, answer, feedback):
    return call('你是写作助手，根据审稿意见修订答案，只输出修订后的完整答案。',
                f'任务:\\n{task}\\n\\n原答案:\\n{answer}\\n\\n审稿意见:\\n{feedback}')

def reflexion_loop(task, max_rounds=3):
    answer = draft(task)
    best = answer
    for _ in range(max_rounds):
        fb = critique(task, answer)
        if fb.strip() == 'PASS':
            return answer            # critic 认可，提前收工
        answer = revise(task, answer, fb)
        best = answer                # 保留最近一版（也可按打分保留最优）
    return best

print(reflexion_loop('用三句话解释什么是数据库索引，面向初级开发者'))`;function j(){return e.jsxs(e.Fragment,{children:[e.jsx(r,{children:e.jsxs("p",{children:["自主 Agent 跑在一个循环里，没有人盯着每一步。它走偏了，没人会报警——只能靠它",e.jsx("strong",{children:"自己发现自己错了"}),"， 再改回来。这种「自我察觉 + 自我纠正」的能力，叫",e.jsx("em",{children:"反思"}),"（reflection / self-correction）。它和你熟悉的 错误处理是两码事，却同样是 Agent 能不能可靠干完活的关键。"]})}),e.jsx("h2",{children:"反思和「错误处理」不是一回事"}),e.jsxs("p",{children:["传统的错误处理，依赖一个",e.jsx("strong",{children:"明确的失败信号"}),"：API 返回 500、函数抛异常、断言失败——有东西「报警」， 你的 ",e.jsx("code",{children:"try/except"})," 才有机会接住。但 Agent 的很多错误不会报警：模型一本正经地编了个不存在的 API、 把需求理解偏了、推理链中间断了一环——程序层面一切「正常」，结果却是错的。"]}),e.jsx("p",{children:"这类「没人报警的错」，只能靠 Agent 自己回头看一眼产出，判断「这对吗、够好吗」，发现不对再改。所以反思不是替代 错误处理，而是补上它够不着的那一大片——逻辑和质量层面的错误。"}),e.jsx("h3",{children:"四种反思模式"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"自我批评"}),"（self-critique）：让",e.jsx("strong",{children:"同一个"}),"模型先答，再在同一段对话里反问自己「上面哪里有问题」， 然后改。最简单，但有个天生的毛病（见下文）。"]}),e.jsxs("li",{children:[e.jsx("em",{children:"Reflexion"}),"：把「答 → 评 → 改」做成一个显式循环，每轮把上一轮的批评意见当作新的输入，迭代逼近更好的答案。 这是反思最常见的落地形态。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"独立 critic agent"}),"：用",e.jsx("strong",{children:"另一个"}),"模型调用（不同的 system prompt、看不到「答题者」的内心戏） 专门挑错。视角独立，不容易护短。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"工具核查"}),"：不靠模型的「感觉」，而是用真实工具验证——编译一下代码、跑一下测试、查一下数据库。 能用工具核查的地方，永远比让模型自评更可靠。"]})]}),e.jsx(c,{title:"挑错比答对容易",children:e.jsxs("p",{children:["反思之所以有效，靠的是一个不对称：",e.jsx("strong",{children:"生成一个正确答案很难，但判断一个给定答案哪里不对，要容易得多"}),"。 就像写一篇文章费劲，但读别人的文章挑毛病轻松。Agent 利用的正是这一点——先尽力答一版（可能不完美），再用相对 省力的「挑错」能力去发现并修补缺陷。这也解释了为什么「答 → 评 → 改」往往真能把质量抬上去。"]})}),e.jsxs(l,{title:"一轮 draft → critique → revise",children:[e.jsx("p",{children:"任务：「用三句话解释数据库索引，面向初级开发者。」"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"draft"}),"　模型答：「索引是一种 B+ 树结构，使用二分查找加速……」——出现了初级开发者未必懂的术语。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"critique"}),"　独立 critic 指出：「面向初级读者却用了 B+ 树、二分查找等术语，违背了受众要求；缺少一个直观类比。」"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"revise"}),"　修订版：「索引就像书末的目录，让数据库不用一页页翻就能快速定位数据。代价是写入会稍慢、要占额外空间。所以查得多、改得少的列才值得加索引。」"]})]}),e.jsx("p",{children:"第一版不算错，但 critic 抓住了「受众不匹配」这种没有任何程序会报警的问题，改完明显更切题。"})]}),e.jsx(s,{variant:"warn",title:"坑：模型会为自己的答案辩护",children:e.jsxs("p",{children:["让",e.jsx("strong",{children:"同一个"}),"模型既当答题者又当批改者，最大的隐患是",e.jsx("strong",{children:"自我偏袒"}),"——它倾向于认为自己刚写的答案是对的， 于是把「批评」写成「夸奖」，或者只挑无关痛痒的小毛病，真正的错误轻轻放过。这会让反思循环空转：转了三轮，答案没实质变化。 可靠得多的做法是用",e.jsx("strong",{children:"独立的 critic"}),"：不同的 system prompt、看不到答题者的推理过程，只对着「任务 + 答案」冷静挑错。 能上工具核查（编译、跑测试）就更别犹豫，那是最不会护短的「critic」。"]})}),e.jsx("h2",{children:"这对做 Agent / 工程实践意味着什么"}),e.jsxs("p",{children:["把反思做成一个 ",e.jsx("strong",{children:"draft → critique → revise 的循环"}),"，并设三道闸：一是",e.jsx("strong",{children:"最大轮数"}),"，避免无止境地改 （和第 1 章的轮数上限同源）；二是",e.jsx("strong",{children:"提前退出"}),"，critic 说「PASS」就立刻收工，别为改而改；三是",e.jsx("strong",{children:"保留最优"}),"——每一轮的修订未必都比上一轮好，要么保留最近通过的版本，要么给每版打分留最高的， 防止「越改越差」。再叠一条原则：能用工具客观核查的环节，就别让模型自评。这样反思才是净增益，而不是徒增成本。"]}),e.jsxs(i,{title:"实现 draft → critique → revise 循环",children:[e.jsxs("p",{children:["下面是一个可运行的 Reflexion 循环：",e.jsx("code",{children:"draft"})," 出初稿，",e.jsx("code",{children:"critique"})," 用",e.jsx("strong",{children:"独立 system prompt"}),"的 critic 挑错（约定无问题时回复 PASS），",e.jsx("code",{children:"revise"})," 据反馈修订，主循环负责控制轮数、提前退出、保留版本。"]}),e.jsx(n,{lang:"python",title:"reflexion.py",code:d}),e.jsxs("p",{children:["三处可以动手深化：把 ",e.jsx("code",{children:"best"})," 的策略从「留最近一版」改成「让一个 judge 给每版打分、留分数最高的」； 把 critic 换成同一段对话里的自我批评，对比一下它是不是更容易给自己「放水」；如果任务是写代码，把 critic 换成 「真的跑一遍单元测试」的工具核查，体会工具比模型自评可靠多少。"]})]}),e.jsx(t,{points:["反思是 Agent 自己发现、自己纠正错误的能力；它补的是错误处理够不着的逻辑与质量层面的「无报警错误」。","四种模式：自我批评、Reflexion（答-评-改循环）、独立 critic agent、工具核查（最可靠）。","反思有效的根基是不对称——挑错比答对容易，所以「先答再挑错再改」常能抬升质量。","最大的坑是自我偏袒：同一模型既答又评会替自己辩护，用独立 critic 更可靠，能上工具核查就别靠模型自评。","工程上把它做成 draft→critique→revise 循环，并设最大轮数、PASS 提前退出、保留最优三道闸。","反思要做成净增益而非徒增成本：客观可验的环节优先用工具核查，防止循环空转或越改越差。"]})]})}export{j as default};
