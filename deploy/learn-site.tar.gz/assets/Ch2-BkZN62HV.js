import{j as e}from"./index-BnUyEu5E.js";import{L as l,S as n}from"./Summary-qZ1-DBVA.js";import{K as i}from"./KeyIdea-DOTgzjr8.js";import{C as r}from"./Callout-DUAtr8Nz.js";import{C as s}from"./CodeBlock-DIEQOVpA.js";import{E as o}from"./Example-BRazL43h.js";const d=`import org.junit.Assert.assertEquals
import org.junit.Test

// 被测的纯逻辑：不依赖 Android 框架，跑在本机 JVM 上，飞快
class PriceCalculator {
    fun withTax(price: Double, rate: Double) = price * (1 + rate)
}

class PriceCalculatorTest {
    private val calc = PriceCalculator()

    @Test
    fun withTax_appliesRate() {
        assertEquals(110.0, calc.withTax(100.0, 0.10), 0.001)
    }
}`,t=`import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.StandardTestDispatcher
import org.junit.Assert.assertEquals
import org.junit.Test

class UserRepository(private val api: Api) {
    suspend fun loadName(id: Int): String = api.fetchUser(id).name
}

class UserRepositoryTest {
    @Test
    fun loadName_returnsName() = runTest {   // runTest：在测试里驱动协程，跳过真实延时
        val fakeApi = FakeApi(User(name = "Ada"))   // 注入假实现，隔离网络
        val repo = UserRepository(fakeApi)

        val name = repo.loadName(1)

        assertEquals("Ada", name)
    }
}`,c=`import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.assertIsDisplayed
import org.junit.Rule
import org.junit.Test

class CounterScreenTest {
    @get:Rule
    val composeRule = createComposeRule()   // 提供一个隔离的 Compose 测试环境

    @Test
    fun clickingButton_incrementsCounter() {
        // 1. 把要测的 Composable 放进测试环境
        composeRule.setContent { CounterScreen() }

        // 2. 断言初始状态
        composeRule.onNodeWithText("Count: 0").assertIsDisplayed()

        // 3. 找到按钮并点击
        composeRule.onNodeWithText("加一").performClick()

        // 4. 断言点击后 UI 更新
        composeRule.onNodeWithText("Count: 1").assertIsDisplayed()
    }
}`,a=`// app/build.gradle.kts
android {
    buildTypes {
        debug {
            applicationIdSuffix = ".debug"   // 包名加后缀，可与正式版同机共存
            isDebuggable = true
        }
        release {
            isMinifyEnabled = true            // 开启 R8 代码压缩 + 混淆
            isShrinkResources = true          // 同时压缩无用资源
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    // 产品风味：例如免费版 / 付费版，各自可有不同包名、资源、配置
    flavorDimensions += "tier"
    productFlavors {
        create("free")  { dimension = "tier"; applicationIdSuffix = ".free" }
        create("paid")  { dimension = "tier"; applicationIdSuffix = ".paid" }
    }
    // 变体 = buildType × flavor，如 freeDebug / paidRelease
}`,h=`// 1. 先生成 keystore（命令行，只做一次，妥善保管不能丢）
//    keytool -genkeypair -v -keystore release.jks \\
//      -alias myapp -keyalg RSA -keysize 2048 -validity 10000

// app/build.gradle.kts
android {
    signingConfigs {
        create("release") {
            // 实战中从环境变量 / local.properties 读，切勿把密码硬编码进版本库
            storeFile = file(System.getenv("KEYSTORE_PATH") ?: "release.jks")
            storePassword = System.getenv("KEYSTORE_PWD")
            keyAlias = "myapp"
            keyPassword = System.getenv("KEY_PWD")
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
        }
    }
}`,p=`# 打包 Android App Bundle（.aab），这是上架 Google Play 的标准产物
./gradlew bundleRelease
# 产物在 app/build/outputs/bundle/release/app-release.aab

# 本地若要装到真机调试 release 包，可用 bundletool 从 aab 生成针对性 apk：
# java -jar bundletool.jar build-apks --bundle=app-release.aab --output=app.apks
#   --mode=universal

# 对比：以前直接上传 .apk；现在上架统一用 .aab，由 Play 按设备下发最小 apk
./gradlew assembleRelease   # 仍可产出 apk，多用于内部分发 / 侧载`;function A(){return e.jsxs("article",{children:[e.jsxs(l,{children:["到了全课最后一章：把写好的 App ",e.jsx("strong",{children:"测试可靠"}),"、",e.jsx("strong",{children:"签名打包"}),"、",e.jsx("strong",{children:"上架到应用商店"}),"。这是从「我电脑上能跑」到「全世界用户能装」的临门一脚。 我们按测试金字塔讲 Android 的测试分层，再走一遍构建变体、签名、AAB 打包、R8 混淆， 最后过一遍 Google Play 的上架流程，为整门课收束。"]}),e.jsx("h2",{children:"一、测试金字塔在 Android 的样子"}),e.jsxs(i,{children:["测试金字塔的原则是：",e.jsx("strong",{children:"底层多、顶层少"}),"。大量快速、便宜的",e.jsx("strong",{children:"单元测试"}),"打底， 中间一层",e.jsx("strong",{children:"集成 / UI 测试"}),"，顶端少量端到端测试。越往上越慢越脆、维护成本越高， 所以越往上数量越少。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"层级"}),e.jsx("th",{children:"测什么"}),e.jsx("th",{children:"工具"}),e.jsx("th",{children:"跑在哪"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"单元测试（底，多）"}),e.jsx("td",{children:"纯逻辑、ViewModel、Repository"}),e.jsx("td",{children:"JUnit + 协程测试"}),e.jsx("td",{children:"本机 JVM，毫秒级"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"UI / 组件测试（中）"}),e.jsx("td",{children:"单个界面的交互与渲染"}),e.jsx("td",{children:"Compose Testing"}),e.jsx("td",{children:"设备 / 模拟器或 Robolectric"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"端到端（顶，少）"}),e.jsx("td",{children:"跨界面的完整用户流程"}),e.jsx("td",{children:"Espresso / UI Automator"}),e.jsx("td",{children:"真机 / 模拟器，最慢"})]})]})]}),e.jsx("h3",{children:"单元测试：JUnit + 协程测试"}),e.jsxs("p",{children:["单元测试针对不依赖 Android 框架的",e.jsx("strong",{children:"纯逻辑"}),"，放在 ",e.jsx("code",{children:"src/test/"})," 下，跑在本机 JVM， 速度极快。用 ",e.jsx("strong",{children:"JUnit"})," 写断言。"]}),e.jsx(s,{lang:"kotlin",title:"JUnit 单元测试",code:d}),e.jsxs("p",{children:["现代 Android 大量用",e.jsx("strong",{children:"协程"}),"，测异步代码要用 ",e.jsx("code",{children:"kotlinx-coroutines-test"}),"。 核心是 ",e.jsx("code",{children:"runTest "}),"：它在测试里驱动协程、",e.jsx("strong",{children:"自动跳过真实延时"}),"，让本来要等几秒的",e.jsx("code",{children:"delay"})," 瞬间完成；配合可控的 ",e.jsx("code",{children:"TestDispatcher"}),"，还能精确控制并发时序。"]}),e.jsx(s,{lang:"kotlin",title:"协程测试：runTest",code:t}),e.jsx("h3",{children:"UI 测试：Compose Testing"}),e.jsxs("p",{children:["测 Compose 界面用官方的 ",e.jsx("strong",{children:"Compose Testing"}),"。它的三板斧是：",e.jsx("code",{children:"createComposeRule()"})," 提供隔离的测试环境并用 ",e.jsx("code",{children:"setContent"})," 放入要测的 Composable；",e.jsx("code",{children:"onNodeWithText(...)"}),"（及 ",e.jsx("code",{children:"onNodeWithTag"})," 等）按语义",e.jsx("strong",{children:"查找节点"}),"； 然后用 ",e.jsx("code",{children:"performClick()"})," 等",e.jsx("strong",{children:"发起交互"}),"、用 ",e.jsx("code",{children:"assertIsDisplayed()"})," 等",e.jsx("strong",{children:"做断言"}),"。"]}),e.jsx(s,{lang:"kotlin",title:"Compose UI 测试",code:c}),e.jsxs(r,{variant:"info",title:"Espresso 一句话",children:[e.jsx("code",{children:"Espresso"})," 是传统 View 体系的 UI 测试框架（",e.jsx("code",{children:"onView"})," / ",e.jsx("code",{children:"perform"})," /",e.jsx("code",{children:"check"}),"），纯 Compose 项目用 Compose Testing 即可，二者也能在混合界面里互通。"]}),e.jsx("h2",{children:"二、构建变体：buildTypes 与 flavors"}),e.jsxs("p",{children:["同一份代码常要产出多种 App 包：调试版要可调试、能装在正式版旁边；正式版要混淆压缩； 可能还要分免费 / 付费版。Gradle 用两个维度组合出这些",e.jsx("strong",{children:"构建变体"}),"。"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"buildTypes"}),"：构建类型，内置 ",e.jsx("code",{children:"debug"})," 和 ",e.jsx("code",{children:"release"}),"。debug 方便开发，release 开启优化与签名。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"productFlavors"}),"：产品风味，按业务维度拆分，如 ",e.jsx("code",{children:"free"})," / ",e.jsx("code",{children:"paid"}),"，各自可有不同包名、资源、配置。"]})]}),e.jsxs("p",{children:["变体 = buildType × flavor。比如声明了上面两者，就能得到 ",e.jsx("code",{children:"freeDebug"}),"、",e.jsx("code",{children:"freeRelease"}),"、",e.jsx("code",{children:"paidDebug"}),"、",e.jsx("code",{children:"paidRelease"})," 四个变体。"]}),e.jsx(s,{lang:"kotlin",title:"buildTypes 与 productFlavors",code:a}),e.jsx("h2",{children:"三、签名：keystore、签名配置与 Play App Signing"}),e.jsxs(i,{children:["每个上架的 App 都必须用",e.jsx("strong",{children:"数字签名"}),"。签名证明「这个更新包确实来自同一开发者」， 系统据此才允许覆盖安装。签名的私钥存在 ",e.jsx("strong",{children:"keystore"})," 文件里，",e.jsx("strong",{children:"一旦丢失或泄露，你将无法再为这个 App 发布更新"}),"。"]}),e.jsxs("p",{children:["流程是：先用 ",e.jsx("code",{children:"keytool"})," 生成一个 keystore（含密钥别名、密码），再在",e.jsx("code",{children:"build.gradle.kts"})," 里配 ",e.jsx("code",{children:"signingConfigs"})," 指向它，并把 release 构建类型挂上这个签名配置。"]}),e.jsx(s,{lang:"kotlin",title:"签名配置",code:h}),e.jsxs(r,{variant:"warn",title:"密钥与密码绝不进版本库",children:["keystore 文件和各种密码",e.jsx("strong",{children:"不能"}),"提交到 Git。实战里从环境变量、",e.jsx("code",{children:"local.properties"})," 或 CI 的密钥管理读取，并对 keystore 做好异地备份——丢了它， 这个应用就再也发不了更新了。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"Play App Signing"}),"（Google Play 应用签名）是 Google 推荐且对新应用默认启用的方案： 你保留一个",e.jsx("strong",{children:"上传密钥"}),"用于给上传到 Play 的包签名，而真正面向用户的",e.jsx("strong",{children:"应用签名密钥"}),"由 Google 安全托管。好处是即便上传密钥泄露也能找 Google 重置，而最终签名密钥永不离开 Google 的保险库。"]}),e.jsx("h2",{children:"四、打包 AAB 与 R8 混淆压缩"}),e.jsx("h3",{children:"Android App Bundle（AAB）"}),e.jsxs("p",{children:["上架 Google Play 的标准产物已经从 APK 变成了 ",e.jsxs("strong",{children:["AAB（Android App Bundle，",e.jsx("code",{children:".aab"}),"）"]}),"。 AAB 不是直接装到手机的包，而是一份「打包好的所有素材」上传给 Play；Play 再根据每台设备的屏幕密度、 CPU 架构、语言，动态生成并下发",e.jsx("strong",{children:"体积最小的定制 APK"}),"。这叫 Dynamic Delivery，能显著减小用户下载量。"]}),e.jsx(s,{lang:"bash",title:"打包 AAB 与 APK",code:p}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"APK"}),e.jsx("th",{children:"AAB"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"本质"}),e.jsx("td",{children:"可直接安装的包"}),e.jsx("td",{children:"上传给商店的发布格式"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"设备适配"}),e.jsx("td",{children:"一个包装所有设备（偏大）"}),e.jsx("td",{children:"Play 按设备下发最小 APK"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Play 上架"}),e.jsx("td",{children:"不再接受新应用用 APK 上架"}),e.jsx("td",{children:"新应用必须用 AAB"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"侧载 / 内部分发"}),e.jsx("td",{children:"仍常用"}),e.jsx("td",{children:"需 bundletool 转成 APK"})]})]})]}),e.jsx("h3",{children:"R8：混淆与压缩"}),e.jsxs("p",{children:["release 构建里把 ",e.jsx("code",{children:"isMinifyEnabled = true"})," 打开，就会启用 ",e.jsx("strong",{children:"R8"}),"。它一步做三件事：",e.jsx("strong",{children:"压缩"}),"（去掉没被用到的类与方法，缩小包体）、",e.jsx("strong",{children:"混淆"}),"（把类名方法名改成 ",e.jsx("code",{children:"a"}),"、",e.jsx("code",{children:"b"})," 这种短名，既减体积又增加逆向难度）、",e.jsx("strong",{children:"优化"}),"（内联、去死代码）。配合",e.jsx("code",{children:"isShrinkResources = true"})," 还能砍掉无用资源。"]}),e.jsxs(r,{variant:"warn",title:"混淆会破坏反射 / 序列化，要写 keep 规则",children:["反射、Gson/Moshi 序列化、JNI 等依赖「名字不变」的场景，会被混淆改名搞坏。需要在",e.jsx("code",{children:"proguard-rules.pro"})," 里写 ",e.jsx("code",{children:"-keep"})," 规则保住这些类。开了混淆后务必",e.jsx("strong",{children:"实测 release 包"}),"， 别只测 debug。"]}),e.jsx("h2",{children:"五、上架 Google Play 的流程"}),e.jsxs("p",{children:["准备好签名的 AAB，就能走 ",e.jsx("strong",{children:"Google Play Console"})," 上架："]}),e.jsxs("ol",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"创建应用"}),"：在 Console 新建应用，填名称、默认语言、应用 / 游戏类别。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"完善商店信息"}),"：图标、截图、简介、隐私政策链接，以及内容分级、数据安全表单等合规项。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"上传 AAB 到测试轨道"}),"：先进",e.jsx("strong",{children:"内测（internal testing）"}),"给少数人验证；再到",e.jsx("strong",{children:"封测（closed testing）"}),"扩大范围；稳了再发",e.jsx("strong",{children:"正式（production）"}),"轨道。轨道是渐进放量的护栏。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"提交审核"}),"：Google 会审核合规与功能，通过后才在商店可见。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"分阶段发布"}),"：正式轨道还可设灰度比例（如先放 10% 用户），出问题能及时止损。"]})]}),e.jsx(r,{variant:"info",title:"国内商店一句话",children:"Google Play 在国内不可用，面向国内还需上架华为、小米、OPPO、vivo、应用宝等各家商店， 各自有独立的开发者后台、审核规则与（多为 APK 的）打包要求。"}),e.jsx(o,{title:"一条典型的发布路径",children:e.jsxs("p",{children:[e.jsx("code",{children:"./gradlew bundleRelease"})," 产出签名 AAB → 传到内测轨道，团队内安装验证 → 升到封测，招募一批外部用户灰度 → 收集崩溃与反馈、修问题 → 发正式轨道并设 10% 分阶段放量 → 指标健康后逐步拉到 100%。每一步都给了「发现问题就回退」的余地。"]})}),e.jsx("h2",{children:"六、全课收束"}),e.jsxs("p",{children:["从 Kotlin 语言基础、Jetpack Compose 的声明式 UI，到状态管理、架构、数据与网络，再到这一卷的 权限适配性能与测试发布——你已经走完了一个 Android App",e.jsx("strong",{children:"从无到上架"}),"的完整闭环。 工程化的精髓不在某个炫技 API，而在把「可靠、可维护、可交付」当成默认要求：测试兜底质量、 变体与签名管住发布、商店流程的渐进放量让你有底气面对真实用户。带着这套闭环思维， 去做出你自己的第一个上架 App 吧。"]}),e.jsx(n,{points:["测试金字塔：底层大量 JUnit 单元测试（含 runTest 跑协程、隔离依赖），中间 Compose UI 测试，顶端少量 Espresso/端到端。","Compose Testing 三板斧：createComposeRule 起环境、onNodeWithText 查节点、performClick/assertIsDisplayed 交互与断言。","构建变体 = buildTypes（debug/release）× productFlavors（如 free/paid）；release 开启优化与签名。","签名靠 keystore 私钥证明同一开发者，丢了就发不了更新；密码绝不进版本库；Play App Signing 让 Google 托管最终签名密钥、你只管上传密钥。","上架产物用 AAB（取代 APK），Play 按设备下发最小 APK；release 开 R8 做压缩+混淆+优化，反射/序列化需写 keep 规则并实测 release 包。","上架流程：Play Console 创建应用→完善商店信息与合规→内测/封测/正式轨道渐进放量→审核→分阶段发布；国内还需上各家安卓商店。"]})]})}export{A as default};
