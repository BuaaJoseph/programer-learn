import{j as r}from"./index-bcw1GFOG.js";import{L as t,S as s}from"./Summary-CzbI5rAL.js";import{K as a}from"./KeyIdea-BfDRPFR2.js";import{E as i}from"./Example-C1jxmPta.js";import{P as c}from"./Practice-DbjK1PhF.js";import{C as n}from"./Callout-Kd5ZZGSH.js";import{C as o}from"./CodeBlock-DTDRATdO.js";const l=`short-link-spring-boot-starter            <- 空壳，只声明对 autoconfigure 的依赖
  -> pom 里依赖 short-link-spring-boot-autoconfigure

short-link-spring-boot-autoconfigure      <- 真正干活的模块
  src/main/java/.../ShortLinkAutoConfiguration.java
  src/main/java/.../ShortLinkProperties.java
  src/main/java/.../ShortLinkService.java
  src/main/resources/META-INF/spring/
      org.springframework.boot.autoconfigure.AutoConfiguration.imports`,d=`// 把 application.yml 里 short-link.* 前缀的配置绑定到这个对象上
@ConfigurationProperties(prefix = "short-link")
public class ShortLinkProperties {

    // 短链域名，对应 short-link.domain
    private String domain = "https://s.demo.cn";

    // 是否启用，对应 short-link.enabled，默认开
    private boolean enabled = true;

    // getter / setter 省略（绑定靠的就是 setter）
}`,e=`@AutoConfiguration
@ConditionalOnClass(ShortLinkService.class)       // 引了本 starter 才有这个类
@EnableConfigurationProperties(ShortLinkProperties.class)
@ConditionalOnProperty(                            // short-link.enabled=true 才装配
    prefix = "short-link", name = "enabled",
    havingValue = "true", matchIfMissing = true)
public class ShortLinkAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean   // 用户自己定义了就用用户的，否则用这个默认实现
    public ShortLinkService shortLinkService(ShortLinkProperties props) {
        return new ShortLinkService(props.getDomain());
    }
}`,h=`# 文件：autoconfigure 模块的
#   src/main/resources/META-INF/spring/
#     org.springframework.boot.autoconfigure.AutoConfiguration.imports
# 把自动配置类注册进去，SpringBoot 启动时才扫得到它

com.demo.shortlink.ShortLinkAutoConfiguration`,p=`# 使用方只要引入 starter，再在 application.yml 里写配置即可
short-link:
  domain: https://s.myapp.cn
  enabled: true

# 然后在任意 Bean 里直接注入，开箱即用：
# @Autowired ShortLinkService shortLinkService;`,x=`<!-- autoconfigure 模块 pom：加上这个，IDE 才有 yml 配置提示 -->
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-configuration-processor</artifactId>
  <optional>true</optional>   <!-- optional：不传递给使用方 -->
</dependency>

<!-- 同时把对 spring-boot-autoconfigure 的依赖标成 optional，
     避免把整套 Boot 依赖硬塞给使用方，让使用方自己决定版本 -->`,g=`// 方式二：不走 imports 清单，改用 @EnableXxx 显式开启
// 适合「希望使用方手动 import、而非自动加载」的组件
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Import(ShortLinkAutoConfiguration.class)   // 直接 @Import 配置类
public @interface EnableShortLink {}

// 使用方在启动类上加 @EnableShortLink 才生效，控制权交回给使用方`,j=`// 用 ApplicationContextRunner 单测自动配置：不用真起整个应用
class ShortLinkAutoConfigurationTest {

    private final ApplicationContextRunner runner =
        new ApplicationContextRunner()
            .withConfiguration(
                AutoConfigurations.of(ShortLinkAutoConfiguration.class));

    @Test
    void 默认情况下应装配ShortLinkService() {
        runner.run(ctx ->
            assertThat(ctx).hasSingleBean(ShortLinkService.class));
    }

    @Test
    void enabled为false时不应装配() {
        runner.withPropertyValues("short-link.enabled=false")
              .run(ctx ->
                  assertThat(ctx).doesNotHaveBean(ShortLinkService.class));
    }

    @Test
    void 用户自定义Bean时应让位() {
        runner.withUserConfiguration(UserConfig.class)
              .run(ctx -> assertThat(ctx)
                  .getBean(ShortLinkService.class)
                  .isSameAs(ctx.getBean(UserConfig.class).custom()));
    }
}`;function v(){return r.jsxs(r.Fragment,{children:[r.jsx(t,{children:r.jsxs("p",{children:["上一章讲了 SpringBoot 怎么读自动配置类、怎么用条件注解决定生效。这一章把视角反过来： 假如",r.jsx("strong",{children:"你"}),"要做一个能让别人「引一下就能用」的功能组件，应该怎么打包成 ",r.jsx("em",{children:"starter"}),"？ 搞懂这件事，自动配置原理才算真正落到自己手上，面试里「你写过 starter 吗」也能答得有血有肉。"]})}),r.jsx("h2",{children:"starter 到底是什么"}),r.jsxs("p",{children:["starter（起步依赖）= ",r.jsx("strong",{children:"一组依赖"})," + ",r.jsx("strong",{children:"一套自动配置"}),"，打包在一起，目标是",r.jsx("em",{children:"开箱即用"}),"。 使用方只需引入一个坐标，不用关心内部用了哪些库、要配哪些 Bean——这些都被 starter 提前安排好了。 官方约定命名规则也值得记：官方 starter 叫 ",r.jsx("code",{children:"spring-boot-starter-xxx"}),"， 第三方的应叫 ",r.jsx("code",{children:"xxx-spring-boot-starter"}),"（前缀放自己的名字），别占用官方命名空间。"]}),r.jsx("h3",{children:"一个 starter 通常拆成两个模块"}),r.jsxs("p",{children:["规范做法是分成两个 Maven 模块：一个 ",r.jsx("code",{children:"autoconfigure"})," 模块装真正的自动配置代码和属性类； 一个 ",r.jsx("code",{children:"starter"})," 模块几乎是个空壳，只在 pom 里声明对 autoconfigure 以及相关第三方库的依赖。 这样做的好处是「依赖管理」和「配置逻辑」职责分离，使用方引 starter 就会顺带把 autoconfigure 拉进来。"]}),r.jsx(o,{lang:"text",title:"模块结构",code:l}),r.jsx(n,{variant:"info",title:"为什么非要拆两个模块",children:r.jsxs("p",{children:["只用一个模块当然也能跑，但官方坚持拆开是有道理的：使用方有时",r.jsx("strong",{children:"想要自动配置类，但不想被强加某些可选依赖"}),"。 拆开后，",r.jsx("code",{children:"autoconfigure"})," 模块把可选依赖都标成 ",r.jsx("code",{children:"optional"}),"，",r.jsx("code",{children:"starter"})," 模块再按「典型场景」把常用依赖打包进去。这样既能「引 starter 一步到位」， 也允许高级用户「只引 autoconfigure、自己挑依赖」。",r.jsx("strong",{children:"职责分离"}),"带来的是使用上的灵活度。"]})}),r.jsx("h2",{children:"自己写一个 starter 的四步"}),r.jsx("p",{children:"把上一章学到的机制反过来用，写 starter 就是这四步："}),r.jsxs("ul",{children:[r.jsxs("li",{children:[r.jsx("strong",{children:"建 autoconfigure 模块"}),"，引入 ",r.jsx("code",{children:"spring-boot-autoconfigure"})," 依赖。"]}),r.jsxs("li",{children:[r.jsx("strong",{children:"写配置属性类"}),"，用 ",r.jsx("code",{children:"@ConfigurationProperties"})," 把 application.yml 里的配置绑定成对象。"]}),r.jsxs("li",{children:[r.jsx("strong",{children:"写自动配置类"}),"，用 ",r.jsx("code",{children:"@Conditional"})," 家族控制按需装配，把功能 Bean 注册进容器。"]}),r.jsxs("li",{children:[r.jsx("strong",{children:"注册自动配置类"}),"，在 ",r.jsx("code",{children:"META-INF/spring/...AutoConfiguration.imports"}),"（老版本用 ",r.jsx("code",{children:"spring.factories"}),"）里登记它，否则 SpringBoot 根本扫不到。"]})]}),r.jsx("h3",{children:"第一关：@ConfigurationProperties 绑定 yml"}),r.jsxs("p",{children:["让组件可配置，就得把 ",r.jsx("code",{children:"application.yml"})," 里的值读进来。",r.jsx("code",{children:'@ConfigurationProperties(prefix = "short-link")'}),"会把所有 ",r.jsx("code",{children:"short-link."})," 开头的配置项，按字段名自动绑定到这个 POJO 的属性上（靠 setter 注入），还能给默认值。"]}),r.jsx(o,{lang:"java",title:"ShortLinkProperties.java",code:d}),r.jsxs(n,{variant:"info",title:"加 configuration-processor，让 yml 有自动补全",children:[r.jsxs("p",{children:["一个让 starter 显得「专业」的小细节：在 autoconfigure 模块引入",r.jsx("code",{children:"spring-boot-configuration-processor"}),"。它在编译期扫描你的",r.jsx("code",{children:"@ConfigurationProperties"})," 类，生成一份 ",r.jsx("code",{children:"META-INF/spring-configuration-metadata.json"}),"， 于是使用方在 IDE 里写 ",r.jsx("code",{children:"short-link."})," 时就有",r.jsx("strong",{children:"自动补全和注释提示"}),"，体验跟官方 starter 一样："]}),r.jsx(o,{lang:"xml",title:"autoconfigure 模块 pom（元数据 + optional）",code:x})]}),r.jsx("h3",{children:"第二关：@Conditional 家族实现按需装配"}),r.jsxs("p",{children:["自动配置类是核心。这里组合用了几个条件注解：",r.jsx("code",{children:"@ConditionalOnClass"})," 保证「引了本 starter 才生效」；",r.jsx("code",{children:"@ConditionalOnProperty"})," 让使用方能用一个开关关掉整个功能；",r.jsx("code",{children:"@ConditionalOnMissingBean"})," 给使用方留出「自定义覆盖默认实现」的余地。",r.jsx("code",{children:"@EnableConfigurationProperties"})," 则负责让上面那个属性类生效并注入容器。"]}),r.jsx(o,{lang:"java",title:"ShortLinkAutoConfiguration.java",code:e}),r.jsx("h3",{children:"第三关：把自动配置类注册进 imports 清单"}),r.jsxs("p",{children:["最容易被忘、也最常导致「我明明写了自动配置却不生效」的一步：自动配置类必须登记在清单文件里， SpringBoot 启动时的 selector 才扫得到它。新版放在",r.jsx("code",{children:"META-INF/spring/...AutoConfiguration.imports"}),"，一行一个全限定类名。"]}),r.jsx(o,{lang:"text",title:"AutoConfiguration.imports",code:h}),r.jsxs(n,{variant:"info",title:"另一条路：@EnableXxx 显式开启",children:[r.jsxs("p",{children:["注册到 imports 清单是「自动加载、引了就生效」；但有些组件作者更希望",r.jsx("strong",{children:"把开关交给使用方"}),"—— 引了依赖还得在启动类上加个 ",r.jsx("code",{children:"@EnableXxx"})," 才生效（早期很多框架都这风格，如",r.jsx("code",{children:"@EnableAsync"}),"、",r.jsx("code",{children:"@EnableScheduling"}),"）。做法是不放 imports，而是自定义注解里",r.jsx("code",{children:"@Import"})," 你的配置类："]}),r.jsx(o,{lang:"java",title:"EnableShortLink.java（显式开启）",code:g}),r.jsxs("p",{children:["选型：通用基础能力（日志、监控）适合自动加载；有副作用、需用户明确意图开启的能力（定时任务、异步线程池）适合 ",r.jsx("code",{children:"@EnableXxx"}),"。"]})]}),r.jsxs(i,{title:"自定义一个 short-link-spring-boot-starter",children:[r.jsxs("p",{children:["把上面三段拼起来，一个短链生成 starter 就成形了。使用方的体验是这样的：引入坐标 → 在 yml 里配个域名 → 直接 ",r.jsx("code",{children:"@Autowired"})," 注入 ",r.jsx("code",{children:"ShortLinkService"})," 就能用。"]}),r.jsx(o,{lang:"yaml",title:"使用方 application.yml",code:p}),r.jsxs("p",{children:["注意这套设计同时满足了三种诉求：默认就能用（",r.jsx("code",{children:"matchIfMissing"})," + 默认域名）、可配置（properties 绑定）、 可替换（",r.jsx("code",{children:"@ConditionalOnMissingBean"}),"），这正是一个「好用的」starter 该有的样子。"]})]}),r.jsx(a,{title:"写 starter 就是把自动配置原理反着用",children:r.jsxs("p",{children:["上一章你",r.jsx("strong",{children:"读"}),"别人的 XxxAutoConfiguration；这一章你",r.jsx("strong",{children:"写"}),"自己的 XxxAutoConfiguration。 底层是同一套机制：",r.jsx("em",{children:"imports 清单"}),"负责被扫到，",r.jsx("em",{children:"@Conditional"})," 负责按需生效，",r.jsx("em",{children:"@ConfigurationProperties"})," 负责接住 yml 配置。把这三个点串起来，自定义 starter 就没有秘密了。"]})}),r.jsx(n,{variant:"warn",title:"新手最常踩的两个坑",children:r.jsxs("ul",{children:[r.jsxs("li",{children:[r.jsx("strong",{children:"忘了注册 imports 文件"}),"：自动配置类写得再好，没登记就不会被加载，表现为「Bean 注入不到」。 排查时先看 imports 文件路径和类名对不对。"]}),r.jsxs("li",{children:[r.jsx("strong",{children:"自动配置类被 @ComponentScan 扫到了"}),"：自动配置类应靠 imports 清单加载， 而",r.jsx("strong",{children:"不该"}),"放在使用方启动类的扫描包路径下，否则可能重复装配或绕过条件判断。把它放到独立的包名里。"]}),r.jsxs("li",{children:[r.jsx("strong",{children:"imports 文件路径或类名写错"}),"：路径是固定的",r.jsx("code",{children:"META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports"}),"， 一个字母都不能错，类名必须是全限定名。这是「写了却不生效」的头号原因。"]}),r.jsxs("li",{children:[r.jsx("strong",{children:"把 Boot 依赖硬塞给使用方"}),"：autoconfigure 对 ",r.jsx("code",{children:"spring-boot-autoconfigure"}),"和第三方库的依赖应尽量标 ",r.jsx("code",{children:"optional"}),"，由 starter 模块或使用方决定版本，避免版本冲突（依赖地狱）。"]})]})}),r.jsxs(i,{title:"给 starter 写自动配置单元测试",children:[r.jsxs("p",{children:["专业的 starter 一定带测试。Spring Boot 提供了 ",r.jsx("code",{children:"ApplicationContextRunner"}),"， 能在",r.jsx("strong",{children:"不启动整个应用"}),"的情况下，模拟各种条件验证「该装配时装配、该让位时让位」："]}),r.jsx(o,{lang:"java",title:"ShortLinkAutoConfigurationTest.java",code:j}),r.jsx("p",{children:"三个用例正好覆盖了 starter 的三大契约：默认生效、开关可关、用户可覆盖。 这种测试比手动起两个项目对接快得多，也更适合放进 CI。"})]}),r.jsx("h2",{children:"实战 / 面试怎么答"}),r.jsxs("p",{children:["被问「怎么自己写一个 starter」，按这条线答最清楚：",r.jsx("strong",{children:"分两个模块"}),"（autoconfigure + starter 空壳）→",r.jsx("strong",{children:"@ConfigurationProperties"})," 绑定配置 → ",r.jsx("strong",{children:"@Conditional"})," 系列控制按需装配 →",r.jsx("strong",{children:"imports / spring.factories"})," 注册自动配置类。再补一句命名规范（",r.jsx("code",{children:"xxx-spring-boot-starter"}),"） 和「靠 @ConditionalOnMissingBean 让用户可覆盖」的设计考量，就很完整了。"]}),r.jsxs(c,{title:"搭一个最小自定义 starter",children:[r.jsxs("p",{children:["照着下面的最小骨架，自己动手做一个 ",r.jsx("code",{children:"short-link-spring-boot-starter"}),"： 一个属性类、一个自动配置类、一个 imports 文件，三样齐了就能在另一个项目里引用验证。"]}),r.jsx(o,{lang:"java",title:"自动配置类（最小版）",code:e}),r.jsxs("p",{children:["建好后新开一个测试项目引入它，在 yml 里改 ",r.jsx("code",{children:"short-link.domain"}),"， 注入 ",r.jsx("code",{children:"ShortLinkService"})," 打印结果；再试试把 ",r.jsx("code",{children:"short-link.enabled"})," 设为",r.jsx("code",{children:"false"}),"，确认这时注入会失败——这说明你的 ",r.jsx("code",{children:"@ConditionalOnProperty"})," 确实生效了。"]})]}),r.jsx(s,{points:["starter = 一组依赖 + 一套自动配置，打包成开箱即用的组件；第三方命名用 xxx-spring-boot-starter。","规范做法分两个模块：autoconfigure 装配置逻辑，starter 空壳只声明依赖。","@ConfigurationProperties(prefix) 把 application.yml 里对应前缀的配置绑定到 POJO，可设默认值。","@Conditional 家族（OnClass / OnProperty / OnMissingBean）实现按需装配，并给使用方留出覆盖空间。","自动配置类必须在 META-INF/spring/...AutoConfiguration.imports（旧版 spring.factories）注册，否则不生效。","常见坑：忘注册 imports、或把自动配置类放进了使用方的组件扫描路径。","加 spring-boot-configuration-processor 生成元数据，使用方写 yml 时能获得 IDE 自动补全；依赖标 optional 避免硬塞给使用方。","除 imports 自动加载外，还可用 @EnableXxx + @Import 把开启权交给使用方，适合有副作用、需明确意图的能力。","用 ApplicationContextRunner 单测自动配置，覆盖默认生效/开关可关/用户可覆盖三大契约，无需启动整个应用。"]})]})}export{v as default};
