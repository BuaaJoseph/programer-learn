import{j as e}from"./index-CBMe5udE.js";import{L as t,S as r}from"./Summary-CEfAQ4SZ.js";import{K as i}from"./KeyIdea-K3hFePn1.js";import{E as l}from"./Example-CFOi3F9j.js";import{P as o}from"./Practice-DPYESI8W.js";import{C as n}from"./Callout-3wJQ5WDp.js";import{C as s}from"./CodeBlock-D4LRiuTl.js";const d=`from openai import OpenAI

client = OpenAI()

# --- 1) 上传训练/验证文件（chat 格式的 jsonl）---
train_file = client.files.create(
    file=open('train.jsonl', 'rb'), purpose='fine-tune',
)
val_file = client.files.create(
    file=open('val.jsonl', 'rb'), purpose='fine-tune',
)

# --- 2) 创建微调任务 ---
job = client.fine_tuning.jobs.create(
    training_file=train_file.id,
    validation_file=val_file.id,
    model='gpt-4o-mini-2024-07-18',
    hyperparameters={'n_epochs': 3},
)
print('job id:', job.id)

# --- 3) 轮询状态，等它训练完 ---
import time
while True:
    job = client.fine_tuning.jobs.retrieve(job.id)
    print('status:', job.status)
    if job.status in ('succeeded', 'failed', 'cancelled'):
        break
    time.sleep(30)

# --- 4) 用训练出来的新模型 ---
if job.status == 'succeeded':
    resp = client.chat.completions.create(
        model=job.fine_tuned_model,   # 形如 ft:gpt-4o-mini:...
        messages=[{'role': 'user', 'content': '怎么退款？'}],
    )
    print(resp.choices[0].message.content)`,a=`from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import LoraConfig
from trl import SFTConfig, SFTTrainer

MODEL = 'Qwen/Qwen2.5-0.5B-Instruct'

# --- 1) 选模型 ---
model = AutoModelForCausalLM.from_pretrained(MODEL)
tok = AutoTokenizer.from_pretrained(MODEL)
if tok.pad_token is None:
    tok.pad_token = tok.eos_token

# --- 2) 备数据（chat 格式的 jsonl，含 messages 字段）---
train_ds = load_dataset('json', data_files='train.jsonl', split='train')
val_ds = load_dataset('json', data_files='val.jsonl', split='train')

# --- 3) 配训练：用 LoRA + SFTConfig ---
peft_config = LoraConfig(
    r=8, lora_alpha=16, lora_dropout=0.05,
    task_type='CAUSAL_LM', target_modules=['q_proj', 'v_proj'],
)
sft_config = SFTConfig(
    output_dir='./sft-out',
    num_train_epochs=3,
    per_device_train_batch_size=2,
    gradient_accumulation_steps=4,   # 等效 batch=8，省显存
    learning_rate=2e-4,
    logging_steps=10,
    eval_strategy='epoch',           # 每个 epoch 在 val 上评估
    save_strategy='epoch',
)

# --- 4) 训练 ---
trainer = SFTTrainer(
    model=model,
    args=sft_config,
    train_dataset=train_ds,
    eval_dataset=val_ds,
    peft_config=peft_config,
    processing_class=tok,
)
trainer.train()
trainer.save_model('./sft-out/final')

# --- 5) 评估：在留出集上看一眼输出 ---
model.eval()
for sample in val_ds.select(range(5)):
    msgs = sample['messages'][:-1]            # 去掉标准答案，只留 prompt
    ids = tok.apply_chat_template(
        msgs, add_generation_prompt=True, return_tensors='pt',
    )
    out = model.generate(ids, max_new_tokens=128)
    print(tok.decode(out[0][ids.shape[1]:], skip_special_tokens=True))`,c=`# 上线前必做：新模型 vs 基座，在同一份留出集上对比。
# 别只问「新模型好不好」，要问「它比原来更好吗」。
def ab_eval(base_model, ft_model, tok, held_out, judge):
    base_win = ft_win = tie = 0
    for sample in held_out:
        prompt = sample['messages'][:-1]
        a = generate(base_model, tok, prompt)   # 基座的回答
        b = generate(ft_model, tok, prompt)     # 微调后的回答
        verdict = judge(prompt, a, b)            # 人工或更强模型当裁判
        if verdict == 'B':   ft_win += 1
        elif verdict == 'A': base_win += 1
        else:                tie += 1
    n = len(held_out)
    print(f'微调胜 {ft_win/n:.0%}  基座胜 {base_win/n:.0%}  平 {tie/n:.0%}')
    # 微调胜率没有显著高于基座，就别上线 —— 不一样不等于更好`,h=`# 用更强的模型当「裁判」批量打分（LLM-as-a-judge）。
# 关键是给裁判一个明确的评分标准，并强制结构化输出，方便解析。
JUDGE_PROMPT = """你是严格的评审。请就【准确性】【是否符合简洁客服风格】两项，
对下面的回答打 1-5 分，并给一句理由。只输出 JSON：
{{"accuracy": <int>, "style": <int>, "reason": "<str>"}}

用户问题：{question}
待评回答：{answer}"""

def judge_one(client, question, answer):
    msg = JUDGE_PROMPT.format(question=question, answer=answer)
    resp = client.chat.completions.create(
        model='gpt-4o',                 # 裁判要比被评模型强
        messages=[{'role': 'user', 'content': msg}],
        temperature=0,                  # 评分要稳定可复现，关掉随机性
    )
    return resp.choices[0].message.content   # 解析这段 JSON 即可`;function u(){return e.jsxs(e.Fragment,{children:[e.jsx(t,{children:e.jsxs("p",{children:["前面几章把零件讲齐了：什么时候该微调、SFT 怎么回事、LoRA 怎么省、数据怎么造、对齐是什么。这一章把它们拼成一条",e.jsx("strong",{children:"能真正跑起来"}),"的流水线。我们走两条并排的路：一条是托管微调 API（把数据扔给云端，它帮你训）， 一条是本地用 HuggingFace 全家桶自己训。两条都给完整可跑的代码，你按手头的资源选一条照着走即可。"]})}),e.jsx("h2",{children:"五步骨架"}),e.jsx("p",{children:"不管走哪条路，微调都是同样的五步，记住这个骨架，剩下的只是填代码："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"选模型"}),"——挑一个合适大小的基座；先从小模型起步，跑通了再放大。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"备数据"}),"——把第 4 章造好的 chat 格式 jsonl 准备好，train 和 val 分开。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"配训练"}),"——设好那几个旋钮（学习率、epochs、batch、LoRA 配置）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"训练"}),"——跑起来，盯着 train/val 两条 loss 曲线。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"评估"}),"——别只看 loss，要真的拿没见过的输入让它答，看效果。"]})]}),e.jsxs("p",{children:["这五步看似线性，实际是个",e.jsx("strong",{children:"循环"}),"。绝大多数情况下你不会一次就训对：第一轮跑完评估，发现某类问题答得差， 于是回到「备数据」补样本，再训一轮。所以把每一步都做成可重复、可记录的脚本至关重要——你迭代的不是一次训练， 而是「训练→评估→改数据→再训练」这个圈。圈转得越快，模型收敛到可用状态就越快，而圈的转速取决于你的流水线有多自动化。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"对比维度"}),e.jsx("th",{children:"托管 API"}),e.jsx("th",{children:"本地 PEFT"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"数据去向"}),e.jsx("td",{children:"上传给第三方"}),e.jsx("td",{children:"不出本地"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能否拿到权重"}),e.jsx("td",{children:"不能"}),e.jsx("td",{children:"能"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"基础设施"}),e.jsx("td",{children:"零运维"}),e.jsx("td",{children:"自备显卡/环境"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"成本模型"}),e.jsx("td",{children:"按训练量+调用量收费"}),e.jsx("td",{children:"一次性算力，后续自托管"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"上手速度"}),e.jsx("td",{children:"最快"}),e.jsx("td",{children:"需配环境"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"适合谁"}),e.jsx("td",{children:"快速验证、数据可外发"}),e.jsx("td",{children:"数据敏感、长期迭代、控成本"})]})]})]}),e.jsx("h2",{children:"路线一：托管微调 API"}),e.jsxs("p",{children:["如果你不想碰显卡和训练细节，托管方案最省心。以 OpenAI fine-tuning 为例，整个流程就三个动作：",e.jsx("strong",{children:"上传 jsonl → 创建 fine_tuning job → 用训练出来的新模型"}),"。云端帮你搞定算力、调度、checkpoint， 你只管准备数据和等结果。它的代价是：数据要交给第三方、模型权重你拿不到、按量收费。"]}),e.jsx(l,{title:"托管路线的产物",children:e.jsxs("p",{children:["训练成功后，你会拿到一个形如 ",e.jsx("code",{children:"ft:gpt-4o-mini:your-org::abc123"})," 的模型名。之后调用时把",e.jsx("code",{children:"model"})," 换成这个名字，其余和普通 API 调用完全一样——这就是它最大的好处：",e.jsx("strong",{children:"无缝接入"}),"。"]})}),e.jsx("h2",{children:"路线二：本地 HuggingFace + PEFT + trl"}),e.jsxs("p",{children:["如果你要数据不出门、要拿到权重、或想省钱，就自己训。技术栈是：",e.jsx("code",{children:"transformers"})," 加载模型、",e.jsx("code",{children:"peft"})," 挂 LoRA、",e.jsx("code",{children:"trl"})," 的 ",e.jsx("em",{children:"SFTTrainer"})," 把训练循环封装好。SFTTrainer 替你处理了 chat 模板套用、label 掩码、batch 拼接这些第 2 章里要手写的脏活，你只需把数据和配置交给它。"]}),e.jsx(i,{title:"SFTTrainer 替你做了什么",children:e.jsxs("p",{children:["还记得第 2 章那个手写的训练循环和 label 掩码吗？",e.jsx("strong",{children:"SFTTrainer 把这些全包了"}),"：它认识 chat 格式的",e.jsx("code",{children:"messages"}),"，自动套用模型的对话模板、自动把 prompt 段的 label 屏蔽掉、自动算只在 assistant 段累加的 loss、 自动跑前向反向更新。再配上 ",e.jsx("code",{children:"peft_config"}),"，它连 LoRA 都帮你挂好。你写几十行配置，就等于手写几百行训练代码。 这就是为什么生产里几乎没人手写训练循环——但理解第 2 章那套底层，你才知道它在替你做什么、出错时去哪查。"]})}),e.jsx(n,{variant:"warn",title:"避坑清单",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"先小后大"}),"——先用 0.5B 模型和几十条数据把全流程跑通，确认 loss 在降，再换大模型和全量数据，别一上来就烧大钱。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"设好 pad_token"}),"——很多模型默认没有 pad token，不设会在拼 batch 时报错，常见做法是用 eos_token 顶上。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"盯住 val loss"}),"——train loss 一直降不代表学好了，val loss 触底回升就是过拟合的信号，该减 epoch 或加数据。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"学习率别照搬"}),"——LoRA 用的学习率（如 2e-4）比全量微调（如 1e-5）大得多，两者不能混用。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"显存不够用梯度累积"}),"——把 batch 调小、accumulation 调大，等效大 batch 又不爆显存。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"留好随机种子和配置"}),"——每次训练记录种子、超参、数据版本，否则效果好了你都复现不出来。"]})]})}),e.jsx("h2",{children:"三层评估"}),e.jsx("p",{children:"训练跑完最危险的事，是只看着 loss 下降就以为成功了。loss 低只说明它在训练分布上拟合得好，不代表它真的有用、没学坏。 评估要分三层，从便宜到贵："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"自动指标"}),"——最便宜，能批量跑：分类任务看准确率，生成任务看 BLEU/ROUGE 或格式合规率。快速但粗糙，只能筛掉明显的烂。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"留出集"}),"（held-out）——拿一份训练时",e.jsx("strong",{children:"完全没碰过"}),"的数据，让模型逐条作答，人工或用更强的模型当裁判打分。 这是最能反映「在新数据上表现」的一层。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"人工抽检"}),"——最贵但不可省：人亲眼读一批真实场景的输出，看语气、看边界、看有没有谄媚或过度拒绝这类对齐副作用。 数字看不出来的问题，眼睛能看出来。"]})]}),e.jsxs("p",{children:["三层里最容易被偷懒跳过、却最关键的是",e.jsx("strong",{children:"「和基座对比」"}),"。新模型答得不错，不代表它比原来的基座更好—— 也许基座本来就答得一样好，你白训了一场。正确的评估姿势是 A/B：同一份留出集，基座和微调后各答一遍，让裁判逐对判优劣， 统计微调的",e.jsx("strong",{children:"胜率"}),"。胜率没有显著超过基座，就别上线。记住一句话：",e.jsx("strong",{children:"「不一样」不等于「更好」。"})]}),e.jsx(s,{lang:"python",title:"ab_eval.py",code:c}),e.jsxs("p",{children:["人工抽检最可靠但最贵，规模上不去。一个折中是 ",e.jsx("strong",{children:"LLM-as-a-judge"}),"：用一个比被评模型更强的模型当裁判批量打分。 要点有三：给裁判明确的评分维度（别只说「打个分」）、强制结构化输出方便解析、把 temperature 设为 0 保证评分可复现。 它不能完全替代人工（裁判也有偏见，比如偏爱长答案），但能把人工的工作量从「逐条读」降到「抽检裁判判得准不准」。"]}),e.jsx(s,{lang:"python",title:"llm_judge.py",code:h}),e.jsx(n,{variant:"warn",title:"评估里的隐形陷阱",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"留出集泄漏"}),"——评估集如果和训练集有重叠或近似重复（见第 4 章），分数会虚高，你会高估模型。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"只测训练分布"}),"——评估集只覆盖训练里见过的问法，测不出模型在真实长尾输入上的崩溃。刻意放一些「没训过的类型」进去。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"裁判偏好"}),"——LLM 裁判倾向于给更长、更礼貌、格式更花的回答打高分，可能和你真正想要的「简洁」背道而驰。校准裁判的标准。"]})]})}),e.jsx("h2",{children:"这对做 Agent / 工程实践意味着什么"}),e.jsxs("p",{children:["把微调当成一条",e.jsx("strong",{children:"可重复的流水线"}),"，而不是一次性的炼丹。两条路线的取舍很清楚：托管 API 适合不想碰基础设施、 数据可外发、要快速验证的场景；本地 PEFT 适合数据敏感、要掌控权重、要长期迭代或控成本的场景。 无论哪条，真正决定成败的还是前面那几章——数据质量、决策是否该微调、评估是否扎实。代码只是把决定落地的最后一公里。 微调上线后，记得保留对照的基座版本，用同一套留出集持续对比，确认新模型确实更好，而不是只是「不一样」。"]}),e.jsxs(o,{title:"两条路线，各跑一遍",children:[e.jsx("p",{children:"路线一，托管微调 API：上传 jsonl、创建任务、轮询、用新模型，四步一气呵成："}),e.jsx(s,{lang:"python",title:"hosted_finetune.py",code:d}),e.jsx("p",{children:"路线二，本地 SFTTrainer：选模型、备数据、配 LoRA、训练、在留出集上评估，五步走完："}),e.jsx(s,{lang:"python",title:"local_sft.py",code:a}),e.jsx("p",{children:"建议先跑本地路线的小模型版把流程摸熟（不花钱、看得见每一步），再决定要不要上托管或放大规模。"})]}),e.jsx(r,{points:["微调五步骨架：选模型→备数据→配训练→训练→评估，两条路线都套这个框架。","托管路线（如 OpenAI fine-tuning）：上传 jsonl→create job→用 ft: 开头的新模型，省心但数据外发、拿不到权重。","本地路线：transformers + peft（LoRA）+ trl 的 SFTTrainer，数据不出门、拿得到权重、可控成本。","SFTTrainer 替你处理了 chat 模板、label 掩码、loss 计算和训练循环，几十行配置顶手写几百行。","避坑：先小后大、设 pad_token、盯 val loss、LoRA 学习率别照搬、显存不够用梯度累积、记录种子与配置。","三层评估缺一不可：自动指标筛烂、留出集看新数据表现、人工抽检揪出 loss 看不见的问题。"]})]})}export{u as default};
