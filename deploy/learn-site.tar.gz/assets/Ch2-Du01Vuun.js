import{j as n}from"./index-I8-WI4LI.js";import{L as i,S as l}from"./Summary-BMIdTn04.js";import{K as s}from"./KeyIdea-Xbvwo63C.js";import{C as r}from"./Callout-ZgrsOCpc.js";import{C as e}from"./CodeBlock-CK6ncc4Q.js";import{E as t}from"./Example-CPIFvVrE.js";import{P as d}from"./Practice-Cum9V7VB.js";import{P as o}from"./PyRunner-ke7trKpn.js";const c=`# print 的几种花样
name = "小明"
age = 18

# 1) 多个参数，默认用空格隔开
print("姓名：", name, "年龄：", age)

# 2) 自定义分隔符
print("2026", "06", "18", sep="-")

# 3) f-string：把变量直接嵌进字符串里
print(f"我是{name}，今年{age}岁，明年{age + 1}岁")

# 4) 转义换行 \\n：一句话里换行
print("第一行\\n第二行")`,h='print("Hello, World!")',x=`# 假设你把文件存成 hello.py，在终端里进入它所在的文件夹，运行：
python hello.py`,j='print("我", "爱", "Python")',p="我 爱 Python",a=`print("2026", "06", "18", sep="-")
print("没有换行", end="")
print("，它们连在一起了")`,y=`2026-06-18
没有换行，它们连在一起了`,g=`print("第一行")
print("第二行")
print("上一行\\n下一行")`,m=`第一行
第二行
上一行
下一行`,P=`# 这是一条注释，Python 会完全忽略它
print("代码会执行")  # 行尾也能写注释：右边这部分被忽略
# print("这一行被注释掉了，不会运行")`,f="代码会执行",E=`if 10 > 5:
    print("10 比 5 大")   # 这一行缩进了 4 个空格，属于 if 内部
print("这句永远会执行")    # 没缩进，不属于 if`,C=`10 比 5 大
这句永远会执行`,u=`if 10 > 5:
print("忘了缩进")`,H=`  File "hello.py", line 2
    print("忘了缩进")
    ^
IndentationError: expected an indented block after 'if' statement on line 1`,W='print("少了一个右括号"',v=`  File "hello.py", line 1
    print("少了一个右括号"
         ^
SyntaxError: '(' was never closed`;function A(){return n.jsxs("article",{children:[n.jsxs(i,{children:["准备工作做完了，这一章我们真正写出并运行第一个程序：经典的「Hello, World!」。 然后学会两种运行方式（REPL 临时试 vs 存成文件正式跑）、",n.jsx("code",{children:"print"})," 的几个常用花样、 怎么写注释，以及 Python 一个很重要的特点——用「缩进」来组织代码。最后认识两个新手最常遇到的报错。"]}),n.jsx("h2",{children:"一、第一个程序：Hello, World!"}),n.jsx("p",{children:"几乎所有编程教程的第一个程序都是让屏幕显示「Hello, World!」。在 Python 里，它只要一行："}),n.jsx(e,{lang:"python",title:"史上最短的第一个程序",code:h}),n.jsx(t,{title:"运行结果",children:n.jsx(e,{lang:"text",title:"运行结果",code:"Hello, World!"})}),n.jsxs("p",{children:["这里的 ",n.jsx("code",{children:"print"})," 是 Python 内置的「打印」功能（叫「函数」），作用就是把括号里的内容显示到屏幕上。 要显示的文字用",n.jsx("strong",{children:"引号"}),"包起来（单引号双引号都行），这种被引号包住的文字叫「字符串」。"]}),n.jsx("h2",{children:"二、两种运行方式"}),n.jsx("h3",{children:"方式一：在 REPL 里临时试"}),n.jsxs("p",{children:["上一章学过的交互式环境（终端输入 ",n.jsx("code",{children:"python"})," 进入）就能直接跑："]}),n.jsx(e,{lang:"python",title:"在 REPL 里直接敲",code:`>>> print("Hello, World!")
Hello, World!`}),n.jsx("p",{children:"这种方式适合快速试一两行，但程序一关就没了，不能保存。"}),n.jsx("h3",{children:"方式二：存成 .py 文件再运行（正式做法）"}),n.jsxs("p",{children:["真正写程序时，我们会把代码保存成一个以 ",n.jsx("code",{children:".py"})," 结尾的文件。步骤："]}),n.jsxs("ol",{children:[n.jsxs("li",{children:["用编辑器（如 VS Code）新建一个文件，写上 ",n.jsx("code",{children:'print("Hello, World!")'}),"。"]}),n.jsxs("li",{children:["保存为 ",n.jsx("code",{children:"hello.py"}),"。"]}),n.jsx("li",{children:"打开终端，进入这个文件所在的文件夹，运行下面的命令。"})]}),n.jsx(e,{lang:"bash",title:"运行一个 .py 文件",code:x}),n.jsxs(r,{variant:"tip",children:[n.jsx("code",{children:".py"})," 是 Python 文件的标准后缀。文件名最好用英文字母、数字和下划线，别用空格和中文，避免麻烦。"]}),n.jsx("h2",{children:"三、print 的更多用法"}),n.jsx("h3",{children:"1. 一次打印多个内容"}),n.jsxs("p",{children:[n.jsx("code",{children:"print"})," 括号里可以放多个内容，用逗号隔开，它们之间默认用一个",n.jsx("strong",{children:"空格"}),"连接："]}),n.jsx(e,{lang:"python",title:"print 多个参数",code:j}),n.jsx(t,{title:"运行结果",children:n.jsx(e,{lang:"text",title:"运行结果",code:p})}),n.jsx("h3",{children:"2. 自定义分隔符和结尾"}),n.jsxs("p",{children:["默认每个 ",n.jsx("code",{children:"print"})," 之间用空格分隔、末尾自动换行。可以用 ",n.jsx("code",{children:"sep"}),"（分隔符）和",n.jsx("code",{children:"end"}),"（结尾）来改："]}),n.jsx(e,{lang:"python",title:"sep 和 end",code:a}),n.jsx(t,{title:"运行结果",children:n.jsx(e,{lang:"text",title:"运行结果",code:y})}),n.jsxs("p",{children:["第一行用 ",n.jsx("code",{children:'sep="-"'})," 把日期连成 ",n.jsx("code",{children:"2026-06-18"}),"；后两行用 ",n.jsx("code",{children:'end=""'}),"（空字符串）取消了自动换行，所以它俩接在了一起。"]}),n.jsx("h3",{children:"3. 换行符 \\\\n"}),n.jsxs("p",{children:["每个 ",n.jsx("code",{children:"print"})," 默认会换行。如果想在一句话中间换行，用",n.jsx("strong",{children:"换行符"})," ",n.jsx("code",{children:"\\n"}),"："]}),n.jsx(e,{lang:"python",title:"换行",code:g}),n.jsx(t,{title:"运行结果",children:n.jsx(e,{lang:"text",title:"运行结果",code:m})}),n.jsx("h2",{children:"四、注释：写给人看的说明"}),n.jsxs(s,{children:["注释是写在代码里、给人读的说明文字，Python 运行时会",n.jsx("strong",{children:"完全忽略"}),"它们。 在 Python 里，以 ",n.jsx("code",{children:"#"})," 号开头的内容就是注释。"]}),n.jsx(e,{lang:"python",title:"注释怎么写",code:P}),n.jsx(t,{title:"运行结果",children:n.jsx(e,{lang:"text",title:"运行结果",code:f})}),n.jsxs(r,{variant:"tip",children:["注释有两个用途：① 解释代码「为什么这么写」，方便日后自己和别人看懂； ② 临时「关掉」某行代码——在它前面加个 ",n.jsx("code",{children:"#"}),"，它就不执行了，调试时很常用。"]}),n.jsx("h2",{children:"五、为什么 Python 靠「缩进」"}),n.jsxs("p",{children:["很多语言（比如 Java、C）用",n.jsx("strong",{children:"花括号"})," ",n.jsx("code",{children:"{ }"})," 来圈出「哪些代码属于一组」。 Python 不用花括号，而是用",n.jsx("strong",{children:"缩进"}),"（行首的空格）来表达这种从属关系。"]}),n.jsx(e,{lang:"python",title:"缩进决定代码归属",code:E}),n.jsx(t,{title:"运行结果",children:n.jsx(e,{lang:"text",title:"运行结果",code:C})}),n.jsxs("p",{children:["看上面：",n.jsx("code",{children:"if"})," 这行末尾有个冒号 ",n.jsx("code",{children:":"}),"，下一行",n.jsx("strong",{children:"缩进"}),"的",n.jsx("code",{children:"print"})," 就属于 ",n.jsx("code",{children:"if"})," 的「内部」，只有条件成立才执行； 而没缩进的那行 ",n.jsx("code",{children:"print"})," 不属于 ",n.jsx("code",{children:"if"}),"，总会执行。"]}),n.jsxs(r,{variant:"warn",title:"缩进规则",children:["Python 官方推荐缩进用 ",n.jsx("strong",{children:"4 个空格"}),"。同一组代码缩进必须一致，不能一会儿 2 格一会儿 4 格。 VS Code 等编辑器一般会帮你自动缩进，按 Tab 键也行（编辑器通常会转成空格）。"]}),n.jsx("h2",{children:"六、新手最常见的两个报错"}),n.jsx("h3",{children:"IndentationError（缩进错误）"}),n.jsxs("p",{children:["该缩进的地方没缩进，就会报这个错。比如 ",n.jsx("code",{children:"if"})," 后面那行忘了缩进："]}),n.jsx(e,{lang:"python",title:"错误示范：忘了缩进",code:u}),n.jsx(t,{title:"运行结果（报错）",children:n.jsx(e,{lang:"text",title:"运行结果",code:H})}),n.jsxs("p",{children:["看到 ",n.jsx("code",{children:"IndentationError"})," 就检查：冒号下面那行有没有正确缩进。"]}),n.jsx("h3",{children:"SyntaxError（语法错误）"}),n.jsx("p",{children:"代码「写得不符合语法」，比如括号、引号没配对。下面少了一个右括号："}),n.jsx(e,{lang:"python",title:"错误示范：括号没闭合",code:W}),n.jsx(t,{title:"运行结果（报错）",children:n.jsx(e,{lang:"text",title:"运行结果",code:v})}),n.jsxs(r,{variant:"tip",children:["报错不可怕！Python 的报错信息会告诉你",n.jsx("strong",{children:"哪个文件、第几行、什么类型"}),"的错。 看到报错，先看最后一行的错误类型，再看它指出的行号，问题往往就在那附近。"]}),n.jsxs("p",{children:[n.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」，看看结果。"]}),n.jsx(o,{initialCode:c}),n.jsx(d,{title:"动手练一练",children:n.jsxs("ol",{children:[n.jsxs("li",{children:["新建 ",n.jsx("code",{children:"hello.py"}),"，写一行 ",n.jsx("code",{children:'print("Hello, World!")'}),"，用 ",n.jsx("code",{children:"python hello.py"})," 跑起来。"]}),n.jsxs("li",{children:["用一个 ",n.jsx("code",{children:"print"})," 同时打印你的姓、名两个字符串，看它们之间是不是有空格。"]}),n.jsxs("li",{children:["故意把某个 ",n.jsx("code",{children:"print"})," 的右括号删掉，运行看看报的是不是 ",n.jsx("code",{children:"SyntaxError"}),"，再把它改回来。"]})]})}),n.jsx(l,{points:["print 把内容显示到屏幕上，要显示的文字（字符串）用引号包起来。","运行方式两种：REPL 临时试（关了就没）；存成 .py 文件用 python 文件名.py 正式运行。","print 可用逗号打印多个内容（默认空格分隔），用 sep 改分隔符、end 改结尾，\\n 表示换行。","以 # 开头的是注释，运行时被忽略，用来解释代码或临时关掉某行。","Python 用缩进（推荐 4 空格）代替花括号来组织代码，冒号下面要缩进。","两个高频报错：IndentationError（缩进不对）、SyntaxError（语法/括号引号没配对），看报错的行号和类型来定位。"]})]})}export{A as default};
