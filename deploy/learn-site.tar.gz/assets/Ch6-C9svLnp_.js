import{j as e}from"./index-4Gnvy4Pk.js";import{L as t,S as s}from"./Summary-8JJJpz6g.js";import{K as n}from"./KeyIdea-6LAlCalL.js";import{C as o}from"./Callout-BfcJpdBu.js";import{C as r}from"./CodeBlock-Bq_ox3wh.js";import{E as c}from"./Example-DoUEk5_G.js";const d=`// memory/types.ts —— 学习型记忆的结构（精简自 DeerFlow 的 memory.json）
export interface Memory {
  user: {
    workContext: string       // 角色/项目/技术栈（1-3 句）
    preferences: string       // 沟通/工具/风格偏好
    topOfMind: string         // 最近在关注的几件事
  }
  facts: { content: string; category: 'preference' | 'context' | 'correction'; confidence: number }[]
  updatedAt: string
}`,i=`// middleware/memory.ts —— 读侧：每轮把记忆注入为「系统提醒」，而不是写进 system prompt
export function memoryMiddleware(store: MemoryStore): Middleware {
  let injected = false
  return {
    name: 'memory',
    async beforeAgent(c) {
      if (injected) return
      const mem = await store.load(c.ctx.cwd)
      if (!mem) return
      // 注入到「第一条用户消息之前」的一条隐藏提醒里
      c.messages.unshift({ role: 'user', content: [{ type: 'text',
        text: \`<系统提醒>\\n<记忆>\\n\${renderMemory(mem)}\\n</记忆>\\n</系统提醒>\` }] })
      injected = true
    },
    // 写侧见下：任务结束后异步归纳
    async afterAgent(c) {
      queueMemoryUpdate(store, c.ctx.cwd, recentTurns(c.messages))
    },
  }
}`,l=`// memory/updater.ts —— 写侧：用一次「后台 LLM 调用」把对话归纳进记忆
const MEMORY_UPDATE_PROMPT = \`你是记忆管理器。读「当前记忆」和「最近对话」，输出更新后的记忆。
- 提取关于用户的稳定事实、偏好、纠正（带 category 与 confidence）
- 用户纠正过你的地方，记为 category="correction"，confidence>=0.95
- 只保留对未来对话有用的信息；与新信息矛盾的旧事实要删除
- 不要记录一次性的、会话临时的东西（比如某次上传的文件）
只返回 JSON：{ user:{...}, facts:[...] }\`

export async function updateMemory(store, cwd, conversation) {
  const current = await store.load(cwd)
  // 注意：这是「后台」调用，不阻塞用户的下一句——去抖动后再跑
  const json = await provider.completeJSON(MEMORY_UPDATE_PROMPT, { current, conversation })
  await store.save(cwd, { ...json, updatedAt: new Date().toISOString() })
}`;function y(){return e.jsxs("article",{children:[e.jsxs(t,{children:["第 4 卷的 ",e.jsx("code",{children:"AGENTS.md"})," 是",e.jsx("strong",{children:"静态记忆"}),"——你手写项目约定，forge 启动时读进来。但它不会「学习」：你纠正过它十次的同一个错， 下次它照犯。DeerFlow 有一套",e.jsx("strong",{children:"学习型记忆"}),"：任务结束后用一次后台 LLM 调用把对话归纳成结构化记忆，下次自动注入。 这一章给 forge 补上这个能「越用越懂你」的记忆系统。"]}),e.jsx("h2",{children:"一、两种记忆，互补而非替代"}),e.jsx("div",{style:{overflowX:"auto"},children:e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{}),e.jsx("th",{children:"AGENTS.md（第 4 卷）"}),e.jsx("th",{children:"学习型记忆（本章）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"谁写的"}),e.jsx("td",{children:"你手写"}),e.jsx("td",{children:"forge 自己归纳"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"内容"}),e.jsx("td",{children:"项目约定、构建命令"}),e.jsx("td",{children:"你的偏好、被纠正过的事实"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"更新"}),e.jsx("td",{children:"手动改文件"}),e.jsx("td",{children:"每次任务后自动更新"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"对应 DeerFlow"}),e.jsx("td",{children:"SOUL.md / 项目配置"}),e.jsxs("td",{children:[e.jsx("code",{children:"agents/memory/"})," 子系统"]})]})]})]})}),e.jsx("h2",{children:"二、记忆长什么样"}),e.jsx(r,{lang:"ts",title:"memory/types.ts",code:d}),e.jsxs("p",{children:["结构精简自 DeerFlow 的 ",e.jsx("code",{children:"memory.json"}),"（它还分 history 的近期/早期/长期等小节）。关键是带 ",e.jsx("code",{children:"category"})," 和",e.jsx("code",{children:"confidence"}),"：尤其是 ",e.jsx("code",{children:"correction"})," 类——「用户纠正过我什么」是最该牢记的高价值信息。"]}),e.jsx("h2",{children:"三、读侧：注入为「系统提醒」，而不是塞进 system prompt"}),e.jsx(r,{lang:"ts",title:"middleware/memory.ts",code:i}),e.jsxs(n,{title:"为什么不写进 system prompt（一个重要细节）",children:["直觉上记忆该放 system prompt。但 DeerFlow 故意",e.jsx("strong",{children:"不这么做"}),"：它让 system prompt 保持",e.jsx("strong",{children:"完全静态"}),"（跨用户/会话一字不差）， 把记忆和日期改由 ",e.jsx("code",{children:"DynamicContextMiddleware"})," 每轮注入到第一条用户消息前的 ",e.jsx("code",{children:"<system-reminder>"})," 里。 原因是 ",e.jsx("strong",{children:"prefix-cache"}),"：system prompt 不变，模型侧的前缀缓存才能命中，省钱省延迟。我们给 forge 抄这个做法—— 记忆走 ",e.jsx("code",{children:"beforeAgent"})," 注入消息流，而不是进 ",e.jsx("code",{children:"buildSystemPrompt"}),"。"]}),e.jsx("h2",{children:"四、写侧：后台 LLM 归纳，不阻塞用户"}),e.jsx(r,{lang:"ts",title:"memory/updater.ts",code:l}),e.jsxs("p",{children:["记忆不是 Agent 主动写的，而是任务结束后（",e.jsx("code",{children:"afterAgent"}),"）把「最近对话」入队，",e.jsx("strong",{children:"去抖动后在后台"}),"用一个专门的 memory-update prompt 调 LLM 归纳成 JSON 写回。关键是",e.jsx("strong",{children:"不能阻塞用户的下一句"}),"——对应 DeerFlow 的",e.jsx("code",{children:"MemoryMiddleware.after_agent"})," + ",e.jsx("code",{children:"MemoryUpdateQueue"})," + 专用线程池的异步去抖动写回。"]}),e.jsxs(o,{variant:"warn",title:"只记该记的",children:["DeerFlow 的更新 prompt 里有一条很实际的规则：",e.jsx("strong",{children:"不要把「上传文件」之类会话临时的东西写进长期记忆"}),"（它们下次就不在了，记了反而误导）。 我们也照抄。记忆要的是「稳定偏好 + 被纠正的事实」，不是流水账。"]}),e.jsxs(c,{title:"越用越懂你",children:["第一次你纠正 forge：「提交信息别写那么啰嗦，一行就行」。任务结束后这条被归纳成",e.jsx("code",{children:'{ content: "用户偏好一行式 commit message", category: "preference", confidence: 0.95 }'}),"。 下次新会话，记忆注入后 forge 一上来就用一行式提交——你不用再说第二遍。这就是静态 AGENTS.md 给不了的东西。"]}),e.jsx(s,{points:["AGENTS.md 是手写静态记忆，不会学习；学习型记忆（对应 DeerFlow agents/memory/）任务后自动归纳、越用越懂你，两者互补。","记忆结构带 category/confidence，尤其重视 correction 类——「用户纠正过我什么」是最高价值信息。","读侧走 beforeAgent 注入为 <系统提醒> 消息而非 system prompt——为了让 system prompt 保持静态、命中 prefix-cache（抄 DeerFlow DynamicContextMiddleware）。","写侧在 afterAgent 入队、去抖动后后台 LLM 归纳成 JSON 写回，绝不阻塞用户下一句；只记稳定偏好/纠正，不记会话临时的东西。"]})]})}export{y as default};
