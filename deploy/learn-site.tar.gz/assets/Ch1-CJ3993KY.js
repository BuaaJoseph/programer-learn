import{j as n}from"./index-D-xLQIFq.js";import{L as s,S as t}from"./Summary-YJHOQU45.js";import{K as i}from"./KeyIdea-D9fwNcvs.js";import{C as r}from"./Callout-Bp0vMJus.js";import{C as e}from"./CodeBlock-DX_K20PW.js";import{E as d}from"./Example-JUHxJgjQ.js";import{A as l}from"./ArchDiagram-DAyu_spo.js";import"./Figure-BR5aUEEr.js";const c=`from agents import Agent, function_tool

@function_tool
def get_weather(city: str) -> str:
    """查询某城市天气（示例）。"""
    return f"{city}：晴，26°C"

agent = Agent(
    name="天气助手",
    instructions="你是天气助手，用中文简洁回答；需要时调用工具。",
    model="gpt-4.1",
    tools=[get_weather],
)`,o=`from agents import Runner

# 异步：在 async 函数里 await
result = await Runner.run(agent, "北京今天天气怎么样？")
print(result.final_output)

# 同步：脚本里一行跑通
result = Runner.run_sync(agent, "上海呢？")
print(result.final_output)`,h=`billing_agent = Agent(name="账单专员", instructions="处理账单问题")
refund_agent  = Agent(name="退款专员", instructions="处理退款问题")

triage_agent = Agent(
    name="分诊台",
    instructions="判断问题归属，交接给对应专员。",
    handoffs=[billing_agent, refund_agent],   # 列出可交接目标
)`,a=`from agents import (
    Agent, GuardrailFunctionOutput, RunContextWrapper, input_guardrail,
)

@input_guardrail
async def block_other_user(
    ctx: RunContextWrapper, agent: Agent, user_input,
) -> GuardrailFunctionOutput:
    text = str(user_input)
    return GuardrailFunctionOutput(
        output_info={"reason": "疑似越权访问"},
        tripwire_triggered="别人" in text,   # 命中即中断
    )

agent = Agent(
    name="客服",
    instructions="...",
    input_guardrails=[block_other_user],
)`,x=`from agents import output_guardrail, GuardrailFunctionOutput

@output_guardrail
async def no_internal_leak(ctx, agent, output) -> GuardrailFunctionOutput:
    text = str(output)
    leaked = any(k in text for k in ["内部成本", "进价", "API_KEY"])
    return GuardrailFunctionOutput(
        output_info={"leaked": leaked},
        tripwire_triggered=leaked,   # 回答里泄露敏感信息就拦下
    )`,j=`from agents import Runner, SQLiteSession

session = SQLiteSession("user-123")          # 用一个 session_id 标识这轮对话
await Runner.run(agent, "我叫小明", session=session)
result = await Runner.run(agent, "我叫什么？", session=session)
print(result.final_output)   # 自动带上历史 → "你叫小明"`,u=`from agents import function_tool

@function_tool
def lookup_order(order_id: str) -> str:
    """根据订单号查询订单状态。"""   # docstring → 工具描述
    return f"订单 {order_id}：已支付，预计 3 天内发货。"
# 函数签名(order_id: str) 自动生成 JSON Schema 参数，无需手写`,g=`from openai import AsyncOpenAI
from agents import (
    set_default_openai_client, set_default_openai_api, set_tracing_disabled,
)

client = AsyncOpenAI(base_url="https://your-endpoint/v1", api_key="...")
set_default_openai_client(client, use_for_tracing=False)
set_default_openai_api("chat_completions")   # 第三方端点只支持 Chat Completions
set_tracing_disabled(True)                    # tracing 上报需 OpenAI key，关掉`;function R(){return n.jsxs("article",{children:[n.jsx(s,{children:"OpenAI Agents SDK 是 OpenAI 官方推出的轻量级多 Agent 编排框架。它的口号是「极少抽象」： 不发明庞大的 DSL，只给你 Agent、Runner、Handoff、Guardrail、Session、Tracing 这几个原语， 用纯 Python 就能拼出可路由、可分诊、带安全护栏、可观测的多 Agent 系统。本章把这套 「少抽象」的设计哲学与每个原语逐个讲透，下一章再用一个能跑的客服分诊系统全部落地。"}),n.jsx("h2",{children:"一、起源：从实验性 Swarm 到生产级继任者"}),n.jsxs("p",{children:["2024 年 OpenAI 放出过一个叫 ",n.jsx("strong",{children:"Swarm"})," 的实验性项目，目的是验证一个朴素的想法： 多 Agent 协作其实不需要复杂的编排引擎，用「Agent + Handoff」两个原语就够了。Swarm 当时 定位是「教学 / 实验」，明确声明不用于生产。"]}),n.jsxs("p",{children:["Agents SDK 就是 Swarm 的",n.jsx("strong",{children:"生产级继任者"}),"：它完整继承了 Swarm 的核心原语 （Agent 与 Handoff），并补齐了真正上生产所缺的工程能力——",n.jsx("strong",{children:"Guardrails（护栏）、 Tracing（可观测）、Sessions（多轮状态）"}),"。换句话说，Swarm 证明了「少抽象」可行， Agents SDK 把它做成了可靠的工程框架。"]}),n.jsx("h3",{children:"设计哲学：三条铁律"}),n.jsxs("ul",{children:[n.jsxs("li",{children:[n.jsx("strong",{children:"少量原语"}),"：能用一个概念解决就绝不引入第二个。你不需要先学一周框架才能写第一个 Agent。"]}),n.jsxs("li",{children:[n.jsx("strong",{children:"Python-first"}),"：工具就是普通 Python 函数，控制流就是普通 Python；不强迫你用图、节点、YAML。"]}),n.jsxs("li",{children:[n.jsx("strong",{children:"不发明 DSL"}),"：没有专有的图描述语言、没有声明式状态机语法，能力靠组合原语得到。"]})]}),n.jsx("h3",{children:"版本与活跃度（2026 年）"}),n.jsxs("ul",{children:[n.jsxs("li",{children:["包名 ",n.jsx("code",{children:"openai-agents"}),"，最新版本约 ",n.jsx("strong",{children:"0.17.x"}),"（2026 年 6 月），",n.jsx("strong",{children:"月度高频发版"}),"。"]}),n.jsxs("li",{children:["GitHub 约 ",n.jsx("strong",{children:"2.7 万 star"}),"，是当前最主流的官方多 Agent 框架之一。"]})]}),n.jsxs(i,{children:["Agents SDK 的核心信念：",n.jsx("strong",{children:"用少量原语拼出多 Agent 系统"}),"。 记住一句话——「Agent 是角色、Handoff 是交接、Guardrail 是护栏、Session 是记忆、 Runner 把它们跑起来」，你就抓住了整个框架。"]}),n.jsx("h2",{children:"二、核心抽象逐个详解"}),n.jsx("p",{children:"下面这张表先给全貌，再逐个配最小代码片段讲清楚。"}),n.jsxs("table",{children:[n.jsx("thead",{children:n.jsxs("tr",{children:[n.jsx("th",{children:"原语"}),n.jsx("th",{children:"职责"}),n.jsx("th",{children:"一句话"})]})}),n.jsxs("tbody",{children:[n.jsxs("tr",{children:[n.jsx("td",{children:n.jsx("code",{children:"Agent"})}),n.jsx("td",{children:"一个可被运行的角色"}),n.jsx("td",{children:"instructions + model + tools"})]}),n.jsxs("tr",{children:[n.jsx("td",{children:n.jsx("code",{children:"Runner"})}),n.jsx("td",{children:"驱动工具循环"}),n.jsx("td",{children:"Runner.run / run_sync"})]}),n.jsxs("tr",{children:[n.jsx("td",{children:n.jsx("code",{children:"Handoff"})}),n.jsx("td",{children:"控制权交接"}),n.jsx("td",{children:"返回另一个 Agent 的特殊工具调用"})]}),n.jsxs("tr",{children:[n.jsx("td",{children:n.jsx("code",{children:"Guardrail"})}),n.jsx("td",{children:"输入/输出并行校验"}),n.jsx("td",{children:"命中 tripwire 抛异常中断"})]}),n.jsxs("tr",{children:[n.jsx("td",{children:n.jsx("code",{children:"Session"})}),n.jsx("td",{children:"自动多轮状态"}),n.jsx("td",{children:"跨轮自动带历史"})]}),n.jsxs("tr",{children:[n.jsx("td",{children:n.jsx("code",{children:"Tracing"})}),n.jsx("td",{children:"内置可观测"}),n.jsx("td",{children:"OpenAI 专有，可视化每一步"})]}),n.jsxs("tr",{children:[n.jsx("td",{children:n.jsx("code",{children:"function_tool"})}),n.jsx("td",{children:"把函数变工具"}),n.jsx("td",{children:"docstring/签名自动成 schema"})]})]})]}),n.jsx("h3",{children:"Agent：一个可被运行的角色"}),n.jsxs("p",{children:["一个 Agent 由三样东西定义：",n.jsx("code",{children:"instructions"}),"（系统提示 / 职责）、",n.jsx("code",{children:"model"}),"（用哪个模型）、",n.jsx("code",{children:"tools"}),"（可调用的工具列表）。它就是一个有明确职责的角色， 比如「分诊台」「账单专员」。还可挂 ",n.jsx("code",{children:"handoffs"}),"、",n.jsx("code",{children:"input_guardrails"}),"、",n.jsx("code",{children:"output_guardrails"}),"、",n.jsx("code",{children:"model_settings"})," 等。"]}),n.jsx(e,{lang:"python",title:"定义一个 Agent",code:c}),n.jsx("h3",{children:"Runner：驱动工具循环"}),n.jsxs("p",{children:["Agent 本身只是个声明，真正跑起来要靠 Runner。",n.jsx("code",{children:"Runner.run(agent, input)"}),"（异步） 与 ",n.jsx("code",{children:"Runner.run_sync(agent, input)"}),"（同步）会启动这样一个循环：",n.jsx("strong",{children:"调用模型 → 若模型要求调用工具则执行工具并把结果回灌 → 再调用模型"}),"， 如此往复，直到模型产出不再调用工具的最终回答为止。循环次数、工具调度、handoff 切换 这些细节全由 Runner 内部处理，你只需要拿 ",n.jsx("code",{children:"result.final_output"}),"。"]}),n.jsx(e,{lang:"python",title:"Runner 驱动循环",code:o}),n.jsx("h3",{children:"Handoff：返回另一个 Agent 的特殊工具调用"}),n.jsxs("p",{children:["Handoff 的本质，是一次",n.jsx("strong",{children:"「返回另一个 Agent」的特殊工具调用"}),"。在",n.jsx("code",{children:"handoffs=[...]"})," 里列出的每个 Agent，都会被自动暴露成一个工具；当前 Agent 判断该交接时，就「调用」这个工具，于是控制权转交给目标 Agent。声明极简："]}),n.jsx(e,{lang:"python",title:"声明 handoffs",code:h}),n.jsx("h3",{children:"Guardrail：输入 / 输出并行校验"}),n.jsxs("p",{children:["护栏用 ",n.jsx("code",{children:"@input_guardrail"})," / ",n.jsx("code",{children:"@output_guardrail"})," 装饰函数，与主流程",n.jsx("strong",{children:"并行"}),"运行，返回 ",n.jsx("code",{children:"GuardrailFunctionOutput(tripwire_triggered=...)"}),"。 一旦 tripwire（绊线）命中，SDK 立即抛异常中断整个运行。"]}),n.jsx(e,{lang:"python",title:"输入护栏",code:a}),n.jsx("h3",{children:"Session：自动多轮状态"}),n.jsxs("p",{children:["Session 让 Agent 跨多轮对话自动保留上下文，无需你手动拼接历史。把同一个 session 传给 多次 ",n.jsx("code",{children:"Runner.run"}),"，前几轮的对话会被自动带上。"]}),n.jsx(e,{lang:"python",title:"多轮会话",code:j}),n.jsx("h3",{children:"Tracing：内置可观测性"}),n.jsxs("ul",{children:[n.jsx("li",{children:"SDK 自带 tracing，能可视化每一次模型调用、工具调用与 handoff 的链路。"}),n.jsxs("li",{children:["这是 OpenAI 专有能力，",n.jsx("strong",{children:"上报需要 OpenAI key"}),"；接第三方模型时通常要关掉，否则上报失败。"]})]}),n.jsx("h3",{children:"function_tool：把普通函数变工具"}),n.jsxs("p",{children:["给一个普通 Python 函数加 ",n.jsx("code",{children:"@function_tool"}),"，它就成了 Agent 可调用的工具： 函数名 → 工具名，docstring → 工具描述，类型注解 → 参数 JSON Schema。你几乎不用手写任何 schema。"]}),n.jsx(e,{lang:"python",title:"function_tool",code:u}),n.jsx("h2",{children:"三、架构总览：数据如何流动"}),n.jsx("p",{children:"把上面几个原语串起来，整体数据流就清晰了。下图展示了一次请求从进入到产出最终结果的全过程。"}),n.jsx(l,{framework:"openai-agents"}),n.jsx("p",{children:"读这张图的关键路径："}),n.jsxs("ul",{children:[n.jsxs("li",{children:[n.jsx("strong",{children:"Runner"})," 接收用户输入，先跑 ",n.jsx("strong",{children:"输入护栏"}),"（并行）；命中 tripwire 直接抛异常中断。"]}),n.jsxs("li",{children:["护栏通过后进入 ",n.jsx("strong",{children:"Agent 的工具循环"}),"：模型决定调用工具还是 handoff。"]}),n.jsxs("li",{children:["若是普通工具调用 → 执行工具、回灌结果、继续循环；若是 ",n.jsx("strong",{children:"handoff"})," → 控制权移交目标 Agent，从此由它接管循环。"]}),n.jsxs("li",{children:["模型产出最终回答后，再跑 ",n.jsx("strong",{children:"输出护栏"}),"，全部通过则返回 ",n.jsx("code",{children:"final_output"}),"。"]})]}),n.jsx("h2",{children:"四、Handoff 深入：交接，而非取一个返回值"}),n.jsx("p",{children:"初学者最容易把 handoff 和「子代理被当成一个工具调用」混为一谈，这是理解 Agents SDK 的关键分水岭。"}),n.jsxs("table",{children:[n.jsx("thead",{children:n.jsxs("tr",{children:[n.jsx("th",{}),n.jsx("th",{children:"子代理当工具调用"}),n.jsx("th",{children:"Handoff 交接"})]})}),n.jsxs("tbody",{children:[n.jsxs("tr",{children:[n.jsx("td",{children:"语义"}),n.jsxs("td",{children:["取一个",n.jsx("strong",{children:"返回值"}),"，主 Agent 继续"]}),n.jsxs("td",{children:["把",n.jsx("strong",{children:"整段对话控制权"}),"移交"]})]}),n.jsxs("tr",{children:[n.jsx("td",{children:"谁作答"}),n.jsx("td",{children:"始终是主 Agent"}),n.jsx("td",{children:"交接后由目标 Agent 直接对用户作答"})]}),n.jsxs("tr",{children:[n.jsx("td",{children:"之后"}),n.jsx("td",{children:"回到主 Agent 的循环"}),n.jsx("td",{children:"不再回到分诊台，目标 Agent 接管"})]}),n.jsxs("tr",{children:[n.jsx("td",{children:"适合"}),n.jsx("td",{children:"查资料、算一个子结果"}),n.jsx("td",{children:"分诊路由、按领域切换专家"})]})]})]}),n.jsxs(d,{title:"多 Agent 分诊的心智模型",children:["想象一个客服分诊台：用户发来「我要退款」。分诊台 Agent 读到问题，判断这属于退款范畴， 于是触发一次 handoff——把整段对话的控制权交给「退款专员」Agent。从这一刻起，对话由退款 专员接管，它用自己的 instructions 和工具继续与用户对话，直到给出最终答复，",n.jsx("strong",{children:"不会"}),"把一个「子结果」返回给分诊台再让分诊台作答。整个过程没有写任何状态机，只是「分诊台决定交给谁」 这一步，路由就自然完成了。"]}),n.jsxs(r,{variant:"note",children:["判断标准：如果你想要的是「让另一个角色接手并直接回用户」，那是 ",n.jsx("strong",{children:"handoff"}),"； 如果你只想「拿一个中间结果回来自己继续」，那应该做成 ",n.jsx("strong",{children:"工具"}),"（function_tool）， 而不是 handoff。"]}),n.jsx("h2",{children:"五、Guardrail 深入：输入护栏 vs 输出护栏"}),n.jsxs("ul",{children:[n.jsxs("li",{children:[n.jsx("strong",{children:"输入护栏（input_guardrail）"}),"：在 Agent 真正处理前校验",n.jsx("strong",{children:"用户输入"}),"， 典型用途是拦截越权、敏感、离题、Prompt 注入等请求。"]}),n.jsxs("li",{children:[n.jsx("strong",{children:"输出护栏（output_guardrail）"}),"：在 Agent 产出最终回答后校验",n.jsx("strong",{children:"输出内容"}),"， 典型用途是防止泄露内部信息、检查格式合规、过滤不当内容。"]})]}),n.jsx("h3",{children:"为什么要「并行」校验"}),n.jsxs("p",{children:["护栏与主流程并行运行，是为了",n.jsx("strong",{children:"不增加额外延迟"}),"：在主 Agent 思考的同时，护栏函数 同步在跑校验。如果护栏发现问题（tripwire 命中），就立刻打断主流程，避免把时间和 token 浪费在一个本就不该处理的请求上。"]}),n.jsx("h3",{children:"tripwire 中断机制"}),n.jsxs("p",{children:["护栏返回的 ",n.jsx("code",{children:"GuardrailFunctionOutput"})," 里有个 ",n.jsx("code",{children:"tripwire_triggered"})," 布尔位。 一旦它为 ",n.jsx("code",{children:"True"}),"，SDK 抛出 ",n.jsx("code",{children:"InputGuardrailTripwireTriggered"}),"（或对应的输出护栏 异常），整个 ",n.jsx("code",{children:"Runner.run"})," 立即中断。所以调用方一般要 ",n.jsx("code",{children:"try/except"})," 捕获， 给用户一个礼貌的拒绝答复。"]}),n.jsx(e,{lang:"python",title:"输出护栏：防止泄露内部信息",code:x}),n.jsx("h2",{children:"六、接非 OpenAI 模型的注意事项"}),n.jsxs("p",{children:["SDK ",n.jsx("strong",{children:"默认走 OpenAI 的 Responses API"}),"。但绝大多数第三方端点（百炼、各类 OpenAI 兼容网关）",n.jsx("strong",{children:"只支持 Chat Completions"}),"，所以要接非 OpenAI 模型，必须显式切 API。"]}),n.jsx(e,{lang:"python",title:"接第三方模型的通用配置",code:g}),n.jsxs("ul",{children:[n.jsxs("li",{children:[n.jsx("strong",{children:"Responses vs Chat Completions"}),"：默认 Responses；第三方端点用 ",n.jsx("code",{children:'set_default_openai_api("chat_completions")'})," 切换，否则报「不支持的接口」类错误。"]}),n.jsxs("li",{children:[n.jsx("strong",{children:"失去原生 tracing"}),"：tracing 上报需 OpenAI key，接第三方时用 ",n.jsx("code",{children:"set_tracing_disabled(True)"})," 关掉，否则会因缺 key 报错。"]}),n.jsxs("li",{children:[n.jsx("strong",{children:"如何补可观测"}),"：失去内置 tracing 后，可以自行接入 ",n.jsx("strong",{children:"OpenTelemetry"}),"， 对 ",n.jsx("code",{children:"Runner.run"})," 与工具调用做埋点，把链路上报到自己的 APM（如 Jaeger / Langfuse 等）。"]})]}),n.jsxs(r,{variant:"warn",children:["接百炼（DashScope）等第三方端点，",n.jsx("strong",{children:"必须切到 Chat Completions 并关掉 tracing"}),"， 否则直接报错。下一章会用一个完整的客服分诊实战，把「接百炼关键四步」逐行讲清楚。"]}),n.jsx("h2",{children:"七、适合与不适合"}),n.jsxs("ul",{children:[n.jsxs("li",{children:[n.jsx("strong",{children:"适合"}),"：多 Agent 分诊路由、带安全护栏的客服 / 工单系统、纯 Python 的轻量编排、 需要官方原生 tracing 的 OpenAI 项目。"]}),n.jsxs("li",{children:[n.jsx("strong",{children:"不适合"}),"：需要",n.jsx("strong",{children:"显式持久状态机"}),"、",n.jsx("strong",{children:"确定性 DAG"}),"、",n.jsx("strong",{children:"可回滚 / 可断点续跑"}),"的长流程编排。这类场景里控制流应当是「图」而不是「交接」，",n.jsx("strong",{children:"LangGraph"})," 更合适——它把状态、节点、边都显式建模，便于持久化与回放。"]}),n.jsx("li",{children:"接非 OpenAI 模型时，会失去 Responses API 与原生 tracing 的部分能力（可用 OTel 弥补）。"})]}),n.jsx("h2",{children:"八、本章定位与下一步"}),n.jsx("p",{children:"本章把 Agents SDK 的「为什么这样设计」和「每个原语怎么用」讲清楚了。它不是一个大而全的编排 引擎，而是一套精挑细选的小原语，让你用最少的概念把多 Agent 协作跑起来。下一章我们直接上手： 用「关键四步」把它接到百炼的 qwen-plus，写一个真实可跑的客服分诊系统，把 handoff、guardrail、 function_tool 全部落地。"}),n.jsx(t,{points:["Agents SDK 是 OpenAI 官方框架，是实验性 Swarm 的生产级继任者：保留 Agent+Handoff 原语，补齐 guardrails/tracing/sessions。","设计哲学：少量原语、Python-first、不发明 DSL；2026 年约 0.17.x，月度高频发版，约 2.7 万 star。","七个核心抽象：Agent（角色）、Runner（驱动循环）、Handoff（交接）、Guardrail（并行护栏）、Session（多轮状态）、Tracing（可观测）、function_tool（函数变工具）。","Handoff 是把整段对话控制权移交给另一个 Agent，而非取一个返回值；想拿子结果用 function_tool。","Guardrail 分输入/输出，与主流程并行校验，命中 tripwire 即抛异常中断，需 try/except 捕获。",'默认走 Responses API；接第三方端点要 set_default_openai_api("chat_completions") 并 set_tracing_disabled(True)，可用 OpenTelemetry 补可观测。',"适合分诊路由/带护栏客服/轻量编排；需显式状态机、确定性 DAG、可回滚长流程时 LangGraph 更合适。"]})]})}export{R as default};
