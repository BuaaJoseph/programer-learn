import{j as e}from"./index-BnUyEu5E.js";import{L as n,S as o}from"./Summary-qZ1-DBVA.js";import{K as d}from"./KeyIdea-DOTgzjr8.js";import{C as i}from"./Callout-DUAtr8Nz.js";import{C as r}from"./CodeBlock-DIEQOVpA.js";import{E as l}from"./Example-BRazL43h.js";const t=`// 1) 定义两套配色：浅色与深色
private val LightColors = lightColorScheme(
    primary = Color(0xFF6750A4),
    onPrimary = Color.White,
    secondary = Color(0xFF625B71),
    background = Color(0xFFFFFBFE),
    surface = Color(0xFFFFFBFE),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFD0BCFF),
    onPrimary = Color(0xFF381E72),
    secondary = Color(0xFFCCC2DC),
    background = Color(0xFF1C1B1F),
    surface = Color(0xFF1C1B1F),
)

// 2) 自定义主题：包住 MaterialTheme，统一注入配色/排版/形状
@Composable
fun AppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),  // 默认跟随系统深色模式
    dynamicColor: Boolean = true,                // Android 12+ 跟随壁纸取色
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val ctx = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,   // 见下
        shapes = AppShapes,           // 见下
        content = content
    )
}`,s=`// 排版：M3 预置了一整套语义化文字样式
val AppTypography = Typography(
    titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelSmall = TextStyle(fontSize = 11.sp)
)

// 形状：small / medium / large 三档圆角，组件按语义自动取用
val AppShapes = Shapes(
    small = RoundedCornerShape(4.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(24.dp)
)

// 在任意组件里读取当前主题值（而不是写死颜色/字号）
Text(
    text = "标题",
    color = MaterialTheme.colorScheme.primary,
    style = MaterialTheme.typography.titleLarge
)`,a=`@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("我的应用") })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { /* 新建 */ }) {
                Icon(Icons.Default.Add, contentDescription = "新建")
            }
        }
    ) { innerPadding ->
        // innerPadding 必须消费：让内容避开 TopAppBar 和系统栏
        Column(modifier = Modifier.padding(innerPadding)) {
            Card(modifier = Modifier.padding(16.dp)) {
                Text("一张卡片", modifier = Modifier.padding(16.dp))
            }
            Button(onClick = { /* 点击 */ }) {
                Text("主按钮")
            }
        }
    }
}`,c=`@Composable
fun ExpandableBox() {
    var expanded by remember { mutableStateOf(false) }

    // animate*AsState：状态从 false->true 时，尺寸/颜色平滑过渡而不是瞬变
    val size by animateDpAsState(
        targetValue = if (expanded) 200.dp else 100.dp,
        animationSpec = tween(durationMillis = 300),
        label = "size"
    )
    val color by animateColorAsState(
        targetValue = if (expanded) Color(0xFF6750A4) else Color(0xFFB0BEC5),
        label = "color"
    )

    Box(
        modifier = Modifier
            .size(size)                 // 这个值在变化时被自动补间
            .background(color)
            .clickable { expanded = !expanded }
    )
}`,h=`@Composable
fun ThemeToggleDemo() {
    var dark by remember { mutableStateOf(false) }
    var showTip by remember { mutableStateOf(true) }

    AppTheme(darkTheme = dark) {
        Surface(color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize()    // 高度变化时自动补间，提示出现/消失更顺
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("深色模式", color = MaterialTheme.colorScheme.onBackground)
                    Spacer(Modifier.weight(1f))
                    Switch(checked = dark, onCheckedChange = { dark = it })
                }

                // AnimatedVisibility：进/出场带淡入淡出 + 展开收起
                AnimatedVisibility(
                    visible = showTip,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Card { Text("点右上角开关切换主题", Modifier.padding(12.dp)) }
                }

                Button(onClick = { showTip = !showTip }) {
                    Text(if (showTip) "隐藏提示" else "显示提示")
                }
            }
        }
    }
}`;function C(){return e.jsxs("article",{children:[e.jsxs(n,{children:["有了布局和列表，界面还需要一套统一的「视觉语言」：颜色、字体、形状要协调，深色模式要能切换， 状态变化最好别生硬地跳变。这一章讲 ",e.jsx("strong",{children:"Material 3"})," 设计系统——它如何用 ColorScheme / Typography / Shape 三件套统一全局风格，",e.jsx("code",{children:"MaterialTheme"})," 如何把主题下发给所有组件， 以及 Android 12+ 的动态取色与深色模式；再讲 Compose 的",e.jsx("strong",{children:"动画"}),"：用 animate*AsState 让状态平滑过渡，用 AnimatedVisibility 做进出场，用 animateContentSize 自适应尺寸变化。"]}),e.jsx("h2",{children:"一、Material 3 设计系统"}),e.jsxs("p",{children:["Material 3（又称 Material You）是 Google 的最新设计系统，也是 Compose 的",e.jsx("strong",{children:"默认组件库"}),"（",e.jsx("code",{children:"androidx.compose.material3"}),"）。它的价值不只是「好看的组件」，更是一套",e.jsx("strong",{children:"语义化的设计令牌（design tokens）"}),"：你不直接写颜色值和字号，而是引用 「主色 / 表面色 / 标题样式 / 中等圆角」这些语义角色，全局换肤时一处改、处处变。"]}),e.jsxs(d,{children:["Material 3 把主题抽象成三件套：",e.jsx("strong",{children:"ColorScheme（配色）"}),"、",e.jsx("strong",{children:"Typography（排版）"}),"、",e.jsx("strong",{children:"Shapes（形状）"}),"。组件不写死样式， 而是",e.jsx("strong",{children:"按语义"}),"从当前主题里取值，所以换主题、切深色模式只需替换这三套令牌。"]}),e.jsx("h3",{children:"ColorScheme：成对出现的语义色"}),e.jsxs("p",{children:["M3 的配色不是一堆零散颜色，而是一组",e.jsx("strong",{children:"有角色的"}),"颜色，且大多",e.jsx("strong",{children:"成对"}),"出现： 每个「容器色」都配一个「在其上的内容色」，保证对比度可读。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"角色"}),e.jsx("th",{children:"含义"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"primary"})," / ",e.jsx("code",{children:"onPrimary"})]}),e.jsx("td",{children:"主色与「画在主色之上」的内容色"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"secondary"})," / ",e.jsx("code",{children:"tertiary"})]}),e.jsx("td",{children:"次要 / 第三强调色"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"background"})," / ",e.jsx("code",{children:"onBackground"})]}),e.jsx("td",{children:"页面背景与其上的文字色"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"surface"})," / ",e.jsx("code",{children:"onSurface"})]}),e.jsx("td",{children:"卡片 / 表面色与其上的内容色"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"error"})," / ",e.jsx("code",{children:"onError"})]}),e.jsx("td",{children:"错误状态色及其内容色"})]})]})]}),e.jsx("h3",{children:"Typography 与 Shapes"}),e.jsxs("p",{children:[e.jsx("strong",{children:"Typography"})," 提供一套语义化文字样式：",e.jsx("code",{children:"displayLarge"}),"、",e.jsx("code",{children:"titleLarge"}),"、",e.jsx("code",{children:"bodyMedium"}),"、",e.jsx("code",{children:"labelSmall"})," 等，按「用途」选样式而非到处写 ",e.jsx("code",{children:"fontSize"}),"。",e.jsx("strong",{children:"Shapes"})," 则定义 ",e.jsx("code",{children:"small"})," / ",e.jsx("code",{children:"medium"})," / ",e.jsx("code",{children:"large"})," 三档圆角， Button、Card 等组件会按各自语义自动取用对应档位。"]}),e.jsx(r,{lang:"kotlin",title:"自定义 Typography 与 Shapes，并按语义读取",code:s}),e.jsx("h2",{children:"二、MaterialTheme：主题的提供者"}),e.jsxs("p",{children:[e.jsx("code",{children:"MaterialTheme"})," 是一个可组合函数，它把 colorScheme / typography / shapes 三套令牌 通过 ",e.jsx("strong",{children:"CompositionLocal"})," 下发给包裹在它内部的所有组件。子组件用",e.jsx("code",{children:"MaterialTheme.colorScheme.primary"})," 这样的方式",e.jsx("strong",{children:"就近读取"}),"当前主题—— 这正是「一处定义、处处生效」的机制。实战中我们通常再包一层自己的 ",e.jsx("code",{children:"AppTheme"}),"。"]}),e.jsx(r,{lang:"kotlin",title:"自定义 AppTheme 包住 MaterialTheme",code:t}),e.jsx("h3",{children:"深色模式：isSystemInDarkTheme"}),e.jsxs("p",{children:[e.jsx("code",{children:"isSystemInDarkTheme()"})," 读取系统当前是否处于深色模式，返回一个会随系统设置变化的状态。 把它作为选 LightColors 还是 DarkColors 的依据，应用就能",e.jsx("strong",{children:"自动跟随系统"}),"切换明暗； 当然你也可以用一个自己的开关状态覆盖它，做应用内手动切换。"]}),e.jsx("h3",{children:"动态取色 dynamicColor（Android 12+）"}),e.jsxs("p",{children:["Android 12（API 31，代号 S）起支持",e.jsx("strong",{children:"动态取色"}),"：系统从用户的",e.jsx("strong",{children:"壁纸"}),"提取主色， 生成一整套和谐的 ColorScheme，让应用「跟着手机主题走」。在 Compose 里用",e.jsx("code",{children:"dynamicLightColorScheme(context)"})," / ",e.jsx("code",{children:"dynamicDarkColorScheme(context)"})," 获取， 但必须",e.jsx("strong",{children:"判断系统版本"}),"，低于 12 的设备回退到你自定义的静态配色。"]}),e.jsxs(i,{variant:"warn",title:"动态取色要做版本判断与回退",children:[e.jsx("code",{children:"dynamic*ColorScheme"})," 仅在 ",e.jsx("code",{children:"Build.VERSION.SDK_INT >= Build.VERSION_CODES.S"}),"时可用。务必先判版本，否则在旧设备上会崩；判断不通过时回退到 Light/DarkColors。"]}),e.jsx("h2",{children:"三、常用 Material 3 组件"}),e.jsxs("p",{children:["M3 提供了开箱即用的常见组件，最骨架级的是 ",e.jsx("code",{children:"Scaffold"}),"——它给你一个标准的页面脚手架， 预留好顶栏、底栏、悬浮按钮、Snackbar 的插槽，并把它们之间的间距（",e.jsx("code",{children:"innerPadding"}),"）算好交给你。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"组件"}),e.jsx("th",{children:"用途"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"Scaffold"})}),e.jsx("td",{children:"页面脚手架，编排 topBar / bottomBar / FAB / 内容区"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"TopAppBar"})}),e.jsx("td",{children:"顶部应用栏，放标题、导航图标与操作"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"Button"})," 系列"]}),e.jsxs("td",{children:["主按钮、",e.jsx("code",{children:"OutlinedButton"}),"、",e.jsx("code",{children:"TextButton"})," 等"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"Card"})}),e.jsx("td",{children:"带表面色与圆角阴影的内容容器"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"FloatingActionButton"})}),e.jsx("td",{children:"悬浮主操作按钮（FAB）"})]})]})]}),e.jsx(r,{lang:"kotlin",title:"用 Scaffold 组织一个页面",code:a}),e.jsxs(i,{variant:"tip",title:"务必消费 innerPadding",children:[e.jsx("code",{children:"Scaffold"})," 内容 lambda 的参数 ",e.jsx("code",{children:"innerPadding"})," 一定要应用到内容上 （",e.jsx("code",{children:"Modifier.padding(innerPadding)"}),"），否则内容会被 TopAppBar 或系统栏盖住。"]}),e.jsx("h2",{children:"四、动画：让状态变化平滑过渡"}),e.jsxs("p",{children:["Compose 是声明式的：你描述「某状态下界面长什么样」，状态一变界面就重组。但默认是",e.jsx("strong",{children:"瞬间跳变"}),"。动画 API 的作用，就是在「旧值」到「新值」之间",e.jsx("strong",{children:"自动补间"}),"， 让变化看起来连续顺滑。"]}),e.jsx("h3",{children:"animate*AsState：单个值的平滑过渡"}),e.jsxs("p",{children:["这是最常用的入门动画。",e.jsx("code",{children:"animateDpAsState"})," / ",e.jsx("code",{children:"animateColorAsState"})," /",e.jsx("code",{children:"animateFloatAsState"})," 等接收一个 ",e.jsx("strong",{children:"目标值"}),"，返回一个会",e.jsx("strong",{children:"朝目标平滑变化"}),"的 State。你只管改目标值，过渡过程框架替你算。"]}),e.jsx(r,{lang:"kotlin",title:"animateDpAsState / animateColorAsState",code:c}),e.jsx("h3",{children:"AnimatedVisibility 与 animateContentSize"}),e.jsxs("p",{children:[e.jsx("strong",{children:"AnimatedVisibility"})," 专管组件的",e.jsx("strong",{children:"进场 / 出场"}),"：根据",e.jsx("code",{children:"visible"})," 布尔值，用 ",e.jsx("code",{children:"enter"})," / ",e.jsx("code",{children:"exit"})," 指定淡入淡出 （",e.jsx("code",{children:"fadeIn"})," / ",e.jsx("code",{children:"fadeOut"}),"）、展开收起（",e.jsx("code",{children:"expandVertically"})," /",e.jsx("code",{children:"shrinkVertically"}),"）等效果，且效果可以用 ",e.jsx("code",{children:"+"})," 组合。",e.jsx("strong",{children:"animateContentSize"})," 是个 Modifier，挂上后组件",e.jsx("strong",{children:"尺寸变化"}),"会自动补间， 常用于「内容增减导致高度变化」时不让它突然跳。"]}),e.jsx(r,{lang:"kotlin",title:"主题切换 + AnimatedVisibility + animateContentSize",code:h}),e.jsxs(l,{title:"这个例子里发生了什么",children:[e.jsxs("p",{children:["点 Switch => ",e.jsx("code",{children:"dark"})," 变化 => ",e.jsx("code",{children:"AppTheme(darkTheme = dark)"})," 重新计算 colorScheme => 所有用 ",e.jsx("code",{children:"MaterialTheme.colorScheme.*"})," 取色的组件随之换肤。"]}),e.jsxs("p",{children:["点「隐藏 / 显示提示」=> ",e.jsx("code",{children:"showTip"})," 变化 => ",e.jsx("code",{children:"AnimatedVisibility"})," 让卡片淡入淡出 + 展开收起；外层 ",e.jsx("code",{children:"animateContentSize"})," 让 Column 的高度变化也平滑，整体不突兀。"]})]}),e.jsx("h3",{children:"updateTransition：一句话"}),e.jsxs("p",{children:["当多个值需要",e.jsx("strong",{children:"跟同一个状态一起协调地变"}),"（如同时变颜色、大小、圆角）， 用 ",e.jsx("code",{children:"updateTransition"})," 统一管理：它以一个状态为驱动，派生出多个被同步补间的子动画， 比分别写多个 animate*AsState 更整齐、更易保持节奏一致。"]}),e.jsx(i,{variant:"tip",children:"到这里，你已能搭出有布局、长列表、统一主题与基础动画的完整界面。下一卷我们进入状态管理与数据层， 让这些漂亮的界面真正「动起来、连上数据」。"}),e.jsx(o,{points:["Material 3 用 ColorScheme / Typography / Shapes 三套语义化令牌统一全局风格，组件按语义取值而非写死。","ColorScheme 的颜色成对出现（如 primary / onPrimary），保证内容在容器上可读。","MaterialTheme 通过 CompositionLocal 下发主题，子组件用 MaterialTheme.colorScheme/typography 就近读取，实现一处定义处处生效。","isSystemInDarkTheme() 跟随系统深色模式；dynamicColor 在 Android 12+ 从壁纸取色，需判版本并回退。","常用组件：Scaffold（脚手架，务必消费 innerPadding）、TopAppBar、Button、Card、FloatingActionButton。","动画：animate*AsState 平滑过渡单个值，AnimatedVisibility 管进出场，animateContentSize 自适应尺寸，updateTransition 协调多值同变。"]})]})}export{C as default};
