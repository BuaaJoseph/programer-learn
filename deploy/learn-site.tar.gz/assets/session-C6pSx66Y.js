const d=[{id:"backend",title:"服务端开发",desc:"Java / Go 后端、分布式、中间件、高并发",skills:["Java 基础","JVM 与垃圾回收","并发编程","MySQL","Redis","RPC","消息队列 MQ","Spring / Spring Boot","计算机网络","操作系统","分布式与微服务","设计模式"]},{id:"frontend",title:"前端开发",desc:"JS/TS、框架、浏览器原理、工程化",skills:["JavaScript 基础","TypeScript","HTML / CSS","浏览器原理","React","Vue","网络与 HTTP","前端工程化","性能优化","Node.js"]},{id:"ios",title:"iOS 开发",desc:"Swift / OC、UIKit、内存与性能",skills:["Swift","Objective-C","UIKit","SwiftUI","内存管理 / ARC","Runtime 运行时","多线程 / GCD","网络层","性能优化","架构设计"]},{id:"android",title:"Android 开发",desc:"Kotlin / Java、Jetpack、性能优化",skills:["Kotlin","Java 基础","Android 四大组件","Jetpack","自定义 View","Handler / Looper","内存优化","多线程","架构（MVVM/MVI）","性能优化"]},{id:"algorithm",title:"算法",desc:"数据结构、刷题、机器学习基础",skills:["数组与字符串","链表 / 树 / 图","动态规划","贪心","回溯","二分查找","排序","哈希","数学","机器学习基础"]},{id:"agent",title:"Agent 开发",desc:"LLM 应用、RAG、Agent 编排",skills:["Prompt 工程","RAG 检索增强","Function Calling","Agent 框架","向量数据库","记忆系统","多 Agent 协作","LLM 应用架构","评估与可观测","工具集成 MCP"]},{id:"llm-algo",title:"大模型算法",desc:"预训练、微调、推理优化",skills:["Transformer 结构","Attention 机制","预训练","SFT 微调","LoRA / PEFT","RLHF","分布式训练","推理优化","模型评估","强化学习基础"]}],u={"Java 基础":["ThreadLocal 的实现原理与内存泄漏问题","synchronized 的锁升级（偏向锁/轻量级锁/重量级锁）","HashMap 的扩容、红黑树退化与线程安全问题","volatile 的可见性与有序性（happens-before）","final / static 关键字、不可变对象"],"JVM 与垃圾回收":["JVM 内存区域划分（堆/栈/方法区/元空间）","垃圾回收算法（标记清除/复制/标记整理）与分代收集","GC Roots 可达性分析、CMS 与 G1 的区别","类加载过程与双亲委派模型","一次 Full GC 频繁的排查思路"],并发编程:["AQS 的实现原理（state + CLH 队列）","ReentrantLock 与 synchronized 的区别","线程池核心参数与拒绝策略、execute 流程","CAS 与 ABA 问题、原子类","ConcurrentHashMap 1.7/1.8 的实现差异"],MySQL:["B+Tree 索引结构、为什么用 B+Tree 而不是 B-Tree/红黑树","聚簇索引与二级索引、回表与覆盖索引","最左前缀原则、索引失效场景","事务隔离级别与对应的并发异常（脏读/不可重复读/幻读）","MVCC 的实现（undo log 版本链 + ReadView）","redo log / undo log / binlog 的作用与两阶段提交","间隙锁 / Next-Key Lock 如何解决幻读"],Redis:["Redis 常用数据结构与底层实现（SDS/ziplist/quicklist/skiplist/hash)","缓存穿透 / 击穿 / 雪崩及解决方案","分布式锁的实现、Redisson watchdog 续约原理","持久化 RDB 与 AOF 的取舍","过期删除策略与内存淘汰策略","哨兵模式、主从复制与数据同步、Cluster 分片"],RPC:["RPC 调用的完整流程（代理/序列化/网络/反序列化）","常见序列化协议对比（Protobuf/Hessian/JSON)","服务注册与发现、负载均衡策略","熔断、限流、降级的实现","Netty 在 RPC 中的作用与 Reactor 模型"],"消息队列 MQ":["发布订阅与点对点模式","MQ 如何保证消息不丢失（生产者/Broker/消费者三端）","消费端如何防止重复消费（幂等设计）","消息顺序性如何保证","消息积压如何处理、死信队列","Kafka 高吞吐的原因（顺序写/零拷贝/分区）"],"Spring / Spring Boot":["IOC 与 DI、Bean 的生命周期","AOP 实现原理（JDK 动态代理 vs CGLIB）","循环依赖与三级缓存","@Transactional 失效的场景","Spring Boot 自动装配原理"],计算机网络:["TCP 三次握手 / 四次挥手、为什么","TCP 如何保证可靠传输（滑动窗口/拥塞控制）","HTTP/1.1 / 2 / 3 的区别，HTTPS 握手过程","HTTP 与 TCP 长连接、keep-alive","从输入 URL 到页面展示的全过程"],操作系统:["进程与线程、协程的区别","进程间通信方式","虚拟内存、分页与缺页中断","死锁的条件与避免","IO 多路复用 select/poll/epoll"],分布式与微服务:["CAP 与 BASE 理论","分布式事务（2PC/TCC/本地消息表/Seata)","分布式 ID 生成方案（雪花算法）","一致性哈希","限流算法（令牌桶/漏桶/滑动窗口）"],设计模式:["单例模式的几种写法与线程安全","工厂 / 策略 / 模板方法的应用场景","代理模式与装饰器模式的区别","观察者模式与发布订阅"],"JavaScript 基础":["原型链与继承","闭包与作用域链","this 指向与 call/apply/bind","事件循环（宏任务/微任务）","Promise 实现原理"],TypeScript:["类型体操（泛型/条件类型/映射类型）","interface 与 type 的区别","类型守卫与协变逆变"],"HTML / CSS":["盒模型与 BFC","flex/grid 布局","水平垂直居中方案","重排与重绘"],浏览器原理:["浏览器渲染流程","回流与重绘","跨域与 CORS","存储 cookie/localStorage/sessionStorage"],React:["Fiber 架构与协调","Hooks 原理与闭包陷阱","diff 算法与 key","状态管理与性能优化(memo/useMemo)"],Vue:["响应式原理（Vue2 defineProperty / Vue3 Proxy)","diff 与虚拟 DOM","nextTick 原理","computed 与 watch"],"网络与 HTTP":["HTTP 缓存（强缓存/协商缓存）","跨域解决方案","HTTPS 过程","HTTP/2 多路复用"],前端工程化:["Webpack/Vite 构建原理","tree-shaking","懒加载与代码分割","Babel 与 AST"],性能优化:["首屏优化","资源加载优化","长列表虚拟滚动","Lighthouse 指标"],"Node.js":["事件循环与 libuv","Stream 与 Buffer","进程与 cluster","中间件机制"],动态规划:["背包问题","最长递增子序列","编辑距离","股票买卖系列"],"链表 / 树 / 图":["链表反转与环检测","二叉树遍历","LCA 最近公共祖先","拓扑排序/最短路径"],机器学习基础:["过拟合与正则化","常见损失函数","梯度下降与优化器","评估指标(AUC/F1)"],"Transformer 结构":["Self-Attention 计算","位置编码","Multi-Head 作用","LayerNorm 位置（Pre/Post)"],"Attention 机制":["QKV 含义与缩放点积","Causal Mask","KV Cache 原理","Flash Attention"],"SFT 微调":["指令微调数据构造","全参微调 vs PEFT","灾难性遗忘","学习率与 warmup"],"LoRA / PEFT":["LoRA 原理（低秩分解）","QLoRA","Adapter / Prefix Tuning 对比","rank 选择"],RLHF:["RLHF 三阶段","PPO 与 DPO 的区别","奖励模型训练","KL 惩罚作用"],推理优化:["量化（INT8/INT4）","KV Cache 与 PagedAttention","投机解码","连续批处理"],"Prompt 工程":["Few-shot / CoT","结构化输出","Prompt 注入与防护","角色与系统提示设计"],"RAG 检索增强":["切块与 embedding 策略","向量检索与重排","幻觉抑制","多路召回"],"Function Calling":["工具定义与参数 schema","并行工具调用","错误处理与重试","ReAct 循环"]};function S(e){const t=[];for(const n of e){const i=u[n];i&&i.length&&t.push({skill:n,questions:i})}return t}function T(e){return d.find(t=>t.id===e)||null}const r="interview.config";function p(e){try{sessionStorage.setItem(r,JSON.stringify(e))}catch{}}function m(){try{const e=sessionStorage.getItem(r);return e?JSON.parse(e):null}catch{return null}}const C=[{id:"intro",title:"个人介绍",minutes:5,desc:"互相熟悉，破冰"},{id:"project",title:"项目考察",minutes:20,desc:"项目深挖与追问"},{id:"tech",title:"技术考察",minutes:20,desc:"原理与中间件深入"},{id:"llm",title:"LLM / AI 编程",minutes:5,desc:"开放性问题"},{id:"coding",title:"编程考察",minutes:10,desc:"动手写代码"}];function g(e){const t=T(e.position),n=t?t.title:e.position,i=e.skills||[],o=S(i),a=o.length?o.map(s=>`【${s.skill}】
  - ${s.questions.join(`
  - `)}`).join(`
`):"（无特定题库，请结合岗位与简历自行设计）",l=e.resumeText&&e.resumeText.trim()?e.resumeText.trim():"（候选人未提供简历正文）",c=e.resumeLink&&e.resumeLink.trim()?`
候选人还提供了简历链接：${e.resumeLink.trim()}（如内容缺失，可在开场时请候选人口述补充）。`:"";return`你是一名资深的技术面试官，正在为「${n}」岗位面试一位候选人。请用中文进行一场专业、真实、有深度的模拟面试。

# 你的身份与风格
- 你是某互联网公司的技术专家，亲和但专业，善于通过追问挖掘候选人的真实水平。
- 一次只问一个问题或一个小的追问，等候选人回答后再继续，绝不要一口气抛出一堆问题。
- 候选人的回答可能来自语音转写，可能有口语化、断句不准的情况，请理解其意图。
- 适当给予简短反馈（"嗯，这个点说得不错" / "这里我再追问一下"），但不要长篇大论地讲解，把舞台留给候选人。
- 控制总时长约 1 小时，按下面的阶段推进；当一个阶段时间差不多了，自然地过渡到下一阶段。

# 候选人简历
${l}${c}

# 本次考察的技能点（候选人勾选）
${i.length?i.join("、"):"（未特别勾选，按岗位常规考察）"}

# 可参考的常见考题（供你出题与追问，不必全用，鼓励结合简历项目）
${a}

# 面试阶段安排（约 1 小时）
1. 【个人介绍 · 约5分钟】先做简短自我介绍（例如："您好，我是 XX 公司的技术专家，今天由我来面试你"），然后请候选人做自我介绍，目的是破冰、互相熟悉，顺带考察其语言组织能力。
2. 【项目考察 · 约20分钟】根据简历请候选人介绍 1-2 个项目，详细描述业务流程和他具体做了什么。针对回答做有针对性的追问：实现细节、没讲清楚的部分、业务逻辑与数据、技术选型的原因与对比方案。判断项目是否本人主导、是否有完整的思考链路（为什么做、目标是什么、如何评估、为何这样选型），挖掘亮点与难点。
3. 【技术考察 · 约20分钟】结合简历中的项目与技术特长，以及上面勾选的技能点，深入考察中间件与基础原理（例如 MySQL 索引/事务/MVCC/binlog/redolog、Redis 数据结构/分布式锁/watchdog/哨兵主从、MQ 防丢失防重复消费、Java ThreadLocal/synchronized/JVM/GC/并发 等）。重点考察是否在使用之余理解底层原理。一题一题地问，循序渐进、由浅入深。
4. 【LLM / AI 编程 · 约5分钟】（针对非算法岗）问一些开放性问题：是否用过 vibe coding / AI 辅助编程，日常如何使用，有什么好的实践，结合项目谈谈对 LLM 的理解，借此判断对新技术的接受度。
5. 【编程考察 · 约10分钟】最后进入动手写代码环节。当你准备进入这一环节时，请明确地对候选人说"接下来我们进入最后的编程环节，请在右侧/下方的代码编辑器中作答"，由系统给出一道随机算法题。候选人提交代码后，你会收到他的代码，请据此点评思路、复杂度与边界处理，并可适当追问。

# 输出要求（重要）
- 每次回复的**第一行**只输出一个阶段标记，格式严格为：[[STAGE:xxx]]，其中 xxx 取值为 intro / project / tech / llm / coding 之一，表示你当前所处的面试阶段。这一行由系统用于同步进度条，不会展示给候选人；从第二行起再写你真正要说的话。
- 当你判断该进入下一阶段时，就在该次回复把标记改成新阶段（例如从 project 进入 tech 就写 [[STAGE:tech]]）。
- 你说的话会被转成**语音**朗读，请用**口语化的纯文本**，不要使用 Markdown：不要用反引号、星号、井号、代码块等标记（例如直接说 finally、remove 方法，而不是写成带反引号的形式）。

# 现在开始
请以面试官身份开场：第一行写 [[STAGE:intro]]，然后先简短自我介绍，再邀请候选人做自我介绍。直接输出你要说的话，不要输出任何解释性的旁白或括号说明。`}function A(e){const t=String(e).match(/^\s*\[\[STAGE:\s*([a-zA-Z]+)\s*\]\]\s*\n?/);return t?{stage:t[1].toLowerCase(),clean:e.slice(t[0].length)}:{stage:null,clean:e}}const L={intro:0,project:1,tech:2,llm:3,coding:4};export{d as P,C as S,L as a,g as b,T as f,m as l,A as p,p as s};
