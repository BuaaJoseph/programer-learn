import{j as e}from"./index-DraKZMSn.js";import{L as d,S as t}from"./Summary-D7nqkGRf.js";import{K as n}from"./KeyIdea-C2HcfWY0.js";import{C as i}from"./Callout-BE-nWzIM.js";import{C as s}from"./CodeBlock-BiqAHAS8.js";import{E as r}from"./Example-yyME7alB.js";const c=`<template>
  <!-- 文本插值：双大括号里只能放「表达式」 -->
  <p>{{ msg }}</p>
  <p>{{ count + 1 }}</p>
  <p>{{ ok ? '通过' : '未通过' }}</p>
  <p>{{ message.split('').reverse().join('') }}</p>

  <!-- 下面这些都【不行】，因为不是表达式 -->
  <!-- {{ if (ok) { return 1 } }}   语句不行 -->
  <!-- {{ const a = 1 }}            声明不行 -->
</template>

<script setup>
import { ref } from 'vue'

const msg = ref('你好，Vue')
const count = ref(0)
const ok = ref(true)
const message = ref('hello')
<\/script>`,l=`<template>
  <!-- 完整写法 v-bind:attr -->
  <img v-bind:src="imgUrl" v-bind:alt="imgAlt" />

  <!-- 简写 :attr（最常用） -->
  <img :src="imgUrl" :alt="imgAlt" />

  <!-- 绑定布尔型 attribute：值为假时该属性会被移除 -->
  <button :disabled="isLoading">提交</button>

  <!-- 动态参数：属性名本身也来自变量 -->
  <a :[attrName]="attrValue">动态属性名</a>

  <!-- 一次绑定一个对象上的多个属性 -->
  <div v-bind="objAttrs"></div>
</template>

<script setup>
import { ref } from 'vue'

const imgUrl = ref('/logo.png')
const imgAlt = ref('站点 Logo')
const isLoading = ref(false)
const attrName = ref('href')
const attrValue = ref('https://vuejs.org')
const objAttrs = ref({ id: 'app', class: 'container' })
<\/script>`,o=`<template>
  <!-- v-if / v-else-if / v-else：条件渲染，三者必须相邻 -->
  <p v-if="score >= 90">优秀</p>
  <p v-else-if="score >= 60">及格</p>
  <p v-else>不及格</p>

  <!-- v-show：始终渲染，只切换 CSS 的 display -->
  <p v-show="visible">我用 v-show 控制显隐</p>

  <!-- 想对「一组元素」整体做 v-if，用 template 包裹，它本身不渲染成标签 -->
  <template v-if="loggedIn">
    <h2>欢迎回来</h2>
    <p>这里是你的面板</p>
  </template>
</template>

<script setup>
import { ref } from 'vue'

const score = ref(75)
const visible = ref(true)
const loggedIn = ref(true)
<\/script>`,h=`<template>
  <!-- 遍历数组：item 是元素，index 是下标 -->
  <ul>
    <li v-for="(item, index) in fruits" :key="item.id">
      {{ index + 1 }}. {{ item.name }}
    </li>
  </ul>

  <!-- 遍历对象：value、key、index 三个参数 -->
  <ul>
    <li v-for="(value, key, index) in user" :key="key">
      {{ index }} - {{ key }}: {{ value }}
    </li>
  </ul>

  <!-- 遍历一个整数范围（从 1 开始） -->
  <span v-for="n in 5" :key="n">{{ n }} </span>
</template>

<script setup>
import { ref } from 'vue'

const fruits = ref([
  { id: 1, name: '苹果' },
  { id: 2, name: '香蕉' },
  { id: 3, name: '橙子' },
])
const user = ref({ name: '小杜', age: 28, city: '杭州' })
<\/script>`,x=`<template>
  <!-- 完整写法 v-on:event -->
  <button v-on:click="onClick">点我</button>

  <!-- 简写 @event（最常用） -->
  <button @click="onClick">点我</button>

  <!-- 行内传参；要拿原生事件对象用特殊变量 $event -->
  <button @click="add(2, $event)">加 2</button>

  <!-- 事件修饰符：链式书写 -->
  <form @submit.prevent="onSubmit">
    <a @click.stop="onLink">阻止冒泡</a>
    <button @click.once="onceonly">只触发一次</button>
  </form>

  <!-- 按键修饰符：只在按下回车时触发 -->
  <input @keyup.enter="onEnter" />
</template>

<script setup>
import { ref } from 'vue'

const count = ref(0)
function onClick() { count.value++ }
function add(n, e) { count.value += n; console.log(e.target) }
function onSubmit() { console.log('提交，且不刷新页面') }
function onLink() {}
function onceonly() {}
function onEnter() {}
<\/script>`,j=`<template>
  <!-- class 对象语法：键是类名，值为真则加上该类 -->
  <div :class="{ active: isActive, 'text-danger': hasError }"></div>

  <!-- class 数组语法 -->
  <div :class="[baseClass, isActive ? 'active' : '']"></div>

  <!-- 与静态 class 共存，最终会合并 -->
  <div class="card" :class="{ shadow: hovered }"></div>

  <!-- style 对象语法（属性名用驼峰或带引号的连字符） -->
  <div :style="{ color: textColor, fontSize: size + 'px' }"></div>

  <!-- style 数组：合并多个样式对象 -->
  <div :style="[baseStyle, overrideStyle]"></div>
</template>

<script setup>
import { ref } from 'vue'

const isActive = ref(true)
const hasError = ref(false)
const baseClass = ref('btn')
const hovered = ref(false)
const textColor = ref('red')
const size = ref(16)
const baseStyle = ref({ margin: '8px' })
const overrideStyle = ref({ color: 'blue' })
<\/script>`,a=`// 模板 <p>{{ msg }}</p> 大致被编译成这样的渲染函数（已简化）
function render() {
  return createElementVNode('p', null, toDisplayString(msg.value))
}
// 指令也一样：v-if 编译成三元 / 条件表达式，v-for 编译成一个把数组映射成 VNode 列表的循环。
// 也就是说，模板只是「写起来更顺手的渲染函数语法」。`,v=`<template>
  <section class="todo">
    <h2>待办清单（{{ remaining }} 项未完成）</h2>

    <!-- 输入框 + 回车新增；这里先用最朴素的 ref 取值方式 -->
    <input
      v-model="draft"
      @keyup.enter="addTodo"
      placeholder="输入后回车新增"
    />
    <button @click="addTodo" :disabled="!draft.trim()">添加</button>

    <!-- 过滤按钮 -->
    <div class="filters">
      <button
        v-for="f in filters"
        :key="f"
        :class="{ active: current === f }"
        @click="current = f"
      >
        {{ f }}
      </button>
    </div>

    <!-- 列表：用稳定的 id 作 key，绝不要用 index -->
    <ul>
      <li
        v-for="todo in visibleTodos"
        :key="todo.id"
        :class="{ done: todo.done }"
      >
        <input type="checkbox" v-model="todo.done" />
        <span>{{ todo.text }}</span>
        <button @click.stop="remove(todo.id)">删除</button>
      </li>
    </ul>

    <!-- 空状态：v-if 真正不渲染节点 -->
    <p v-if="visibleTodos.length === 0">这里空空如也～</p>
  </section>
</template>

<script setup>
import { ref, computed } from 'vue'

let uid = 0
const draft = ref('')
const current = ref('全部')
const filters = ['全部', '未完成', '已完成']
const todos = ref([
  { id: ++uid, text: '学习模板语法', done: true },
  { id: ++uid, text: '搞懂 v-for 的 key', done: false },
])

const remaining = computed(() => todos.value.filter(t => !t.done).length)

const visibleTodos = computed(() => {
  if (current.value === '未完成') return todos.value.filter(t => !t.done)
  if (current.value === '已完成') return todos.value.filter(t => t.done)
  return todos.value
})

function addTodo() {
  const text = draft.value.trim()
  if (!text) return
  todos.value.push({ id: ++uid, text, done: false })
  draft.value = ''
}

function remove(id) {
  todos.value = todos.value.filter(t => t.id !== id)
}
<\/script>`;function y(){return e.jsxs("article",{children:[e.jsxs(d,{children:["Vue 3 的模板是「带指令的增强 HTML」：它看起来就是普通 HTML，但多了一套以",e.jsx("code",{children:"v-"})," 开头的特殊属性（指令）和一对双大括号文本插值。这套模板并不会原样交给浏览器， 而是会被 Vue 在构建期或运行期",e.jsx("strong",{children:"编译成 JavaScript 渲染函数"}),"。这一章我们逐个拆解 四个最核心的指令——",e.jsx("code",{children:"v-bind"}),"、",e.jsx("code",{children:"v-if"}),"、",e.jsx("code",{children:"v-for"}),"、",e.jsx("code",{children:"v-on"}),"， 再加上文本插值、class / style 绑定，最后用一个待办列表把它们串起来。"]}),e.jsx("h2",{children:"一、模板的本质：会被编译成渲染函数的增强 HTML"}),e.jsxs("p",{children:["很多初学者把 Vue 模板当成「字符串模板」或「会被正则替换的 HTML」，这是误解。Vue 的模板语法 是",e.jsx("strong",{children:"合法的 HTML 超集"}),"：任何能解析 HTML 的工具都能解析它，而 Vue 在此之上加了 插值与指令两类语法。真正运行时，模板早已被编译器翻译成一个返回虚拟节点（VNode）树的",e.jsx("strong",{children:"渲染函数"}),"。"]}),e.jsxs(n,{children:["模板不是魔法，而是「写起来更顺手的渲染函数语法糖」。",e.jsx("code",{children:"{{ msg }}"})," 会被编译成读取响应式数据并输出文本的代码；",e.jsx("code",{children:"v-if"})," 编译成条件表达式；",e.jsx("code",{children:"v-for"})," 编译成把数组映射成 VNode 列表的循环。 理解这一点，后面所有指令的行为都会变得可预测。"]}),e.jsx(s,{lang:"vue",title:"模板大致被编译成什么",code:a}),e.jsxs("p",{children:["既然最终是 JavaScript，那「模板里能写什么」就有了明确边界：插值和指令绑定里只能放",e.jsx("strong",{children:"单个表达式"}),"（能求出一个值的东西），不能放语句（如 ",e.jsx("code",{children:"if"})," 块、 变量声明）。这一条贯穿全章，请先记住。"]}),e.jsx("h2",{children:"二、文本插值：双大括号只接受表达式"}),e.jsxs("p",{children:["最基础的数据展示就是双大括号 ",e.jsx("code",{children:"{{ }}"}),"。它会把里面表达式的求值结果作为文本插入， 并且当依赖的响应式数据变化时自动更新。注意「表达式」这个限制：",e.jsx("code",{children:"{{ count + 1 }}"}),"、",e.jsx("code",{children:'{{ ok ? "是" : "否" }}'}),"、",e.jsx("code",{children:'{{ list.join(",") }}'})," 都可以，但 ",e.jsx("code",{children:"if"}),"、",e.jsx("code",{children:"for"}),"、",e.jsx("code",{children:"const a = 1"})," 这类语句不行。"]}),e.jsx(s,{lang:"vue",title:"文本插值与它的边界",code:c}),e.jsxs(i,{variant:"info",title:"插值只对文本生效",children:["双大括号只能用在标签的「文本内容」位置，",e.jsx("strong",{children:"不能"}),"用在 HTML 属性上。要给属性 动态赋值，必须用下一节的 ",e.jsx("code",{children:"v-bind"}),"。例如 ",e.jsx("code",{children:'<a href="{{ url }}">'})," 是错的， 应写成 ",e.jsx("code",{children:'<a :href="url">'}),"。"]}),e.jsx("h2",{children:"三、v-bind：把数据绑到属性上"}),e.jsxs("p",{children:[e.jsx("code",{children:"v-bind"})," 让 HTML 属性的值来自数据而非写死的字符串。它的简写是一个冒号",e.jsx("code",{children:":"}),"，这也是实战中几乎唯一的写法。被绑定的值是 JavaScript 表达式，所以",e.jsx("code",{children:':href="url"'})," 里的 ",e.jsx("code",{children:"url"})," 是变量，而不是字面字符串。"]}),e.jsx(s,{lang:"vue",title:"v-bind 的几种形态",code:l}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"简写"}),"：",e.jsx("code",{children:"v-bind:src"})," 等价于 ",e.jsx("code",{children:":src"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"布尔属性"}),"：像 ",e.jsx("code",{children:':disabled="false"'})," 时，Vue 会把该属性",e.jsx("strong",{children:"整个移除"}),"，而不是渲染成 ",e.jsx("code",{children:'disabled="false"'}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"动态参数"}),"：",e.jsx("code",{children:':[attrName]="value"'})," 连「属性名」本身都可以是变量。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"批量绑定"}),"：",e.jsx("code",{children:'v-bind="obj"'}),"（不带参数）会把对象的每个键值 展开成一个个属性。"]})]}),e.jsx("h2",{children:"四、条件渲染：v-if 家族 vs v-show"}),e.jsxs("p",{children:["让元素「出现或消失」有两条路。",e.jsx("code",{children:"v-if"})," / ",e.jsx("code",{children:"v-else-if"})," / ",e.jsx("code",{children:"v-else"}),"是真正的条件渲染：条件为假时，元素压根不会出现在 DOM 里。",e.jsx("code",{children:"v-show"})," 则永远渲染元素， 只是通过切换 CSS 的 ",e.jsx("code",{children:"display"})," 来显隐。"]}),e.jsx(s,{lang:"vue",title:"v-if 家族与 v-show",code:o}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"v-if 家族"}),e.jsx("th",{children:"v-show"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"实现方式"}),e.jsx("td",{children:"条件为假则不创建 / 销毁 DOM"}),e.jsxs("td",{children:["始终创建，切换 ",e.jsx("code",{children:"display:none"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"初始开销"}),e.jsx("td",{children:"低（假则不渲染）"}),e.jsx("td",{children:"较高（无论真假都渲染）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"切换开销"}),e.jsx("td",{children:"较高（反复创建销毁）"}),e.jsx("td",{children:"低（只改样式）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"支持 else 链"}),e.jsxs("td",{children:["支持 ",e.jsx("code",{children:"v-else-if"})," / ",e.jsx("code",{children:"v-else"})]}),e.jsx("td",{children:"不支持"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能用在 template 上"}),e.jsx("td",{children:"能（不渲染额外标签）"}),e.jsx("td",{children:"不能"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"适用场景"}),e.jsx("td",{children:"条件很少改变、或初始就不需要"}),e.jsx("td",{children:"频繁切换显隐"})]})]})]}),e.jsxs(i,{variant:"tip",title:"一句话取舍",children:["切换非常频繁（如选项卡、折叠面板）用 ",e.jsx("code",{children:"v-show"}),"；条件很少变、或某些分支可能永远用不到 用 ",e.jsx("code",{children:"v-if"}),"。"]}),e.jsx("h2",{children:"五、v-for：列表渲染与 key 的重要性"}),e.jsxs("p",{children:[e.jsx("code",{children:"v-for"})," 把一个数组 / 对象 / 数字范围渲染成一组元素。它的语法是",e.jsx("code",{children:"item in list"})," 或带下标的 ",e.jsx("code",{children:"(item, index) in list"}),"。 遍历对象时还能拿到键与序号：",e.jsx("code",{children:"(value, key, index) in obj"}),"。"]}),e.jsx(s,{lang:"vue",title:"v-for 的几种遍历",code:h}),e.jsxs(n,{children:["每个 ",e.jsx("code",{children:"v-for"})," 都应配一个 ",e.jsx("code",{children:":key"}),"，且 key 要用",e.jsx("strong",{children:"稳定且唯一"}),"的标识 （通常是数据的 id）。key 是 Vue 用来在更新时「认出谁是谁」的身份证，有了它，Vue 才能在列表 增删、排序时高效地复用、移动节点。"]}),e.jsxs(i,{variant:"warn",title:"不要用 index 当 key",children:["当列表会发生",e.jsx("strong",{children:"插入、删除、排序"}),"时，用数组下标 ",e.jsx("code",{children:"index"})," 作 key 会让 每个位置的 key 都跟着错位，导致 Vue 复用了错误的节点——常见症状是：删了第一项，结果勾选状态、 输入框内容「串台」到了别的行。只有当列表是",e.jsx("strong",{children:"纯静态、永不重排"}),"时，用 index 才勉强安全。"]}),e.jsx("h2",{children:"六、v-on：事件与修饰符"}),e.jsxs("p",{children:[e.jsx("code",{children:"v-on"})," 监听 DOM 事件并执行处理逻辑，简写是 ",e.jsx("code",{children:"@"}),"。处理函数既可以是方法名， 也可以是行内表达式；需要原生事件对象时用特殊变量 ",e.jsx("code",{children:"$event"}),"。"]}),e.jsx(s,{lang:"vue",title:"v-on 与各类修饰符",code:x}),e.jsx("p",{children:"修饰符让常见的事件处理写法更短，链式书写即可叠加："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"修饰符"}),e.jsx("th",{children:"作用"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:".prevent"})}),e.jsxs("td",{children:["调用 ",e.jsx("code",{children:"event.preventDefault()"}),"，如阻止表单刷新页面"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:".stop"})}),e.jsxs("td",{children:["调用 ",e.jsx("code",{children:"event.stopPropagation()"}),"，阻止事件冒泡"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:".once"})}),e.jsx("td",{children:"事件只触发一次后自动解绑"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:".self"})}),e.jsx("td",{children:"只有事件源是元素自身时才触发"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:".enter"})," / ",e.jsx("code",{children:".esc"})]}),e.jsx("td",{children:"按键修饰符：仅在按下指定键时触发"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:".ctrl"})," / ",e.jsx("code",{children:".shift"})]}),e.jsx("td",{children:"系统修饰键：需同时按下才触发"})]})]})]}),e.jsx("h2",{children:"七、class 与 style 绑定"}),e.jsxs("p",{children:["给元素动态加类名或内联样式是高频需求，Vue 为 ",e.jsx("code",{children:":class"})," 和 ",e.jsx("code",{children:":style"})," 提供了 专门的对象 / 数组语法，比手动拼字符串清晰得多。"]}),e.jsx(s,{lang:"vue",title:"class 与 style 的对象 / 数组语法",code:j}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"class 对象语法"}),"：键是类名，值为真该类就生效，非常适合「状态决定样式」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"class 数组语法"}),"：适合需要同时拼多个类、或类名本身也是变量的场景。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"与静态 class 共存"}),"：",e.jsx("code",{children:'class="card" :class="{...}"'})," 两者会自动合并。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"style 对象"}),"：CSS 属性名写成驼峰（",e.jsx("code",{children:"fontSize"}),"）或带引号的连字符形式。"]})]}),e.jsx("h2",{children:"八、综合实战：一个待办列表模板"}),e.jsxs("p",{children:["下面把本章所有指令拢到一起：",e.jsx("code",{children:"v-model"})," 收集输入（下一章细讲）、",e.jsx("code",{children:"@keyup.enter"})," 回车新增、",e.jsx("code",{children:":disabled"})," 控制按钮、",e.jsx("code",{children:"v-for"})," + 稳定",e.jsx("code",{children:":key"})," 渲染列表、",e.jsx("code",{children:":class"})," 标记完成态、",e.jsx("code",{children:"@click.stop"})," 删除、",e.jsx("code",{children:"v-if"})," 处理空状态。"]}),e.jsx(s,{lang:"vue",title:"待办列表：指令综合演练",code:v}),e.jsxs(r,{title:"读懂这个待办列表的几个关键点",children:[e.jsxs("p",{children:["1. 列表用 ",e.jsx("code",{children:"todo.id"})," 而非 ",e.jsx("code",{children:"index"})," 作 key，删除中间项后勾选状态不会串台。"]}),e.jsxs("p",{children:["2. ",e.jsx("code",{children:"remaining"})," 和 ",e.jsx("code",{children:"visibleTodos"})," 用计算属性派生，模板里只读结果， 保持模板内只放表达式的纪律。"]}),e.jsxs("p",{children:["3. 空状态用 ",e.jsx("code",{children:"v-if"})," 而非 ",e.jsx("code",{children:"v-show"}),"：列表为空时根本不需要那个节点存在。"]})]}),e.jsxs(i,{variant:"tip",children:["你可能注意到例子里的 ",e.jsx("code",{children:"v-model"})," 还没正式讲——它其实是",e.jsx("code",{children:"v-bind"})," 加 ",e.jsx("code",{children:"v-on"})," 的组合语法糖。下一章我们就把 ",e.jsx("code",{children:"v-model"}),"和表单处理彻底讲透。"]}),e.jsx(t,{points:["Vue 模板是合法 HTML 的超集，最终会被编译成返回 VNode 的渲染函数；插值与指令里只能放单个表达式，不能放语句。","文本插值用双大括号，只能用于文本位置，不能用于属性；属性动态赋值要用 v-bind（简写 :）。","v-bind 支持简写、布尔属性自动增删、动态参数 :[name] 与无参批量绑定。","v-if 家族真正增删 DOM 且支持 else 链与 template 包裹；v-show 只切换 display，适合频繁显隐。","v-for 遍历数组 / 对象 / 范围，必须配稳定唯一的 :key；列表会增删排序时绝不能用 index 当 key。","v-on（简写 @）监听事件，支持 .prevent / .stop / .once 等事件修饰符与 .enter 等按键修饰符。","class / style 用对象与数组语法绑定，比拼字符串更清晰，且能与静态 class 自动合并。"]})]})}export{y as default};
