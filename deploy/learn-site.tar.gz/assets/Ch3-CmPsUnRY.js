import{r as u,j as e}from"./index-BdVncPlI.js";import{L as m,S}from"./Summary-Baiwq3-G.js";import{K as C}from"./KeyIdea-Cnr-5ipR.js";import{E as j}from"./Example-phQ905Fb.js";import{P as R}from"./Practice-CD-79usu.js";import{C as s}from"./Callout-BRUKkrb4.js";import{C as t}from"./CodeBlock-DCdshbU5.js";import{F as f}from"./Figure-YSBQF7O5.js";const i=[{desc:"请求先到达前端控制器 DispatcherServlet(统一入口)",hl:"ds"},{desc:"DispatcherServlet 问 HandlerMapping：这个 URL 该交给哪个 Controller？",hl:"hm"},{desc:"HandlerAdapter 适配并真正调用对应的 Controller 方法",hl:"ha"},{desc:"Controller 执行业务，返回 ModelAndView(模型数据 + 视图名)",hl:"c"},{desc:"ViewResolver 把视图名解析成具体视图(如 JSP/Thymeleaf)",hl:"vr"},{desc:"视图渲染(填入模型数据)，结果返回给客户端",hl:"view"}];function H(){const[d,o]=u.useState(0),c=i[d],n=r=>c.hl===r,g=e.jsxs(e.Fragment,{children:[e.jsx("button",{className:"fig-btn",onClick:()=>o(r=>Math.min(r+1,i.length-1)),children:"下一步 ▸"}),e.jsx("button",{className:"fig-btn",onClick:()=>o(0),children:"重来"}),e.jsx("span",{className:"fig-note",children:`第 ${d+1}/${i.length} 步`})]}),l=(r,a,h,x,v,p)=>e.jsxs("g",{children:[e.jsx("rect",{x:a,y:h,width:x,height:"38",rx:"8",fill:n(r)?p:"var(--bg-subtle)",stroke:n(r)?p:"var(--border-strong)",strokeWidth:n(r)?2:1}),e.jsx("text",{x:a+x/2,y:h+23,textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"10",fontWeight:"700",fill:n(r)?"#ffffff":"var(--ink)",children:v})]});return e.jsx(f,{caption:"SpringMVC 一次请求的处理流程，核心是前端控制器 DispatcherServlet 统一调度：找处理器 → 适配调用 → 拿 ModelAndView → 解析视图 → 渲染返回。",controls:g,children:e.jsxs("svg",{viewBox:"0 0 460 190",width:"460",role:"img","aria-label":"SpringMVC 流程",children:[l("ds",160,20,140,"DispatcherServlet","var(--accent)"),l("hm",20,78,130,"HandlerMapping","var(--violet)"),l("ha",165,78,130,"HandlerAdapter","var(--violet)"),l("c",310,78,130,"Controller","var(--green)"),l("vr",95,130,130,"ViewResolver","var(--amber)"),l("view",250,130,110,"View 渲染","var(--amber)"),e.jsx("line",{x1:"200",y1:"58",x2:"85",y2:"78",stroke:"var(--ink-faint)",strokeWidth:"1.2",markerEnd:"url(#mv-a)"}),e.jsx("line",{x1:"230",y1:"58",x2:"230",y2:"78",stroke:"var(--ink-faint)",strokeWidth:"1.2",markerEnd:"url(#mv-a)"}),e.jsx("line",{x1:"295",y1:"97",x2:"310",y2:"97",stroke:"var(--ink-faint)",strokeWidth:"1.2",markerEnd:"url(#mv-a)"}),e.jsx("line",{x1:"230",y1:"58",x2:"160",y2:"130",stroke:"var(--ink-faint)",strokeWidth:"1.2",markerEnd:"url(#mv-a)"}),e.jsx("line",{x1:"225",y1:"149",x2:"250",y2:"149",stroke:"var(--ink-faint)",strokeWidth:"1.2",markerEnd:"url(#mv-a)"}),e.jsx("defs",{children:e.jsx("marker",{id:"mv-a",markerWidth:"8",markerHeight:"8",refX:"5",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L5,3 L0,6 Z",fill:"var(--ink-faint)"})})}),e.jsx("rect",{x:"20",y:"160",width:"420",height:"0",fill:"none"}),e.jsx("text",{x:"20",y:"176",fontFamily:"var(--sans)",fontSize:"12",fill:"var(--ink)",children:c.desc})]})})}const M=`@RestController          // = @Controller + @ResponseBody，返回值直接写进响应体
@RequestMapping("/api/users")
class UserController {

    @Autowired
    private UserService userService;

    // GET /api/users/123 → 直接返回 JSON，不走视图解析
    @GetMapping("/{id}")
    public User getUser(@PathVariable Long id) {
        return userService.findById(id);
    }
}`,A=`// 拦截器：实现 HandlerInterceptor，由 DispatcherServlet 在分发前后调用
@Component
class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest req,
                             HttpServletResponse resp,
                             Object handler) {
        String token = req.getHeader("Authorization");
        if (token == null) {
            resp.setStatus(401);
            return false;   // 返回 false 直接中断，不再进入 Controller
        }
        return true;        // 放行
    }
}

@Configuration
class WebConfig implements WebMvcConfigurer {
    @Autowired
    private AuthInterceptor authInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor)
                .addPathPatterns("/api/**");   // 只拦 /api 开头的请求
    }
}`,V=`// 全局异常处理：一处定义，所有 Controller 通用
@RestControllerAdvice          // = @ControllerAdvice + @ResponseBody
class GlobalExceptionHandler {

    // 参数校验失败统一转成 400 + 友好提示
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<?> handleValid(MethodArgumentNotValidException e) {
        String msg = e.getBindingResult().getFieldError().getDefaultMessage();
        return Result.fail(400, msg);
    }

    // 业务异常 → 统一包装；兜底 Exception → 500，避免堆栈泄露给前端
    @ExceptionHandler(BizException.class)
    public Result<?> handleBiz(BizException e) {
        return Result.fail(e.getCode(), e.getMessage());
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Result<?> handleAll(Exception e) {
        log.error("未捕获异常", e);
        return Result.fail(500, "系统繁忙，请稍后再试");
    }
}`,E=`@RestController
@RequestMapping("/api/orders")
class OrderController {

    // 1. 路径变量
    @GetMapping("/{id}")
    public Order get(@PathVariable Long id) { /* ... */ }

    // 2. 查询参数，带默认值与是否必填
    @GetMapping
    public List<Order> list(@RequestParam(defaultValue = "1") int page,
                            @RequestParam(required = false) String status) { /* ... */ }

    // 3. JSON 请求体 + 参数校验（@Valid 触发 JSR-303 校验）
    @PostMapping
    public Order create(@RequestBody @Valid OrderForm form) { /* ... */ }

    // 4. 请求头
    @GetMapping("/whoami")
    public String who(@RequestHeader("Authorization") String token) { /* ... */ }
}`;function B(){return e.jsxs(e.Fragment,{children:[e.jsx(m,{children:e.jsxs("p",{children:["一个 HTTP 请求打到 Spring 应用，是怎么一步步走到你写的 ",e.jsx("code",{children:"Controller"})," 方法、又怎么把结果返回去的？ 答案的中枢是 ",e.jsx("em",{children:"DispatcherServlet"}),"（前端控制器）。这一章我们顺着「一个请求的旅程」， 把 SpringMVC 的核心组件和完整流程串起来，这是面试 Web 层几乎必问的题。"]})}),e.jsx("h2",{children:"核心组件"}),e.jsx("p",{children:"SpringMVC 把请求处理拆成几个各司其职的组件，记住它们的分工，流程就自然清晰了："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"DispatcherServlet"}),"：",e.jsx("em",{children:"前端控制器"}),"，所有请求的统一入口，负责调度下面这些组件。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"HandlerMapping"}),"：根据请求 URL 找到对应的处理器（哪个 Controller 的哪个方法）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"HandlerAdapter"}),"：适配并真正调用处理器方法，屏蔽不同类型 Controller 的差异。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Controller"}),"：你写的业务处理器，执行逻辑并返回结果。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"ViewResolver"}),"：把逻辑视图名解析成具体视图对象（如 JSP、Thymeleaf 模板）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"HandlerExceptionResolver"}),"：处理整个流程中抛出的异常，把它们转成合适的响应（",e.jsx("code",{children:"@ExceptionHandler"})," 就走这里）。"]})]}),e.jsxs("p",{children:[e.jsx("strong",{children:"为什么要搞这么多组件、而不是一个大 Servlet 全包？"}),"这是",e.jsx("strong",{children:"前端控制器模式"}),"加",e.jsx("strong",{children:"策略模式"}),"的经典落地：DispatcherServlet 只负责「调度」，把「URL 怎么映射」「方法怎么调用」 「视图怎么解析」「异常怎么处理」分别抽成可插拔的策略接口。于是你想支持一种新的参数类型、 新的返回值格式、新的视图技术，只要往对应的扩展点塞实现，",e.jsx("strong",{children:"完全不用改 DispatcherServlet 本身"}),"—— 这正是「对扩展开放、对修改关闭」的开闭原则在框架级别的体现。"]}),e.jsx("h3",{children:"完整流程"}),e.jsx("p",{children:"把上面的组件按顺序连起来，就是一个请求的完整生命周期："}),e.jsxs("ul",{children:[e.jsxs("li",{children:["请求到达 ",e.jsx("strong",{children:"DispatcherServlet"}),"（统一入口）。"]}),e.jsxs("li",{children:["DispatcherServlet 问 ",e.jsx("strong",{children:"HandlerMapping"}),"：这个 URL 该交给哪个 handler？"]}),e.jsxs("li",{children:["拿到 handler 后，交给 ",e.jsx("strong",{children:"HandlerAdapter"})," 执行，真正调用 Controller 方法。"]}),e.jsxs("li",{children:["Controller 执行业务，返回 ",e.jsx("strong",{children:"ModelAndView"}),"（模型数据 + 逻辑视图名）。"]}),e.jsxs("li",{children:["DispatcherServlet 把视图名交给 ",e.jsx("strong",{children:"ViewResolver"})," 解析成具体视图。"]}),e.jsxs("li",{children:["视图",e.jsx("em",{children:"渲染"}),"（填入模型数据），结果返回给客户端。"]})]}),e.jsx(j,{title:"一个 GET 请求的旅程",children:e.jsxs("p",{children:["浏览器发出 ",e.jsx("code",{children:"GET /api/users/123"}),"，它会这样走完全程：请求先撞上",e.jsx("strong",{children:"DispatcherServlet"}),"；DispatcherServlet 拿 URL 去问",e.jsx("strong",{children:"HandlerMapping"}),"，得知该交给 ",e.jsx("code",{children:"UserController#getUser"}),"；",e.jsx("strong",{children:"HandlerAdapter"})," 把路径里的 ",e.jsx("code",{children:"123"})," 绑定到 ",e.jsx("code",{children:"@PathVariable id"})," 并调用方法； 方法返回一个 ",e.jsx("code",{children:"User"})," 对象。由于这是 ",e.jsx("code",{children:"@RestController"}),"，结果不走视图解析， 而是被消息转换器序列化成 JSON 直接写回响应体。"]})}),e.jsx(H,{}),e.jsx("h3",{children:"参数是怎么从 HTTP 绑到方法形参的"}),e.jsxs("p",{children:["Controller 方法的参数五花八门（路径变量、查询参数、JSON 体、请求头），它们能自动「填进来」， 靠的是 ",e.jsx("code",{children:"HandlerAdapter"})," 背后一组 ",e.jsx("strong",{children:"HandlerMethodArgumentResolver"}),"（参数解析器）。 每个解析器认领一种注解：",e.jsx("code",{children:"@PathVariable"}),"、",e.jsx("code",{children:"@RequestParam"}),"、",e.jsx("code",{children:"@RequestBody"}),"、",e.jsx("code",{children:"@RequestHeader"})," 各有专门的解析器；返回值同理由 ",e.jsx("strong",{children:"HandlerMethodReturnValueHandler"})," 处理。"]}),e.jsx(t,{lang:"java",title:"OrderController.java（四类参数绑定）",code:E}),e.jsx(s,{variant:"info",title:"@RequestParam 与 @RequestBody 的高频混淆",children:e.jsxs("p",{children:[e.jsx("code",{children:"@RequestParam"})," 取的是 URL 查询串或表单字段（",e.jsx("code",{children:"application/x-www-form-urlencoded"}),"）， 一个请求里可以有多个；",e.jsx("code",{children:"@RequestBody"})," 取的是整个请求体并交给消息转换器反序列化（通常是 JSON）， 一个方法",e.jsx("strong",{children:"最多一个"}),"。把前端发的 JSON 用 ",e.jsx("code",{children:"@RequestParam"})," 接，必然接到 null——这是新手最常见的 400/null 来源。"]})}),e.jsx(C,{title:"@RestController 为什么不走视图解析",children:e.jsxs("p",{children:[e.jsx("code",{children:"@RestController"})," 等于 ",e.jsx("code",{children:"@Controller"})," 加 ",e.jsx("code",{children:"@ResponseBody"}),"。 普通 ",e.jsx("code",{children:"@Controller"})," 方法返回的字符串会被当成",e.jsx("em",{children:"逻辑视图名"}),"交给 ViewResolver 去找页面； 而加了 ",e.jsx("code",{children:"@ResponseBody"})," 后，返回值被 ",e.jsx("em",{children:"HttpMessageConverter"}),"（如 Jackson）直接序列化成 JSON 写进响应体，",e.jsx("strong",{children:"完全跳过 ViewResolver 这一步"}),"。这就是前后端分离时人人用 @RestController 的原因—— 它要的是数据，不是页面。"]})}),e.jsxs(s,{variant:"warn",title:"拦截器 Interceptor vs 过滤器 Filter",children:[e.jsx("p",{children:"这两个都能在请求前后做处理，但层级和能力不同，别混为一谈："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Filter（过滤器）"}),"：属于 Servlet 规范，由 Servlet 容器（如 Tomcat）管理，作用在 DispatcherServlet ",e.jsx("em",{children:"之前"}),"， 能拦截一切请求（包括静态资源），但拿不到 Spring 的 handler 信息。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Interceptor（拦截器）"}),"：属于 SpringMVC，由 DispatcherServlet 调用，作用在",e.jsx("em",{children:"找到 handler 之后"}),"， 能拿到具体的 Controller 方法、能访问 Spring 容器里的 Bean，粒度更细。"]}),e.jsx("li",{children:"执行顺序：Filter 包在最外层，Interceptor 在内层；请求是 Filter → Interceptor → Controller，响应反向。"})]})]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"对比项"}),e.jsx("th",{children:"Filter"}),e.jsx("th",{children:"Interceptor"}),e.jsx("th",{children:"AOP"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"规范来源"}),e.jsx("td",{children:"Servlet 规范"}),e.jsx("td",{children:"SpringMVC"}),e.jsx("td",{children:"Spring AOP"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"作用位置"}),e.jsx("td",{children:"进 DispatcherServlet 前"}),e.jsx("td",{children:"找到 handler 后"}),e.jsx("td",{children:"任意 Bean 方法"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能否拿到 handler"}),e.jsx("td",{children:"不能"}),e.jsx("td",{children:"能"}),e.jsx("td",{children:"能（方法签名/参数）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"典型用途"}),e.jsx("td",{children:"编码、跨域、压缩、全局日志"}),e.jsx("td",{children:"登录鉴权、权限、耗时统计"}),e.jsx("td",{children:"事务、细粒度日志、缓存"})]})]})]}),e.jsxs(j,{title:"HandlerInterceptor 的三个回调时机",children:[e.jsx("p",{children:"拦截器有三个钩子，对应请求处理的不同阶段，组合起来能做很多事："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"preHandle"}),"：Controller 执行",e.jsx("em",{children:"前"}),"，返回 ",e.jsx("code",{children:"false"})," 直接中断（鉴权常用）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"postHandle"}),"：Controller 执行",e.jsx("em",{children:"后"}),"、视图渲染",e.jsx("em",{children:"前"}),"，能改 ",e.jsx("code",{children:"ModelAndView"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"afterCompletion"}),"：整个请求",e.jsx("em",{children:"完成后"}),"（视图也渲染完），无论成功失败都执行，适合做耗时统计、资源清理。"]})]}),e.jsxs("p",{children:["一个坑：多个拦截器时，",e.jsx("code",{children:"preHandle"})," 按注册顺序",e.jsx("strong",{children:"正序"}),"执行， 而 ",e.jsx("code",{children:"postHandle"})," 和 ",e.jsx("code",{children:"afterCompletion"})," ",e.jsx("strong",{children:"逆序"}),"执行，像栈一样。 且只要某个拦截器的 ",e.jsx("code",{children:"preHandle"})," 返回了 ",e.jsx("code",{children:"true"}),"，它的 ",e.jsx("code",{children:"afterCompletion"})," 就一定会被调用—— 这保证了「已经放行的拦截器一定有机会清理」。"]})]}),e.jsxs(s,{variant:"info",title:"全局异常处理：生产必备的 @RestControllerAdvice",children:[e.jsxs("p",{children:["没有统一异常处理，每个 Controller 都得写一堆 try-catch，异常堆栈还可能直接糊到前端脸上。",e.jsx("code",{children:"@RestControllerAdvice"})," + ",e.jsx("code",{children:"@ExceptionHandler"})," 让你",e.jsx("strong",{children:"一处定义、全局生效"}),"， 把各类异常转成统一的返回结构，是企业项目的标配："]}),e.jsx(t,{lang:"java",title:"GlobalExceptionHandler.java",code:V}),e.jsxs("p",{children:["注意它处理的是",e.jsx("strong",{children:"进入 DispatcherServlet 之后"}),"抛出的异常；如果异常发生在 Filter 层 （还没到 SpringMVC），",e.jsx("code",{children:"@ControllerAdvice"})," 是兜不住的，那种得靠 Filter 自己处理或交给容器的错误页。"]})]}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["被问「SpringMVC 处理流程」时，先报出五大组件及其分工，再按 「请求 → DispatcherServlet → HandlerMapping 找 handler → HandlerAdapter 执行 → 返回 ModelAndView → ViewResolver 解析 → 渲染返回」 这条主线一气呵成。能主动补充「",e.jsx("code",{children:"@RestController"})," / ",e.jsx("code",{children:"@ResponseBody"})," 走消息转换器、不走视图解析」和 「Interceptor 与 Filter 的层级区别」，会明显加分。"]}),e.jsxs(R,{title:"一个 RestController + 拦截器",children:[e.jsxs("p",{children:["先写一个返回 JSON 的 ",e.jsx("code",{children:"@RestController"}),"："]}),e.jsx(t,{lang:"java",title:"UserController.java",code:M}),e.jsxs("p",{children:["再加一个鉴权拦截器，在请求进入 Controller 前校验 token，并通过 ",e.jsx("code",{children:"WebMvcConfigurer"})," 注册到",e.jsx("code",{children:"/api/**"})," 路径："]}),e.jsx(t,{lang:"java",title:"AuthInterceptor.java",code:A}),e.jsxs("p",{children:["动手验证：不带 ",e.jsx("code",{children:"Authorization"})," 头访问 ",e.jsx("code",{children:"/api/users/1"})," 应返回 401（被 preHandle 中断、根本没进 Controller）； 带上头则正常返回 JSON。借此体会拦截器「在 handler 之后、Controller 之前」的位置。"]})]}),e.jsx(S,{points:["DispatcherServlet 是前端控制器，所有请求的统一入口，负责调度其余组件。","核心组件：HandlerMapping 找 handler、HandlerAdapter 执行、Controller 处理业务、ViewResolver 解析视图。","完整流程：请求 → DispatcherServlet → HandlerMapping → HandlerAdapter → ModelAndView → ViewResolver → 渲染返回。","@RestController / @ResponseBody 经 HttpMessageConverter 直接返回 JSON，跳过 ViewResolver。","Filter 属 Servlet 容器、在 DispatcherServlet 之前；Interceptor 属 SpringMVC、在找到 handler 之后，粒度更细。","MVC 用前端控制器+策略模式：参数靠 ArgumentResolver 绑定，@RequestParam 取查询/表单、@RequestBody 取 JSON 体且最多一个。","Interceptor 三钩子 preHandle/postHandle/afterCompletion；多拦截器 preHandle 正序、后两者逆序，放行过的一定会 afterCompletion。","生产用 @RestControllerAdvice + @ExceptionHandler 做全局异常处理，但兜不住 Filter 层（进 DispatcherServlet 前）的异常。","面试落点：先报组件分工，再串完整流程，主动补 JSON 返回与拦截器/过滤器区别即可拿高分。"]})]})}export{B as default};
