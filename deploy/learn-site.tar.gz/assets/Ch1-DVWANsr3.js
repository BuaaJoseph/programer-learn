import{j as e}from"./index-BnUyEu5E.js";import{L as n,S as r}from"./Summary-qZ1-DBVA.js";import{K as o}from"./KeyIdea-DOTgzjr8.js";import{C as s}from"./Callout-DUAtr8Nz.js";import{C as t}from"./CodeBlock-DIEQOVpA.js";import{E as i}from"./Example-BRazL43h.js";const d=`// 浏览器原生 History API：改 URL 但不刷新整页
history.pushState({ page: 2 }, '', '/posts/2')  // 压入一条新历史记录，地址栏变成 /posts/2
history.replaceState({}, '', '/login')          // 替换当前记录，不新增历史栈条目

// 用户点「后退 / 前进」时，浏览器触发 popstate，我们据此重新渲染对应视图
window.addEventListener('popstate', (e) => {
  console.log('回退到的状态：', e.state)
  renderViewForUrl(location.pathname)  // 根据当前 URL 决定渲染哪个组件
})`,a=`import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'

function App() {
  return (
    <BrowserRouter>
      {/* 导航区：Link 不会触发整页刷新，只改 URL 并切换视图 */}
      <nav>
        <Link to="/">首页</Link>
        <Link to="/about">关于</Link>
        <Link to="/posts">文章</Link>
      </nav>

      {/* Routes 在一堆 Route 里挑出第一个「最匹配」当前 URL 的来渲染 */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/posts" element={<PostList />} />
        {/* 通配：上面都没命中时兜底，做 404 页 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  )
}`,c=`import { HashRouter } from 'react-router-dom'

// HashRouter 把路由信息放到 # 后面：example.com/#/about
// 优点：纯静态托管（GitHub Pages、对象存储）也能直接刷新 /#/about 不 404
// 因为 # 后面的内容浏览器不会发给服务器，服务器永远只收到根路径请求
function Root() {
  return (
    <HashRouter>
      {/* 内部用法和 BrowserRouter 完全一致 */}
      <App />
    </HashRouter>
  )
}`,l=`import { NavLink } from 'react-router-dom'

// NavLink 比 Link 多一件事：知道自己「是否处于激活状态」
// 它给 className / style 传入 { isActive, isPending }，方便高亮当前页
function Menu() {
  return (
    <nav>
      <NavLink
        to="/posts"
        className={({ isActive }) => (isActive ? 'tab tab-active' : 'tab')}
      >
        文章
      </NavLink>

      {/* end 表示「精确匹配」：没有 end 时 "/" 会匹配所有子路径 */}
      <NavLink to="/" end>
        首页
      </NavLink>
    </nav>
  )
}`,h=`import { Routes, Route, Outlet, Link, NavLink } from 'react-router-dom'

// 父布局：公共的壳（侧边栏 + 顶栏），子路由内容渲染到 <Outlet /> 的位置
function DashboardLayout() {
  return (
    <div className="dashboard">
      <aside>
        <NavLink to="/dashboard">概览</NavLink>
        <NavLink to="/dashboard/settings">设置</NavLink>
      </aside>
      <main>
        {/* 子路由匹配到的组件会被塞进这里 */}
        <Outlet />
      </main>
    </div>
  )
}

function App() {
  return (
    <Routes>
      {/* 父路由只提供布局，本身没有内容 */}
      <Route path="/dashboard" element={<DashboardLayout />}>
        {/* index 路由：精确匹配父路径 /dashboard 时渲染它 */}
        <Route index element={<Overview />} />
        {/* 相对路径：完整地址是 /dashboard/settings */}
        <Route path="settings" element={<Settings />} />
      </Route>
    </Routes>
  )
}`,u=`import { Routes, Route, useParams, Link } from 'react-router-dom'

function App() {
  return (
    <Routes>
      {/* :id 是动态段，匹配 /posts/任意值 */}
      <Route path="/posts/:id" element={<PostDetail />} />
    </Routes>
  )
}

function PostList() {
  return (
    <ul>
      <li><Link to="/posts/42">第 42 篇</Link></li>
      <li><Link to="/posts/99">第 99 篇</Link></li>
    </ul>
  )
}

function PostDetail() {
  // useParams 读出 URL 里的动态段，键名就是 :id 里的 id
  const { id } = useParams()
  return <h1>正在看第 {id} 篇文章</h1>
}`,x=`import { useNavigate, useLocation, useSearchParams } from 'react-router-dom'

function LoginButton() {
  const navigate = useNavigate()

  async function handleLogin() {
    await doLogin()
    navigate('/dashboard')            // 编程式跳转：登录成功后去仪表盘
    // navigate(-1)                   // 等价于浏览器后退
    // navigate('/login', { replace: true })  // 替换当前历史，禁止回退到这一页
  }

  return <button onClick={handleLogin}>登录</button>
}

function SearchPage() {
  const location = useLocation()           // 当前 location：pathname / search / hash / state
  const [params, setParams] = useSearchParams()  // 读写 ?key=value 查询串

  const keyword = params.get('q') || ''
  return (
    <input
      value={keyword}
      onChange={(e) => setParams({ q: e.target.value })}  // 改 URL 上的 ?q=...
    />
  )
}`,j=`import {
  HashRouter, Routes, Route, Outlet,
  Link, NavLink, useParams, useNavigate,
} from 'react-router-dom'

// ---- 公共布局：顶栏 + 内容出口 ----
function Layout() {
  return (
    <div>
      <header>
        <NavLink to="/" end>首页</NavLink>
        <NavLink to="/posts">文章</NavLink>
        <NavLink to="/about">关于</NavLink>
      </header>
      <main><Outlet /></main>
    </div>
  )
}

function Home() { return <h1>欢迎</h1> }
function About() { return <h1>关于我们</h1> }

function PostList() {
  return (
    <ul>
      <li><Link to="/posts/1">文章一</Link></li>
      <li><Link to="/posts/2">文章二</Link></li>
    </ul>
  )
}

function PostDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  return (
    <div>
      <h1>文章 #{id}</h1>
      <button onClick={() => navigate('/posts')}>返回列表</button>
    </div>
  )
}

function NotFound() { return <h1>404：页面不存在</h1> }

export default function App() {
  return (
    <HashRouter>
      <Routes>
        {/* 所有页面共用 Layout，内容渲染进它的 Outlet */}
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="about" element={<About />} />
          {/* 文章区：列表 + 详情，详情带动态参数 */}
          <Route path="posts">
            <Route index element={<PostList />} />
            <Route path=":id" element={<PostDetail />} />
          </Route>
          {/* 兜底 404 */}
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </HashRouter>
  )
}`;function k(){return e.jsxs("article",{children:[e.jsxs(n,{children:["在传统多页网站里，每次点链接都向服务器要一张新 HTML，整页白屏、重新加载。 而 React 这类单页应用（SPA）只在首屏加载一次，之后的「翻页」全靠 JavaScript 在浏览器里换内容。问题来了：地址栏的 URL 还能不能用？前进后退还灵不灵？链接还能不能分享？ React Router 就是来回答这些问题的——它把",e.jsx("strong",{children:"URL 和组件"}),"对应起来，让 SPA 既有「换页」的体验，又保留 URL 的全部好处。这一章讲透它的原理与日常 API。"]}),e.jsx("h2",{children:"一、SPA 路由到底要解决什么"}),e.jsx("p",{children:"先想清楚需求。一个像样的「页面」应该满足四件事，而朴素的 SPA（用一个 state 切来切去）会把它们全弄丢："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"不刷新整页"}),"：切视图时不重新拉 HTML、不白屏，体验顺滑。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"URL 决定视图"}),"：地址栏是什么，屏幕上就该是什么——刷新后还在同一页。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"前进后退可用"}),"：浏览器的后退键要能退回上一个视图，而不是退出整个应用。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"链接可分享"}),"：把地址发给别人，对方打开看到的是同一页，而不是首页。"]})]}),e.jsxs("p",{children:["如果只用一个 ",e.jsx("code",{children:"useState"})," 记「当前在第几页」，那么刷新即清零、后退即离站、 链接发出去对方只看到首页——四条全废。路由库的使命就是：",e.jsx("strong",{children:"让视图状态住进 URL 里"}),"， 并和浏览器历史打通。"]}),e.jsxs(o,{children:["路由的本质是一个映射：",e.jsx("strong",{children:"当前 URL → 应该渲染哪个（些）组件"}),"。 React Router 监听 URL 变化，匹配出对应组件并渲染；同时拦截站内导航， 只改 URL 不刷新页面。URL 成了 SPA 的「单一事实来源」。"]}),e.jsx("h2",{children:"二、底层基石：History API 一句话原理"}),e.jsxs("p",{children:["React Router 并不是魔法，它站在浏览器原生的 ",e.jsx("strong",{children:"History API"})," 肩上。 关键就两件事：",e.jsx("code",{children:"history.pushState"})," 能",e.jsx("strong",{children:"改变地址栏 URL 却不触发整页加载"}),"； 而当用户点前进 / 后退时，浏览器抛出 ",e.jsx("code",{children:"popstate"})," 事件，让你有机会 「根据新的 URL 重新渲染」。把这两点接起来，就有了不刷新的可前进后退的路由。"]}),e.jsx(t,{lang:"javascript",title:"History API：路由的底层原理",code:d}),e.jsxs("p",{children:["React Router 把这套底层封装好了：你写声明式的 ",e.jsx("code",{children:"<Route>"})," 配置和",e.jsx("code",{children:"<Link>"}),"，它在内部替你调 ",e.jsx("code",{children:"pushState"}),"、监听 ",e.jsx("code",{children:"popstate"}),"、 做 URL 匹配。你几乎不用直接碰 History API。"]}),e.jsx("h2",{children:"三、两种 Router：BrowserRouter vs HashRouter"}),e.jsxs("p",{children:["React Router 提供两种「路由器外壳」，区别只在于",e.jsx("strong",{children:"URL 长什么样、刷新时谁来处理"}),"："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"BrowserRouter"}),e.jsx("th",{children:"HashRouter"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"URL 形态"}),e.jsx("td",{children:e.jsx("code",{children:"example.com/about"})}),e.jsx("td",{children:e.jsx("code",{children:"example.com/#/about"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"依赖"}),e.jsx("td",{children:"History API（pushState）"}),e.jsx("td",{children:"URL 的 hash（#）片段"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"刷新 /about"}),e.jsx("td",{children:"请求会发到服务器，需服务器把所有路径回退到 index.html"}),e.jsx("td",{children:"服务器只收到根路径，永不 404"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"需要服务器配置"}),e.jsx("td",{children:"需要（fallback 重写）"}),e.jsx("td",{children:"不需要"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"SEO / 美观"}),e.jsx("td",{children:"更干净，利于 SEO"}),e.jsx("td",{children:"带 #，不利 SEO"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"适用"}),e.jsx("td",{children:"有服务端或托管能做 fallback 时"}),e.jsx("td",{children:"纯静态托管、子路径部署、嵌入第三方页面"})]})]})]}),e.jsx(t,{lang:"jsx",title:"BrowserRouter：干净 URL 的常规配置",code:a}),e.jsx(t,{lang:"jsx",title:"HashRouter：纯静态托管的省心选择",code:c}),e.jsxs(s,{variant:"info",title:"我们这个站为什么用 HashRouter",children:["本教学站是",e.jsx("strong",{children:"纯前端、静态托管"}),"的：没有后端，也没法给每条路径配 fallback 重写规则。如果用 BrowserRouter，用户直接刷新 ",e.jsx("code",{children:"/courses/react"}),"这种深层地址，服务器找不到对应文件就会返回 404。HashRouter 把路由放进",e.jsx("code",{children:"#"})," 后面，服务器永远只看到根路径请求，所以无论刷新哪一页都稳。 这就是 App 套壳选 HashRouter 的现实原因——拿确定性换那个 #。"]}),e.jsx("h2",{children:"四、配置路由：Routes / Route 与导航 Link / NavLink"}),e.jsxs("p",{children:[e.jsx("code",{children:"<Routes>"})," 是一组路由的容器，它会在内部所有 ",e.jsx("code",{children:"<Route>"})," 里 挑出",e.jsx("strong",{children:"第一个最匹配当前 URL"}),"的来渲染。每个 ",e.jsx("code",{children:"<Route>"})," 用",e.jsx("code",{children:"path"})," 声明匹配规则，用 ",e.jsx("code",{children:"element"})," 指定命中后渲染什么组件。"]}),e.jsxs("p",{children:["导航不要用 ",e.jsx("code",{children:"<a href>"}),"——那会触发整页刷新，前功尽弃。要用",e.jsx("code",{children:"<Link to>"}),"，它在底层调 ",e.jsx("code",{children:"pushState"}),"，只改 URL 不刷新。 需要「高亮当前页」时用 ",e.jsx("code",{children:"<NavLink>"}),"，它会告诉你自己是否处于激活态。"]}),e.jsx(t,{lang:"jsx",title:"NavLink：自带激活状态的导航",code:l}),e.jsxs(s,{variant:"warn",title:"别用裸 a 标签做站内跳转",children:["站内导航若写成 ",e.jsx("code",{children:'<a href="/about">'}),"，点击会让浏览器向服务器要新页面， 整页重载，React 应用从头初始化，所有内存状态清空。站内一律用",e.jsx("code",{children:"<Link>"})," / ",e.jsx("code",{children:"<NavLink>"}),"；只有跳到",e.jsx("strong",{children:"外站"}),"时才用",e.jsx("code",{children:"<a>"}),"。"]}),e.jsx("h2",{children:"五、嵌套路由与 Outlet"}),e.jsxs("p",{children:["真实应用里页面常有公共外壳：顶栏、侧边栏、面包屑不变，只有中间内容随路由切换。 React Router 用",e.jsx("strong",{children:"嵌套路由"}),"表达这种「布局套内容」的关系：父路由提供布局， 在布局里放一个 ",e.jsx("code",{children:"<Outlet />"})," 作为「子内容的出口」，匹配到的子路由就渲染进去。"]}),e.jsx(t,{lang:"jsx",title:"嵌套路由 + Outlet：布局复用",code:h}),e.jsxs("p",{children:["注意两点：① 子路由的 ",e.jsx("code",{children:"path"})," 写",e.jsx("strong",{children:"相对路径"}),"（如 ",e.jsx("code",{children:"settings"}),"）， 最终地址是父路径拼上来的 ",e.jsx("code",{children:"/dashboard/settings"}),"；② 当 URL 精确等于父路径",e.jsx("code",{children:"/dashboard"})," 时，没有子路径可匹配，这时由 ",e.jsx("strong",{children:"index 路由"}),"顶上。"]}),e.jsx("h3",{children:"index 路由：父路径的默认内容"}),e.jsxs("p",{children:[e.jsx("code",{children:"<Route index element={...} />"})," 没有 ",e.jsx("code",{children:"path"}),"，它表示 「当父路由被精确匹配、且没有更具体的子路由命中时，渲染我」。可以理解成",e.jsx("strong",{children:"这个布局的 首页 / 默认页"}),"。每个有 ",e.jsx("code",{children:"<Outlet />"})," 的父路由通常都该配一个 index， 否则进父路径时 Outlet 里是空的。"]}),e.jsx("h2",{children:"六、动态参数 :id 与 useParams"}),e.jsxs("p",{children:["文章详情、用户主页这类页面，URL 里有一段是变量。用 ",e.jsx("code",{children:":"})," 开头声明",e.jsx("strong",{children:"动态段"}),"：",e.jsx("code",{children:'path="/posts/:id"'})," 能匹配 ",e.jsx("code",{children:"/posts/42"}),"、",e.jsx("code",{children:"/posts/99"}),"……组件里用 ",e.jsx("code",{children:"useParams()"})," 读出这个值。"]}),e.jsx(t,{lang:"jsx",title:"动态参数 :id + useParams",code:u}),e.jsxs("p",{children:[e.jsx("code",{children:"useParams()"})," 返回一个对象，键名就是路径里 ",e.jsx("code",{children:":"})," 后面的名字。 想要多个参数就写多个段，如 ",e.jsx("code",{children:'path="/users/:userId/posts/:postId"'}),"， 读出来就是 ",e.jsx("code",{children:"{ userId, postId }"}),"。"]}),e.jsx("h2",{children:"七、编程式导航与 URL 信息：三个常用 Hook"}),e.jsxs("p",{children:["除了点链接，很多跳转发生在逻辑里——登录成功后去仪表盘、提交后回列表。这时用",e.jsx("code",{children:"useNavigate()"})," 拿到一个 ",e.jsx("code",{children:"navigate"})," 函数手动跳。配套的还有",e.jsx("code",{children:"useLocation()"}),"（读当前地址信息）和 ",e.jsx("code",{children:"useSearchParams()"}),"（读写 ",e.jsx("code",{children:"?key=value"})," 查询串）。"]}),e.jsx(t,{lang:"jsx",title:"useNavigate / useLocation / useSearchParams",code:x}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Hook"}),e.jsx("th",{children:"作用"}),e.jsx("th",{children:"典型场景"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"useNavigate"})}),e.jsx("td",{children:"返回 navigate 函数，编程式跳转"}),e.jsx("td",{children:"登录后跳转、提交后返回、navigate(-1) 后退"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"useLocation"})}),e.jsx("td",{children:"读当前 location（pathname / search / state）"}),e.jsx("td",{children:"记录来源页、根据路径做埋点"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"useSearchParams"})}),e.jsx("td",{children:"读写查询字符串"}),e.jsx("td",{children:"搜索关键词、分页页码、筛选条件"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"useParams"})}),e.jsx("td",{children:"读路径动态段"}),e.jsx("td",{children:"详情页拿 id"})]})]})]}),e.jsxs(s,{variant:"tip",title:"查询串 vs 路径参数怎么选",children:["语义上「定位唯一资源」用",e.jsx("strong",{children:"路径参数"}),"（",e.jsx("code",{children:"/posts/42"}),"）， 「对一个列表做筛选 / 排序 / 分页」用",e.jsx("strong",{children:"查询串"}),"（",e.jsx("code",{children:"/posts?tag=react&page=2"}),"）。 查询串放进 URL 的好处是：用户可以把「筛选后的结果」当链接分享出去。"]}),e.jsx("h2",{children:'八、404：通配 path="*"'}),e.jsxs("p",{children:["当所有具体路由都没命中，需要一个兜底页。用 ",e.jsx("code",{children:'path="*"'})," 匹配任意未匹配的 URL， 通常放在 ",e.jsx("code",{children:"<Routes>"})," 最后，渲染一个 404 组件。它也常用在嵌套布局里， 让「未知子路径」也落在同一套外壳内。"]}),e.jsx("h2",{children:"九、综合示例：多页 + 嵌套布局"}),e.jsx("p",{children:"把前面所有概念串起来——HashRouter 外壳、公共 Layout + Outlet、index 默认页、 文章列表与详情的嵌套、动态参数、编程式返回、404 兜底——就是一个能直接跑的小应用："}),e.jsx(t,{lang:"jsx",title:"可运行示例：多页 + 嵌套 + 动态参数",code:j}),e.jsxs(i,{title:"读懂这个路由表的匹配过程",children:[e.jsxs("p",{children:["访问 ",e.jsx("code",{children:"/#/"}),"：匹配 Layout，再由 index 渲染 Home。"]}),e.jsxs("p",{children:["访问 ",e.jsx("code",{children:"/#/posts"}),"：匹配 Layout 下的 posts，其 index 渲染 PostList。"]}),e.jsxs("p",{children:["访问 ",e.jsx("code",{children:"/#/posts/2"}),"：匹配 Layout → posts → ",e.jsx("code",{children:":id"}),"， PostDetail 用 ",e.jsx("code",{children:"useParams"})," 读到 id 为 2。"]}),e.jsxs("p",{children:["访问 ",e.jsx("code",{children:"/#/xyz"}),"：前面都没命中，落到 ",e.jsx("code",{children:'path="*"'}),"，渲染 NotFound。"]})]}),e.jsx("h2",{children:"十、小结与边界"}),e.jsxs("p",{children:["这一章覆盖的是 React Router 的「声明式路由」核心：URL 与组件的映射、不刷新的导航、 嵌套布局、参数与编程式跳转。它够你搭出绝大多数前端站点的页面结构。但还有一块更进阶的能力 我们留到下一章——",e.jsx("strong",{children:"数据路由"}),"：在进入页面前就把数据取好、用 loader/action 统一管理数据流，以及路由级的代码分割。"]}),e.jsxs(s,{variant:"tip",children:["下一章进入 v6.4+ 引入的 Data Router：",e.jsx("code",{children:"createBrowserRouter"})," + ",e.jsx("code",{children:"RouterProvider"}),"， 把「取数」「提交」「报错」「懒加载」都收进路由配置，让组件更专注于渲染。"]}),e.jsx(r,{points:["SPA 路由要同时满足四件事：不刷新整页、URL 决定视图、前进后退可用、链接可分享；本质是 URL → 组件 的映射。","React Router 站在浏览器 History API 之上：pushState 改 URL 不刷新，popstate 监听前进后退后重新渲染。","BrowserRouter 给干净 URL 但刷新深层路径需服务器 fallback；HashRouter 把路由放进 # 后，纯静态托管刷新不 404——本站正因如此用 HashRouter。","Routes 挑最匹配的 Route 渲染；站内导航用 Link / NavLink（绝不用裸 a），NavLink 自带 isActive 高亮。","嵌套路由用父布局 + Outlet 复用外壳，index 路由当父路径的默认页；动态段 :id 配 useParams 读取。",'编程式导航用 useNavigate；useLocation 读地址、useSearchParams 读写查询串；path="*" 兜底做 404。']})]})}export{k as default};
