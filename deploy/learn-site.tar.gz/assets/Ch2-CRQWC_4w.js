import{j as e}from"./index-BnUyEu5E.js";import{L as i,S as c}from"./Summary-qZ1-DBVA.js";import{K as r}from"./KeyIdea-DOTgzjr8.js";import{C as n}from"./Callout-DUAtr8Nz.js";import{C as s}from"./CodeBlock-DIEQOVpA.js";import{E as t}from"./Example-BRazL43h.js";const l=`import { Suspense } from 'react'

// Profile 内部「会暂停」：它在等数据或等代码就绪
function Page() {
  return (
    <Suspense fallback={<p>加载中…</p>}>
      <Profile />
    </Suspense>
  )
}
// Profile 没准备好时，React 自动显示 fallback；准备好了再无缝换上真实内容`,d=`import { Suspense, lazy } from 'react'

// React.lazy 把组件做成「按需加载」：首屏不下载这段代码
const Settings = lazy(() => import('./Settings.jsx'))

function App({ showSettings }) {
  return (
    <Suspense fallback={<p>正在加载设置面板…</p>}>
      {showSettings && <Settings />}
    </Suspense>
  )
}
// 第一次渲染 Settings 时才去下载它的 chunk，期间展示 fallback`,a=`import { useSuspenseQuery } from '@tanstack/react-query'

// suspense 模式：不再返回 isPending，而是「暂停」交给外层 Suspense 接住
function Profile() {
  const { data } = useSuspenseQuery({
    queryKey: ['profile'],
    queryFn: fetchProfile,
  })
  // 走到这里 data 一定有值——加载态由 <Suspense> 统一处理
  return <h1>{data.name}</h1>
}`,o=`import { use, Suspense } from 'react'

// React 19 的 use()：直接「读」一个 promise，未完成就暂停
function Message({ promise }) {
  const text = use(promise)        // promise 没 resolve，组件暂停
  return <p>{text}</p>
}

function Page({ messagePromise }) {
  return (
    <Suspense fallback={<p>读取消息中…</p>}>
      <Message promise={messagePromise} />
    </Suspense>
  )
}`,u=`import { Suspense } from 'react'
import { ErrorBoundary } from 'react-error-boundary'

// 错误边界接住「加载失败」，Suspense 接住「正在加载」，二者互补
function Page() {
  return (
    <ErrorBoundary fallback={<p>加载失败，请重试</p>}>
      <Suspense fallback={<p>加载中…</p>}>
        <Profile />
      </Suspense>
    </ErrorBoundary>
  )
}`,h=`import { useState, useTransition } from 'react'

function Search({ allItems }) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState(allItems)
  const [isPending, startTransition] = useTransition()

  function handleChange(e) {
    const next = e.target.value
    setQuery(next)                 // 紧急更新：输入框必须立刻跟手

    startTransition(() => {
      // 非紧急更新：标记为「过渡」，可被新输入打断，不阻塞打字
      const filtered = allItems.filter((it) =>
        it.toLowerCase().includes(next.toLowerCase())
      )
      setResults(filtered)
    })
  }

  return (
    <div>
      <input value={query} onChange={handleChange} />
      {isPending && <span>筛选中…</span>}
      <ul>{results.map((r) => <li key={r}>{r}</li>)}</ul>
    </div>
  )
}`,p=`import { useState, useDeferredValue, useMemo } from 'react'

function Search({ allItems }) {
  const [query, setQuery] = useState('')
  const deferredQuery = useDeferredValue(query)  // 延迟版的 query

  // 重计算只跟「延迟值」走：输入飞快时它落后一拍，但绝不卡输入
  const results = useMemo(
    () => allItems.filter((it) => it.includes(deferredQuery)),
    [allItems, deferredQuery]
  )

  const stale = query !== deferredQuery          // 正在追赶时可置灰
  return (
    <div>
      <input value={query} onChange={(e) => setQuery(e.target.value)} />
      <ul style={{ opacity: stale ? 0.5 : 1 }}>
        {results.map((r) => <li key={r}>{r}</li>)}
      </ul>
    </div>
  )
}`,x=`import { startTransition } from 'react'

// 独立函数版：用在事件回调外、或不需要 isPending 的地方
function navigate(url) {
  startTransition(() => {
    setRoute(url)                  // 切路由这种重更新标记为可中断的过渡
  })
}`;function T(){return e.jsxs("article",{children:[e.jsxs(i,{children:["上一章我们解决了「数据怎么取、怎么缓存」。这一章换个角度：当数据还没来、代码还没下载、 或者一次重渲染很费时，",e.jsx("strong",{children:"用户的界面会不会卡住、会不会闪烁"}),"？React 给出的答案是 Suspense 与一组并发特性（",e.jsx("code",{children:"useTransition"}),"、",e.jsx("code",{children:"useDeferredValue"}),"）。它们的共同目标只有一个： 让等待变得声明式、让重渲染不再阻塞用户的输入，整体体验更顺滑。"]}),e.jsx("h2",{children:"一、Suspense：把「正在等待」变成声明式"}),e.jsxs("p",{children:["过去我们处理加载态，是在每个组件里写 ",e.jsx("code",{children:"if (loading) return <Spinner/>"}),"。 Suspense 把这件事翻转过来：",e.jsxs("strong",{children:["子组件只管「我还没准备好就暂停」，由外层的",e.jsx("code",{children:"<Suspense>"})," 统一决定暂停期间显示什么 fallback"]}),"。加载态不再散落在各处， 而是被提到一个清晰的边界上。"]}),e.jsx(s,{lang:"jsx",title:"Suspense 的基本形态",code:l}),e.jsxs(r,{children:["Suspense 的心智模型是：组件在「等数据」或「等代码」时可以",e.jsx("strong",{children:"暂停（suspend）"}),"渲染， React 会沿组件树向上找到最近的 ",e.jsx("code",{children:"<Suspense>"}),"，先展示它的 ",e.jsx("code",{children:"fallback"}),"， 等子树准备好再无缝替换。加载态从「命令式的 if 判断」变成「声明式的边界」。"]}),e.jsxs("p",{children:["哪些东西能触发「暂停」？目前主要有三类：用 ",e.jsx("code",{children:"React.lazy"})," 做代码分割的组件、 支持 Suspense 模式的数据库（如 TanStack Query 的 ",e.jsx("code",{children:"useSuspenseQuery"}),"）、 以及 React 19 的 ",e.jsx("code",{children:"use()"})," 读取一个未完成的 promise。下面逐个看。"]}),e.jsx("h2",{children:"二、与 React.lazy 配合：代码分割"}),e.jsxs("p",{children:[e.jsx("code",{children:"React.lazy"})," 让你把某个组件的代码拆成单独的 chunk，只有真正要渲染它时才下载。 下载这段时间组件「未就绪」，正好被 Suspense 接住显示 fallback。"]}),e.jsx(s,{lang:"jsx",title:"lazy + Suspense 做按需加载",code:d}),e.jsx(t,{title:"为什么首屏更快",children:e.jsxs("p",{children:["假设设置面板有一大坨图表代码，但大多数用户进来根本不点它。用 ",e.jsx("code",{children:"lazy"})," 后， 这段代码",e.jsx("strong",{children:"不进首屏包"}),"，首屏 JS 更小、下载更快、可交互更早； 只有用户真去开设置时才按需拉取，期间 Suspense 给个加载提示即可。"]})}),e.jsx("h2",{children:"三、与数据获取配合：suspense 模式 / RSC / use()"}),e.jsx("p",{children:"Suspense 最初是为代码分割设计的，如今已扩展到数据获取。三条主流路径："}),e.jsx("h3",{children:"3.1 TanStack Query 的 suspense 模式"}),e.jsxs("p",{children:["把 ",e.jsx("code",{children:"useQuery"})," 换成 ",e.jsx("code",{children:"useSuspenseQuery"}),"，组件就不再自己处理 ",e.jsx("code",{children:"isPending"}),"， 而是在数据未就绪时暂停，交给外层 Suspense。好处是组件体内拿到的 ",e.jsx("code",{children:"data"})," 一定有值，代码更干净。"]}),e.jsx(s,{lang:"jsx",title:"useSuspenseQuery",code:a}),e.jsx("h3",{children:"3.2 RSC（React 服务端组件）"}),e.jsxs("p",{children:["在 React 服务端组件里，组件本身可以是 ",e.jsx("code",{children:"async"})," 函数，直接 ",e.jsx("code",{children:"await"})," 数据； Suspense 在服务端就能边等边流式发送 HTML——先发已就绪的部分，慢的部分用 fallback 占位， 好了再流式补上。这让首屏不必死等最慢的数据。"]}),e.jsx("h3",{children:"3.3 use() 读取 promise"}),e.jsxs("p",{children:["React 19 引入的 ",e.jsx("code",{children:"use()"})," 可以在渲染中直接「读」一个 promise：promise 未 resolve 时组件暂停， resolve 后拿到值继续。它把「等一个 Promise」收敛成一行同步风格的读取。"]}),e.jsx(s,{lang:"jsx",title:"use() 读取 promise",code:o}),e.jsx("h2",{children:"四、错误边界：Suspense 的另一半"}),e.jsxs("p",{children:["Suspense 只负责「正在加载」，不负责「加载失败」。失败由",e.jsx("strong",{children:"错误边界（ErrorBoundary）"}),"接住。 两者是互补搭档：一个管等待态、一个管错误态，包在一起就覆盖了异步的两种坏情况。"]}),e.jsx(s,{lang:"jsx",title:"ErrorBoundary + Suspense 搭配",code:u}),e.jsxs(n,{variant:"warn",title:"别忘了错误边界",children:["只写 ",e.jsx("code",{children:"<Suspense>"})," 而不配错误边界，一旦数据请求抛错，错误会一路冒泡， 轻则整片白屏、重则崩到根。",e.jsx("strong",{children:"异步边界应当成对出现：Suspense 兜加载，ErrorBoundary 兜失败。"})]}),e.jsx("h2",{children:"五、并发特性：让重渲染不阻塞输入"}),e.jsxs("p",{children:["Suspense 解决「等待」的展示问题；并发特性解决另一个问题：",e.jsx("strong",{children:"当一次状态更新会触发昂贵的重渲染时， 别让它卡住用户正在进行的交互"}),"（尤其是打字）。React 把更新分成两类—— 必须立刻反映的",e.jsx("strong",{children:"紧急更新"}),"（如输入框跟手），和可以稍后、可被打断的",e.jsx("strong",{children:"过渡更新"}),"（如根据输入重算一个大列表）。"]}),e.jsxs(r,{children:["并发的核心是「更新有优先级，且可被打断」。把重活标记成",e.jsx("strong",{children:"过渡（transition）"}),"， React 就能在用户继续打字时",e.jsx("strong",{children:"中断"}),"这次重渲染、先响应输入，回头再接着算—— 于是「输入框永远跟手，列表稍微落后一点」，而不是「打一个字卡一下」。"]}),e.jsx("h3",{children:"5.1 useTransition：把重更新标记为可中断"}),e.jsxs("p",{children:[e.jsx("code",{children:"useTransition"})," 给你一个 ",e.jsx("code",{children:"startTransition"})," 函数和一个 ",e.jsx("code",{children:"isPending"})," 标志。 包在 ",e.jsx("code",{children:"startTransition"})," 里的状态更新被视为「过渡」，优先级低、可被打断；",e.jsx("code",{children:"isPending"})," 则告诉你过渡是否在进行，方便显示一个轻量的「处理中」提示。"]}),e.jsx(s,{lang:"jsx",title:"useTransition 做搜索过滤",code:h}),e.jsx(t,{title:"这里发生了什么",children:e.jsxs("p",{children:["用户快速打字时，",e.jsx("code",{children:"setQuery"})," 是紧急更新——输入框每个字都",e.jsx("strong",{children:"立刻"}),"显示。 而把大列表 ",e.jsx("code",{children:"setResults"})," 放进 ",e.jsx("code",{children:"startTransition"})," 后，它成了可中断的过渡： 下一个字符到来时，React 直接丢弃还没算完的那次筛选、先响应新输入。结果就是",e.jsx("strong",{children:"打字丝滑、 列表晚一拍跟上"}),"，配合 ",e.jsx("code",{children:"isPending"})," 给个「筛选中」提示体验更完整。"]})}),e.jsx("h3",{children:"5.2 useDeferredValue：延迟派生值"}),e.jsxs("p",{children:[e.jsx("code",{children:"useDeferredValue"})," 是另一种思路：你不改更新逻辑，而是拿到某个值的「延迟版」， 让昂贵的派生计算只跟着延迟值走。输入飞快时延迟值会落后一拍，但输入本身永不卡顿。 它特别适合「值来自上游、你无法把 setState 包进 transition」的场景。"]}),e.jsx(s,{lang:"jsx",title:"useDeferredValue 做搜索过滤",code:p}),e.jsx("h3",{children:"5.3 startTransition：独立函数版"}),e.jsxs("p",{children:["如果你不需要 ",e.jsx("code",{children:"isPending"}),"，或要在组件外（如路由跳转工具函数里）标记过渡， 可以直接用从 ",e.jsx("code",{children:"react"})," 导入的独立 ",e.jsx("code",{children:"startTransition"}),"。"]}),e.jsx(s,{lang:"jsx",title:"独立的 startTransition",code:x}),e.jsx("h2",{children:"六、useTransition vs useDeferredValue：怎么选"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"useTransition"}),e.jsx("th",{children:"useDeferredValue"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"你控制的东西"}),e.jsxs("td",{children:["包裹一次 ",e.jsx("strong",{children:"状态更新"})]}),e.jsxs("td",{children:["派生一个值的 ",e.jsx("strong",{children:"延迟副本"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"适用前提"}),e.jsxs("td",{children:["你能拿到并改写那次 ",e.jsx("code",{children:"setState"})]}),e.jsx("td",{children:"值来自上游（props 等），改不了源头更新"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"加载提示"}),e.jsxs("td",{children:["自带 ",e.jsx("code",{children:"isPending"})]}),e.jsxs("td",{children:["自己比较 ",e.jsx("code",{children:"value !== deferred"})," 判断"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"典型场景"}),e.jsx("td",{children:"点击切 Tab / 提交 / 主动触发的重更新"}),e.jsx("td",{children:"输入驱动的昂贵列表、图表重算"})]})]})]}),e.jsxs(n,{variant:"tip",children:["一句话选择：",e.jsx("strong",{children:"能改写那次 setState，就用 useTransition；只能拿到一个值、改不了上游更新，就用 useDeferredValue。"}),"两者底层都是「过渡优先级 + 可中断」，达到的效果一致——让重渲染给用户输入让路。"]}),e.jsx("h2",{children:"七、把两者放在一起看"}),e.jsxs("p",{children:["Suspense 与并发特性常常协同：切换页面时，用 ",e.jsx("code",{children:"startTransition"})," 包住路由更新， 让旧页面在新页面（可能因 ",e.jsx("code",{children:"lazy"})," 或数据未就绪而暂停）准备好之前继续显示、不闪 fallback； 等新页面就绪再切过去。这就是「过渡式导航」——既不卡输入，也不让用户盯着空白加载条。"]}),e.jsxs("p",{children:["到这里，服务端状态这一卷的两条主线就齐了：",e.jsx("strong",{children:"TanStack Query 管「数据的获取与缓存」， Suspense 与并发特性管「等待与重渲染的交互体验」"}),"。前者让数据正确高效，后者让界面始终顺滑跟手。"]}),e.jsx(c,{points:["Suspense 把加载态变成声明式边界：子组件「未就绪就暂停」，外层 <Suspense> 统一显示 fallback。","能触发暂停的有三类：React.lazy（代码分割）、suspense 模式的数据库（useSuspenseQuery）、React 19 的 use() 读 promise（含 RSC 流式渲染）。","Suspense 只管加载态，失败要靠 ErrorBoundary 接住；二者应成对出现，覆盖异步的等待与出错。","并发特性的核心：更新有优先级且可被打断，把重活标记为过渡，就能让重渲染给用户输入让路。","useTransition 用 startTransition 包裹状态更新，提供 isPending，适合主动触发的重更新（切 Tab / 提交）。","useDeferredValue 给值一个延迟副本，让昂贵派生计算跟延迟值走，适合输入驱动、改不了上游更新的场景。","选择口诀：能改写 setState 用 useTransition，只能拿到值用 useDeferredValue；二者效果一致——重渲染不阻塞输入。"]})]})}export{T as default};
