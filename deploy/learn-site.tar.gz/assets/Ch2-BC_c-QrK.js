import{j as e}from"./index-bcw1GFOG.js";import{L as r,S as o}from"./Summary-CzbI5rAL.js";import{K as s}from"./KeyIdea-BfDRPFR2.js";import{C as n}from"./Callout-Kd5ZZGSH.js";import{C as i}from"./CodeBlock-DTDRATdO.js";import{E as l}from"./Example-C1jxmPta.js";const c=`<properties>
    <java.version>17</java.version>
    <spring-ai.version>1.1.8</spring-ai.version>
</properties>

<dependencyManagement>
    <dependencies>
        <!-- 统一管理 Spring AI 全家桶版本 -->
        <dependency>
            <groupId>org.springframework.ai</groupId>
            <artifactId>spring-ai-bom</artifactId>
            <version>\${spring-ai.version}</version>
            <type>pom</type>
            <scope>import</scope>
        </dependency>
    </dependencies>
</dependencyManagement>

<dependencies>
    <!-- Web：提供 @RestController -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <!-- OpenAI 兼容 starter：用它走百炼的 compatible-mode -->
    <dependency>
        <groupId>org.springframework.ai</groupId>
        <artifactId>spring-ai-starter-model-openai</artifactId>
    </dependency>
</dependencies>`,t=`spring:
  ai:
    openai:
      api-key: \${DASHSCOPE_API_KEY}
      base-url: https://dashscope.aliyuncs.com/compatible-mode
      chat:
        options:
          model: qwen-plus`,a=`package com.example.bailian;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BailianDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(BailianDemoApplication.class, args);
    }
}`,p=`# 把百炼 API Key 注入环境变量（与 yml 里的 \${DASHSCOPE_API_KEY} 对应）
export DASHSCOPE_API_KEY=sk-你的百炼key

# 启动应用
mvn spring-boot:run`,d=`package com.example.bailian;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChatController {

    private final ChatClient chat;

    // ChatClient.Builder 由 spring-ai-starter-model-openai 自动装配
    public ChatController(ChatClient.Builder builder) {
        this.chat = builder.build();
    }

    @GetMapping("/chat")
    public String chat(@RequestParam String q) {
        return chat.prompt().user(q).call().content();
    }
}`,h=`curl "http://localhost:8080/chat?q=用一句话介绍杭州"
# 预期返回一段模型生成的中文文本`,m=`base-url: https://dashscope.aliyuncs.com/compatible-mode
# 框架拼接 completions-path（默认 /v1/chat/completions）后：
# https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions   ← 正确`,x=`base-url: https://dashscope.aliyuncs.com/compatible-mode/v1
# 再拼默认的 /v1/chat/completions：
# https://dashscope.aliyuncs.com/compatible-mode/v1/v1/chat/completions ← 双 v1 → 404`,j=`spring:
  ai:
    openai:
      base-url: https://dashscope.aliyuncs.com/compatible-mode/v1
      chat:
        completions-path: /chat/completions   # 改掉默认值，避免重复 /v1`;function S(){return e.jsxs("article",{children:[e.jsxs(r,{children:["本章用一个最小可跑的 Spring Boot 工程，通过 OpenAI 兼容模式接入阿里云百炼（DashScope）， 把 Qwen 模型用起来。全程只写三个文件 + 一段配置，并把最容易踩的 ",e.jsx("strong",{children:"base-url 拼接坑"}),"讲透—— 这是 90% 新手第一次接百炼报 404 的根因。"]}),e.jsx("h2",{children:"一、为什么选 OpenAI 兼容模式接百炼"}),e.jsx("p",{children:"接百炼有两条路径："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"路径 A（本章）"}),"：用官方 ",e.jsx("code",{children:"spring-ai-starter-model-openai"}),"，把 base-url 指向百炼的 compatible-mode 端点。无需引入阿里专属依赖，纯 Spring AI 原生抽象，迁移成本最低。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"路径 B（Ch3 加餐）"}),"：用阿里官方 ",e.jsx("strong",{children:"Spring AI Alibaba"}),"（",e.jsx("code",{children:"spring-ai-alibaba-starter-dashscope"}),"）原生 DashScope，支持 Qwen 多模态/Embedding/Agent-Graph，且无 base-url 坑。"]})]}),e.jsx("p",{children:"路径 A 胜在通用：今天接百炼，明天换成任何兼容 OpenAI 协议的服务，改 yml 即可。"}),e.jsx("h2",{children:"二、pom.xml 关键依赖"}),e.jsxs("p",{children:["用 ",e.jsx("code",{children:"spring-ai-bom"})," 统一管理版本（本卷锁定 1.1.8），再引入 Web 和 OpenAI starter："]}),e.jsx(i,{lang:"xml",title:"pom.xml（关键片段）",code:c}),e.jsxs(n,{variant:"note",title:"为什么用 BOM",children:[e.jsx("code",{children:"spring-ai-bom"})," 统一约束 Spring AI 全家桶的版本，子依赖就不用再各自写 ",e.jsx("code",{children:"<version>"}),"， 避免版本错配。注意 ",e.jsx("code",{children:"${spring-ai.version}"})," 是 Maven 属性占位符，由上面的 ",e.jsx("code",{children:"<properties>"})," 提供。"]}),e.jsx("h2",{children:"三、application.yml（完整配置）"}),e.jsx(i,{lang:"yaml",title:"src/main/resources/application.yml",code:t}),e.jsx("p",{children:"四个关键点："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"api-key"})," 用 ",e.jsx("code",{children:"${DASHSCOPE_API_KEY}"})," 引用环境变量，绝不硬编码进仓库；"]}),e.jsxs("li",{children:[e.jsx("code",{children:"base-url"})," 只写到 ",e.jsx("code",{children:".../compatible-mode"}),"，",e.jsx("strong",{children:"不带 /v1"}),"（详见第五节）；"]}),e.jsxs("li",{children:["虽然用的是百炼，但 starter 是 openai，所以配置节点在 ",e.jsx("code",{children:"spring.ai.openai"})," 下；"]}),e.jsxs("li",{children:[e.jsx("code",{children:"model"})," 填百炼模型名，如 ",e.jsx("code",{children:"qwen-plus"})," / ",e.jsx("code",{children:"qwen-max"})," / ",e.jsx("code",{children:"qwen-turbo"}),"。"]})]}),e.jsx("h2",{children:"四、启动类"}),e.jsx(i,{lang:"java",title:"BailianDemoApplication.java",code:a}),e.jsx("p",{children:"标准 Spring Boot 启动类，无任何 AI 相关代码——所有装配由 starter + yml 自动完成，这正是 Spring AI 的设计哲学。"}),e.jsx("h2",{children:"五、base-url 拼接坑（重点中的重点）"}),e.jsxs("p",{children:["Spring AI 的 OpenAI client 请求的最终 URL 是",e.jsx("strong",{children:"拼出来的"}),"："]}),e.jsx("p",{style:{textAlign:"center",fontWeight:600},children:"最终 URL = base-url + completions-path"}),e.jsxs("p",{children:["而 ",e.jsx("code",{children:"completions-path"})," 的默认值是 ",e.jsx("code",{children:"/v1/chat/completions"}),"。所以 base-url 只需写到 ",e.jsx("code",{children:".../compatible-mode"}),"，框架会自动补出正确路径："]}),e.jsx(i,{lang:"yaml",title:"正确：base-url 不带 /v1",code:m}),e.jsxs(n,{variant:"warn",title:"最常见的 404：双 v1",children:["如果你按直觉把 base-url 写成 ",e.jsx("code",{children:".../compatible-mode/v1"}),"，框架再拼上默认的",e.jsx("code",{children:"/v1/chat/completions"}),"，结果是 ",e.jsx("code",{children:".../compatible-mode/v1/v1/chat/completions"}),"—— 多出一个 ",e.jsx("code",{children:"/v1"}),"，百炼直接返回 404。这是接百炼第一次必踩的坑。"]}),e.jsx(i,{lang:"yaml",title:"错误：base-url 带 /v1 导致双 v1 → 404",code:x}),e.jsx("h3",{children:"替代写法（二者取一）"}),e.jsxs("p",{children:["如果你确实想让 base-url 带上 ",e.jsx("code",{children:"/v1"}),"（比如团队规范要求），那就同时改掉 completions-path："]}),e.jsx(i,{lang:"yaml",title:"替代：base-url 带 /v1 + 改 completions-path",code:j}),e.jsxs(s,{title:"记牢这条规则",children:["base-url 带不带 ",e.jsx("code",{children:"/v1"}),"，必须和 completions-path 配套：默认 path 是 ",e.jsx("code",{children:"/v1/chat/completions"}),"， 所以默认就让 base-url 停在 ",e.jsx("code",{children:"/compatible-mode"}),"。两边都带 ",e.jsx("code",{children:"/v1"})," = 双 v1 = 404。"]}),e.jsx("h3",{children:"区域端点"}),e.jsxs("p",{children:["百炼有不同地域端点。国内默认 ",e.jsx("code",{children:"dashscope.aliyuncs.com"}),"，国际站为",e.jsx("code",{children:"dashscope-intl.aliyuncs.com"}),"。换区域只改 base-url 的域名部分，",e.jsx("code",{children:"/compatible-mode"})," 后缀与拼接规则不变。"]}),e.jsx("h2",{children:"六、环境与运行"}),e.jsx(i,{lang:"bash",title:"设置 Key 并启动",code:p}),e.jsxs("p",{children:[e.jsx("code",{children:"export"})," 的变量名必须与 yml 里 ",e.jsx("code",{children:"${DASHSCOPE_API_KEY}"})," 一致。 生产环境通常通过容器环境变量或配置中心注入，开发期用 export 即可。"]}),e.jsx("h2",{children:"七、最小 ChatClient 调用验证"}),e.jsxs("p",{children:["写一个 ",e.jsx("code",{children:"@RestController"}),"，构造注入 ",e.jsx("code",{children:"ChatClient.Builder"}),"，链式调用返回字符串："]}),e.jsx(i,{lang:"java",title:"ChatController.java",code:d}),e.jsx(i,{lang:"bash",title:"curl 验证",code:h}),e.jsxs(l,{title:"这一条链发生了什么",children:[e.jsx("code",{children:"prompt()"})," 开启构建 → ",e.jsx("code",{children:"user(q)"})," 设置用户消息 → ",e.jsx("code",{children:"call()"}),"经 base-url 拼出的正确 URL 发请求给百炼 → 百炼用 Qwen 生成回复 → ",e.jsx("code",{children:"content()"})," 取出纯文本返回浏览器。"]}),e.jsx("h2",{children:"八、常见报错与调试清单"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"404、URL 里出现 /v1/v1"}),"：base-url 多写了 ",e.jsx("code",{children:"/v1"}),"，去掉它（见第五节）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"401 Unauthorized"}),"：API Key 错误或未生效——检查 ",e.jsx("code",{children:"export DASHSCOPE_API_KEY"})," 是否设置、是否与 yml 占位符同名、Key 是否是百炼（DashScope）的而非其它平台。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"启动报找不到 ChatClient.Builder / 无 AI Bean"}),"：",e.jsx("code",{children:"spring-ai-starter-model-openai"})," 没引入，或被 BOM 版本约束遗漏。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"依赖解析失败 / 版本冲突"}),"：Spring Boot 与 Spring AI 版本不匹配——1.1.x 需配 Spring Boot 3.x。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"调试技巧"}),"：开 ",e.jsx("code",{children:"logging.level.org.springframework.ai=DEBUG"})," 可看到实际请求的完整 URL，一眼确认是否双 v1。"]})]}),e.jsx(o,{points:["路径 A：用 spring-ai-starter-model-openai + base-url 指向百炼 compatible-mode，纯原生抽象、迁移成本低。","pom 用 spring-ai-bom（1.1.8）统一版本 + spring-boot-starter-web + spring-ai-starter-model-openai。","application.yml 配在 spring.ai.openai 下：api-key 用环境变量、base-url 到 /compatible-mode、model 填 qwen-plus。","【核心坑】最终URL = base-url + completions-path(默认 /v1/chat/completions)；base-url 必须不带 /v1，否则双 v1 → 404。","替代写法：base-url 带 /v1 时，把 completions-path 改成 /chat/completions，二者取一。","运行：export DASHSCOPE_API_KEY=... 后 mvn spring-boot:run；用 /chat?q=... 验证。","排错：404 看双 v1、401 看 Key、无 Bean 看 starter、依赖冲突看 Boot/AI 版本（1.1.x 配 Boot 3.x）。"]})]})}export{S as default};
