import{j as e}from"./index-4Gnvy4Pk.js";import{L as r,S as n}from"./Summary-8JJJpz6g.js";import{K as l}from"./KeyIdea-6LAlCalL.js";import{E as d}from"./Example-DoUEk5_G.js";import{P as c}from"./Practice-B3Zrc-xC.js";import{C as s}from"./Callout-BfcJpdBu.js";import{C as i}from"./CodeBlock-Bq_ox3wh.js";import{M as o}from"./MVCCVersionChain-Oxnhg6G4.js";import"./Figure-DjFYQXdx.js";const x=`-- 你建的表里只有这两列
CREATE TABLE account (
    id    INT PRIMARY KEY,
    money INT
);

-- 但 InnoDB 在每行后面偷偷加了三个隐藏字段：
--   DB_TRX_ID    6 字节  最近一次修改这行的事务 ID
--   DB_ROLL_PTR  7 字节  回滚指针，指向 undo log 里的上一个版本
--   DB_ROW_ID    6 字节  没有主键时才用，作为隐藏自增行号`,t=`-- 设当前行版本的 DB_TRX_ID = trx_id，ReadView 四要素如下：
--   m_ids          : 创建 ReadView 时仍然活跃（未提交）的事务 ID 列表
--   min_trx_id     : m_ids 里的最小值
--   max_trx_id     : 系统下一个将要分配的事务 ID（比所有已出现的都大）
--   creator_trx_id : 创建这个 ReadView 的事务自己的 ID

-- 可见性判断（对版本链上的每个版本依次套用）：
IF trx_id == creator_trx_id THEN 可见          -- 自己改的，当然看得见
ELSE IF trx_id <  min_trx_id THEN 可见          -- 在我快照之前就提交了
ELSE IF trx_id >= max_trx_id THEN 不可见        -- 在我快照之后才开始的事务
ELSE IF trx_id IN m_ids      THEN 不可见        -- 快照那一刻还活跃，没提交
ELSE                              可见          -- 落在区间内但已提交`,h=`-- ========== 前置：准备数据 ==========
-- 任一会话执行一次
SET SESSION transaction_isolation = 'REPEATABLE-READ';
INSERT INTO account VALUES (1, 100);


-- ========== 会话 T1：修改但先不提交 ==========
START TRANSACTION;
UPDATE account SET money = 200 WHERE id = 1;
-- 注意：到这里 T1 还没 COMMIT
-- 此刻行上 DB_TRX_ID 已变成 T1 的事务号，
-- 旧版本(money=100)被 undo log 通过 DB_ROLL_PTR 串起来


-- ========== 会话 T2：快照读 ==========
START TRANSACTION;
SELECT money FROM account WHERE id = 1;
-- 结果是 100，而不是 200
-- 因为 T1 还在 m_ids 里（活跃未提交），最新版本对 T2 不可见，
-- T2 沿 DB_ROLL_PTR 回溯版本链，找到可见的旧版本 money=100


-- ========== 回到 T1：提交 ==========
COMMIT;`,_=`-- undo / 版本链回收（purge）的健康度排查
-- History list length：等待 purge 清理的“旧版本事务”数，长事务会让它失控暴涨
SHOW ENGINE INNODB STATUS\\G    -- TRANSACTIONS 段里找 History list length

-- 8.0 也能直接查（单位是“可清理事务数”的估算）
SELECT count FROM information_schema.INNODB_METRICS
WHERE name = 'trx_rseg_history_len';

-- purge 线程数（清理跟不上时可调大）
SHOW VARIABLES LIKE 'innodb_purge_threads';

-- undo 表空间大小（长事务撑大它，且 8.0 前 undo 占用的空间不会自动收缩）
SHOW VARIABLES LIKE 'innodb_undo%';`,j=`-- 把可见性判断“走一遍”：假设我的 ReadView 是
--   m_ids = [60, 80]，min_trx_id = 60，max_trx_id = 90，creator_trx_id = 70
-- 版本链（链头→链尾）：
--   v1: money=300, DB_TRX_ID=80   → 80 在 m_ids 里 → 未提交 → 不可见，往下找
--   v2: money=200, DB_TRX_ID=60   → 60 在 m_ids 里 → 未提交 → 不可见，往下找
--   v3: money=150, DB_TRX_ID=55   → 55 < min_trx_id(60) → 早已提交 → 可见！停在这
-- 所以这个事务看到的是 money=150
--
-- 若把 creator_trx_id 改成 80（即 v1 是我自己改的）：
--   v1 的 DB_TRX_ID==creator_trx_id → 自己改的 → 立即可见 → 看到 300`;function p(){return e.jsxs(e.Fragment,{children:[e.jsx(r,{children:e.jsxs("p",{children:["你大概早就背过「InnoDB 默认隔离级别是可重复读，靠 MVCC 实现」这句话。但 ",e.jsx("em",{children:"MVCC"}),"（Multi-Version Concurrency Control，多版本并发控制）到底是怎么做到「读不加锁、写不阻塞读」的？ 答案藏在每一行数据的三个隐藏字段、一条由 undo log 串起来的版本链，以及一个叫 ",e.jsx("em",{children:"ReadView"}),"的「快照视角」里。这一章我们把这台机器拆开看。"]})}),e.jsx("h2",{children:"问题：为什么读和写可以不互相等待"}),e.jsxs("p",{children:["在没有 MVCC 的世界里，要保证一个事务读到的数据是一致的，最朴素的做法是给读操作也加锁——别人正在改这行， 你就得等它改完。这样读写互相阻塞，并发度很低。MVCC 的思路反过来：",e.jsx("strong",{children:"不删除旧数据，而是为每一次修改保留一个历史版本"}),"。这样写操作只管生成新版本， 读操作去挑一个「对自己合适」的旧版本来看，两者各取所需，互不打扰。"]}),e.jsxs("p",{children:["这里的「读」特指普通的 ",e.jsx("code",{children:"SELECT"}),"，也就是",e.jsx("em",{children:"快照读"}),"（snapshot read），它完全不加锁。 本章先讲清楚版本是怎么存的、快照是怎么选版本的；下一章再讲快照读和当前读的区别。"]}),e.jsx("h3",{children:"每一行的三个隐藏字段"}),e.jsxs("p",{children:["你 ",e.jsx("code",{children:"CREATE TABLE"})," 时只写了业务列，但 InnoDB 在每行后面还偷偷塞了几个字段， 它们是整套 MVCC 的物理基础："]}),e.jsx(i,{lang:"sql",title:"行的隐藏字段",code:x}),e.jsxs("p",{children:["最关键的是前两个：",e.jsx("code",{children:"DB_TRX_ID"})," 记下「这行最近是哪个事务改的」，",e.jsx("code",{children:"DB_ROLL_PTR"})," 是一根指针，指向 undo log 里这一行的「上一个版本」。 有了这根指针，同一行的多个历史版本就能像链表一样首尾相接。"]}),e.jsx("h3",{children:"undo log 把历史版本串成版本链"}),e.jsxs("p",{children:["每当一个事务修改某行，InnoDB 不是原地覆盖就完事——它会先把",e.jsx("strong",{children:"修改前的旧值"}),"写进",e.jsx("em",{children:"undo log"}),"，然后让新版本的 ",e.jsx("code",{children:"DB_ROLL_PTR"})," 指向那条 undo 记录。 如果这行被改了很多次，就形成一条",e.jsx("strong",{children:"版本链"}),"：链头是最新版本，沿着",e.jsx("code",{children:"DB_ROLL_PTR"})," 一路往回，是越来越旧的历史版本。回滚（",e.jsx("code",{children:"ROLLBACK"}),"） 其实就是顺着这条链把数据还原回去。"]}),e.jsxs(d,{title:"一行被改了两次后的版本链",children:[e.jsx("p",{children:"假设 id=1 这行依次被三个事务修改："}),e.jsxs("ul",{children:[e.jsxs("li",{children:["链头（最新）：",e.jsx("code",{children:"money=300"}),"，",e.jsx("code",{children:"DB_TRX_ID=trx80"})," ——指向↓"]}),e.jsxs("li",{children:["中间：",e.jsx("code",{children:"money=200"}),"，",e.jsx("code",{children:"DB_TRX_ID=trx60"})," ——指向↓"]}),e.jsxs("li",{children:["链尾（最旧）：",e.jsx("code",{children:"money=100"}),"，",e.jsx("code",{children:"DB_TRX_ID=trx40"})]})]}),e.jsxs("p",{children:["注意：这三个版本里，",e.jsx("strong",{children:"只有链头存在聚簇索引的真实页上"}),"， 下面两个都活在 undo log 里。一个读事务要看哪个版本，取决于它的 ReadView 怎么判断。"]})]}),e.jsx(o,{}),e.jsx("h3",{children:"ReadView：决定「我能看见哪个版本」"}),e.jsxs("p",{children:["光有版本链还不够——读事务凭什么知道该停在哪个版本？这就是 ",e.jsx("em",{children:"ReadView"})," 的职责。 ReadView 是事务在做快照读那一刻，给整个数据库的「活跃状态」拍的一张照片，它由四个要素构成："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"m_ids"}),"：拍照那一刻",e.jsx("strong",{children:"仍然活跃（已开始但未提交）"}),"的事务 ID 列表。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"min_trx_id"}),"：",e.jsx("code",{children:"m_ids"})," 里的最小值，活跃事务的「下界」。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"max_trx_id"}),"：系统下一个将要分配的事务 ID，比此刻出现过的所有事务都大。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"creator_trx_id"}),"：创建这个 ReadView 的事务自己的 ID。"]})]}),e.jsxs("p",{children:["拿着这张照片，读事务从版本链的链头开始，对每个版本的 ",e.jsx("code",{children:"DB_TRX_ID"})," 套用一套固定规则， 判断「这个版本对我可见吗」；不可见就顺着 ",e.jsx("code",{children:"DB_ROLL_PTR"})," 往回找更旧的版本， 直到找到第一个可见的为止。"]}),e.jsx(i,{lang:"sql",title:"ReadView 可见性判断规则",code:t}),e.jsx("h3",{children:"把规则“走一遍”：一次完整的可见性判断"}),e.jsxs("p",{children:["光看规则容易蒙，最好的办法是拿一条具体的版本链，按规则一格一格往下走。下面这段把",e.jsx("code",{children:"m_ids"}),"、",e.jsx("code",{children:"min/max_trx_id"})," 都给定，沿链头往链尾逐版本判断，直到停在第一个可见版本—— 把它在纸上推一遍，ReadView 你就再也忘不掉了。"]}),e.jsx(i,{lang:"sql",title:"visibility_walkthrough.sql",code:j}),e.jsx(s,{variant:"warn",title:"一个高频混淆：可见性比的是「提交时刻」还是「事务 ID 大小」",children:e.jsxs("p",{children:["很多人误以为 MVCC 是“按事务 ID 谁大谁新”来判断可见性，其实不然。事务 ID 在 ",e.jsx("code",{children:"START TRANSACTION"})," 时并不分配， 而是在",e.jsx("strong",{children:"第一次真正修改数据"}),"时才分配。所以一个早开启但晚修改的事务，可能拿到比你大的 ID。 ReadView 用 ",e.jsx("code",{children:"m_ids"}),"（活跃未提交名单）来判断，本质判的是“",e.jsx("strong",{children:"这个版本对应的事务，在我拍快照那一刻提交了没有"}),"”， 而不是单纯比 ID 大小——只有当 ID 落在 ",e.jsx("code",{children:"min"})," 和 ",e.jsx("code",{children:"max"})," 之间时，才需要查 ",e.jsx("code",{children:"m_ids"})," 来确认它当时是否已提交。"]})}),e.jsx(l,{title:"可见性的核心直觉",children:e.jsxs("p",{children:["抛开公式，一句话概括：",e.jsx("strong",{children:"我只能看见「在我拍快照之前就已经提交」的修改"}),"。",e.jsx("code",{children:"trx_id < min_trx_id"})," 说明它早就提交了，看得见；",e.jsx("code",{children:"trx_id ≥ max_trx_id"})," 说明它是我快照之后才出现的事务，看不见； 落在区间内的，就看它当时在不在 ",e.jsx("code",{children:"m_ids"})," 这份「未提交名单」里—— 在名单里=还没提交=看不见，不在名单里=已经提交=看得见。自己改的版本则永远看得见。"]})}),e.jsxs(s,{variant:"warn",title:"MVCC 不是万能的",children:[e.jsxs("p",{children:["MVCC 只管",e.jsx("strong",{children:"快照读"}),"的可见性，它处理不了下面这些场景，别把它当银弹："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"SELECT ... FOR UPDATE"}),"、",e.jsx("code",{children:"UPDATE"}),"、",e.jsx("code",{children:"DELETE"})," 这类",e.jsx("strong",{children:"当前读"}),"不走 ReadView，它们读的是最新版本并加锁（下一章详谈）。"]}),e.jsx("li",{children:"版本链不会无限增长：旧版本要等到「没有任何 ReadView 还需要它」时，才会被 purge 线程清理。 长事务迟迟不提交，会让 undo log 越堆越大，这是线上常见的隐患。"})]})]}),e.jsxs(d,{title:"undo 暴涨拖垮线上：一次真实排障",children:[e.jsx("p",{children:"某监控告警“磁盘使用率持续上涨”，但业务数据量没明显增长。排查链路："}),e.jsxs("ul",{children:[e.jsx("li",{children:"发现涨的是 InnoDB 的 undo 表空间，而不是数据文件。"}),e.jsxs("li",{children:[e.jsx("code",{children:"SHOW ENGINE INNODB STATUS"})," 里 ",e.jsx("code",{children:"History list length"})," 高达几百万（健康值通常几千以内）。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"information_schema.INNODB_TRX"})," 里有个事务跑了好几小时还没提交——是一个 BI 工具开的只读大查询，连接池没回收。"]})]}),e.jsxs("p",{children:["根因：这个老事务的 ReadView 一直存活，",e.jsx("strong",{children:"purge 线程不敢清理任何比它新的旧版本"}),"（万一它要读呢）， 于是版本链越积越长、undo 越撑越大。kill 掉那个连接后，History list length 几分钟内回落、磁盘释放。 教训：",e.jsx("strong",{children:"长事务不分读写都危险，只读长事务一样会卡死 purge"}),"。"]})]}),e.jsx("h2",{children:"这对实际开发意味着什么"}),e.jsxs("p",{children:["理解了 ReadView，很多「灵异现象」就不灵异了。比如你在一个长事务里反复查同一行， 中间别人改了又提交了，你却始终看到老值——这不是 bug，是 RR 隔离级别下 ReadView 复用的正常表现。 再比如你发现 undo log 占用的表空间一直涨、",e.jsx("code",{children:"history list length"})," 居高不下， 八成是哪个会话开了事务忘了提交，导致旧版本无法被回收。",e.jsx("strong",{children:"把「读看的是版本快照、写生成的是新版本」这件事刻进脑子，是排查并发问题的起点。"})]}),e.jsxs(c,{title:"两会话亲眼看一次快照读",children:[e.jsxs("p",{children:["开两个 MySQL 客户端连同一个库（下面记作会话 T1、T2）。T1 改了数据但",e.jsx("strong",{children:"先不提交"}),"， T2 用普通 ",e.jsx("code",{children:"SELECT"})," 去读同一行——你会看到 T2 读到的是改之前的旧值。 这正是 ReadView 把 T1 判为「活跃未提交、不可见」，T2 沿版本链回溯到旧版本的结果。"]}),e.jsx(i,{lang:"sql",title:"snapshot_read_demo.sql",code:h}),e.jsxs("p",{children:["做完后再查一下版本链回收的健康度：盯住 ",e.jsx("code",{children:"History list length"}),"，开一个事务故意不提交，看它怎么涨；提交后再看它怎么回落。"]}),e.jsx(i,{lang:"sql",title:"purge_health.sql",code:_}),e.jsxs("p",{children:["再做个对照实验：让 T1 先 ",e.jsx("code",{children:"COMMIT"}),"，",e.jsx("strong",{children:"然后"}),"再开 T2 事务去查—— 这次 T2 会看到 200，因为创建 ReadView 时 T1 已不在 ",e.jsx("code",{children:"m_ids"})," 里了。 仅仅是「读的时机」差了一点，结果就完全不同，这就是 ReadView 时机的威力（下一章会专门讲它）。"]})]}),e.jsx(n,{points:["MVCC 让“读不加锁、写不阻塞读”：写操作生成新版本，读操作挑一个合适的旧版本看，互不等待。","每行有三个隐藏字段：DB_TRX_ID（最近修改的事务）、DB_ROLL_PTR（指向旧版本的回滚指针）、DB_ROW_ID（无主键时的隐藏行号）。","undo log 保存修改前的旧值，DB_ROLL_PTR 把同一行的历史版本串成一条版本链，链头最新、链尾最旧。","ReadView 四要素：m_ids（活跃事务列表）、min_trx_id、max_trx_id、creator_trx_id，是快照那一刻的活跃状态照片。","可见性规则：trx_id 小于 min 可见、不小于 max 不可见、在 m_ids 中=活跃未提交不可见、否则可见；自己改的永远可见。","读事务从链头沿 DB_ROLL_PTR 回溯，找到第一个可见版本；旧版本要等没有 ReadView 需要时才被 purge 回收，长事务会拖垮 undo log。"]})]})}export{p as default};
