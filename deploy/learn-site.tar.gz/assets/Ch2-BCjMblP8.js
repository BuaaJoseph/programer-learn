import{j as e}from"./index-4Gnvy4Pk.js";import{L as t,S as l}from"./Summary-8JJJpz6g.js";import{K as s}from"./KeyIdea-6LAlCalL.js";import{E as c}from"./Example-DoUEk5_G.js";import{P as d}from"./Practice-B3Zrc-xC.js";import{C as r}from"./Callout-BfcJpdBu.js";import{C as n}from"./CodeBlock-Bq_ox3wh.js";const i=`from openai import OpenAI

client = OpenAI()


class MemoryManager:
    """短期记忆：滑动窗口 + 摘要压缩；长期记忆：读写分离的存取接口。"""

    def __init__(self, window=6, summary_trigger=12):
        self.window = window               # 最近保留几条消息原文
        self.summary_trigger = summary_trigger  # 历史超过多少条就触发摘要
        self.messages = []                 # 短期：原始消息列表
        self.summary = ''                  # 短期：被压缩掉的旧对话摘要
        self.long_term = {}                # 长期：键值事实库（这里用内存字典代替向量库）

    # ---------- 短期记忆 ----------
    def add(self, role, content):
        self.messages.append({'role': role, 'content': content})
        if len(self.messages) > self.summary_trigger:
            self._compress()

    def _compress(self):
        # 把「窗口之外」的旧消息抽成一段摘要，腾出 token 预算
        old = self.messages[:-self.window]
        self.messages = self.messages[-self.window:]
        text = '\\n'.join(f"{m['role']}: {m['content']}" for m in old)
        resp = client.chat.completions.create(
            model='gpt-4o-mini',
            messages=[
                {'role': 'system', 'content': '把下面的对话压成要点，保留事实与决定，去掉寒暄。'},
                {'role': 'user', 'content': (self.summary + '\\n' + text).strip()},
            ],
        )
        self.summary = resp.choices[0].message.content

    # ---------- 长期记忆（读写分离） ----------
    def remember(self, key, fact):
        # 写入：把要点存库（真实系统里这里会做 embedding 再入向量库）
        self.long_term[key] = fact

    def recall(self, query):
        # 读取：按需检索（这里用朴素子串匹配代替语义检索）
        return [v for k, v in self.long_term.items() if query in k or query in v]

    # ---------- 组装最终上下文 ----------
    def build_context(self, system_prompt, recall_query=None):
        ctx = [{'role': 'system', 'content': system_prompt}]
        facts = self.recall(recall_query) if recall_query else []
        if facts:
            ctx.append({'role': 'system', 'content': '已知事实：' + '；'.join(facts)})
        if self.summary:
            ctx.append({'role': 'system', 'content': '早前对话摘要：' + self.summary})
        ctx.extend(self.messages)          # 最近窗口内的原文
        return ctx


# 用法
mem = MemoryManager(window=4, summary_trigger=8)
mem.remember('user.name', '用户叫小杜')
mem.remember('user.lang', '用户偏好 Python')
mem.add('user', '帮我写个排序函数')
mem.add('assistant', '好的，给你一个快排实现……')

ctx = mem.build_context('你是编程助手。', recall_query='user')
resp = client.chat.completions.create(model='gpt-4o-mini', messages=ctx)
print(resp.choices[0].message.content)`,o=`# 给上下文做「预算分配」：把固定窗口切成几块，各管各的上限。
# 真实系统不会让某一层无限膨胀，而是先定预算，再让各层在预算内取舍。

CONTEXT_LIMIT = 8000   # 模型窗口（留出输出余量后的可用 token）

BUDGET = {
    'system':   400,    # 系统指令，固定不动
    'facts':    600,    # 长期记忆检索回来的事实
    'summary':  1000,   # 早前对话摘要
    'recent':   5000,   # 最近窗口原文
    'reserve':  1000,   # 给模型输出预留
}

def fit(text, max_tokens, count):
    """简化：超预算就截断（真实系统会先按重要度排序再裁）。"""
    toks = count(text)
    if toks <= max_tokens:
        return text
    # 按比例粗暴截断；生产里应按句子/消息边界裁，避免切碎语义
    keep = int(len(text) * max_tokens / toks)
    return text[:keep] + ' …(截断)'

# 关键点：预算之和必须 <= CONTEXT_LIMIT，否则照样撑爆。
assert sum(BUDGET.values()) <= CONTEXT_LIMIT
# 哪一层最该挤？通常是 summary 和 recent 互相让——
# 对话越长，summary 预算适当加大、recent 适当缩小。`;function p(){return e.jsxs(e.Fragment,{children:[e.jsx(t,{children:e.jsxs("p",{children:["上一章说清了问题：不能把所有历史都原样重发。那到底该怎么取舍？答案是把记忆",e.jsx("strong",{children:"分层"}),"。 像人一样，Agent 也有「短期记忆」（最近几轮的细节，新鲜但易逝）和「长期记忆」 （久远但重要的事实，比如「这个用户偏好 Python」）。两层用完全不同的策略管理， 这一章把四种短期策略、长期记忆的读写分离，以及它和 RAG 的边界一次讲透。"]})}),e.jsx("h2",{children:"短期记忆的四种策略"}),e.jsxs("p",{children:["短期记忆要回答的问题是：「最近这段对话，怎么塞进有限的上下文窗口？」核心永远是一对矛盾——",e.jsx("strong",{children:"保真度"}),"（细节留得越多越好）和 ",e.jsx("strong",{children:"token 预算"}),"（塞得越少越省）。四种主流策略， 本质是在这条线上选不同的点："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"全量保留"}),"：一条不删，原样重发。保真度最高，但就是上一章那个 O(N²) 灾难，只适合短对话。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"滑动窗口"}),"：只保留最近 ",e.jsx("code",{children:"k"})," 条消息，更早的直接丢弃。token 恒定、实现最简单， 但代价是「窗口外」的信息彻底丢失——用户开头说的名字，聊到后面就忘了。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"摘要压缩"}),"：把旧对话交给模型压成一段要点，用「摘要」替代「原文」。保真度居中、token 大幅下降， 代价是多一次 LLM 调用，且摘要本身可能丢细节或引入误差。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"混合"}),"：最近 ",e.jsx("code",{children:"k"})," 条留原文（保细节），更早的滚动压成摘要（保大意）。 这是工程上最常用的方案，兼顾了「近处清晰、远处概括」。"]})]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"策略"}),e.jsx("th",{children:"token 增长"}),e.jsx("th",{children:"保真度"}),e.jsx("th",{children:"额外开销"}),e.jsx("th",{children:"适用场景"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"全量保留"}),e.jsx("td",{children:"O(N²)"}),e.jsx("td",{children:"最高"}),e.jsx("td",{children:"无"}),e.jsx("td",{children:"短对话、客服单轮工单"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"滑动窗口"}),e.jsx("td",{children:"O(N·k) 近线性"}),e.jsx("td",{children:"低（远处全丢）"}),e.jsx("td",{children:"无"}),e.jsx("td",{children:"对早期信息不敏感的闲聊"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"摘要压缩"}),e.jsx("td",{children:"受控"}),e.jsx("td",{children:"中（丢细节）"}),e.jsx("td",{children:"每次压缩一次 LLM 调用"}),e.jsx("td",{children:"长对话、需保留早期决定"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"混合"}),e.jsx("td",{children:"受控"}),e.jsx("td",{children:"近处高 / 远处中"}),e.jsx("td",{children:"偶尔压缩"}),e.jsx("td",{children:"绝大多数严肃 Agent"})]})]})]}),e.jsx(c,{title:"同一段 20 轮对话，四种策略的差别",children:e.jsxs("p",{children:["用户第 2 轮说「我在做一个电商后台」，第 18 轮问「刚才那个项目用什么数据库好？」。",e.jsx("strong",{children:"全量保留"}),"能答（但很贵）；",e.jsx("strong",{children:"滑动窗口（k=6）"}),"答不上来，因为第 2 轮早被丢了；",e.jsx("strong",{children:"摘要压缩"}),"大概率能答，只要摘要里留了「电商后台」这个事实；",e.jsx("strong",{children:"混合"}),"同样能答， 且最近几轮的代码细节还完整保留着。这就是为什么严肃系统几乎都选混合。"]})}),e.jsx(s,{title:"摘要的时机比算法更关键",children:e.jsxs("p",{children:["很多人把精力花在「怎么把摘要 prompt 写得更好」，却忽略了一个更要命的工程问题：",e.jsx("strong",{children:"什么时候触发压缩"}),"。 每轮都压，既浪费 LLM 调用、又像上一章说的会反复击穿前缀缓存；压得太晚，则可能这一轮就直接撑爆窗口。 常见做法是设一个",e.jsx("strong",{children:"双阈值"}),"：历史 token 超过软阈值（如窗口的 70%）就在下一个「对话间隙」异步压缩， 硬阈值（如 90%）则立即同步压缩。把压缩当成「后台垃圾回收」来调度，而不是每轮都跑，是省钱又稳的关键。"]})}),e.jsx("h2",{children:"长期记忆：读写分离"}),e.jsxs("p",{children:["短期记忆再怎么压，也只是「这次会话内」的事。可有些信息要跨会话、跨天甚至跨月地记住—— 用户的名字、长期偏好、过往的关键决定。把这些一直挂在上下文里既浪费又会被滑窗冲掉， 正确做法是",e.jsx("strong",{children:"读写分离"}),"："]}),e.jsxs("p",{children:[e.jsx("strong",{children:"写入时"}),"，从对话里",e.jsx("em",{children:"抽取"}),"出值得长期保存的要点（「用户偏好 Python」「项目部署在 AWS」）， 存进一个外部库（键值库、数据库，或更常见的向量库）。",e.jsx("strong",{children:"读取时"}),"，不把整个库塞进去， 而是根据当前问题",e.jsx("em",{children:"按需检索"}),"出相关的几条，临时拼进上下文。写归写、读归读，库可以无限大， 但每轮只取回最相关的一小撮。"]}),e.jsxs("p",{children:["写入这一步是整个长期记忆里",e.jsx("strong",{children:"最容易做砸"}),"的地方。两个常见坑：一是「什么都记」，把每句寒暄都抽成事实， 库越长越脏，检索时全是噪声；二是「事实冲突」，用户上周说「我用 React」，这周说「换 Vue 了」，如果只追加不更新， 库里就同时存着两条矛盾的事实，检索回来模型反而懵了。所以严肃的写入逻辑要做",e.jsx("strong",{children:"去重与更新"}),"： 抽取时判断这条事实是不是已有事实的更新版本，是就覆盖、不是才新增。"]}),e.jsx(s,{title:"记忆系统 = 一个「该记什么 / 该取什么」的决策器",children:e.jsxs("p",{children:["把这一章的所有策略统一成一句话：记忆系统的本质，是在每一轮替模型回答两个问题——",e.jsx("strong",{children:"哪些旧内容值得带进这次上下文，哪些可以丢、可以压、可以存进库里等以后再取"}),"。 短期策略决定「近处怎么放」，长期读写分离决定「远处怎么存与取」。模型本身一点不变， 变聪明的是你喂给它的那段上下文。"]})}),e.jsx("h2",{children:"给上下文做预算分配"}),e.jsxs("p",{children:["当短期、长期、系统指令几路信息都想往上下文里挤，就需要一个「总调度」。成熟系统的做法不是放任各层膨胀， 而是先把固定窗口",e.jsx("strong",{children:"切成几块预算"}),"：系统指令固定一小块、检索事实一块、摘要一块、最近窗口一大块， 再各自在预算内取舍，并且一定要给模型的",e.jsx("strong",{children:"输出"}),"留余量。预算之和必须小于等于窗口，否则一切策略都白搭。"]}),e.jsx(n,{lang:"python",title:"context_budget.py",code:o}),e.jsx("p",{children:"预算分配让取舍变得显式可调：对话变长时，把 summary 的预算调大、recent 调小；接入了重要文档时，把 facts 的预算加大。 这比「拍脑袋截断」可控得多，也方便排查「为什么模型突然忘了某件事」——多半是那一层的预算被挤爆了。"}),e.jsx("h2",{children:"记忆 vs RAG：别搞混"}),e.jsxs("p",{children:["长期记忆的「按需检索」听起来很像下一章要讲的 RAG，技术栈也确实重叠（都可能用向量库）。但两者的",e.jsx("strong",{children:"内容性质不同"}),"："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"记忆"}),"存的是「关于",e.jsx("em",{children:"这个用户 / 这次会话"}),"的事实」——名字、偏好、聊过的决定。它是个性化的、私有的、随交互动态增长的。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"RAG"}),"检索的是「",e.jsx("em",{children:"外部知识"}),"」——产品文档、API 手册、法规条文。它是公共的、相对静态的、与具体用户无关的。"]})]}),e.jsx(r,{variant:"tip",title:"一句话区分",children:e.jsxs("p",{children:["记忆回答「",e.jsx("strong",{children:"关于你，我知道什么"}),"」；RAG 回答「",e.jsx("strong",{children:"关于这个世界 / 这套资料，我能查到什么"}),"」。 一个成熟 Agent 通常两者都要：用记忆维持个性化连续性，用 RAG 接入权威知识。"]})}),e.jsx(r,{variant:"warn",title:"记忆系统的三个常见误区",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"「把整个长期库塞进上下文」"}),"——库会无限增长，全塞进去等于没分离，迟早撑爆。长期记忆的意义就在于「只取相关的几条」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"「摘要越频繁越好」"}),"——每轮压缩既费钱又击穿缓存，还会因「摘要的摘要」层层失真。压缩要按阈值调度，不是越勤越好。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"「记忆抽取交给规则就够了」"}),"——靠关键词规则抽事实漏得厉害；但全交给 LLM 抽又贵又可能幻觉出不存在的事实。实践中常是规则做粗筛 + LLM 做精提 + 人工可纠错。"]})]})}),e.jsx("h2",{children:"这对做 Agent / 工程实践意味着什么"}),e.jsxs("p",{children:["给 Agent 设计记忆，不是选「一个最好的策略」，而是搭一条",e.jsx("strong",{children:"流水线"}),"：最近几轮走滑动窗口保原文， 溢出的旧对话滚动压成摘要，跨会话的关键事实抽出来写进长期库、用时再检索回来。每一层都在为下一次调用 「攒出一段既省 token 又信息够用的上下文」。把这条流水线封装成一个 ",e.jsx("code",{children:"MemoryManager"}),"， 业务代码就只管 ",e.jsx("code",{children:"add()"})," 和 ",e.jsx("code",{children:"build_context()"}),"，复杂度全藏在里面。"]}),e.jsxs("p",{children:["封装的另一个好处是",e.jsx("strong",{children:"可观测"}),"：把每轮各层占用的 token、检索命中了哪几条事实、是否触发了压缩， 都打到日志里。线上一旦出现「模型忘事」或「答非所问」，你能立刻定位是滑窗丢了、摘要失真了，还是检索没召回—— 而不是对着一个黑箱抓瞎。记忆是 Agent 最容易出诡异 bug 的地方，可观测性几乎是必需品。"]}),e.jsxs(d,{title:"实现一个可运行的 MemoryManager",children:[e.jsxs("p",{children:["下面这个类同时实现了短期（滑动窗口 + 触发式摘要）和长期（读写分离的 ",e.jsx("code",{children:"remember"})," /",e.jsx("code",{children:"recall"})," 接口），并用 ",e.jsx("code",{children:"build_context()"})," 把摘要、检索到的事实、最近窗口 三部分拼成最终发给模型的 ",e.jsx("code",{children:"messages"}),"。这里长期库用内存字典代替向量库， 下一章会把它换成真正的语义检索。"]}),e.jsx(n,{lang:"python",title:"memory_manager.py",code:i}),e.jsxs("p",{children:["动手改两个旋钮感受取舍：把 ",e.jsx("code",{children:"window"})," 调小，省 token 但近处细节也少了；把 ",e.jsx("code",{children:"summary_trigger"}),"调大，摘要触发得晚、保真度高但 token 涨得快。没有银弹，只有针对你的场景调出的那个平衡点。"]}),e.jsxs("p",{children:["进阶练习：给 ",e.jsx("code",{children:"remember"})," 加一段去重逻辑——写入新事实前先 ",e.jsx("code",{children:"recall"})," 同主题的旧事实，若语义重复就覆盖而非新增； 再给 ",e.jsx("code",{children:"build_context"})," 套上上面的预算分配，让每一层都不超过各自上限。改完你就有了一个接近生产形态的记忆内核。"]})]}),e.jsx(l,{points:["记忆要分层：短期记忆管最近几轮的细节，长期记忆管跨会话的重要事实，两层用不同策略。","短期四策略——全量保留、滑动窗口、摘要压缩、混合——本质都是在「保真度 vs token 预算」上选点。","混合策略（最近留原文 + 更早滚动摘要）兼顾近处清晰与远处概括，是工程上最常用的方案。","摘要的时机比算法更关键：用软/硬双阈值调度压缩，当后台垃圾回收来跑，别每轮都压。","长期记忆走读写分离：写入时抽取要点存库（要去重、要更新冲突事实），读取时按问题检索相关几条再拼进上下文。","用预算分配把固定窗口切成几块（system/facts/summary/recent/reserve），让取舍显式可调、问题可定位。","记忆 ≠ RAG：记忆存「关于用户 / 会话的事实」，RAG 检索「外部公共知识」，成熟 Agent 通常两者都用。","把短期 + 长期封装成一个 MemoryManager，业务只管 add 与 build_context，并把各层占用打进日志保证可观测。"]})]})}export{p as default};
