import{j as e}from"./index-B0-Um9Xw.js";import{L as s,a as r,P as c,C as i,S as d}from"./Summary-CRXglwZ1.js";import{K as n}from"./KeyIdea-zCCzkW7I.js";import{E as x}from"./Example-Djk5fvs9.js";const o=`proxy_cache_path /data/nginx/cache levels=1:2
                 keys_zone=api_cache:10m
                 max_size=1g inactive=60m;

server {
    listen 80;
    server_name www.example.com;

    gzip on;
    gzip_types text/css application/javascript application/json;
    gzip_min_length 1k;

    # 静态资源：直接由 Nginx 读本地磁盘，并设长缓存
    location ~* \\.(js|css|png|jpg|gif|ico)$ {
        root /var/www/static;
        expires 7d;                 # 浏览器缓存 7 天
        add_header Cache-Control "public";
    }

    # 动态接口：反向代理到后端
    location /api/ {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_cache api_cache;                  # 启用缓存
        proxy_cache_key $scheme$request_method$host$request_uri;
        proxy_cache_valid 200 302 10m;          # 200/302 缓存 10 分钟
        proxy_cache_valid 404 1m;
        add_header X-Cache-Status $upstream_cache_status;   # 命中情况回写头
    }
}`;function p(){return e.jsxs(e.Fragment,{children:[e.jsx(s,{children:e.jsxs("p",{children:["Nginx 最经典的用法不是直接处理业务，而是站在所有后端前面当「门面」： 对外它是唯一入口，对内它把请求转给真正干活的服务。这种「替后端收发请求」的模式叫",e.jsx("em",{children:"reverse proxy"}),"（反向代理）。在它之上，再叠动静分离和缓存， 就能让站点又快又稳——这也是面试里被问到最多的一组组合拳。"]})}),e.jsx("h2",{children:"反向代理：Nginx 替后端出面"}),e.jsxs("p",{children:["正向代理替",e.jsx("strong",{children:"客户端"}),"出面（比如翻墙代理，服务端不知道真实用户）； 反向代理替",e.jsx("strong",{children:"服务端"}),"出面（客户端只认识 Nginx，不知道背后有几台后端）。 在 Nginx 里实现反向代理只要一行 ",e.jsx("code",{children:"proxy_pass"}),"：把进来的请求原样转给后端地址。"]}),e.jsx("h3",{children:"proxy_set_header：别把真实信息丢了"}),e.jsxs("p",{children:["请求经过 Nginx 中转后，后端直接看到的「来源」其实是 Nginx，不是真实客户端。 如果不处理，后端拿到的 ",e.jsx("code",{children:"Host"})," 是错的、看到的 IP 全是 Nginx 的内网地址。 所以要靠 ",e.jsx("code",{children:"proxy_set_header"})," 把关键信息透传下去："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"Host $host"}),"：把用户访问的域名带给后端，否则后端可能按错误的虚拟主机匹配。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"X-Real-IP $remote_addr"}),"：把真实客户端 IP 放进自定义头，后端做日志、风控、限流都要用。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"X-Forwarded-For $proxy_add_x_forwarded_for"}),"：记录请求经过的代理链，多层代理时尤其重要。"]})]}),e.jsxs(x,{title:"静态走 Nginx、API 转后端",children:[e.jsxs("p",{children:["一个典型站点：首页和详情页用了一堆 JS、CSS、图片，外加若干 ",e.jsx("code",{children:"/api/"})," 开头的数据接口。 合理的切法是——浏览器请求 ",e.jsx("code",{children:".js / .css / .png"})," 这类静态文件时，Nginx 直接从本地磁盘读出来返回，根本不惊动后端；而请求 ",e.jsx("code",{children:"/api/订单列表"})," 这类动态数据时， 才用 ",e.jsx("code",{children:"proxy_pass"})," 转给后端的应用服务。"]}),e.jsx("p",{children:"这样一来，后端只需处理真正需要计算的请求，静态资源全被 Nginx 这台「专业搬运工」消化掉， 后端的压力可能直接降一个数量级。"})]}),e.jsx("h2",{children:"动静分离：让专业的干专业的"}),e.jsxs("p",{children:["Nginx 读取并返回静态文件的效率极高，而应用服务器（Tomcat、Node 等）真正的价值在于跑业务逻辑。 让 Tomcat 去吐图片，纯属浪费。",e.jsx("strong",{children:"动静分离"}),"就是按请求类型分流：静态资源交给 Nginx， 动态请求转给后端。实现上通常用 ",e.jsx("code",{children:"location"})," 的正则匹配把静态后缀拦下来， 其余的再走 ",e.jsx("code",{children:"proxy_pass"}),"。"]}),e.jsx("h2",{children:"缓存与压缩：再快一截"}),e.jsx("h3",{children:"proxy_cache：把后端的响应缓存下来"}),e.jsxs("p",{children:["对于「短时间内结果不变」的动态接口（比如商品分类、首页推荐），Nginx 可以用",e.jsx("code",{children:"proxy_cache"})," 把后端的响应缓存起来，下次同样的请求直接由 Nginx 返回，不再打后端。 几个关键概念："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"cache key"}),"：用什么来区分「同一个请求」。默认包含方法、host、URI， 通过 ",e.jsx("code",{children:"proxy_cache_key"})," 自定义。key 设得太粗会串数据，太细会几乎缓存不命中。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"过期"}),"：",e.jsx("code",{children:"proxy_cache_valid 200 10m"})," 表示状态码 200 的响应缓存 10 分钟，过期后回源刷新。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"命中率"}),"：用 ",e.jsx("code",{children:"add_header X-Cache-Status $upstream_cache_status"}),"把 HIT/MISS/EXPIRED 写到响应头里，是观察缓存效果最直接的办法。"]})]}),e.jsx("h3",{children:"expires：让浏览器自己缓存静态文件"}),e.jsxs("p",{children:[e.jsx("code",{children:"proxy_cache"})," 缓存在 Nginx 这一侧；而 ",e.jsx("code",{children:"expires 7d"})," 是给静态资源加",e.jsx("code",{children:"Cache-Control"})," 头，让",e.jsx("strong",{children:"浏览器"}),"把文件缓存在本地，下次连请求都不发。 两者一个管服务端、一个管客户端，配合使用。"]}),e.jsx("h3",{children:"gzip：压缩后再传"}),e.jsxs("p",{children:[e.jsx("code",{children:"gzip on"})," 让 Nginx 对文本类响应（HTML/CSS/JS/JSON）做压缩再发出，体积常能减到三分之一以下， 显著省带宽、加快加载。注意只对文本生效，图片、视频本就是压缩格式，再压几乎无效还浪费 CPU， 所以用 ",e.jsx("code",{children:"gzip_types"})," 限定类型。"]}),e.jsx(n,{title:"一条请求的快慢，取决于它走多远",children:e.jsxs("p",{children:["这套组合拳的核心思路是",e.jsx("strong",{children:"让请求尽量在靠前的环节就被解决"}),"： 能命中浏览器缓存的就不发请求，发了能命中 Nginx 缓存的就不打后端， 实在要打后端的也先做动静分离、再 gzip 压缩着传。越往后端走代价越大， 所以优化的方向永远是「把流量挡在前面」。"]})}),e.jsx(r,{variant:"warn",title:"缓存最容易踩的坑",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"把带个性化数据的接口也缓存了"}),"：比如「我的订单」这种因人而异的响应， 如果 cache key 里不含用户标识，A 用户会看到 B 用户的数据，事故级别。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"POST 等写操作被缓存"}),"：默认 Nginx 只缓存 GET/HEAD，别手贱去缓存写请求。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"静态文件加了长 expires 又没做版本号"}),"：发版后浏览器还拿旧文件。 正解是给文件名带哈希（如 ",e.jsx("code",{children:"app.3f9a.js"}),"），内容变了文件名就变。"]})]})}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["被问「Nginx 怎么给站点提速」，按层次答：",e.jsx("strong",{children:"反向代理"}),"当统一入口，用",e.jsx("code",{children:"proxy_set_header"})," 把 Host / X-Real-IP / X-Forwarded-For 透传给后端；",e.jsx("strong",{children:"动静分离"}),"让静态资源由 Nginx 直接吐、动态请求才转后端； 再叠",e.jsx("strong",{children:"缓存"}),"——",e.jsx("code",{children:"proxy_cache"})," 缓存后端响应（讲清 cache key、过期、命中率监控），",e.jsx("code",{children:"expires"})," 让浏览器缓存静态文件；最后 ",e.jsx("code",{children:"gzip"})," 压缩文本响应。 能把「客户端缓存 / Nginx 缓存 / 后端」三层分清，就显得有体系。"]}),e.jsxs(c,{title:"给一个站点配上动静分离与缓存",children:[e.jsxs("p",{children:["准备一个有静态目录和后端接口的站点，按下面的配置把静态后缀交给 Nginx、 把 ",e.jsx("code",{children:"/api/"})," 转给后端并加缓存。访问接口两次，看响应头里的",e.jsx("code",{children:"X-Cache-Status"})," 第一次是 MISS、第二次变 HIT，再用 curl 带",e.jsx("code",{children:"Accept-Encoding: gzip"})," 看是否返回了压缩内容。"]}),e.jsx(i,{lang:"nginx",title:"nginx.conf",code:o}),e.jsxs("p",{children:["把 ",e.jsx("code",{children:"proxy_cache_valid"})," 的时间调短到 ",e.jsx("code",{children:"10s"}),"， 连续刷新就能看到 HIT → EXPIRED → HIT 的循环，直观体会缓存的生命周期。"]})]}),e.jsx(d,{points:["反向代理用 proxy_pass 让 Nginx 替后端出面，是统一入口与后续优化的基础。","proxy_set_header 把 Host / X-Real-IP / X-Forwarded-For 透传给后端，否则后端拿不到真实来源信息。","动静分离：静态资源由 Nginx 直接返回，动态请求才 proxy_pass 转后端，给后端大幅减压。","proxy_cache 缓存后端响应，关键是 cache key、过期时间，并用 X-Cache-Status 监控命中率。","expires 让浏览器缓存静态文件、gzip 压缩文本响应，分别管客户端侧和传输体积。","优化主线是把流量挡在前面：浏览器缓存 → Nginx 缓存 → 后端，越靠前解决代价越小。"]})]})}export{p as default};
