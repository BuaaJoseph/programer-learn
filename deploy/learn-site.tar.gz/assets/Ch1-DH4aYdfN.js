import{j as t}from"./index-Bkb6eOY7.js";import{L as d,S as o}from"./Summary-Dj-Y5ESD.js";import{K as n}from"./KeyIdea-N6HVLWjp.js";import{C as r}from"./Callout-FpvHzM97.js";import{C as e}from"./CodeBlock-BQqVtp_3.js";import{E as i}from"./Example-iLfTRUEi.js";import{P as s}from"./Practice-CL62kf51.js";import{P as c}from"./PyRunner-D0JYPDVw.js";const l=`# 标准库：math / random / datetime 各用一下
import math
import random
import datetime

# math：数学运算
print("根号 2 =", round(math.sqrt(2), 4))
print("圆面积(r=3) =", round(math.pi * 3 ** 2, 2))

# random：随机（每次运行结果不同）
random.seed(42)                      # 固定种子，方便演示
print("掷骰子:", random.randint(1, 6))
print("随机选:", random.choice(["红", "绿", "蓝"]))

# datetime：日期时间
today = datetime.date(2026, 6, 18)
print("日期:", today)
print("是星期几(0=周一):", today.weekday())`,m=`import math               # 导入整个 math 模块

print(math.sqrt(16))      # 用「模块名.功能」的方式调用
print(math.pi)`,h=`4.0
3.141592653589793`,a=`from math import sqrt, pi   # 只导入需要的几个

print(sqrt(25))             # 直接用，不用写 math.
print(pi)`,x=`5.0
3.141592653589793`,p=`import datetime as dt       # 给模块起个短别名

now = dt.datetime.now()
print(type(now))`,j="<class 'datetime.datetime'>",y=`# 文件：mymath.py
def add(a, b):
    return a + b

def multiply(a, b):
    return a * b

PI = 3.14159`,_=`# 文件：main.py（和 mymath.py 放在同一个文件夹）
import mymath

print(mymath.add(2, 3))
print(mymath.multiply(4, 5))
print(mymath.PI)`,f=`5
20
3.14159`,u=`# 文件：tool.py
def greet():
    print("你好")

if __name__ == "__main__":
    # 只有「直接运行这个文件」时，下面才执行；
    # 被别的文件 import 时，下面不执行
    print("我被直接运行了")
    greet()`,g=`# 直接 python tool.py 的输出：
我被直接运行了
你好

# 而在别的文件里 import tool 时，上面两行不会自动打印`,C=`import os
import random
import datetime

print(os.getcwd())                      # 当前工作目录
print(random.randint(1, 6))             # 1~6 的随机整数（掷骰子）
print(random.choice(["A", "B", "C"]))   # 随机选一个
print(datetime.date.today())            # 今天的日期`,P=`/home/user/project
4
B
2026-06-18`,b=`import math

print(math.ceil(3.2))     # 向上取整 -> 4
print(math.floor(3.8))    # 向下取整 -> 3
print(math.sqrt(144))     # 平方根 -> 12.0
print(math.pow(2, 10))    # 2 的 10 次方 -> 1024.0`,O=`4
3
12.0
1024.0`;function k(){return t.jsxs("article",{children:[t.jsxs(d,{children:["随着程序变大，把所有代码堆在一个文件里会乱成一团。Python 用",t.jsx("strong",{children:"模块"}),"来组织代码： 每个 ",t.jsx("code",{children:".py"})," 文件就是一个模块，可以被别的文件「导入」来复用。 这一章讲 ",t.jsx("code",{children:"import"})," 的几种用法、如何把代码拆成自己的模块、那个神秘的",t.jsx("code",{children:'if __name__ == "__main__"'}),"，以及最常用的几个标准库速览。"]}),t.jsx("h2",{children:"一、import：导入别人写好的模块"}),t.jsxs(n,{children:["Python 自带一大批现成的「标准库」模块（比如算数学的 math、生成随机数的 random）。 用 ",t.jsx("code",{children:"import 模块名"})," 把它请进来，之后用 ",t.jsx("code",{children:"模块名.功能"})," 的方式调用里面的东西。"]}),t.jsx(e,{lang:"python",title:"import 整个模块",code:m}),t.jsx(i,{title:"运行结果",children:t.jsx(e,{lang:"text",title:"运行结果",code:h})}),t.jsx("h3",{children:"from ... import：只拿需要的"}),t.jsxs("p",{children:["如果只用模块里的某几样，用 ",t.jsx("code",{children:"from 模块 import 名字"})," 直接导入，用的时候就不用加模块名前缀了："]}),t.jsx(e,{lang:"python",title:"from import",code:a}),t.jsx(i,{title:"运行结果",children:t.jsx(e,{lang:"text",title:"运行结果",code:x})}),t.jsx("h3",{children:"as：起个别名"}),t.jsxs("p",{children:["模块名太长，可以用 ",t.jsx("code",{children:"as"})," 起个简短的别名。这在数据分析里很常见（如把 numpy 起名 np）："]}),t.jsx(e,{lang:"python",title:"as 别名",code:p}),t.jsx(i,{title:"运行结果",children:t.jsx(e,{lang:"text",title:"运行结果",code:j})}),t.jsx("h2",{children:"二、把代码拆成自己的模块"}),t.jsxs("p",{children:["你自己写的 ",t.jsx("code",{children:".py"})," 文件也是模块，可以被同目录的其他文件导入。比如先写一个 ",t.jsx("code",{children:"mymath.py"}),"："]}),t.jsx(e,{lang:"python",title:"mymath.py（自己的模块）",code:y}),t.jsx("p",{children:"然后在另一个文件里导入它、用它的函数和变量："}),t.jsx(e,{lang:"python",title:"main.py（导入自己的模块）",code:_}),t.jsx(i,{title:"运行结果",children:t.jsx(e,{lang:"text",title:"运行结果",code:f})}),t.jsxs(r,{variant:"tip",children:[t.jsx("code",{children:"import mymath"})," 写的是文件名",t.jsx("strong",{children:"去掉 .py"}),"。两个文件要在同一个文件夹里， 这样 Python 才能找到。把功能拆进不同模块，是让大项目保持整洁的关键。"]}),t.jsx("h2",{children:'三、if __name__ == "__main__"'}),t.jsxs("p",{children:["你会经常在 Python 文件末尾看到这一行，它的作用是：",t.jsx("strong",{children:"区分「直接运行」和「被导入」"}),"。"]}),t.jsx(e,{lang:"python",title:"tool.py",code:u}),t.jsx(i,{title:"运行结果",children:t.jsx(e,{lang:"text",title:"运行结果",code:g})}),t.jsxs(n,{children:["当你直接 ",t.jsx("code",{children:"python tool.py"})," 运行时，Python 把这个文件的 ",t.jsx("code",{children:"__name__"})," 设为",t.jsx("code",{children:'"__main__"'}),"，于是 if 里的代码会执行；而当这个文件被别的文件 ",t.jsx("code",{children:"import"})," 时，",t.jsx("code",{children:"__name__"})," 是模块名（如 ",t.jsx("code",{children:'"tool"'}),"），if 里的代码就不会执行。"]}),t.jsxs(r,{variant:"note",title:"为什么需要它",children:["它让一个文件既能「被导入当工具库」，又能「直接运行做测试」。 把测试 / 演示代码放进 ",t.jsx("code",{children:'if __name__ == "__main__":'})," 里，导入时就不会被它干扰。 这是一个非常标准、到处都能见到的写法。"]}),t.jsx("h2",{children:"四、常用标准库速览"}),t.jsx("p",{children:"Python「自带电池」——标准库非常丰富，不用安装就能用。下面挑几个最常用的各看一个小例子。"}),t.jsxs("table",{children:[t.jsx("thead",{children:t.jsxs("tr",{children:[t.jsx("th",{children:"模块"}),t.jsx("th",{children:"用来做什么"})]})}),t.jsxs("tbody",{children:[t.jsxs("tr",{children:[t.jsx("td",{children:t.jsx("code",{children:"os"})}),t.jsx("td",{children:"和操作系统打交道：路径、文件夹、环境变量"})]}),t.jsxs("tr",{children:[t.jsx("td",{children:t.jsx("code",{children:"sys"})}),t.jsx("td",{children:"和 Python 解释器打交道：命令行参数、退出程序"})]}),t.jsxs("tr",{children:[t.jsx("td",{children:t.jsx("code",{children:"math"})}),t.jsx("td",{children:"数学运算：开方、取整、三角函数等"})]}),t.jsxs("tr",{children:[t.jsx("td",{children:t.jsx("code",{children:"random"})}),t.jsx("td",{children:"随机数：随机整数、随机选择、打乱"})]}),t.jsxs("tr",{children:[t.jsx("td",{children:t.jsx("code",{children:"datetime"})}),t.jsx("td",{children:"日期和时间：今天几号、现在几点"})]})]})]}),t.jsx(e,{lang:"python",title:"os / random / datetime 小例",code:C}),t.jsx(i,{title:"运行结果（随机值每次不同）",children:t.jsx(e,{lang:"text",title:"运行结果",code:P})}),t.jsxs("p",{children:[t.jsx("code",{children:"math"})," 模块里几个常用函数："]}),t.jsx(e,{lang:"python",title:"math 常用函数",code:b}),t.jsx(i,{title:"运行结果",children:t.jsx(e,{lang:"text",title:"运行结果",code:O})}),t.jsxs("p",{children:[t.jsx("code",{children:"sys"})," 模块常用 ",t.jsx("code",{children:"sys.argv"}),"（读取命令行传进来的参数）和 ",t.jsx("code",{children:"sys.exit()"}),"（提前退出程序）。 这些模块你不用全记住，知道「遇到这类需求去查这个库」就够了。"]}),t.jsxs("p",{children:[t.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」。"]}),t.jsx(c,{initialCode:l}),t.jsx(s,{title:"动手练一练",children:t.jsxs("ol",{children:[t.jsxs("li",{children:["用 ",t.jsx("code",{children:"random.randint"})," 模拟掷两个骰子，打印两个点数和它们的和。"]}),t.jsxs("li",{children:["把你写过的几个工具函数（比如 ",t.jsx("code",{children:"is_even"}),"）放进一个 ",t.jsx("code",{children:"utils.py"}),"，在另一个文件里 import 并使用。"]}),t.jsxs("li",{children:["给 ",t.jsx("code",{children:"utils.py"})," 加上 ",t.jsx("code",{children:'if __name__ == "__main__":'}),"，里面写几行测试代码，确认直接运行时执行、被导入时不执行。"]})]})}),t.jsx(o,{points:["每个 .py 文件是一个模块；import 模块名 后用「模块名.功能」调用。","from 模块 import 名字 只导入需要的（用时免前缀）；import 模块 as 别名 起短名。","自己的 .py 也能被同目录文件 import（写文件名去掉 .py），用来把大项目拆整洁。",'if __name__ == "__main__": 区分直接运行（执行）和被导入（不执行），适合放测试/入口代码。',"标准库自带不用装：os 系统/路径、sys 解释器、math 数学、random 随机、datetime 日期时间。","不必背全部 API，记住「这类需求查这个库」即可。"]})]})}export{k as default};
