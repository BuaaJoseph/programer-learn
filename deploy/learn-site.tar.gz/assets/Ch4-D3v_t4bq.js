import{j as e}from"./index-BdVncPlI.js";import{L as n,S as l}from"./Summary-Baiwq3-G.js";import{K as c}from"./KeyIdea-Cnr-5ipR.js";import{E as i}from"./Example-phQ905Fb.js";import{P as d}from"./Practice-CD-79usu.js";import{C as r}from"./Callout-BRUKkrb4.js";import{C as s}from"./CodeBlock-DCdshbU5.js";const h=`维度            TCP                       UDP
连接            面向连接（要握手）         无连接（直接发）
可靠            可靠（确认 + 重传）        不可靠（尽力而为，可能丢）
有序            保证有序                   不保证顺序
拥塞/流量控制   有                         无
首部开销        20 字节起                  固定 8 字节
通信方式        一对一                     一对一/一对多/广播/组播
速度/时延       较慢，有控制开销           快，几乎零额外开销`,t=`# 长度字段法拆包：每条消息前加 4 字节长度头
# 发送端
def send_msg(sock, payload: bytes):
    header = len(payload).to_bytes(4, 'big')   # 先写消息长度
    sock.sendall(header + payload)              # 再写消息体

# 接收端：先读满 4 字节长度，再按长度读满消息体
def recv_msg(sock):
    header = recv_exactly(sock, 4)              # 必须读够 4 字节
    if header is None:
        return None
    length = int.from_bytes(header, 'big')
    return recv_exactly(sock, length)           # 再精确读够 length 字节

def recv_exactly(sock, n):
    buf = b''
    while len(buf) < n:                          # 循环直到凑够 n 字节
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None                          # 连接关闭
        buf += chunk
    return buf`,x=`# TCP 与 UDP 首部对比（字段越多，能力越强，开销也越大）

# UDP 首部：固定 8 字节，简单到极致
+--------+--------+--------+--------+
| 源端口          | 目的端口        |
| 长度            | 校验和          |
+--------+--------+--------+--------+

# TCP 首部：至少 20 字节，多出来的字段正对应它的各种能力
| 源端口 | 目的端口 |
| 序号 seq            |   <- 可靠/有序
| 确认号 ack          |   <- 确认机制
| 数据偏移 | 标志位 | 窗口大小 |   <- 标志位含 SYN/ACK/FIN/RST，窗口=流量控制
| 校验和  | 紧急指针 |
| 选项（MSS/窗口缩放/SACK/时间戳...）|  <- 协商能力`,o=`# Nagle 算法 + 延迟 ACK 可能导致小包延迟，交互式场景常关掉 Nagle
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)  # 禁用 Nagle，立刻发

# Nagle 的本意：把多个小包攒成一个大包发，减少「一个字节一个包」的浪费
# 副作用：和延迟 ACK 撞上时，交互延迟可能高达几十到几百毫秒
# 所以 SSH、游戏、RPC 这类对延迟敏感的小包场景，通常 TCP_NODELAY=1`;function U(){return e.jsxs(e.Fragment,{children:[e.jsx(n,{children:e.jsxs("p",{children:["TCP 可靠但「重」，UDP 轻快但「不管」。它们是传输层的两位主角，没有谁更好，只有谁更合适。 这一章把它们摆在一起逐项对比，再讲清楚什么场景该选谁、以及绕不开的两道坎：",e.jsx("strong",{children:"UDP 上怎么做可靠"}),"，和 ",e.jsx("strong",{children:"TCP 的粘包 / 拆包"}),"。"]})}),e.jsx("h2",{children:"逐项对比"}),e.jsxs("p",{children:["两者的差异，本质都源于「",e.jsx("em",{children:"TCP 为可靠有序付出了代价，UDP 把这些代价省掉换取了速度"}),"」："]}),e.jsx(s,{lang:"text",title:"TCP vs UDP",code:h}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"连接"}),"：TCP 通信前要三次握手，UDP 拿起来就发，没有连接的概念。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"可靠与有序"}),"：TCP 用确认、重传、排序保证不丢不乱；UDP 尽力而为，丢了不补、乱了不管。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"首部开销"}),"：UDP 首部固定 8 字节，TCP 首部至少 20 字节，UDP 更省。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"通信方式"}),"：TCP 只能一对一；UDP 支持一对一、一对多、广播、组播。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"速度"}),"：UDP 没有握手、确认、拥塞控制的开销，时延更低、更快。"]})]}),e.jsx("h2",{children:"从首部看能力差异"}),e.jsxs("p",{children:["TCP 和 UDP 的能力差距，其实",e.jsx("strong",{children:"明明白白写在首部里"}),"。UDP 首部只有 8 字节（源端口、目的端口、长度、校验和）， 除了「发到哪个进程」之外几乎什么都不管。而 TCP 首部至少 20 字节，多出来的每个字段都对应一项能力： 序号/确认号撑起可靠与有序，窗口字段实现流量控制，标志位（",e.jsx("code",{children:"SYN/ACK/FIN/RST"}),"）驱动连接的建立与关闭， 选项区还能协商 MSS、窗口缩放、SACK。看懂首部，就看懂了「为什么 TCP 重、UDP 轻」。"]}),e.jsx(s,{lang:"text",title:"TCP / UDP 首部对比",code:x}),e.jsx("h2",{children:"各自适合什么"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"TCP"}),"：要求数据一字节都不能错的场景——网页（HTTP）、文件传输（FTP）、邮件（SMTP）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"UDP"}),"：要求快、能容忍少量丢失的场景——DNS 查询、视频直播、在线游戏，以及 HTTP/3 底层的 QUIC。"]})]}),e.jsx(i,{title:"直播为什么用 UDP",children:e.jsxs("p",{children:["看直播时，最怕的是「卡住等待」。如果用 TCP，某一帧画面的数据包丢了，TCP 会停下来反复重传、 等它补齐才往后放——结果就是",e.jsx("strong",{children:"画面卡死、越拖越久"}),"。可对直播来说，一帧旧画面补回来已经没意义了， 观众宁可",e.jsx("strong",{children:"丢掉这帧、直接看最新的"}),"。UDP 正好「不管丢包、不管顺序」， 应用层只挑最新的画面渲染，体验反而更流畅。这就是「实时性比完整性更重要」的典型取舍。"]})}),e.jsx(c,{title:"选型的一句话原则",children:e.jsxs("p",{children:["要",e.jsx("strong",{children:"不丢不乱"}),"、能容忍一点延迟，选 ",e.jsx("strong",{children:"TCP"}),"；要",e.jsx("strong",{children:"低延迟、实时"}),"、 能容忍少量丢失，选 ",e.jsx("strong",{children:"UDP"}),"。如果既想要 UDP 的快、又想要部分可靠，那就在",e.jsx("strong",{children:"应用层自己实现可靠机制"}),"——这正是下面要讲的。"]})}),e.jsx("h2",{children:"在 UDP 上实现可靠"}),e.jsxs("p",{children:["UDP 本身不可靠，但我们可以把 TCP 那套思路",e.jsx("strong",{children:"搬到应用层"}),"：给每个包加序号、收到要回 ACK、 没收到 ACK 就重传、乱序到达自己排序。这样既保留了 UDP 的灵活与低延迟，又按需补上可靠性。 现实中的代表就是 ",e.jsx("em",{children:"QUIC"}),"（HTTP/3 的传输层，跑在 UDP 之上，自带可靠、有序、多路复用和加密） 和 ",e.jsx("em",{children:"KCP"}),"（一种为低延迟优化的可靠 UDP 协议，游戏里常用）。"]}),e.jsx(r,{variant:"warn",title:"为什么不直接用 TCP",children:e.jsxs("p",{children:["既然要可靠，为何不干脆用 TCP？因为 TCP 内核实现僵化、改不动，还有",e.jsx("strong",{children:"队头阻塞"}),"（head-of-line blocking）等老问题；而在 UDP 上自建协议，可以按业务定制重传策略、拥塞算法、 多路复用，灵活性高得多。QUIC 能在弱网下表现更好、连接迁移更顺滑，正是得益于此。"]})}),e.jsx("h2",{children:"TCP 粘包 / 拆包"}),e.jsxs("p",{children:["TCP 是",e.jsx("strong",{children:"面向字节流"}),"的，它眼里没有「一条消息」的边界，只有连续的字节。于是会出现： 你连发两条消息，接收方可能一次就读到了两条拼在一起（",e.jsx("em",{children:"粘包"}),"）， 也可能一条消息被分成两次才读全（",e.jsx("em",{children:"拆包"}),"）。注意 UDP 是面向报文的，天然保留边界，没有这个问题。"]}),e.jsx("p",{children:"解决办法是在应用层自己定义消息边界，常见三种："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"定长消息"}),"：每条消息固定字节数，读满就是一条。简单但浪费、不灵活。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"分隔符"}),"：用特殊字符（如换行符）分隔消息。要处理消息体里出现分隔符的转义问题。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"长度字段"}),"：每条消息前面加一个头，写明消息体的长度；接收方先读长度、再按长度读消息体。 最通用，主流 RPC 框架基本都用它。"]})]}),e.jsx("h2",{children:"「粘包」这个词其实是误称"}),e.jsxs("p",{children:["严格说，",e.jsx("strong",{children:"「粘包」是个被叫错的名字"}),"。TCP 从设计上就是字节流，它",e.jsx("em",{children:"从来没有「包」的概念"}),"， 所以谈不上「粘」——是应用层错误地假设「一次 ",e.jsx("code",{children:"recv"})," 就是一条完整消息」才产生了问题。 换个角度看：所谓粘包/拆包，根本不是 TCP 的 bug，而是",e.jsx("strong",{children:"应用层没有定义消息边界"}),"的后果。 理解这一点，面试时就不会被「TCP 为什么会粘包、要不要修复 TCP」带偏——要修的是应用层协议，不是 TCP。"]}),e.jsxs(r,{variant:"warn",title:"Nagle 算法与延迟 ACK：被忽视的延迟元凶",children:[e.jsxs("p",{children:["TCP 还有两个默认开启的优化，会在某些场景制造意外延迟。",e.jsx("strong",{children:"Nagle 算法"}),"会把多个小包攒一攒再一起发， 减少「一字节一个包」的浪费；",e.jsx("strong",{children:"延迟 ACK"}),"则让接收方稍等一会儿、看能不能把 ACK 和回包合并。 两者单独都合理，但",e.jsx("em",{children:"撞在一起"}),"时，发送方在等 ACK 才发下一个小包、接收方又在延迟这个 ACK， 就可能凭空多出几十到几百毫秒延迟。所以 SSH、游戏、RPC 这类小包交互场景，常用",e.jsx("code",{children:"TCP_NODELAY"})," 关掉 Nagle。"]}),e.jsx(s,{lang:"python",title:"关闭 Nagle 降低交互延迟",code:o})]}),e.jsx(r,{variant:"info",title:"面试追问与常见误区",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"误区：以为 UDP「不可靠」就等于「经常丢」。"}),"UDP 只是",e.jsx("em",{children:"不保证"}),"可靠， 在质量好的网络里它照样几乎不丢；它省掉的是「保证」的机制开销。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"追问：UDP 有粘包问题吗？"}),"没有。UDP 面向报文，一次 ",e.jsx("code",{children:"recvfrom"})," 正好对应一个发出的数据报， 边界天然保留——但要注意单个 UDP 数据报过大会在 IP 层分片，任一片丢失整个报文作废。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"追问：QUIC 凭什么比 TCP 好？"}),"它跑在 UDP 上、在用户态实现，避开了 TCP 的队头阻塞 （一条流丢包不阻塞其他流）、把 TLS 握手和传输握手合并（更少 RTT）、还支持连接迁移（换网不断连）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"追问：DNS 为什么用 UDP？"}),"查询小、要快、丢了重查代价低；但响应过大或区域传送时切 TCP。"]})]})}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["被问「TCP 和 UDP 区别」，按「连接 / 可靠 / 有序 / 开销 / 通信方式 / 速度」六维对比， 再各举两个典型场景；被追问「直播为什么用 UDP」就讲实时性优先于完整性的取舍； 被问「粘包怎么解决」，直接答",e.jsx("strong",{children:"定长 / 分隔符 / 长度字段"}),"三选一，并说明长度字段最常用、 强调这是因为 TCP 面向字节流、没有消息边界，而 UDP 面向报文不存在此问题。"]}),e.jsxs(d,{title:"用长度字段解决粘包",children:[e.jsxs("p",{children:["下面是「长度字段」方案的伪代码：发送端给每条消息加 4 字节长度头；接收端先",e.jsx("strong",{children:"读满 4 字节"}),"拿到长度，再",e.jsx("strong",{children:"精确读够这么多字节"}),"作为消息体。关键在那个",e.jsx("code",{children:"recv_exactly"}),"——必须循环读到凑够指定字节数，才能彻底躲开粘包 / 拆包。"]}),e.jsx(s,{lang:"python",title:"length_prefix.py",code:t}),e.jsxs("p",{children:["想一想：如果不用 ",e.jsx("code",{children:"recv_exactly"})," 而是一次 ",e.jsx("code",{children:"recv"})," 就当成一条消息处理， 在高并发或大消息下会出什么问题？（答案：读到半条或多条，正是粘包 / 拆包。）"]})]}),e.jsx(l,{points:["TCP 面向连接、可靠、有序但开销大、只能一对一；UDP 无连接、不可靠、首部小、支持广播组播、更快。","TCP 适合网页/文件/邮件等不容出错的场景，UDP 适合 DNS/直播/游戏/QUIC 等低延迟可容错的场景。","直播用 UDP，是因为实时性比完整性更重要——丢帧比卡顿更可接受。","想在 UDP 上要可靠，就在应用层自建序号/确认/重传，代表是 QUIC 和 KCP，灵活性优于改不动的 TCP。","TCP 面向字节流没有消息边界，会出现粘包/拆包；UDP 面向报文不存在该问题。","解决粘包三法：定长、分隔符、长度字段，其中长度字段最通用，配合 recv_exactly 循环读满。","能力差异写在首部里：UDP 固定 8 字节、TCP 至少 20 字节，多出的序号/确认/窗口/标志位/选项正对应可靠、有序、流控、连接管理。","“粘包”是误称——TCP 本就是字节流没有包边界，问题出在应用层没定义消息边界，要修的是应用协议而非 TCP。","Nagle 算法与延迟 ACK 撞上时会制造几十到几百毫秒延迟，交互式小包场景常用 TCP_NODELAY 关闭 Nagle。"]})]})}export{U as default};
