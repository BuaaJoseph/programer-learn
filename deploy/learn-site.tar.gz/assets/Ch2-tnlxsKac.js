import{r as g,j as e}from"./index-BRE2eT09.js";import{L as m,a as p,P as R,C as t,S as Z}from"./Summary-0I5Aw5GG.js";import{K as E}from"./KeyIdea-BpzDuX4B.js";import{E as N}from"./Example-B36MEsxr.js";import{F as S}from"./Figure-CmauUF1f.js";const o=[10,23,37,48,55,62,78,90],k=[1,2,1,3,1,2,1,2],O=[55,78,23];function f(){const[i,a]=g.useState(55),d=o.map((s,c)=>56+c*48),h=o.indexOf(i),j=e.jsxs(e.Fragment,{children:[O.map(s=>e.jsxs("button",{className:`fig-btn ${i===s?"active":""}`,onClick:()=>a(s),children:["查 ",s]},s)),e.jsx("span",{className:"fig-note",children:"ZSet 用跳表：O(log N) 找到分数、支持范围/排名"})]});return e.jsx(S,{caption:"跳表在原始链表上叠加多层「快速通道」。查找从最高层开始，能跳就跳、跳过头就下降一层，平均 O(log N)——这正是 ZSet 排行榜按分数排序与范围查询的底座。",controls:j,children:e.jsxs("svg",{viewBox:"0 0 460 200",width:"460",role:"img","aria-label":"跳表查找",children:[[3,2,1].map((s,c)=>{const r=30+c*42;return e.jsxs("g",{children:[e.jsxs("text",{x:"14",y:r+5,fontFamily:"var(--mono)",fontSize:"10",fill:"var(--ink-faint)",children:["L",s]}),e.jsx("line",{x1:"40",y1:r,x2:"440",y2:r,stroke:"var(--border)"}),o.map((x,l)=>{if(k[l]<s)return null;const n=x===i;return e.jsxs("g",{children:[e.jsx("circle",{cx:d[l],cy:r,r:"11",fill:n?"var(--rose)":"var(--rose-soft)",stroke:n?"var(--rose)":"var(--rose-line)"}),e.jsx("text",{x:d[l],y:r+4,textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"9",fontWeight:n?"700":"400",fill:n?"#ffffff":"var(--ink)",children:x})]},l)})]},s)}),e.jsx("rect",{x:"40",y:"158",width:"400",height:"30",rx:"7",fill:"var(--green-soft)",stroke:"var(--green-line)"}),e.jsxs("text",{x:"52",y:"178",fontFamily:"var(--mono)",fontSize:"12",fill:"var(--green)",children:["ZRANK 得到「",i,"」的排名 = 第 ",h+1," 名（从高层快速逼近，再下沉命中）"]})]})})}const u=`# 游戏排行榜：score=分数，member=玩家
127.0.0.1:6379> ZADD game:rank 1500 alice 1200 bob 1800 carol
(integer) 3

# 玩家加分（原子）：carol 又赢了一局 +50
127.0.0.1:6379> ZINCRBY game:rank 50 carol
"1850"

# Top10 排行榜（从高到低，带分数）
127.0.0.1:6379> ZREVRANGE game:rank 0 9 WITHSCORES
1) "carol"
2) "1850"
3) "alice"
4) "1500"
5) "bob"
6) "1200"

# 查某个玩家的排名（ZREVRANK 是从高到低的名次，0 开始）
127.0.0.1:6379> ZREVRANK game:rank alice
(integer) 1                 # alice 排第 2 名`,C=`# 延时队列：score=到期时间戳(毫秒)，member=任务ID
# 把「30秒后执行」的任务塞进来
127.0.0.1:6379> ZADD delay:queue 1718500000000 task:order_close:99
(integer) 1

# 消费者轮询：取出所有「已到期」的任务（score <= 当前时间）
127.0.0.1:6379> ZRANGEBYSCORE delay:queue 0 1718500005000
1) "task:order_close:99"

# 取到后用 ZREM 删除，避免重复消费（生产中用 Lua 保证原子）
127.0.0.1:6379> ZREM delay:queue task:order_close:99
(integer) 1`,A=`# ZSet 小的时候是 listpack，大了切「跳表 + 字典」
127.0.0.1:6379> ZADD top 90 a 85 b
(integer) 2
127.0.0.1:6379> OBJECT ENCODING top
"listpack"

# 元素数超过 zset-max-listpack-entries(默认128)
# 或成员长度超过 zset-max-listpack-value(默认64) → skiplist
127.0.0.1:6379> CONFIG GET zset-max-listpack-entries
1) "zset-max-listpack-entries"
2) "128"`;function D(){return e.jsxs(e.Fragment,{children:[e.jsx(m,{children:e.jsxs("p",{children:["「做一个实时排行榜」几乎是后端面试的标准题，而标准答案永远是 Redis 的 ",e.jsx("strong",{children:"ZSet"}),"。 为什么排行榜偏偏用它？因为 ZSet 底层藏着一个叫",e.jsx("em",{children:"跳表"}),"（skiplist）的结构，能在 O(log N) 内完成 「按分数排序、查名次、取一段区间」——这些恰好是排行榜的全部需求。这一章把跳表讲透。"]})}),e.jsx("h2",{children:"ZSet 的底层：跳表 + 字典，一个都不能少"}),e.jsxs("p",{children:["当 ZSet 元素变多（超过 ",e.jsx("code",{children:"zset-max-listpack-entries"}),"，默认 128）后，它的底层编码会从 listpack 切成",e.jsx("strong",{children:"跳表（skiplist）加字典（dict）的组合"}),"。这两个结构存的是同一批数据，但各管一头："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"字典 dict"}),"：保存「member → score」的映射，让 ",e.jsx("code",{children:"ZSCORE member"}),"（按成员查分数）做到 O(1)。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"跳表 skiplist"}),"：按 score 从小到大把成员串起来，支持",e.jsx("strong",{children:"按分数排序、范围查询、查排名"}),"，都是 O(log N)。"]})]}),e.jsxs("p",{children:["两个结构的成员对象是",e.jsx("strong",{children:"共享"}),"的（指针指向同一份），所以不会双倍存数据。一句话： 字典负责「按名字找分数」，跳表负责「按分数找排序」，配合起来 ZSet 才能既快查分又快排序。"]}),e.jsx("h3",{children:"跳表是什么：给链表加「快速通道」"}),e.jsxs("p",{children:["想象一个按分数排好序的",e.jsx("em",{children:"有序链表"}),"，查一个值得从头一个个走，O(N)。跳表的聪明之处是：在原始链表之上， 随机给一部分节点",e.jsx("strong",{children:"加几层索引"}),"，高层索引节点稀疏、跨度大，像高速路的服务区。查找时",e.jsx("strong",{children:"从最高层开始， 能跳就跳"}),"，跳过头了就下降一层、继续逼近目标，逐层下沉直到命中。"]}),e.jsxs("p",{children:["因为每层的节点数大约是下一层的一半，层数约为 log N，所以查找、插入、删除都是 ",e.jsx("strong",{children:"O(log N)"}),"。 范围查询更是跳表的强项：先 O(log N) 定位到区间起点，然后沿最底层链表",e.jsx("strong",{children:"顺着指针往后扫"}),"即可， 这正是 ",e.jsx("code",{children:"ZRANGE"})," / ",e.jsx("code",{children:"ZRANGEBYSCORE"})," 高效的原因。"]}),e.jsx(f,{}),e.jsxs(N,{title:"游戏排行榜 Top10 怎么落地",children:[e.jsx("p",{children:"一个有上万玩家的游戏排行榜，用 ZSet 只需要几条命令就搞定，而且全是 O(log N) 级别："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"加分"}),"：玩家得分用 ",e.jsx("code",{children:"ZINCRBY game:rank 50 carol"})," 原子累加，不用读出来再写回。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Top10"}),"：",e.jsx("code",{children:"ZREVRANGE game:rank 0 9 WITHSCORES"})," 直接拿到分数最高的前 10 名及分数。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"查我的名次"}),"：",e.jsx("code",{children:"ZREVRANK game:rank alice"})," 得到从高到低的排名，前端显示「你排第 N 名」。"]})]}),e.jsxs("p",{children:["换成关系型数据库，每刷新一次排行榜都要 ",e.jsx("code",{children:"ORDER BY score DESC LIMIT 10"})," 全表排序，上万玩家高并发下直接崩； ZSet 因为数据天然按分数有序，取 Top10 几乎零成本。"]})]}),e.jsx("h2",{children:"为什么用跳表，不用红黑树？"}),e.jsx("p",{children:"平衡二叉树（红黑树、AVL）同样能做到 O(log N) 的有序操作，但 Redis 作者偏偏选了跳表，原因很实际："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"范围查询更友好"}),"：跳表最底层就是一条有序链表，定位到起点后顺着指针扫一段即可； 红黑树取区间得做中序遍历、来回上下跳节点，实现和效率都更别扭。",e.jsx("code",{children:"ZRANGE"})," 这种区间操作 ZSet 用得极多。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"实现简单、易维护"}),"：跳表插入删除只需调整少数几个指针，靠随机层高保持平衡，没有红黑树那套 复杂的旋转和变色逻辑，代码少、出 bug 概率低。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"更易做并发/演进"}),"：跳表的局部修改特性，让它在需要并发或迭代时比树结构更容易处理。"]})]}),e.jsx(E,{title:"ZSet = 字典(O(1)查分) + 跳表(O(log N)排序)",children:e.jsx("p",{children:"记住这个组合就抓住了 ZSet 的精髓：任何「既要按 key 精确查，又要按值排序/取区间」的需求， ZSet 都是首选。排行榜、带权重的去重列表、按时间排序的延时队列，本质都是这同一个能力的不同包装。"})}),e.jsx("h3",{children:"延时队列：把「到期时间」当 score"}),e.jsxs("p",{children:["ZSet 还有个经典用法是",e.jsx("strong",{children:"延时队列"}),"：把任务的",e.jsx("em",{children:"到期时间戳"}),"当作 score，任务 ID 当 member。 消费者只需周期性地 ",e.jsx("code",{children:"ZRANGEBYSCORE delay:queue 0 当前时间"}),"，就能一次性捞出所有「已经到期」的任务来执行。 订单 30 分钟未支付自动关闭、消息延迟推送，都能这么实现。"]}),e.jsx(p,{variant:"warn",title:"延时队列的坑",children:e.jsxs("ul",{children:[e.jsxs("li",{children:["「取出 + 删除」必须",e.jsx("strong",{children:"原子"}),"，否则多个消费者会重复消费同一个任务——生产中用 Lua 脚本把",e.jsx("code",{children:"ZRANGEBYSCORE"})," 和 ",e.jsx("code",{children:"ZREM"})," 包成一步。"]}),e.jsx("li",{children:"轮询有延迟和空转开销，对实时性极高或量极大的场景，更适合用专门的消息队列（如 Kafka、RabbitMQ 延迟插件）。"})]})}),e.jsx("h2",{children:"面试怎么答"}),e.jsxs("p",{children:["被问「排行榜为什么用 ZSet」，标准答法三句话：一是 ",e.jsx("strong",{children:"ZSet 底层是跳表 + 字典"}),"，字典保证 O(1) 查分、 跳表保证 O(log N) 排序和范围查询；二是",e.jsx("strong",{children:"排行榜的核心操作（加分、取 Top N、查名次）正好都被跳表覆盖"}),"， 而数据库要全表排序扛不住高并发；三是",e.jsx("strong",{children:"跳表相比红黑树更适合范围查询、实现也更简单"}),"。"]}),e.jsxs(R,{title:"动手做一个排行榜 + 延时队列",children:[e.jsxs("p",{children:["先用几条命令把游戏排行榜跑起来，体会 ",e.jsx("code",{children:"ZINCRBY"})," / ",e.jsx("code",{children:"ZREVRANGE"})," / ",e.jsx("code",{children:"ZREVRANK"})," 的配合："]}),e.jsx(t,{lang:"bash",title:"排行榜",code:u}),e.jsx("p",{children:"再用同一个 ZSet 实现延时队列，把到期时间戳当分数："}),e.jsx(t,{lang:"bash",title:"延时队列",code:C}),e.jsxs("p",{children:["最后用 ",e.jsx("code",{children:"OBJECT ENCODING"})," 观察 ZSet 何时从 listpack 切到 skiplist："]}),e.jsx(t,{lang:"bash",title:"编码切换",code:A})]}),e.jsx(Z,{points:["ZSet 底层是「跳表 skiplist + 字典 dict」的组合：字典管 O(1) 按成员查分，跳表管 O(log N) 排序与范围查询。","跳表是给有序链表加多层稀疏索引，查找时从高层「能跳就跳」逐层下降，复杂度 O(log N)。","范围查询是跳表强项：定位起点后沿最底层链表顺扫，这是 ZRANGE/ZRANGEBYSCORE 高效的根本。","选跳表不选红黑树：范围查询更友好、实现更简单、更易做并发与演进。","排行榜用 ZADD/ZINCRBY 加分、ZREVRANGE 取 TopN、ZREVRANK 查名次，全是 O(log N)。","延时队列把到期时间戳当 score，ZRANGEBYSCORE 捞到期任务，取出与删除要用 Lua 保证原子。"]})]})}export{D as default};
