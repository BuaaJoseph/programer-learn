import{r as g,j as e}from"./index-DL563RIm.js";import{L as S,S as p}from"./Summary-BrgLcNDp.js";import{K as c}from"./KeyIdea-exK4GrdK.js";import{C as s}from"./Callout-B-8nslAm.js";import{C as r}from"./CodeBlock-DkVyd3P6.js";import{E as v}from"./Example-HxOmIesu.js";import{F as b}from"./Figure-Ueosrsuu.js";const l=[{key:"state",label:"@State",title:"@State（视图私有状态）",note:"由当前视图「拥有」的本地可变状态（计数、开关、输入）。它一变，SwiftUI 就重新计算这个视图的 body，自动刷新界面。是状态的「单一数据源」。"},{key:"binding",label:"@Binding",title:"@Binding（双向引用）",note:"不拥有状态，而是持有对上层 @State 的读写引用。把它传给子视图，子视图改它就等于改源头——这就是 TextField/Toggle 的双向绑定原理（用 $ 取得 Binding）。"},{key:"observable",label:"@Observable",title:"@Observable（可观察模型）",note:"标注一个类（通常是 ViewModel）。SwiftUI 自动追踪视图实际读取了哪些属性，只有这些属性变化时才刷新对应视图——比旧的 ObservableObject 更精准。"},{key:"environment",label:"@Environment",title:"@Environment（跨层共享）",note:"把模型或系统值注入环境，深层子视图无需逐层传递即可读取。适合主题、路由、登录用户等需要被很多视图共享的状态。"},{key:"body",label:"body 刷新",title:"body：UI = f(state)",note:"以上任一被读取的状态变化，都会让 SwiftUI 重新调用 body 计算出新的视图描述，再 diff 出最小改动刷新屏幕。你只声明「长什么样」，框架负责「怎么变」。"}];function u(){const[n,d]=g.useState("state"),o=l.find(t=>t.key===n),j=e.jsx(e.Fragment,{children:l.map(t=>e.jsx("button",{className:`fig-btn ${n===t.key?"active":""}`,onClick:()=>d(t.key),children:t.label},t.key))});return e.jsx(b,{caption:"SwiftUI 是状态驱动的：@State 持有私有状态、@Binding 把读写权下传、@Observable 暴露模型、@Environment 跨层共享。任一被读取的状态一变，body 就重新计算、界面自动刷新。点每个包装器看它的角色。",controls:j,children:e.jsxs("svg",{viewBox:"0 0 480 232",width:"480",role:"img","aria-label":"SwiftUI 状态驱动数据流图",children:[l.slice(0,4).map((t,a)=>{const x=12+a%2*234,h=22+Math.floor(a/2)*50,i=t.key===n;return e.jsxs("g",{onClick:()=>d(t.key),style:{cursor:"pointer"},children:[e.jsx("rect",{x,y:h,width:"222",height:"40",rx:"9",fill:i?"var(--accent)":"var(--bg-subtle)",fillOpacity:i?.16:1,stroke:i?"var(--accent)":"var(--border)",strokeWidth:i?2:1}),e.jsx("text",{x:x+111,y:h+25,textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"12.5",fontWeight:i?"700":"600",fill:i?"var(--accent-strong)":"var(--ink)",children:t.label})]},t.key)}),e.jsxs("g",{onClick:()=>d("body"),style:{cursor:"pointer"},children:[e.jsx("rect",{x:"12",y:"124",width:"456",height:"34",rx:"9",fill:n==="body"?"var(--accent)":"var(--bg-subtle)",fillOpacity:n==="body"?.16:1,stroke:n==="body"?"var(--accent)":"var(--border)",strokeWidth:n==="body"?2:1}),e.jsx("text",{x:"240",y:"146",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"12",fontWeight:n==="body"?"700":"600",fill:n==="body"?"var(--accent-strong)":"var(--ink)",children:"body 重新计算 → 界面刷新"})]}),e.jsx("rect",{x:"12",y:"166",width:"456",height:"60",rx:"10",fill:"var(--accent-soft)",stroke:"var(--accent-line)"}),e.jsx("text",{x:"26",y:"186",fontFamily:"var(--mono)",fontSize:"11",fill:"var(--accent-strong)",children:o.title}),e.jsx("foreignObject",{x:"24",y:"192",width:"434",height:"32",children:e.jsx("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"12px var(--sans)",color:"var(--ink)",lineHeight:1.4},children:o.note})})]})})}const m=`import SwiftUI

struct CounterView: View {
    // @State：这个视图私有的本地可变状态
    @State private var count = 0

    var body: some View {
        VStack(spacing: 16) {
            Text("当前计数：\\(count)")   // 读 count
                .font(.title)
            Button("加一") {
                count += 1                // 改 count → 触发 body 重算 → 界面刷新
            }
        }
        .padding()
    }
}`,f=`struct ToggleDemo: View {
    @State private var isOn = false

    var body: some View {
        VStack {
            // $isOn 取得对该 @State 的 Binding（双向引用）
            Toggle("开关", isOn: $isOn)
            Text(isOn ? "已开启" : "已关闭")
        }
        .padding()
    }
}`,y=`struct NameForm: View {
    @State private var name = ""

    var body: some View {
        VStack(alignment: .leading) {
            // TextField 需要一个 Binding<String>：用 $ 取得
            TextField("请输入名字", text: $name)
                .textFieldStyle(.roundedBorder)
            Text(name.isEmpty ? "（还没输入）" : "你好，\\(name)")
        }
        .padding()
    }
}`,w=`import SwiftUI

// 子视图：自己不「拥有」状态，只持有上层 @State 的读写引用
struct StepperRow: View {
    let title: String
    @Binding var value: Int          // 注意是 @Binding，不是 @State

    var body: some View {
        HStack {
            Text(title)
            Spacer()
            Button("-") { value -= 1 }   // 改的是上层那个源头
            Text("\\(value)").frame(minWidth: 32)
            Button("+") { value += 1 }
        }
    }
}

// 父视图：单一数据源在这里
struct CounterScreen: View {
    @State private var apples = 0      // 源头：唯一可信状态
    @State private var pears = 0

    var body: some View {
        VStack(spacing: 12) {
            // 用 $ 把 @State 的 Binding 传给子视图
            StepperRow(title: "苹果", value: $apples)
            StepperRow(title: "梨",  value: $pears)
            Divider()
            Text("合计：\\(apples + pears)")   // 子视图一改，这里立刻同步
                .font(.headline)
        }
        .padding()
    }
}`,B=`// 不好：状态藏在子视图里，父视图想用却拿不到
struct ChildView: View {
    @State private var text = ""        // 状态被「锁」在子视图内部
    var body: some View {
        TextField("输入", text: $text)
    }
}
// 父视图无法读到 text，也无法和兄弟视图共享 → 需要状态提升`,k=`// 好：把状态提升到能覆盖所有用到它的视图的最近公共父节点
struct ParentView: View {
    @State private var text = ""        // 提升到父视图，作为单一数据源

    var body: some View {
        VStack {
            ChildInput(text: $text)     // 用 $ 下传 Binding
            Text("实时预览：\\(text)")    // 同级也能读到同一个源头
        }
    }
}

struct ChildInput: View {
    @Binding var text: String
    var body: some View {
        TextField("输入", text: $text)
    }
}`;function U(){return e.jsxs("article",{children:[e.jsxs(S,{children:["上一章我们让界面「长出来了」，但它还是死的——点按钮没反应、输入框改不了文字。 这一章要点亮 SwiftUI 真正的灵魂：",e.jsx("strong",{children:"状态驱动"}),"。你只要改一个被视图读取的状态值， 框架就会自动重算 ",e.jsx("code",{children:"body"})," 并刷新界面，你",e.jsx("strong",{children:"永远不用手动去更新控件"}),"。 我们会讲透 ",e.jsx("code",{children:"@State"}),"（视图私有的本地状态）、",e.jsx("code",{children:"$"})," 取得的 ",e.jsx("code",{children:"Binding"}),"、",e.jsx("code",{children:"@Binding"}),"（把状态的读写引用传给子视图实现双向绑定），以及背后的单一数据源、 单向数据流和状态提升。"]}),e.jsx("h2",{children:"一、SwiftUI 的灵魂：改状态 → 自动刷新"}),e.jsxs(c,{children:["SwiftUI 的核心机制是：",e.jsx("strong",{children:"把可变状态标记出来，状态一变，框架就自动重算用到它的 body， 刷新对应界面"}),"。你声明「界面 = 状态的函数」，框架负责「状态变了之后怎么把屏幕改对」。 这就是 ",e.jsx("code",{children:"UI = f(state)"})," 的运行时含义。"]}),e.jsxs("p",{children:["对比上一章提过的 UIKit：那里你得 ",e.jsx("code",{children:'label.text = "\\\\(count)"'})," 亲手把新值写回控件， 漏写一处界面就和数据脱节了。SwiftUI 把这件事反过来——你只管改 ",e.jsx("strong",{children:"状态"}),"， 界面是状态的投影，框架保证投影永远是最新的。下面这个交互图把各种「状态来源」摊开， 点一个看它扮演什么角色："]}),e.jsx(u,{}),e.jsx("h2",{children:"二、@State：视图私有的本地可变状态"}),e.jsxs(c,{children:[e.jsx("code",{children:"@State"})," 声明一份",e.jsx("strong",{children:"由当前视图私有、拥有"}),"的本地可变状态。它的值一旦变化， SwiftUI 就重新计算这个视图的 ",e.jsx("code",{children:"body"}),"，从而刷新界面。它适合",e.jsx("strong",{children:"简单类型"}),"（计数、开关、输入文本）和",e.jsx("strong",{children:"视图私有"}),"的小状态。"]}),e.jsxs("p",{children:["为什么需要这个特殊标记？回忆上一章：视图是 ",e.jsx("strong",{children:"struct（值类型）"}),"，每次 ",e.jsx("code",{children:"body"}),"重算都会被重新生成。普通存储属性会随之「重置」，存不住跨刷新的状态。",e.jsx("code",{children:"@State"}),"是一个属性包装器，它把真实存储放在视图",e.jsx("strong",{children:"之外"}),"由框架托管，于是值能跨越多次",e.jsx("code",{children:"body"})," 重算而保持；同时框架知道「谁读了它」，值变时就只刷新相关视图。"]}),e.jsx(r,{lang:"swift",title:"@State 计数器：改值即刷新",code:m}),e.jsxs("p",{children:["点「加一」执行 ",e.jsx("code",{children:"count += 1"}),"，框架监测到 ",e.jsx("code",{children:"count"})," 变了，重算",e.jsx("code",{children:"CounterView"})," 的 ",e.jsx("code",{children:"body"}),"，",e.jsx("code",{children:"Text"})," 里的 ",e.jsx("code",{children:"\\\\(count)"}),"随之更新。整个过程你没有去碰任何 ",e.jsx("code",{children:"Text"})," 对象。"]}),e.jsxs(s,{variant:"tip",title:"约定：@State 几乎总是 private",children:["既然 ",e.jsx("code",{children:"@State"})," 表达的是「视图私有」状态，惯例就写成 ",e.jsx("code",{children:"@State private var"}),"。 它不该被外部直接赋值；要让外部参与读写，应该用 ",e.jsx("code",{children:"@Binding"}),"（见下文）。"]}),e.jsx("h2",{children:"三、用 $ 取得 Binding"}),e.jsxs("p",{children:["当一个控件需要",e.jsx("strong",{children:"双向"}),"读写某个状态（比如 ",e.jsx("code",{children:"Toggle"})," 要能读当前开关、 也要能在用户拨动时把新值写回），它要的不是值本身，而是一个 ",e.jsx("strong",{children:e.jsx("code",{children:"Binding"})}),"—— 一个「能读也能写」这块状态的引用。对一个 ",e.jsx("code",{children:"@State"})," 属性加 ",e.jsx("strong",{children:e.jsx("code",{children:"$"})}),"前缀，就能取得它的 ",e.jsx("code",{children:"Binding"}),"。"]}),e.jsx(r,{lang:"swift",title:"$isOn 把 Binding 交给 Toggle",code:f}),e.jsx(r,{lang:"swift",title:"TextField 也吃 Binding",code:y}),e.jsxs("p",{children:["这里有三个层次别混：",e.jsx("code",{children:"count"})," 是",e.jsx("strong",{children:"值"}),"（读出来用）；",e.jsx("code",{children:"$count"})," 是它的 ",e.jsx("strong",{children:"Binding"}),"（读写引用，传给需要双向绑定的控件）； 而 ",e.jsx("code",{children:"_count"}),"（很少直接用）才是底层那个 ",e.jsx("code",{children:"State"})," 包装器实例。日常你只需记住 「读值用名字、要双向就加 ",e.jsx("code",{children:"$"}),"」。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"写法"}),e.jsx("th",{children:"是什么"}),e.jsx("th",{children:"典型用途"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"count"})}),e.jsx("td",{children:"当前值（如 Int）"}),e.jsx("td",{children:"在 body 里读出来显示 / 计算"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"$count"})}),e.jsx("td",{children:"Binding（读写引用）"}),e.jsx("td",{children:"传给 Toggle / TextField / 子视图"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"_count"})}),e.jsx("td",{children:"State 包装器本体"}),e.jsx("td",{children:"极少直接用（如自定义初始化）"})]})]})]}),e.jsx("h2",{children:"四、@Binding：不拥有状态，只持有上层的读写引用"}),e.jsxs(c,{children:[e.jsx("code",{children:"@Binding"})," 声明的属性",e.jsx("strong",{children:"不拥有"}),"状态，它持有的是对",e.jsx("strong",{children:"上层某个 @State 的读写引用"}),"。 子视图读它就是读源头，改它就是改源头——这就实现了父子之间的",e.jsx("strong",{children:"双向绑定"}),"。"]}),e.jsxs("p",{children:["当你要把一块状态",e.jsx("strong",{children:"下发"}),"给子视图，并允许子视图修改它时，子视图就用 ",e.jsx("code",{children:"@Binding"}),"声明这个属性。父视图在传参时用 ",e.jsx("code",{children:"$"})," 把自己 ",e.jsx("code",{children:"@State"})," 的 Binding 交下去。 于是父子共享",e.jsx("strong",{children:"同一个源头"}),"，不存在「子视图拿到一份拷贝、改了父视图不知道」的问题。"]}),e.jsx(r,{lang:"swift",title:"计数器：父 @State + 子 @Binding 的完整例子",code:w}),e.jsxs("p",{children:["看清这条链路：源头是 ",e.jsx("code",{children:"CounterScreen"})," 里的 ",e.jsx("code",{children:"@State apples"}),"；它通过",e.jsx("code",{children:"value: $apples"})," 把 Binding 交给子视图 ",e.jsx("code",{children:"StepperRow"}),"；子视图里",e.jsx("code",{children:"@Binding var value"})," 持有这个引用，按「+」执行 ",e.jsx("code",{children:"value += 1"})," 实际改的是",e.jsx("code",{children:"apples"}),"；",e.jsx("code",{children:"apples"})," 一变，框架重算 ",e.jsx("code",{children:"CounterScreen"})," 的 body， 底部 ",e.jsx("code",{children:"合计：\\\\(apples + pears)"})," 立刻同步。子视图",e.jsx("strong",{children:"自己不存"}),"这个数。"]}),e.jsxs(v,{title:"@State vs @Binding 一句话",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"@State"}),"：「这块状态归我（这个视图）所有，我是源头。」"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"@Binding"}),"：「这块状态不是我的，我只拿到一个能读能写它的引用，改它就是改源头。」"]})]}),e.jsx("h2",{children:"五、单一数据源与单向数据流"}),e.jsx("p",{children:"把上面的例子抽象一下，就得到 SwiftUI（也是 React、Jetpack Compose 共有）的两条基本纪律："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"单一数据源（single source of truth）"}),"：每块状态只有",e.jsx("strong",{children:"一个"}),"权威所有者 （用 ",e.jsx("code",{children:"@State"})," 持有），其他视图都引用它，绝不各存一份拷贝。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"单向数据流"}),"：状态",e.jsx("strong",{children:"向下"}),"流给子视图（值或 Binding），事件 / 修改",e.jsx("strong",{children:"向上"}),"回到源头去改那唯一的状态，状态再向下重新流——形成一个清晰的环，而不是 四处互相直接改来改去。"]})]}),e.jsxs(s,{variant:"info",title:"和 React / Compose 是同一套心智",children:["如果你写过 React，",e.jsx("code",{children:"@State"})," 约等于 ",e.jsx("code",{children:"useState"}),"，",e.jsx("code",{children:"$value"})," 下传约等于把",e.jsx("code",{children:"value"})," 和 ",e.jsx("code",{children:"setValue"})," 一起传给子组件；Jetpack Compose 里则对应",e.jsxs("code",{children:["remember ","{ mutableStateOf(...) }"]})," 加「state hoisting」。换了语言，骨架完全一致。"]}),e.jsx("h2",{children:"六、状态该放在哪一层：状态提升"}),e.jsxs("p",{children:["既然要单一数据源，一个现实问题就来了：某块状态到底声明在",e.jsx("strong",{children:"哪个视图"}),"里？规则很简单—— 把它放在",e.jsx("strong",{children:"所有需要读写它的视图的「最近公共父节点」"}),"。如果状态藏得太深（在某个子视图里）， 它的兄弟视图或父视图就够不着；这时就要把它",e.jsx("strong",{children:"提升（lift）"}),"到更上层。"]}),e.jsx(r,{lang:"swift",title:"反例：状态藏在子视图里，外面够不着",code:B}),e.jsx(r,{lang:"swift",title:"正例：把状态提升到公共父节点，再用 $ 下传",code:k}),e.jsxs("p",{children:["提升后，父视图持有唯一的 ",e.jsx("code",{children:"@State"}),"，把 Binding 用 ",e.jsx("code",{children:"$"})," 下传给真正负责输入的子视图， 同级的「预览」也能读到同一个源头。这就是「状态提升」：让状态住在",e.jsx("strong",{children:"恰好够高"}),"的那一层—— 不要更高（否则无关视图也被牵连重算），也不要更低（否则该用的人够不着）。"]}),e.jsx("h2",{children:"七、@State 的注意事项与边界"}),e.jsxs(s,{variant:"warn",title:"别用 @State 存「该由模型持有」的长生命周期状态",children:[e.jsx("code",{children:"@State"})," 是给",e.jsx("strong",{children:"视图私有、生命周期跟着视图走"}),"的简单状态用的（计数、开关、临时输入）。 不要拿它去存「用户的购物车」「登录会话」「从服务器拉来的领域数据」这类",e.jsx("strong",{children:"应由模型层持有、 需要跨视图共享或长期存活"}),"的状态——那是 ",e.jsx("code",{children:"@Observable"})," 模型 / ",e.jsx("code",{children:"@Environment"}),"的活（后续章节讲）。用错层会导致状态随视图重建而丢失，或多处不一致。"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"@State 写 private"}),"：它表达视图私有，外部要参与就改用 @Binding 下传。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"简单值优先"}),"：@State 最适合 Int / Bool / String 这类值类型的小状态。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"别复制状态"}),"：需要共享时传 Binding（同一个源头），不要在多处各 @State 一份。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"状态放对层"}),"：放在最近公共父节点，过高过低都会带来问题。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"领域数据交给模型"}),"：长生命周期 / 跨视图共享的数据不归 @State，留给 @Observable / @Environment。"]})]}),e.jsxs(s,{variant:"tip",children:["到这里你已经掌握了 SwiftUI 最关键的一条主线：状态驱动界面。",e.jsx("code",{children:"@State"})," 管视图私有的小状态，",e.jsx("code",{children:"@Binding"})," 把读写引用下传实现双向绑定，配合单一数据源 + 状态提升就能撑起大多数界面。 当状态变成「需要被很多视图共享的领域模型」时，就该请出 ",e.jsx("code",{children:"@Observable"})," 与",e.jsx("code",{children:"@Environment"}),"——那是下一章的内容。"]}),e.jsx(p,{points:["SwiftUI 的灵魂是状态驱动：改一个被读取的状态，框架自动重算 body 并刷新界面，你从不手动更新控件。","@State 是视图私有、由当前视图拥有的本地可变状态，适合简单类型；值变就触发该视图 body 重算。","对 @State 加 $ 前缀取得 Binding（读写引用）；count 是值、$count 是 Binding，传给 Toggle/TextField 实现双向绑定。","@Binding 不拥有状态，只持有对上层 @State 的读写引用；父用 $ 下传、子用 @Binding 接收，改它即改源头。","遵循单一数据源 + 单向数据流（与 React 的 useState、Compose 的 state hoisting 同一心智）。","状态提升：把状态放在所有用到它的视图的最近公共父节点——不要更高也不要更低。","别用 @State 存应由模型持有的长生命周期 / 跨视图共享数据，那是 @Observable / @Environment 的职责。"]})]})}export{U as default};
