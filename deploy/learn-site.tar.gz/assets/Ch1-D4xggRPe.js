import{j as e}from"./index-CNCQ9D3g.js";import{L as r,S as t}from"./Summary-B81QYNtK.js";import{K as d}from"./KeyIdea-CJu1AmJK.js";import{C as s}from"./Callout-DBjCLF-u.js";import{C as i}from"./CodeBlock-B4ANG3D_.js";import{E as n}from"./Example-C7EXHAW5.js";const c=`import SwiftUI

// 一个 View 就是一个遵循 View 协议的 struct（值类型）
struct GreetingView: View {
    // body 是计算属性，返回这个视图「长什么样」
    var body: some View {
        Text("你好，SwiftUI")
            .font(.title)
            .foregroundStyle(.blue)
    }
}`,l=`// SwiftUI 框架里 View 协议大致长这样（简化）
protocol View {
    // 关联类型：body 的具体类型由你实现时决定
    associatedtype Body: View
    // 唯一要求：提供一个描述界面的 body
    @ViewBuilder var body: Self.Body { get }
}`,o=`struct BasicsView: View {
    var body: some View {
        VStack(spacing: 12) {            // 竖向排列容器
            Text("标题")                  // 文本
                .font(.headline)
            Image(systemName: "star.fill") // 系统图标
                .foregroundStyle(.yellow)
            HStack {                      // 横向排列容器
                Text("左")
                Spacer()                  // 弹性占位，把两端推开
                Text("右")
            }
            Button("点我") {              // 按钮：标题 + 点击闭包
                print("tapped")
            }
        }
        .padding()
    }
}`,x=`// 每个修饰符都返回一个「包了一层」的新视图，可链式叠加
Text("修饰符是链式的")
    .font(.title2)            // 返回 ModifiedContent<Text, ...>
    .foregroundStyle(.white) // 又包一层
    .padding(12)             // 再包一层
    .background(.blue)       // 顺序有讲究：先 padding 再 background
    .clipShape(RoundedRectangle(cornerRadius: 8))`,h=`// 把界面拆成可复用的小视图，再组合成大视图
struct Avatar: View {
    let systemName: String
    var body: some View {
        Image(systemName: systemName)
            .font(.largeTitle)
            .foregroundStyle(.teal)
    }
}

struct UserRow: View {
    let name: String
    let subtitle: String
    var body: some View {
        HStack(spacing: 12) {
            Avatar(systemName: "person.crop.circle")  // 复用子视图
            VStack(alignment: .leading) {
                Text(name).font(.headline)
                Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

struct UserList: View {
    var body: some View {
        VStack(alignment: .leading) {
            UserRow(name: "小杜", subtitle: "iOS 学习中")   // 组合
            UserRow(name: "小李", subtitle: "SwiftUI 入门")
        }
        .padding()
    }
}`,a=`// UIKit：命令式——你亲手创建控件、设置属性、addSubview、还要管约束
final class UserRowView: UIView {
    private let avatar = UIImageView()
    private let titleLabel = UILabel()
    private let subtitleLabel = UILabel()

    init(name: String, subtitle: String) {
        super.init(frame: .zero)
        avatar.image = UIImage(systemName: "person.crop.circle")
        titleLabel.text = name
        subtitleLabel.text = subtitle
        subtitleLabel.textColor = .secondaryLabel

        let stack = UIStackView(arrangedSubviews: [titleLabel, subtitleLabel])
        stack.axis = .vertical
        let row = UIStackView(arrangedSubviews: [avatar, stack])
        row.axis = .horizontal
        row.spacing = 12
        addSubview(row)                       // 手动挂载
        row.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([         // 手动写约束
            row.topAnchor.constraint(equalTo: topAnchor),
            row.bottomAnchor.constraint(equalTo: bottomAnchor),
            row.leadingAnchor.constraint(equalTo: leadingAnchor),
            row.trailingAnchor.constraint(equalTo: trailingAnchor),
        ])
    }
    required init?(coder: NSCoder) { fatalError() }
}`,j=`// VStack 的初始化器大致是这样：content 被标了 @ViewBuilder
// 所以花括号里能直接「列出」多个视图，由 ViewBuilder 拼成一个整体
VStack {
    Text("第一行")
    Text("第二行")   // 不用逗号、不用数组，ViewBuilder 帮你打包
    if showHint {    // 甚至能写有限的 if
        Text("提示")
    }
}`;function V(){return e.jsxs("article",{children:[e.jsxs(r,{children:["SwiftUI 是一套",e.jsx("strong",{children:"声明式"}),"的界面框架：你不再一步步告诉系统「先创建这个控件、 再把它加到那个父视图、然后设置约束」，而是直接",e.jsx("strong",{children:"描述"}),"「界面应该长成什么样」， 剩下的渲染与更新交给框架。这一章我们从最根基的 ",e.jsx("code",{children:"View"})," 协议讲起：它是什么、",e.jsx("code",{children:"body"})," 为什么是计算属性、为什么用组合而非继承拼界面、声明式与命令式到底差在哪， 以及 ",e.jsx("code",{children:"some View"})," 和 ",e.jsx("code",{children:"@ViewBuilder"})," 这两个一上来就会撞见的概念。"]}),e.jsx("h2",{children:"一、View 是「描述界面的值」，不是控件对象"}),e.jsxs(d,{children:["在 SwiftUI 里，一个视图就是一个遵循 ",e.jsx("code",{children:"View"})," 协议的 ",e.jsx("strong",{children:"struct（值类型）"}),"。 它不是一个长期存在、你拿着引用去改的控件对象，而是一份",e.jsx("strong",{children:"对界面的描述"}),"—— 框架读这份描述去渲染屏幕。界面要变，就产生一份新的描述，而不是去「修改」旧控件。"]}),e.jsxs("p",{children:["这是和 UIKit 最根本的世界观差异。UIKit 里 ",e.jsx("code",{children:"UILabel"}),"、",e.jsx("code",{children:"UIButton"}),"都是 ",e.jsx("strong",{children:"class（引用类型）"}),"的对象，活在内存里，你保存它的引用，之后随时",e.jsx("code",{children:'label.text = "新值"'})," 去改它。SwiftUI 的 ",e.jsx("code",{children:"Text"}),"、",e.jsx("code",{children:"Button"}),"则是",e.jsx("strong",{children:"轻量的值"}),"：每次 ",e.jsx("code",{children:"body"})," 被计算，都会重新生成它们。 你几乎从不持有某个视图的引用去「改」它——你改的是",e.jsx("strong",{children:"状态"}),"，框架据此重算视图描述。"]}),e.jsx(i,{lang:"swift",title:"最小的一个 View",code:c}),e.jsxs("p",{children:["上面 ",e.jsx("code",{children:"GreetingView"})," 是个 struct，遵循 ",e.jsx("code",{children:"View"}),"。它唯一的「内容」就是 一个名叫 ",e.jsx("code",{children:"body"})," 的计算属性。注意 ",e.jsx("code",{children:'Text("...")'})," 后面跟着一串",e.jsx("code",{children:".font(...)"}),"、",e.jsx("code",{children:".foregroundStyle(...)"}),"——这些是修饰符，后面会讲。"]}),e.jsx("h2",{children:"二、body：返回视图树的计算属性"}),e.jsxs("p",{children:[e.jsx("code",{children:"View"})," 协议其实只对你提一个要求：实现一个 ",e.jsx("code",{children:"body"}),"。它是",e.jsx("strong",{children:"计算属性"}),"（用 ",e.jsx("code",{children:"var"})," + 花括号，没有存储值），每次被访问都会",e.jsx("strong",{children:"重新求值"}),"，返回一棵「视图树」——也就是由各种子视图嵌套组合出的描述。"]}),e.jsx(i,{lang:"swift",title:"View 协议的形状（简化）",code:l}),e.jsxs("p",{children:["这里有个关键点要记住：",e.jsx("strong",{children:"body 会被反复调用"}),"。当状态变化时，框架就是靠重新读取",e.jsx("code",{children:"body"})," 拿到新描述，再和旧描述做 diff，算出屏幕上最小的改动。所以 ",e.jsx("code",{children:"body"}),"里",e.jsx("strong",{children:"不要做有副作用的重活"}),"（网络请求、写文件），它应当是「给定当前状态、纯粹地算出界面长什么样」。 这正是那句口号的含义：",e.jsx("code",{children:"UI = f(state)"}),"，界面是状态的函数。"]}),e.jsxs(s,{variant:"warn",title:"body 不是「只算一次」",children:["初学者常以为 ",e.jsx("code",{children:"body"})," 像构造函数一样只跑一次。恰恰相反，它可能在一次交互里被算很多次。 把它当成",e.jsx("strong",{children:"纯函数"}),"对待：只读状态、只产出视图，别在里面藏计数器自增、发请求这类副作用。"]}),e.jsx("h2",{children:"三、常用基础视图"}),e.jsx("p",{children:"SwiftUI 内置了一批「积木」视图，绝大多数界面都是它们拼出来的。先认识最常用的几个："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"视图"}),e.jsx("th",{children:"作用"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"Text"})}),e.jsx("td",{children:"显示一段文字"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"Image"})}),e.jsxs("td",{children:["显示图片；",e.jsx("code",{children:"Image(systemName:)"})," 用系统 SF Symbols 图标"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"Button"})}),e.jsx("td",{children:"按钮：一个标题/标签 + 一段点击时执行的闭包"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"VStack"})}),e.jsxs("td",{children:["把子视图",e.jsx("strong",{children:"竖直"}),"排列的容器"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"HStack"})}),e.jsxs("td",{children:["把子视图",e.jsx("strong",{children:"水平"}),"排列的容器"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"Spacer"})}),e.jsx("td",{children:"弹性占位，把同一栈里的视图推向两端"})]})]})]}),e.jsx(i,{lang:"swift",title:"用基础视图拼一个小界面",code:o}),e.jsxs("p",{children:["注意 ",e.jsxs("code",{children:['Button("点我") ',"{ ... }"]})," 里的花括号是一个",e.jsx("strong",{children:"闭包"}),"，是点击时才执行的动作。",e.jsx("code",{children:"VStack"})," 和 ",e.jsx("code",{children:"HStack"})," 的花括号里则直接「列出」了若干子视图——这能成立要归功于 后面讲的 ",e.jsx("code",{children:"@ViewBuilder"}),"。"]}),e.jsx("h2",{children:"四、修饰符：返回新视图的链式调用"}),e.jsxs(d,{children:["修饰符（modifier）如 ",e.jsx("code",{children:".font(...)"}),"、",e.jsx("code",{children:".padding(...)"})," 不是「就地改这个视图」， 而是",e.jsx("strong",{children:"包一层、返回一个新视图"}),"。所以它们能像管道一样链式串起来，每一节都在外面再裹一层。"]}),e.jsx(i,{lang:"swift",title:"修饰符是链式的，且顺序有意义",code:x}),e.jsxs("p",{children:["因为每个修饰符都「往外包一层」，",e.jsx("strong",{children:"顺序会影响结果"}),"。先 ",e.jsx("code",{children:".padding()"})," 再",e.jsx("code",{children:".background(.blue)"}),"，蓝色会铺满包含内边距的范围；反过来先 ",e.jsx("code",{children:".background"}),"再 ",e.jsx("code",{children:".padding"}),"，背景只贴着文字、外面那圈留白就没颜色了。把它想成「一层层往外套盒子」， 套的次序自然决定最终样子。"]}),e.jsxs(s,{variant:"tip",title:"链式 ≠ 命令式",children:["别被链式语法骗了——它和 UIKit 的 ",e.jsx("code",{children:"label.font = ...; label.backgroundColor = ..."}),"本质不同。后者在",e.jsx("strong",{children:"修改同一个对象"}),"；SwiftUI 每一步都在",e.jsx("strong",{children:"产出一个新值"}),"， 旧值原封不动。这正是值类型 + 声明式的体现。"]}),e.jsx("h2",{children:"五、组合而非继承：把界面拆成小视图再拼起来"}),e.jsxs("p",{children:["UIKit 里扩展界面常靠",e.jsx("strong",{children:"继承"}),"（自定义一个 ",e.jsx("code",{children:"UIView"})," 子类）。SwiftUI 走的是另一条路：",e.jsx("strong",{children:"组合"}),"。你写一堆职责单一的小视图，再像搭积木一样把它们嵌进更大的视图里。 小视图便于复用、便于单独预览、便于各自管自己那一小块状态。"]}),e.jsx(i,{lang:"swift",title:"声明式：拆成可复用子视图再组合",code:h}),e.jsxs("p",{children:["看 ",e.jsx("code",{children:"UserList"}),"：它没有「创建 UserRow、再 add 进去」，而是直接在 ",e.jsx("code",{children:"body"})," 里",e.jsx("strong",{children:"声明"}),"「这里有两行 UserRow」。每个 ",e.jsx("code",{children:"UserRow"})," 又声明它由一个 ",e.jsx("code",{children:"Avatar"}),"和两段 ",e.jsx("code",{children:"Text"})," 组成。整棵树是「描述」，不是「一连串创建与挂载的指令」。"]}),e.jsx("h2",{children:"六、声明式 vs 命令式：和 UIKit 正面对照"}),e.jsxs("p",{children:["同样是渲染一行用户信息，UIKit 的命令式写法要你",e.jsx("strong",{children:"亲手"}),"走完每一步：new 出控件、 设置属性、塞进 ",e.jsx("code",{children:"UIStackView"}),"、",e.jsx("code",{children:"addSubview"}),"、再写一串 Auto Layout 约束。 而且数据变了，你还得记得手动回去更新对应控件。"]}),e.jsx(i,{lang:"swift",title:"UIKit：命令式（对照前面的 SwiftUI 版）",code:a}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"命令式（UIKit）"}),e.jsx("th",{children:"声明式（SwiftUI）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"你写的内容"}),e.jsx("td",{children:"一步步「怎么做」：创建、挂载、布局"}),e.jsx("td",{children:"「长什么样」：描述结果"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"视图本体"}),e.jsx("td",{children:"class 对象，长期持有"}),e.jsx("td",{children:"struct 值，随时重算"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"数据变化时"}),e.jsx("td",{children:"手动找到控件去更新"}),e.jsx("td",{children:"改状态，框架自动刷新"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"布局"}),e.jsx("td",{children:"常需手写 Auto Layout 约束"}),e.jsx("td",{children:"栈 + 修饰符自动排布"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"复用方式"}),e.jsx("td",{children:"继承 / 自定义子类为主"}),e.jsx("td",{children:"组合小视图为主"})]})]})]}),e.jsxs(n,{title:"一句话抓住差别",children:[e.jsx("p",{children:"命令式：「拿到那个 label，把它的文字改成新值。」——你对控件下指令。"}),e.jsxs("p",{children:["声明式：「这个位置的文字",e.jsx("strong",{children:"等于"}),"这个状态。」——状态一变，界面自己跟上， 你从头到尾没碰过任何控件对象。"]})]}),e.jsx("h2",{children:"七、some View：不透明返回类型，为什么用在 body"}),e.jsxs("p",{children:["你会发现 ",e.jsx("code",{children:"body"})," 的类型几乎总是写成 ",e.jsx("code",{children:"some View"}),"。这是 Swift 的",e.jsx("strong",{children:"不透明返回类型（opaque return type）"}),"。它的意思是：「我返回的是",e.jsx("strong",{children:"某一个"}),"遵循 ",e.jsx("code",{children:"View"})," 的",e.jsx("strong",{children:"具体"}),"类型，编译期是确定且唯一的，但我不想把那个又长又乱的 真实类型名写出来。」"]}),e.jsxs("p",{children:["为什么需要它？因为 ",e.jsx("code",{children:"body"})," 的真实类型常常极其复杂——前面修饰符链的注释里 你已经看到 ",e.jsx("code",{children:"ModifiedContent<Text, ...>"})," 这种层层嵌套的泛型。一个稍复杂的视图， 其真实类型可能是几行长的泛型噩梦。",e.jsx("code",{children:"some View"})," 让你只需说「它是个 View」， 把那一长串交给编译器去推断。"]}),e.jsxs(s,{variant:"info",title:"some View 不等于 any View",children:[e.jsx("code",{children:"some View"})," 是「",e.jsx("strong",{children:"某个确定但被隐藏"}),"的具体类型」，编译期固定、零额外开销；",e.jsx("code",{children:"any View"})," 才是「运行时可以是任意 View」的类型擦除，开销更大、能力受限。 日常 ",e.jsx("code",{children:"body"})," 用 ",e.jsx("code",{children:"some View"})," 就对了。"]}),e.jsx("h2",{children:"八、@ViewBuilder：花括号里能直接「列视图」的魔法"}),e.jsxs("p",{children:["前面 ",e.jsxs("code",{children:["VStack ","{ Text(...) ; Text(...) }"]})," 里我们没用逗号、没建数组，就直接列了好几个视图， 甚至能写 ",e.jsx("code",{children:"if"}),"。一句话解释：这些花括号是被 ",e.jsxs("strong",{children:[e.jsx("code",{children:"@ViewBuilder"})," 结果构造器"]}),"接管的——它把你「列出」的多个视图",e.jsx("strong",{children:"自动打包"}),"成一个合成视图，并支持有限的",e.jsx("code",{children:"if"})," / ",e.jsx("code",{children:"switch"})," 等控制流。所以你能用近乎「声明列表」的方式描述子视图。"]}),e.jsx(i,{lang:"swift",title:"@ViewBuilder 让你直接列视图",code:j}),e.jsx("h2",{children:"九、边界与常见误区"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"别在 body 里做副作用"}),"：它会被反复调用，发请求 / 自增计数器都会出问题。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"别试图持有视图引用去改它"}),"：视图是值、是描述；要变就改驱动它的状态（下一章讲）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"修饰符顺序要想清楚"}),"：padding 与 background、frame 与 background 的先后会改变外观。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"视图拆得过碎也有代价"}),"：合理粒度即可，不必为每个 Text 都单独建一个 struct。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"ViewBuilder 的 if 是有限的"}),"：它支持常见控制流，但不是任意 Swift 代码都能塞进去。"]})]}),e.jsxs(s,{variant:"tip",children:["这一章我们只讲了「界面长什么样」这半边。但 SwiftUI 真正的威力在于另一半——",e.jsx("strong",{children:"界面如何随数据自动变化"}),"。下一章进入 ",e.jsx("code",{children:"@State"})," 与 ",e.jsx("code",{children:"@Binding"}),"： 看「改状态 → body 重算 → 界面刷新」这条主线如何让你彻底告别手动更新控件。"]}),e.jsx(t,{points:["View 是遵循 View 协议的 struct（值类型），是对界面的「描述」，不是你持有去修改的控件对象。","body 是计算属性，会被反复调用并返回视图树；把它当纯函数，UI = f(state)，别在里面做副作用。","基础积木：Text / Image / Button / VStack / HStack / Spacer，绝大多数界面由它们组合而成。","修饰符（.font/.padding/.background…）返回新视图、可链式叠加，且顺序会影响外观。","SwiftUI 用组合而非继承拼界面：写职责单一的小视图，再嵌套组合成大视图。","声明式（描述结果、改状态自动刷新）对比命令式 UIKit（手动创建、挂载、布局、更新）。","body 用 some View（不透明返回类型）隐藏复杂真实类型；@ViewBuilder 让花括号能直接列出多个视图并支持有限控制流。"]})]})}export{V as default};
