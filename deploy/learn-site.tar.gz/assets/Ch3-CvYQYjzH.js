import{j as e}from"./index-CbwU9xsL.js";import{L as i,a as s,C as l,P as d,S as r}from"./Summary-C6oEuVV5.js";import{K as c}from"./KeyIdea-B20gnIt6.js";import{E as o}from"./Example-BTxSzQRy.js";const n=`---
name: pr-triage
description: 自动审查并归类新提交的 Pull Request。当用户要 triage PR、批量处理待审 PR、给 PR 打标签时使用。
allowed-tools:
  - Bash(git diff:*)
  - Bash(git log:*)
  - mcp__github__list_pull_requests
  - mcp__github__pull_request_read
  - mcp__github__add_comment_to_pending_review
  - mcp__github__pull_request_review_write
---

# 审查并归类 Pull Request

激活后无需逐条确认即可调用上面列出的工具。

## 步骤
1. 用 mcp__github__list_pull_requests 拉取待审 PR 列表
2. 对每个 PR，用 mcp__github__pull_request_read 读取 diff 与描述
3. 找出明显 bug 与风险点，用 review 工具写成评论
4. 给每个 PR 归类：approve / needs-changes / question`,t=`# 调用捆绑在 skill 里的脚本
# CLAUDE_SKILL_DIR 指向本技能所在目录
python "$CLAUDE_SKILL_DIR/scripts/extract.py" --input report.pdf`;function j(){return e.jsxs(e.Fragment,{children:[e.jsx(i,{children:e.jsxs("p",{children:["到这里，技能还只是「一段写给 Claude 的文字」。真正让它有手有脚的，是三件事：在加载前先跑命令把实时信息嵌进正文、 调用捆绑在技能里的脚本、以及用 ",e.jsx("code",{children:"allowed-tools"})," 预批准一批工具（包括 MCP 工具）让它们激活时免确认。 本章把这三招串起来，最后给一个「自动化 GitHub 流程」的完整片段。"]})}),e.jsx("h2",{children:"动态上下文注入：加载前先跑命令"}),e.jsxs("p",{children:["有些信息必须是「此刻」的——当前分支、今天日期、最近几条提交。你可以让技能在被 Claude 看到之前，",e.jsx("strong",{children:"先执行一条命令、把它的输出替换进正文"}),"。写法是在正文里用行内代码标记一段命令， 并在命令后面加一个叹号 ",e.jsx("code",{children:"!"})," 作为「先执行我」的信号；除了行内形式，也有把整个代码块加叹号的多行形式。"]}),e.jsx("p",{children:"效果是：当这段正文准备进入上下文时，命令先跑一遍，Claude 真正读到的已经是命令的输出而非命令本身。 比如让技能正文里嵌一段「当前 git 状态」，它每次激活看到的都是最新的工作区情况。"}),e.jsx(s,{variant:"note",title:"本文如何表示这种语法",children:e.jsxs("p",{children:["这种「命令加叹号」的注入语法本身含有反引号，为避免和代码块冲突，本章一律用 ",e.jsx("code",{children:"行内代码"})," 或文字来描述它。 你在真正的 SKILL.md 里照官方语法书写即可：把命令包进行内代码、紧跟一个 ",e.jsx("code",{children:"!"})," 号。"]})}),e.jsx("h2",{children:"调用捆绑脚本：用 CLAUDE_SKILL_DIR 定位"}),e.jsxs("p",{children:["复杂逻辑（解析 PDF、跑数据处理、批量改文件）不该塞进正文，而该写成脚本放进技能的 ",e.jsx("code",{children:"scripts/"})," 目录， 正文里只负责「在什么情况下、怎么调用它」。难点在于：技能目录的绝对路径在不同机器上不一样。 为此系统提供了环境变量 ",e.jsx("code",{children:"CLAUDE_SKILL_DIR"}),"，它在技能激活时指向",e.jsx("strong",{children:"本技能所在目录"}),"， 用它拼路径就稳了："]}),e.jsx(l,{lang:"bash",title:"在正文里调用捆绑脚本",code:t}),e.jsxs("p",{children:["配合 ",e.jsx("code",{children:"allowed-tools"})," 里预批准 ",e.jsx("code",{children:"Bash(python:*)"})," 之类的命令，这条调用就能免确认直接跑。"]}),e.jsxs(o,{title:"脚本 + 注入的常见组合",children:[e.jsx("p",{children:"一个 PDF 抽取技能的正文往往长这样："}),e.jsxs("ul",{children:[e.jsx("li",{children:"开头用「命令加叹号」注入一句当前目录下的文件清单，让 Claude 知道有哪些 PDF 可处理；"}),e.jsxs("li",{children:["正文指令里写：调用 ",e.jsx("code",{children:"scripts/extract.py"})," 时用 ",e.jsx("code",{children:"CLAUDE_SKILL_DIR"})," 拼出脚本绝对路径；"]}),e.jsxs("li",{children:["把脚本的参数说明、异常排查这些长内容，丢进 ",e.jsx("code",{children:"reference/usage.md"}),"。"]})]})]}),e.jsx("h2",{children:"用 allowed-tools 预批准工具"}),e.jsxs("p",{children:["默认情况下，技能调用工具仍要逐次确认。把工具写进 ",e.jsx("code",{children:"allowed-tools"}),"，它们在该技能",e.jsx("strong",{children:"激活期间免确认"}),"。 可以列两类："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"内置工具（可带模式约束）"}),"——例如 ",e.jsx("code",{children:"Bash(git diff:*)"})," 只放行 ",e.jsx("code",{children:"git diff"})," 开头的命令， 范围越窄越安全。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"MCP 工具"}),"——直接写工具名即可，格式是 ",e.jsx("code",{children:"mcp__<server>__<tool>"}),"； 如果是 plugin 内的 MCP 服务器，格式为 ",e.jsx("code",{children:"mcp__plugin_<plugin>_<server>__<tool>"}),"。"]})]}),e.jsx(c,{title:"预批准要按最小权限来",children:e.jsxs("p",{children:[e.jsx("code",{children:"allowed-tools"})," 是在拿安全换便利，所以宁可写细。",e.jsx("strong",{children:"用模式约束把 Bash 收窄"}),"到具体命令前缀 （",e.jsx("code",{children:"Bash(git log:*)"})," 而不是放开整个 ",e.jsx("code",{children:"Bash"}),"），MCP 工具",e.jsx("strong",{children:"只列真正用得到的那几个"}),"。 需要禁止某些工具时还可以配 ",e.jsx("code",{children:"disallowed-tools"})," 反向兜底。"]})}),e.jsx(s,{variant:"warn",title:"项目级 skill 需要工作区信任",children:e.jsxs("p",{children:["放在项目里（随仓库分发）的技能，其 ",e.jsx("code",{children:"allowed-tools"})," 要生效，",e.jsx("strong",{children:"得先接受该工作区的信任"}),"。 这是一道防线：别人 clone 下来的仓库里若带着预批准了危险工具的技能，不会在你没点同意前就自动放行。"]})}),e.jsx("h2",{children:"合在一起：自动化 GitHub 流程"}),e.jsxs("p",{children:["把上面三招凑齐，就能做一个「拉取待审 PR、读 diff、写审查评论、归类」的自动化技能。 关键在 frontmatter 的 ",e.jsx("code",{children:"allowed-tools"})," 里列出要用到的 GitHub MCP 工具，让它们激活时免逐一确认："]}),e.jsx(l,{lang:"yaml",title:".claude/skills/pr-triage/SKILL.md",code:n}),e.jsxs("p",{children:["这里 ",e.jsx("code",{children:"mcp__github__*"})," 那几个就是 MCP 工具名，",e.jsx("code",{children:"Bash(git diff:*)"})," 则把 shell 收窄到只读的 diff 命令。 激活后，整套流程不再被确认打断，但越权的命令依然会被挡在外面。"]}),e.jsx("h2",{children:"这对实战意味着什么"}),e.jsxs("p",{children:["让技能「能动手」的本质，是把",e.jsx("strong",{children:"实时信息（注入）、复杂逻辑（脚本）、外部能力（工具）"}),"三者接进来， 同时用最小权限和工作区信任守住安全边界。真正高频自动化的技能，几乎都是这三件套的组合： 开头注入一点环境信息、中间调脚本干重活、全程靠预批准的工具丝滑联动。"]}),e.jsxs(d,{title:"写一个带 allowed-tools + 脚本/命令的 SKILL.md 片段",children:[e.jsx("p",{children:"做一个「生成今日站会摘要」的技能：注入今天的提交、调一个汇总脚本、预批准只读的 git 命令。"}),e.jsx(l,{lang:"yaml",title:".claude/skills/standup/SKILL.md",code:`---
name: standup
description: 汇总我今天的 Git 提交，生成站会用的工作摘要。当用户要写 standup、日报、今日进展时使用。
allowed-tools:
  - Bash(git log:*)
  - Bash(python:*)
---

# 生成今日站会摘要

（在正文开头，用「命令加叹号」的行内语法注入今天的提交，
 例如：今日提交 + git log --since=midnight --oneline + 叹号）

## 步骤
1. 阅读上面注入的今日提交列表
2. 调用汇总脚本做归类：
   python "$CLAUDE_SKILL_DIR/scripts/summarize.py"
3. 输出三段：昨天完成 / 今天计划 / 阻塞项`}),e.jsxs("p",{children:["自检：注入用对了「命令加叹号」语法吗？脚本路径用 ",e.jsx("code",{children:"CLAUDE_SKILL_DIR"})," 拼了吗？",e.jsx("code",{children:"allowed-tools"})," 是否只放行了 ",e.jsx("code",{children:"git log"})," 与 ",e.jsx("code",{children:"python"})," 这种最小范围？"]})]}),e.jsx(r,{points:["动态上下文注入：在正文里用「命令加叹号」的语法，让命令在 Claude 看到前先执行、用输出替换原文。","捆绑脚本放进 scripts/，正文用环境变量 CLAUDE_SKILL_DIR 拼出绝对路径来调用，跨机器都稳。","allowed-tools 让所列工具在技能激活期间免确认，可列内置工具（带模式约束）和 MCP 工具。","MCP 工具名格式 mcp__<server>__<tool>，plugin 内为 mcp__plugin_<plugin>_<server>__<tool>。","预批准按最小权限：用 Bash(cmd:*) 收窄命令、只列必要的 MCP 工具，必要时配 disallowed-tools。","项目级 skill 的 allowed-tools 需先接受工作区信任才生效，防止 clone 来的仓库自动放行危险工具。"]})]})}export{j as default};
