import{j as e}from"./index-DraKZMSn.js";import{L as n,S as o}from"./Summary-D7nqkGRf.js";import{K as t}from"./KeyIdea-C2HcfWY0.js";import{C as s}from"./Callout-BE-nWzIM.js";import{C as r}from"./CodeBlock-BiqAHAS8.js";import{E as i}from"./Example-yyME7alB.js";import{P as c}from"./Practice-Bq0moWPJ.js";import{P as d}from"./PyRunner-Dqs5MyKf.js";const l=`# 综合：try/except 捕获异常 + json 互转
import json

# Python 字典 -> JSON 字符串
data = {"name": "小明", "age": 18, "hobbies": ["篮球", "编程"]}
text = json.dumps(data, ensure_ascii=False)
print("JSON 字符串:", text)

# JSON 字符串 -> Python 字典
obj = json.loads(text)
print("名字:", obj["name"], "| 第一个爱好:", obj["hobbies"][0])

# 用 try/except 兜住可能的错误
def safe_get(d, key):
    try:
        return d[key]
    except KeyError:
        return f"(没有键 {key})"

print("city ->", safe_get(obj, "city"))

# 解析非法 JSON 也能优雅处理
try:
    json.loads("这不是合法的 JSON")
except json.JSONDecodeError as e:
    print("解析失败:", e.msg)`,a=`# 没有异常处理：一出错，程序直接崩溃停掉
num = int(input("输入一个整数："))   # 用户输入 "abc"
print(num * 2)`,x=`输入一个整数：abc
Traceback (most recent call last):
  File "demo.py", line 1, in <module>
    num = int(input("输入一个整数："))
ValueError: invalid literal for int() with base 10: 'abc'`,h=`try:
    num = int(input("输入一个整数："))
    print("它的两倍是", num * 2)
except ValueError:
    print("这不是一个整数，请重试！")`,j=`输入一个整数：abc
这不是一个整数，请重试！`,p=`try:
    age = int(input("年龄："))
    result = 100 // age          # 可能除以零
except ValueError:
    print("请输入数字")           # 转换失败时执行
except ZeroDivisionError:
    print("年龄不能为 0")          # 除零时执行
else:
    print("没出错，结果是", result)  # try 顺利跑完才执行
finally:
    print("无论如何都会执行（常用来收尾）")`,u=`# ValueError：值不对（比如把字母转成 int）
int("abc")

# KeyError：字典里没有这个键
{"a": 1}["b"]

# IndexError：列表越界
[1, 2, 3][10]

# FileNotFoundError：文件不存在
open("不存在.txt")

# TypeError：类型用错了
"abc" + 5`,y=`def set_age(age):
    if age < 0:
        raise ValueError("年龄不能为负数")   # 主动抛出异常
    return age

try:
    set_age(-5)
except ValueError as e:
    print("出错了：", e)`,m="出错了： 年龄不能为负数",g=`# 自定义异常：继承 Exception 即可
class NotEnoughMoneyError(Exception):
    pass

def withdraw(balance, amount):
    if amount > balance:
        raise NotEnoughMoneyError(f"余额不足：有 {balance}，想取 {amount}")
    return balance - amount

try:
    withdraw(100, 200)
except NotEnoughMoneyError as e:
    print(e)`,E="余额不足：有 100，想取 200",b=`import json

# Python 对象 -> JSON 字符串：dumps（dump string）
data = {"name": "小明", "age": 18, "hobbies": ["篮球", "编程"]}
text = json.dumps(data, ensure_ascii=False)   # ensure_ascii=False 保留中文
print(text)

# JSON 字符串 -> Python 对象：loads（load string）
obj = json.loads(text)
print(obj["name"], obj["hobbies"][0])`,f=`{"name": "小明", "age": 18, "hobbies": ["篮球", "编程"]}
小明 篮球`,N=`import json

data = {"name": "小红", "scores": [90, 85, 99]}

# 写 JSON 到文件：dump（注意没有 s）
with open("data.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

# 从文件读 JSON：load（注意没有 s）
with open("data.json", "r", encoding="utf-8") as f:
    obj = json.load(f)
print(obj["scores"])`,S="[90, 85, 99]",J=`{
  "name": "小红",
  "scores": [
    90,
    85,
    99
  ]
}`,O=`# 调用大模型 / 网络 API 时，请求和返回几乎都是 JSON
import json

# 你发出去的请求体（Python 字典 -> JSON）
payload = {
    "model": "qwen-plus",
    "messages": [{"role": "user", "content": "你好"}],
}
body = json.dumps(payload)

# 收到的回复（JSON 字符串 -> Python 字典，再取字段）
resp_text = '{"reply": "你好！有什么可以帮你？"}'
resp = json.loads(resp_text)
print(resp["reply"])`,P=`import json

def load_config(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"找不到 {path}，用默认配置")
        return {"theme": "light"}
    except json.JSONDecodeError:
        print(f"{path} 不是合法 JSON，用默认配置")
        return {"theme": "light"}

print(load_config("settings.json"))`;function v(){return e.jsxs("article",{children:[e.jsxs(n,{children:["程序运行时难免出错：用户输入了奇怪的东西、要读的文件不存在、网络断了…… 如果不管，程序就直接崩溃。这一章学",e.jsx("strong",{children:"异常处理"}),"，让程序遇到错误时优雅应对而不是死掉； 再学 ",e.jsx("strong",{children:"JSON"}),"——它是程序之间、尤其是和网络 API 打交道时交换数据的通用格式， 后面调用大模型 API 全靠它。"]}),e.jsx("h2",{children:"一、为什么需要异常处理"}),e.jsx("p",{children:"先看一段没有保护的代码。如果用户不输入数字，会发生什么？"}),e.jsx(r,{lang:"python",title:"没有保护的代码",code:a}),e.jsx(r,{lang:"text",title:"运行结果（崩溃）",code:x}),e.jsx("p",{children:"程序直接报错停掉，后面的代码再也没机会执行。在真实程序里这很糟糕—— 我们希望即使出错，程序也能给个友好提示、继续运行。这就是异常处理要解决的事。"}),e.jsx("h2",{children:"二、try-except：捕获错误"}),e.jsxs("p",{children:['把"可能出错"的代码放进 ',e.jsx("code",{children:"try"}),'，把"出错后怎么办"放进 ',e.jsx("code",{children:"except"}),"。"]}),e.jsx(r,{lang:"python",title:"用 try-except 兜住错误",code:h}),e.jsx(r,{lang:"text",title:"运行结果（不再崩溃）",code:j}),e.jsxs(t,{children:[e.jsx("code",{children:"try"})," 里的代码一旦出错，Python 立刻跳到 ",e.jsx("code",{children:"except"})," 去处理， 而不是让整个程序崩溃。处理完，程序继续往下走。"]}),e.jsx("h2",{children:"三、捕获具体的异常类型"}),e.jsxs("p",{children:['不同的错误有不同的"类型"（异常类）。最好',e.jsx("strong",{children:"按类型分别处理"}),"， 而不是笼统地抓所有错误——这样你才知道到底哪里出了问题。"]}),e.jsx(r,{lang:"python",title:"常见异常类型",code:u}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"异常"}),e.jsx("th",{children:"什么时候出现"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"ValueError"})}),e.jsxs("td",{children:["值不合法，如 ",e.jsx("code",{children:'int("abc")'})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"KeyError"})}),e.jsx("td",{children:"字典里没有要的键"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"IndexError"})}),e.jsx("td",{children:"列表 / 字符串下标越界"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"FileNotFoundError"})}),e.jsx("td",{children:"要打开的文件不存在"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"TypeError"})}),e.jsx("td",{children:"类型不匹配，如字符串加数字"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"ZeroDivisionError"})}),e.jsx("td",{children:"除以 0"})]})]})]}),e.jsxs(s,{variant:"warn",title:"别用裸 except",children:["直接写 ",e.jsx("code",{children:"except:"})," 会吞掉所有错误（包括你写错代码导致的 bug）， 让问题更难发现。尽量写明具体类型，如 ",e.jsx("code",{children:"except ValueError:"}),"。"]}),e.jsx("h2",{children:"四、完整结构：try-except-else-finally"}),e.jsx("p",{children:"除了 try 和 except，还有两个可选部分："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"else"}),"：",e.jsx("code",{children:"try"})," 没出错时执行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"finally"}),"：无论出不出错",e.jsx("strong",{children:"都会"}),"执行，常用来做收尾（关文件、断连接）。"]})]}),e.jsx(r,{lang:"python",title:"四件套",code:p}),e.jsx("h2",{children:"五、raise：主动抛出异常"}),e.jsxs("p",{children:["异常不只是 Python 抛给你——你也可以在自己的代码里用 ",e.jsx("code",{children:"raise"}),' 主动抛出， 告诉调用者"这个输入不对"。用 ',e.jsx("code",{children:"as e"})," 还能拿到异常对象，读出错误信息。"]}),e.jsx(r,{lang:"python",title:"用 raise 抛出异常",code:y}),e.jsx(r,{lang:"text",title:"运行结果",code:m}),e.jsx("h3",{children:"自定义异常"}),e.jsxs("p",{children:["内置异常不够用时，可以定义自己的异常类型——只要",e.jsx("strong",{children:"继承 Exception"})," 即可。 这样错误的含义更清晰。"]}),e.jsx(r,{lang:"python",title:"自定义异常",code:g}),e.jsx(r,{lang:"text",title:"运行结果",code:E}),e.jsxs(c,{title:"练一练",children:["写一个 ",e.jsx("code",{children:"safe_divide(a, b)"}),"，正常返回 ",e.jsx("code",{children:"a / b"}),"； 当 ",e.jsx("code",{children:"b"})," 为 0 时捕获 ",e.jsx("code",{children:"ZeroDivisionError"})," 并返回字符串 ",e.jsx("code",{children:'"不能除以零"'}),"。"]}),e.jsx("h2",{children:"六、JSON：和 API 打交道的通用语言"}),e.jsxs("p",{children:["JSON 是一种文本格式，长得很像 Python 的字典和列表。几乎所有网络 API （包括大模型 API）发送和接收的数据都是 JSON。Python 用内置 ",e.jsx("code",{children:"json"})," 模块处理它。"]}),e.jsxs(t,{children:["记住四个名字：",e.jsx("code",{children:"dumps"})," / ",e.jsx("code",{children:"loads"})," 处理",e.jsx("strong",{children:"字符串"}),"（带 s），",e.jsx("code",{children:"dump"})," / ",e.jsx("code",{children:"load"})," 处理",e.jsx("strong",{children:"文件"}),'（不带 s）。 "dump"= 把 Python 对象倒成 JSON，"load"= 把 JSON 装回 Python 对象。']}),e.jsx("h3",{children:"对象与字符串互转"}),e.jsx(r,{lang:"python",title:"dumps / loads",code:b}),e.jsx(r,{lang:"text",title:"运行结果",code:f}),e.jsxs(s,{variant:"tip",title:"中文别变 \\u",children:[e.jsx("code",{children:"json.dumps"})," 默认会把中文转成 ",e.jsx("code",{children:"\\uXXXX"})," 的形式。 加上 ",e.jsx("code",{children:"ensure_ascii=False"})," 就能保留原样的中文，更可读。"]}),e.jsx("h3",{children:"读写 JSON 文件"}),e.jsx(r,{lang:"python",title:"dump / load 配合文件",code:N}),e.jsx(r,{lang:"text",title:"运行结果",code:S}),e.jsxs("p",{children:[e.jsx("code",{children:"indent=2"})," 让写出的文件带缩进、更好看："]}),e.jsx(r,{lang:"json",title:"data.json 的内容",code:J}),e.jsx("h2",{children:"七、为什么这是 API 的基础"}),e.jsx("p",{children:"把异常处理和 JSON 放在一起讲不是巧合——它们是调用网络 API 的两块基石： 请求和回复都是 JSON，而网络请求又随时可能出错（断网、超时、返回格式不对）。"}),e.jsx(r,{lang:"python",title:"预览：API 交互就是 JSON 进出",code:O}),e.jsxs(i,{title:"健壮地读一个 JSON 配置文件",children:[e.jsx("p",{children:"真实程序里，读文件常常要同时防两种错：文件不存在、文件内容不是合法 JSON。"}),e.jsx(r,{lang:"python",title:"带异常处理的配置读取",code:P}),e.jsxs("p",{children:["这正是后面调用大模型 API 时反复出现的模式：",e.jsx("strong",{children:"把可能出错的网络 / 解析操作放进 try， 按类型处理失败"}),"，程序才不会因为一次意外就整个崩掉。"]})]}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」。"]}),e.jsx(d,{initialCode:l}),e.jsx(o,{points:["不处理异常，程序一出错就崩溃；用 try-except 把可能出错的代码兜住，出错后优雅应对。","按具体类型捕获：ValueError / KeyError / IndexError / FileNotFoundError / TypeError 等；别用裸 except 吞掉所有错误。","完整结构 try-except-else-finally：else 在没出错时跑，finally 无论如何都跑（用于收尾）。","用 raise 主动抛异常；继承 Exception 可定义自己的异常类型，用 except ... as e 拿到错误信息。","JSON 是 API 通信的通用格式：dumps/loads 处理字符串、dump/load 处理文件；中文加 ensure_ascii=False。","调用网络 / 大模型 API = 收发 JSON + 防错处理，这一章是后续 API 编程的基础。"]})]})}export{v as default};
