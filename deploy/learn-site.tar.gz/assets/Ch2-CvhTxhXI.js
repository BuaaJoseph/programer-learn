import{j as t}from"./index-DL563RIm.js";import{L as r,S as s}from"./Summary-BrgLcNDp.js";import{K as i}from"./KeyIdea-exK4GrdK.js";import{C as n}from"./Callout-B-8nslAm.js";import{C as e}from"./CodeBlock-DkVyd3P6.js";import{E as l}from"./Example-HxOmIesu.js";import{P as o}from"./Practice-r6liJb9j.js";import{P as c}from"./PyRunner-CEF0nuxG.js";const d=`# 综合：正则 re.findall / re.sub + 一点类型注解
import re
from typing import List

def extract_phones(text: str) -> List[str]:   # 类型注解
    return re.findall(r"\\d{11}", text)        # 找出所有 11 位数字

def mask_phones(text: str) -> str:
    return re.sub(r"\\d{11}", "***", text)     # 把手机号替换成 ***

msg = "联系电话 13800001234，备用 13912345678"
print("找到手机号:", extract_phones(msg))
print("脱敏后:", mask_phones(msg))

# 提取所有邮箱
emails = re.findall(r"\\w+@\\w+\\.\\w+", "客服 a@qq.com 或 b@163.com")
print("邮箱:", emails)`,a=`import re

text = "我的电话是 13800001234，备用 13912345678"

# match：只从开头匹配
print(re.match(r"\\d+", text))            # 开头是"我"，不是数字 -> None

# search：在整个字符串里找第一个匹配
m = re.search(r"\\d+", text)
print(m.group())                         # 找到的内容

# findall：找出所有匹配，返回列表
print(re.findall(r"\\d{11}", text))       # 所有 11 位数字

# sub：替换匹配到的内容
print(re.sub(r"\\d{11}", "***", text))    # 把手机号换成 ***`,x=`None
13800001234
['13800001234', '13912345678']
我的电话是 ***，备用 ***`,h=`import re

# . 任意字符   \\d 数字   \\w 字母数字下划线   \\s 空白
# +一个或多个  *零个或多个  ? 零个或一个  {n} 恰好n个
# ^ 开头   $ 结尾   [] 字符集   | 或

print(re.findall(r"\\w+@\\w+\\.\\w+", "联系 a@qq.com 或 b@163.com"))  # 邮箱
print(re.findall(r"[0-9]+", "房间 101 和 202"))                       # 连续数字
print(bool(re.match(r"^1\\d{10}$", "13800001234")))                  # 整串是手机号吗`,j=`['a@qq.com', 'b@163.com']
['101', '202']
True`,p=`# 类型注解：给参数和返回值标注"应该是什么类型"
def greet(name: str) -> str:        # 参数 name 是 str，返回 str
    return f"你好，{name}"

def add(a: int, b: int) -> int:     # 两个 int，返回 int
    return a + b

print(greet("小明"))
print(add(3, 4))`,m=`你好，小明
7`,u=`# 容器与可选类型：从 typing 导入（Python 3.9+ 也可直接用内置 list/dict）
from typing import Optional

def total(scores: list[int]) -> int:        # 一个由 int 组成的列表
    return sum(scores)

def get_age(info: dict[str, int]) -> int:   # 键是 str、值是 int 的字典
    return info["age"]

def find(name: str) -> Optional[str]:       # 返回 str 或 None
    users = {"小明": "北京"}
    return users.get(name)                   # 找不到返回 None

print(total([90, 85, 99]))
print(find("小红"))`,g=`274
None`,f=`# 注意：类型注解只是"标注"，Python 不会强制检查！
def add(a: int, b: int) -> int:
    return a + b

print(add("你", "好"))   # 照样能跑，输出"你好"——注解只是给人和工具看的提示`,y="你好",b=`nums = [3, 1, 4, 1, 5, 9, 2, 6]

print(len(nums))            # 元素个数
print(sum(nums))            # 求和
print(max(nums), min(nums)) # 最大、最小
print(sorted(nums))         # 排序（返回新列表）
print(any(x > 8 for x in nums))   # 有没有大于 8 的
print(all(x > 0 for x in nums))   # 是不是全大于 0`,C=`8
31
9 1
[1, 1, 2, 3, 4, 5, 6, 9]
True
True`,w=`names = ["小明", "小红", "小刚"]
scores = [90, 85, 99]

# zip：把多个列表"拉链"配对
for name, score in zip(names, scores):
    print(name, score)

print("---")

# enumerate：遍历时同时拿到下标
for i, name in enumerate(names, start=1):
    print(i, name)`,P=`小明 90
小红 85
小刚 99
---
1 小明
2 小红
3 小刚`,R=`from collections import Counter, defaultdict

# Counter：统计出现次数，超方便
words = ["苹果", "香蕉", "苹果", "苹果", "香蕉"]
print(Counter(words))
print(Counter(words).most_common(1))   # 出现最多的

# defaultdict：访问不存在的键时给个默认值，不报 KeyError
groups = defaultdict(list)
groups["水果"].append("苹果")           # 不用先建空列表
print(dict(groups))`,N=`Counter({'苹果': 3, '香蕉': 2})
[('苹果', 3)]
{'水果': ['苹果']}`,z=`import itertools

# 把多个列表首尾相连
print(list(itertools.chain([1, 2], [3, 4])))

# 累计求和
print(list(itertools.accumulate([1, 2, 3, 4])))

# 两两组合
print(list(itertools.combinations(["A", "B", "C"], 2)))`,B=`[1, 2, 3, 4]
[1, 3, 6, 10]
[('A', 'B'), ('A', 'C'), ('B', 'C')]`;function K(){return t.jsxs("article",{children:[t.jsxs(r,{children:['这一章是一组"日常高频工具"的合集：用',t.jsx("strong",{children:"正则表达式"}),"从文本里精准提取信息； 用",t.jsx("strong",{children:"类型注解"}),"给代码加上类型说明、让它更易读易维护；复习一批",t.jsx("strong",{children:"常用内置函数"}),"；最后逛一逛 Python 自带的几个",t.jsx("strong",{children:"好用标准库"}),"。 它们不一定每个都天天用，但认识了，写起代码来会顺手很多。"]}),t.jsx("h2",{children:"一、正则表达式 re：在文本里找规律"}),t.jsxs("p",{children:['正则表达式是一种"描述文本规律"的小语言。比如"11 位连续数字"就是手机号的规律。 Python 用内置 ',t.jsx("code",{children:"re"})," 模块来用它。先看四个核心函数："]}),t.jsx(e,{lang:"python",title:"match / search / findall / sub",code:a}),t.jsx(e,{lang:"text",title:"运行结果",code:x}),t.jsxs("table",{children:[t.jsx("thead",{children:t.jsxs("tr",{children:[t.jsx("th",{children:"函数"}),t.jsx("th",{children:"作用"})]})}),t.jsxs("tbody",{children:[t.jsxs("tr",{children:[t.jsx("td",{children:t.jsx("code",{children:"re.match"})}),t.jsxs("td",{children:["只从字符串",t.jsx("strong",{children:"开头"}),"匹配"]})]}),t.jsxs("tr",{children:[t.jsx("td",{children:t.jsx("code",{children:"re.search"})}),t.jsxs("td",{children:["在整个字符串里找",t.jsx("strong",{children:"第一个"}),"匹配"]})]}),t.jsxs("tr",{children:[t.jsx("td",{children:t.jsx("code",{children:"re.findall"})}),t.jsxs("td",{children:["找出",t.jsx("strong",{children:"所有"}),"匹配，返回列表"]})]}),t.jsxs("tr",{children:[t.jsx("td",{children:t.jsx("code",{children:"re.sub"})}),t.jsxs("td",{children:[t.jsx("strong",{children:"替换"}),"匹配到的内容"]})]})]})]}),t.jsx("h3",{children:"常用元字符"}),t.jsx("p",{children:'正则的"规律"由元字符拼出来。下面是最常用的一批：'}),t.jsx(e,{lang:"python",title:"常用元字符示例",code:h}),t.jsx(e,{lang:"text",title:"运行结果",code:j}),t.jsxs(n,{variant:"tip",title:"为什么字符串前面加 r",children:["正则里有很多反斜杠（如 ",t.jsx("code",{children:"\\d"}),"）。写成 ",t.jsx("code",{children:'r"\\\\d+"'})," 这样的",t.jsx("strong",{children:"原始字符串"}),"，反斜杠就不会被 Python 当转义符处理，省去重复转义的麻烦。"]}),t.jsx("h2",{children:"二、类型注解：给代码加说明"}),t.jsx("p",{children:'类型注解是给参数和返回值标注"应该是什么类型"的语法。它让代码更易读， 也让编辑器能帮你检查错误、自动补全。'}),t.jsx(e,{lang:"python",title:"基本类型注解",code:p}),t.jsx(e,{lang:"text",title:"运行结果",code:m}),t.jsx("h3",{children:"容器与 Optional"}),t.jsxs("p",{children:["列表、字典也能标注里面装什么；",t.jsx("code",{children:"Optional[X]"}),' 表示"是 X 或者 None"。']}),t.jsx(e,{lang:"python",title:"list / dict / Optional",code:u}),t.jsx(e,{lang:"text",title:"运行结果",code:g}),t.jsxs(i,{children:[t.jsx("code",{children:"Optional[str]"}),' 等价于"',t.jsx("code",{children:"str"})," 或 ",t.jsx("code",{children:"None"}),'"。 函数可能返回 None（如查不到）时，用它标注最清楚。']}),t.jsxs(n,{variant:"warn",title:"注解不会强制检查",children:["类型注解只是",t.jsx("strong",{children:"给人和工具看的提示"}),"，Python 运行时",t.jsx("strong",{children:"不会"}),"因为类型不符而报错。它的价值在可读性和工具支持，不是运行时约束。"]}),t.jsx(e,{lang:"python",title:"注解不会拦住你",code:f}),t.jsx(e,{lang:"text",title:"运行结果",code:y}),t.jsxs("p",{children:[t.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」。"]}),t.jsx(c,{initialCode:d}),t.jsx("h2",{children:"三、常用内置函数"}),t.jsx("p",{children:"这些函数不用 import，直接就能用，处理列表 / 序列时极其顺手。"}),t.jsx(e,{lang:"python",title:"len/sum/max/min/sorted/any/all",code:b}),t.jsx(e,{lang:"text",title:"运行结果",code:C}),t.jsx("h3",{children:"zip 与 enumerate"}),t.jsxs("p",{children:[t.jsx("code",{children:"zip"})," 把多个列表配对，",t.jsx("code",{children:"enumerate"})," 在遍历时附带下标—— 这两个在 ",t.jsx("code",{children:"for"})," 循环里出镜率极高。"]}),t.jsx(e,{lang:"python",title:"zip 配对 / enumerate 带下标",code:w}),t.jsx(e,{lang:"text",title:"运行结果",code:P}),t.jsxs(o,{title:"练一练",children:["给定 ",t.jsx("code",{children:'names = ["A", "B", "C"]'})," 和 ",t.jsx("code",{children:"ages = [20, 19, 21]"}),"， 用 ",t.jsx("code",{children:"zip"})," 配对，找出年龄最大的人的名字（提示：可配合 ",t.jsx("code",{children:"max"})," 的 ",t.jsx("code",{children:"key"})," 参数）。"]}),t.jsx("h2",{children:"四、好用的标准库一览"}),t.jsx("h3",{children:"collections：更趁手的容器"}),t.jsxs("p",{children:[t.jsx("code",{children:"Counter"})," 统计次数、",t.jsx("code",{children:"defaultdict"})," 给字典设默认值，两个救命神器。"]}),t.jsx(e,{lang:"python",title:"Counter 与 defaultdict",code:R}),t.jsx(e,{lang:"text",title:"运行结果",code:N}),t.jsx("h3",{children:"itertools：迭代工具箱"}),t.jsxs("p",{children:[t.jsx("code",{children:"itertools"})," 提供一堆高效的迭代工具，配合上一章的生成器思想很搭。"]}),t.jsx(e,{lang:"python",title:"chain / accumulate / combinations",code:z}),t.jsx(e,{lang:"text",title:"运行结果",code:B}),t.jsx("h3",{children:"pathlib：现代路径处理"}),t.jsxs("p",{children:["前面讲文件时见过它。",t.jsx("code",{children:"pathlib.Path"})," 用 ",t.jsx("code",{children:"/"})," 拼路径、能直接读写、 判断存在，是处理文件路径的现代首选。"]}),t.jsx(l,{title:"标准库速查",children:t.jsxs("ul",{children:[t.jsxs("li",{children:[t.jsx("strong",{children:"collections"}),"：Counter（计数）、defaultdict（带默认值的字典）、deque（双端队列）。"]}),t.jsxs("li",{children:[t.jsx("strong",{children:"itertools"}),"：chain、accumulate、combinations、product 等迭代工具。"]}),t.jsxs("li",{children:[t.jsx("strong",{children:"pathlib"}),"：面向对象的路径操作，读写 / 拼接 / 判断一把抓。"]}),t.jsxs("li",{children:[t.jsx("strong",{children:"json"}),"（前面学过）、",t.jsx("strong",{children:"datetime"}),"（日期时间）、",t.jsx("strong",{children:"random"}),"（随机数）也都是高频常客。"]})]})}),t.jsx(n,{variant:"tip",title:"不用全记",children:'标准库非常庞大，没人能背全。记住"遇到某类问题，标准库里大概率有现成的"， 需要时去查官方文档即可。会查，比死记更重要。'}),t.jsx(s,{points:["正则 re 四大函数：match（开头匹配）、search（找第一个）、findall（找全部）、sub（替换）。",'常用元字符：\\d 数字、\\w 字母数字、. 任意、+ 一或多、{n} 恰好n个、^ $ 头尾、[] 字符集、| 或；正则串用 r"..." 原始字符串。',"类型注解给参数 / 返回值标类型（如 def f(x: int) -> str），容器用 list[int]/dict[str,int]，可空用 Optional[X]；注解只是提示，不强制检查。","内置函数高频：len/sum/max/min/sorted/any/all，加 zip（配对）、enumerate（带下标）。","collections 的 Counter / defaultdict、itertools 的迭代工具、pathlib 的路径处理都很实用。",'标准库庞大，重点是"知道有、会去查"，不必死记。']})]})}export{K as default};
