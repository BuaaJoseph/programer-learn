import{j as e}from"./index-CNCQ9D3g.js";import{L as r,S as n}from"./Summary-B81QYNtK.js";import{K as d}from"./KeyIdea-CJu1AmJK.js";import{C as s}from"./Callout-DBjCLF-u.js";import{C as c}from"./CodeBlock-B4ANG3D_.js";import{E as l}from"./Example-C7EXHAW5.js";const i=`// 你写的 JSX
const el = <h1 className="t">Hi</h1>

// 编译后（经典 React.createElement 转换）
const el = React.createElement('h1', { className: 't' }, 'Hi')`,t=`// React.createElement 返回的，其实是一个普通的 JS 对象
const el = {
  $$typeof: Symbol.for('react.element'),
  type: 'h1',                 // 标签名字符串，或组件函数 / 类
  key: null,                  // 列表里用来标识身份
  ref: null,
  props: {                    // 所有属性 + children 都塞进 props
    className: 't',
    children: 'Hi',
  },
}`,h=`// React 17+ 的「新 JSX 转换」：不再依赖作用域里的 React
// 编译器自动从 react/jsx-runtime 引入 jsx / jsxs
import { jsx as _jsx } from 'react/jsx-runtime'

const el = _jsx('h1', { className: 't', children: 'Hi' })

// 多个 children 时用 jsxs（s = static array）
import { jsxs as _jsxs } from 'react/jsx-runtime'
const list = _jsxs('ul', { children: [_jsx('li', { children: 'a' }), _jsx('li', { children: 'b' })] })`,x=`// 嵌套 JSX
const tree = (
  <section className="box">
    <h2>标题</h2>
    <p>正文</p>
  </section>
)

// 编译后：children 从外到内层层嵌套的 createElement 调用
const tree = React.createElement(
  'section',
  { className: 'box' },
  React.createElement('h2', null, '标题'),
  React.createElement('p', null, '正文'),
)`,o=`// 首字母大写 = 组件，编译时 type 是函数本身（不是字符串）
function Card({ title }) {
  return <div className="card">{title}</div>
}

const used = <Card title="Hello" />
// 编译后：
const used = React.createElement(Card, { title: 'Hello' })
//                                ^^^^ 传的是函数引用，不是 'Card' 字符串`,j=`// 不想多包一层 DOM 节点时用 Fragment
function Row() {
  return (
    <>
      <td>姓名</td>
      <td>年龄</td>
    </>
  )
}
// <>...</> 编译成 React.createElement(React.Fragment, null, ...)`,a=`const name = '小明'
const age = 18
const user = { city: '杭州' }

const el = (
  <p>
    {name}今年{age}岁，来自{user.city}。
    {/* 这是 JSX 注释，也是用大括号包起来的表达式 */}
    {1 + 1 === 2 ? '加法正常' : '世界崩了'}
  </p>
)`,m=`const fruits = ['苹果', '香蕉', '橘子']

const list = (
  <ul>
    {fruits.map((fruit, i) => (
      <li key={i}>{fruit}</li>
    ))}
  </ul>
)
// map 返回一个元素数组，React 直接接受数组作为 children`,p=`const isLoggedIn = true
const count = 3

const view = (
  <div>
    {/* 逻辑与：左边为真才渲染右边；为假渲染 false（不显示） */}
    {isLoggedIn && <span>欢迎回来</span>}

    {/* 三元：二选一 */}
    {count > 0 ? <p>有 {count} 条消息</p> : <p>没有新消息</p>}
  </div>
)`,S=`// 这样写会报错：if 是语句，不能放进大括号
// <div>{ if (x) { ... } }</div>   // SyntaxError

// 正确做法 1：在 JSX 之外用 if 算好，再插值
let label
if (count > 0) label = '有消息'
else label = '空'
const ok = <div>{label}</div>`;function y(){return e.jsxs("article",{children:[e.jsxs(r,{children:["很多人写了很久 React，脑子里还把 JSX 当成「一种 HTML 模板」或「一段会被替换的字符串」。 这是误会。JSX 既不是字符串，也不是 HTML，它是 JavaScript 的",e.jsx("strong",{children:"语法糖"}),"—— 在送进浏览器之前，构建工具会把它编译成一串普通的函数调用，调用的结果是一个普通的 JS 对象。 这一章我们把这层糖剥开，看清你写的每一段尖括号最后变成了什么，并把 JSX 的所有书写规则 逐条讲透。理解了「它编译成什么」，后面所有看似奇怪的规则都会变得理所当然。"]}),e.jsx("h2",{children:"一、JSX 不是 HTML，是 JavaScript 表达式"}),e.jsxs("p",{children:["先纠正三个最常见的错误印象。第一，JSX 不是字符串——它没有引号包着，你也不能直接把它 拼接、截取。第二，JSX 不是 HTML——它长得像 HTML，但属性名、事件、注释的写法都不一样， 因为它最终要变成 JS。第三，浏览器",e.jsx("strong",{children:"看不懂"})," JSX——浏览器只认识 JavaScript， 所以 JSX 必须先经过 Babel（或 SWC、esbuild、TypeScript 编译器）这类工具转译成普通 JS 才能运行。"]}),e.jsxs(d,{children:["JSX 是一段会被编译的语法糖。每一个 ",e.jsx("code",{children:"<标签>"})," 最终都会被翻译成一次函数调用， 这个函数（旧式是 ",e.jsx("code",{children:"React.createElement"}),"，新式是 ",e.jsx("code",{children:"jsx()"}),"）返回一个描述 UI 的普通对象——React Element。你写的是「长得像标签的 JS」，运行的是「对象」。"]}),e.jsxs("p",{children:["既然 JSX 是 JS 表达式，它就遵循表达式的一切规则：可以赋值给变量、可以作为函数参数、 可以从函数里 ",e.jsx("code",{children:"return"}),"、可以放进数组。下面这点尤其重要——既然一段 JSX 求值后 是一个对象，那它当然能被存进变量："]}),e.jsx(c,{lang:"jsx",title:"JSX 就是一个能赋值的表达式",code:i}),e.jsx("h2",{children:"二、编译成什么：createElement 调用"}),e.jsxs("p",{children:["看上面那段对比的下半部分。",e.jsx("code",{children:'<h1 className="t">Hi</h1>'})," 被编译成了",e.jsx("code",{children:"React.createElement('h1', { className: 't' }, 'Hi')"}),"。三个参数分别是："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"第一个参数 type"}),"：标签名（普通 HTML 标签是字符串 ",e.jsx("code",{children:"'h1'"}),"）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"第二个参数 props"}),"：一个对象，装着所有属性，比如 ",e.jsx("code",{children:"{ className: 't' }"}),"；没有属性时是 ",e.jsx("code",{children:"null"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"第三个及以后的参数"}),"：children（子节点），这里是文本 ",e.jsx("code",{children:"'Hi'"}),"。"]})]}),e.jsxs(s,{variant:"note",title:"为什么是 className 而不是 class",children:["因为编译后是 JavaScript，而 ",e.jsx("code",{children:"class"})," 在 JS 里是保留关键字（用来声明类）。 为了不冲突，React 用 ",e.jsx("code",{children:"className"})," 代替。同理，HTML 的 ",e.jsx("code",{children:"for"})," 属性 （label 关联表单控件用）在 JSX 里写成 ",e.jsx("code",{children:"htmlFor"}),"，因为 ",e.jsx("code",{children:"for"})," 也是 JS 的循环关键字。这些不是 React 故意为难你，而是「它最终是 JS」这一事实的必然结果。"]}),e.jsx("h2",{children:"三、createElement 返回什么：一个普通对象"}),e.jsxs("p",{children:["关键中的关键：",e.jsx("code",{children:"React.createElement(...)"})," 并不会创建任何真实的 DOM 节点， 它只是返回一个轻量的普通 JavaScript 对象，这个对象叫 ",e.jsx("strong",{children:"React Element"}),"。 它就是对「我想要长成什么样」的一份描述（descriptor），是一张蓝图，不是房子本身。"]}),e.jsx(c,{lang:"js",title:"React Element 的真面目",code:t}),e.jsxs("p",{children:["注意三个字段：",e.jsx("code",{children:"type"})," 记录这是什么（标签名或组件），",e.jsx("code",{children:"props"})," 装着 所有属性",e.jsx("strong",{children:"以及 children"}),"（是的，子节点最后也被收进了 props.children），",e.jsx("code",{children:"key"})," 在列表渲染里标识元素身份。React 拿到这些对象组成的树后，才去对比、计算、 最终操作真实 DOM。这就是「声明式」的物理基础：你只负责描述「要什么」，渲染交给 React。"]}),e.jsx(l,{title:"嵌套 JSX 怎么编译",children:e.jsxs("p",{children:["嵌套结构会编译成层层嵌套的 ",e.jsx("code",{children:"createElement"})," 调用，外层的 children 参数 就是内层调用的返回值。一棵 JSX 树，对应一棵 Element 对象树。"]})}),e.jsx(c,{lang:"jsx",title:"嵌套结构层层编译",code:x}),e.jsx("h2",{children:"四、新 JSX 转换：jsx() 调用"}),e.jsxs("p",{children:["上面讲的是经典转换。从 React 17 起，官方推出了",e.jsx("strong",{children:"新 JSX 转换（new JSX transform）"}),"。 差别在于：经典转换要求你的文件作用域里必须有 ",e.jsx("code",{children:"React"})," 这个变量（所以老代码顶部 总要写 ",e.jsx("code",{children:"import React from 'react'"}),"），否则编译出的 ",e.jsx("code",{children:"React.createElement"}),"会找不到 ",e.jsx("code",{children:"React"}),"。新转换则让编译器",e.jsx("strong",{children:"自动"}),"从 ",e.jsx("code",{children:"react/jsx-runtime"}),"引入 ",e.jsx("code",{children:"jsx"})," / ",e.jsx("code",{children:"jsxs"})," 函数，于是你不必再手动 import React。"]}),e.jsx(c,{lang:"js",title:"新转换：编译成 jsx() / jsxs()",code:h}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"经典转换"}),e.jsx("th",{children:"新转换（React 17+）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"编译成"}),e.jsx("td",{children:e.jsx("code",{children:"React.createElement(...)"})}),e.jsxs("td",{children:[e.jsx("code",{children:"jsx(...)"})," / ",e.jsx("code",{children:"jsxs(...)"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"来源"}),e.jsxs("td",{children:["依赖作用域里的 ",e.jsx("code",{children:"React"})]}),e.jsxs("td",{children:["编译器自动从 ",e.jsx("code",{children:"react/jsx-runtime"})," 引入"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"需手动 import React"}),e.jsx("td",{children:"需要"}),e.jsx("td",{children:"不需要"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"children 传法"}),e.jsx("td",{children:"作为第三个及以后的参数"}),e.jsxs("td",{children:["放进 props 的 ",e.jsx("code",{children:"children"})," 字段"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"返回值"}),e.jsx("td",{colSpan:2,children:"都是 React Element 普通对象，本质一致"})]})]})]}),e.jsxs(s,{variant:"tip",title:"两者结果一样",children:["无论经典还是新转换，最终拿到的都是同一种 React Element 对象。新转换只是省掉了样板 import、并对多 children 场景（",e.jsx("code",{children:"jsxs"}),"）做了点优化。理解时可以统一记成： 「JSX 编译成创建 Element 的函数调用」。"]}),e.jsx("h2",{children:"五、组件 vs 标签：大小写决定 type 是什么"}),e.jsxs("p",{children:["JSX 有一条铁规则：",e.jsx("strong",{children:"首字母小写"}),"的标签被当作普通 HTML 元素，编译时 type 是 字符串（如 ",e.jsx("code",{children:"'div'"}),"）；",e.jsx("strong",{children:"首字母大写"}),"的标签被当作组件，编译时 type 是那个函数 / 类的",e.jsx("strong",{children:"引用本身"}),"。这就是为什么自定义组件必须大写开头——否则 React 会把 ",e.jsx("code",{children:"<card />"})," 当成一个它不认识的 HTML 标签 ",e.jsx("code",{children:"'card'"}),"，而不是你的组件。"]}),e.jsx(c,{lang:"jsx",title:"大写组件：type 是函数引用",code:o}),e.jsx("h2",{children:"六、JSX 的书写规则逐条讲"}),e.jsx("h3",{children:"1. 单一根节点 / Fragment"}),e.jsxs("p",{children:["一段 JSX 表达式只能返回",e.jsx("strong",{children:"一个"}),"根节点。原因还是编译：函数只能 ",e.jsx("code",{children:"return"}),"一个值，",e.jsx("code",{children:"return"})," 两个并列的 ",e.jsx("code",{children:"<div>"})," 就像 ",e.jsx("code",{children:"return 1 2"}),"一样不合法。要并列多个元素又不想多包一层真实 DOM，用 ",e.jsx("strong",{children:"Fragment"}),"：写成空标签",e.jsx("code",{children:"<>...</>"}),"，它编译成 ",e.jsx("code",{children:"React.Fragment"}),"，不产生额外 DOM 节点。"]}),e.jsx(c,{lang:"jsx",title:"用 Fragment 包裹并列元素",code:j}),e.jsx("h3",{children:"2. className 与 htmlFor"}),e.jsxs("p",{children:["如第二节所述，因为 JS 关键字冲突，",e.jsx("code",{children:"class"})," 写成 ",e.jsx("code",{children:"className"}),"，",e.jsx("code",{children:"for"})," 写成 ",e.jsx("code",{children:"htmlFor"}),"。这是最常被新手踩的两个坑。"]}),e.jsx("h3",{children:"3. 属性与事件用驼峰命名"}),e.jsxs("p",{children:["DOM 事件在 JSX 里一律驼峰：HTML 的 ",e.jsx("code",{children:"onclick"})," 写成 ",e.jsx("code",{children:"onClick"}),"，",e.jsx("code",{children:"onchange"})," 写成 ",e.jsx("code",{children:"onChange"}),"，",e.jsx("code",{children:"onmouseover"})," 写成",e.jsx("code",{children:"onMouseOver"}),"。而且事件值是一个",e.jsx("strong",{children:"函数"}),"，不是字符串：写",e.jsx("code",{children:"onClick={handleClick}"}),"，不是 ",e.jsx("code",{children:'onclick="handleClick()"'}),"。 其他多词属性同理走驼峰，如 ",e.jsx("code",{children:"tabIndex"}),"、",e.jsx("code",{children:"readOnly"}),"。"]}),e.jsx("h3",{children:"4. 大括号插值"}),e.jsxs("p",{children:["在 JSX 里用一对大括号 ",e.jsx("code",{children:"{ }"})," 嵌入 JavaScript ",e.jsx("strong",{children:"表达式"}),"： 变量、运算、函数调用、三元、属性访问都行。文本位置可以插，属性值也可以插 （",e.jsx("code",{children:"<img src={url} />"}),"）。注释也是用大括号包一个块注释：",e.jsx("code",{children:"{/* 注释 */}"}),"。"]}),e.jsx(c,{lang:"jsx",title:"大括号里放各种表达式",code:a}),e.jsx("h3",{children:"5. 列表渲染与 key"}),e.jsxs("p",{children:["渲染一组数据用数组的 ",e.jsx("code",{children:"map"}),"，把每项映射成一个元素，返回的元素数组可以直接当 children。每个列表项必须带一个",e.jsx("strong",{children:"稳定且唯一"}),"的 ",e.jsx("code",{children:"key"}),"，React 靠它 在数据变化时识别「哪个是哪个」，从而高效地复用、移动、删除节点。能用数据里的稳定 id 就 用 id；用数组下标 ",e.jsx("code",{children:"i"})," 作 key 只在列表顺序永不变化时勉强可以。"]}),e.jsx(c,{lang:"jsx",title:"map + key 渲染列表",code:m}),e.jsxs(s,{variant:"warn",title:"key 不是普通属性",children:[e.jsx("code",{children:"key"})," 是 React 内部使用的特殊标识，",e.jsx("strong",{children:"不会"}),"作为普通 prop 传进 子组件。子组件里读 ",e.jsx("code",{children:"props.key"})," 是读不到的。它纯粹用于协调（reconciliation）阶段 的身份比对。用错（比如用会变化的随机数或永远递增的值当 key）会导致组件状态错乱、性能下降。"]}),e.jsx("h3",{children:"6. 条件渲染"}),e.jsxs("p",{children:["JSX 里没有 ",e.jsx("code",{children:"if"})," 语句的位置（见下一节），条件渲染靠两种",e.jsx("strong",{children:"表达式"}),"： 逻辑与 ",e.jsx("code",{children:"&&"})," 和三元 ",e.jsx("code",{children:"? :"}),"。",e.jsx("code",{children:"cond && <X/>"}),"表示「cond 为真才渲染 X」；",e.jsx("code",{children:"cond ? <A/> : <B/>"})," 表示二选一。"]}),e.jsx(c,{lang:"jsx",title:"&& 与三元做条件渲染",code:p}),e.jsxs(s,{variant:"warn",title:"&& 的数字陷阱",children:[e.jsx("code",{children:"cond && <X/>"})," 里，如果 ",e.jsx("code",{children:"cond"})," 求值成数字 ",e.jsx("code",{children:"0"}),"， React 会把 ",e.jsx("code",{children:"0"})," 渲染出来（屏幕上冒出一个 0），而不是什么都不显示。 因为 ",e.jsx("code",{children:"0"})," 是假值，",e.jsx("code",{children:"&&"})," 直接返回 ",e.jsx("code",{children:"0"}),"，而 React 会渲染数字。 所以写 ",e.jsx("code",{children:"list.length && <List/>"})," 要改成",e.jsx("code",{children:"list.length > 0 && <List/>"}),"，让左边是布尔值。"]}),e.jsx("h3",{children:"7. 自闭合标签"}),e.jsxs("p",{children:["没有子节点的标签必须自闭合，结尾带斜杠：",e.jsx("code",{children:"<img />"}),"、",e.jsx("code",{children:"<br />"}),"、",e.jsx("code",{children:"<input />"}),"、",e.jsx("code",{children:"<MyComponent />"}),"。这比 HTML 严格——HTML 里",e.jsx("code",{children:"<br>"})," 不写斜杠也行，JSX 里不写会报错，因为它要被解析成合法的 JS。"]}),e.jsx("h2",{children:"七、为什么大括号里只能放表达式，不能放语句"}),e.jsxs("p",{children:["这是 JSX 最让初学者困惑的限制之一。答案还是回到编译：大括号里的内容最后会成为",e.jsx("code",{children:"createElement"})," 的",e.jsx("strong",{children:"参数"}),"，或者拼进字符串模板般的位置——而参数 必须是一个",e.jsx("strong",{children:"有值"}),"的东西，也就是表达式（expression）。",e.jsx("code",{children:"if"}),"、",e.jsx("code",{children:"for"}),"、",e.jsx("code",{children:"while"}),"、",e.jsx("code",{children:"switch"})," 是",e.jsx("strong",{children:"语句"}),"（statement）， 它们",e.jsx("strong",{children:"不产生值"}),"，没法作为参数传进去，所以不能直接放进大括号。"]}),e.jsxs("p",{children:["区分口诀：",e.jsx("strong",{children:"能被赋值给变量的就是表达式，不能的就是语句。"}),e.jsx("code",{children:"a > b ? 1 : 2"})," 能赋值（三元是表达式），",e.jsx("code",{children:"arr.map(...)"})," 能赋值 （函数调用是表达式），所以它们能进大括号。而 ",e.jsx("code",{children:"if (x) {}"})," 不能赋值， 所以不能进。解决办法：把语句移到 JSX 之外算好，或者把 ",e.jsx("code",{children:"if"})," 改写成等价的三元 /",e.jsx("code",{children:"&&"})," 表达式。"]}),e.jsx(c,{lang:"jsx",title:"语句要挪到 JSX 外面",code:S}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"能放进大括号（表达式）"}),e.jsx("th",{children:"不能放（语句）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsxs("td",{children:["变量 ",e.jsx("code",{children:"name"})]}),e.jsx("td",{children:e.jsx("code",{children:"if / else"})})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["运算 ",e.jsx("code",{children:"a + b"})]}),e.jsx("td",{children:e.jsx("code",{children:"for / while"})})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["三元 ",e.jsx("code",{children:"a ? b : c"})]}),e.jsx("td",{children:e.jsx("code",{children:"switch"})})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["逻辑 ",e.jsx("code",{children:"a && b"})]}),e.jsxs("td",{children:["变量声明 ",e.jsx("code",{children:"const x = 1"})]})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["函数调用 ",e.jsx("code",{children:"arr.map(fn)"})]}),e.jsx("td",{children:e.jsx("code",{children:"return"})})]})]})]}),e.jsx(s,{variant:"tip",children:"下一章我们从「单个元素长什么样」走到「组件怎么组合」：讲 Props 如何自上而下流动、 组件如何接收和组合数据、以及「数据向下、事件向上」的经典模式。带着本章的认知去看—— 组件不过是「返回 Element 树的函数」，Props 不过是传给那个函数的参数。"}),e.jsx(n,{points:["JSX 不是字符串也不是 HTML，而是 JavaScript 的语法糖，浏览器看不懂，必须先经 Babel/SWC 等编译成普通 JS。","每个标签都被编译成一次函数调用：经典转换是 React.createElement(type, props, ...children)，新转换（React 17+）是自动引入的 jsx()/jsxs()。","调用返回的是 React Element——一个普通 JS 对象 { type, props, key }，是 UI 的描述（蓝图），不是真实 DOM。","小写标签 type 为字符串（HTML 元素），大写标签 type 为函数/类引用（组件），所以自定义组件必须大写开头。","书写规则源于「最终是 JS」：单一根节点/Fragment、className 与 htmlFor、驼峰事件、大括号插值、map+key 列表、&& 与三元条件、自闭合标签。","大括号里只能放表达式不能放语句，因为内容要成为函数参数（必须有值）；if/for/switch 不产生值，要挪到 JSX 外或改写成三元/&&。"]})]})}export{y as default};
