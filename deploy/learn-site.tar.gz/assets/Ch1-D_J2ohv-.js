import{j as e}from"./index-D-xLQIFq.js";import{L as r,S as c}from"./Summary-YJHOQU45.js";import{K as s}from"./KeyIdea-D9fwNcvs.js";import{C as i}from"./Callout-Bp0vMJus.js";import{C as t}from"./CodeBlock-DX_K20PW.js";import{E as n}from"./Example-JUHxJgjQ.js";import{P as d}from"./Practice-Cvuj-BXK.js";import{P as l}from"./PyRunner-BxuLdg2A.js";const x=`# 变量、运算、类型
price = 100        # 整数 int
discount = 0.8     # 小数 float
final = price * discount
print("打折后价格：", final)

# type() 查看类型
print(type(price))
print(type(discount))
print(type(final))

# 类型转换：字符串 → 整数
qty_str = "3"
qty = int(qty_str)
print(f"买 {qty} 件，共需 {final * qty} 元")`,o=`name = "小红"
age = 18
height = 1.65

print(name)
print(age)
print(height)`,h=`小红
18
1.65`,j=`score = 90
score = 95      # 重新赋值，旧值被覆盖
print(score)`,p="95",a=`a = 10          # 整数 int
b = 3.14        # 小数 float
print(type(a))
print(type(b))`,y=`<class 'int'>
<class 'float'>`,g=`print(7 + 3)    # 加
print(7 - 3)    # 减
print(7 * 3)    # 乘
print(7 / 3)    # 除（结果是小数）
print(7 // 3)   # 整除（只取整数部分）
print(7 % 3)    # 取余（除不尽的余数）
print(7 ** 3)   # 幂（7 的 3 次方）`,u=`10
4
21
2.3333333333333335
2
1
343`,m=`x = "100"           # 这是字符串，不是数字
y = int(x) + 5      # 先转成整数才能做加法
print(y)

pi = 3.9
print(int(pi))      # 转成整数会直接砍掉小数部分（不是四舍五入）

n = 42
print("年龄是" + str(n) + "岁")   # 数字转成字符串才能和文字拼接`,f=`105
3
年龄是42岁`,C=`x = "100"
print(x + 5)        # 字符串和数字不能直接相加`,O='TypeError: can only concatenate str (not "int") to str',P=`name = input("请输入你的名字：")
print("你好，" + name)`,E=`请输入你的名字：小明
你好，小明`,v=`age = input("请输入你的年龄：")   # input 读到的永远是字符串
age = int(age)                    # 要转成数字才能计算
print("明年你", age + 1, "岁")`,q=`请输入你的年龄：18
明年你 19 岁`;function S(){return e.jsxs("article",{children:[e.jsxs(r,{children:["这一章开始接触编程的核心：用",e.jsx("strong",{children:"变量"}),"给数据起名字、存起来反复用；认识两种数字 （整数和小数）和它们的",e.jsx("strong",{children:"运算"}),"；学会在不同类型之间",e.jsx("strong",{children:"转换"}),"； 用 ",e.jsx("code",{children:"type()"})," 查看一个东西是什么类型；最后用 ",e.jsx("code",{children:"input()"})," 读取用户从键盘输入的内容， 写出能「和人对话」的程序。"]}),e.jsx("h2",{children:"一、变量：给数据起个名字"}),e.jsxs(s,{children:["变量就像一个贴了标签的盒子：你把数据放进去，给盒子起个名字，以后用名字就能取出里面的数据。 在 Python 里，用一个等号 ",e.jsx("code",{children:"="})," 来「赋值」——把右边的值装进左边的名字里。"]}),e.jsx(t,{lang:"python",title:"创建变量并使用",code:o}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:h})}),e.jsx("p",{children:"变量是可以「变」的——再赋一次值，旧值就被新值覆盖："}),e.jsx(t,{lang:"python",title:"变量可以重新赋值",code:j}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:p})}),e.jsxs(i,{variant:"warn",title:"= 不是「等于」",children:["编程里的 ",e.jsx("code",{children:"="})," 念作「赋值」，意思是「把右边的值放进左边」，",e.jsx("strong",{children:"不是数学里的「相等」"}),"。 判断相等用的是两个等号 ",e.jsx("code",{children:"=="}),"，后面章节会讲。"]}),e.jsx("h3",{children:"变量命名规则"}),e.jsxs("ul",{children:[e.jsxs("li",{children:["只能用",e.jsx("strong",{children:"字母、数字、下划线"})," ",e.jsx("code",{children:"_"}),"，且",e.jsx("strong",{children:"不能用数字开头"}),"。"]}),e.jsxs("li",{children:["区分大小写：",e.jsx("code",{children:"age"})," 和 ",e.jsx("code",{children:"Age"})," 是两个不同的变量。"]}),e.jsxs("li",{children:["不能用 Python 的",e.jsx("strong",{children:"关键字"}),"（如 ",e.jsx("code",{children:"if"}),"、",e.jsx("code",{children:"for"}),"、",e.jsx("code",{children:"print"})," 这类）做变量名。"]}),e.jsxs("li",{children:["建议起",e.jsx("strong",{children:"有意义"}),"的名字，比如用 ",e.jsx("code",{children:"user_age"})," 而不是 ",e.jsx("code",{children:"a"}),"，让代码一看就懂。"]})]}),e.jsx("h2",{children:"二、两种数字：整数 int 和小数 float"}),e.jsxs("p",{children:["Python 里最常用的两种数字：",e.jsx("strong",{children:"整数"}),"（int，没有小数点，如 ",e.jsx("code",{children:"10"}),"、",e.jsx("code",{children:"-3"}),"） 和",e.jsx("strong",{children:"浮点数"}),"（float，带小数点，如 ",e.jsx("code",{children:"3.14"}),"、",e.jsx("code",{children:"1.0"}),"）。"]}),e.jsx(t,{lang:"python",title:"两种数字类型",code:a}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:y})}),e.jsx("h2",{children:"三、算术运算符"}),e.jsx("p",{children:"Python 能像计算器一样算数，下面是全部 7 个常用运算符："}),e.jsx(t,{lang:"python",title:"七种算术运算",code:g}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:u})}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"运算符"}),e.jsx("th",{children:"含义"}),e.jsx("th",{children:"例子（7 和 3）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"+"})}),e.jsx("td",{children:"加"}),e.jsx("td",{children:"10"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"-"})}),e.jsx("td",{children:"减"}),e.jsx("td",{children:"4"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"*"})}),e.jsx("td",{children:"乘"}),e.jsx("td",{children:"21"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"/"})}),e.jsx("td",{children:"除（结果是小数）"}),e.jsx("td",{children:"2.333..."})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"//"})}),e.jsx("td",{children:"整除（去掉小数部分）"}),e.jsx("td",{children:"2"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"%"})}),e.jsx("td",{children:"取余（余数）"}),e.jsx("td",{children:"1"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"**"})}),e.jsx("td",{children:"幂（次方）"}),e.jsx("td",{children:"343"})]})]})]}),e.jsxs(i,{variant:"tip",children:[e.jsx("code",{children:"%"}),"（取余）非常有用：判断一个数能不能被另一个整除——比如 ",e.jsx("code",{children:"n % 2 == 0"})," 就是「n 是偶数」。"]}),e.jsx("h2",{children:"四、类型转换"}),e.jsxs("p",{children:["不同类型的数据有时需要互相转换。常用三个转换函数：",e.jsx("code",{children:"int()"})," 转整数、",e.jsx("code",{children:"float()"})," 转小数、",e.jsx("code",{children:"str()"})," 转字符串。"]}),e.jsx(t,{lang:"python",title:"类型转换实例",code:m}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:f})}),e.jsx(i,{variant:"warn",title:"字符串和数字不能直接运算",children:"文字（字符串）和数字是两种东西，不能直接相加。下面这段会报错："}),e.jsx(t,{lang:"python",title:"错误示范",code:C}),e.jsx(n,{title:"运行结果（报错）",children:e.jsx(t,{lang:"text",title:"运行结果",code:O})}),e.jsxs("p",{children:["解决办法：要么把字符串 ",e.jsx("code",{children:'"100"'})," 用 ",e.jsx("code",{children:"int()"})," 转成数字，要么把数字 ",e.jsx("code",{children:"5"})," 用",e.jsx("code",{children:"str()"})," 转成字符串——取决于你想做加法还是拼接。"]}),e.jsx("h2",{children:"五、用 type() 查看类型"}),e.jsxs("p",{children:["不确定一个变量是什么类型？用 ",e.jsx("code",{children:"type()"})," 一查便知，调试时特别有用："]}),e.jsx(t,{lang:"python",title:"查看类型",code:`print(type(10))
print(type(3.14))
print(type("你好"))`}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:`<class 'int'>
<class 'float'>
<class 'str'>`})}),e.jsx("h2",{children:"六、input()：读取用户输入"}),e.jsxs(s,{children:[e.jsx("code",{children:"input()"})," 会暂停程序、等用户在键盘上敲字并回车，然后把敲的内容交给你。 括号里可以写一句提示语。",e.jsx("strong",{children:"关键点：input 读到的永远是字符串"}),"，哪怕用户输入的是数字。"]}),e.jsx(t,{lang:"python",title:"读取一段文字",code:P}),e.jsx(n,{title:"运行结果（下划线部分是用户输入的）",children:e.jsx(t,{lang:"text",title:"运行结果",code:E})}),e.jsxs("p",{children:["因为 ",e.jsx("code",{children:"input"})," 给的是字符串，想拿来计算就必须先用 ",e.jsx("code",{children:"int()"})," 或 ",e.jsx("code",{children:"float()"})," 转换："]}),e.jsx(t,{lang:"python",title:"读取数字要转换",code:v}),e.jsx(n,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:q})}),e.jsxs(i,{variant:"warn",title:"最常见的新手坑",children:["忘了转换，直接拿 ",e.jsx("code",{children:"input()"})," 的结果做加减乘除，要么报错，要么得到奇怪的结果 （比如 ",e.jsx("code",{children:'"3" * 2'})," 会得到 ",e.jsx("code",{children:'"33"'})," 而不是 6）。读数字记得 ",e.jsx("code",{children:"int(input(...))"}),"。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」，看看结果。"]}),e.jsx(l,{initialCode:x}),e.jsx(d,{title:"动手练一练",children:e.jsxs("ol",{children:[e.jsx("li",{children:"写一个程序，问用户两个数字，输出它们的和、差、积、商。"}),e.jsxs("li",{children:["用 ",e.jsx("code",{children:"%"})," 判断用户输入的数字是奇数还是偶数（提示：偶数 ",e.jsx("code",{children:"n % 2 == 0"}),"）。"]}),e.jsx("li",{children:"问用户出生年份，算出今年（2026）他多少岁并打印出来。"})]})}),e.jsx(c,{points:["变量用 = 赋值，把右边的值装进左边的名字，可重新赋值覆盖旧值；= 是赋值不是相等。","命名规则：字母数字下划线、不能数字开头、区分大小写、别用关键字，起有意义的名字。","两种数字：整数 int 和小数 float；type() 可查看类型。","七个算术运算符：+ - * / // % **，其中 / 得小数、// 是整除、% 取余、** 是幂。","类型转换用 int() / float() / str()；字符串和数字不能直接运算，否则 TypeError。","input() 读用户输入，结果永远是字符串，要计算先用 int()/float() 转换。"]})]})}export{S as default};
