import{j as e}from"./index-DraKZMSn.js";import{L as s,S as d}from"./Summary-D7nqkGRf.js";import{K as n}from"./KeyIdea-C2HcfWY0.js";import{C as r}from"./Callout-BE-nWzIM.js";import{C as i}from"./CodeBlock-BiqAHAS8.js";import{E as t}from"./Example-yyME7alB.js";const c=`class Calculator {
    // 重载（overload）：同名、参数列表不同，编译期决定
    int add(int a, int b) { return a + b; }
    double add(double a, double b) { return a + b; }
    int add(int a, int b, int c) { return a + b + c; }
}

class Base {
    Object create() { return new Object(); }
}
class Sub extends Base {
    // 重写（override）：方法签名相同，运行期动态分派
    // 返回类型可协变（String 是 Object 的子类），访问权限不能更严
    @Override String create() { return "sub"; }
}`,l=`public class PassByValue {
    static void changePrimitive(int n) { n = 100; }          // 改的是副本
    static void changeRef(StringBuilder sb) { sb.append("!"); } // 改的是同一对象
    static void reassignRef(StringBuilder sb) { sb = new StringBuilder("x"); } // 重指无效

    public static void main(String[] args) {
        int a = 1;
        changePrimitive(a);
        System.out.println(a);              // 1：基本类型传值，原值不变

        StringBuilder s = new StringBuilder("hi");
        changeRef(s);
        System.out.println(s);              // hi!：通过引用副本改到了同一对象

        reassignRef(s);
        System.out.println(s);              // hi!：重新赋值只改了副本指向，原引用不动
    }
}`,h=`// Object 类的核心方法（所有类都继承）
public boolean equals(Object obj)   // 默认比较引用（==），常需重写
public int hashCode()               // 默认基于地址，重写 equals 必须重写它
public String toString()            // 默认 类名@十六进制hashCode，建议重写
public final Class<?> getClass()    // 运行时类型，反射入口
protected Object clone()            // 浅拷贝，需实现 Cloneable
public final void wait() / notify() / notifyAll()  // 线程协作（配合 synchronized）
protected void finalize()           // 已废弃，不要依赖`,j=`List<Integer> list = new ArrayList<>(List.of(1, 2, 3, 4));

// 普通 for：有索引，可按下标增删，适合需要索引或反向遍历
for (int i = 0; i < list.size(); i++) {
    System.out.println(list.get(i));
}

// foreach（增强 for）：底层用迭代器，简洁，但不能拿到索引
for (int v : list) {
    System.out.println(v);
}

// 陷阱：foreach 中直接删元素会抛 ConcurrentModificationException
for (int v : list) {
    if (v == 2) list.remove(Integer.valueOf(2));  // 运行时异常！
}`;function u(){return e.jsxs("article",{children:[e.jsx(s,{children:"方法与对象的细节是 Java 笔试面试的高发区：重载和重写老是搞混、静态方法能不能被重写说不清、 「Java 是值传递还是引用传递」更是经典送命题。本章把这些问题连同 Object 类方法、 for 与 foreach 的取舍一次讲透，并给出最容易答错的反例。"}),e.jsx("h2",{children:"一、重载 vs 重写"}),e.jsxs(n,{children:["重载（overload）是",e.jsx("strong",{children:"同一个类里方法名相同、参数列表不同"}),"，编译期就能确定调谁，属于编译时多态； 重写（override）是",e.jsx("strong",{children:"子类重新实现父类的同签名方法"}),"，运行期根据对象真实类型动态分派，属于运行时多态。 一句话：重载比参数，重写比类型。"]}),e.jsx("h3",{children:"面试题 1：重载和重写的区别？"}),e.jsx(i,{lang:"java",title:"重载与重写",code:c}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"重载 overload"}),e.jsx("th",{children:"重写 override"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"发生位置"}),e.jsx("td",{children:"同一个类（或父子类间）"}),e.jsx("td",{children:"子类与父类之间"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"方法名"}),e.jsx("td",{children:"相同"}),e.jsx("td",{children:"相同"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"参数列表"}),e.jsx("td",{children:"必须不同（个数/类型/顺序）"}),e.jsx("td",{children:"必须相同"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"返回类型"}),e.jsx("td",{children:"可不同（不作为区分依据）"}),e.jsx("td",{children:"相同或协变（子类型）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"访问权限"}),e.jsx("td",{children:"无限制"}),e.jsx("td",{children:"不能比父类更严格"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"绑定时机"}),e.jsx("td",{children:"编译期（静态）"}),e.jsx("td",{children:"运行期（动态）"})]})]})]}),e.jsxs(r,{variant:"warn",title:"易错点：返回类型不能用来区分重载",children:["两个方法只有返回类型不同、参数完全一样，",e.jsx("strong",{children:"不构成重载，编译直接报错"}),"。 因为调用时编译器无法仅凭返回类型判断该调哪个。区分重载只看「参数列表」。"]}),e.jsx("h3",{children:"面试题 2：静态方法和实例方法有什么区别？静态方法能被重写吗？"}),e.jsxs("p",{children:["静态方法属于",e.jsx("strong",{children:"类"}),"，用 ",e.jsx("code",{children:"类名.方法()"})," 调用，没有 ",e.jsx("code",{children:"this"}),"， 不能访问实例字段；实例方法属于",e.jsx("strong",{children:"对象"}),"，需先 new 出对象再调，能访问实例状态。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"静态方法"}),e.jsx("th",{children:"实例方法"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"归属"}),e.jsx("td",{children:"类"}),e.jsx("td",{children:"对象"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"调用方式"}),e.jsx("td",{children:e.jsx("code",{children:"ClassName.m()"})}),e.jsx("td",{children:e.jsx("code",{children:"obj.m()"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"this"}),e.jsx("td",{children:"无"}),e.jsx("td",{children:"有"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"访问实例成员"}),e.jsx("td",{children:"不能直接访问"}),e.jsx("td",{children:"可以"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"多态"}),e.jsx("td",{children:"不参与重写（静态绑定）"}),e.jsx("td",{children:"可被重写（动态分派）"})]})]})]}),e.jsxs(r,{variant:"note",title:"静态方法不能被重写，只能被「隐藏」",children:["子类若定义一个与父类同签名的静态方法，那叫",e.jsx("strong",{children:"方法隐藏（hiding）"}),"，不是重写。 区别在于：调用静态方法看的是",e.jsx("strong",{children:"引用的声明类型（编译期）"}),"，而非对象真实类型。 所以 ",e.jsx("code",{children:"Parent p = new Child(); p.staticM();"})," 调的是 Parent 的版本——这与实例方法重写的动态分派正好相反。"]}),e.jsx("h2",{children:"二、参数传递：值还是引用"}),e.jsx("h3",{children:"面试题 3：Java 是值传递还是引用传递？"}),e.jsxs("p",{children:["标准答案只有一个：",e.jsx("strong",{children:"Java 永远是值传递（pass by value）"}),"。 关键在于理解「值」是什么：基本类型传的是数值的副本；引用类型传的是",e.jsx("strong",{children:"引用（地址）的副本"}),"， 而不是对象本身。所以你能通过这个引用副本去修改它指向的对象，但",e.jsx("strong",{children:"重新给参数赋值"}),"不会影响原引用。"]}),e.jsx(i,{lang:"java",title:"一段代码看清值传递的本质",code:l}),e.jsx(t,{title:"为什么这不是「引用传递」？",children:e.jsxs("p",{children:["真正的引用传递（如 C++ 的 ",e.jsx("code",{children:"&"})," 引用）意味着在方法里给参数重新赋值， 外部的原变量也会跟着改。但上面 ",e.jsx("code",{children:"reassignRef"})," 里把 ",e.jsx("code",{children:"sb"})," 指向新对象后， 外部的 ",e.jsx("code",{children:"s"})," 仍指向老对象——说明传进来的只是引用的",e.jsx("strong",{children:"副本"}),"。 能改对象内容，是因为副本和原引用指向同一个对象；不能改原引用指向，证明它是值传递。"]})}),e.jsx(r,{variant:"warn",title:"送命题应对：一句话框定",children:"被问这题，先斩钉截铁说「Java 只有值传递」，再补一句「对象传的是引用的副本，所以能改对象内容但改不了原引用指向」。 切忌含糊地说「基本类型值传递、对象引用传递」——这是最常见的错误表述。"}),e.jsx("h2",{children:"三、Object 类方法"}),e.jsx("h3",{children:"面试题 4：Object 类有哪些方法？"}),e.jsxs("p",{children:["所有类都隐式继承 ",e.jsx("code",{children:"Object"}),"，它定义了一组「万物皆有」的方法，是很多机制的根基："]}),e.jsx(i,{lang:"java",title:"Object 的核心方法",code:h}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"equals"})," / ",e.jsx("code",{children:"hashCode"}),"：判等与散列，必须成对重写（详见第三卷）。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"toString"}),"：默认返回「类名@哈希码十六进制」，业务类一般重写成可读信息。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"getClass"}),"：拿到运行时类对象，是反射的入口。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"clone"}),"：受保护的浅拷贝方法，需实现 ",e.jsx("code",{children:"Cloneable"})," 才能用。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"wait"})," / ",e.jsx("code",{children:"notify"})," / ",e.jsx("code",{children:"notifyAll"}),"：线程间协作，必须在 ",e.jsx("code",{children:"synchronized"})," 块内调用。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"finalize"}),"：对象回收前的回调，已被官方废弃，不要依赖。"]})]}),e.jsxs(r,{variant:"tip",title:"为什么 wait/notify 在 Object 而不在 Thread？",children:["因为它们是基于",e.jsx("strong",{children:"对象监视器（monitor）"}),"的协作机制，锁是加在任意对象上的， 而不是加在线程上。任何对象都可以作为锁，所以这组方法理应定义在所有对象的共同祖先 Object 里。 这是个很能体现理解深度的追问点。"]}),e.jsx("h2",{children:"四、for 与 foreach"}),e.jsx("h3",{children:"面试题 5：普通 for 和增强 for（foreach）有什么区别？"}),e.jsxs("p",{children:["普通 for 通过索引访问，能拿到下标、能反向遍历、能在遍历中按下标增删； foreach（增强 for）底层是",e.jsx("strong",{children:"迭代器"}),"语法糖，写法简洁，但拿不到索引，且遍历中不能直接增删集合。"]}),e.jsx(i,{lang:"java",title:"for 与 foreach 及其陷阱",code:j}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"普通 for"}),e.jsx("th",{children:"foreach"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"是否有索引"}),e.jsx("td",{children:"有"}),e.jsx("td",{children:"无"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"底层"}),e.jsx("td",{children:"下标访问"}),e.jsx("td",{children:"Iterator 迭代"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"遍历中删除"}),e.jsx("td",{children:"可（注意下标偏移）"}),e.jsx("td",{children:"直接删抛 ConcurrentModificationException"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"可读性"}),e.jsx("td",{children:"一般"}),e.jsx("td",{children:"简洁"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"适用"}),e.jsx("td",{children:"需要索引/反向/边遍历边改"}),e.jsx("td",{children:"只读遍历集合或数组"})]})]})]}),e.jsxs(r,{variant:"warn",title:"foreach 删除元素为何抛异常？",children:["foreach 编译后用迭代器遍历，集合维护一个 ",e.jsx("code",{children:"modCount"})," 记录结构性修改次数。 你直接调 ",e.jsx("code",{children:"list.remove()"})," 会改 modCount，而迭代器记着旧值，下次取元素时发现对不上， 就抛 ",e.jsx("code",{children:"ConcurrentModificationException"}),"（快速失败 fail-fast 机制）。 正确做法是改用 ",e.jsx("code",{children:"Iterator.remove()"})," 或 ",e.jsx("code",{children:"removeIf()"}),"。"]}),e.jsx("h3",{children:"面试题 6：构造方法能被重写、继承、被 final/static 修饰吗？"}),e.jsx("p",{children:"构造方法（构造器）是个特殊存在，这道题专考它的边界："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"问题"}),e.jsx("th",{children:"结论"}),e.jsx("th",{children:"原因"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"能被继承吗"}),e.jsx("td",{children:"不能"}),e.jsx("td",{children:"构造器不是普通方法，子类有自己的构造器"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能被重写吗"}),e.jsx("td",{children:"不能"}),e.jsx("td",{children:"不能继承，自然谈不上重写"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能被重载吗"}),e.jsx("td",{children:"能"}),e.jsx("td",{children:"同名（类名）不同参数列表，很常见"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能加 static 吗"}),e.jsx("td",{children:"不能"}),e.jsx("td",{children:"构造器就是为创建实例服务的"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能加 final 吗"}),e.jsx("td",{children:"不能"}),e.jsx("td",{children:"本就不能被重写，final 无意义"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能加 abstract 吗"}),e.jsx("td",{children:"不能"}),e.jsx("td",{children:"构造器必须有实现"})]})]})]}),e.jsxs(r,{variant:"note",title:"子类构造一定先调父类构造",children:["子类构造器执行前，会先调用父类构造器（默认隐式调 ",e.jsx("code",{children:"super()"}),"，也可显式 ",e.jsx("code",{children:"super(...)"}),"）。 如果父类没有无参构造器，子类又没显式调有参的，就会编译报错。这保证了「先把父类那部分初始化好，再初始化子类」—— 理解这点能解释很多「为什么父类得加无参构造器」的报错。"]}),e.jsx(d,{points:["重载比参数（编译期静态绑定），重写比类型（运行期动态分派）；返回类型不能用来区分重载。","静态方法属于类、无 this、不参与多态；子类同签名静态方法是「隐藏」而非重写，按声明类型静态绑定。","Java 只有值传递：基本类型传数值副本，对象传引用副本——能改对象内容，但重新赋值改不动原引用。","Object 提供 equals/hashCode/toString/getClass/clone/wait/notify/finalize；wait/notify 在 Object 是因为锁加在任意对象上。","普通 for 有索引、可边遍历边按下标改；foreach 是迭代器语法糖，简洁但无索引、直接增删会触发 fail-fast 异常。","foreach 中删元素要用 Iterator.remove() 或 removeIf()，避免 ConcurrentModificationException。"]})]})}export{u as default};
