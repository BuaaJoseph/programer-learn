import{j as e}from"./index-DL563RIm.js";import{L as r,S as l}from"./Summary-BrgLcNDp.js";import{K as s}from"./KeyIdea-exK4GrdK.js";import{C as t}from"./Callout-B-8nslAm.js";import{C as i}from"./CodeBlock-DkVyd3P6.js";import{E as n}from"./Example-HxOmIesu.js";import{P as c}from"./Practice-r6liJb9j.js";import{P as o}from"./PyRunner-CEF0nuxG.js";const d=`# for + if：打印 1~10 里的偶数
n = 10
print(f"1~{n} 里的偶数：")
for i in range(1, n + 1):
    if i % 2 == 0:
        print(i, end=" ")
print()   # 换行

# while：累加 1+2+...+5
total = 0
k = 1
while k <= 5:
    total += k
    k += 1
print("1+2+3+4+5 =", total)

# 九九乘法表片段（第 3 行）
row = 3
for col in range(1, row + 1):
    print(f"{col}x{row}={col * row}", end="  ")
print()`,x=`age = 18
if age >= 18:
    print("成年了")
else:
    print("未成年")`,h="成年了",j=`score = 75
if score >= 90:
    print("优秀")
elif score >= 60:
    print("及格")
else:
    print("不及格")`,a="及格",f=`print(3 > 2)     # 大于
print(3 == 3)    # 等于（两个等号！）
print(3 != 5)    # 不等于
print(3 <= 2)    # 小于等于`,p=`True
True
True
False`,g=`age = 20
has_ticket = True
if age >= 18 and has_ticket:      # 两个条件都成立
    print("可以进场")
if age < 12 or age > 60:          # 任一条件成立
    print("享受优惠票")
if not has_ticket:                # 取反
    print("请先买票")`,u="可以进场",m=`# 这些会被当成「假」：0、空字符串、空列表、空字典、None
if "":
    print("不会打印")
if "你好":
    print("非空字符串是真")
if []:
    print("不会打印")
if [1, 2]:
    print("非空列表是真")`,C=`非空字符串是真
非空列表是真`,y=`for fruit in ["苹果", "香蕉", "橙子"]:
    print(fruit)`,k=`苹果
香蕉
橙子`,w=`for i in range(5):        # 0,1,2,3,4
    print(i, end=" ")
print()
for i in range(1, 4):     # 1,2,3
    print(i, end=" ")
print()
for i in range(0, 10, 2): # 0 到 9，步长 2
    print(i, end=" ")`,b=`0 1 2 3 4
1 2 3
0 2 4 6 8`,O=`for ch in "Hi":
    print(ch)`,T=`H
i`,P=`n = 1
while n <= 3:        # 条件为真就一直循环
    print("第", n, "次")
    n = n + 1        # 别忘了改变量，否则死循环！`,L=`第 1 次
第 2 次
第 3 次`,R=`for i in range(1, 10):
    if i == 3:
        continue     # 跳过本次，进入下一次
    if i == 6:
        break        # 直接结束整个循环
    print(i, end=" ")`,S="1 2 4 5",v=`for i in range(1, 10):
    for j in range(1, i + 1):
        print(f"{j}x{i}={i*j}", end="\\t")
    print()   # 每行末尾换行`,E=`1x1=1
1x2=2	2x2=4
1x3=3	2x3=6	3x3=9
1x4=4	2x4=8	3x4=12	4x4=16
... (共 9 行)`;function z(){return e.jsxs("article",{children:[e.jsxs(r,{children:["程序要会「做选择」和「重复干活」，才算真正聪明起来。这一章讲两大流程控制： 用 ",e.jsx("strong",{children:"if / elif / else"})," 做条件判断，用 ",e.jsx("strong",{children:"for / while"})," 做循环， 以及 ",e.jsx("code",{children:"break"}),"、",e.jsx("code",{children:"continue"})," 这两个循环里的「急刹车」和「跳过」。 最后用嵌套循环打印一张九九乘法表。"]}),e.jsx("h2",{children:"一、if / elif / else 条件判断"}),e.jsxs(s,{children:[e.jsx("code",{children:"if"})," 后面跟一个条件，条件成立（为真）就执行它下面缩进的代码块。 可以加 ",e.jsx("code",{children:"else"})," 表示「否则」，加 ",e.jsx("code",{children:"elif"}),"（else if 的缩写）表示「再不然」。 注意每个 ",e.jsx("code",{children:"if/elif/else"})," 行末都有冒号，下面的代码要缩进。"]}),e.jsx(i,{lang:"python",title:"最简单的 if / else",code:x}),e.jsx(n,{title:"运行结果",children:e.jsx(i,{lang:"text",title:"运行结果",code:h})}),e.jsxs("p",{children:["多个分支用 ",e.jsx("code",{children:"elif"})," 连起来，Python 会",e.jsx("strong",{children:"从上往下"}),"逐个检查，命中第一个成立的就执行、不再往下看："]}),e.jsx(i,{lang:"python",title:"多分支 elif",code:j}),e.jsx(n,{title:"运行结果",children:e.jsx(i,{lang:"text",title:"运行结果",code:a})}),e.jsx("h2",{children:"二、比较与逻辑运算"}),e.jsxs("p",{children:["条件通常由比较运算符构成，结果是 ",e.jsx("code",{children:"True"}),"（真）或 ",e.jsx("code",{children:"False"}),"（假）："]}),e.jsx(i,{lang:"python",title:"比较运算符",code:f}),e.jsx(n,{title:"运行结果",children:e.jsx(i,{lang:"text",title:"运行结果",code:p})}),e.jsxs(t,{variant:"warn",title:"判断相等用 == 不是 =",children:[e.jsx("code",{children:"="})," 是赋值，",e.jsx("code",{children:"=="})," 才是「判断相等」。在 ",e.jsx("code",{children:"if"})," 里写错成 ",e.jsx("code",{children:"="})," 会直接报语法错误。"]}),e.jsxs("p",{children:["多个条件可以用",e.jsx("strong",{children:"逻辑运算符"}),"组合：",e.jsx("code",{children:"and"}),"（且）、",e.jsx("code",{children:"or"}),"（或）、",e.jsx("code",{children:"not"}),"（非）。"]}),e.jsx(i,{lang:"python",title:"and / or / not",code:g}),e.jsx(n,{title:"运行结果",children:e.jsx(i,{lang:"text",title:"运行结果",code:u})}),e.jsx("h3",{children:"真假值：什么算「真」"}),e.jsxs("p",{children:["条件不一定非得是比较表达式。Python 里有些值天生被当作「假」：",e.jsxs("strong",{children:["0、空字符串 ",e.jsx("code",{children:'""'}),"、空列表 ",e.jsx("code",{children:"[]"}),"、空字典 ",e.jsx("code",{children:"{}"}),"、",e.jsx("code",{children:"None"})]}),"。 其余非空、非零的值都算「真」。"]}),e.jsx(i,{lang:"python",title:"真假值实验",code:m}),e.jsx(n,{title:"运行结果",children:e.jsx(i,{lang:"text",title:"运行结果",code:C})}),e.jsxs(t,{variant:"tip",children:["这个特性让代码很简洁：判断列表是否非空，直接写 ",e.jsx("code",{children:"if mylist:"})," 即可，不用写 ",e.jsxs("code",{children:["if len(mylist) ",">"," 0:"]}),"。"]}),e.jsx("h2",{children:"三、for 循环：把一组东西逐个处理"}),e.jsxs("p",{children:[e.jsx("code",{children:"for ... in"})," 会把一个序列里的元素一个个取出来。先看遍历列表："]}),e.jsx(i,{lang:"python",title:"遍历列表",code:y}),e.jsx(n,{title:"运行结果",children:e.jsx(i,{lang:"text",title:"运行结果",code:k})}),e.jsx("h3",{children:"用 range 生成数字序列"}),e.jsxs("p",{children:["想循环固定次数，用 ",e.jsx("code",{children:"range"}),"。",e.jsx("code",{children:"range(n)"})," 产生 0 到 n-1；",e.jsx("code",{children:"range(a, b)"})," 产生 a 到 b-1；",e.jsx("code",{children:"range(a, b, step)"})," 还能指定步长。"]}),e.jsx(i,{lang:"python",title:"range 的三种用法",code:w}),e.jsx(n,{title:"运行结果",children:e.jsx(i,{lang:"text",title:"运行结果",code:b})}),e.jsx("h3",{children:"遍历字符串"}),e.jsx(i,{lang:"python",title:"遍历字符串的每个字符",code:O}),e.jsx(n,{title:"运行结果",children:e.jsx(i,{lang:"text",title:"运行结果",code:T})}),e.jsx("h2",{children:"四、while 循环：条件为真就一直转"}),e.jsxs("p",{children:[e.jsx("code",{children:"while"})," 后跟一个条件，只要条件成立就反复执行循环体。适合「不知道要循环几次、但知道停止条件」的情况。"]}),e.jsx(i,{lang:"python",title:"while 循环",code:P}),e.jsx(n,{title:"运行结果",children:e.jsx(i,{lang:"text",title:"运行结果",code:L})}),e.jsxs(t,{variant:"warn",title:"当心死循环",children:["写 ",e.jsx("code",{children:"while"})," 一定要保证条件最终会变成「假」。上面例子里如果忘了 ",e.jsx("code",{children:"n = n + 1"}),"，",e.jsx("code",{children:"n"})," 永远是 1，程序会无限打印，卡死。按 Ctrl+C 可以强制停止。"]}),e.jsx("h2",{children:"五、break 和 continue"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"break"}),"：",e.jsx("strong",{children:"立即结束"}),"整个循环，跳出去。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"continue"}),"：",e.jsx("strong",{children:"跳过本次"}),"剩下的代码，直接进入下一次循环。"]})]}),e.jsx(i,{lang:"python",title:"break 与 continue",code:R}),e.jsx(n,{title:"运行结果",children:e.jsx(i,{lang:"text",title:"运行结果",code:S})}),e.jsxs("p",{children:["分析：",e.jsx("code",{children:"i=3"})," 时 ",e.jsx("code",{children:"continue"})," 跳过了打印；",e.jsx("code",{children:"i=6"})," 时 ",e.jsx("code",{children:"break"})," 直接结束，所以只打印了 1 2 4 5。"]}),e.jsx("h2",{children:"六、嵌套循环：九九乘法表"}),e.jsx("p",{children:"循环里还能套循环。经典练习就是九九乘法表——外层控制行，内层控制每行的列："}),e.jsx(i,{lang:"python",title:"九九乘法表",code:v}),e.jsx(n,{title:"运行结果（节选）",children:e.jsx(i,{lang:"text",title:"运行结果",code:E})}),e.jsxs("p",{children:["外层 ",e.jsx("code",{children:"i"})," 从 1 到 9 是每一行；内层 ",e.jsx("code",{children:"j"})," 从 1 到 ",e.jsx("code",{children:"i"})," 打印这一行的每个乘式，",e.jsx("code",{children:"\\t"})," 让它们对齐；内层结束后用一个空 ",e.jsx("code",{children:"print()"})," 换行。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」，看看结果。"]}),e.jsx(o,{initialCode:d}),e.jsx(c,{title:"动手练一练",children:e.jsxs("ol",{children:[e.jsx("li",{children:"让用户输入一个分数，用 if/elif/else 判断等级（90 以上优秀，60 以上及格，否则不及格）。"}),e.jsx("li",{children:"用 for + range 打印 1 到 100 所有偶数的和。"}),e.jsx("li",{children:"用 while 实现一个简单的「猜数字」：心里设定一个数，让用户反复输入直到猜中，猜中就 break。"})]})}),e.jsx(l,{points:["if 条件成立执行缩进代码块，else 否则，elif 再不然；从上往下命中第一个成立的分支。","比较运算符 > < >= <= == !=（相等是 ==），逻辑运算 and 且 / or 或 / not 非。","真假值：0、空字符串、空列表、空字典、None 为假，其余为真，可直接 if mylist 判断非空。","for ... in 遍历列表/字符串；range(n)、range(a,b)、range(a,b,step) 生成数字序列。","while 条件为真就循环，务必保证条件会变假，否则死循环（Ctrl+C 停止）。","break 结束整个循环，continue 跳过本次；循环可嵌套，如九九乘法表外层管行内层管列。"]})]})}export{z as default};
