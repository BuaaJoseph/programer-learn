import{j as e}from"./index-6B4LaKrF.js";import{L as i,S as s}from"./Summary-CdadMIHa.js";import{K as t}from"./KeyIdea-Dk7JleQ-.js";import{C as n}from"./Callout-Bc-_Rgy3.js";import{C as r}from"./CodeBlock-CsqKASm5.js";import{E as c}from"./Example-BJvFbdam.js";import{P as d}from"./Practice-B0a6ljMe.js";import{P as o}from"./PyRunner-BbglBp-d.js";const l=`# 综合：生成器 yield + 一个简单装饰器
# 1) 生成器：依次吐出前 n 个偶数
def even_numbers(n):
    count = 0
    num = 0
    while count < n:
        yield num
        num += 2
        count += 1

print("前 5 个偶数:", list(even_numbers(5)))

# 2) 装饰器：调用前后打印日志
def log_call(func):
    def wrapper(*args, **kwargs):
        print(f"-> 调用 {func.__name__}{args}")
        result = func(*args, **kwargs)
        print(f"<- 返回 {result}")
        return result
    return wrapper

@log_call
def add(a, b):
    return a + b

add(3, 4)`,x=`# 这些都是"可迭代对象"，能用 for 遍历
for x in [1, 2, 3]:       # 列表
    print(x)
for c in "abc":           # 字符串
    print(c)
for k in {"a": 1, "b": 2}: # 字典（遍历键）
    print(k)`,a=`# for 背后其实在做这些事
nums = [10, 20, 30]
it = iter(nums)       # 1. 拿到一个"迭代器"
print(next(it))       # 2. 反复 next() 取下一个
print(next(it))
print(next(it))
# print(next(it))     # 没有更多了，会抛 StopIteration

# for 循环就是自动帮你做 iter() + 不断 next()，遇到尽头自动停`,h=`10
20
30`,j=`# 用 yield 写生成器：调用时不立刻算，要一个才给一个
def count_up(n):
    i = 1
    while i <= n:
        yield i        # 每次 yield 吐出一个值，然后"暂停"在这里
        i += 1

for x in count_up(3):
    print(x)`,p=`1
2
3`,m=`# 列表：一次性把 100 万个数全造出来，占大量内存
big_list = [x * x for x in range(1_000_000)]

# 生成器：用到哪个才算哪个，几乎不占内存
big_gen = (x * x for x in range(1_000_000))   # 注意是圆括号

print(sum(big_gen))   # 边算边求和，内存友好`,g="333332833333500000",f=`# 生成器是"惰性"的：不遍历就不会执行里面的代码
def make_numbers():
    print("开始生成")
    yield 1
    print("生成了 1，继续")
    yield 2

g = make_numbers()        # 此时什么都没打印！
print("还没开始取")
print(next(g))            # 取第一个，才执行到第一个 yield
print(next(g))            # 再取，继续往下执行`,u=`还没开始取
开始生成
1
生成了 1，继续
2`,_=`# 装饰器：一个"包装函数的函数"
def my_decorator(func):
    def wrapper():
        print("调用前")
        func()              # 执行原来的函数
        print("调用后")
    return wrapper

def say_hi():
    print("你好")

say_hi = my_decorator(say_hi)   # 手动包装
say_hi()`,y=`调用前
你好
调用后`,w=`# @语法：和上面手动包装完全等价，但更优雅
def my_decorator(func):
    def wrapper():
        print("调用前")
        func()
        print("调用后")
    return wrapper

@my_decorator              # 等于 say_hi = my_decorator(say_hi)
def say_hi():
    print("你好")

say_hi()`,b=`import time

# 给任意函数"计时"的装饰器
def timer(func):
    def wrapper(*args, **kwargs):       # 收下原函数的所有参数
        start = time.time()
        result = func(*args, **kwargs)  # 执行原函数，保留返回值
        cost = time.time() - start
        print(f"{func.__name__} 耗时 {cost:.4f} 秒")
        return result
    return wrapper

@timer
def slow_add(a, b):
    time.sleep(1)
    return a + b

print(slow_add(3, 4))`,k=`slow_add 耗时 1.0012 秒
7`,R=`# with 上下文管理器：自动管理"开始 / 结束"成对的操作
with open("note.txt", "w", encoding="utf-8") as f:
    f.write("hello")
# 离开 with，文件自动关闭——哪怕中间出错也会关

# 自己也能写一个上下文管理器
from contextlib import contextmanager

@contextmanager
def timer_block():
    import time
    start = time.time()
    yield                      # yield 之前是"进入时"，之后是"离开时"
    print(f"耗时 {time.time() - start:.4f} 秒")

with timer_block():
    sum(range(1_000_000))`;function I(){return e.jsxs("article",{children:[e.jsxs(i,{children:['这一章讲三个让 Python 代码更优雅、也更"Pythonic"的概念：',e.jsx("strong",{children:"迭代器"}),"（for 循环背后的机制）、",e.jsx("strong",{children:"生成器"}),"（用 yield 边算边给、省内存）、",e.jsx("strong",{children:"装饰器"}),"（不改原函数就给它加功能）。再顺带认识一下 ",e.jsx("code",{children:"with"}),"背后的",e.jsx("strong",{children:"上下文管理器"}),"。它们在后面的实战代码里随处可见。"]}),e.jsx("h2",{children:"一、可迭代对象与 for 的背后"}),e.jsxs("p",{children:["我们早就在用 ",e.jsx("code",{children:"for"})," 遍历列表、字符串、字典——这些都叫",e.jsx("strong",{children:"可迭代对象"}),"。"]}),e.jsx(r,{lang:"python",title:"各种可迭代对象",code:x}),e.jsxs("p",{children:[e.jsx("code",{children:"for"})," 其实是个语法糖。它背后做的是：先用 ",e.jsx("code",{children:"iter()"})," 拿到一个",e.jsx("strong",{children:"迭代器"}),"，再不断调用 ",e.jsx("code",{children:"next()"})," 取下一个值，直到没有为止。"]}),e.jsx(r,{lang:"python",title:"for 背后的 iter / next",code:a}),e.jsx(r,{lang:"text",title:"运行结果",code:h}),e.jsxs(t,{children:["一个对象只要实现了 ",e.jsx("code",{children:"__iter__"}),"（返回迭代器）和 ",e.jsx("code",{children:"__next__"}),"（返回下一个值）， 就能被 ",e.jsx("code",{children:"for"})," 遍历。好在大多数时候我们不用手写这两个——用下面的生成器更简单。"]}),e.jsx("h2",{children:"二、生成器：用 yield 边算边给"}),e.jsxs("p",{children:["写一个带 ",e.jsx("code",{children:"yield"})," 的函数，它就变成了",e.jsx("strong",{children:"生成器"}),"。和普通函数",e.jsx("code",{children:"return"})," 一次就结束不同，",e.jsx("code",{children:"yield"})," 可以",e.jsx("strong",{children:"吐出一个值后暂停"}),"， 下次再要时从暂停处继续。"]}),e.jsx(r,{lang:"python",title:"第一个生成器",code:j}),e.jsx(r,{lang:"text",title:"运行结果",code:p}),e.jsx("h3",{children:"省内存：用到哪算到哪"}),e.jsxs("p",{children:["生成器最大的好处是",e.jsx("strong",{children:"省内存"}),'。列表会把所有元素一次性全造出来， 生成器则"要一个算一个"。处理大量数据时差别巨大。']}),e.jsx(r,{lang:"python",title:"列表 vs 生成器（内存）",code:m}),e.jsx(r,{lang:"text",title:"运行结果",code:g}),e.jsxs(n,{variant:"tip",title:"生成器表达式",children:["把列表推导的方括号 ",e.jsx("code",{children:"[]"})," 换成圆括号 ",e.jsx("code",{children:"()"}),"，就得到一个",e.jsx("strong",{children:"生成器表达式"}),"，写法和列表推导几乎一样，但不占内存。"]}),e.jsx("h3",{children:"惰性：不取就不算"}),e.jsxs("p",{children:["生成器是",e.jsx("strong",{children:"惰性"}),"的——你不去遍历（不 ",e.jsx("code",{children:"next"}),"），里面的代码根本不会执行。"]}),e.jsx(r,{lang:"python",title:"生成器的惰性",code:f}),e.jsx(r,{lang:"text",title:"运行结果",code:u}),e.jsxs(d,{title:"练一练",children:["写一个生成器 ",e.jsx("code",{children:"even_numbers(n)"}),"，依次 ",e.jsx("code",{children:"yield"})," 出前 n 个偶数。 用 ",e.jsx("code",{children:"for"})," 打印前 5 个，再用 ",e.jsx("code",{children:"list(even_numbers(5))"})," 一次性收集成列表看看。"]}),e.jsx("h2",{children:"三、装饰器：给函数加功能而不改它"}),e.jsxs("p",{children:["装饰器是",e.jsx("strong",{children:'"包装函数的函数"'}),"：它接收一个函数，返回一个新函数， 在不动原函数代码的前提下给它加上额外行为（如打日志、计时、权限检查）。 先看不用语法糖的原始形态："]}),e.jsx(r,{lang:"python",title:"装饰器的本质：包装函数",code:_}),e.jsx(r,{lang:"text",title:"运行结果",code:y}),e.jsx("h3",{children:"@语法：优雅写法"}),e.jsxs("p",{children:["手动写 ",e.jsx("code",{children:"say_hi = my_decorator(say_hi)"})," 太啰嗦。Python 提供",e.jsx("code",{children:"@装饰器名"})," 的语法糖，放在函数定义上面即可，效果完全一样。"]}),e.jsx(r,{lang:"python",title:"用 @ 语法",code:w}),e.jsxs(t,{children:[e.jsx("code",{children:"@my_decorator"})," 写在 ",e.jsx("code",{children:"def say_hi"})," 上面，就等于",e.jsx("code",{children:"say_hi = my_decorator(say_hi)"}),"。你在框架代码里见到的一堆 ",e.jsx("code",{children:"@xxx"}),"（如 ",e.jsx("code",{children:"@tool"}),"、",e.jsx("code",{children:"@dataclass"}),"）全是这个机制。"]}),e.jsx("h3",{children:"实用例子：给函数计时"}),e.jsxs("p",{children:["下面这个 ",e.jsx("code",{children:"@timer"})," 能给",e.jsx("strong",{children:"任意"}),"函数计时。关键是用",e.jsx("code",{children:"*args, **kwargs"})," 接住原函数的所有参数，并 ",e.jsx("code",{children:"return"})," 它的结果， 这样包装后功能不变、只是多了计时。"]}),e.jsx(r,{lang:"python",title:"计时装饰器",code:b}),e.jsx(r,{lang:"text",title:"运行结果",code:k}),e.jsx(c,{title:"为什么要 *args, **kwargs",children:e.jsxs("p",{children:["因为我们想让 ",e.jsx("code",{children:"@timer"})," 能装饰各种函数——有的没参数，有的两个参数，有的带关键字参数。",e.jsx("code",{children:"*args"})," 收集所有位置参数、",e.jsx("code",{children:"**kwargs"}),' 收集所有关键字参数， 原样转交给被包装的函数，做到"通用"。']})}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」。"]}),e.jsx(o,{initialCode:l}),e.jsx("h2",{children:"四、with 与上下文管理器一瞥"}),e.jsxs("p",{children:["前面读写文件用过 ",e.jsx("code",{children:"with"}),"。它背后是",e.jsx("strong",{children:"上下文管理器"}),'： 负责"进入时做准备、离开时做收尾"，而且',e.jsx("strong",{children:"哪怕中间出错也保证收尾"}),"（比如关文件）。我们也能用 ",e.jsx("code",{children:"@contextmanager"})," + ",e.jsx("code",{children:"yield"})," 自己写一个。"]}),e.jsx(r,{lang:"python",title:"with 与自定义上下文管理器",code:R}),e.jsxs("p",{children:["注意自定义那个里 ",e.jsx("code",{children:"yield"}),' 把代码分成两半：之前是"进入 with 时"执行， 之后是"离开 with 时"执行。这和生成器的暂停机制是同一套思想。']}),e.jsx(n,{variant:"note",title:"它们其实是一家人",children:'迭代器、生成器、上下文管理器都建立在"协议（特定的双下方法）"之上。 你不需要死记细节，记住它们各自解决什么问题，会用就够了。'}),e.jsx(s,{points:["for 背后是 iter() 拿迭代器 + 反复 next() 取值，到尽头抛 StopIteration 自动停。","带 yield 的函数是生成器：吐一个值就暂停，下次从暂停处继续；省内存、且惰性（不取不算）。","生成器表达式：把列表推导的 [] 换成 ()，写法相同但不一次性占内存。",'装饰器是"包装函数的函数"，不改原函数就加功能；@装饰器 等价于 函数 = 装饰器(函数)。',"通用装饰器用 *args, **kwargs 接住任意参数并 return 原结果，典型应用如计时、日志。",'with 背后是上下文管理器，保证"进入准备、离开收尾"（如自动关文件），可用 @contextmanager + yield 自定义。']})]})}export{I as default};
