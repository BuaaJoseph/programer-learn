import{j as e}from"./index-BAhU_Xet.js";import{L as n,S as r}from"./Summary-DeCBcqSp.js";import{K as c}from"./KeyIdea-DnEcW4Ye.js";import{C as s}from"./Callout-OljS8ooD.js";import{C as d}from"./CodeBlock-ClAC9vi8.js";import{E as l}from"./Example-D5OEBxRp.js";const i=`typeof "hi"          // "string"
typeof 42            // "number"
typeof true          // "boolean"
typeof undefined     // "undefined"
typeof Symbol("id")  // "symbol"
typeof 10n           // "bigint"
typeof {}            // "object"
typeof [1, 2]        // "object"  ← 数组也是 object
typeof function(){}  // "function"（函数是可调用对象的特例）
typeof null          // "object"  ← 著名的历史 bug，并非真的对象`,o=`// 原始值本身没有方法，但你能写 "abc".toUpperCase()
const s = "abc"
s.toUpperCase()   // "ABC"

// 背后发生了什么：引擎临时把原始值「装箱」成包装对象
// 大致等价于：
new String("abc").toUpperCase()
// 用完即弃，下一行 s 仍然是那个原始字符串

// 永远不要手动 new String() / new Number() / new Boolean()
typeof new String("abc")   // "object"，不是 "string"，反而制造麻烦`,j=`// 八个 falsy 值（转成布尔时为 false），其余一律 true
Boolean(false)        // false
Boolean(0)            // false
Boolean(-0)           // false
Boolean(0n)           // false（BigInt 的零）
Boolean("")           // false（空字符串）
Boolean(null)         // false
Boolean(undefined)    // false
Boolean(NaN)          // false

// 容易踩坑的 truthy 值
Boolean("0")          // true（非空字符串）
Boolean("false")      // true（非空字符串）
Boolean([])           // true（空数组也是对象）
Boolean({})           // true（空对象）`,h=`Number("42")      // 42
Number("  42  ")  // 42（首尾空白被忽略）
Number("")        // 0   ← 空字符串变 0，常见坑
Number("3.14")    // 3.14
Number("0x1F")    // 31（识别十六进制）
Number("12px")    // NaN（含非法字符整体失败）
Number(true)      // 1
Number(false)     // 0
Number(null)      // 0   ← 注意
Number(undefined) // NaN ← 与 null 不同
Number([])        // 0   （[] -> "" -> 0）
Number([5])       // 5   （[5] -> "5" -> 5）
Number([1, 2])    // NaN （[1,2] -> "1,2" -> NaN）`,x=`// + 运算符：只要有一边是字符串，就做字符串拼接
1 + 2          // 3
1 + "2"        // "12"
"1" + 2        // "12"
1 + 2 + "3"    // "33"（先 1+2=3，再 3+"3"）
"1" + 2 + 3    // "123"（先 "1"+2="12"，再 +"3"）

// 其它算术运算符（- * / %）会把两边都转成数字
"5" - 2        // 3
"5" * "2"      // 10
"abc" - 1      // NaN

// 模板字符串：内部一律走 ToString
const n = 42
\`值是 \${n}\`            // "值是 42"
\`数组：\${[1, 2, 3]}\`   // "数组：1,2,3"
\`对象：\${{a: 1}}\`      // "对象：[object Object]"`,t=`// === 严格相等：类型不同直接 false，不做任何转换
1 === 1          // true
1 === "1"        // false（number vs string）
null === undefined // false

// == 宽松相等：类型不同会先转换再比较
1 == "1"         // true（"1" 转成数字 1）
true == 1        // true（true 转成 1）
null == undefined // true（规范特例，二者互等）
null == 0        // false（null 只和 undefined 相等，不转数字）`,a=`// 经典面试题逐步推导

// 1) [] == ![]  结果竟是 true
// step1: ![] 先算 —— [] 是 truthy，所以 ![] 为 false
//        => [] == false
// step2: == 遇到布尔，把布尔转数字 false -> 0
//        => [] == 0
// step3: == 遇到 对象 vs 数字，对象走 ToPrimitive -> []转成 ""
//        => "" == 0
// step4: 字符串 vs 数字，"" 转数字 -> 0
//        => 0 == 0  => true

// 2) null == undefined  => true（规范规定，且仅此二者互等）
// 3) null == 0          => false（null 不转换为数字）
// 4) NaN == NaN         => false（NaN 不等于任何值，包括自己）
// 5) "" == 0            => true（"" -> 0）
// 6) "0" == 0           => true（"0" -> 0）
// 7) "" == "0"          => false（同为字符串，逐字符比，不等）`,u=`NaN === NaN          // false ← NaN 不等于任何值，连自己都不等
NaN == NaN           // false

// 因此判断「是不是 NaN」不能用 ===，要用专门 API
Number.isNaN(NaN)    // true
Number.isNaN("abc")  // false（不会做隐式转换，更严谨）

// 全局 isNaN 会先做 ToNumber，容易误判，少用
isNaN("abc")         // true（"abc" -> NaN）
Number.isNaN("abc")  // false（"abc" 本身不是 NaN）

// NaN 的来源：无意义的数值运算
0 / 0                // NaN
Math.sqrt(-1)        // NaN
Number("hello")      // NaN`;function y(){return e.jsxs("article",{children:[e.jsxs(n,{children:["要真正读懂 JavaScript，第一步是搞清楚它的「类型与值」。JS 是一门动态类型语言：变量本身没有类型， 类型属于它当前持有的「值」。而 JS 最被诟病、也最容易在面试与线上事故里坑人的， 正是它那套",e.jsx("strong",{children:"隐式类型转换"}),"规则。这一章我们把原始类型、",e.jsx("code",{children:"typeof"})," 的真相、 显式与隐式转换的底层规则、falsy 清单、",e.jsx("code",{children:"=="})," 与 ",e.jsx("code",{children:"==="})," 的差别， 以及 ",e.jsx("code",{children:"NaN"})," 的怪脾气，逐一讲透。"]}),e.jsx("h2",{children:"一、七种原始类型 + 对象"}),e.jsxs("p",{children:["JavaScript 的值分为两大阵营：",e.jsx("strong",{children:"原始类型（primitive）"}),"和",e.jsx("strong",{children:"对象（object）"}),"。 到今天为止，原始类型共有",e.jsx("strong",{children:"七种"}),"，其余一切（数组、函数、日期、正则……）都是对象。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"原始类型"}),e.jsx("th",{children:"说明"}),e.jsx("th",{children:"例子"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"string"})}),e.jsx("td",{children:"文本，不可变"}),e.jsx("td",{children:e.jsx("code",{children:'"hello"'})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"number"})}),e.jsx("td",{children:"双精度浮点，整数小数都是它"}),e.jsxs("td",{children:[e.jsx("code",{children:"42"})," / ",e.jsx("code",{children:"3.14"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"boolean"})}),e.jsx("td",{children:"真假"}),e.jsxs("td",{children:[e.jsx("code",{children:"true"})," / ",e.jsx("code",{children:"false"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"null"})}),e.jsx("td",{children:"「有意的空值」，主动赋的空"}),e.jsx("td",{children:e.jsx("code",{children:"null"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"undefined"})}),e.jsx("td",{children:"「未定义」，变量声明未赋值的默认值"}),e.jsx("td",{children:e.jsx("code",{children:"undefined"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"symbol"})}),e.jsx("td",{children:"唯一标识符（ES6 引入）"}),e.jsx("td",{children:e.jsx("code",{children:'Symbol("id")'})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"bigint"})}),e.jsx("td",{children:"任意精度整数（ES2020 引入）"}),e.jsx("td",{children:e.jsx("code",{children:"10n"})})]})]})]}),e.jsxs("p",{children:["原始值有两个关键特征：",e.jsx("strong",{children:"不可变（immutable）"}),"——你无法改变一个原始值本身， 只能用新值替换它；",e.jsx("strong",{children:"按值复制"}),"——把它赋给另一个变量时复制的是值本身（下一章详谈）。 而对象是",e.jsx("strong",{children:"可变的"}),"、按引用持有的，这是第二章的主题。"]}),e.jsxs(s,{variant:"info",title:"null 与 undefined 的语义差别",children:["二者都表示「空」，但语义不同：",e.jsx("code",{children:"undefined"})," 是「系统级的空」——变量声明了还没赋值、 函数没有 ",e.jsx("code",{children:"return"}),"、访问不存在的属性，都会得到它；",e.jsx("code",{children:"null"})," 是「程序员主动赋的空」—— 「这里现在故意没有值」。习惯上：要表达「暂无」用 ",e.jsx("code",{children:"null"}),"，别去手动赋 ",e.jsx("code",{children:"undefined"}),"。"]}),e.jsx("h2",{children:"二、typeof：结果与那些坑"}),e.jsxs(c,{children:[e.jsx("code",{children:"typeof"})," 返回一个描述类型的字符串。它能区分大部分原始类型， 但有两个必须背下来的特例：",e.jsx("code",{children:"typeof null"})," 返回 ",e.jsx("code",{children:'"object"'}),"（历史 bug）， 而函数会返回 ",e.jsx("code",{children:'"function"'})," 而不是 ",e.jsx("code",{children:'"object"'}),"。"]}),e.jsx(d,{lang:"js",title:"typeof 的全部结果（含坑）",code:i}),e.jsx("p",{children:"逐条说三个最容易出错的地方："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:'typeof null === "object"'})}),"：这是 JS 诞生之初遗留的 bug， 因为历史兼容无法修复，只能记住。想判断 ",e.jsx("code",{children:"null"})," 要直接写",e.jsx("code",{children:"x === null"}),"。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:["数组也是 ",e.jsx("code",{children:'"object"'})]}),"：",e.jsx("code",{children:"typeof [1,2]"})," 是",e.jsx("code",{children:'"object"'}),"，要判断数组得用 ",e.jsx("code",{children:"Array.isArray(x)"}),"。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:["函数是 ",e.jsx("code",{children:'"function"'})]}),"：函数本质是可调用的对象， 但 ",e.jsx("code",{children:"typeof"})," 特地为它返回 ",e.jsx("code",{children:'"function"'}),"，方便检测。"]})]}),e.jsx("h2",{children:"三、包装对象（一句话）"}),e.jsxs("p",{children:["既然原始值不是对象、没有方法，为什么 ",e.jsx("code",{children:'"abc".toUpperCase()'})," 能跑？ 因为引擎会在你调用方法的瞬间，把原始值临时",e.jsx("strong",{children:"装箱（autoboxing）"}),"成对应的包装对象 （",e.jsx("code",{children:"String"})," / ",e.jsx("code",{children:"Number"})," / ",e.jsx("code",{children:"Boolean"}),"），调用完即丢弃。"]}),e.jsx(d,{lang:"js",title:"自动装箱：用完即弃的包装对象",code:o}),e.jsx("h2",{children:"四、类型转换：显式 vs 隐式"}),e.jsxs("p",{children:["类型转换分两种：你",e.jsx("strong",{children:"主动调用"})," ",e.jsx("code",{children:"Number()"})," / ",e.jsx("code",{children:"String()"})," /",e.jsx("code",{children:"Boolean()"})," 的叫",e.jsx("strong",{children:"显式转换"}),"；引擎在运算时",e.jsx("strong",{children:"悄悄替你转"}),"的叫",e.jsx("strong",{children:"隐式转换（强制类型转换 / coercion）"}),"。隐式转换正是大量「诡异行为」的根源， 而它背后只有三套规则：",e.jsx("strong",{children:"ToBoolean"}),"、",e.jsx("strong",{children:"ToNumber"}),"、",e.jsx("strong",{children:"ToString"}),"（对象还要先经 ",e.jsx("strong",{children:"ToPrimitive"}),"）。"]}),e.jsx("h3",{children:"ToBoolean 与 falsy 值清单"}),e.jsxs("p",{children:["任何值放进 ",e.jsx("code",{children:"if"})," 条件、逻辑运算符里，都会走 ToBoolean。规则极简：",e.jsx("strong",{children:"记住八个 falsy 值，其余全部为 true"}),"。"]}),e.jsx(d,{lang:"js",title:"ToBoolean：八个 falsy 值",code:j}),e.jsxs(s,{variant:"warn",title:"空数组 / 空对象都是 truthy",children:["初学者最容易栽在这：",e.jsx("code",{children:"[]"})," 和 ",e.jsx("code",{children:"{}"})," 在布尔上下文里都是",e.jsx("strong",{children:"true"}),"。所以 ",e.jsx("code",{children:"if ([]) { ... }"})," 一定会进分支。 要判断数组是否为空，得看 ",e.jsx("code",{children:"arr.length === 0"}),"，而不是 ",e.jsx("code",{children:"if (!arr)"}),"。"]}),e.jsx("h3",{children:"ToNumber"}),e.jsxs("p",{children:["算术运算、一元 ",e.jsx("code",{children:"+"}),"、比较运算等会触发 ToNumber。两个最常见的坑：",e.jsx("code",{children:'Number("")'})," 是 ",e.jsx("code",{children:"0"}),"（不是 ",e.jsx("code",{children:"NaN"}),"）， 而 ",e.jsx("code",{children:"Number(null)"})," 是 ",e.jsx("code",{children:"0"}),"、",e.jsx("code",{children:"Number(undefined)"}),"却是 ",e.jsx("code",{children:"NaN"}),"。"]}),e.jsx(d,{lang:"js",title:"ToNumber：各种值转数字",code:h}),e.jsx("h3",{children:"ToString、ToPrimitive 与 + 运算符"}),e.jsxs("p",{children:["模板字符串、字符串拼接会触发 ToString。而对象转原始值要先经 ",e.jsx("strong",{children:"ToPrimitive"}),"： 引擎按场景调用对象的 ",e.jsx("code",{children:"valueOf()"})," / ",e.jsx("code",{children:"toString()"}),"。普通对象",e.jsx("code",{children:"toString()"})," 给出 ",e.jsx("code",{children:'"[object Object]"'}),"，数组的",e.jsx("code",{children:"toString()"})," 把元素用逗号连起来（",e.jsx("code",{children:"[1,2,3]"})," 变 ",e.jsx("code",{children:'"1,2,3"'}),"）—— 这正是上面 ",e.jsx("code",{children:"Number([1,2])"})," 得到 ",e.jsx("code",{children:"NaN"})," 的原因。"]}),e.jsxs("p",{children:[e.jsx("code",{children:"+"})," 是最特殊的运算符：",e.jsx("strong",{children:"只要有一边是字符串就做拼接"}),"，否则做加法； 而 ",e.jsx("code",{children:"-"})," ",e.jsx("code",{children:"*"})," ",e.jsx("code",{children:"/"})," 等永远做数字运算。"]}),e.jsx(d,{lang:"js",title:"+ 运算符 vs 模板字符串",code:x}),e.jsx(l,{title:'为什么 [] + {} 是 "[object Object]"',children:e.jsxs("p",{children:[e.jsx("code",{children:"[] + {}"})," 中两边都是对象，",e.jsx("code",{children:"+"})," 先把它们各自 ToPrimitive 成字符串：",e.jsx("code",{children:"[]"})," 变 ",e.jsx("code",{children:'""'}),"，",e.jsx("code",{children:"{}"})," 变",e.jsx("code",{children:'"[object Object]"'}),"，再拼接，得到 ",e.jsx("code",{children:'"[object Object]"'}),"。 整个过程没有任何「加法」，全是字符串转换在作祟。"]})}),e.jsx("h2",{children:"五、相等：== 与 ==="}),e.jsxs(c,{children:[e.jsx("code",{children:"==="}),"（严格相等）",e.jsx("strong",{children:"不做类型转换"}),"：类型不同直接返回 ",e.jsx("code",{children:"false"}),"。",e.jsx("code",{children:"=="}),"（宽松相等）会",e.jsx("strong",{children:"先按规则把两边转成同类型再比"}),"， 正是这套转换催生了无数反直觉的结果。结论先行：",e.jsxs("strong",{children:["默认永远用 ",e.jsx("code",{children:"==="})]}),"。"]}),e.jsx(d,{lang:"js",title:"== 与 === 对比",code:t}),e.jsx("h3",{children:"== 的转换规则（简化版）"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"两边类型"}),e.jsx("th",{children:"== 的处理"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"同类型"}),e.jsxs("td",{children:["等价于 ",e.jsx("code",{children:"==="}),"，不转换"]})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"null"})," vs ",e.jsx("code",{children:"undefined"})]}),e.jsxs("td",{children:["互等，结果 ",e.jsx("code",{children:"true"}),"；且二者不与其它任何值相等"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"number vs string"}),e.jsx("td",{children:"把 string 转成 number 再比"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"boolean 参与"}),e.jsxs("td",{children:["先把 boolean 转成 number（",e.jsx("code",{children:"true"})," → 1，",e.jsx("code",{children:"false"})," → 0）"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"object vs 原始值"}),e.jsx("td",{children:"把 object 经 ToPrimitive 转原始值再比"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["有一边是 ",e.jsx("code",{children:"NaN"})]}),e.jsxs("td",{children:["永远 ",e.jsx("code",{children:"false"})]})]})]})]}),e.jsx("h3",{children:"经典面试题逐步推导"}),e.jsxs("p",{children:["下面把几道「看起来违反直觉」的题，按规则一步步拆开。重点看 ",e.jsx("code",{children:"[] == ![]"}),"这道——它把布尔转换、ToPrimitive、字符串转数字三套规则全串了一遍。"]}),e.jsx(d,{lang:"js",title:"经典题逐步推导",code:a}),e.jsxs("p",{children:[e.jsx("code",{children:"[] == ![]"})," 为 ",e.jsx("code",{children:"true"})," 的推导链："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:["第一步：",e.jsx("code",{children:"![]"})," 先算。",e.jsx("code",{children:"[]"})," 是 truthy，取反得 ",e.jsx("code",{children:"false"}),"。式子变 ",e.jsx("code",{children:"[] == false"}),"。"]}),e.jsxs("li",{children:["第二步：",e.jsx("code",{children:"=="})," 遇到布尔，把 ",e.jsx("code",{children:"false"})," 转数字 ",e.jsx("code",{children:"0"}),"。式子变 ",e.jsx("code",{children:"[] == 0"}),"。"]}),e.jsxs("li",{children:["第三步：对象 vs 数字，",e.jsx("code",{children:"[]"})," 经 ToPrimitive 变空字符串 ",e.jsx("code",{children:'""'}),"。式子变 ",e.jsx("code",{children:'"" == 0'}),"。"]}),e.jsxs("li",{children:["第四步：字符串 vs 数字，",e.jsx("code",{children:'""'})," 转数字得 ",e.jsx("code",{children:"0"}),"。式子变 ",e.jsx("code",{children:"0 == 0"}),"，结果 ",e.jsx("code",{children:"true"}),"。"]})]}),e.jsxs(s,{variant:"tip",title:"== 的唯一推荐用法",children:["如果你坚持要用 ",e.jsx("code",{children:"=="}),"，",e.jsx("strong",{children:"只有一个场景值得"}),"：用 ",e.jsx("code",{children:"x == null"}),"同时判断 ",e.jsx("code",{children:"x"})," 是 ",e.jsx("code",{children:"null"})," 或 ",e.jsx("code",{children:"undefined"}),"——这正好利用了 「",e.jsx("code",{children:"null"})," 与 ",e.jsx("code",{children:"undefined"})," 互等」的特例，简洁且无歧义。其余一律用 ",e.jsx("code",{children:"==="}),"。"]}),e.jsx("h2",{children:"六、NaN：不等于自己的值"}),e.jsxs("p",{children:[e.jsx("code",{children:"NaN"}),"（Not a Number）是 number 类型里的一个特殊值，代表「无意义的数值运算结果」。 它有一个独一无二的性质：",e.jsx("strong",{children:"不等于任何值，包括它自己"}),"。"]}),e.jsx(d,{lang:"js",title:"NaN 的特性与正确判断",code:u}),e.jsxs("p",{children:["正因为 ",e.jsx("code",{children:"NaN === NaN"})," 是 ",e.jsx("code",{children:"false"}),"，判断一个值是不是 ",e.jsx("code",{children:"NaN"}),"不能用相等运算，要用 ",e.jsx("code",{children:"Number.isNaN(x)"}),"。注意它和全局 ",e.jsx("code",{children:"isNaN(x)"}),"的区别：全局版会先对参数做 ToNumber，导致 ",e.jsx("code",{children:'isNaN("abc")'})," 误报为 ",e.jsx("code",{children:"true"}),"； 而 ",e.jsx("code",{children:"Number.isNaN"})," 只在参数",e.jsx("strong",{children:"本身就是 NaN"})," 时才返回 ",e.jsx("code",{children:"true"}),"，更严谨，优先用它。"]}),e.jsx("h2",{children:"七、易错点小结"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"typeof null"})," 是 ",e.jsx("code",{children:'"object"'}),"，判断 null 用 ",e.jsx("code",{children:"=== null"}),"。"]}),e.jsxs("li",{children:["判断数组用 ",e.jsx("code",{children:"Array.isArray()"}),"，不要用 ",e.jsx("code",{children:"typeof"}),"。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"[]"})," 和 ",e.jsx("code",{children:"{}"})," 都是 truthy；空字符串、",e.jsx("code",{children:"0"}),"、",e.jsx("code",{children:"NaN"})," 才是 falsy。"]}),e.jsxs("li",{children:[e.jsx("code",{children:'Number("")'})," 与 ",e.jsx("code",{children:"Number(null)"})," 都是 ",e.jsx("code",{children:"0"}),"，",e.jsx("code",{children:"Number(undefined)"})," 是 ",e.jsx("code",{children:"NaN"}),"。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"+"})," 一边是字符串就拼接；其余算术运算符一律转数字。"]}),e.jsxs("li",{children:["默认用 ",e.jsx("code",{children:"==="}),"；仅在判空时可用 ",e.jsx("code",{children:"x == null"}),"。"]}),e.jsxs("li",{children:["判断 NaN 用 ",e.jsx("code",{children:"Number.isNaN"}),"，不要用 ",e.jsx("code",{children:"==="})," 也别用全局 ",e.jsx("code",{children:"isNaN"}),"。"]})]}),e.jsx(r,{points:["JS 的值分原始类型与对象；原始类型共七种：string / number / boolean / null / undefined / symbol / bigint，其余皆为对象。",'typeof 有两大特例：typeof null 是 "object"（历史 bug），函数是 "function"；判断 null 用 === null，判断数组用 Array.isArray。',"原始值调用方法靠「自动装箱」临时生成包装对象，用完即弃；切勿手动 new String/Number/Boolean。","隐式转换只有三套规则 ToBoolean / ToNumber / ToString（对象先经 ToPrimitive）；八个 falsy 值之外全为 truthy，空数组空对象都是 true。",'+ 只要一边是字符串就拼接，其余算术运算转数字；模板字符串一律走 ToString，对象得到 "[object Object]"。',"=== 不转换类型，== 会先转换再比；默认永远用 ===，仅判空可用 x == null。[] == ![] 为 true 是布尔/ToPrimitive/字符串转数字三规则叠加的结果。","NaN 不等于任何值（含自己），判断是否为 NaN 必须用 Number.isNaN，而非 === 或全局 isNaN。"]})]})}export{y as default};
