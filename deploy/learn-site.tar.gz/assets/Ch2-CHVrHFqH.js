import{j as e}from"./index-DL563RIm.js";import{L as o,S as i}from"./Summary-BrgLcNDp.js";import{K as r}from"./KeyIdea-exK4GrdK.js";import{C as t}from"./Callout-B-8nslAm.js";import{C as s}from"./CodeBlock-DkVyd3P6.js";import{E as d}from"./Example-HxOmIesu.js";const n=`import Foundation

// 最简单的 GET：data(from:) 直接接收一个 URL
let url = URL(string: "https://api.example.com/users")!
let (data, response) = try await URLSession.shared.data(from: url)
// data 是返回的字节，response 是 URLResponse（含状态码、头等）`,c=`// 需要自定义方法 / 请求头 / 请求体时，构造 URLRequest，
// 再用 data(for:) 发送
var request = URLRequest(url: URL(string: "https://api.example.com/login")!)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.setValue("Bearer \\(token)", forHTTPHeaderField: "Authorization")

let body = ["username": "alice", "password": "secret"]
request.httpBody = try JSONEncoder().encode(body)

let (data, response) = try await URLSession.shared.data(for: request)`,l=`import Foundation

// 同时遵守 Encodable + Decodable，可写成 Codable
struct User: Codable {
    let id: Int
    let name: String
    let email: String
}

// 解码：JSON -> 模型
let user = try JSONDecoder().decode(User.self, from: data)

// 编码：模型 -> JSON
let json = try JSONEncoder().encode(user)`,a=`// 后端字段是 snake_case，本地想用 Swift 风格的 camelCase
struct Article: Codable {
    let id: Int
    let title: String
    let authorName: String
    let publishedAt: Date

    // 方式一：CodingKeys 逐个改名
    enum CodingKeys: String, CodingKey {
        case id, title
        case authorName = "author_name"
        case publishedAt = "published_at"
    }
}

// 方式二：不写 CodingKeys，让解码器统一转换
let decoder = JSONDecoder()
decoder.keyDecodingStrategy = .convertFromSnakeCase   // author_name -> authorName
decoder.dateDecodingStrategy = .iso8601               // 日期按 ISO8601 解析`,h=`// 嵌套模型：结构嵌套，Codable 会自动递归解码
struct Feed: Codable {
    let page: Int
    let articles: [Article]   // 数组成员也是 Codable
    let author: Author        // 嵌套对象
}

struct Author: Codable {
    let id: Int
    let name: String
    let avatarURL: URL        // URL 本身就是 Codable
}`,x=`import Foundation

// 自定义错误：把网络层可能出的问题归类
enum APIError: Error {
    case invalidResponse          // 不是 HTTPURLResponse
    case httpStatus(Int)          // 服务器返回了非 2xx 状态码
    case decoding(Error)          // JSON 解码失败
}

func fetchUser(id: Int) async throws -> User {
    let url = URL(string: "https://api.example.com/users/\\(id)")!
    let (data, response) = try await URLSession.shared.data(from: url)

    // 1. 检查响应类型
    guard let http = response as? HTTPURLResponse else {
        throw APIError.invalidResponse
    }
    // 2. 检查 HTTP 状态码（200..<300 才算成功）
    guard (200..<300).contains(http.statusCode) else {
        throw APIError.httpStatus(http.statusCode)
    }
    // 3. 解码，失败时包装成自定义错误
    do {
        return try JSONDecoder().decode(User.self, from: data)
    } catch {
        throw APIError.decoding(error)
    }
}`,j=`import Foundation

// 协议：对上层只暴露干净的 async 接口，便于替换 / 测试
protocol UserRepository {
    func loadUsers() async throws -> [User]
}

// 实现：内部封装「网络拉取 + 本地缓存」
final class DefaultUserRepository: UserRepository {
    private let session: URLSession
    private let cache: UserCache   // 例如包一层 SwiftData / 文件缓存

    init(session: URLSession = .shared, cache: UserCache) {
        self.session = session
        self.cache = cache
    }

    func loadUsers() async throws -> [User] {
        do {
            // 优先走网络
            let url = URL(string: "https://api.example.com/users")!
            let (data, response) = try await session.data(from: url)
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode) else {
                throw APIError.invalidResponse
            }
            let users = try JSONDecoder().decode([User].self, from: data)
            await cache.save(users)     // 成功则更新本地缓存
            return users
        } catch {
            // 网络失败时回退到缓存，保证离线也能用
            if let cached = await cache.load(), !cached.isEmpty {
                return cached
            }
            throw error
        }
    }
}`,p=`import SwiftUI

// iOS 17 起用 @Observable 宏标注 ViewModel：
// 属性变化自动驱动 SwiftUI 视图刷新
@Observable
final class UserListViewModel {
    var users: [User] = []
    var isLoading = false
    var errorMessage: String?

    private let repository: UserRepository
    init(repository: UserRepository) {
        self.repository = repository
    }

    // @MainActor 保证 UI 状态在主线程更新
    @MainActor
    func load() async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            users = try await repository.loadUsers()   // 调用 Repository 的 async 接口
        } catch {
            errorMessage = "加载失败：\\(error.localizedDescription)"
        }
    }
}

// 视图里触发
struct UserListView: View {
    @State private var vm: UserListViewModel

    var body: some View {
        List(vm.users) { user in Text(user.name) }
            .overlay { if vm.isLoading { ProgressView() } }
            .task { await vm.load() }   // 视图出现时发起加载
    }
}`,u=`// 并发：用 async let 同时发多个请求，再一起 await（总耗时≈最慢的那个）
async let profile = fetchProfile(id: id)
async let posts   = fetchPosts(userID: id)
let (p, ps) = try await (profile, posts)

// 超时：在 URLSessionConfiguration 上配置请求 / 资源超时
let config = URLSessionConfiguration.default
config.timeoutIntervalForRequest = 15   // 单次请求超时（秒）
let session = URLSession(configuration: config)`;function w(){return e.jsxs("article",{children:[e.jsxs(o,{children:["上一章我们把数据存在了本地，但 App 的另一半数据来自",e.jsx("strong",{children:"网络"}),"：从服务器拉列表、 提交表单、登录鉴权……这一章讲 iOS 网络数据层的两大主角——用 ",e.jsx("code",{children:"async"})," 风格的",e.jsx("strong",{children:"URLSession"})," 发请求，用 ",e.jsx("strong",{children:"Codable"})," 把 JSON 自动编解码成模型。 然后我们把错误处理做扎实，再用一个 ",e.jsx("strong",{children:"Repository"})," 把「网络 + 本地缓存」 封装起来，对上层 ViewModel 只暴露干净的 ",e.jsx("code",{children:"async"})," 接口。"]}),e.jsx("h2",{children:"一、URLSession：iOS 的网络入口"}),e.jsxs("p",{children:[e.jsx("code",{children:"URLSession"})," 是苹果内置的网络框架，发 HTTP 请求、下载上传文件都靠它。 过去它用回调（completion handler）风格，回调嵌回调容易写成「回调地狱」。 从 Swift 并发（",e.jsx("code",{children:"async/await"}),"）登场后，",e.jsx("code",{children:"URLSession"})," 提供了",e.jsx("code",{children:"async"})," 版本的方法，写网络请求变得像写同步代码一样直白。"]}),e.jsxs(r,{children:["现代 iOS 网络请求的骨架就两行：用 ",e.jsx("code",{children:"try await URLSession.shared.data(...)"}),"拿到 ",e.jsx("code",{children:"(data, response)"}),"，再把 ",e.jsx("code",{children:"data"})," 交给 ",e.jsx("code",{children:"JSONDecoder"}),"解成模型。请求是",e.jsx("strong",{children:"异步"}),"的（用 ",e.jsx("code",{children:"await"})," 等待、用 ",e.jsx("code",{children:"try"})," 接错误）， 但代码读起来是",e.jsx("strong",{children:"顺序"}),"的。"]}),e.jsx(s,{lang:"swift",title:"最简单的 GET：data(from:)",code:n}),e.jsxs("p",{children:["要自定义请求——指定方法（POST / PUT / DELETE）、加请求头（如 ",e.jsx("code",{children:"Authorization"}),"）、 带请求体——就先构造一个 ",e.jsx("code",{children:"URLRequest"}),"，再用 ",e.jsx("code",{children:"data(for:)"})," 发送。"]}),e.jsx(s,{lang:"swift",title:"自定义请求：URLRequest + data(for:)",code:c}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方法"}),e.jsx("th",{children:"用途"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"data(from: URL)"})}),e.jsx("td",{children:"最简单的 GET，只给一个 URL"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"data(for: URLRequest)"})}),e.jsx("td",{children:"自定义方法 / 头 / 请求体时用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"URLRequest.httpMethod"})}),e.jsx("td",{children:"设置 GET / POST / PUT / DELETE 等"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"setValue(_:forHTTPHeaderField:)"})}),e.jsx("td",{children:"设置请求头"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"URLRequest.httpBody"})}),e.jsx("td",{children:"设置请求体（通常是编码后的 JSON）"})]})]})]}),e.jsx("h2",{children:"二、Codable：JSON 与模型的自动桥梁"}),e.jsxs("p",{children:["网络返回的几乎都是 JSON 字节。把 JSON 变成 Swift 模型对象（解码），或把模型变回 JSON（编码）， 就是 ",e.jsx("strong",{children:"Codable"})," 干的事。",e.jsx("code",{children:"Codable"})," 其实是",e.jsx("code",{children:"Encodable"}),"（可编码）与 ",e.jsx("code",{children:"Decodable"}),"（可解码）两个协议的合称。 只要你的模型里每个属性的类型都是 Codable 的（Swift 标准类型大都如此）， 编译器就",e.jsx("strong",{children:"自动"}),"帮你生成编解码代码，一行不用写。"]}),e.jsx(s,{lang:"swift",title:"遵守 Codable，自动编解码",code:l}),e.jsx("h3",{children:"CodingKeys：字段改名"}),e.jsxs("p",{children:["现实里后端常用 ",e.jsx("code",{children:"snake_case"}),"（如 ",e.jsx("code",{children:"author_name"}),"），而 Swift 习惯",e.jsx("code",{children:"camelCase"}),"（如 ",e.jsx("code",{children:"authorName"}),"）。两种对齐方式：要么用 ",e.jsx("code",{children:"CodingKeys"}),"枚举逐个映射，要么给解码器设 ",e.jsx("code",{children:"keyDecodingStrategy = .convertFromSnakeCase"})," 统一转换。"]}),e.jsx(s,{lang:"swift",title:"CodingKeys 改名 + 日期解码策略",code:a}),e.jsx("h3",{children:"嵌套模型与日期"}),e.jsxs("p",{children:["JSON 经常层层嵌套：一个对象里有数组、数组里又是对象。Codable 会",e.jsx("strong",{children:"递归"}),"处理—— 只要每一层的类型都遵守 Codable，整棵树就自动解开。日期则需要告诉解码器格式：",e.jsx("code",{children:"dateDecodingStrategy = .iso8601"})," 是最常见的选择，时间戳可用 ",e.jsx("code",{children:".secondsSince1970"}),"。"]}),e.jsx(s,{lang:"swift",title:"嵌套模型自动递归解码",code:h}),e.jsxs(t,{variant:"info",title:"为什么解码会失败",children:["最常见的解码错误是",e.jsx("strong",{children:"类型 / 字段对不上"}),"：JSON 里是字符串你声明成了 ",e.jsx("code",{children:"Int"}),"、 某个字段后端没返回但你声明成了非可选、或字段名拼错。把",e.jsx("strong",{children:"可能缺失"}),"的字段声明为 可选（",e.jsx("code",{children:"String?"}),"），并在调试时打印 ",e.jsx("code",{children:"DecodingError"})," 的详情，能快速定位问题。"]}),e.jsx("h2",{children:"三、错误处理：别只盯着「成功路径」"}),e.jsx("p",{children:"网络是最不可靠的一环：可能断网、超时、服务器返回 500、返回的 JSON 格式变了。 一个健壮的网络层要把这些都考虑进去。关键有三步："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"检查响应类型"}),"：把 ",e.jsx("code",{children:"URLResponse"})," 转成 ",e.jsx("code",{children:"HTTPURLResponse"})," 才能读状态码。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"检查 HTTP 状态码"}),"：只有 ",e.jsx("code",{children:"200..<300"})," 才算成功，其余（401、404、500…）应抛错。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"包装解码错误"}),"：把底层的 ",e.jsx("code",{children:"DecodingError"})," 归到自己的错误类型里，便于上层统一处理。"]})]}),e.jsxs("p",{children:["Swift 里通常用 ",e.jsx("code",{children:"throws"})," + 自定义 ",e.jsx("code",{children:"enum: Error"})," 来表达错误； 如果不想用抛错，也可以用 ",e.jsx("code",{children:"Result<Success, Failure>"})," 把成功与失败包在一个返回值里。 两种风格都常见，本课统一用 ",e.jsx("code",{children:"async throws"}),"。"]}),e.jsx(s,{lang:"swift",title:"带状态码检查与错误包装的请求",code:x}),e.jsx("h2",{children:"四、Repository：把数据层封装起来"}),e.jsxs(r,{children:["不要让 ViewModel 直接写 ",e.jsx("code",{children:"URLSession"})," 和 ",e.jsx("code",{children:"JSONDecoder"}),"。把网络请求、 缓存读写、错误归类都收进一个 ",e.jsx("strong",{children:"Repository（仓库）"}),"，对上层只暴露 像 ",e.jsx("code",{children:"func loadUsers() async throws -> [User]"})," 这样干净的 ",e.jsx("code",{children:"async"})," 接口。 这样 ViewModel 不关心数据从网络还是缓存来，测试时还能换成假的 Repository。"]}),e.jsxs("p",{children:["Repository 是数据层的「门面」。把它定义成",e.jsx("strong",{children:"协议"}),"，再给一个默认实现，好处有三： ① 上层与实现解耦，换数据源不动 UI；② 缓存策略（先网络后缓存、离线回退）集中在一处； ③ 测试时注入 mock 实现，不必真的发网络。"]}),e.jsx(s,{lang:"swift",title:"UserRepository：网络 + 缓存回退",code:j}),e.jsx("h2",{children:"五、在 @Observable ViewModel 里调用"}),e.jsxs("p",{children:["iOS 17 起，ViewModel 推荐用 ",e.jsx("code",{children:"@Observable"})," 宏标注：它让 ViewModel 的属性变化 自动驱动 SwiftUI 刷新，比老的 ",e.jsx("code",{children:"ObservableObject"})," + ",e.jsx("code",{children:"@Published"})," 更简洁。 ViewModel 持有 Repository，在 ",e.jsx("code",{children:"async"})," 方法里调用它，并维护 ",e.jsx("code",{children:"isLoading"}),"、",e.jsx("code",{children:"errorMessage"})," 等界面状态。注意用 ",e.jsx("code",{children:"@MainActor"})," 保证 UI 状态在主线程更新。"]}),e.jsx(d,{title:"一条完整的数据流",children:e.jsxs("p",{children:["视图 ",e.jsx("code",{children:".task"})," 触发 → ViewModel 的 ",e.jsx("code",{children:"load()"})," 调",e.jsx("code",{children:"repository.loadUsers()"})," → Repository 先发网络、失败回退缓存 → 结果写回 ",e.jsx("code",{children:"vm.users"})," → ",e.jsx("code",{children:"@Observable"})," 通知 SwiftUI →",e.jsx("code",{children:"List"})," 自动重绘。整条链路里 UI 只认 ViewModel，根本不知道网络长什么样。"]})}),e.jsx(s,{lang:"swift",title:"@Observable ViewModel + 视图触发",code:p}),e.jsx("h2",{children:"六、并发请求与超时（一句话版）"}),e.jsxs("p",{children:[e.jsx("strong",{children:"并发"}),"：用 ",e.jsx("code",{children:"async let"})," 同时发起多个互不依赖的请求，再一起 ",e.jsx("code",{children:"await"}),"， 总耗时约等于最慢的那个，而非各自相加；",e.jsx("strong",{children:"超时"}),"：在",e.jsx("code",{children:"URLSessionConfiguration"})," 上设 ",e.jsx("code",{children:"timeoutIntervalForRequest"})," 控制单次请求等待上限。"]}),e.jsx(s,{lang:"swift",title:"async let 并发与超时配置",code:u}),e.jsx("h2",{children:"七、边界与注意事项"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"状态码不等于成功"}),"：请求「发出去并收到回应」和「业务成功」是两回事，必须显式检查状态码。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"主线程更新 UI"}),"：网络回来后改 UI 状态要回到主线程，用 ",e.jsx("code",{children:"@MainActor"})," 标注最省心。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"缺失字段要可选"}),"：后端可能不返回某字段，声明为可选能避免整次解码失败。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"不要在 View 里直接发请求"}),"：把网络收进 Repository，View 只通过 ViewModel 拿数据。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"敏感信息别硬编码"}),"：token、密钥不要写死在代码里，更不要随手 print 出来。"]})]}),e.jsxs(t,{variant:"tip",children:["到这里，本地持久化（SwiftData）与网络数据层（URLSession + Codable）就凑齐了 App 的两半数据来源。 把它们用 Repository 缝合，再用 ",e.jsx("code",{children:"@Observable"})," ViewModel 暴露给界面， 你就有了一套清晰、可测试、可离线的现代 iOS 数据层。"]}),e.jsx(i,{points:["用 async 版 URLSession 发请求：data(from:) 适合简单 GET，data(for:) 配合 URLRequest 设置方法 / 头 / 体。","Codable = Encodable + Decodable，编译器自动生成编解码；CodingKeys 或 keyDecodingStrategy 改名，dateDecodingStrategy 解析日期，嵌套模型自动递归。","错误处理三步：转 HTTPURLResponse、检查 200..<300 状态码、包装 DecodingError；用 async throws 与自定义 Error，或用 Result。","用 Repository（协议 + 实现）封装网络 + 本地缓存，对上层只暴露 async 接口，便于解耦、集中缓存策略与测试。","在 @Observable ViewModel 里调用 Repository 的 async 方法，维护 isLoading / errorMessage，用 @MainActor 在主线程更新 UI，视图用 .task 触发。","并发用 async let 同时发多请求再一起 await；超时在 URLSessionConfiguration 的 timeoutIntervalForRequest 配置。"]})]})}export{w as default};
