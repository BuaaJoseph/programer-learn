import{j as e}from"./index-BnUyEu5E.js";import{L as i,S as r}from"./Summary-qZ1-DBVA.js";import{K as n}from"./KeyIdea-DOTgzjr8.js";import{E as c}from"./Example-BRazL43h.js";import{P as l}from"./Practice-CbyZMrNx.js";import{C as d}from"./Callout-DUAtr8Nz.js";import{C as s}from"./CodeBlock-DIEQOVpA.js";const t=`PUT /products
{
  "settings": {
    "number_of_shards": 3,
    "number_of_replicas": 1
  },
  "mappings": {
    "properties": {
      "title":     { "type": "text" },
      "brand":     { "type": "keyword" },
      "price":     { "type": "double" },
      "stock":     { "type": "integer" },
      "tags":      { "type": "keyword" },
      "created_at":{ "type": "date" }
    }
  }
}`,o=`PUT /products/_doc/1001
{
  "title": "无线蓝牙耳机 降噪版",
  "brand": "Acme",
  "price": 299.0,
  "stock": 120,
  "tags": ["耳机", "蓝牙", "降噪"],
  "created_at": "2026-06-16"
}

GET /products/_doc/1001`,x=`# 对象数组场景：一个订单含多个商品行
PUT /orders
{
  "mappings": {
    "properties": {
      "items": {
        "type": "nested",
        "properties": {
          "sku":   { "type": "keyword" },
          "qty":   { "type": "integer" }
        }
      }
    }
  }
}

# nested 查询：sku=A 且 qty>=2 必须是「同一个」商品行
GET /orders/_search
{
  "query": {
    "nested": {
      "path": "items",
      "query": {
        "bool": {
          "must": [
            { "term":  { "items.sku": "A" } },
            { "range": { "items.qty": { "gte": 2 } } }
          ]
        }
      }
    }
  }
}`,h=`# 改不了字段类型，正确姿势：建新索引 + reindex + 切别名
PUT /products_v2 { "mappings": { "properties": { "brand": { "type": "keyword" } } } }

POST _reindex
{
  "source": { "index": "products" },
  "dest":   { "index": "products_v2" }
}

# 用别名做无缝切换，业务始终访问 products_alias
POST _aliases
{
  "actions": [
    { "remove": { "index": "products",    "alias": "products_alias" } },
    { "add":    { "index": "products_v2", "alias": "products_alias" } }
  ]
}`;function _(){return e.jsxs(e.Fragment,{children:[e.jsx(i,{children:e.jsxs("p",{children:["刚从关系型数据库转过来的人，第一反应总是问：",e.jsx("em",{children:"Elasticsearch"})," 里的「表」在哪、「建表语句」在哪？ 答案是：索引就是它的「表」，文档就是「行」，而决定一张表长什么样、字段怎么存的，是一份叫",e.jsx("em",{children:"mapping"})," 的结构定义。把这套对应关系搞清楚，后面的查询、聚合、分片才有立足点。"]})}),e.jsx("h2",{children:"从关系型数据库类比过来"}),e.jsx("p",{children:"最快的入门方式是做一组类比。它们并不严格相等，但足以让你建立直觉："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"index（索引）"}),"≈ 数据库里的「表」，是一类文档的集合，比如「商品索引」「订单索引」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"document（文档）"}),"≈ 表里的一「行」，但它是一段 JSON，而不是固定列的元组。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"field（字段）"}),"≈ 表里的「列」，是 JSON 里的一个个 key。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"mapping（映射）"}),"≈ 「表结构 / DDL」，规定每个字段是什么类型、怎么被索引。"]})]}),e.jsx("p",{children:"注意一个关键差异：关系型数据库的行必须严格符合表结构，而 Elasticsearch 的文档是 JSON，天然支持嵌套、数组、 可有可无的字段。这种灵活也带来一个坑——如果你不提前定义 mapping，它会替你「猜」，猜错了后面很难收场。"}),e.jsxs("p",{children:["还有一组术语别答漏：早期 ES 有 ",e.jsx("strong",{children:"type"}),"（类似一张表里再分子表），但 7.x 起一个 index 只允许一个 type （固定为 ",e.jsx("code",{children:"_doc"}),"），8.x 彻底移除。面试若被问「index 和 type 关系」，直接说「type 已废弃，一个 index 一类文档」即可。"]}),e.jsx("h3",{children:"mapping 里的常见字段类型"}),e.jsx("p",{children:"mapping 的核心是给每个字段挑对类型，挑错了会直接影响能不能搜、能不能聚合。最常用的几类："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"text"}),"：会被",e.jsx("strong",{children:"分词"}),"（拆成一个个词条），用于全文检索，比如商品标题、文章正文。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"keyword"}),"：",e.jsx("strong",{children:"不分词"}),"，整体作为一个值，用于精确匹配、排序、聚合，比如品牌、状态、标签。"]}),e.jsxs("li",{children:["数值类型：",e.jsx("code",{children:"integer"})," / ",e.jsx("code",{children:"long"})," / ",e.jsx("code",{children:"double"})," 等，用于范围查询和数值聚合，比如价格、库存。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"date"}),"：日期类型，支持范围过滤和按时间聚合，比如创建时间。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"boolean"}),"、",e.jsx("code",{children:"ip"}),"、",e.jsx("code",{children:"geo_point"}),"：分别用于布尔过滤、IP 检索、地理位置（「附近的商家」）。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"nested"}),"：用于「对象数组」且需要保持对象内字段关联的场景，比如一个订单里的多个商品行。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"object"}),"：普通嵌套对象，会被打平存储；",e.jsx("code",{children:"dense_vector"}),"：存向量做 kNN 语义检索。"]})]}),e.jsx("h3",{children:"为什么对象数组要用 nested"}),e.jsxs("p",{children:["这是个高频且阴险的坑。默认的 ",e.jsx("code",{children:"object"})," 类型会把对象数组",e.jsx("strong",{children:"打平（flatten）"}),"：",e.jsx("code",{children:"items: [{sku:A, qty:1}, {sku:B, qty:5}]"})," 会被存成",e.jsx("code",{children:"items.sku:[A,B]"})," 和 ",e.jsx("code",{children:"items.qty:[1,5]"})," 两个独立数组——字段间的对应关系丢了。 于是查询「sku=A 且 qty=5」会错误命中（因为 A 在 sku 数组里、5 在 qty 数组里，分开看都满足）。",e.jsx("code",{children:"nested"})," 类型把每个子对象当成",e.jsx("strong",{children:"独立的隐藏文档"}),"来索引，才能保证「同一行内」的条件关联。 代价是写入和查询都更重，所以只在真的需要「数组内对象字段联动」时才用它。"]}),e.jsx(s,{lang:"json",title:"nested 类型与查询",code:x}),e.jsx("h3",{children:"动态映射 vs 显式映射"}),e.jsxs("p",{children:["当你往一个还没定义 mapping 的索引里写文档时，Elasticsearch 会启动",e.jsx("em",{children:"动态映射"}),"（dynamic mapping）： 看到一个字符串就自动给它配上 ",e.jsx("code",{children:"text"})," 加 ",e.jsx("code",{children:"keyword"})," 的组合，看到数字就配数值类型。 方便是方便，但它的猜测经常不是你想要的——比如把一个只该精确匹配的订单号猜成了 ",e.jsx("code",{children:"text"}),"。"]}),e.jsxs("p",{children:["生产环境的建议是",e.jsx("strong",{children:"显式映射"}),"（explicit mapping）：建索引时就把每个字段类型写清楚， 把动态映射当成临时探索用的兜底，而不是依赖它。动态映射还有两个隐患要知道：一是",e.jsx("strong",{children:"字段爆炸（mapping explosion）"}),"， 如果日志里有大量不固定的 key，会自动生成成千上万字段拖垮集群，可设 ",e.jsx("code",{children:"dynamic: strict"})," 或限制字段数； 二是",e.jsx("strong",{children:"类型冲突"}),"，同一字段第一次是数字、后来写了字符串，会直接报 mapper parsing 错误。"]}),e.jsxs(c,{title:"商品索引该怎么设计 mapping",children:[e.jsx("p",{children:"假设要做一个电商商品搜索，字段和类型这样分配才合理："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"title"})," 用 ",e.jsx("code",{children:"text"}),"：用户要按「降噪耳机」这种关键词做全文搜索。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"brand"}),"、",e.jsx("code",{children:"tags"})," 用 ",e.jsx("code",{children:"keyword"}),"：要按品牌精确筛选、要做「各品牌商品数」的聚合。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"price"}),"、",e.jsx("code",{children:"stock"})," 用数值类型：要做价格区间过滤、按价格排序。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"created_at"})," 用 ",e.jsx("code",{children:"date"}),"：要做「最近上架」的时间范围过滤。"]})]}),e.jsxs("p",{children:["如果偷懒把 ",e.jsx("code",{children:"brand"})," 设成了 ",e.jsx("code",{children:"text"}),"，你会发现按品牌聚合时报错或结果被拆成了词条—— 这就是类型选错的典型代价。"]})]}),e.jsx(n,{title:"mapping 一旦定下来，很难改",children:e.jsxs("p",{children:["这是面试高频考点：已有字段的",e.jsx("strong",{children:"类型不能直接修改"}),"。你可以给索引",e.jsx("strong",{children:"新增"}),"字段， 但不能把一个 ",e.jsx("code",{children:"text"})," 改成 ",e.jsx("code",{children:"keyword"}),"，因为底层倒排索引已经按旧类型建好了。 真要改，只能新建一个目标 mapping 的索引，再用 ",e.jsx("code",{children:"_reindex"})," 把数据搬过去，最后切别名。 所以「设计阶段把 mapping 想清楚」远比「上线后补救」划算。"]})}),e.jsxs(d,{variant:"info",title:"reindex + 别名 = 不停机改结构",children:[e.jsxs("p",{children:["生产里改 mapping 的标准流程不是直接改，而是「建新索引 → reindex 灌数据 → 切别名」。 关键在",e.jsx("strong",{children:"别名（alias）"}),"：业务代码永远访问 ",e.jsx("code",{children:"products_alias"})," 而不是具体索引名， 切换时一条原子的 ",e.jsx("code",{children:"_aliases"})," 命令把别名从旧索引指到新索引，业务无感知。这套打法也是 索引滚动（rollover）、零停机升级的基础，值得作为一个固定套路记住。"]}),e.jsx(s,{lang:"json",title:"reindex 改结构 + 别名切换",code:h})]}),e.jsxs(d,{variant:"warn",title:"text 和 keyword 别用混了",children:[e.jsx("p",{children:"记住这条判断准则，能避免大量返工："}),e.jsxs("ul",{children:[e.jsxs("li",{children:["需要",e.jsx("strong",{children:"全文检索"}),"（输入一部分词就能命中）→ 用 ",e.jsx("code",{children:"text"}),"。"]}),e.jsxs("li",{children:["需要",e.jsx("strong",{children:"精确匹配、排序、聚合"}),"（整体相等、分组统计）→ 用 ",e.jsx("code",{children:"keyword"}),"。"]}),e.jsxs("li",{children:["两者都要？用",e.jsx("strong",{children:"多字段"}),"（multi-field）：主字段 ",e.jsx("code",{children:"text"}),"，再挂一个 ",e.jsx("code",{children:"title.keyword"})," 子字段，鱼和熊掌兼得。"]})]})]}),e.jsx("h2",{children:"每个文档自带的两个元字段：_source 和 _id"}),e.jsxs("p",{children:["除了你写进去的业务字段，每个文档还有两个绕不开的元字段。",e.jsx("code",{children:"_id"})," 是文档的唯一标识， 你可以自己指定（比如用商品 ID），不指定则由系统生成；它还决定了文档被路由到哪个分片（下一章细讲）。"]}),e.jsxs("p",{children:[e.jsx("code",{children:"_source"})," 则是 Elasticsearch 完整保存的那份",e.jsx("strong",{children:"原始 JSON"}),"。搜索时返回给你的文档内容、 以及将来要 ",e.jsx("code",{children:"_reindex"})," 或 ",e.jsx("code",{children:"update"})," 时依赖的原文，全靠它。把 ",e.jsx("code",{children:"_source"})," 关掉能省存储， 但会让很多操作没法做，一般不建议关。"]}),e.jsxs("p",{children:["还有几个常被问到的元字段：",e.jsx("code",{children:"_version"}),"（版本号，做乐观并发控制，下一卷写入会用到）、",e.jsx("code",{children:"_routing"}),"（自定义路由值，默认就是 ",e.jsx("code",{children:"_id"}),"）、",e.jsx("code",{children:"_index"}),"（所属索引名）。 理解 ",e.jsx("code",{children:"_id"})," 既是主键又是默认路由值，是连接「mapping」和「分片路由」两章的关键纽带。"]}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["被问到「Elasticsearch 和 MySQL 的对应关系」时，按 ",e.jsx("em",{children:"index≈表、document≈行、field≈列、mapping≈表结构"}),"这条主线答，再补一句「但文档是 JSON、支持嵌套，且 mapping 字段类型定了不能改、只能 reindex」， 立刻显得你真用过。被追问 ",e.jsx("code",{children:"text"})," 和 ",e.jsx("code",{children:"keyword"})," 区别时，落到「分词 vs 不分词、全文检索 vs 精确聚合」， 并主动提多字段方案，基本就稳了。"]}),e.jsx(d,{variant:"info",title:"面试追问与误区",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"「能不能改字段类型？」"}),"——已有字段类型不可改，只能新增字段或 reindex；答出别名切换是加分项。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"误区：对象数组随便用 object"}),"——会打平丢失字段关联，需要联动条件时必须 nested。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"「动态映射有什么风险？」"}),"——字段爆炸和类型冲突，生产建议显式映射 + dynamic strict。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"误区：以为关掉 _source 没影响"}),"——会导致无法 reindex、update、高亮取原文，慎关。"]})]})}),e.jsxs(l,{title:"亲手建一个带 mapping 的商品索引",children:[e.jsxs("p",{children:["先用显式 mapping 建索引，再写一条文档进去，最后查出来看 ",e.jsx("code",{children:"_source"})," 和 ",e.jsx("code",{children:"_id"})," 长什么样。 故意把 ",e.jsx("code",{children:"brand"})," 改成 ",e.jsx("code",{children:"text"})," 再试一次按品牌聚合，体会类型选错的后果。"]}),e.jsx(s,{lang:"json",title:"建带 mapping 的索引",code:t}),e.jsx(s,{lang:"json",title:"写入并查询文档",code:o}),e.jsxs("p",{children:["想体会改结构的正确姿势，可以接着跑 reindex + 别名那段：建 ",e.jsx("code",{children:"products_v2"}),"、把数据搬过去、 再用一条 ",e.jsx("code",{children:"_aliases"})," 把别名切到新索引，全程业务访问别名、无感知。"]})]}),e.jsx(r,{points:["index≈表、document≈行 JSON、field≈列、mapping≈表结构，是从关系型数据库迁移过来的核心类比。","type 已废弃：7.x 起一个 index 只一个 type，8.x 移除，一个 index 就是一类文档。","mapping 常见类型：text、keyword、数值、date、boolean、ip、geo_point、nested、dense_vector。","对象数组需要字段联动时必须用 nested，否则 object 打平会丢失同一行内的关联。","动态映射会替你猜类型且常猜错，还有字段爆炸/类型冲突风险，生产应优先显式映射。","mapping 字段类型一旦定下不能改，标准做法是新建索引 + _reindex + 别名原子切换，业务无感知。","text 用于全文检索，keyword 用于精确匹配与聚合，两者都要时用多字段（multi-field）。","每个文档自带 _id（主键 + 默认路由）、_source（原始 JSON）、_version（乐观并发）等元字段。"]})]})}export{_ as default};
