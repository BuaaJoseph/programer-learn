import{j as e}from"./index-Bs06kW3a.js";import{L as t,S as r}from"./Summary-CLAN1smq.js";import{K as c}from"./KeyIdea-iVczm-9t.js";import{C as s}from"./Callout-BCaSeUge.js";import{C as l}from"./CodeBlock-BUaxuxwl.js";import{E as i}from"./Example-XOtO_AMb.js";const o=`import kotlinx.coroutines.flow.*

// flow{} 构建器：声明式地描述「怎么一个个发射元素」
fun simpleFlow(): Flow<Int> = flow {
    println("flow 开始执行")     // 注意：collect 之前这行不会运行
    for (i in 1..3) {
        kotlinx.coroutines.delay(100)  // 模拟异步取数（网络 / IO）
        emit(i)                  // 发射一个元素给下游
    }
}

suspend fun demo() {
    val f = simpleFlow()         // 此时什么都没发生——冷流还没被点燃
    println("还没 collect")
    f.collect { value ->         // 终端操作：collect 才真正触发上游执行
        println("收到 $value")
    }
}`,n=`import kotlinx.coroutines.flow.*
import kotlinx.coroutines.Dispatchers

// 一条典型的 Flow 操作链：每个中间操作都返回一个新的 Flow（仍然是冷的）
fun userNames(): Flow<String> =
    repository.observeUsers()        // Flow<User>，来自数据层
        .onEach { u -> log("收到用户 \${u.id}") }   // 副作用：每个元素经过时做点事
        .filter { u -> u.active }                   // 只保留活跃用户
        .map { u -> u.name.trim() }                 // 变换：User -> String
        .flowOn(Dispatchers.IO)                     // 上游切到 IO 线程执行
        .catch { e -> emit("出错：\${e.message}") }  // 捕获上游异常，可降级发射

// transform：比 map 更灵活，一个输入可 emit 0..N 个输出
fun expand(): Flow<Int> = flowOf(1, 2, 3).transform { n ->
    emit(n)
    emit(n * 10)   // 同一个输入元素发射两次
}`,d=`import kotlinx.coroutines.flow.*

// 热流：不依赖收集者，自身持有 / 广播数据
class Counter {
    // StateFlow：永远持有「最新值」，必须有初始值，新订阅者立刻拿到当前值
    private val _count = MutableStateFlow(0)
    val count: StateFlow<Int> = _count.asStateFlow()

    // SharedFlow：事件广播，无「当前值」概念，订阅前发射的事件默认收不到
    private val _events = MutableSharedFlow<String>()
    val events: SharedFlow<String> = _events.asSharedFlow()

    fun increment() { _count.value += 1 }            // 直接改最新值
    suspend fun toast(msg: String) { _events.emit(msg) }  // 发一次性事件
}`,h=`import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*

class UserViewModel(repo: UserRepository) : ViewModel() {

    // 把数据层的冷 Flow 转成给 UI 用的热 StateFlow
    val uiState: StateFlow<List<User>> =
        repo.observeUsers()                  // 冷流：Flow<List<User>>
            .map { list -> list.sortedBy { it.name } }
            .stateIn(
                scope = viewModelScope,      // 绑定 ViewModel 生命周期
                // 没订阅者 5 秒后停止上游收集，省电；旋屏等短暂无订阅不重启
                started = SharingStarted.WhileSubscribed(5_000),
                initialValue = emptyList()   // 首屏先给个空列表
            )
}`,x=`import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun UserScreen(viewModel: UserViewModel) {
    // collectAsStateWithLifecycle：内部用 repeatOnLifecycle(STARTED)
    // 界面进入后台（STOPPED）时自动取消收集，回到前台再恢复——不浪费资源
    val users by viewModel.uiState.collectAsStateWithLifecycle()

    LazyColumn {
        items(users) { user -> Text(user.name) }
    }
}`;function S(){return e.jsxs("article",{children:[e.jsxs(t,{children:["协程让我们能用同步的写法表达异步逻辑，而 ",e.jsx("strong",{children:"Flow"})," 则把这种能力从「返回一个值」 扩展到「随时间陆续返回多个值」——它是协程世界里的异步数据流。这一章我们讲透 Flow 的核心性质：它是",e.jsx("strong",{children:"冷的"}),"（被收集才开始发射）；常用的中间操作符与终端操作； 冷流与热流（StateFlow / SharedFlow）的本质区别；背压是什么；以及在 Android 里 如何把数据层的 Flow 安全、省电地接到 Compose 界面上。"]}),e.jsx("h2",{children:"一、Flow 是什么：随时间到来的多个值"}),e.jsxs("p",{children:["一个 ",e.jsx("code",{children:"suspend"})," 函数最终只能",e.jsx("strong",{children:"返回一个值"}),"。但很多场景里数据是 「一批」或「源源不断」的：数据库某张表的实时查询结果、传感器读数、搜索框的输入变化、 下载进度的百分比。这些用单个返回值表达不了，用 ",e.jsx("code",{children:"List"})," 又必须等全部就绪才能拿到。 Flow 填的就是这个空——它代表一个",e.jsx("strong",{children:"异步产生、按顺序到达的值序列"}),"， 类型写作 ",e.jsx("code",{children:"Flow<T>"}),"。"]}),e.jsxs(c,{children:["Flow 是「",e.jsx("strong",{children:"冷的"}),"异步数据流」。冷（cold）的含义是：你拿到一个 Flow 时， 里面的代码",e.jsx("strong",{children:"一行都还没跑"}),"；只有当某个",e.jsx("strong",{children:"终端操作"}),"（如",e.jsx("code",{children:"collect"}),"）去收集它时，",e.jsx("code",{children:"flow"})," 里的逻辑才从头开始执行并逐个",e.jsx("code",{children:"emit"})," 发射。没人收集，就什么都不发生。"]}),e.jsxs("p",{children:["这一点和很多人对「流」的直觉相反。可以这样理解：Flow 更像一份",e.jsx("strong",{children:"菜谱"}),"而不是",e.jsx("strong",{children:"一桌菜"}),"——菜谱描述了「怎么做」，但只有你真正下厨（collect）时灶火才点起来。 每来一个收集者，菜谱就被独立地从头执行一遍。"]}),e.jsxs("h2",{children:["二、构建 Flow：flow"," 与 emit"]}),e.jsxs("p",{children:["最基础的构建器是 ",e.jsxs("code",{children:["flow ","{ ... }"]}),"。它的代码块是一个 ",e.jsx("code",{children:"suspend"}),"环境，你在里面调用 ",e.jsx("code",{children:"emit(value)"})," 把值一个个发射给下游。下面的例子能直观看出冷流的特性：",e.jsx("code",{children:"collect"})," 之前，连 ",e.jsx("code",{children:"flow"})," 里的第一行 ",e.jsx("code",{children:"println"})," 都不会执行。"]}),e.jsx(l,{lang:"kotlin",title:"flow{} 构建器与冷流特性",code:o}),e.jsxs("p",{children:["除了 ",e.jsx("code",{children:"flow"}),"，还有几个便捷构建器：",e.jsx("code",{children:"flowOf(1, 2, 3)"})," 把固定几个值变成流；",e.jsx("code",{children:"listOf(...).asFlow()"})," 把集合转成流。它们本质相同，都是冷的。"]}),e.jsxs(s,{variant:"info",title:"emit 必须在同一个协程里",children:[e.jsx("code",{children:"flow"})," 内部不允许从别的协程里调用 ",e.jsx("code",{children:"emit"}),"（这会破坏上下文一致性）。 如果你确实要在多个协程并发产生值，应使用 ",e.jsx("code",{children:"channelFlow"}),"，它允许并发 ",e.jsx("code",{children:"send"}),"。"]}),e.jsx("h2",{children:"三、中间操作符：把流接成一条加工链"}),e.jsxs("p",{children:["中间操作符（intermediate operator）接收一个 Flow、返回一个",e.jsx("strong",{children:"新的"})," Flow， 而且返回的流",e.jsx("strong",{children:"仍然是冷的"}),"——它只是把「将来要做的加工」记下来，并不立即执行。 只有终端操作触发时，整条链才一气呵成地跑起来。常用的几个："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"操作符"}),e.jsx("th",{children:"作用"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"map"})}),e.jsxs("td",{children:["把每个元素一对一变换：",e.jsx("code",{children:"T -> R"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"filter"})}),e.jsx("td",{children:"只保留满足条件的元素"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"transform"})}),e.jsxs("td",{children:["最灵活：一个输入可 ",e.jsx("code",{children:"emit"})," 零到多个输出"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"onEach"})}),e.jsx("td",{children:"对每个流经的元素做副作用（打日志等），不改变元素"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"catch"})}),e.jsxs("td",{children:["捕获",e.jsx("strong",{children:"上游"}),"抛出的异常，可降级或重新发射"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"flowOn"})}),e.jsxs("td",{children:["切换",e.jsx("strong",{children:"上游"}),"的执行线程（如切到 IO）"]})]})]})]}),e.jsx(l,{lang:"kotlin",title:"一条典型的操作链",code:n}),e.jsxs(s,{variant:"warn",title:"flowOn 和 catch 只影响「上游」",children:["Flow 的线程切换与异常捕获都遵循「",e.jsx("strong",{children:"上游"}),"」原则：",e.jsx("code",{children:"flowOn(IO)"}),"只把它",e.jsx("strong",{children:"之前"}),"的操作切到 IO，下游（包括 ",e.jsx("code",{children:"collect"})," 的代码块）仍在收集者所在的线程；",e.jsx("code",{children:"catch"})," 同理只能捕获它上方操作抛出的异常，捕不到下游 ",e.jsx("code",{children:"collect"})," 块里的异常。 所以这两个操作符的",e.jsx("strong",{children:"摆放位置"}),"很关键。"]}),e.jsx("h2",{children:"四、终端操作：collect 点燃整条链"}),e.jsxs("p",{children:["终端操作（terminal operator）是真正",e.jsx("strong",{children:"触发"}),"流执行的那一下，它是一个",e.jsx("code",{children:"suspend"})," 函数，必须在协程里调用。最核心的是 ",e.jsx("code",{children:"collect"}),"： 它逐个接收上游发射的每个值。其它终端操作如 ",e.jsx("code",{children:"toList()"}),"（收集成列表）、",e.jsx("code",{children:"first()"}),"（拿第一个就停）、",e.jsx("code",{children:"single()"}),"、",e.jsx("code",{children:"reduce()"}),"、",e.jsx("code",{children:"collectLatest"}),"（新值到来时取消尚未处理完的上一个）也都属于终端操作。"]}),e.jsx(i,{title:"一条链的执行时机",children:e.jsxs("p",{children:["有了 ",e.jsx("code",{children:"repo.observeUsers().filter{...}.map{...}"})," 这条链，只要没人",e.jsx("code",{children:"collect"}),"，",e.jsx("code",{children:"repo"})," 那边的数据库查询",e.jsx("strong",{children:"根本不会发起"}),"。 一旦某处写了 ",e.jsx("code",{children:".collect { ... }"}),"，查询发起、每条数据依次经过 filter、map， 最终到达 collect 块。换一个收集者，整条链会被",e.jsx("strong",{children:"独立地再跑一遍"}),"——这就是冷流。"]})}),e.jsx("h2",{children:"五、冷流 vs 热流：StateFlow 与 SharedFlow"}),e.jsxs("p",{children:["前面强调 Flow 默认是冷的：每个收集者各自触发一份独立执行。但有些数据天然是 「",e.jsx("strong",{children:"共享的、与收集者无关的"}),"」——比如「当前登录用户」「页面 UI 状态」 这种全局只有一份、谁来看都是同一个的东西。这就是",e.jsx("strong",{children:"热流（hot flow）"}),"的用武之地。"]}),e.jsxs(c,{children:[e.jsx("strong",{children:"冷流"}),"：被收集才执行，每个收集者一份独立的数据。",e.jsx("br",{}),e.jsx("strong",{children:"热流"}),"：独立于收集者而存在、主动持有 / 广播数据，多个收集者共享同一个数据源。 Kotlin 提供两种热流：",e.jsx("code",{children:"StateFlow"}),"（持有",e.jsx("strong",{children:"最新值"}),"，表达「状态」）和",e.jsx("code",{children:"SharedFlow"}),"（广播",e.jsx("strong",{children:"事件"}),"，表达「发生了一次什么」）。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"StateFlow"}),e.jsx("th",{children:"SharedFlow"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"语义"}),e.jsx("td",{children:"状态：永远有一个「当前值」"}),e.jsx("td",{children:"事件：一次性的广播"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"初始值"}),e.jsx("td",{children:"必须有"}),e.jsx("td",{children:"没有"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"新订阅者"}),e.jsx("td",{children:"立刻收到当前最新值"}),e.jsx("td",{children:"默认收不到订阅前发射的内容"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"去重"}),e.jsx("td",{children:"值相等时不重复发射（conflate）"}),e.jsx("td",{children:"不去重，可配重放缓存"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"典型用途"}),e.jsx("td",{children:"UI 状态、表单数据、开关"}),e.jsx("td",{children:"导航跳转、Toast、一次性提示"})]})]})]}),e.jsx(l,{lang:"kotlin",title:"StateFlow（状态）与 SharedFlow（事件）",code:d}),e.jsxs(s,{variant:"tip",title:"一个常见判断口诀",children:["问自己：「这条数据如果界面重建（如旋屏）后",e.jsx("strong",{children:"需要立刻拿到当前值"}),"吗？」 需要——用 StateFlow（状态）；不需要、它是「只该响一次」的事件（如弹一个 Toast）—— 用 SharedFlow（事件）。把一次性事件错配成 StateFlow，旋屏后会把旧事件又重放一遍，造成重复弹窗。"]}),e.jsx("h2",{children:"六、背压：下游跟不上上游怎么办"}),e.jsxs("p",{children:[e.jsx("strong",{children:"背压（backpressure）"}),"指的是上游发射速度比下游处理速度快时的应对策略。 因为 ",e.jsx("code",{children:"emit"})," 是挂起函数，默认情况下上游会被「顶住」——下游没处理完， 上游就挂起等待，天然不会丢数据也不会爆内存。当你不想让上游被拖慢时，可以用：",e.jsx("code",{children:"buffer()"}),"（加一个缓冲区，让上游先跑、下游慢慢消费）或",e.jsx("code",{children:"conflate()"}),"（只保留",e.jsx("strong",{children:"最新"}),"值，中间来不及处理的旧值直接丢弃， 适合「只关心最新状态」的场景）。"]}),e.jsx("h2",{children:"七、在 Android 里：从 Repository 到 UI 的标准接法"}),e.jsxs("p",{children:["实战中的典型数据流向是：",e.jsx("strong",{children:"数据层"}),"（Room / 网络）暴露冷 ",e.jsx("code",{children:"Flow"})," →",e.jsx("strong",{children:"ViewModel"})," 用 ",e.jsx("code",{children:"stateIn"})," 把它转成热 ",e.jsx("code",{children:"StateFlow"})," →",e.jsx("strong",{children:"UI 层"}),"用 ",e.jsx("code",{children:"collectAsStateWithLifecycle"})," 安全收集。"]}),e.jsx("h3",{children:"ViewModel：用 stateIn 转成 StateFlow"}),e.jsxs("p",{children:[e.jsx("code",{children:"stateIn"})," 把一个冷流「钉」在某个协程作用域里，变成一个共享的热 StateFlow。 关键是 ",e.jsx("code",{children:"started"})," 参数：",e.jsx("code",{children:"SharingStarted.WhileSubscribed(5_000)"})," 表示 「有订阅者时才收集上游，最后一个订阅者离开 5 秒后停止」——这 5 秒的宽限让旋屏等 短暂无订阅的瞬间不会白白重启上游，同时界面真正退出后能及时释放资源。"]}),e.jsx(l,{lang:"kotlin",title:"ViewModel 用 stateIn 暴露 UI 状态",code:h}),e.jsx("h3",{children:"UI：用 collectAsStateWithLifecycle 安全收集"}),e.jsxs("p",{children:["在 Compose 里，绝不要用普通的 ",e.jsx("code",{children:"collectAsState()"})," 去收集长期存在的流—— 因为它在界面进入后台时仍会继续收集，白白消耗资源、甚至引发崩溃。正确做法是",e.jsx("code",{children:"collectAsStateWithLifecycle()"}),"：它内部基于 ",e.jsx("code",{children:"repeatOnLifecycle(STARTED)"}),"， 界面不可见时",e.jsx("strong",{children:"自动取消"}),"收集，回到前台再恢复。"]}),e.jsx(l,{lang:"kotlin",title:"Compose 中用生命周期感知的方式收集",code:x}),e.jsxs(s,{variant:"warn",title:"为什么必须用生命周期感知的收集",children:["想象一个收集网络流的界面被切到后台：如果用普通 ",e.jsx("code",{children:"collect"}),"，上游会持续发起请求、 持续更新一个用户根本看不见的界面，浪费电量与流量。",e.jsx("code",{children:"repeatOnLifecycle"})," /",e.jsx("code",{children:"collectAsStateWithLifecycle"})," 解决的正是这件事——",e.jsx("strong",{children:"不可见就不收集"}),"。"]}),e.jsx("h2",{children:"八、小结性的心智模型"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"冷流 = 菜谱"}),"：被 collect 才下厨，每个收集者各跑一遍。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"中间操作 = 加工步骤"}),"：返回新的冷流，",e.jsx("code",{children:"flowOn"})," / ",e.jsx("code",{children:"catch"})," 只管上游。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"终端操作 = 点火"}),"：",e.jsx("code",{children:"collect"})," 等才真正触发执行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"热流 = 共享的数据源"}),"：StateFlow 管状态、SharedFlow 管事件。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Android 接法"}),"：Repository 冷流 → ",e.jsx("code",{children:"stateIn"})," → ",e.jsx("code",{children:"collectAsStateWithLifecycle"}),"。"]})]}),e.jsx(r,{points:["Flow 是冷的异步数据流：拿到时一行未跑，只有终端操作（collect）去收集才从头执行并逐个 emit；每个收集者独立跑一遍。","用 flow{} + emit 构建；中间操作符 map / filter / transform / onEach / catch / flowOn 返回新的冷流，flowOn 与 catch 只作用于上游，位置很关键。","终端操作（collect / toList / first / collectLatest 等）是挂起函数，是真正触发整条链执行的那一下。","热流独立于收集者：StateFlow 持有最新值表达状态（有初始值、新订阅者立即拿到当前值）；SharedFlow 广播一次性事件（无当前值）。","背压：emit 挂起天然顶住上游不丢数据；buffer 加缓冲让上游先跑，conflate 只保留最新值丢弃旧值。","Android 标准接法：Repository 冷 Flow → ViewModel 用 stateIn(WhileSubscribed) 转 StateFlow → UI 用 collectAsStateWithLifecycle（基于 repeatOnLifecycle）后台不收集、省电。"]})]})}export{S as default};
