import{j as e}from"./index-Bkb6eOY7.js";import{L as t,S as n}from"./Summary-Dj-Y5ESD.js";import{K as s}from"./KeyIdea-N6HVLWjp.js";import{C as r}from"./Callout-FpvHzM97.js";import{C as i}from"./CodeBlock-BQqVtp_3.js";import{E as d}from"./Example-iLfTRUEi.js";const c=`// Collection 体系（单值集合）
Collection
├── List          有序、可重复、有下标
│   ├── ArrayList         动态数组，查快增删慢
│   ├── LinkedList        双向链表，增删快查慢，兼做 Deque
│   └── Vector            古老的线程安全 List（方法 synchronized）
│       └── Stack         继承 Vector，后进先出
├── Set           不可重复、无下标
│   ├── HashSet           底层是 HashMap，无序
│   ├── LinkedHashSet     按插入顺序
│   └── TreeSet           基于红黑树，有序
└── Queue         队列 / 双端队列
    ├── ArrayDeque        数组实现的双端队列
    ├── LinkedList        也实现了 Deque
    └── PriorityQueue     优先级队列（小顶堆）

// Map 体系（键值对集合，不属于 Collection）
Map
├── HashMap               数组+链表+红黑树
├── LinkedHashMap         记录插入/访问顺序
├── TreeMap               红黑树，按 key 排序
└── Hashtable             古老的线程安全 Map`,l=`// 数组：长度固定，类型确定，下标随机访问 O(1)
int[] arr = new int[10];
arr[3] = 42;            // 直接按内存偏移定位

// 链表：节点离散分布，靠指针串联
class Node {
    int val;
    Node prev;
    Node next;
}
// 访问第 i 个元素要从头/尾遍历 O(n)，
// 但已知位置后插入/删除只改指针 O(1)`,o=`// JDK 8 ArrayList 扩容核心（简化）
private void grow(int minCapacity) {
    int oldCapacity = elementData.length;
    // 新容量 = 旧容量 + 旧容量 >> 1，即 1.5 倍
    int newCapacity = oldCapacity + (oldCapacity >> 1);
    if (newCapacity - minCapacity < 0)
        newCapacity = minCapacity;          // 一次 addAll 大量元素时
    if (newCapacity - MAX_ARRAY_SIZE > 0)
        newCapacity = hugeCapacity(minCapacity);
    // 关键：复制到新数组，旧数组等待 GC
    elementData = Arrays.copyOf(elementData, newCapacity);
}

// 默认初始容量 10（第一次 add 时才真正分配，懒加载）
// 容量序列：10 -> 15 -> 22 -> 33 -> 49 ...`,x=`// CopyOnWriteArrayList：写时复制
public boolean add(E e) {
    synchronized (lock) {              // 写操作互斥
        Object[] es = getArray();
        int len = es.length;
        Object[] newElements = Arrays.copyOf(es, len + 1);  // 复制整个数组
        newElements[len] = e;
        setArray(newElements);         // 用 volatile 数组引用一次性切换
        return true;
    }
}
// 读操作完全无锁，读的是切换前的旧数组快照
public E get(int index) {
    return elementAt(getArray(), index);
}`,h=`List<Integer> list = new ArrayList<>(List.of(1, 2, 3, 4));

// 错误：遍历中直接用 list.remove，触发 ConcurrentModificationException
for (Integer x : list) {           // foreach 底层用 Iterator
    if (x == 2) list.remove(x);    // modCount++，但迭代器 expectedModCount 没变
}

// 正确：用迭代器自身的 remove
Iterator<Integer> it = list.iterator();
while (it.hasNext()) {
    if (it.next() == 2) it.remove();   // 同步 expectedModCount
}

// 或用 removeIf（内部安全）
list.removeIf(x -> x == 2);`;function m(){return e.jsxs("article",{children:[e.jsxs(t,{children:["集合是 Java 工程师每天都在用、面试官每次都在问的话题。这一章我们从最常用的 List 入手： 先俯瞰整个集合框架的两大体系，再把数组与链表这对数据结构的本质讲透，进而拆解",e.jsx("code",{children:"ArrayList"})," 与 ",e.jsx("code",{children:"LinkedList"})," 的取舍、",e.jsx("code",{children:"ArrayList"})," 的扩容机制、 线程安全的 ",e.jsx("code",{children:"CopyOnWriteArrayList"}),"，最后讲清那个几乎人人踩过的",e.jsx("code",{children:"ConcurrentModificationException"})," 到底怎么来的。"]}),e.jsx("h2",{children:"一、集合框架总览：两大体系"}),e.jsxs("p",{children:["Java 集合分成两条主线：一条是单值集合 ",e.jsx("code",{children:"Collection"}),"，下面挂着 ",e.jsx("code",{children:"List"}),"、",e.jsx("code",{children:"Set"}),"、",e.jsx("code",{children:"Queue"}),"；另一条是键值对集合 ",e.jsx("code",{children:"Map"}),"，它",e.jsx("strong",{children:"不属于"}),e.jsx("code",{children:"Collection"}),"，是独立的一支。很多人面试一上来就把 ",e.jsx("code",{children:"Map"})," 归进 ",e.jsx("code",{children:"Collection"}),"， 这是第一个易错点。"]}),e.jsx(i,{lang:"java",title:"集合框架两大体系",code:c}),e.jsxs(s,{children:["记住一句话：",e.jsx("code",{children:"Collection"})," 装单个元素，",e.jsx("code",{children:"Map"})," 装键值对，两者平级、互不继承。",e.jsx("code",{children:"List"})," 有序可重复，",e.jsx("code",{children:"Set"})," 不可重复，",e.jsx("code",{children:"Queue"})," 强调出入顺序—— 选哪个集合，先想清楚你要的是「有序」「去重」还是「键值映射」。"]}),e.jsx("h2",{children:"二、数组 vs 链表：一切 List 的底座"}),e.jsxs("p",{children:["理解 List 的性能差异，根子在数组与链表这两种底层结构。数组在内存里是",e.jsx("strong",{children:"连续的一整块"}),"， 每个元素大小相同，所以「第 i 个元素」可以用「首地址 + i × 元素大小」直接算出地址—— 这就是随机访问 O(1) 的来历。代价是长度固定，扩容要重新分配并复制；中间插入 / 删除要把后面 所有元素整体搬动，是 O(n)。"]}),e.jsxs("p",{children:["链表则是一堆",e.jsx("strong",{children:"离散"}),"的节点，每个节点存着数据和指向相邻节点的指针。它没有「按下标算地址」 的能力，要找第 i 个元素只能从头（或尾）一个个走，是 O(n)；但一旦定位到位置，插入 / 删除只需要 改几个指针，是 O(1)。"]}),e.jsx(i,{lang:"java",title:"数组与链表的本质差异",code:l}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"操作"}),e.jsx("th",{children:"数组"}),e.jsx("th",{children:"链表"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"按下标访问"}),e.jsx("td",{children:"O(1)"}),e.jsx("td",{children:"O(n)"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"头部插入 / 删除"}),e.jsx("td",{children:"O(n)"}),e.jsx("td",{children:"O(1)"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"尾部插入"}),e.jsx("td",{children:"均摊 O(1)（可能扩容）"}),e.jsx("td",{children:"O(1)"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"中间插入 / 删除"}),e.jsx("td",{children:"O(n)"}),e.jsx("td",{children:"O(n) 查 + O(1) 改"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"内存"}),e.jsx("td",{children:"连续、紧凑"}),e.jsx("td",{children:"离散、每节点多存指针"})]})]})]}),e.jsx("h2",{children:"三、ArrayList vs LinkedList：到底怎么选"}),e.jsxs("p",{children:[e.jsx("code",{children:"ArrayList"})," 底层是动态数组，",e.jsx("code",{children:"LinkedList"})," 底层是双向链表。这决定了它们几乎相反的性能曲线： 前者查改快、随机访问强；后者头尾增删快。但实战里有个反直觉结论——",e.jsx("strong",{children:"绝大多数场景都该用 ArrayList"}),"。"]}),e.jsxs(r,{variant:"note",title:"为什么实战偏爱 ArrayList",children:["理论上 ",e.jsx("code",{children:"LinkedList"})," 中间增删 O(1)，但前提是「已经定位到了那个节点」，而定位本身要 O(n) 遍历；加上链表节点离散，CPU 缓存命中率差，每个节点还多占两个指针的内存。结果就是：除非你",e.jsx("strong",{children:"反复在头部增删且不随机访问"}),"，否则 ",e.jsx("code",{children:"ArrayList"})," 在实际跑分里几乎全面胜出。 需要队列 / 栈语义时，也更推荐 ",e.jsx("code",{children:"ArrayDeque"})," 而非 ",e.jsx("code",{children:"LinkedList"}),"。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"ArrayList"}),e.jsx("th",{children:"LinkedList"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"底层"}),e.jsx("td",{children:"Object[] 动态数组"}),e.jsx("td",{children:"双向链表 Node"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"随机访问 get(i)"}),e.jsx("td",{children:"O(1)，快"}),e.jsx("td",{children:"O(n)，慢"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"尾部 add"}),e.jsx("td",{children:"均摊 O(1)"}),e.jsx("td",{children:"O(1)"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"头部 / 中间增删"}),e.jsx("td",{children:"O(n) 搬移"}),e.jsx("td",{children:"定位 O(n)，改指针 O(1)"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"内存"}),e.jsx("td",{children:"紧凑（可能有预留空位）"}),e.jsx("td",{children:"每节点多两个指针"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"额外接口"}),e.jsx("td",{children:"RandomAccess"}),e.jsx("td",{children:"Deque（可当队列/栈）"})]})]})]}),e.jsx("h2",{children:"四、ArrayList 扩容机制"}),e.jsxs("p",{children:[e.jsx("code",{children:"ArrayList"})," 的默认初始容量是 10，但有个细节：",e.jsx("code",{children:"new ArrayList<>()"})," 时并不会真的 分配长度 10 的数组，而是指向一个空数组，",e.jsx("strong",{children:"第一次 add 时才懒加载"}),"分配到 10。这是 JDK7 之后的优化，避免大量空 List 浪费内存。"]}),e.jsxs("p",{children:["当元素个数超过当前容量，触发扩容：新容量 = 旧容量 + 旧容量 >> 1，也就是",e.jsx("strong",{children:"约 1.5 倍"}),"。 扩容的实质是 ",e.jsx("code",{children:"Arrays.copyOf"})," 申请一个更大的新数组、把旧元素全部复制过去，旧数组交给 GC。 所以频繁扩容是有代价的——能预估大小时，应当用 ",e.jsx("code",{children:"new ArrayList<>(expectedSize)"})," 指定初始容量。"]}),e.jsx(i,{lang:"java",title:"ArrayList grow 扩容核心",code:o}),e.jsx(r,{variant:"tip",title:"为什么是 1.5 倍而不是 2 倍",children:"1.5 倍是「空间浪费」和「扩容频率」之间的折中。倍数太小，扩容太频繁，复制开销大；倍数太大（如 2 倍）， 容易留下大量永远用不到的空位、浪费内存，且新申请的大块内存难以复用之前释放的碎片。1.5 倍让被释放的 旧数组在多次扩容后有机会被新申请复用，是经过权衡的工程选择。"}),e.jsx("h2",{children:"五、CopyOnWriteArrayList：写时复制的并发 List"}),e.jsxs("p",{children:["普通 ",e.jsx("code",{children:"ArrayList"})," 不是线程安全的，多线程并发读写会出问题。",e.jsx("code",{children:"CopyOnWriteArrayList"}),"（COW）是 JUC 包提供的线程安全 List，思路很特别：",e.jsx("strong",{children:"读不加锁，写时把整个底层数组复制一份，在副本上改完再原子替换引用"}),"。"]}),e.jsx(i,{lang:"java",title:"CopyOnWriteArrayList 写时复制",code:x}),e.jsxs("p",{children:["因为写操作总是在新数组上进行，读操作读的是「切换前的旧数组」，所以读永远不会读到写了一半的中间状态， 也就",e.jsx("strong",{children:"无需加锁"}),"。代价是：每次写都要全量复制，写多了内存和性能都吃不消；而且读到的可能是 旧快照，存在",e.jsx("strong",{children:"弱一致性"}),"（数据最终一致，但某一刻读到的不一定最新）。"]}),e.jsxs(r,{variant:"note",title:"CopyOnWriteArrayList vs Collections.synchronizedList",children:["两者都能让 List 线程安全，但路线相反。",e.jsx("code",{children:"Collections.synchronizedList"})," 是给所有方法套一把 互斥锁，",e.jsx("strong",{children:"读写都要抢锁"}),"，读并发性能差，但写不复制、内存友好。",e.jsx("code",{children:"CopyOnWriteArrayList"})," 读完全无锁、并发读极快，但写要复制整个数组、内存开销大。 结论：",e.jsx("strong",{children:"读多写极少"}),"（如配置、监听器列表、白名单）用 COW；",e.jsx("strong",{children:"读写较均衡"}),"则用 synchronizedList 或 ",e.jsx("code",{children:"ConcurrentXxx"})," 结构。"]}),e.jsx("h2",{children:"六、ConcurrentModificationException 怎么产生的"}),e.jsxs("p",{children:["这是 List 面试的经典必考题。它",e.jsx("strong",{children:"不是并发独有"}),"——单线程里遍历同时修改也会触发。 根源在 fail-fast（快速失败）机制：集合内部有一个 ",e.jsx("code",{children:"modCount"})," 记录结构性修改次数， 迭代器创建时会把它快照成 ",e.jsx("code",{children:"expectedModCount"}),"。每次 ",e.jsx("code",{children:"next()"})," 都会校验两者是否相等， 一旦你在遍历途中用 ",e.jsx("code",{children:"list.add/remove"})," 改了集合（",e.jsx("code",{children:"modCount++"})," 而 ",e.jsx("code",{children:"expectedModCount"})," 没动）， 校验失败就抛出 ",e.jsx("code",{children:"ConcurrentModificationException"}),"。"]}),e.jsx(i,{lang:"java",title:"CME 的产生与正确写法",code:h}),e.jsx(d,{title:"为什么 foreach 删除会中招",children:e.jsxs("p",{children:["增强 for 循环（foreach）在编译后其实是用 ",e.jsx("code",{children:"Iterator"})," 实现的。当你在循环体里调用",e.jsx("code",{children:"list.remove(x)"}),"，改的是集合的 ",e.jsx("code",{children:"modCount"}),"，但迭代器手里的",e.jsx("code",{children:"expectedModCount"})," 不知情；下一次 ",e.jsx("code",{children:"it.next()"})," 检查发现两者对不上，立刻抛异常。 正确做法是用迭代器自己的 ",e.jsx("code",{children:"it.remove()"}),"（它会同步更新 ",e.jsx("code",{children:"expectedModCount"}),"）， 或直接用 ",e.jsx("code",{children:"removeIf"}),"。"]})}),e.jsxs(r,{variant:"warn",title:"fail-fast 不是并发安全保证",children:[e.jsx("code",{children:"modCount"})," 的检查没有任何加锁，它只是一种「尽力而为」的错误探测，目的是",e.jsx("strong",{children:"帮你尽早发现 bug"}),"， 而非保证线程安全。多线程下它可能漏报也可能误报，绝不能把「没抛 CME」当成「线程安全」。 真要并发遍历修改，请用 ",e.jsx("code",{children:"CopyOnWriteArrayList"})," 这类 fail-safe 集合。"]}),e.jsx(n,{points:["集合分 Collection（单值：List/Set/Queue）与 Map（键值对）两大体系，Map 不属于 Collection。","数组连续内存、随机访问 O(1) 但增删搬移 O(n)；链表离散、增删改指针 O(1) 但访问 O(n)。","ArrayList 底层动态数组、查快；LinkedList 底层双向链表、头尾增删快；实战绝大多数场景用 ArrayList。","ArrayList 默认容量 10（懒加载），扩容约 1.5 倍，本质是 Arrays.copyOf 复制到新数组；能预估大小就指定初始容量。","CopyOnWriteArrayList 读无锁、写时复制整个数组再原子替换，适合读多写极少；synchronizedList 读写都加锁。","ConcurrentModificationException 源于 fail-fast 的 modCount 校验，遍历中改集合即触发；用迭代器 remove 或 removeIf 解决。"]})]})}export{m as default};
