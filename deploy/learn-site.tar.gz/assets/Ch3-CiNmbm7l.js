import{r as d,j as e}from"./index-CNCQ9D3g.js";import{L as a,S as x}from"./Summary-B81QYNtK.js";import{K as h}from"./KeyIdea-CJu1AmJK.js";import{E as j}from"./Example-C7EXHAW5.js";import{P as p}from"./Practice-Cem8Avrf.js";import{C as g}from"./Callout-DBjCLF-u.js";import{C as n}from"./CodeBlock-B4ANG3D_.js";import{F as f}from"./Figure-DNCpIpnp.js";const i={simple:{label:"简单工厂",desc:"一个工厂类用 if/switch 按参数 new 出不同产品。调用方不再自己 new；但新增产品要改工厂(违反开闭原则)。",not:"不属于 GoF 23 种"},method:{label:"工厂方法",desc:"定义创建产品的接口，每种产品对应一个具体工厂子类。新增产品只需加一个工厂子类(符合开闭)。",not:"一个工厂造一类产品"},abstract:{label:"抽象工厂",desc:"一个工厂创建「一族」相关产品(如同一风格的按钮+文本框)。适合产品成套出现的场景。",not:"一个工厂造一族产品"}};function u(){const[s,o]=d.useState("method"),c=i[s],l=e.jsx(e.Fragment,{children:Object.entries(i).map(([r,t])=>e.jsx("button",{className:`fig-btn ${s===r?"active":""}`,onClick:()=>o(r),children:t.label},r))});return e.jsx(f,{caption:"工厂模式把对象创建集中起来、面向接口编程，让调用方与具体实现解耦。三兄弟解决不同程度的解耦：简单工厂(一个工厂全包)、工厂方法(一厂一品)、抽象工厂(一厂一族)。",controls:l,children:e.jsxs("svg",{viewBox:"0 0 460 180",width:"460",role:"img","aria-label":"工厂模式",children:[e.jsx("rect",{x:"40",y:"40",width:"90",height:"40",rx:"9",fill:"var(--accent)"}),e.jsx("text",{x:"85",y:"64",textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"12",fontWeight:"700",fill:"#ffffff",children:"调用方"}),e.jsx("rect",{x:"180",y:"36",width:"100",height:"48",rx:"9",fill:"var(--violet)",fillOpacity:"0.14",stroke:"var(--violet)"}),e.jsx("text",{x:"230",y:"56",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"11",fontWeight:"700",fill:"var(--violet)",children:"工厂"}),e.jsx("text",{x:"230",y:"72",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:"var(--ink-soft)",children:c.not}),e.jsx("line",{x1:"130",y1:"60",x2:"180",y2:"60",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#fa-a)"}),["产品A","产品B","产品C"].map((r,t)=>e.jsxs("g",{children:[e.jsx("rect",{x:"330",y:20+t*44,width:"100",height:"34",rx:"7",fill:"var(--green-soft)",stroke:"var(--green-line)"}),e.jsx("text",{x:"380",y:41+t*44,textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"11",fill:"var(--green)",children:r}),e.jsx("line",{x1:"280",y1:"60",x2:"330",y2:37+t*44,stroke:"var(--ink-faint)",strokeWidth:"1.2",markerEnd:"url(#fa-a)"})]},r)),e.jsx("defs",{children:e.jsx("marker",{id:"fa-a",markerWidth:"8",markerHeight:"8",refX:"5",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L5,3 L0,6 Z",fill:"var(--ink-faint)"})})}),e.jsx("rect",{x:"20",y:"146",width:"420",height:"0",fill:"none"}),e.jsx("foreignObject",{x:"20",y:"120",width:"300",height:"56",children:e.jsxs("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"11px var(--sans)",color:"var(--ink)",lineHeight:1.35},children:[e.jsxs("strong",{style:{color:"var(--accent-strong)"},children:[c.label,"："]}),c.desc]})})]})})}const m=`// 简单工厂：一个工厂用 if/switch 决定造哪个产品
public class DbConnectionFactory {

    public static Connection create(String type) {
        // 每加一种数据库就得回来改这里，违反开闭原则
        if ("mysql".equals(type)) {
            return new MySQLConnection();
        } else if ("oracle".equals(type)) {
            return new OracleConnection();
        }
        throw new IllegalArgumentException("不支持的类型: " + type);
    }
}`,y=`// 工厂方法：一个产品对应一个工厂，新增产品只加类不改老代码

// 1. 抽象产品
public interface Connection {
    void connect();
}

// 2. 具体产品
public class MySQLConnection implements Connection {
    public void connect() {
        System.out.println("连接 MySQL");
    }
}

public class OracleConnection implements Connection {
    public void connect() {
        System.out.println("连接 Oracle");
    }
}

// 3. 抽象工厂
public interface ConnectionFactory {
    Connection create();
}

// 4. 具体工厂：每个产品一个工厂
public class MySQLFactory implements ConnectionFactory {
    public Connection create() {
        return new MySQLConnection();
    }
}

public class OracleFactory implements ConnectionFactory {
    public Connection create() {
        return new OracleConnection();
    }
}

// 使用：要换数据库，只换注入的工厂，业务代码不变
// ConnectionFactory factory = new MySQLFactory();
// Connection conn = factory.create();
// conn.connect();`,C=`// 抽象工厂：创建「一族」相关产品（同一风格的一整套 UI 组件）

public interface Button { void render(); }
public interface CheckBox { void render(); }

// 一个工厂负责造出一整套同风格的产品
public interface UIFactory {
    Button createButton();
    CheckBox createCheckBox();
}

public class DarkFactory implements UIFactory {
    public Button createButton() { return new DarkButton(); }
    public CheckBox createCheckBox() { return new DarkCheckBox(); }
}

public class LightFactory implements UIFactory {
    public Button createButton() { return new LightButton(); }
    public CheckBox createCheckBox() { return new LightCheckBox(); }
}`,F=`// 工厂方法在框架里常以「模板方法 + 工厂方法」组合出现：
// 父类定义流程骨架，把"造哪个产品"这一步留给子类的工厂方法

public abstract class ExportProcessor {

    // 模板方法：固定的导出流程
    public final void export(Data data) {
        Exporter exporter = createExporter();   // 工厂方法，子类决定造谁
        exporter.open();
        exporter.write(data);
        exporter.close();
    }

    // 工厂方法：留给子类实现，这就是 GoF "Factory Method" 的本意
    protected abstract Exporter createExporter();
}

public class PdfExportProcessor extends ExportProcessor {
    protected Exporter createExporter() { return new PdfExporter(); }
}

public class ExcelExportProcessor extends ExportProcessor {
    protected Exporter createExporter() { return new ExcelExporter(); }
}`;function I(){return e.jsxs(e.Fragment,{children:[e.jsx(a,{children:e.jsxs("p",{children:["工厂模式要解决的痛点是：",e.jsx("strong",{children:"对象的创建过程是易变的"}),"。 如果到处直接 ",e.jsx("code",{children:"new"}),"，一旦要换实现、加类型，就得满项目改 new。 工厂模式把「创建对象」这件事单独隔离出来，让调用方只管「要什么」，不管「怎么造」。 它有三个层次：简单工厂、工厂方法、抽象工厂。"]})}),e.jsx("h2",{children:"工厂模式的意图与 UML 角色"}),e.jsxs("p",{children:["工厂模式的本质意图是",e.jsx("strong",{children:"把「对象的创建」与「对象的使用」解耦"}),"。 调用方拿到的是抽象产品，至于背后 new 的是哪个具体类、怎么 new、要不要复用，全被工厂藏起来了。 以 GoF 的工厂方法为例，UML 上有四个角色："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"抽象产品（Product）"}),"：工厂要造的东西的接口，如 ",e.jsx("code",{children:"Connection"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"具体产品（ConcreteProduct）"}),"：接口的实现，如 ",e.jsx("code",{children:"MySQLConnection"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"抽象工厂（Creator）"}),"：声明工厂方法 ",e.jsx("code",{children:"create()"})," 返回抽象产品。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"具体工厂（ConcreteCreator）"}),"：实现工厂方法，决定造哪个具体产品。"]})]}),e.jsx("h2",{children:"三个层次，逐层进化"}),e.jsxs("p",{children:["三者是从「能用」到「优雅」再到「成套」的递进。理解它们的关键，是看每一步是如何",e.jsx("strong",{children:"更好地满足开闭原则"}),"的。"]}),e.jsx("h3",{children:"简单工厂：一个工厂搞定一切（非 GoF）"}),e.jsxs("p",{children:["用一个工厂类，靠 ",e.jsx("code",{children:"if / switch"})," 判断参数来决定 new 哪个产品。 它把 new 集中到一处，调用方确实清爽了。但它",e.jsx("strong",{children:"违反开闭原则"}),"： 每加一种产品，都得回来改这个工厂的判断分支。注意，简单工厂",e.jsx("strong",{children:"不属于 GoF 的 23 种模式"}),"， 它只是一种朴素的编程习惯，但因为常用所以单独拿出来讲。"]}),e.jsx("h3",{children:"工厂方法：一个产品一个工厂"}),e.jsxs("p",{children:["把工厂也抽象成接口，每种产品配一个具体工厂。要加新产品，就",e.jsx("strong",{children:"新建一个产品类 + 一个工厂类"}),"， 老代码完全不动——",e.jsx("strong",{children:"完美符合开闭原则"}),"。代价是类的数量变多了。 这是真正意义上的 GoF 工厂方法模式。"]}),e.jsx("h3",{children:"抽象工厂：创建一族产品"}),e.jsxs("p",{children:["当产品不是单个，而是",e.jsx("strong",{children:"一整套互相搭配"}),"的时候用它。比如 UI 主题： 深色主题的按钮要配深色的复选框，不能混搭。抽象工厂让一个工厂负责造出",e.jsx("strong",{children:"同一族的一整套产品"}),"，保证它们风格一致。换主题就换整个工厂。"]}),e.jsxs("p",{children:["这里有个关键概念要分清：",e.jsx("strong",{children:"产品等级结构"}),"（同一种产品的不同实现，如「所有按钮」） 与",e.jsx("strong",{children:"产品族"}),"（同一风格下不同种产品的组合，如「深色按钮 + 深色复选框」）。 工厂方法解决的是「同一等级结构里加新实现」，抽象工厂解决的是「成族地切换」。 抽象工厂的硬伤也正在此：",e.jsx("strong",{children:"它对「增加产品等级」是封闭的"}),"—— 若要新增一种产品（比如再加个 ",e.jsx("code",{children:"Slider"}),"），所有工厂接口和实现都得改，违反开闭。 所以抽象工厂适合「产品族稳定、但常整族切换」的场景。"]}),e.jsx("h3",{children:"工厂方法 ≠ 简单工厂里的静态方法"}),e.jsxs("p",{children:["初学常把「带个 static 的创建方法」就叫工厂方法，其实 GoF 的工厂方法强调的是",e.jsx("strong",{children:"把创建步骤延迟到子类"}),"。它在框架里最常见的形态是和模板方法搭配： 父类把流程定死，唯独「造哪个产品」做成抽象方法让子类去填。"]}),e.jsx(n,{lang:"java",title:"工厂方法的经典形态：模板方法 + 工厂方法",code:F}),e.jsx(j,{title:"用「换数据库 / 换 UI 风格」记住区别",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"简单工厂"})," · 一个 DbFactory 用 switch 决定造 MySQL 还是 Oracle 连接，加类型要改它。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"工厂方法"})," · MySQLFactory、OracleFactory 各管一个产品，加 PostgreSQL 只新建工厂。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"抽象工厂"})," · DarkFactory 一次造出深色按钮 + 深色复选框一整套，换风格换工厂即可。"]})]})}),e.jsx(u,{}),e.jsx("h2",{children:"三种工厂对比表"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"简单工厂"}),e.jsx("th",{children:"工厂方法"}),e.jsx("th",{children:"抽象工厂"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"是否 GoF"}),e.jsx("td",{children:"否（编程习惯）"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"是"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"满足开闭"}),e.jsx("td",{children:"否（加类型要改）"}),e.jsx("td",{children:"是（加产品只加类）"}),e.jsx("td",{children:"加族满足、加等级违反"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"产品数量"}),e.jsx("td",{children:"一种"}),e.jsx("td",{children:"一种（多实现）"}),e.jsx("td",{children:"一族（多种搭配）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"类的数量"}),e.jsx("td",{children:"最少"}),e.jsx("td",{children:"较多（一品一厂）"}),e.jsx("td",{children:"最多"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"典型例子"}),e.jsx("td",{children:"Calendar.getInstance"}),e.jsx("td",{children:"Collection.iterator"}),e.jsx("td",{children:"跨平台 UI 组件库"})]})]})]}),e.jsx("h2",{children:"与相近模式 / 概念的区别"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"vs 建造者"}),"：工厂关注「造哪个对象」（一步拿到成品，关注",e.jsx("em",{children:"类型"}),"）； 建造者关注「怎样一步步装配一个复杂对象」（多步构造，关注",e.jsx("em",{children:"过程与配置"}),"）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"vs 抽象工厂内部用工厂方法"}),"：抽象工厂的每个 ",e.jsx("code",{children:"createXxx"})," 本身常用工厂方法实现， 二者经常组合，但意图不同——一个解决「产品族」，一个解决「单产品延迟创建」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"vs 单纯 new"}),"：当类型固定、几乎不变时，直接 new 最清晰，引入工厂只是噪音。"]})]}),e.jsx(h,{title:"工厂的本质是隔离「易变的创建」",children:e.jsxs("p",{children:["为什么要绕这么大圈子？因为",e.jsx("strong",{children:"new 一个具体类，意味着代码写死了依赖"}),"， 违反依赖倒置原则。工厂模式把「决定造谁」这件最易变的事，从业务逻辑里抽离出来， 让业务只依赖产品接口和工厂接口。一句话：",e.jsx("strong",{children:"工厂模式 = 把创建逻辑抽象化，以满足开闭与依赖倒置"}),"。"]})}),e.jsx(g,{variant:"warn",title:"不要一上来就抽象工厂",children:e.jsxs("p",{children:["层次越高，类越多、越复杂。如果产品只有一两种、几乎不变，直接 new 或简单工厂就够了， 强上工厂方法、抽象工厂就是",e.jsx("strong",{children:"过度设计"}),"。 只有当「产品类型会增长」或「产品需要成套搭配」时，更高层次才划算。"]})}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["工厂模式在框架里随处可见：",e.jsx("strong",{children:"Spring 的 BeanFactory"})," 就是巨型工厂，负责创建和管理所有 Bean；",e.jsx("code",{children:"Calendar.getInstance()"})," 根据地区返回不同的 Calendar 实现，是典型的工厂思想； 日志框架（如 SLF4J 的 ",e.jsx("code",{children:"LoggerFactory.getLogger()"}),"）也用工厂屏蔽底层实现差异。 面试要点：说清三者区别，强调",e.jsx("strong",{children:"简单工厂违反开闭且非 GoF"}),"、",e.jsx("strong",{children:"工厂方法符合开闭"}),"、",e.jsx("strong",{children:"抽象工厂解决产品族"}),"。"]}),e.jsxs("p",{children:["JDK 里还有更多例子可顺手举：",e.jsx("code",{children:"Collection.iterator()"})," 是工厂方法（每个集合返回自己的迭代器实现）、",e.jsx("code",{children:"Integer.valueOf()"})," 是带缓存的静态工厂（-128~127 复用同一对象）、",e.jsx("code",{children:"ThreadLocalRandom.current()"})," 也是静态工厂思想。 被追问「工厂模式和 IoC 容器什么关系」时，可以答：",e.jsx("strong",{children:"IoC 容器就是一个超级通用工厂"}),"， 它把「创建 + 装配 + 生命周期管理」全包了，是工厂思想在框架层面的极致体现。"]}),e.jsxs(p,{title:"手写工厂方法模式",children:[e.jsx("p",{children:"以「创建不同数据库连接」为例，先看简单工厂的写法及其问题，再看如何用工厂方法重构成 「加新数据库只新增类」。最后给出抽象工厂的骨架，体会「产品族」的概念。"}),e.jsx(n,{lang:"java",title:"简单工厂（违反开闭、非 GoF）",code:m}),e.jsx(n,{lang:"java",title:"工厂方法（接口 + 具体工厂）",code:y}),e.jsx(n,{lang:"java",title:"抽象工厂（创建一族 UI 产品）",code:C})]}),e.jsx(x,{points:["工厂模式隔离「易变的对象创建」，让调用方只关心要什么、不关心怎么造，满足开闭与依赖倒置。","简单工厂用一个 if/switch 工厂集中创建，方便但违反开闭，且不属于 GoF 23 种模式。","工厂方法为每个产品配一个工厂，新增产品只加类不改老代码，完美符合开闭原则。","抽象工厂用于创建一整族互相搭配的产品（如同一风格的 UI 组件），换族就换工厂。","层次越高类越多越复杂，产品稳定时强上抽象工厂属于过度设计。","区分产品等级结构（同种产品多实现）与产品族（同风格多种产品组合）：抽象工厂对加族开放、对加等级封闭。","工厂方法的经典形态是「模板方法 + 工厂方法」：父类定流程，把造哪个产品延迟到子类。","实际应用：Spring BeanFactory（超级工厂）、Calendar.getInstance、LoggerFactory、Collection.iterator、Integer.valueOf 都是工厂思想。"]})]})}export{I as default};
