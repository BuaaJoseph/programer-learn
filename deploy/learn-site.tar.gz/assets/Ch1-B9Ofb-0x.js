import{j as e}from"./index-CVHWXZpb.js";import{L as r,S as n}from"./Summary-CJTCDEeZ.js";import{K as i}from"./KeyIdea-XVLVSS4B.js";import{C as s}from"./Callout-DCq22jZW.js";import{C as t}from"./CodeBlock-ljkh5ShG.js";import{E as c}from"./Example-BSuN_UvG.js";const d=`import SwiftUI

struct ProfileView: View {
    @State private var counter = 0
    let user: User

    var body: some View {
        // 打印「这次 body 为什么被重算」——是 @State 变了，还是入参变了
        let _ = Self._printChanges()

        VStack {
            Text(user.name)
            Button("点我 \\(counter)") { counter += 1 }
        }
    }
}

// 控制台会输出类似：
// ProfileView: _counter changed.
// 说明这次重算是因为 counter 这个 @State 发生了变化`,l=`// ❌ 反例：body 里做了昂贵计算，每次重算都全量重跑
struct BadListView: View {
    let items: [Item]
    var body: some View {
        // 排序 + 过滤写在 body 里：只要视图重算就重新算一遍
        let sorted = items
            .filter { $0.isEnabled }
            .sorted { $0.score > $1.score }
        List(sorted) { item in
            Text(item.title)
        }
    }
}

// ✅ 正解一：把派生数据上移到 ViewModel，用缓存/计算属性管理
// ✅ 正解二：用稳定 id 的 List，让 SwiftUI 精确 diff，而非整列重建`,o=`// 数据模型遵循 Identifiable，且 id 必须「稳定」——
// 不要用数组下标 (offset)、也不要每次新建随机 UUID 当 id
struct Item: Identifiable, Equatable {
    let id: UUID          // 持久、稳定，跨刷新不变
    var title: String
    var score: Int
}

struct GoodListView: View {
    let items: [Item]
    var body: some View {
        // List 直接吃 Identifiable，SwiftUI 能按 id 做最小化 diff
        List(items) { item in
            ItemRow(item: item)   // 拆成独立子视图，缩小重算范围
        }
    }
}

// ItemRow 只依赖自己那一行的数据，
// 其它行变化时它不会被重算 —— 这就是「拆分视图」的收益`,h=`// 给子视图加 Equatable，可让 SwiftUI 在入参没变时跳过 body
struct ItemRow: View, Equatable {
    let item: Item

    var body: some View {
        HStack {
            Text(item.title)
            Spacer()
            Text("\\(item.score)")
        }
    }

    // 入参相等就认为视图相等，SwiftUI 据此跳过这次重算
    static func == (lhs: ItemRow, rhs: ItemRow) -> Bool {
        lhs.item == rhs.item
    }
}`,a=`import XCTest
@testable import MyApp

final class CounterViewModelTests: XCTestCase {
    func testIncrementRaisesCount() {
        // Given：一个初始计数为 0 的 ViewModel
        let sut = CounterViewModel(start: 0)

        // When：调用一次自增
        sut.increment()

        // Then：计数变为 1
        XCTAssertEqual(sut.count, 1)
    }

    func testCannotGoBelowZero() {
        let sut = CounterViewModel(start: 0)
        sut.decrement()
        XCTAssertEqual(sut.count, 0, "计数不应小于 0")
    }
}`,x=`import Testing
@testable import MyApp

// 新一代 Swift Testing：用 @Test 标记、用 #expect 断言，语法更轻
struct CounterViewModelTests {
    @Test func incrementRaisesCount() {
        let sut = CounterViewModel(start: 0)
        sut.increment()
        #expect(sut.count == 1)
    }

    // 参数化测试：一个函数跑多组用例
    @Test(arguments: [0, 5, 99])
    func incrementFrom(_ start: Int) {
        let sut = CounterViewModel(start: start)
        sut.increment()
        #expect(sut.count == start + 1)
    }
}`,j=`import Testing
@testable import MyApp

struct UserServiceTests {
    // 异步测试：直接 await，无需 XCTestExpectation 那套回调样板
    @Test func fetchUserReturnsName() async throws {
        // 注入一个假的网络层（协议实现），不打真实接口
        let service = UserService(api: MockAPI(json: validUserJSON))

        let user = try await service.fetchUser(id: "42")

        #expect(user.name == "张三")
    }

    // 断言会抛错：用 #expect(throws:)
    @Test func fetchInvalidUserThrows() async {
        let service = UserService(api: MockAPI(failWith: .notFound))
        await #expect(throws: APIError.notFound) {
            try await service.fetchUser(id: "bad")
        }
    }
}`,p=`// 可测试性的关键：依赖「协议」而非「具体实现」，从外部注入
protocol APIClient {
    func get(_ path: String) async throws -> Data
}

// 生产实现：真的发网络请求
struct LiveAPIClient: APIClient {
    func get(_ path: String) async throws -> Data { /* URLSession... */ }
}

// 测试替身：返回预设数据，不碰网络，结果可预测
struct MockAPI: APIClient {
    var json: Data = Data()
    func get(_ path: String) async throws -> Data { json }
}

@MainActor
final class UserViewModel: ObservableObject {
    @Published var name = ""
    private let api: APIClient          // 依赖抽象

    // 构造器注入：生产传 Live，测试传 Mock
    init(api: APIClient) { self.api = api }
}`,f=`import XCTest

// UI 测试运行在「另一个进程」里，通过无障碍标识操纵真实界面
final class LoginUITests: XCTestCase {
    func testLoginFlow() {
        let app = XCUIApplication()
        app.launch()

        // 通过 accessibilityIdentifier 定位控件，比按文案更稳
        app.textFields["username"].tap()
        app.textFields["username"].typeText("alice")

        app.secureTextFields["password"].tap()
        app.secureTextFields["password"].typeText("secret")

        app.buttons["loginButton"].tap()

        // 断言登录后首页出现
        XCTAssertTrue(app.staticTexts["欢迎回来"].waitForExistence(timeout: 3))
    }
}`;function T(){return e.jsxs("article",{children:[e.jsxs(r,{children:["App 写得能跑只是起点，能不能",e.jsx("strong",{children:"跑得顺、改得稳、上线后不崩"}),"才是工程化的分水岭。 这一章我们把 iOS 的「质量三件套」讲透：用 Instruments 量化并定位性能瓶颈，用调试技巧看清 SwiftUI 到底为什么重算，再用单元测试 / UI 测试给代码织一张安全网。贯穿全章的主线是一句话——",e.jsx("strong",{children:"先测量，再优化；先解耦，才可测"}),"。"]}),e.jsx("h2",{children:"一、性能分析：先测量，别猜"}),e.jsxs(i,{children:["性能优化的第一原则是",e.jsx("strong",{children:"不要凭感觉猜瓶颈"}),"。人对「哪段代码慢」的直觉常常是错的。 正确做法是用 Instruments 这类剖析工具",e.jsx("strong",{children:"测量"}),"出真正的热点，针对数据动手，再测量验证。 盲目优化往往把时间花在不痛不痒的地方。"]}),e.jsxs("p",{children:["Instruments 是 Xcode 自带的性能剖析套件，从菜单",e.jsx("code",{children:"Product ▸ Profile"}),"（快捷键 ",e.jsx("code",{children:"⌘I"}),"）启动。它会把 App 以 Release 优化级别构建后在真机上运行，并按「模板（Instrument）」采集不同维度的数据。 下面是最常用的几个模板。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Instrument 模板"}),e.jsx("th",{children:"解决什么问题"}),e.jsx("th",{children:"关键看什么"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"Time Profiler"}),e.jsx("td",{children:"CPU 耗时：哪个函数最吃 CPU"}),e.jsx("td",{children:"调用树里占比最高的栈（heaviest stack trace）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Allocations"}),e.jsx("td",{children:"内存分配：谁分配了大量对象"}),e.jsx("td",{children:"持续增长的分配、过大的瞬时峰值"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Leaks"}),e.jsx("td",{children:"内存泄漏：对象该释放却没释放"}),e.jsx("td",{children:"红色叉号标记的泄漏块与其引用环"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"SwiftUI"}),e.jsx("td",{children:"视图重算：哪些 body 算得太频繁"}),e.jsx("td",{children:"View Body 的次数与耗时、长帧（hitch）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Animation Hitches"}),e.jsx("td",{children:"掉帧 / 卡顿"}),e.jsx("td",{children:"超过帧预算的渲染提交"})]})]})]}),e.jsx("h3",{children:"Time Profiler：找出耗时的函数"}),e.jsxs("p",{children:["Time Profiler 按固定时间间隔对线程「拍快照」，统计每个函数出现在调用栈里的次数， 近似得出 CPU 时间分布。看的时候要勾上 ",e.jsx("code",{children:"Hide System Libraries"})," 只看自己的代码， 再用 ",e.jsx("code",{children:"Invert Call Tree"})," 把最底层的热点函数顶到列表上方。占比最高的那几行， 就是优化的优先目标。"]}),e.jsx("h3",{children:"Allocations 与 Leaks：找内存问题"}),e.jsxs("p",{children:["内存问题分两类。一类是",e.jsx("strong",{children:"真泄漏"}),"：对象失去引用却没被释放，",e.jsx("code",{children:"Leaks"})," 模板会直接标红，通常源于 ",e.jsx("strong",{children:"强引用环"}),"（闭包捕获 self、 delegate 没用 weak）。另一类是",e.jsx("strong",{children:"滥用 / 涨而不退"}),"：没泄漏但分配过多、内存只升不降， 靠 ",e.jsx("code",{children:"Allocations"})," 的时间曲线和「Generations」标记来定位是哪段操作把内存推高了。"]}),e.jsxs(s,{variant:"warn",title:"最常见的泄漏：闭包捕获 self",children:["在 ",e.jsx("code",{children:"Task"}),"、闭包或异步回调里直接用 ",e.jsx("code",{children:"self"}),"，很容易形成 「self 持有闭包、闭包又持有 self」的引用环。解法是用捕获列表",e.jsx("code",{children:"[weak self]"}),"，并在用时 ",e.jsx("code",{children:"guard let self else { return }"}),"。 Leaks 模板里那个绕成环的引用图，多半就指向它。"]}),e.jsx("h3",{children:"SwiftUI Instrument：看 body 重算"}),e.jsxs("p",{children:["SwiftUI 是声明式的：状态一变，框架就重新计算受影响视图的 ",e.jsx("code",{children:"body"}),"，再 diff 出最小更新。 如果某个 ",e.jsx("code",{children:"body"})," 算得过于频繁、或单次算得太贵，界面就会卡。SwiftUI 模板能告诉你",e.jsx("strong",{children:"每个视图的 body 被算了多少次、各花了多久"}),"，以及哪些帧超出了渲染预算（出现 hitch）。 这是定位 SwiftUI 性能问题最直接的工具。"]}),e.jsx("h2",{children:"二、SwiftUI 常见性能陷阱"}),e.jsx("p",{children:"SwiftUI 的性能问题几乎都可以归到「重算太多」或「单次重算太贵」这两类。逐个来看。"}),e.jsx("h3",{children:"陷阱 1：昂贵的 body"}),e.jsxs("p",{children:[e.jsx("code",{children:"body"})," 是",e.jsx("strong",{children:"纯函数"}),"，会被频繁调用，因此里面绝不该放重活—— 排序、过滤、正则、日期格式化、大对象构造等都不该写在 ",e.jsx("code",{children:"body"})," 里。 正确做法是把这些派生计算上移到 ViewModel，用计算属性或缓存维护，",e.jsx("code",{children:"body"})," 只负责描述界面。"]}),e.jsx(t,{lang:"swift",title:"反例：把排序过滤写进了 body",code:l}),e.jsx("h3",{children:"陷阱 2：不必要的状态依赖触发重算"}),e.jsxs("p",{children:["SwiftUI 会追踪一个视图",e.jsx("strong",{children:"读取"}),"了哪些状态，被读取的状态一变就重算该视图。 如果你把一个粒度过粗的大对象（比如整个 ",e.jsx("code",{children:"@ObservedObject"}),"）塞进很多视图， 任何一个字段变化都会引发一大片重算。",e.jsx("strong",{children:"缩小依赖粒度"}),"——只把视图真正用到的那部分 传进去，是减少重算最有效的手段之一。"]}),e.jsx("h3",{children:"陷阱 3：大数据 List 与不稳定的 id"}),e.jsxs("p",{children:["长列表性能的关键是让 SwiftUI 能做",e.jsx("strong",{children:"精确 diff"}),"，而这依赖",e.jsx("strong",{children:"稳定的标识"}),"。 如果用数组下标当 id，或每次刷新都给元素 new 一个随机 ",e.jsx("code",{children:"UUID"}),"，SwiftUI 就无法判断 「这一行还是不是上一行」，只能整列重建，既慢又会丢失动画与选中态。 正确做法是让模型遵循 ",e.jsx("code",{children:"Identifiable"})," 且 id 持久不变。"]}),e.jsx(t,{lang:"swift",title:"稳定的 Identifiable + 拆分子视图",code:o}),e.jsxs(s,{variant:"tip",title:"给重的子视图加 Equatable",children:["当一个子视图的 ",e.jsx("code",{children:"body"})," 较贵、而它只依赖少量入参时，可让它遵循",e.jsx("code",{children:"Equatable"})," 并实现 ",e.jsx("code",{children:"=="}),"。入参没变时 SwiftUI 会直接跳过这次 body 计算， 进一步收窄重算范围。"]}),e.jsx(t,{lang:"swift",title:"Equatable 视图：入参没变就跳过 body",code:h}),e.jsx("h2",{children:"三、调试技巧：看清「为什么会这样」"}),e.jsxs("p",{children:["除了断点这种基本功，SwiftUI 还有几招专门用来回答「这个视图",e.jsx("strong",{children:"为什么"}),"重算了」。"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"断点"}),"：在可疑代码行设普通断点；用",e.jsx("strong",{children:"条件断点"}),"只在",e.jsxs("code",{children:["count ",">"," 100"]})," 时停；用",e.jsx("strong",{children:"符号断点"}),"对 ",e.jsx("code",{children:"malloc_error_break"}),"、 崩溃符号统一拦截。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Self._printChanges()"}),"：在 ",e.jsx("code",{children:"body"})," 里加一行，控制台会打印 「这次重算是哪个状态 / 入参引起的」，是定位「莫名其妙又重算了」的利器。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"预览（Preview）调试"}),"：Xcode Previews 支持热重载，能针对单个视图、 注入假数据快速验证布局与状态分支，不必每次跑整个 App。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"视图层级调试器"}),"：运行时点 ",e.jsx("code",{children:"Debug View Hierarchy"})," 可 3D 拆解 当前界面，查约束冲突、看不见的覆盖层等问题。"]})]}),e.jsx(t,{lang:"swift",title:"用 Self._printChanges() 看重算原因",code:d}),e.jsxs(s,{variant:"warn",title:"_printChanges 仅供调试",children:[e.jsx("code",{children:"Self._printChanges()"})," 是带下划线的私有 API，只该在调试期临时使用， 发布前务必移除，不要把它留在生产代码里。"]}),e.jsx("h2",{children:"四、测试体系：单元、异步与 UI"}),e.jsxs(i,{children:["测试不是「写完功能后的额外负担」，而是让你",e.jsx("strong",{children:"敢于重构"}),"的底气。 一个有测试网的工程，你改完代码跑一遍测试就知道有没有破坏既有行为； 没有测试网，每次改动都像在黑暗里走路。"]}),e.jsx("h3",{children:"单元测试：XCTest 与新的 Swift Testing"}),e.jsxs("p",{children:["单元测试验证「一小块逻辑」的输入输出是否符合预期，跑得快、定位准。iOS 上有两套框架： 老牌的 ",e.jsx("strong",{children:"XCTest"}),"（继承 ",e.jsx("code",{children:"XCTestCase"}),"、用 ",e.jsx("code",{children:"XCTAssert*"})," 断言） 与较新的 ",e.jsx("strong",{children:"Swift Testing"}),"（用 ",e.jsx("code",{children:"@Test"})," 标记函数、用 ",e.jsx("code",{children:"#expect"})," 断言， 语法更轻、报错信息更友好，还原生支持参数化）。两者可以共存，新代码推荐用 Swift Testing。"]}),e.jsx(t,{lang:"swift",title:"XCTest 风格",code:a}),e.jsx(t,{lang:"swift",title:"Swift Testing 风格（@Test / #expect）",code:x}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"对比项"}),e.jsx("th",{children:"XCTest"}),e.jsx("th",{children:"Swift Testing"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"测试用例"}),e.jsxs("td",{children:["类里以 ",e.jsx("code",{children:"test"})," 开头的方法"]}),e.jsxs("td",{children:[e.jsx("code",{children:"@Test"})," 标记的任意函数"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"断言"}),e.jsxs("td",{children:[e.jsx("code",{children:"XCTAssertEqual"})," 等一族"]}),e.jsxs("td",{children:["统一的 ",e.jsx("code",{children:"#expect"})," / ",e.jsx("code",{children:"#require"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"参数化"}),e.jsx("td",{children:"需手写循环"}),e.jsxs("td",{children:[e.jsx("code",{children:"@Test(arguments:)"})," 原生支持"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"异步"}),e.jsx("td",{children:"支持，但有 expectation 样板"}),e.jsxs("td",{children:[e.jsx("code",{children:"async/await"})," 一等公民"]})]})]})]}),e.jsx("h3",{children:"异步测试：直接 await"}),e.jsxs("p",{children:["现代 iOS 代码大量使用 ",e.jsx("code",{children:"async/await"}),"，测试也要能等异步结果。Swift Testing 里直接把测试函数标成",e.jsx("code",{children:"async throws"}),"、在断言前 ",e.jsx("code",{children:"await"})," 即可，干净利落；要断言会抛错则用",e.jsx("code",{children:"#expect(throws:)"}),"。"]}),e.jsx(t,{lang:"swift",title:"异步测试与抛错断言",code:j}),e.jsx("h3",{children:"UI 测试：XCUITest"}),e.jsxs("p",{children:["UI 测试（XCUITest）模拟真实用户在界面上的点击、输入、滑动，验证",e.jsx("strong",{children:"端到端流程"}),"是否通畅。 它运行在独立进程里，通过",e.jsx("strong",{children:"无障碍标识（accessibilityIdentifier）"}),"定位控件—— 按标识比按文案稳定得多，文案会因本地化或文案微调而失效。UI 测试慢、脆，适合覆盖关键路径 （如登录、下单），不该用来覆盖所有细枝末节。"]}),e.jsx(t,{lang:"swift",title:"XCUITest：登录流程端到端",code:f}),e.jsx("h2",{children:"五、可测试性来自架构：MVVM + 协议注入"}),e.jsxs("p",{children:["代码好不好测，很大程度上在",e.jsx("strong",{children:"写之前"}),"就决定了。把业务逻辑塞进 View、或在方法里 直接 ",e.jsx("code",{children:"URLSession.shared"})," 发请求，这种代码几乎没法做单元测试——你无法在不联网的情况下 制造可预测的输入。解法是两条原则的组合："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"MVVM"}),"：把逻辑从 View 抽到 ",e.jsx("code",{children:"ViewModel"}),"，让逻辑脱离 UI 独立存在、可被直接实例化测试。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"协议注入（依赖倒置）"}),"：ViewModel 依赖",e.jsx("strong",{children:"协议"}),"而非具体实现， 通过构造器把依赖",e.jsx("strong",{children:"注入"}),"进来。生产环境注入真实实现，测试时注入 Mock 替身， 于是输入可控、结果可预测。"]})]}),e.jsx(t,{lang:"swift",title:"协议注入：让网络层可被替换",code:p}),e.jsx(c,{title:"为什么这样就能测了",children:e.jsxs("p",{children:["因为 ",e.jsx("code",{children:"UserViewModel"})," 不认识「真实网络」，它只认识 ",e.jsx("code",{children:"APIClient"})," 这个协议。 测试时你递给它一个 ",e.jsx("code",{children:"MockAPI"}),"，它返回预设 JSON——于是「输入固定、输出可断言」， 整段逻辑就能在毫秒级、零网络的环境下被反复验证。这正是「先解耦，才可测」的含义。"]})}),e.jsxs(s,{variant:"tip",title:"把测试接进 CI",children:["本地能跑的测试，更应让它在每次提交时自动跑。用 ",e.jsx("code",{children:"xcodebuild test"})," 命令把整套测试接入 持续集成（CI），就能在合并前自动拦住「改坏了既有功能」的提交——这是测试网真正发挥威力的地方。"]}),e.jsx(n,{points:["性能优化第一原则：先用 Instruments 测量再动手——Time Profiler 找 CPU 热点、Allocations/Leaks 找内存问题、SwiftUI 模板看 body 重算。","SwiftUI 性能陷阱集中在「重算太多 / 单次太贵」：别在 body 里做昂贵计算、缩小状态依赖粒度、长列表用稳定的 Identifiable 并拆分子视图。","调试三招看清重算：条件/符号断点、Self._printChanges() 打印重算原因、Previews 热重载快速验证；_printChanges 仅供调试，发布前移除。","测试是敢重构的底气：单元测试用 XCTest 或更轻的 Swift Testing（@Test/#expect、原生参数化与 async），异步直接 await，关键流程用 XCUITest。","可测试性来自架构：MVVM 把逻辑抽离 UI，协议注入让依赖可被 Mock 替换，做到「输入可控、输出可断言」——先解耦，才可测。"]})]})}export{T as default};
