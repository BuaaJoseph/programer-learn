import{r as m,j as e}from"./index-DraKZMSn.js";import{L as p,S as R}from"./Summary-D7nqkGRf.js";import{K as Z}from"./KeyIdea-C2HcfWY0.js";import{E}from"./Example-yyME7alB.js";import{P as N}from"./Practice-Bq0moWPJ.js";import{C as a}from"./Callout-BE-nWzIM.js";import{C as i}from"./CodeBlock-BiqAHAS8.js";import{F as S}from"./Figure-BqzlOW-g.js";const o=[10,23,37,48,55,62,78,90],k=[1,2,1,3,1,2,1,2],O=[55,78,23];function f(){const[n,h]=m.useState(55),d=o.map((s,t)=>56+t*48),j=o.indexOf(n),g=e.jsxs(e.Fragment,{children:[O.map(s=>e.jsxs("button",{className:`fig-btn ${n===s?"active":""}`,onClick:()=>h(s),children:["查 ",s]},s)),e.jsx("span",{className:"fig-note",children:"ZSet 用跳表：O(log N) 找到分数、支持范围/排名"})]});return e.jsx(S,{caption:"跳表在原始链表上叠加多层「快速通道」。查找从最高层开始，能跳就跳、跳过头就下降一层，平均 O(log N)——这正是 ZSet 排行榜按分数排序与范围查询的底座。",controls:g,children:e.jsxs("svg",{viewBox:"0 0 460 200",width:"460",role:"img","aria-label":"跳表查找",children:[[3,2,1].map((s,t)=>{const r=30+t*42;return e.jsxs("g",{children:[e.jsxs("text",{x:"14",y:r+5,fontFamily:"var(--mono)",fontSize:"10",fill:"var(--ink-faint)",children:["L",s]}),e.jsx("line",{x1:"40",y1:r,x2:"440",y2:r,stroke:"var(--border)"}),o.map((x,l)=>{if(k[l]<s)return null;const c=x===n;return e.jsxs("g",{children:[e.jsx("circle",{cx:d[l],cy:r,r:"11",fill:c?"var(--rose)":"var(--rose-soft)",stroke:c?"var(--rose)":"var(--rose-line)"}),e.jsx("text",{x:d[l],y:r+4,textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"9",fontWeight:c?"700":"400",fill:c?"#ffffff":"var(--ink)",children:x})]},l)})]},s)}),e.jsx("rect",{x:"40",y:"158",width:"400",height:"30",rx:"7",fill:"var(--green-soft)",stroke:"var(--green-line)"}),e.jsxs("text",{x:"52",y:"178",fontFamily:"var(--mono)",fontSize:"12",fill:"var(--green)",children:["ZRANK 得到「",n,"」的排名 = 第 ",j+1," 名（从高层快速逼近，再下沉命中）"]})]})})}const u=`# 游戏排行榜：score=分数，member=玩家
127.0.0.1:6379> ZADD game:rank 1500 alice 1200 bob 1800 carol
(integer) 3

# 玩家加分（原子）：carol 又赢了一局 +50
127.0.0.1:6379> ZINCRBY game:rank 50 carol
"1850"

# Top10 排行榜（从高到低，带分数）
127.0.0.1:6379> ZREVRANGE game:rank 0 9 WITHSCORES
1) "carol"
2) "1850"
3) "alice"
4) "1500"
5) "bob"
6) "1200"

# 查某个玩家的排名（ZREVRANK 是从高到低的名次，0 开始）
127.0.0.1:6379> ZREVRANK game:rank alice
(integer) 1                 # alice 排第 2 名`,A=`# 延时队列：score=到期时间戳(毫秒)，member=任务ID
# 把「30秒后执行」的任务塞进来
127.0.0.1:6379> ZADD delay:queue 1718500000000 task:order_close:99
(integer) 1

# 消费者轮询：取出所有「已到期」的任务（score <= 当前时间）
127.0.0.1:6379> ZRANGEBYSCORE delay:queue 0 1718500005000
1) "task:order_close:99"

# 取到后用 ZREM 删除，避免重复消费（生产中用 Lua 保证原子）
127.0.0.1:6379> ZREM delay:queue task:order_close:99
(integer) 1`,C=`# ZSet 小的时候是 listpack，大了切「跳表 + 字典」
127.0.0.1:6379> ZADD top 90 a 85 b
(integer) 2
127.0.0.1:6379> OBJECT ENCODING top
"listpack"

# 元素数超过 zset-max-listpack-entries(默认128)
# 或成员长度超过 zset-max-listpack-value(默认64) → skiplist
127.0.0.1:6379> CONFIG GET zset-max-listpack-entries
1) "zset-max-listpack-entries"
2) "128"`,b=`# ZSet 的范围与排名命令全家桶
# 按排名取区间（0 到 -1 表示全部，从低到高）
ZRANGE game:rank 0 -1 WITHSCORES

# 按分数区间取，( 表示开区间，+inf/-inf 表示无穷
ZRANGEBYSCORE game:rank 1000 (1800        # [1000, 1800)
ZRANGEBYSCORE game:rank -inf +inf         # 全量

# 分页：取分数 1000~2000 内的第 0~9 个（LIMIT offset count）
ZRANGEBYSCORE game:rank 1000 2000 LIMIT 0 10

# 统计某分数区间内有几个成员
ZCOUNT game:rank 1500 2000

# 字典序区间（同分场景，要求所有成员同分才有意义）
ZRANGEBYLEX names [a [c

# Redis 6.2+ 统一新命令：ZRANGE 支持 REV / BYSCORE / BYLEX
ZRANGE game:rank 0 9 REV WITHSCORES       # 等价 ZREVRANGE`,G=`# 跳表节点的简化结构（zskiplistNode）
struct zskiplistNode {
    sds        ele;        // 成员名 member
    double     score;      // 分值，用于排序
    struct zskiplistNode *backward;   // 后退指针，支持反向遍历
    struct zskiplistLevel {
        struct zskiplistNode *forward; // 每一层的前进指针
        unsigned long span;            // 跨度：到下个节点跨过几个节点(算排名用)
    } level[];             // 柔性数组，层数随机决定
}

# 关键点：
# 1. 排序键是 (score, ele)：score 相同则按成员字典序排，保证全序
# 2. span 累加 = 排名，所以 ZRANK / ZREVRANK 也是 O(log N)
# 3. 层高随机生成，期望 1/4 概率升一层(Redis 默认 p=0.25)，最高 32 层`;function V(){return e.jsxs(e.Fragment,{children:[e.jsx(p,{children:e.jsxs("p",{children:["「做一个实时排行榜」几乎是后端面试的标准题，而标准答案永远是 Redis 的 ",e.jsx("strong",{children:"ZSet"}),"。 为什么排行榜偏偏用它？因为 ZSet 底层藏着一个叫",e.jsx("em",{children:"跳表"}),"（skiplist）的结构，能在 O(log N) 内完成 「按分数排序、查名次、取一段区间」——这些恰好是排行榜的全部需求。这一章把跳表讲透。"]})}),e.jsx("h2",{children:"ZSet 的底层：跳表 + 字典，一个都不能少"}),e.jsxs("p",{children:["当 ZSet 元素变多（超过 ",e.jsx("code",{children:"zset-max-listpack-entries"}),"，默认 128）后，它的底层编码会从 listpack 切成",e.jsx("strong",{children:"跳表（skiplist）加字典（dict）的组合"}),"。这两个结构存的是同一批数据，但各管一头："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"字典 dict"}),"：保存「member → score」的映射，让 ",e.jsx("code",{children:"ZSCORE member"}),"（按成员查分数）做到 O(1)。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"跳表 skiplist"}),"：按 score 从小到大把成员串起来，支持",e.jsx("strong",{children:"按分数排序、范围查询、查排名"}),"，都是 O(log N)。"]})]}),e.jsxs("p",{children:["两个结构的成员对象是",e.jsx("strong",{children:"共享"}),"的（指针指向同一份），所以不会双倍存数据。一句话： 字典负责「按名字找分数」，跳表负责「按分数找排序」，配合起来 ZSet 才能既快查分又快排序。 没有字典，",e.jsx("code",{children:"ZSCORE"})," 就得在跳表里 O(N) 找成员；没有跳表，",e.jsx("code",{children:"ZRANGE"})," 就得给字典全量排序——缺一不可。"]}),e.jsx("h3",{children:"跳表是什么：给链表加「快速通道」"}),e.jsxs("p",{children:["想象一个按分数排好序的",e.jsx("em",{children:"有序链表"}),"，查一个值得从头一个个走，O(N)。跳表的聪明之处是：在原始链表之上， 随机给一部分节点",e.jsx("strong",{children:"加几层索引"}),"，高层索引节点稀疏、跨度大，像高速路的服务区。查找时",e.jsx("strong",{children:"从最高层开始， 能跳就跳"}),"，跳过头了就下降一层、继续逼近目标，逐层下沉直到命中。"]}),e.jsxs("p",{children:["因为每层的节点数大约是下一层的一半，层数约为 log N，所以查找、插入、删除都是 ",e.jsx("strong",{children:"O(log N)"}),"。 范围查询更是跳表的强项：先 O(log N) 定位到区间起点，然后沿最底层链表",e.jsx("strong",{children:"顺着指针往后扫"}),"即可， 这正是 ",e.jsx("code",{children:"ZRANGE"})," / ",e.jsx("code",{children:"ZRANGEBYSCORE"})," 高效的原因。"]}),e.jsx(f,{}),e.jsx("h3",{children:"层高怎么定？为什么是随机的"}),e.jsxs("p",{children:["跳表不靠旋转、变色这类复杂操作维持平衡，而是靠",e.jsx("strong",{children:"随机层高"}),"。每插入一个新节点，就抛硬币决定它的层数： Redis 用概率 ",e.jsx("code",{children:"p = 0.25"}),"，即一个节点有 1/4 概率多升一层，期望层高约 1.33，最高 32 层（足以支撑约 2³² 个元素）。 随机化让整张表在统计意义上保持「上稀下密」的平衡，避免了树结构那套旋转逻辑。下面是跳表节点的真实结构， 注意 ",e.jsx("code",{children:"span"})," 字段——它是查排名（",e.jsx("code",{children:"ZRANK"}),"）能做到 O(log N) 的关键："]}),e.jsx(i,{lang:"text",title:"zskiplistNode 结构与排序键",code:G}),e.jsxs("p",{children:["一个易被忽略的点：跳表的排序键是 ",e.jsx("strong",{children:"(score, member)"})," 二元组。分数相同时按成员名的",e.jsx("strong",{children:"字典序"}),"排， 这样保证全序、排名唯一，也让 ",e.jsx("code",{children:"ZRANGEBYLEX"}),"（同分时按字典序取区间）有了意义。"]}),e.jsxs(E,{title:"游戏排行榜 Top10 怎么落地",children:[e.jsx("p",{children:"一个有上万玩家的游戏排行榜，用 ZSet 只需要几条命令就搞定，而且全是 O(log N) 级别："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"加分"}),"：玩家得分用 ",e.jsx("code",{children:"ZINCRBY game:rank 50 carol"})," 原子累加，不用读出来再写回。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Top10"}),"：",e.jsx("code",{children:"ZREVRANGE game:rank 0 9 WITHSCORES"})," 直接拿到分数最高的前 10 名及分数。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"查我的名次"}),"：",e.jsx("code",{children:"ZREVRANK game:rank alice"})," 得到从高到低的排名，前端显示「你排第 N 名」。"]})]}),e.jsxs("p",{children:["换成关系型数据库，每刷新一次排行榜都要 ",e.jsx("code",{children:"ORDER BY score DESC LIMIT 10"})," 全表排序，上万玩家高并发下直接崩； ZSet 因为数据天然按分数有序，取 Top10 几乎零成本。"]})]}),e.jsx(a,{variant:"info",title:"实战进阶：同分如何按时间排序",children:e.jsxs("p",{children:["排行榜常有个需求：分数相同时，",e.jsx("strong",{children:"先达到的人排前面"}),"。但 ZSet 同分是按成员字典序排的，不满足这个需求。 经典技巧是把",e.jsx("strong",{children:"时间编码进 score"}),"：用一个 double，整数部分放分数、小数部分放 「（最大时间戳 - 当前时间戳）/ 一个大常数」，让早到的时间换算出更大的 score。或者更稳妥地用",e.jsx("code",{children:"score * 10^13 + (maxTs - ts)"})," 这种「高位放分、低位放时间」的复合分值。这是排行榜面试的高频追问。"]})}),e.jsx("h2",{children:"为什么用跳表，不用红黑树？"}),e.jsx("p",{children:"平衡二叉树（红黑树、AVL）同样能做到 O(log N) 的有序操作，但 Redis 作者偏偏选了跳表，原因很实际："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"范围查询更友好"}),"：跳表最底层就是一条有序链表，定位到起点后顺着指针扫一段即可； 红黑树取区间得做中序遍历、来回上下跳节点，实现和效率都更别扭。",e.jsx("code",{children:"ZRANGE"})," 这种区间操作 ZSet 用得极多。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"实现简单、易维护"}),"：跳表插入删除只需调整少数几个指针，靠随机层高保持平衡，没有红黑树那套 复杂的旋转和变色逻辑，代码少、出 bug 概率低。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"更易做并发/演进"}),"：跳表的局部修改特性，让它在需要并发或迭代时比树结构更容易处理。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"内存可调"}),"：通过调小概率 p 可以减少层数、省内存；树结构的内存开销是固定的。"]})]}),e.jsx(Z,{title:"ZSet = 字典(O(1)查分) + 跳表(O(log N)排序)",children:e.jsx("p",{children:"记住这个组合就抓住了 ZSet 的精髓：任何「既要按 key 精确查，又要按值排序/取区间」的需求， ZSet 都是首选。排行榜、带权重的去重列表、按时间排序的延时队列，本质都是这同一个能力的不同包装。"})}),e.jsx("h3",{children:"延时队列：把「到期时间」当 score"}),e.jsxs("p",{children:["ZSet 还有个经典用法是",e.jsx("strong",{children:"延时队列"}),"：把任务的",e.jsx("em",{children:"到期时间戳"}),"当作 score，任务 ID 当 member。 消费者只需周期性地 ",e.jsx("code",{children:"ZRANGEBYSCORE delay:queue 0 当前时间"}),"，就能一次性捞出所有「已经到期」的任务来执行。 订单 30 分钟未支付自动关闭、消息延迟推送，都能这么实现。"]}),e.jsx(a,{variant:"warn",title:"延时队列的坑",children:e.jsxs("ul",{children:[e.jsxs("li",{children:["「取出 + 删除」必须",e.jsx("strong",{children:"原子"}),"，否则多个消费者会重复消费同一个任务——生产中用 Lua 脚本把",e.jsx("code",{children:"ZRANGEBYSCORE"})," 和 ",e.jsx("code",{children:"ZREM"})," 包成一步。"]}),e.jsx("li",{children:"轮询有延迟和空转开销，对实时性极高或量极大的场景，更适合用专门的消息队列（如 Kafka、RabbitMQ 延迟插件）。"}),e.jsx("li",{children:"单个 ZSet 太大时操作会变慢，可按「到期时间分桶」拆成多个 ZSet（如每分钟一个 key），分摊压力。"})]})}),e.jsx("h2",{children:"面试怎么答"}),e.jsxs("p",{children:["被问「排行榜为什么用 ZSet」，标准答法三句话：一是 ",e.jsx("strong",{children:"ZSet 底层是跳表 + 字典"}),"，字典保证 O(1) 查分、 跳表保证 O(log N) 排序和范围查询；二是",e.jsx("strong",{children:"排行榜的核心操作（加分、取 Top N、查名次）正好都被跳表覆盖"}),"， 而数据库要全表排序扛不住高并发；三是",e.jsx("strong",{children:"跳表相比红黑树更适合范围查询、实现也更简单"}),"。"]}),e.jsxs("p",{children:["常见追问：「跳表怎么查排名？」——靠每层指针上的 ",e.jsx("code",{children:"span"}),"（跨度），查找路径上把 span 累加起来就是排名。 「层高怎么定？」——随机，Redis 用 p=0.25、最高 32 层。「同分怎么排？」——按成员字典序，要按时间排需把时间编码进 score。 「为什么不用 B+ 树？」——B+ 树为磁盘 IO 优化（减少树高），而 ZSet 全在内存，跳表实现更简单、范围扫描同样高效。"]}),e.jsxs(N,{title:"动手做一个排行榜 + 延时队列",children:[e.jsxs("p",{children:["先用几条命令把游戏排行榜跑起来，体会 ",e.jsx("code",{children:"ZINCRBY"})," / ",e.jsx("code",{children:"ZREVRANGE"})," / ",e.jsx("code",{children:"ZREVRANK"})," 的配合："]}),e.jsx(i,{lang:"bash",title:"排行榜",code:u}),e.jsx("p",{children:"再把范围、排名、分页命令都摸一遍，这是 ZSet 真正的威力所在："}),e.jsx(i,{lang:"bash",title:"范围与排名命令全家桶",code:b}),e.jsx("p",{children:"再用同一个 ZSet 实现延时队列，把到期时间戳当分数："}),e.jsx(i,{lang:"bash",title:"延时队列",code:A}),e.jsxs("p",{children:["最后用 ",e.jsx("code",{children:"OBJECT ENCODING"})," 观察 ZSet 何时从 listpack 切到 skiplist："]}),e.jsx(i,{lang:"bash",title:"编码切换",code:C})]}),e.jsx(R,{points:["ZSet 底层是「跳表 skiplist + 字典 dict」的组合：字典管 O(1) 按成员查分，跳表管 O(log N) 排序与范围查询。","跳表是给有序链表加多层稀疏索引，查找时从高层「能跳就跳」逐层下降，复杂度 O(log N)。","层高随机生成(Redis 用 p=0.25、最高32层)，靠随机化保持平衡，无需旋转变色；span 跨度让查排名也是 O(log N)。","排序键是 (score, member)：同分按成员字典序，要按时间排需把时间编码进 score。","范围查询是跳表强项：定位起点后沿最底层链表顺扫，这是 ZRANGE/ZRANGEBYSCORE 高效的根本。","选跳表不选红黑树/B+树：范围查询更友好、实现更简单、内存可调、更易并发与演进。","排行榜用 ZADD/ZINCRBY 加分、ZREVRANGE 取 TopN、ZREVRANK 查名次；延时队列把到期时间戳当 score，取删用 Lua 保证原子。"]})]})}export{V as default};
