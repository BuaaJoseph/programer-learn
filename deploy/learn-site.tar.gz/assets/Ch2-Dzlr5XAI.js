import{j as e}from"./index-BAhU_Xet.js";import{L as c,S as n}from"./Summary-DeCBcqSp.js";import{K as l}from"./KeyIdea-DnEcW4Ye.js";import{E as t}from"./Example-D5OEBxRp.js";import{P as d}from"./Practice-C1BP1gjD.js";import{C as i}from"./Callout-OljS8ooD.js";import{C as r}from"./CodeBlock-ClAC9vi8.js";const o=`<!-- 消费端配置：超时与重试 -->
<!-- timeout：单次调用最多等 1000ms，超过就报 TimeoutException -->
<!-- retries：失败后再重试 2 次（共 3 次），默认配 failover 集群策略 -->
<dubbo:reference id="orderService"
                 interface="com.demo.OrderService"
                 timeout="1000"
                 retries="2"
                 cluster="failover" />

<!-- 也可以在方法级别精细控制：查询可重试，下单不重试 -->
<dubbo:reference id="orderService" interface="com.demo.OrderService">
    <dubbo:method name="queryOrder" timeout="500" retries="2" />
    <dubbo:method name="createOrder" timeout="2000" retries="0" />
</dubbo:reference>`,x=`<!-- provider 端：限制每个方法的并发执行数（服务端自我保护） -->
<dubbo:service interface="com.demo.OrderService" executes="50" />

<!-- consumer 端：限制每个方法的并发调用数（客户端自我克制） -->
<dubbo:reference interface="com.demo.OrderService" actives="20" />

<!-- 超过阈值的请求会被直接拒绝，抛出 RpcException，避免把下游压垮 -->`,s=`// 方式一：Sentinel 熔断降级（@SentinelResource 指定兜底方法）
@Service
public class OrderClient {

    @SentinelResource(value = "queryOrder", fallback = "queryOrderFallback")
    public Order queryOrder(Long id) {
        return orderService.queryOrder(id);   // 远程调用
    }

    // 熔断或异常时走这里，返回兜底数据，不让用户看到报错
    public Order queryOrderFallback(Long id, Throwable ex) {
        Order fallback = new Order();
        fallback.setId(id);
        fallback.setStatus("UNKNOWN");        // 降级标记
        return fallback;
    }
}

// 方式二：Dubbo 原生 Mock 降级（无需引入 Sentinel）
// 1. 配置 reference 开启 mock
//    <dubbo:reference id="orderService"
//                     interface="com.demo.OrderService"
//                     mock="com.demo.OrderServiceMock" />
// 2. 写 Mock 实现，调用失败时自动回退到它
public class OrderServiceMock implements OrderService {
    public Order queryOrder(Long id) {
        Order fallback = new Order();
        fallback.setStatus("DEGRADED");       // 返回兜底
        return fallback;
    }
}`,h=`// 熔断器的三态状态机（Sentinel/Hystrix 通用模型）
//
//        错误率/慢调用超阈值
//   CLOSED ─────────────────────► OPEN
//   (放行)                         (跳闸，全部快速失败)
//     ▲                              │
//     │ 探测请求成功                   │ 熔断时长到期
//     │                              ▼
//   恢复合闸 ◄──── HALF_OPEN ◄────────┘
//                 (放少量探测请求)
//        探测失败 -> 回到 OPEN

// CLOSED：正常放行，同时统计错误率
// OPEN：跳闸期间所有请求不打下游，直接走降级（fail fast）
// HALF_OPEN：熔断时长到了，放几个探测请求试水，成功则合闸、失败则继续 OPEN`,a=`# 不重启动态改超时：通过配置中心下发，覆盖到运行中的实例
# 推到注册中心/配置中心的 configurators，Dubbo 监听后热更新
configVersion: v2.7
key: com.demo.OrderService
enabled: true
configs:
  - side: consumer        # 改消费端
    parameters:
      timeout: 2000        # 把超时从 1000 临时调到 2000，无需重启
  - side: provider        # 也能改提供端
    addresses: [ "192.168.0.13" ]   # 只对某台机器生效（精准降配）
    parameters:
      weight: 50           # 把这台权重调低，给它减压`;function S(){return e.jsxs(e.Fragment,{children:[e.jsx(c,{children:e.jsxs("p",{children:["本地方法调用慢一点、错一次，影响有限；可一旦跨进程、走网络，调用就",e.jsx("strong",{children:"必然"}),"会失败、会变慢—— 网络抖动、对端 GC、机器宕机，都躲不掉。服务治理做的事，本质就是给远程调用",e.jsx("em",{children:"加安全带"}),"： 超时不拖死、失败能重试、过载会限流、雪崩前先熔断、最坏也能降级返回兜底。"]})}),e.jsx("h2",{children:"超时 timeout：别让线程被一直拖住"}),e.jsxs("p",{children:["最危险的不是「调用失败」，而是「调用一直不返回」。每个卡住的请求都占着一个线程，下游一慢，上游线程池被占满， 新请求进不来，整个服务就被一个慢接口拖垮——这就是",e.jsx("em",{children:"线程耗尽"}),"。",e.jsx("strong",{children:"timeout 是第一道安全带"}),"： 到点还没返回就果断放弃，把线程还回去。"]}),e.jsx(r,{lang:"xml",title:"超时与重试配置",code:o}),e.jsxs("p",{children:["经验上，timeout 要按接口的真实耗时来定，留出余量但别太长。链路上多个服务串起来时， 还要注意",e.jsx("strong",{children:"上游的 timeout 应大于下游"}),"，否则上游早早超时、下游却还在白干，纯属浪费。"]}),e.jsx("h2",{children:"重试 retries：好用，但有个大前提"}),e.jsxs("p",{children:["Dubbo 默认的集群策略是 ",e.jsx("em",{children:"failover"}),"（失败自动切换），配合 ",e.jsx("code",{children:"retries"})," 就能在某台 provider 出问题时，自动换另一台重试，对调用方几乎无感。但重试有个铁律："]}),e.jsx(i,{variant:"warn",title:"重试只能用于幂等操作",children:e.jsxs("p",{children:[e.jsx("strong",{children:"查询、读取这类幂等操作可以放心重试"}),"；而下单、扣款、发短信这类",e.jsx("strong",{children:"非幂等"}),"的写操作， 重试会带来重复下单、重复扣款的灾难。所以下单接口要把 ",e.jsx("code",{children:'retries="0"'})," 关掉， 或者在业务侧做幂等设计（如唯一订单号去重）再开重试。这是面试高频考点，务必记牢。"]})}),e.jsx("h2",{children:"限流：保护自己不被打垮"}),e.jsx("p",{children:"限流是「自我保护」：当请求量超过自己能扛的上限时，主动拒绝一部分，保住核心能力，而不是来者不拒最后一起死。 Dubbo 提供两端的并发控制，还可以接专门的限流组件："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsxs("strong",{children:["provider 端 ",e.jsx("code",{children:"executes"})]}),"——限制服务端每个方法的并发执行数，是服务端的自我保护。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:["consumer 端 ",e.jsx("code",{children:"actives"})]}),"——限制客户端每个方法的并发调用数，是客户端的自我克制。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Sentinel / TPS 限流"}),"——按 QPS、按时间窗口做更精细的流量整形，能力比内置的并发数控制强很多。"]})]}),e.jsx(r,{lang:"xml",title:"并发限流配置",code:x}),e.jsx("h2",{children:"熔断与降级：雪崩前的保险丝"}),e.jsxs("p",{children:[e.jsx("em",{children:"熔断"}),"（circuit breaker）的灵感来自电路保险丝：当对某个下游的调用",e.jsx("strong",{children:"错误率或慢调用比例过高"}),"时， 熔断器「跳闸」，接下来一段时间内的请求",e.jsx("strong",{children:"直接快速失败"}),"，不再真正打到那个奄奄一息的下游—— 给它喘息恢复的机会，也避免自己的线程都堆在它身上。过一会儿再放少量请求去「试探」，恢复了就合闸。"]}),e.jsxs("p",{children:[e.jsx("em",{children:"降级"}),"（fallback）是熔断之后的下一步：既然真实结果拿不到，就返回一个",e.jsx("strong",{children:"兜底结果"}),"—— 缓存的旧数据、默认值、或一句「系统繁忙稍后再试」，保证用户体验不至于直接报错。 Sentinel、Hystrix 都提供熔断加降级；Dubbo 自带的 ",e.jsx("em",{children:"Mock 降级"})," 则是更轻量的方案： 调用失败时自动回退到你写的 Mock 实现。"]}),e.jsx(r,{lang:"java",title:"Sentinel 降级与 Dubbo Mock 降级",code:s}),e.jsx("h3",{children:"熔断器的三态状态机"}),e.jsxs("p",{children:["熔断不是「坏了就一直拒绝」，它是一个会自我恢复的",e.jsx("strong",{children:"三态状态机"}),"，这是面试常被追问的细节。 正常时处于 ",e.jsx("code",{children:"CLOSED"}),"（闭合，放行并统计错误率）；错误率或慢调用比例超阈值就跳到 ",e.jsx("code",{children:"OPEN"}),"（断开，所有请求快速失败走降级）；熔断时长到了进入 ",e.jsx("code",{children:"HALF_OPEN"}),"（半开，放几个探测请求试水）， 探测成功就合闸回 ",e.jsx("code",{children:"CLOSED"}),"，失败则继续 ",e.jsx("code",{children:"OPEN"}),"："]}),e.jsx(r,{lang:"text",title:"熔断器三态转换",code:h}),e.jsx(i,{variant:"note",title:"熔断 vs 限流 vs 降级，别混为一谈",children:e.jsxs("p",{children:["三者目的不同：",e.jsx("strong",{children:"限流"}),"是「入口减负」——请求太多主动拒一部分，保护自己不被压垮；",e.jsx("strong",{children:"熔断"}),"是「对下游断流」——下游不行了就别再打它，保护调用链不雪崩；",e.jsx("strong",{children:"降级"}),"是「兜底返回」——拿不到真结果时给个默认值，保护用户体验。限流和熔断触发后， 通常都会走降级返回兜底。面试能把这三个的「保护对象」说清楚就赢了。"]})}),e.jsx("h2",{children:"动态配置：不重启就改治理参数"}),e.jsxs("p",{children:["线上最怕「改个超时还得发版重启」。Dubbo 的治理参数大多能通过",e.jsx("strong",{children:"配置中心动态下发"}),"， 利用前一章讲的 URL + @Adaptive 机制，运行中的实例监听到配置变化就热更新，无需重启。 甚至能精准到「只调某一台机器的权重」做应急降配："]}),e.jsx(r,{lang:"yaml",title:"动态下发治理配置",code:a}),e.jsxs(t,{title:"下游抖动时，怎么不被拖垮",children:[e.jsx("p",{children:"场景：订单服务要调用库存服务，某天库存服务因为一次 GC 频繁卡顿，单次响应从 50ms 飙到 5 秒。如果什么都不做："}),e.jsxs("ul",{children:[e.jsx("li",{children:"订单服务的线程一个个卡在等库存上，线程池很快被占满；"}),e.jsx("li",{children:"新进来的下单请求排不上队，订单服务自己也开始大面积超时；"}),e.jsxs("li",{children:["调订单服务的网关跟着卡，故障像多米诺骨牌一路蔓延——这就是",e.jsx("strong",{children:"服务雪崩"}),"。"]})]}),e.jsxs("p",{children:["加上安全带之后：",e.jsx("code",{children:"timeout=500ms"})," 让线程最多卡半秒就释放；熔断器发现库存调用错误率超阈值后跳闸， 后续请求",e.jsx("strong",{children:"不再真打库存"}),"而是直接走降级，返回「库存查询中」的兜底；库存服务没了持续压力， GC 缓过来后熔断器自动合闸恢复。整条链路稳稳扛住了一次下游抖动。"]})]}),e.jsx(l,{title:"治理的核心是「快速失败 + 兜底」",children:e.jsxs("p",{children:["分布式系统里，",e.jsx("strong",{children:"慢比错更可怕"}),"——错了至少能立刻知道，慢则会悄悄耗光资源引发雪崩。 所以治理的主线就两条：用 timeout 和熔断让失败「来得快」，别拖；用降级和 Mock 让失败「有兜底」，别裸奔。 重试和限流则分别在「失败后争取成功」和「过载前主动减负」上补位。"]})}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["被问「Dubbo 怎么做服务治理 / 怎么防雪崩」，按一条主线串起来答：先 ",e.jsx("strong",{children:"timeout"})," 防线程耗尽， 再 ",e.jsx("strong",{children:"retries"}),"（强调只对幂等读、配 failover），然后 ",e.jsx("strong",{children:"限流"}),"（provider 的 executes、consumer 的 actives、或上 Sentinel 做 QPS 限流），最后 ",e.jsx("strong",{children:"熔断 + 降级"}),"（错误率过高熔断、Mock 或 fallback 兜底）。 能点出「慢比错可怕、治理就是加安全带」这句立意，层次感就有了。"]}),e.jsx(i,{variant:"warn",title:"服务治理的真实坑",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"上游 timeout 小于下游"}),"：上游 500ms 超时，下游配了 1000ms，结果上游早早放弃、下游还在白干，资源全浪费且重试加倍。链路超时应该「越往上游越大」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"熔断阈值拍脑袋"}),"：错误率阈值设太低，正常抖动也跳闸误伤；设太高，等真跳闸下游早被打垮了。要基于真实的错误率基线来调。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"降级数据当真实数据用"}),"：fallback 返回的兜底值若没打标记，上游误以为是真实结果写入库，会造成数据污染。降级结果必须可识别。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"误区「限流配了就万无一失」"}),"：单机限流挡不住集群整体过载，需要分布式限流（如 Sentinel 集群流控）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"重试与超时叠加放大流量"}),"：retries=2 + 下游变慢，瞬间流量×3 压向下游，本想容错反而加速雪崩。治理参数要整体配套，不能各调各的。"]})]})}),e.jsxs(d,{title:"配齐 timeout / retries 并加一个降级",children:[e.jsx("p",{children:"目标：给一个查询接口配上合理的超时与重试，再为它加一个降级兜底（Sentinel fallback 或 Dubbo Mock 二选一）， 然后手动制造下游异常，观察是否平滑回退到兜底结果而不是直接报错。"}),e.jsx(r,{lang:"java",title:"降级示例",code:s}),e.jsxs("p",{children:["验证方法：把下游服务停掉或在它里面 ",e.jsx("code",{children:"Thread.sleep"})," 制造超时，看调用方是否在 timeout 后走进 fallback / Mock，返回带降级标记的兜底数据——这就是「不被拖垮」的可观测证据。"]})]}),e.jsx(n,{points:["远程调用必然会失败和变慢，服务治理的本质是给调用加安全带，核心立意是「慢比错更可怕」。","timeout 防止线程被慢调用一直拖住，是防雪崩的第一道防线，注意上游 timeout 应大于下游。","retries 配合 failover 可在失败时自动切换重试，但只能用于幂等的读操作，写操作要 retries=0。","限流是自我保护：provider 端用 executes、consumer 端用 actives，或接 Sentinel 做 QPS/TPS 限流。","熔断在错误率过高时跳闸快速失败，给下游恢复机会；降级返回兜底结果，Sentinel/Hystrix 或 Dubbo Mock 均可实现。","面试主线：timeout → retries（幂等）→ 限流 → 熔断+降级，串起来讲清「快速失败 + 兜底」即可。"]})]})}export{S as default};
