import{j as e}from"./index-CBMe5udE.js";import{L as o,S as d}from"./Summary-CEfAQ4SZ.js";import{K as s}from"./KeyIdea-K3hFePn1.js";import{C as n}from"./Callout-3wJQ5WDp.js";import{C as t}from"./CodeBlock-D4LRiuTl.js";import{E as r}from"./Example-CFOi3F9j.js";const l=`<!-- 子组件 PanelBox.vue：用 <slot> 占一个“坑” -->
<script setup>
defineProps(['title'])
<\/script>

<template>
  <div class="panel">
    <h3>{{ title }}</h3>
    <div class="panel-body">
      <!-- 父组件标签内部写的内容，会填到这个 slot 的位置 -->
      <slot></slot>
    </div>
  </div>
</template>`,i=`<!-- 父组件：标签内部的内容就是要“填”进默认插槽的东西 -->
<template>
  <PanelBox title="公告">
    <!-- 下面这两行被填进子组件的 <slot> 位置 -->
    <p>今晚 22:00 系统维护。</p>
    <button>知道了</button>
  </PanelBox>
</template>`,c=`<!-- 插槽可以写“默认内容”：父组件没填时显示它 -->
<template>
  <button class="btn">
    <slot>提交</slot>   <!-- 父组件没传内容时，按钮显示“提交” -->
  </button>
</template>

<!-- 父组件 <MyButton /> 显示“提交”；
     <MyButton>保存</MyButton> 显示“保存” -->`,a=`<!-- 子组件 LayoutCard.vue：多个具名插槽 + 一个默认插槽 -->
<template>
  <div class="card">
    <header>
      <slot name="header"></slot>   <!-- 具名插槽：header -->
    </header>

    <main>
      <slot></slot>                 <!-- 没写 name 即默认插槽 -->
    </main>

    <footer>
      <slot name="footer"></slot>   <!-- 具名插槽：footer -->
    </footer>
  </div>
</template>`,h=`<!-- 父组件：用 <template #名字> 指定内容填到哪个具名插槽 -->
<template>
  <LayoutCard>
    <!-- #header 是 v-slot:header 的简写 -->
    <template #header>
      <h2>用户资料</h2>
    </template>

    <!-- 不带 template 包裹、或用 #default 的内容进默认插槽 -->
    <p>这里是卡片正文，进默认插槽。</p>

    <template #footer>
      <button>保存</button>
      <button>取消</button>
    </template>
  </LayoutCard>
</template>`,x=`<!-- 子组件 UserList.vue：作用域插槽——把子组件的数据“传回”给父的插槽内容 -->
<script setup>
defineProps({ users: { type: Array, default: () => [] } })
<\/script>

<template>
  <ul>
    <li v-for="user in users" :key="user.id">
      <!-- 在 <slot> 上像传 props 一样把数据绑上去，父组件就能用到 -->
      <slot :user="user" :index="user.id"></slot>
    </li>
  </ul>
</template>`,p=`<!-- 父组件：用 v-slot="作用域对象" 接住子组件传回来的数据 -->
<template>
  <UserList :users="users">
    <!-- slotProps 就是子组件在 <slot> 上绑的那些数据的集合 -->
    <template #default="slotProps">
      <strong>{{ slotProps.index }}.</strong>
      {{ slotProps.user.name }}
    </template>
  </UserList>

  <!-- 也可以直接解构，更常见： -->
  <UserList :users="users">
    <template #default="{ user, index }">
      <strong>{{ index }}.</strong> {{ user.name }}
    </template>
  </UserList>
</template>`,j=`<script setup>
import {
  onBeforeMount, onMounted,
  onBeforeUpdate, onUpdated,
  onBeforeUnmount, onUnmounted,
} from 'vue'

onBeforeMount(() => {
  // 组件即将挂载：模板还没真正渲染成 DOM
})

onMounted(() => {
  // 组件已挂载：DOM 已就绪，可安全访问元素、取数、初始化第三方库
  console.log('挂载完成')
})

onBeforeUpdate(() => {
  // 响应式数据变了、DOM 即将更新之前
})

onUpdated(() => {
  // DOM 已根据最新数据更新完成
})

onBeforeUnmount(() => {
  // 组件即将卸载：此时实例仍然可用，适合做收尾准备
})

onUnmounted(() => {
  // 组件已卸载：清理定时器 / 事件监听 / 第三方实例，避免内存泄漏
})
<\/script>`,u=`<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

const list = ref([])
let timer = null

onMounted(async () => {
  // 1. 进页面就取数据
  list.value = await fetch('/api/list').then((r) => r.json())
  // 2. 初始化一个轮询定时器
  timer = setInterval(refresh, 5000)
})

onUnmounted(() => {
  // 组件销毁时一定要清掉定时器，否则它会一直跑，造成泄漏
  clearInterval(timer)
})

async function refresh() {
  list.value = await fetch('/api/list').then((r) => r.json())
}
<\/script>`,m=`<!-- ====== 综合例子：带具名 + 作用域插槽的卡片组件 ====== -->

<!-- DataCard.vue（子组件） -->
<script setup>
import { onMounted, ref } from 'vue'

const props = defineProps({
  fetchUrl: { type: String, required: true },
})

const items = ref([])
const loading = ref(true)

onMounted(async () => {
  // 组件挂载后取数：典型的 onMounted 用途
  items.value = await fetch(props.fetchUrl).then((r) => r.json())
  loading.value = false
})
<\/script>

<template>
  <section class="data-card">
    <!-- 具名插槽 header：让父组件定制标题区 -->
    <header><slot name="header">列表</slot></header>

    <p v-if="loading">加载中…</p>

    <ul v-else>
      <li v-for="(item, i) in items" :key="item.id">
        <!-- 作用域插槽：把每一项数据 item / 序号 i 传回父组件 -->
        <slot name="row" :item="item" :index="i">
          {{ item.name }}   <!-- 父组件没定制时的兜底渲染 -->
        </slot>
      </li>
    </ul>

    <!-- 具名插槽 footer -->
    <footer><slot name="footer"></slot></footer>
  </section>
</template>


<!-- 父组件：填具名插槽，并用作用域插槽自定义每行的渲染 -->
<template>
  <DataCard fetch-url="/api/users">
    <template #header>
      <h2>用户列表</h2>
    </template>

    <!-- 接住子组件传回的 item 与 index，自己决定怎么画这一行 -->
    <template #row="{ item, index }">
      <span>{{ index + 1 }}</span>
      <b>{{ item.name }}</b>
      <em>{{ item.email }}</em>
    </template>

    <template #footer>
      <small>共 {{ items.length }} 人</small>
    </template>
  </DataCard>
</template>`,f=`<!-- keep-alive 缓存被包裹的组件，切走不销毁、切回不重建 -->
<template>
  <keep-alive>
    <component :is="currentTab" />
  </keep-alive>
</template>

<script setup>
import { onActivated, onDeactivated } from 'vue'

onActivated(() => {
  // 被 keep-alive 缓存的组件“重新显示”时触发（不是重新挂载）
})
onDeactivated(() => {
  // 被切走、进入缓存时触发（不是卸载）
})
<\/script>`;function S(){return e.jsxs("article",{children:[e.jsx(o,{children:"上一章解决了组件间“传数据”，这一章讲两件让组件真正灵活起来的事：插槽和生命周期。 插槽让父组件能往子组件里“填内容”，把布局与内容解耦，做出高度可复用的容器组件； 生命周期钩子则让你抓住组件“出生到死亡”的关键时机，在对的时刻取数、初始化、清理。 两者一个管“组合”，一个管“时机”，是写出好组件的基本功。"}),e.jsx("h2",{children:"一、插槽是什么：往子组件里“填内容”"}),e.jsxs(s,{children:["props 让父组件往子组件传",e.jsx("strong",{children:"数据"}),"，而插槽（slot）让父组件往子组件传",e.jsx("strong",{children:"一段模板内容"}),"。子组件在模板里用 ",e.jsx("code",{children:"<slot>"})," 占一个“坑”， 父组件在使用这个子组件时，把要填的 HTML / 组件写进它的标签内部，就会被填到那个坑的位置。"]}),e.jsxs("p",{children:["为什么需要插槽？因为有很多组件，结构是固定的、内容却千变万化——比如一个弹窗、一张卡片、 一个面板：边框、标题栏、底部按钮区的",e.jsx("strong",{children:"布局"}),"是组件该管的，但里面具体放什么",e.jsx("strong",{children:"内容"}),"应该由使用者决定。插槽就是把“内容的决定权”交还给父组件的机制。"]}),e.jsx("h2",{children:"二、默认插槽"}),e.jsxs("p",{children:["最简单的插槽：子组件写一个不带名字的 ",e.jsx("code",{children:"<slot>"}),"，父组件标签内部的内容就会被填进去。"]}),e.jsx(t,{lang:"vue",title:"子组件用 <slot> 占位",code:l}),e.jsx(t,{lang:"vue",title:"父组件填充默认插槽",code:i}),e.jsxs("p",{children:["插槽还能写",e.jsx("strong",{children:"默认内容（后备内容）"}),"：当父组件没有填任何东西时，就显示",e.jsx("code",{children:"<slot>"})," 标签里预置的内容；父组件一旦填了，默认内容就被覆盖。"]}),e.jsx(t,{lang:"vue",title:"带默认内容的插槽",code:c}),e.jsx("h2",{children:"三、具名插槽"}),e.jsxs("p",{children:["一个组件常常需要多个“坑”：比如卡片有头部、正文、底部三处都要父组件定制。这时用",e.jsx("strong",{children:"具名插槽"}),"：给 ",e.jsx("code",{children:"<slot>"})," 加上 ",e.jsx("code",{children:"name"}),"，父组件用",e.jsx("code",{children:"<template #名字>"}),"（即 ",e.jsx("code",{children:"v-slot:名字"})," 的简写）指明内容填到哪个坑。"]}),e.jsx(t,{lang:"vue",title:"子组件声明多个具名插槽",code:a}),e.jsx(t,{lang:"vue",title:"父组件用 #名字 指定填充位置",code:h}),e.jsxs(n,{variant:"info",title:"#name 与 v-slot:name",children:[e.jsx("code",{children:"#header"})," 是 ",e.jsx("code",{children:"v-slot:header"})," 的简写，两者等价。 没用 ",e.jsx("code",{children:"<template>"})," 包裹、或写 ",e.jsx("code",{children:"#default"})," 的内容，都进默认插槽。 具名插槽内容必须写在 ",e.jsx("code",{children:"<template>"})," 标签上，名字才有处安放。"]}),e.jsx("h2",{children:"四、作用域插槽：子组件把数据“传回”给父"}),e.jsxs("p",{children:["前面的插槽都是父组件单方面往里填内容。但有时父组件想填的内容",e.jsx("strong",{children:"依赖子组件内部的数据"}),"—— 比如子组件在 ",e.jsx("code",{children:"v-for"})," 一个列表，父组件想自定义“每一项”长什么样，可它根本拿不到子组件循环里的 那个 item。",e.jsx("strong",{children:"作用域插槽"}),"就是为此而生：子组件像传 props 一样，把数据绑在",e.jsx("code",{children:"<slot>"})," 上，父组件就能在插槽内容里用到这些数据。"]}),e.jsxs(s,{children:["作用域插槽是“双向”的：父组件提供",e.jsx("strong",{children:"模板"}),"，子组件提供",e.jsx("strong",{children:"数据"}),"。 子组件在 ",e.jsx("code",{children:'<slot :user="user">'})," 上绑数据，父组件用",e.jsx("code",{children:'<template #default="{ user }">'})," 接住——子把循环里的数据传回给父的插槽内容。"]}),e.jsx(t,{lang:"vue",title:"子组件在 <slot> 上绑数据",code:x}),e.jsx(t,{lang:"vue",title:"父组件用 v-slot 接住数据",code:p}),e.jsx("h2",{children:"五、插槽的典型用途"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"布局组件"}),"：像卡片、弹窗、页面骨架，用具名插槽划出 header / body / footer， 骨架由组件管，内容交给使用者。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"列表渲染定制"}),"：表格 / 列表组件负责取数、循环、分页逻辑，用作用域插槽把每行数据 传回父组件，让父组件自由决定每一行怎么渲染。这是组件库里最常见的高级用法。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"无渲染（renderless）组件"}),"：组件只管逻辑，把数据通过作用域插槽全交出去， 完全不关心 UI 长什么样。"]})]}),e.jsx("h2",{children:"六、生命周期：组件从创建到销毁"}),e.jsxs("p",{children:["一个组件从被创建、渲染成 DOM、随数据更新、到最终被移除，会经历若干阶段。Vue 在每个关键节点 都提供了一个",e.jsx("strong",{children:"生命周期钩子"}),"，让你在那个时刻插入自己的代码。在",e.jsx("code",{children:"<script setup>"})," 里，这些钩子是以 ",e.jsx("code",{children:"onXxx"})," 函数的形式从 ",e.jsx("code",{children:"vue"})," 导入并调用的。"]}),e.jsx(t,{lang:"vue",title:"六个常用生命周期钩子",code:j}),e.jsx("h3",{children:"执行时机与典型用途"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"钩子"}),e.jsx("th",{children:"触发时机"}),e.jsx("th",{children:"典型用途"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"onBeforeMount"})}),e.jsx("td",{children:"挂载前，DOM 尚未生成"}),e.jsx("td",{children:"很少用，挂载前最后准备"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"onMounted"})}),e.jsx("td",{children:"挂载后，DOM 已就绪"}),e.jsx("td",{children:"取数、访问 DOM、初始化第三方库"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"onBeforeUpdate"})}),e.jsx("td",{children:"数据变、DOM 更新前"}),e.jsx("td",{children:"读取更新前的旧 DOM 状态"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"onUpdated"})}),e.jsx("td",{children:"DOM 已按新数据更新后"}),e.jsx("td",{children:"依赖最新 DOM 的操作（慎用，易死循环）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"onBeforeUnmount"})}),e.jsx("td",{children:"卸载前，实例仍可用"}),e.jsx("td",{children:"收尾准备、保存状态"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"onUnmounted"})}),e.jsx("td",{children:"卸载后"}),e.jsx("td",{children:"清理定时器 / 事件监听 / 第三方实例"})]})]})]}),e.jsxs("p",{children:["最常打交道的是",e.jsx("strong",{children:"一头一尾"}),"这对：",e.jsx("code",{children:"onMounted"})," 里发请求取数据、 操作刚渲染好的 DOM、初始化图表 / 地图等第三方库；",e.jsx("code",{children:"onUnmounted"})," 里把",e.jsx("code",{children:"onMounted"})," 建立的东西",e.jsx("strong",{children:"对称地清掉"}),"——清定时器、移除事件监听、 销毁第三方实例，否则组件没了，这些东西还在后台跑，就是内存泄漏。"]}),e.jsx(t,{lang:"vue",title:"onMounted 取数 + onUnmounted 清理",code:u}),e.jsxs(n,{variant:"info",title:"和 React useEffect 的一句话类比",children:["如果你熟悉 React：",e.jsx("code",{children:"onMounted"})," 约等于 ",e.jsx("code",{children:"useEffect(fn, [])"})," 的首次执行，",e.jsx("code",{children:"onUnmounted"})," 约等于 ",e.jsx("code",{children:"useEffect"})," 返回的那个清理函数——“建立”和“清理”成对出现。"]}),e.jsx("h2",{children:"七、keep-alive 与 onActivated / onDeactivated"}),e.jsxs("p",{children:["当组件被 ",e.jsx("code",{children:"<keep-alive>"})," 包裹时，它切走不会被销毁、切回也不会重建，而是被缓存起来； 此时它不会触发 ",e.jsx("code",{children:"onUnmounted"})," / ",e.jsx("code",{children:"onMounted"}),"，而是触发",e.jsxs("strong",{children:[e.jsx("code",{children:"onActivated"}),"（缓存组件重新显示时）和 ",e.jsx("code",{children:"onDeactivated"}),"（被切走进缓存时）"]}),"。"]}),e.jsx(t,{lang:"vue",title:"keep-alive 缓存组件的专属钩子",code:f}),e.jsx("h2",{children:"八、综合例子：带具名 + 作用域插槽的卡片组件"}),e.jsxs("p",{children:["把这一章的东西凑成一个真实组件：",e.jsx("code",{children:"DataCard"})," 在 ",e.jsx("code",{children:"onMounted"})," 里取数， 提供 ",e.jsx("code",{children:"header"})," / ",e.jsx("code",{children:"footer"})," 两个具名插槽让父组件定制头尾， 再用一个名为 ",e.jsx("code",{children:"row"})," 的",e.jsx("strong",{children:"作用域插槽"}),"把每一项数据 ",e.jsx("code",{children:"item"})," 和序号",e.jsx("code",{children:"index"})," 传回父组件，让父组件自由渲染每一行。"]}),e.jsx(t,{lang:"vue",title:"DataCard：具名插槽 + 作用域插槽 + onMounted 取数",code:m}),e.jsxs(r,{title:"拆解这个组件的协作",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"子组件 DataCard 负责"}),"：挂载时取数据（onMounted）、显示加载态、循环渲染、 划出 header / row / footer 三个插槽口子。这些是“通用容器”该管的事。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"父组件负责"}),"：用 ",e.jsx("code",{children:"#header"})," 填标题、用",e.jsx("code",{children:'#row="{ item, index }"'})," 接住每行数据并决定它长什么样、用 ",e.jsx("code",{children:"#footer"}),"填底部。同一个 DataCard，换不同父组件就能渲染用户列表、订单列表、商品列表—— 这就是插槽带来的复用力。"]})]}),e.jsx("h2",{children:"九、边界与易错点"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"作用域插槽的数据只在插槽内可用"}),"：子组件通过 ",e.jsx("code",{children:'<slot :x="x">'}),"传回的数据，只能在父组件对应的 ",e.jsx("code",{children:"<template #...>"})," 里访问，出了这个范围就没有。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"onMounted 才能安全访问 DOM"}),"：在 setup 顶层或 onBeforeMount 里访问模板里的元素 会拿到 null，因为那时 DOM 还没生成。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"onUpdated 里别改响应式数据"}),"：改了会再次触发更新，可能陷入死循环； 要响应数据变化通常该用 ",e.jsx("code",{children:"watch"})," 而非 onUpdated。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"清理要对称"}),"：onMounted 里 ",e.jsx("code",{children:"addEventListener"})," / ",e.jsx("code",{children:"setInterval"})," / 建第三方实例，就要在 onUnmounted 里成对地移除 / 清除 / 销毁。"]})]}),e.jsx(n,{variant:"tip",children:"到这里，组件化这一卷的核心就齐了：通信（props / emit / provide-inject）解决“组件间怎么传”， 插槽解决“怎么往里填内容”，生命周期解决“在什么时机做事”。把这三块捏合好， 你就能写出既灵活复用、又行为可控的组件。"}),e.jsx(d,{points:["插槽让父组件往子组件“填内容”：子用 <slot> 占坑，父在标签内部写内容填进去，可设默认（后备）内容。","具名插槽用 name 区分多个坑，父组件用 <template #名字>（即 v-slot:名字 简写）指定填充位置。",'作用域插槽让子组件把内部数据（如循环里的 item）通过 <slot :x="x"> 传回父组件，父用 v-slot="{ x }" 接住，常用于列表渲染定制。',"插槽典型用途：布局组件（header/body/footer）、列表渲染定制、无渲染组件。","生命周期六钩子：onBeforeMount/onMounted、onBeforeUpdate/onUpdated、onBeforeUnmount/onUnmounted，对应挂载、更新、卸载三阶段的前后。","onMounted 取数 / 访问 DOM / 初始化第三方库；onUnmounted 对称清理定时器、事件监听、第三方实例，防内存泄漏。","onMounted≈React useEffect(fn,[]) 首次执行，onUnmounted≈其清理函数；keep-alive 缓存组件用 onActivated（显示）/ onDeactivated（切走）而非挂载卸载。"]})]})}export{S as default};
