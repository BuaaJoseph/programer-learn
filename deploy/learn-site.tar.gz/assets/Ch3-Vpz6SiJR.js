import{r as a,j as e}from"./index-B0-Um9Xw.js";import{L as h,a as x,P as d,C as c,S as j}from"./Summary-CRXglwZ1.js";import{K as f}from"./KeyIdea-zCCzkW7I.js";import{E as p}from"./Example-Djk5fvs9.js";import{F as g}from"./Figure-DKg6w6XJ.js";const o={simple:{label:"简单工厂",desc:"一个工厂类用 if/switch 按参数 new 出不同产品。调用方不再自己 new；但新增产品要改工厂(违反开闭原则)。",not:"不属于 GoF 23 种"},method:{label:"工厂方法",desc:"定义创建产品的接口，每种产品对应一个具体工厂子类。新增产品只需加一个工厂子类(符合开闭)。",not:"一个工厂造一类产品"},abstract:{label:"抽象工厂",desc:"一个工厂创建「一族」相关产品(如同一风格的按钮+文本框)。适合产品成套出现的场景。",not:"一个工厂造一族产品"}};function y(){const[i,s]=a.useState("method"),r=o[i],l=e.jsx(e.Fragment,{children:Object.entries(o).map(([n,t])=>e.jsx("button",{className:`fig-btn ${i===n?"active":""}`,onClick:()=>s(n),children:t.label},n))});return e.jsx(g,{caption:"工厂模式把对象创建集中起来、面向接口编程，让调用方与具体实现解耦。三兄弟解决不同程度的解耦：简单工厂(一个工厂全包)、工厂方法(一厂一品)、抽象工厂(一厂一族)。",controls:l,children:e.jsxs("svg",{viewBox:"0 0 460 180",width:"460",role:"img","aria-label":"工厂模式",children:[e.jsx("rect",{x:"40",y:"40",width:"90",height:"40",rx:"9",fill:"var(--accent)"}),e.jsx("text",{x:"85",y:"64",textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"12",fontWeight:"700",fill:"#ffffff",children:"调用方"}),e.jsx("rect",{x:"180",y:"36",width:"100",height:"48",rx:"9",fill:"var(--violet)",fillOpacity:"0.14",stroke:"var(--violet)"}),e.jsx("text",{x:"230",y:"56",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"11",fontWeight:"700",fill:"var(--violet)",children:"工厂"}),e.jsx("text",{x:"230",y:"72",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:"var(--ink-soft)",children:r.not}),e.jsx("line",{x1:"130",y1:"60",x2:"180",y2:"60",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#fa-a)"}),["产品A","产品B","产品C"].map((n,t)=>e.jsxs("g",{children:[e.jsx("rect",{x:"330",y:20+t*44,width:"100",height:"34",rx:"7",fill:"var(--green-soft)",stroke:"var(--green-line)"}),e.jsx("text",{x:"380",y:41+t*44,textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"11",fill:"var(--green)",children:n}),e.jsx("line",{x1:"280",y1:"60",x2:"330",y2:37+t*44,stroke:"var(--ink-faint)",strokeWidth:"1.2",markerEnd:"url(#fa-a)"})]},n)),e.jsx("defs",{children:e.jsx("marker",{id:"fa-a",markerWidth:"8",markerHeight:"8",refX:"5",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L5,3 L0,6 Z",fill:"var(--ink-faint)"})})}),e.jsx("rect",{x:"20",y:"146",width:"420",height:"0",fill:"none"}),e.jsx("foreignObject",{x:"20",y:"120",width:"300",height:"56",children:e.jsxs("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"11px var(--sans)",color:"var(--ink)",lineHeight:1.35},children:[e.jsxs("strong",{style:{color:"var(--accent-strong)"},children:[r.label,"："]}),r.desc]})})]})})}const u=`// 简单工厂：一个工厂用 if/switch 决定造哪个产品
public class DbConnectionFactory {

    public static Connection create(String type) {
        // 每加一种数据库就得回来改这里，违反开闭原则
        if ("mysql".equals(type)) {
            return new MySQLConnection();
        } else if ("oracle".equals(type)) {
            return new OracleConnection();
        }
        throw new IllegalArgumentException("不支持的类型: " + type);
    }
}`,m=`// 工厂方法：一个产品对应一个工厂，新增产品只加类不改老代码

// 1. 抽象产品
public interface Connection {
    void connect();
}

// 2. 具体产品
public class MySQLConnection implements Connection {
    public void connect() {
        System.out.println("连接 MySQL");
    }
}

public class OracleConnection implements Connection {
    public void connect() {
        System.out.println("连接 Oracle");
    }
}

// 3. 抽象工厂
public interface ConnectionFactory {
    Connection create();
}

// 4. 具体工厂：每个产品一个工厂
public class MySQLFactory implements ConnectionFactory {
    public Connection create() {
        return new MySQLConnection();
    }
}

public class OracleFactory implements ConnectionFactory {
    public Connection create() {
        return new OracleConnection();
    }
}

// 使用：要换数据库，只换注入的工厂，业务代码不变
// ConnectionFactory factory = new MySQLFactory();
// Connection conn = factory.create();
// conn.connect();`,C=`// 抽象工厂：创建「一族」相关产品（同一风格的一整套 UI 组件）

public interface Button { void render(); }
public interface CheckBox { void render(); }

// 一个工厂负责造出一整套同风格的产品
public interface UIFactory {
    Button createButton();
    CheckBox createCheckBox();
}

public class DarkFactory implements UIFactory {
    public Button createButton() { return new DarkButton(); }
    public CheckBox createCheckBox() { return new DarkCheckBox(); }
}

public class LightFactory implements UIFactory {
    public Button createButton() { return new LightButton(); }
    public CheckBox createCheckBox() { return new LightCheckBox(); }
}`;function B(){return e.jsxs(e.Fragment,{children:[e.jsx(h,{children:e.jsxs("p",{children:["工厂模式要解决的痛点是：",e.jsx("strong",{children:"对象的创建过程是易变的"}),"。 如果到处直接 ",e.jsx("code",{children:"new"}),"，一旦要换实现、加类型，就得满项目改 new。 工厂模式把「创建对象」这件事单独隔离出来，让调用方只管「要什么」，不管「怎么造」。 它有三个层次：简单工厂、工厂方法、抽象工厂。"]})}),e.jsx("h2",{children:"三个层次，逐层进化"}),e.jsxs("p",{children:["三者是从「能用」到「优雅」再到「成套」的递进。理解它们的关键，是看每一步是如何",e.jsx("strong",{children:"更好地满足开闭原则"}),"的。"]}),e.jsx("h3",{children:"简单工厂：一个工厂搞定一切（非 GoF）"}),e.jsxs("p",{children:["用一个工厂类，靠 ",e.jsx("code",{children:"if / switch"})," 判断参数来决定 new 哪个产品。 它把 new 集中到一处，调用方确实清爽了。但它",e.jsx("strong",{children:"违反开闭原则"}),"： 每加一种产品，都得回来改这个工厂的判断分支。注意，简单工厂",e.jsx("strong",{children:"不属于 GoF 的 23 种模式"}),"， 它只是一种朴素的编程习惯，但因为常用所以单独拿出来讲。"]}),e.jsx("h3",{children:"工厂方法：一个产品一个工厂"}),e.jsxs("p",{children:["把工厂也抽象成接口，每种产品配一个具体工厂。要加新产品，就",e.jsx("strong",{children:"新建一个产品类 + 一个工厂类"}),"， 老代码完全不动——",e.jsx("strong",{children:"完美符合开闭原则"}),"。代价是类的数量变多了。 这是真正意义上的 GoF 工厂方法模式。"]}),e.jsx("h3",{children:"抽象工厂：创建一族产品"}),e.jsxs("p",{children:["当产品不是单个，而是",e.jsx("strong",{children:"一整套互相搭配"}),"的时候用它。比如 UI 主题： 深色主题的按钮要配深色的复选框，不能混搭。抽象工厂让一个工厂负责造出",e.jsx("strong",{children:"同一族的一整套产品"}),"，保证它们风格一致。换主题就换整个工厂。"]}),e.jsx(p,{title:"用「换数据库 / 换 UI 风格」记住区别",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"简单工厂"})," · 一个 DbFactory 用 switch 决定造 MySQL 还是 Oracle 连接，加类型要改它。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"工厂方法"})," · MySQLFactory、OracleFactory 各管一个产品，加 PostgreSQL 只新建工厂。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"抽象工厂"})," · DarkFactory 一次造出深色按钮 + 深色复选框一整套，换风格换工厂即可。"]})]})}),e.jsx(y,{}),e.jsx(f,{title:"工厂的本质是隔离「易变的创建」",children:e.jsxs("p",{children:["为什么要绕这么大圈子？因为",e.jsx("strong",{children:"new 一个具体类，意味着代码写死了依赖"}),"， 违反依赖倒置原则。工厂模式把「决定造谁」这件最易变的事，从业务逻辑里抽离出来， 让业务只依赖产品接口和工厂接口。一句话：",e.jsx("strong",{children:"工厂模式 = 把创建逻辑抽象化，以满足开闭与依赖倒置"}),"。"]})}),e.jsx(x,{variant:"warn",title:"不要一上来就抽象工厂",children:e.jsxs("p",{children:["层次越高，类越多、越复杂。如果产品只有一两种、几乎不变，直接 new 或简单工厂就够了， 强上工厂方法、抽象工厂就是",e.jsx("strong",{children:"过度设计"}),"。 只有当「产品类型会增长」或「产品需要成套搭配」时，更高层次才划算。"]})}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["工厂模式在框架里随处可见：",e.jsx("strong",{children:"Spring 的 BeanFactory"})," 就是巨型工厂，负责创建和管理所有 Bean；",e.jsx("code",{children:"Calendar.getInstance()"})," 根据地区返回不同的 Calendar 实现，是典型的工厂思想； 日志框架（如 SLF4J 的 ",e.jsx("code",{children:"LoggerFactory.getLogger()"}),"）也用工厂屏蔽底层实现差异。 面试要点：说清三者区别，强调",e.jsx("strong",{children:"简单工厂违反开闭且非 GoF"}),"、",e.jsx("strong",{children:"工厂方法符合开闭"}),"、",e.jsx("strong",{children:"抽象工厂解决产品族"}),"。"]}),e.jsxs(d,{title:"手写工厂方法模式",children:[e.jsx("p",{children:"以「创建不同数据库连接」为例，先看简单工厂的写法及其问题，再看如何用工厂方法重构成 「加新数据库只新增类」。最后给出抽象工厂的骨架，体会「产品族」的概念。"}),e.jsx(c,{lang:"java",title:"简单工厂（违反开闭、非 GoF）",code:u}),e.jsx(c,{lang:"java",title:"工厂方法（接口 + 具体工厂）",code:m}),e.jsx(c,{lang:"java",title:"抽象工厂（创建一族 UI 产品）",code:C})]}),e.jsx(j,{points:["工厂模式隔离「易变的对象创建」，让调用方只关心要什么、不关心怎么造，满足开闭与依赖倒置。","简单工厂用一个 if/switch 工厂集中创建，方便但违反开闭，且不属于 GoF 23 种模式。","工厂方法为每个产品配一个工厂，新增产品只加类不改老代码，完美符合开闭原则。","抽象工厂用于创建一整族互相搭配的产品（如同一风格的 UI 组件），换族就换工厂。","层次越高类越多越复杂，产品稳定时强上抽象工厂属于过度设计。","实际应用：Spring BeanFactory、Calendar.getInstance、日志框架的 LoggerFactory 都是工厂思想。"]})]})}export{B as default};
