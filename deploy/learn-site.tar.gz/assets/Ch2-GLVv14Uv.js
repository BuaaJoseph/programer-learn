import{j as e}from"./index-CNCQ9D3g.js";import{L as d,S as c}from"./Summary-B81QYNtK.js";import{K as s}from"./KeyIdea-CJu1AmJK.js";import{C as i}from"./Callout-DBjCLF-u.js";import{C as n}from"./CodeBlock-B4ANG3D_.js";import{E as r}from"./Example-C7EXHAW5.js";const t=`import SwiftUI

// @main 标记整个 App 的入口，有且只有一个
@main
struct HelloWorldApp: App {
    // body 返回的是 Scene，不是 View
    var body: some Scene {
        // WindowGroup 是最常用的场景：管理一组可展示内容的窗口
        WindowGroup {
            ContentView()   // 窗口里放置的根视图
        }
    }
}`,o=`import SwiftUI

struct ContentView: View {
    // @State 让视图持有可变状态，状态一变界面自动刷新
    @State private var count = 0

    // body 描述「这个视图长什么样」，类型是 some View
    var body: some View {
        VStack(spacing: 16) {
            Text("你好，SwiftUI")
                .font(.largeTitle)
                .bold()

            Text("你已经点击了 \\(count) 次")
                .foregroundStyle(.secondary)

            Button("点我 +1") {
                count += 1          // 改状态，无需手动刷新界面
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}`,l=`import SwiftUI

struct ContentView: View {
    @State private var count = 0
    var body: some View {
        VStack(spacing: 16) {
            Text("你好，SwiftUI").font(.largeTitle).bold()
            Text("你已经点击了 \\(count) 次")
            Button("点我 +1") { count += 1 }
                .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}

// #Preview 宏：让 Xcode 右侧画布实时渲染这个视图
#Preview {
    ContentView()
}`,h=`// Package.swift 里声明依赖（库作者视角）
// dependencies: [
//     .package(url: "https://github.com/Alamofire/Alamofire.git", from: "5.9.0")
// ]

// 在 App 工程里更常用图形界面添加：
// File > Add Package Dependencies… > 粘贴仓库 URL > 选版本规则
// 添加后，直接 import 即可使用
import Alamofire

AF.request("https://api.example.com/data").responseDecodable(of: Item.self) { resp in
    print(resp.value as Any)
}`;function m(){return e.jsxs("article",{children:[e.jsxs(d,{children:["上一章我们俯瞰了整个苹果生态，这一章正式动手。我们会拆开 Xcode 工程的骨架——它由哪些文件和概念组成、 各管什么；学会用 Swift Package Manager 引入第三方库；然后从 ",e.jsx("code",{children:"@main"})," 入口一路写到第一个 SwiftUI 视图，用 Xcode 的实时预览看着它成型，最后送进模拟器跑起来。读完你将拥有一个能交互的、 真正可运行的 App，并理解「代码如何变成屏幕上的画面」这条链路。"]}),e.jsx("h2",{children:"一、Xcode 是什么"}),e.jsxs("p",{children:[e.jsx("strong",{children:"Xcode"})," 是苹果官方的集成开发环境（IDE），写代码、设计界面、管理资源、编译、调试、 跑模拟器、上传 App Store，全在这一个工具里完成。它只能在 macOS 上运行，是 iOS 开发的必备工具， 可在 Mac App Store 免费下载。"]}),e.jsxs(i,{variant:"tip",title:"创建工程的起手式",children:["打开 Xcode，选 ",e.jsx("code",{children:"File > New > Project"}),"，平台选 iOS、模板选 App， Interface 选 ",e.jsx("strong",{children:"SwiftUI"}),"、Language 选 ",e.jsx("strong",{children:"Swift"}),"。 填好产品名，Xcode 就会替你生成一个能直接运行的最小工程。"]}),e.jsx("h2",{children:"二、工程结构：那些文件都是干嘛的"}),e.jsx("p",{children:"新建工程后，左侧导航器里会出现一堆文件和概念。它们各司其职，理解了你才不会「不敢乱动」。"}),e.jsx("h3",{children:".xcodeproj：工程文件"}),e.jsxs("p",{children:["以 ",e.jsx("code",{children:".xcodeproj"})," 结尾的就是工程本体——它记录了有哪些源文件、编译设置、依赖、目标等全部信息。 你平时双击它来打开整个项目。注意它其实是个「包」，里面藏着配置，一般不要手动改内部文件。"]}),e.jsx("h3",{children:"Target（目标）"}),e.jsxs("p",{children:["一个 ",e.jsx("strong",{children:"Target"})," 描述「要构建出的一个产物」——比如你的主 App、一个测试包、一个 Widget 扩展。 它定义了用哪些源文件、什么编译选项、最低支持的系统版本等。一个工程可以有多个 Target。"]}),e.jsx("h3",{children:"Info.plist：App 的配置清单"}),e.jsxs("p",{children:[e.jsx("code",{children:"Info.plist"})," 是一份属性列表，记录 App 的元信息：显示名、版本号、支持的方向、 以及上一章提到的",e.jsx("strong",{children:"各项隐私权限的用途说明"}),"。新版 Xcode 把许多配置搬进了 Target 的 Info 标签页，但概念不变——它就是 App 的「身份证 + 声明表」。"]}),e.jsx("h3",{children:"Assets.xcassets：资源目录"}),e.jsxs("p",{children:["图片、App 图标、颜色、启动画面等资源放在 ",e.jsx("code",{children:"Assets"})," 资源目录里。它帮你管理不同分辨率 （@2x / @3x）和明暗模式的变体，代码里用名字就能取用，无需关心具体文件。"]}),e.jsx("h3",{children:"Scheme：构建与运行方案"}),e.jsxs("p",{children:[e.jsx("strong",{children:"Scheme"})," 定义「点运行按钮时到底干什么」——构建哪个 Target、用 Debug 还是 Release 配置、 跑在哪个设备 / 模拟器上。顶部工具栏选的就是它。调试和发布常用不同 Scheme / 配置。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"概念"}),e.jsx("th",{children:"是什么"}),e.jsx("th",{children:"你常做的事"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:".xcodeproj"}),e.jsx("td",{children:"工程本体，记录全部设置"}),e.jsx("td",{children:"双击打开项目"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Target"}),e.jsx("td",{children:"一个要构建的产物"}),e.jsx("td",{children:"设最低系统版本、签名"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Info.plist"}),e.jsx("td",{children:"App 元信息与权限说明"}),e.jsx("td",{children:"填权限用途、版本号"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Assets.xcassets"}),e.jsx("td",{children:"图片 / 图标 / 颜色资源"}),e.jsx("td",{children:"拖入图片、配 App 图标"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Scheme"}),e.jsx("td",{children:"构建 + 运行方案"}),e.jsx("td",{children:"选目标设备、Debug/Release"})]})]})]}),e.jsx("h2",{children:"三、用 Swift Package Manager 管理依赖"}),e.jsxs("p",{children:["几乎没有 App 是从零造所有轮子的，你会想引入网络、图片加载、JSON 解析等第三方库。苹果官方的依赖管理工具是",e.jsx("strong",{children:"Swift Package Manager（SPM）"}),"，已内置在 Xcode 里，无需额外安装。"]}),e.jsxs("p",{children:["在 App 工程里添加依赖最直接的方式是图形界面：菜单 ",e.jsx("code",{children:"File > Add Package Dependencies…"}),"， 粘贴库的 Git 仓库地址，选好版本规则（比如「5.9.0 及以上的兼容版本」），Xcode 自动下载并接进工程。 之后直接 ",e.jsx("code",{children:"import"})," 就能用。"]}),e.jsx(n,{lang:"swift",title:"用 SPM 引入并使用依赖",code:h}),e.jsx(i,{variant:"note",title:"版本规则别选太松",children:"SPM 用语义化版本控制依赖范围。生产项目里建议锁定到「兼容的次要版本」而非「任意最新」， 避免某天库作者发了破坏性更新，你的工程突然编译不过。"}),e.jsx("h2",{children:"四、App 入口：@main、App 与 Scene"}),e.jsxs("p",{children:["SwiftUI App 的启动入口是一个标了 ",e.jsx("code",{children:"@main"})," 的结构体，它遵循 ",e.jsx("code",{children:"App"})," 协议。 整个程序",e.jsx("strong",{children:"有且只有一个"})," ",e.jsx("code",{children:"@main"}),"，它告诉系统「从这里开始」。"]}),e.jsxs(s,{children:["入口结构体的 ",e.jsx("code",{children:"body"})," 返回的是 ",e.jsx("strong",{children:"Scene"}),"（场景），不是 View。 最常用的场景是 ",e.jsx("code",{children:"WindowGroup"}),"——它管理一组承载内容的窗口，里面再放你的根视图。 记住这条层级：",e.jsx("strong",{children:"App → Scene（WindowGroup）→ View（ContentView）"}),"。"]}),e.jsx(n,{lang:"swift",title:"@main App 入口",code:t}),e.jsxs("p",{children:["为什么要分 Scene 和 View 两层？因为同一个 App 在 iPad 上可以开多个窗口、在 Mac 上有菜单栏， Scene 这一层正是用来描述「窗口 / 场景级别」的结构，而 View 描述窗口内部的具体界面。 在 iPhone 上你通常只用一个 ",e.jsx("code",{children:"WindowGroup"}),"，但这层抽象为跨平台留好了余地。"]}),e.jsx("h2",{children:"五、写第一个 SwiftUI 视图"}),e.jsxs("p",{children:["视图是 SwiftUI 的基本积木。一个视图就是一个遵循 ",e.jsx("code",{children:"View"})," 协议的结构体， 它必须提供一个 ",e.jsx("code",{children:"body"})," 属性来描述自己长什么样。",e.jsx("code",{children:"body"})," 的返回类型写作",e.jsx("code",{children:"some View"}),"——意思是「某种具体的 View 类型，由编译器推断」。"]}),e.jsxs("p",{children:["下面这个 ",e.jsx("code",{children:"ContentView"})," 用 ",e.jsx("code",{children:"VStack"}),"（纵向堆叠）排了两个 ",e.jsx("code",{children:"Text"})," 和一个",e.jsx("code",{children:"Button"}),"，并用 ",e.jsx("code",{children:"@State"})," 持有一个计数："]}),e.jsx(n,{lang:"swift",title:"ContentView：第一个可交互视图",code:o}),e.jsxs(r,{title:"为什么点按钮界面就变了",children:[e.jsxs("p",{children:["关键在 ",e.jsx("code",{children:"@State private var count"})," 和 ",e.jsx("code",{children:'Button("点我 +1") { count += 1 }'}),"。 按钮闭包里只是简单地 ",e.jsx("code",{children:"count += 1"}),"，并没有任何「去更新那行文字」的代码。"]}),e.jsxs("p",{children:["这正是",e.jsx("strong",{children:"声明式"}),"的魔法：SwiftUI 发现被 ",e.jsx("code",{children:"@State"})," 标记的 ",e.jsx("code",{children:"count"})," 变了， 就自动重新求值整个 ",e.jsx("code",{children:"body"}),"，",e.jsx("code",{children:'Text("你已经点击了 \\(count) 次")'})," 随之刷新。 你只管改数据，界面同步交给框架。"]})]}),e.jsxs(i,{variant:"warn",title:"body 不能有副作用",children:[e.jsx("code",{children:"body"})," 可能被框架频繁、反复地求值，它应当是「根据当前状态描述界面」的纯函数。 别在 ",e.jsx("code",{children:"body"})," 里发网络请求、改全局状态或做其它副作用，那会导致难以预料的行为。"]}),e.jsx("h2",{children:"六、Xcode Preview：边写边看"}),e.jsxs("p",{children:["SwiftUI 最爽的体验是",e.jsx("strong",{children:"实时预览"}),"。用 ",e.jsx("code",{children:"#Preview"})," 宏包住一个视图， Xcode 右侧的画布就会实时渲染它——你改一行代码，预览几乎立刻更新，无需每次都编译进模拟器， 极大加快了调界面的节奏。"]}),e.jsx(n,{lang:"swift",title:"用 #Preview 开启实时预览",code:l}),e.jsx("p",{children:"预览不只是静态截图：你可以在画布里直接点按钮、滚动列表、切换明暗模式与设备尺寸， 像用真 App 一样交互。它本质上是把这个视图单独跑了起来，因此能反映真实的状态变化。"}),e.jsx(i,{variant:"tip",title:"预览卡住了怎么办",children:"预览偶尔会因为代码改动而暂停或报错，点画布上的刷新 / 恢复按钮重新构建即可。 预览出问题不代表 App 跑不起来，二者是独立的两条路径。"}),e.jsx("h2",{children:"七、从代码到屏幕：完整链路"}),e.jsx("p",{children:"把这一章串起来，看一个 App 从你按下运行键到画面亮起，中间发生了什么："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"1. 选 Scheme 与设备"}),"：在工具栏选好目标（某个模拟器或真机）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"2. 编译"}),"：Xcode 用 Swift 编译器把你的源码编译成机器码，链接依赖与资源，打包成 App。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"3. 安装与启动"}),"：把 App 装到模拟器 / 真机，系统找到 ",e.jsx("code",{children:"@main"})," 入口启动它。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"4. 构建场景"}),"：入口的 ",e.jsx("code",{children:"WindowGroup"})," 创建窗口，实例化根视图 ",e.jsx("code",{children:"ContentView"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"5. 渲染上屏"}),"：SwiftUI 求值 ",e.jsx("code",{children:"body"}),"，交给底层（核心服务 / 内核）调度 GPU，把像素画到屏幕。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"6. 交互循环"}),"：你点按钮 → 改 ",e.jsx("code",{children:"@State"})," → SwiftUI 重新求值 body → 界面刷新，如此往复。"]})]}),e.jsx("p",{children:"模拟器是 Mac 上的一个 iOS 虚拟设备，适合日常开发调试；要体验真实性能、传感器、相机等， 还得连真机运行（这需要上一章提到的开发者账号来签名）。"}),e.jsx("h2",{children:"八、小结"}),e.jsxs("p",{children:["你已经认识了 Xcode 工程的每个零件、学会了用 SPM 引依赖、从 ",e.jsx("code",{children:"@main"})," 入口写到第一个 交互式 SwiftUI 视图、并理解了预览与运行链路。这是后续一切的地基。下一卷起，我们将深入 Swift 语言本身， 把视图里那些 ",e.jsx("code",{children:"@State"}),"、闭包、类型推断讲透。"]}),e.jsx(c,{points:["Xcode 是苹果官方 IDE（仅限 macOS）：写码、设计、编译、调试、跑模拟器、上架一站式完成。","工程骨架：.xcodeproj（工程本体）、Target（构建产物）、Info.plist（元信息与权限说明）、Assets（资源）、Scheme（构建运行方案）。","Swift Package Manager 已内置 Xcode，用 File > Add Package Dependencies 粘贴仓库 URL 即可引依赖，版本规则别选太松。","App 入口是唯一的 @main 结构体，body 返回 Scene（常用 WindowGroup）；层级是 App → Scene → View。","视图是遵循 View 协议的结构体，必须有 body（类型 some View）；@State 持有可变状态，状态一变界面自动刷新，body 不能有副作用。","#Preview 宏开启 Xcode 实时可交互预览；运行链路为 选设备 → 编译 → 安装启动 → 构建场景 → 渲染上屏 → 交互循环。"]})]})}export{m as default};
