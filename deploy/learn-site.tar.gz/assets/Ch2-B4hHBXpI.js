import{j as e}from"./index-CVHWXZpb.js";import{L as s,S as r}from"./Summary-CJTCDEeZ.js";import{K as n}from"./KeyIdea-XVLVSS4B.js";import{C as t}from"./Callout-DCq22jZW.js";import{C as i}from"./CodeBlock-ljkh5ShG.js";import{E as d}from"./Example-BSuN_UvG.js";const c=`import SwiftUI

struct RootView: View {
    var body: some View {
        NavigationStack {                    // 取代旧的 NavigationView
            List {
                NavigationLink("设置", value: "settings")
                NavigationLink("关于", value: "about")
            }
            .navigationTitle("首页")
            .navigationDestination(for: String.self) { key in
                // 根据被点击的 value 决定跳转到哪个页面
                DetailView(name: key)
            }
        }
    }
}`,o=`struct AppNavigator: View {
    @State private var path: [Route] = []     // 用数组持有整条导航栈

    var body: some View {
        NavigationStack(path: $path) {          // 把 path 绑定给栈
            HomeView()
                .navigationDestination(for: Route.self) { route in
                    switch route {
                    case .profile(let id): ProfileView(userID: id)
                    case .settings:        SettingsView()
                    }
                }
        }
    }
}

enum Route: Hashable {                          // 路由必须可哈希
    case profile(id: Int)
    case settings
}`,l=`Button("打开我的资料") {
    path.append(.profile(id: 42))      // 编程式跳转：往栈里压一个路由
}

Button("回到首页") {
    path.removeAll()                   // 一键弹回根视图
}

Button("返回上一页") {
    path.removeLast()                  // 弹出栈顶
}

// 深链：从一个 URL 解析出多级路由，一次性还原整条栈
func openDeepLink() {
    path = [.settings, .profile(id: 7)]   // 直接定位到 设置 → 资料(7)
}`,a=`import Observation

@Observable                          // 新的 Observation 宏，标注模型类
final class CartModel {
    var items: [String] = []         // 普通存储属性即可，无需 @Published
    var couponApplied = false

    var count: Int { items.count }   // 计算属性也会被自动追踪

    func add(_ item: String) {
        items.append(item)
    }
}`,h=`struct ShopApp: View {
    @State private var cart = CartModel()    // 用 @State 持有 @Observable 模型

    var body: some View {
        NavigationStack {
            ProductList()
                .environment(cart)            // 通过 environment 注入，跨层共享
        }
    }
}

struct ProductList: View {
    @Environment(CartModel.self) private var cart   // 从环境读取共享模型

    var body: some View {
        VStack {
            Text("购物车：\\(cart.count) 件")          // 自动随 count 变化刷新
            Button("加入牛奶") { cart.add("牛奶") }
        }
    }
}`,j=`struct CouponEditor: View {
    @Bindable var cart: CartModel        // 子视图需要双向绑定 @Observable 的属性时

    var body: some View {
        Toggle("使用优惠券", isOn: $cart.couponApplied)   // $ 取得绑定
    }
}`,x=`struct LibraryView: View {
    @State private var showAdd = false
    @State private var showOnboarding = false

    var body: some View {
        VStack {
            Button("添加") { showAdd = true }
            Button("引导") { showOnboarding = true }
        }
        .sheet(isPresented: $showAdd) {              // 半屏卡片，可下滑关闭
            AddItemView()
        }
        .fullScreenCover(isPresented: $showOnboarding) {  // 全屏覆盖，需手动关
            OnboardingView()
        }
    }
}`;function O(){return e.jsxs("article",{children:[e.jsxs(s,{children:["一个真实 App 不止有页面，还要在页面间",e.jsx("strong",{children:"跳转"}),"，并在不同页面之间",e.jsx("strong",{children:"共享数据"}),"。这一章讲两件大事：用 ",e.jsx("code",{children:"NavigationStack"})," 做导航 （包括最有威力的「数据驱动 / 编程式导航」与深链），以及用 iOS 17 引入的全新",e.jsx("strong",{children:"Observation 框架"}),"（",e.jsx("code",{children:"@Observable"})," / ",e.jsx("code",{children:"@Bindable"})," /",e.jsx("code",{children:"@Environment"}),"）做跨视图状态共享。最后我们对照新旧 API，讲清这次范式升级到底变了什么。"]}),e.jsx("h2",{children:"一、NavigationStack：新一代导航容器"}),e.jsxs("p",{children:["iOS 16 起，",e.jsx("code",{children:"NavigationStack"})," 正式取代了旧的 ",e.jsx("code",{children:"NavigationView"}),"。 旧 API 的导航状态藏在一堆 ",e.jsx("code",{children:"NavigationLink"})," 的 ",e.jsx("code",{children:"isActive"})," 布尔值里， 难以编程控制、也难做深链。新的 ",e.jsx("code",{children:"NavigationStack"})," 把整条导航栈抽象成一个",e.jsx("strong",{children:"可绑定的路径（path）"}),"，让导航第一次变得「数据驱动、可被代码完全掌控」。"]}),e.jsx(i,{lang:"swift",title:"NavigationStack + NavigationLink + navigationDestination",code:c}),e.jsxs("p",{children:["新写法的关键是",e.jsx("strong",{children:"「值 + 目的地」分离"}),"：",e.jsx("code",{children:"NavigationLink"})," 不再直接写死目标视图， 而是携带一个 ",e.jsx("code",{children:"value"}),"；真正「这个值对应哪个页面」由 ",e.jsx("code",{children:".navigationDestination(for:)"}),"统一声明。这样一来，所有跳转目标集中管理，也为编程式导航打下基础。"]}),e.jsx("h2",{children:"二、数据驱动 / 编程式导航与深链"}),e.jsxs(n,{children:["给 ",e.jsx("code",{children:"NavigationStack(path: $path)"})," 绑定一个数组，这个数组",e.jsx("strong",{children:"就是"}),"当前的导航栈： 往里 ",e.jsx("code",{children:"append"})," 一个路由 = 前进一页，",e.jsx("code",{children:"removeLast"})," = 返回，",e.jsx("code",{children:"removeAll"})," = 回到根。 导航从此不再依赖用户点击，而是「修改数据 → 界面自动同步」。"]}),e.jsxs("p",{children:["实战中常把路由定义成一个遵循 ",e.jsx("code",{children:"Hashable"})," 的 ",e.jsx("code",{children:"enum"}),"，每个 case 代表一类目的地， 还能携带参数（如用户 id）。",e.jsx("code",{children:".navigationDestination(for: Route.self)"})," 里用",e.jsx("code",{children:"switch"})," 把每种路由映射到对应视图。"]}),e.jsx(i,{lang:"swift",title:"用 path 绑定做数据驱动导航",code:o}),e.jsx(i,{lang:"swift",title:"编程式跳转与深链",code:l}),e.jsxs("p",{children:[e.jsx("strong",{children:"深链（deep link）"}),"的本质就是：从一个外部 URL 或通知里解析出多级路由， 然后",e.jsx("strong",{children:"一次性给 path 赋一个数组"}),"，界面便会直接还原出整条栈——比如打开 App 就停在「设置 → 我的资料」这一深处页面，无需用户逐级点进去。这是旧 ",e.jsx("code",{children:"NavigationView"}),"几乎做不到的事。"]}),e.jsx(d,{title:"编程式导航能干什么",children:e.jsxs("p",{children:["登录成功后自动跳进主页、支付完成后跳到订单详情、收到推送后直达对应聊天——这些 「由逻辑而非点击触发的跳转」，都是往 ",e.jsx("code",{children:"path"})," 里追加路由实现的。"]})}),e.jsx("h3",{children:"toolbar：给导航栏放按钮"}),e.jsxs("p",{children:[e.jsx("code",{children:".toolbar"})," 修饰符用来往导航栏 / 底部栏放置按钮、标题等内容，并用",e.jsx("code",{children:"ToolbarItem"})," 的 ",e.jsx("code",{children:"placement"})," 指定位置（如",e.jsx("code",{children:".topBarTrailing"})," 放右上角）。它和 ",e.jsx("code",{children:"navigationTitle"})," 一起，构成了页面顶部的标准配置。"]}),e.jsx("h2",{children:"三、Observation 框架：新的跨视图状态共享"}),e.jsxs("p",{children:["iOS 17 带来了全新的 ",e.jsx("strong",{children:"Observation 框架"}),"，用一个 ",e.jsx("code",{children:"@Observable"})," 宏 重写了「可观察对象」的玩法，目标是替换啰嗦的 ",e.jsx("code",{children:"ObservableObject"})," + ",e.jsx("code",{children:"@Published"})," 组合。 新方案不仅写得更短，性能也更好——它能做到",e.jsx("strong",{children:"属性级别的精确追踪"}),"：视图只在它",e.jsx("em",{children:"真正读到"}),"的那个属性变化时才刷新，而不是对象任意属性一变就全量重渲染。"]}),e.jsx(i,{lang:"swift",title:"用 @Observable 标注模型类",code:a}),e.jsxs("p",{children:["对比旧写法：以前你要让类遵循 ",e.jsx("code",{children:"ObservableObject"}),"，再给每个需要触发刷新的属性加",e.jsx("code",{children:"@Published"}),"。现在只需在类上加一个 ",e.jsx("code",{children:"@Observable"}),"，里面写",e.jsx("strong",{children:"普通存储属性"}),"即可， 连计算属性也会被自动纳入追踪。"]}),e.jsx("h3",{children:"三个搭档：@State 持有、@Environment 注入、@Bindable 绑定"}),e.jsxs(n,{children:["新框架下记住三句话：在",e.jsx("strong",{children:"拥有者"}),"视图里用 ",e.jsx("code",{children:"@State"})," 持有",e.jsx("code",{children:"@Observable"})," 模型实例；要",e.jsx("strong",{children:"跨层共享"}),"就用 ",e.jsx("code",{children:".environment(model)"})," 注入、 子视图用 ",e.jsx("code",{children:"@Environment(Model.self)"})," 读取；当子视图要",e.jsx("strong",{children:"双向绑定"}),"模型的属性 （拿 ",e.jsx("code",{children:"$"})," 绑定给 ",e.jsx("code",{children:"Toggle"}),"/",e.jsx("code",{children:"TextField"}),"）时，用 ",e.jsx("code",{children:"@Bindable"}),"。"]}),e.jsx(i,{lang:"swift",title:"@State 持有 + @Environment 注入与读取",code:h}),e.jsxs("p",{children:["注意持有方式的变化：在旧 API 里你要用 ",e.jsx("code",{children:"@StateObject"})," 来持有",e.jsx("code",{children:"ObservableObject"}),"；新框架里 ",e.jsx("code",{children:"@Observable"})," 模型统一用普通的",e.jsx("code",{children:"@State"})," 持有即可，概念被大大简化了。注入侧，旧的",e.jsx("code",{children:"@EnvironmentObject"})," 被 ",e.jsx("code",{children:"@Environment(Model.self)"})," 取代。"]}),e.jsx(i,{lang:"swift",title:"@Bindable：子视图双向绑定模型属性",code:j}),e.jsxs(t,{variant:"warn",title:"@Environment 读取前必须先注入",children:["用 ",e.jsx("code",{children:"@Environment(CartModel.self)"})," 读取共享模型时，祖先视图必须已经用",e.jsx("code",{children:".environment(cart)"})," 注入过同类型实例，否则运行时会崩溃。这一点和旧的",e.jsx("code",{children:"@EnvironmentObject"})," 一样：忘了注入 = 闪退。"]}),e.jsx("h2",{children:"四、新旧 API 对照表"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"作用"}),e.jsx("th",{children:"旧 API（iOS 13–16）"}),e.jsx("th",{children:"新 API（iOS 17+）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"导航容器"}),e.jsx("td",{children:e.jsx("code",{children:"NavigationView"})}),e.jsx("td",{children:e.jsx("code",{children:"NavigationStack"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"编程式导航"}),e.jsxs("td",{children:[e.jsx("code",{children:"NavigationLink(isActive:)"})," 一堆布尔"]}),e.jsxs("td",{children:["绑定 ",e.jsx("code",{children:"path"})," 数组，append/remove"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"跳转目标声明"}),e.jsx("td",{children:"链接里写死目标视图"}),e.jsx("td",{children:e.jsx("code",{children:".navigationDestination(for:)"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"可观察模型"}),e.jsxs("td",{children:[e.jsx("code",{children:"class: ObservableObject"})," + ",e.jsx("code",{children:"@Published"})]}),e.jsxs("td",{children:[e.jsx("code",{children:"@Observable"})," 宏，普通属性"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"持有模型"}),e.jsx("td",{children:e.jsx("code",{children:"@StateObject"})}),e.jsx("td",{children:e.jsx("code",{children:"@State"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"观察外部传入的模型"}),e.jsx("td",{children:e.jsx("code",{children:"@ObservedObject"})}),e.jsxs("td",{children:["直接持有，或 ",e.jsx("code",{children:"@Bindable"})," 取绑定"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"跨层注入 / 读取"}),e.jsx("td",{children:e.jsx("code",{children:"@EnvironmentObject"})}),e.jsxs("td",{children:[e.jsx("code",{children:".environment(_:)"})," + ",e.jsx("code",{children:"@Environment(Type.self)"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"刷新粒度"}),e.jsx("td",{children:"对象任意属性变即全量刷新"}),e.jsx("td",{children:"属性级精确追踪，只刷新真正读到的"})]})]})]}),e.jsx("h2",{children:"五、模态呈现：sheet 与 fullScreenCover"}),e.jsxs("p",{children:["除了把页面压进导航栈，另一类常见交互是",e.jsx("strong",{children:"模态弹出"}),"。",e.jsx("code",{children:".sheet"})," 弹出一张 半屏卡片，用户可以下滑关闭，适合「临时的、可随手取消」的任务（新建、筛选、分享）；",e.jsx("code",{children:".fullScreenCover"})," 弹出全屏覆盖层，不能下滑关闭、必须由代码主动收起，适合 登录、开屏引导等「必须走完流程」的场景。两者都用一个 ",e.jsx("code",{children:"isPresented"})," 布尔绑定来控制显隐。"]}),e.jsx(i,{lang:"swift",title:"sheet 与 fullScreenCover",code:x}),e.jsxs(t,{variant:"tip",children:["选型口诀：",e.jsx("strong",{children:"可随手取消的临时任务用 sheet，必须完成的强制流程用 fullScreenCover"}),"。 sheet 还支持 ",e.jsx("code",{children:"presentationDetents"})," 设置半高 / 全高的停靠点，做出抽屉式的高度调节。"]}),e.jsx("h2",{children:"六、边界与易错点"}),e.jsxs("p",{children:["几条提醒：① 路由 ",e.jsx("code",{children:"enum"})," 必须 ",e.jsx("code",{children:"Hashable"}),"，否则无法作为",e.jsx("code",{children:"navigationDestination(for:)"})," 的类型；② ",e.jsx("code",{children:"@Environment"})," 读取前祖先必须注入， 否则崩溃；③ ",e.jsx("code",{children:"@Observable"})," 模型用 ",e.jsx("code",{children:"@State"})," 持有，别再习惯性写",e.jsx("code",{children:"@StateObject"}),"（那是旧框架的）；④ 只有需要把模型属性",e.jsx("strong",{children:"双向绑定"}),"给控件时才用",e.jsx("code",{children:"@Bindable"}),"，只读展示用普通访问即可；⑤ 新 Observation 框架需要 iOS 17+， 若要兼容更老系统仍得用 ",e.jsx("code",{children:"ObservableObject"})," 一套。"]}),e.jsx(r,{points:["NavigationStack 取代 NavigationView：用可绑定的 path 把整条导航栈抽象成数据，导航变得可编程、可深链。","NavigationLink 携带 value，由 navigationDestination(for:) 统一声明「值对应哪个页面」，跳转目标集中管理。","数据驱动导航：path 数组就是栈，append 前进、removeLast 返回、removeAll 回根；深链就是一次性给 path 赋多级路由。","Observation 框架：用 @Observable 宏标注模型类，写普通属性即可，自动做属性级精确追踪，性能更好。","三搭档：@State 持有模型，@Environment 跨层注入/读取，@Bindable 给子视图做双向绑定；对应旧的 @StateObject / @EnvironmentObject / @ObservedObject。","sheet 是可下滑取消的半屏卡片，fullScreenCover 是必须代码关闭的全屏覆盖；二者均用 isPresented 布尔控制显隐。"]})]})}export{O as default};
