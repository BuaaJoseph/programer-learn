import{j as e}from"./index-qtIRnDEm.js";import{L as r,S as t}from"./Summary-D7M9FdYM.js";import{K as i}from"./KeyIdea-C5mX38F7.js";import{C as d}from"./Callout-Bvq_rfqV.js";import{C as c}from"./CodeBlock-DsDQiuPI.js";import{E as s}from"./Example-Ba1iSJHN.js";const n=`import SwiftUI

struct StackDemo: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {   // 纵向：从上到下
            Text("标题").font(.title)
            Text("副标题").foregroundStyle(.secondary)

            HStack(spacing: 8) {                       // 横向：从左到右
                Image(systemName: "star.fill")
                Text("4.8")
                Spacer()                               // 把后面的内容推到最右
                Text("查看全部")
            }
        }
        .padding()
    }
}`,a=`struct Badge: View {
    var body: some View {
        ZStack(alignment: .topTrailing) {   // 沿 z 轴层叠，后写的在上层
            Image(systemName: "bell.fill")
                .font(.largeTitle)

            Text("3")                        // 红色角标叠在铃铛右上角
                .font(.caption2)
                .padding(5)
                .background(.red, in: Circle())
                .foregroundStyle(.white)
        }
    }
}`,l=`// alignment 决定子视图在交叉轴上如何对齐
VStack(alignment: .leading) {   // 子视图统一靠左
    Text("短")
    Text("长一点的一行文字")
}

HStack(alignment: .top) {       // 子视图统一靠顶
    Text("A").font(.largeTitle)
    Text("B").font(.caption)
}

// Divider 在 Stack 里画一条分隔线，方向随 Stack 自动旋转
VStack {
    Text("上半区")
    Divider()
    Text("下半区")
}`,o=`// 顺序 A：先加内边距，再上背景 —— 背景把"内容 + padding"一起包住
Text("Hello")
    .padding()
    .background(.yellow)     // 黄色块较大，含 padding

// 顺序 B：先上背景，再加内边距 —— 背景只裹住文字，padding 在背景外
Text("Hello")
    .background(.yellow)     // 黄色块紧贴文字，外面才是 padding
    .padding()`,h=`Text("固定宽高")
    .frame(width: 200, height: 80)          // 提议一个固定尺寸
    .background(.blue.opacity(0.2))

Text("撑满可用宽度")
    .frame(maxWidth: .infinity)             // 尽量占满父给的宽度
    .background(.green.opacity(0.2))

Text("带对齐的 frame")
    .frame(width: 200, height: 80, alignment: .topLeading)
    .background(.orange.opacity(0.2))       // 内容靠左上`,x=`GeometryReader { proxy in
    // proxy.size 给出父分配给本视图的可用尺寸
    Text("宽度的一半")
        .frame(width: proxy.size.width / 2)
        .background(.mint)
}`,j=`import SwiftUI

struct Task: Identifiable {           // List/ForEach 需要稳定身份
    let id = UUID()
    var title: String
    var done: Bool = false
}

struct TaskListView: View {
    @State private var tasks: [Task] = [
        Task(title: "买菜"),
        Task(title: "写周报"),
        Task(title: "健身"),
    ]

    var body: some View {
        List {
            Section("今天") {
                ForEach(tasks) { task in           // 闭包参数 task
                    HStack {
                        Image(systemName: task.done ? "checkmark.circle.fill" : "circle")
                        Text(task.title)
                    }
                }
                .onDelete { offsets in             // 左滑删除，回调给出下标集合
                    tasks.remove(atOffsets: offsets)
                }
            }
        }
    }
}`,g=`struct InboxView: View {
    @State private var query = ""
    @State private var mails: [String] = ["发票", "周报", "面试邀请"]

    var filtered: [String] {
        query.isEmpty ? mails : mails.filter { $0.contains(query) }
    }

    var body: some View {
        List(filtered, id: \\.self) { mail in
            Text(mail)
        }
        .searchable(text: $query)              // 顶部搜索框
        .refreshable {                          // 下拉刷新（async）
            await reload()
        }
    }

    func reload() async { /* 拉取新数据 */ }
}`;function u(){return e.jsxs("article",{children:[e.jsxs(r,{children:["SwiftUI 的界面是「拼」出来的：你不去手算每个控件的坐标，而是把视图放进",e.jsx("strong",{children:"布局容器"}),"里，告诉系统「它们该横着排、竖着排、还是叠在一起」， 剩下的尺寸协商交给框架。这一章我们讲透三大 Stack、Spacer 与 Divider、修饰符 （Modifier）以及它顺序敏感的坑，最后落到 SwiftUI 里最重要的高性能容器——",e.jsx("strong",{children:"List"}),"，并写一个带左滑删除、搜索、下拉刷新的可运行例子。"]}),e.jsx("h2",{children:"一、布局体系：三种 Stack 是骨架"}),e.jsxs("p",{children:["SwiftUI 的布局基石是三个容器：",e.jsx("code",{children:"VStack"}),"（纵向，从上到下）、",e.jsx("code",{children:"HStack"}),"（横向，从左到右）、",e.jsx("code",{children:"ZStack"}),"（沿 z 轴层叠，后写的盖在上层）。 几乎任何复杂界面，都是这三者层层嵌套的结果。它们都接收两个常用参数：",e.jsx("code",{children:"alignment"}),"（交叉轴对齐方式）和 ",e.jsx("code",{children:"spacing"}),"（子视图间距）。"]}),e.jsx(c,{lang:"swift",title:"VStack / HStack 基础",code:n}),e.jsxs("p",{children:["注意 ",e.jsx("code",{children:"alignment"})," 管的是",e.jsx("strong",{children:"交叉轴"}),"：",e.jsx("code",{children:"VStack"})," 的主轴是纵向， 所以它的 ",e.jsx("code",{children:"alignment"})," 控制子视图左右怎么对齐（",e.jsx("code",{children:".leading"})," /",e.jsx("code",{children:".center"})," / ",e.jsx("code",{children:".trailing"}),"）；",e.jsx("code",{children:"HStack"})," 主轴是横向， 它的 ",e.jsx("code",{children:"alignment"})," 控制上下怎么对齐（",e.jsx("code",{children:".top"})," / ",e.jsx("code",{children:".center"})," /",e.jsx("code",{children:".bottom"})," / ",e.jsx("code",{children:".firstTextBaseline"}),"）。"]}),e.jsx("h3",{children:"ZStack：层叠出角标、遮罩、卡片背景"}),e.jsxs("p",{children:[e.jsx("code",{children:"ZStack"})," 让视图沿垂直屏幕的方向堆叠，常用来做角标、半透明遮罩、给卡片铺底色。 它的 ",e.jsx("code",{children:"alignment"})," 是二维的，比如 ",e.jsx("code",{children:".topTrailing"})," 表示子视图统一对齐到右上角。"]}),e.jsx(c,{lang:"swift",title:"ZStack 做红点角标",code:a}),e.jsx("h3",{children:"Spacer 与 Divider：撑开与切分"}),e.jsxs("p",{children:[e.jsx("code",{children:"Spacer"})," 是一个「会膨胀的弹簧」：它尽可能占据主轴上的剩余空间，从而把其他视图 推开。在 ",e.jsx("code",{children:"HStack"})," 里放一个 ",e.jsx("code",{children:"Spacer"}),"，就能让左右两组内容分居两端； 放两个，则把内容挤到中间。",e.jsx("code",{children:"Divider"})," 则在 Stack 里画一条分隔线，方向随所在 Stack 自动旋转——在 ",e.jsx("code",{children:"VStack"})," 里是水平线，在 ",e.jsx("code",{children:"HStack"})," 里是竖线。"]}),e.jsx(c,{lang:"swift",title:"alignment、Divider 用法",code:l}),e.jsx(s,{title:"一句话理解三种 Stack",children:e.jsxs("p",{children:["把控件想成积木：",e.jsx("code",{children:"VStack"})," 是「叠罗汉」，",e.jsx("code",{children:"HStack"})," 是「手拉手排队」，",e.jsx("code",{children:"ZStack"})," 是「贴纸盖在海报上」。复杂界面 = 这三种积木反复嵌套。"]})}),e.jsx("h2",{children:"二、布局协商：父子之间的「三步对话」"}),e.jsxs(i,{children:["SwiftUI 的尺寸不是父强加给子的，而是一场协商：",e.jsx("strong",{children:"父视图给子视图一个建议尺寸 → 子视图根据自身内容自己决定要多大 → 父视图拿到子的实际尺寸后，再决定把它放在哪里"}),"。 理解这「提议—决定—放置」三步，是看懂一切布局行为的钥匙。"]}),e.jsxs("p",{children:["举例：",e.jsx("code",{children:"Text"})," 拿到父给的建议宽度后，会按内容算出自己「刚好够用」的尺寸；而",e.jsx("code",{children:"Color"})," 或 ",e.jsx("code",{children:"Rectangle"})," 这类形状则倾向于「父给多少我占多少」。 这就是为什么一段文字默认只占自己那么大，而一个色块会铺满——它们对「建议尺寸」的态度不同。"]}),e.jsx("h2",{children:"三、修饰符（Modifier）：链式描述视图"}),e.jsxs("p",{children:["修饰符是 SwiftUI 描述外观与行为的方式：你在视图后面用点语法链式调用",e.jsx("code",{children:".padding()"}),"、",e.jsx("code",{children:".background(...)"}),"、",e.jsx("code",{children:".frame(...)"}),"、",e.jsx("code",{children:".font(...)"})," 等。关键认知是——",e.jsx("strong",{children:"每个修饰符都返回一个「包裹了原视图的新视图」"}),"， 而不是在原地修改。所以一条修饰符链，本质是从内到外一层层套娃。"]}),e.jsx(c,{lang:"swift",title:"frame 与对齐",code:h}),e.jsxs(d,{variant:"warn",title:"修饰符顺序会改变结果",children:["因为每个修饰符都「包裹」前一个，所以",e.jsx("strong",{children:"顺序不同，结果就不同"}),"。最经典的坑是",e.jsx("code",{children:".padding()"})," 与 ",e.jsx("code",{children:".background(...)"})," 的先后：先 padding 再 background， 背景会把内边距一起染色；反过来，背景只裹住内容，padding 留在背景之外。"]}),e.jsx(c,{lang:"swift",title:"顺序对照：padding 与 background",code:o}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"写法"}),e.jsx("th",{children:"效果"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:".padding().background()"})}),e.jsx("td",{children:"背景较大，把内容 + 内边距一起填色"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:".background().padding()"})}),e.jsx("td",{children:"背景紧贴内容，内边距留在背景外（透明）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:".frame().background()"})}),e.jsx("td",{children:"背景填满整个 frame 区域"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:".background().frame()"})}),e.jsx("td",{children:"背景只填内容，frame 多出的空间不上色"})]})]})]}),e.jsx("h3",{children:"Layout 协议与 GeometryReader（了解即可）"}),e.jsxs("p",{children:["当三大 Stack 不够用时，iOS 16+ 提供了自定义 ",e.jsx("code",{children:"Layout"})," 协议（可实现流式布局等）， 而 ",e.jsx("code",{children:"GeometryReader"})," 则让你读到父分配的",e.jsx("strong",{children:"实际可用尺寸"}),"，按比例做布局—— 但它会「贪婪」地占满空间，应谨慎、局部地使用，不要用它包整个页面。"]}),e.jsx(c,{lang:"swift",title:"GeometryReader 读取可用尺寸",code:x}),e.jsx("h2",{children:"四、List：高性能列表容器"}),e.jsxs("p",{children:["当你要展示一长串数据时，不要用 ",e.jsx("code",{children:"ScrollView"})," + ",e.jsx("code",{children:"VStack"})," 硬堆——那会一次性 创建所有行，列表一长就卡。正确做法是 ",e.jsx("code",{children:"List"}),"：它底层基于",e.jsx("strong",{children:"行复用（cell reuse）"}),"机制，只渲染屏幕上可见的行，滑出去的行会被回收复用， 因此能流畅承载成千上万条数据。这是 SwiftUI 里做列表的首选。"]}),e.jsxs(i,{children:[e.jsx("code",{children:"List"})," + ",e.jsx("code",{children:"ForEach"})," 是黄金搭档。",e.jsx("code",{children:"ForEach"})," 要求每个元素有",e.jsx("strong",{children:"稳定且唯一的身份"}),"：要么数据类型遵循 ",e.jsx("code",{children:"Identifiable"}),"（提供 ",e.jsx("code",{children:"id"}),"）， 要么显式用 ",e.jsx("code",{children:"id:"})," 参数指定。有了稳定身份，SwiftUI 才能正确地复用行、计算插入 / 删除 / 移动的动画。"]}),e.jsx("h3",{children:"ForEach + Identifiable + Section + 滑动删除"}),e.jsxs("p",{children:["下面是一个可运行的待办列表：模型 ",e.jsx("code",{children:"Task"})," 遵循 ",e.jsx("code",{children:"Identifiable"}),"，",e.jsx("code",{children:"ForEach"})," 遍历它生成行，",e.jsx("code",{children:"Section"})," 把行分组并带标题，",e.jsx("code",{children:".onDelete"})," 提供左滑删除——它的回调参数是被删除行的下标集合 （",e.jsx("code",{children:"IndexSet"}),"），配合数组的 ",e.jsx("code",{children:"remove(atOffsets:)"})," 即可。"]}),e.jsx(c,{lang:"swift",title:"List + ForEach + Section + onDelete（可运行）",code:j}),e.jsxs("p",{children:["这里 ",e.jsx("code",{children:".onDelete"})," 挂在 ",e.jsx("code",{children:"ForEach"})," 上而不是 ",e.jsx("code",{children:"List"})," 上，这一点很重要： 删除操作针对的是「这一组被遍历的数据」，所以由 ",e.jsx("code",{children:"ForEach"})," 来声明。闭包参数",e.jsx("code",{children:"offsets"})," 是一个下标集合（可能一次删多行），交给 ",e.jsx("code",{children:"remove(atOffsets:)"})," 处理。"]}),e.jsx("h3",{children:"searchable 与 refreshable"}),e.jsxs("p",{children:["现代 List 还内建两个开箱即用的能力：",e.jsx("code",{children:".searchable(text:)"})," 在导航栏下方挂一个搜索框， 你只需把它绑定到一个 ",e.jsx("code",{children:"@State"})," 字符串，再用该字符串过滤数据源；",e.jsx("code",{children:".refreshable"})," 提供原生的下拉刷新，它的闭包是 ",e.jsx("code",{children:"async"})," 的， 系统会自动显示加载指示器，直到你的异步任务完成。"]}),e.jsx(c,{lang:"swift",title:"searchable + refreshable",code:g}),e.jsxs(d,{variant:"tip",children:["当数组元素本身不是 ",e.jsx("code",{children:"Identifiable"}),"（比如就是一串 ",e.jsx("code",{children:"String"}),"），可以用",e.jsx("code",{children:"id: \\.self"})," 把元素自身当作身份——前提是元素",e.jsx("strong",{children:"唯一且可哈希"}),"。 一旦有重复值，行的身份就会混乱，导致动画与复用出错。"]}),e.jsx("h2",{children:"五、边界与易错点"}),e.jsxs("p",{children:["几条实战经验：① ",e.jsx("code",{children:"ForEach"})," 的身份一定要稳定，用数组下标当 id 在增删时会出乱子； ② ",e.jsx("code",{children:"GeometryReader"})," 会撑满父空间，别拿它包整页；③ 修饰符顺序敏感，遇到「背景大小不对」 先回头看是不是 padding/background 写反了；④ 大数据量坚决用 ",e.jsx("code",{children:"List"})," 而非",e.jsx("code",{children:"ScrollView"})," + ",e.jsx("code",{children:"VStack"}),"；⑤ ",e.jsx("code",{children:"Spacer"})," 在没有约束的容器里可能不生效， 要确认它所在的 Stack 在主轴方向上有可分配的空间。"]}),e.jsx(t,{points:["三大布局容器：VStack（纵向）、HStack（横向）、ZStack（层叠），用 alignment 控交叉轴对齐、spacing 控间距，复杂界面靠它们嵌套。","Spacer 是会膨胀的弹簧（把视图推开），Divider 在 Stack 里画分隔线（方向随 Stack 旋转）。","SwiftUI 布局是三步协商：父给建议尺寸 → 子自己决定大小 → 父再放置子视图。","修饰符链式且顺序敏感：每个修饰符都返回包裹原视图的新视图，padding 与 background 的先后会改变填色范围。","Layout 协议可做自定义布局，GeometryReader 能读父分配的可用尺寸但会贪婪占满，应局部使用。","List 靠行复用做到高性能，搭配 ForEach + Identifiable（或 id:）；Section 分组、onDelete 滑动删除、refreshable 下拉刷新、searchable 搜索均开箱即用。"]})]})}export{u as default};
