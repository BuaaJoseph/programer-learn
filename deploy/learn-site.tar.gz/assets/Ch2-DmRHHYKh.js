import{r as h,j as e}from"./index-DraKZMSn.js";import{L as x,S as j}from"./Summary-D7nqkGRf.js";import{K as g}from"./KeyIdea-C2HcfWY0.js";import{E as v}from"./Example-yyME7alB.js";import{P as f}from"./Practice-Bq0moWPJ.js";import{C as p}from"./Callout-BE-nWzIM.js";import{C as s}from"./CodeBlock-BiqAHAS8.js";import{F as u}from"./Figure-BqzlOW-g.js";const c={hungry:{label:"饿汉式",safe:!0,lazy:!1,desc:"类加载时就创建实例(static final)。线程安全、简单；缺点是不管用不用都创建，可能浪费。"},lazyBad:{label:"懒汉式(非线程安全)",safe:!1,lazy:!0,desc:"用时才创建，但多线程下可能创建出多个实例——错误示范。"},dcl:{label:"双重检查锁 DCL",safe:!0,lazy:!0,desc:"两次判空 + synchronized + volatile(防指令重排导致拿到半初始化对象)。懒加载且线程安全。"},holder:{label:"静态内部类",safe:!0,lazy:!0,desc:"利用类加载机制：外部类加载时不创建，调用 getInstance 才加载内部类。懒加载、线程安全、写法优雅。"},enum:{label:"枚举",safe:!0,lazy:!1,desc:"《Effective Java》推荐：天然线程安全、且能防反射和反序列化破坏单例。"}};function m(){const[t,a]=h.useState("dcl"),n=c[t],o=e.jsx(e.Fragment,{children:Object.entries(c).map(([r,i])=>e.jsx("button",{className:`fig-btn ${t===r?"active":""}`,onClick:()=>a(r),children:i.label.split("(")[0]},r))});return e.jsx(u,{caption:"单例保证一个类全局只有一个实例。五种写法各有取舍，面试重点是线程安全与懒加载：DCL 为什么要 volatile、静态内部类为什么优雅、枚举为什么最安全。",controls:o,children:e.jsxs("svg",{viewBox:"0 0 460 180",width:"460",role:"img","aria-label":"单例模式五种写法",children:[Object.entries(c).map(([r,i],d)=>{const l=t===r;return e.jsxs("g",{children:[e.jsx("rect",{x:"20",y:20+d*26,width:"180",height:"22",rx:"5",fill:l?"var(--accent)":"var(--bg-subtle)",stroke:l?"var(--accent-strong)":"var(--border)"}),e.jsx("text",{x:"30",y:35+d*26,fontFamily:"var(--mono)",fontSize:"10",fontWeight:l?"700":"400",fill:l?"#ffffff":"var(--ink)",children:i.label})]},r)}),e.jsxs("g",{transform:"translate(220 24)",children:[e.jsx("rect",{x:"0",y:"0",width:"100",height:"44",rx:"8",fill:n.safe?"var(--green-soft)":"var(--rose-soft)",stroke:n.safe?"var(--green)":"var(--rose)"}),e.jsx("text",{x:"50",y:"20",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"10",fill:"var(--ink-soft)",children:"线程安全"}),e.jsx("text",{x:"50",y:"36",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"13",fontWeight:"700",fill:n.safe?"var(--green)":"var(--rose)",children:n.safe?"✓":"✗"}),e.jsx("rect",{x:"110",y:"0",width:"100",height:"44",rx:"8",fill:n.lazy?"var(--green-soft)":"var(--bg-sunken)",stroke:n.lazy?"var(--green)":"var(--border-strong)"}),e.jsx("text",{x:"160",y:"20",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"10",fill:"var(--ink-soft)",children:"懒加载"}),e.jsx("text",{x:"160",y:"36",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"13",fontWeight:"700",fill:n.lazy?"var(--green)":"var(--ink-faint)",children:n.lazy?"✓":"✗"})]}),e.jsx("rect",{x:"220",y:"80",width:"210",height:"86",rx:"8",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsx("foreignObject",{x:"228",y:"84",width:"194",height:"80",children:e.jsxs("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"11px var(--sans)",color:"var(--ink)",lineHeight:1.35},children:[e.jsxs("strong",{style:{color:"var(--accent-strong)"},children:[n.label,"："]}),n.desc]})})]})})}const b=`// 饿汉式：类加载时就创建实例，天生线程安全，但不能懒加载
public class Hungry {

    // 类加载阶段由 JVM 保证只初始化一次，所以线程安全
    private static final Hungry INSTANCE = new Hungry();

    private Hungry() {}   // 私有构造，禁止外部 new

    public static Hungry getInstance() {
        return INSTANCE;
    }
}`,y=`// 懒汉式（非线程安全）：用时才创建，但多线程下会创建多个实例
public class Lazy {

    private static Lazy instance;

    private Lazy() {}

    public static Lazy getInstance() {
        // 两个线程可能同时通过这个 if，于是各 new 一个
        if (instance == null) {
            instance = new Lazy();
        }
        return instance;
    }
}`,C=`// 静态内部类：既懒加载又线程安全，推荐写法之一
public class Holder {

    private Holder() {}

    // 内部类不会随外部类加载而加载，
    // 只有第一次调用 getInstance 才会触发，实现懒加载
    private static class Inner {
        // 类初始化由 JVM 加锁保证，所以线程安全
        private static final Holder INSTANCE = new Holder();
    }

    public static Holder getInstance() {
        return Inner.INSTANCE;
    }
}`,S=`// 写法一：双重检查锁 DCL
public class Dcl {

    // volatile 必不可少：禁止指令重排，防止拿到半初始化对象
    private static volatile Dcl instance;

    private Dcl() {}

    public static Dcl getInstance() {
        if (instance == null) {               // 第一次检查：避免每次都加锁
            synchronized (Dcl.class) {
                if (instance == null) {       // 第二次检查：防止重复创建
                    instance = new Dcl();
                }
            }
        }
        return instance;
    }
}`,D=`// 写法二：枚举单例，最安全，天然防反射与反序列化
public enum EnumSingleton {

    INSTANCE;

    public void doSomething() {
        System.out.println("枚举单例在工作");
    }
}

// 使用：EnumSingleton.INSTANCE.doSomething();`,w=`// 反射攻击：普通单例的私有构造挡不住反射
Constructor<Dcl> c = Dcl.class.getDeclaredConstructor();
c.setAccessible(true);          // 强行打开私有构造
Dcl one = c.newInstance();      // 造出第二个实例，单例被打破！
Dcl two = Dcl.getInstance();
System.out.println(one == two); // false

// 防御：在构造方法里加判断，已存在实例就抛异常
private Dcl() {
    if (instance != null) {
        throw new IllegalStateException("已存在实例，禁止反射创建");
    }
}
// 但枚举从根上免疫：JVM 在 newInstance 里直接拒绝反射创建枚举`,I=`// 反序列化攻击：每次 readObject 都会 new 出新对象，破坏单例
// 防御：实现 readResolve，反序列化时强制返回已有实例
public class Singleton implements Serializable {
    private static final Singleton INSTANCE = new Singleton();
    private Singleton() {}
    public static Singleton getInstance() { return INSTANCE; }

    // 反序列化最后一步会调用它，用它顶替掉新 new 的对象
    private Object readResolve() {
        return INSTANCE;
    }
}`;function k(){return e.jsxs(e.Fragment,{children:[e.jsx(x,{children:e.jsxs("p",{children:["单例模式（Singleton）要解决的问题只有一句话：",e.jsx("strong",{children:"保证一个类全局只有一个实例， 并提供一个访问它的入口"}),"。听起来简单，却是面试里被追问最深的一个—— 因为它把「私有构造、懒加载、线程安全、指令重排、反射攻击」这些硬核知识点全串了起来。"]})}),e.jsx("h2",{children:"单例模式的意图与适用场景"}),e.jsxs("p",{children:["GoF 对单例的定义是：",e.jsx("strong",{children:"保证一个类仅有一个实例，并提供一个全局访问点"}),"。 它的两个核心承诺缺一不可——「仅有一个」（唯一性）和「全局可访问」（访问点）。 从 UML 角色看，单例只有一个角色：",e.jsx("strong",{children:"Singleton"})," 自身，它既是类、又是自己唯一实例的持有者与提供者。"]}),e.jsx("p",{children:"什么时候才真的需要它？典型场景有三类："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"表示「物理上唯一」的资源"}),"：数据库连接池、线程池、文件系统句柄——多份反而出错或浪费。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"无状态或状态全局一致的工具"}),"：日志器、ID 生成器、缓存、计数器。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"全局配置中心"}),"：应用启动时加载一次配置，处处共享同一份。"]})]}),e.jsx("p",{children:"反过来，凡是「有请求级/会话级状态」「需要被替换以便测试」的对象都不该做成单例——这一点本章末尾会展开。"}),e.jsx("h2",{children:"单例的三个共同要件"}),e.jsxs("p",{children:["无论哪种写法，单例都离不开三件事：",e.jsx("strong",{children:"构造方法私有化"}),"（不让外部 new）、",e.jsx("strong",{children:"类内部自己持有唯一实例"}),"、",e.jsx("strong",{children:"对外暴露一个静态获取方法"}),"。 各种写法的差异，本质都在回答两个问题：实例什么时候创建（懒不懒）、多线程下安不安全。"]}),e.jsx("h3",{children:"饿汉式：简单但不懒"}),e.jsxs("p",{children:["实例在类加载时就创建好。JVM 保证类只初始化一次，所以",e.jsx("strong",{children:"天生线程安全"}),"。 缺点是无论用不用都先创建，",e.jsx("strong",{children:"不能懒加载"}),"，可能浪费资源。"]}),e.jsx("h3",{children:"懒汉式：懒但不安全"}),e.jsxs("p",{children:["第一次调用才创建，实现了懒加载，但裸写的判空在多线程下会",e.jsx("strong",{children:"同时通过 if 各创建一个"}),"， 破坏了单例。直接加 ",e.jsx("code",{children:"synchronized"})," 到方法上能解决，但每次获取都加锁，性能差。"]}),e.jsx("h3",{children:"双重检查锁 DCL：为什么必须 volatile"}),e.jsxs("p",{children:["DCL 用两次判空把加锁缩小到「第一次创建」那一瞬间，兼顾性能与安全。关键的坑在",e.jsx("code",{children:"volatile"}),"：",e.jsx("code",{children:"instance = new Dcl()"})," 这一行不是原子的， 它包含「分配内存、初始化对象、把引用指向内存」三步，JVM 可能",e.jsx("strong",{children:"指令重排"}),"， 让「引用先指向内存」而「对象还没初始化完」。此时另一个线程在第一次判空里看到 instance 非空就直接返回，拿到的却是",e.jsx("strong",{children:"半初始化对象"}),"。 加 ",e.jsx("code",{children:"volatile"})," 禁止这种重排，问题才彻底解决。"]}),e.jsx("h3",{children:"静态内部类：又懒又安全"}),e.jsxs("p",{children:["把实例放进一个静态内部类里。外部类加载时",e.jsx("strong",{children:"不会"}),"加载内部类，只有第一次调用 getInstance 引用到内部类，才触发它的初始化——这就实现了懒加载。 而类的初始化过程由 JVM 加锁保证只执行一次，所以又天然线程安全。写法干净，强烈推荐。"]}),e.jsx("h3",{children:"枚举：最安全的写法"}),e.jsxs("p",{children:["《Effective Java》力荐的写法。枚举由 JVM 保证实例唯一且线程安全，更重要的是它能",e.jsx("strong",{children:"天然防反射和防反序列化"}),"：反射创建枚举会被 JDK 主动抛异常， 反序列化也由 JVM 保证返回同一个枚举实例。其他写法都需要额外手段才能堵这两个漏洞。"]}),e.jsx(v,{title:"五种写法对比",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"饿汉式"})," · 线程安全，",e.jsx("strong",{children:"不"}),"懒加载"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"懒汉式（裸）"})," · 懒加载，",e.jsx("strong",{children:"非"}),"线程安全"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"DCL"})," · 懒加载 + 线程安全（必须 volatile）"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"静态内部类"})," · 懒加载 + 线程安全，写法最优雅"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"枚举"})," · 线程安全 + 防反射 / 防反序列化，最安全"]})]})}),e.jsx(m,{}),e.jsx("h2",{children:"五种写法横向对比表"}),e.jsx("p",{children:"把懒加载、线程安全、防反射、防反序列化、推荐度五个维度拉成一张表，一眼看清各写法的取舍："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"写法"}),e.jsx("th",{children:"懒加载"}),e.jsx("th",{children:"线程安全"}),e.jsx("th",{children:"防反射"}),e.jsx("th",{children:"防反序列化"}),e.jsx("th",{children:"推荐度"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"饿汉式"}),e.jsx("td",{children:"否"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"否"}),e.jsx("td",{children:"需 readResolve"}),e.jsx("td",{children:"简单场景可用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"裸懒汉式"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"否"}),e.jsx("td",{children:"否"}),e.jsx("td",{children:"需 readResolve"}),e.jsx("td",{children:"不推荐"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"DCL"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"是（须 volatile）"}),e.jsx("td",{children:"否"}),e.jsx("td",{children:"需 readResolve"}),e.jsx("td",{children:"可用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"静态内部类"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"否"}),e.jsx("td",{children:"需 readResolve"}),e.jsx("td",{children:"推荐"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"枚举"}),e.jsx("td",{children:"否"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"是（天然）"}),e.jsx("td",{children:"是（天然）"}),e.jsx("td",{children:"最推荐"})]})]})]}),e.jsx("h2",{children:"两个被忽视的攻击面：反射与反序列化"}),e.jsxs("p",{children:["面试官追问完 DCL，下一刀往往就是「私有构造真的拦得住所有人吗」。答案是：",e.jsx("strong",{children:"拦不住反射"}),"。 通过 ",e.jsx("code",{children:"setAccessible(true)"})," 可以强行打开私有构造，造出第二个实例，单例被打破："]}),e.jsx(s,{lang:"java",title:"反射攻击与防御",code:w}),e.jsxs("p",{children:["第二个口子是",e.jsx("strong",{children:"反序列化"}),"：每次 ",e.jsx("code",{children:"readObject"})," 都会通过反射 new 出一个新对象， 同样破坏唯一性。防御手段是实现 ",e.jsx("code",{children:"readResolve"}),"，让反序列化最后用已有实例顶替掉新对象："]}),e.jsx(s,{lang:"java",title:"反序列化攻击与防御",code:I}),e.jsxs("p",{children:["而这两个口子，",e.jsx("strong",{children:"枚举单例天生免疫"}),"：JVM 在 ",e.jsx("code",{children:"Constructor.newInstance"})," 里 显式禁止反射创建枚举，反序列化也由 JVM 保证返回同一枚举实例。这正是《Effective Java》力荐枚举的根本原因。"]}),e.jsx(g,{title:"volatile 防的是「半成品对象」",children:e.jsxs("p",{children:["DCL 里 volatile 的作用常被误说成「保证可见性」。更精确地说，这里它真正解决的是",e.jsx("strong",{children:"指令重排导致的安全发布问题"}),"：禁止「引用赋值」越过「对象初始化」提前发生， 从而保证任何线程看到非空 instance 时，对象一定",e.jsx("strong",{children:"已经完整初始化"}),"。 这是 DCL 面试的标准追问，答出「半初始化对象」这五个字就拿分了。"]})}),e.jsx(p,{variant:"warn",title:"单例不是想用就用",children:e.jsxs("p",{children:["单例把对象生命周期变成全局可见，容易变成",e.jsx("strong",{children:"变相的全局变量"}),"， 带来隐式依赖、难以单元测试、状态共享引发并发问题等隐患。 配置类、连接池、日志器这类「确实全局唯一且无状态或状态可控」的对象才适合用单例， 普通业务对象别滥用。"]})}),e.jsx("h2",{children:"单例的常见误用与争议"}),e.jsx("p",{children:"很多人把单例当成「方便取对象」的捷径，结果埋下不少坑："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"变相全局变量"}),"：单例的可变状态会被任意代码随时读写，并发下极易出现脏数据， 且这种依赖是",e.jsx("em",{children:"隐式"}),"的——从方法签名根本看不出它偷偷用了哪个单例。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"难以单元测试"}),"：单例把依赖写死在静态方法里，测试时无法替换成 mock； 而且单例的状态会跨测试用例残留，导致用例之间互相污染。这正是 DIP（依赖注入）更受欢迎的原因。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"类加载器/多实例陷阱"}),"：在多个 ClassLoader（如某些容器、热部署环境）下， 同一个单例类可能被加载多份，「全局唯一」在 JVM 层面就不再成立。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"过早优化"}),"：为「省一次创建」而上单例，往往得不偿失；现代对象创建极快， 除非确有唯一性语义，否则普通对象 + 依赖注入更清晰。"]})]}),e.jsxs("p",{children:["正因如此，社区里一直有「单例是反模式」的声音。更准确的说法是：",e.jsx("strong",{children:"单例适合表达「唯一性」的语义， 但不该被用来做「全局取值」的偷懒"}),"。需要全局共享时，优先交给 IoC 容器以单例作用域管理 Bean， 而不是自己写静态单例——这样既保留唯一性，又能注入、能替换、能测试。"]}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["实际开发里我们很少手写单例，因为 ",e.jsx("strong",{children:"Spring 的 Bean 默认就是单例"}),"（singleton 作用域）， 容器帮你保证唯一性，各种 ",e.jsx("code",{children:"@Configuration"})," 配置类、Service、连接池都靠它管理。 面试被问「单例怎么写」，建议主线答",e.jsx("strong",{children:"静态内部类"}),"（优雅）和",e.jsx("strong",{children:"枚举"}),"（最安全）， 再用 DCL 的 volatile 展示你懂底层，最后点一句「工程里一般交给 Spring」。"]}),e.jsxs("p",{children:["几个高频追问预先备好答案：",e.jsx("strong",{children:"「Spring 的单例和 GoF 单例一样吗」"}),"——不一样， GoF 单例是「整个 JVM 一个实例」，Spring 单例是「每个",e.jsx("em",{children:"容器"}),"、每个 beanName 一个实例」， 作用域不同；",e.jsx("strong",{children:"「DCL 不加 volatile 会怎样」"}),"——可能拿到半初始化对象，答出「指令重排 + 安全发布」；",e.jsx("strong",{children:"「为什么枚举最安全」"}),"——天然防反射与反序列化，且写法最简；",e.jsx("strong",{children:"「单例有什么缺点」"}),"——隐式全局依赖、难测试、可变状态并发风险，建议交给容器管理。"]}),e.jsxs(f,{title:"手写 DCL 与枚举两种单例",children:[e.jsxs("p",{children:["下面是面试最常要求手写的两种：双重检查锁与枚举。重点记住 DCL 的两次判空和那个 关键的 ",e.jsx("code",{children:"volatile"}),"，以及枚举写法为何能一行解决所有安全问题。"]}),e.jsx(s,{lang:"java",title:"双重检查锁 DCL",code:S}),e.jsx(s,{lang:"java",title:"枚举单例",code:D}),e.jsx("p",{children:"对照参考：饿汉、懒汉、静态内部类三种写法的骨架如下，注意它们在懒加载与线程安全上的取舍。"}),e.jsx(s,{lang:"java",title:"饿汉式",code:b}),e.jsx(s,{lang:"java",title:"懒汉式（非线程安全）",code:y}),e.jsx(s,{lang:"java",title:"静态内部类",code:C})]}),e.jsx(j,{points:["单例三要件：私有构造、内部持有唯一实例、对外暴露静态获取方法，差异都在懒加载与线程安全的取舍。","饿汉式线程安全但不懒；裸懒汉式懒加载但非线程安全，会创建多个实例。","DCL 用两次判空把加锁缩到创建瞬间，volatile 必不可少，作用是禁止指令重排、防止拿到半初始化对象。","静态内部类利用「内部类延迟加载 + JVM 类初始化加锁」做到又懒又安全，是最优雅的写法。","枚举单例最安全，天然防反射与反序列化，是《Effective Java》推荐的首选。","普通单例挡不住反射（setAccessible 强开私有构造）和反序列化（每次 readObject 造新对象），需构造判空 + readResolve 防御。","单例适合表达「唯一性」语义（连接池、日志器、配置），但用作「全局取值」会带来隐式依赖、难测试、并发风险。","Spring 单例是「每容器每 beanName 一个」，与 GoF「整个 JVM 一个」作用域不同；工程中优先交给容器管理而非手写静态单例。"]})]})}export{k as default};
