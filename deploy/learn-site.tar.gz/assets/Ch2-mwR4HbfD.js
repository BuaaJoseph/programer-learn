import{j as e}from"./index-BAhU_Xet.js";import{L as s,S as c}from"./Summary-DeCBcqSp.js";import{K as t}from"./KeyIdea-DnEcW4Ye.js";import{C as i}from"./Callout-OljS8ooD.js";import{C as r}from"./CodeBlock-ClAC9vi8.js";import{E as l}from"./Example-D5OEBxRp.js";const o=`# 安装 CrewAI（Python 3.10–3.13）
pip install crewai

# 配置百炼 API Key（OpenAI 兼容协议）
export DASHSCOPE_API_KEY="sk-你的key"

# 运行
python examples/agent-frameworks/05-crewai/research_write_crew.py`,n=`import os

from crewai import LLM, Agent, Crew, Process, Task

llm = LLM(
    model="openai/qwen-plus",
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    api_key=os.environ["DASHSCOPE_API_KEY"],
)

researcher = Agent(
    role="技术研究员",
    goal="就给定主题梳理 3-5 个关键要点",
    backstory="你擅长快速抓住一个技术话题的核心，条理清晰。",
    llm=llm,
    verbose=True,
)
writer = Agent(
    role="技术撰稿人",
    goal="把研究要点写成一篇通俗易懂的中文短文",
    backstory="你擅长把复杂技术讲得清楚有趣。",
    llm=llm,
    verbose=True,
)

research_task = Task(
    description="研究主题：{topic}。列出 3-5 个最关键的要点，每点一句话。",
    expected_output="一个要点列表。",
    agent=researcher,
)
write_task = Task(
    description="根据研究要点，写一篇约 300 字的中文科普短文。",
    expected_output="一篇约 300 字的短文。",
    agent=writer,
    context=[research_task],
)

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, write_task],
    process=Process.sequential,
)


def main() -> None:
    result = crew.kickoff(inputs={"topic": "什么是 AI Agent"})
    print("=== 最终产出 ===")
    print(result)


if __name__ == "__main__":
    main()`,a=`llm = LLM(
    model="openai/qwen-plus",   # openai/ 前缀 = 走 OpenAI 兼容协议
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    api_key=os.environ["DASHSCOPE_API_KEY"],
)`,h=`write_task = Task(
    description="根据研究要点，写一篇约 300 字的中文科普短文。",
    expected_output="一篇约 300 字的短文。",
    agent=writer,
    context=[research_task],   # 把 research_task 的产出接力进来
)`,d=`from crewai.tools import tool

@tool("简单计算器")
def calc(expr: str) -> str:
    """对一个算术表达式求值，返回结果字符串。"""
    return str(eval(expr))   # 演示用；生产环境请勿直接 eval

researcher = Agent(
    role="技术研究员",
    goal="就给定主题梳理 3-5 个关键要点",
    backstory="你擅长快速抓住一个技术话题的核心，条理清晰。",
    llm=llm,
    tools=[calc],     # 把工具挂到 Agent 上，它就能在推理时调用
    verbose=True,
)`,p=`# 把 Process 换成 hierarchical，需要额外提供 manager_llm
crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, write_task],
    process=Process.hierarchical,   # 由经理动态委派
    manager_llm=llm,                # 必填：经理用哪个模型来委派
)`,x=`from crewai.flow.flow import Flow, start, listen


class ResearchWriteFlow(Flow):
    @start()
    def choose_topic(self):
        topic = "什么是 AI Agent"
        self.state["topic"] = topic
        return topic

    @listen(choose_topic)
    def run_crew(self, topic):
        # Flow 负责确定性流程；创造性的协作交给自治的 Crew
        result = crew.kickoff(inputs={"topic": topic})
        return result


if __name__ == "__main__":
    print(ResearchWriteFlow().kickoff())`;function u(){return e.jsxs("article",{children:[e.jsx(s,{children:"这一章我们把一个真实可跑的双 Agent 协作脚本逐行拆开：一个「研究员」先梳理要点，一个「撰稿人」接力写成科普短文，全程接百炼的 qwen-plus。看懂它，你就掌握了 CrewAI 最常用的 sequential 协作模式，并能进一步扩展到工具、hierarchical 与 Flow。"}),e.jsx("h2",{children:"安装与环境"}),e.jsxs("p",{children:["CrewAI 支持 Python 3.10–3.13。安装后只需一个环境变量 ",e.jsx("code",{children:"DASHSCOPE_API_KEY"})," 即可接通百炼。"]}),e.jsx(r,{lang:"bash",title:"安装与环境",code:o}),e.jsx("h2",{children:"完整代码"}),e.jsx(r,{lang:"python",title:"examples/agent-frameworks/05-crewai/research_write_crew.py",code:n}),e.jsx("h2",{children:"逐段讲解"}),e.jsx("h3",{children:"1. 配置 LLM：openai/ 前缀是关键"}),e.jsxs("p",{children:["百炼提供 OpenAI 兼容端点，所以我们用 CrewAI 的 ",e.jsx("code",{children:"LLM"})," 包一层。",e.jsx("code",{children:"model"})," 里的 ",e.jsx("code",{children:"openai/"})," 前缀",e.jsx("strong",{children:"不能省"}),"——它告诉 CrewAI「按 OpenAI 协议去请求」，后半段 ",e.jsx("code",{children:"qwen-plus"})," 才是真正的模型名。",e.jsx("code",{children:"base_url"})," 指向百炼的兼容端点，",e.jsx("code",{children:"api_key"})," 从环境变量读取。"]}),e.jsx(r,{lang:"python",title:"LLM 配置",code:a}),e.jsx("h3",{children:"2. 定义两个角色：用人设塑造行为"}),e.jsxs("p",{children:["researcher 和 writer 的差异完全由 role / goal / backstory 决定。研究员的 backstory 强调「抓核心、条理清晰」，于是它倾向输出结构化要点；撰稿人的 backstory 强调「讲得清楚有趣」，于是它倾向写流畅的科普文字。两者共用同一个 ",e.jsx("code",{children:"llm"}),"，但因为人设不同，行为也不同。",e.jsx("code",{children:"verbose=True"})," 会把它们的思考过程打印出来，调试时非常有用。"]}),e.jsx("h3",{children:"3. 定义两个任务：context 实现接力"}),e.jsxs("p",{children:["research_task 的 description 里有 ",e.jsx("code",{children:"{topic}"})," 占位符，会在 kickoff 时被 inputs 填充。write_task 的 ",e.jsx("code",{children:"context=[research_task]"})," 是这段代码的灵魂——它把研究员的产出作为上下文喂给撰稿人，于是撰稿人「看到」了要点再动笔。没有这一行，两个 Agent 就各干各的、互不相关。"]}),e.jsx(r,{lang:"python",title:"context 接力",code:h}),e.jsx("h3",{children:"4. 组队并启动：Process.sequential + kickoff"}),e.jsxs("p",{children:["Crew 把两个 Agent、两个 Task 聚合起来，",e.jsx("code",{children:"process=Process.sequential"})," 表示按 tasks 列表顺序执行：先 research_task，再 write_task。",e.jsx("code",{children:"kickoff()"})," 启动整支团队，inputs 里的 ",e.jsx("code",{children:"topic"})," 会填进 research_task 的占位符 ",e.jsx("code",{children:"{topic}"}),"。返回值是最后一个 Task 的产出，也就是那篇短文。"]}),e.jsx("h2",{children:"运行时它们怎么协作"}),e.jsx(l,{title:"一次 kickoff 的内部时序",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"① 填充"}),'：inputs 里的 topic = "什么是 AI Agent" 填进 research_task 的 description。']}),e.jsxs("li",{children:[e.jsx("strong",{children:"② 研究员上场"}),"：researcher 执行 research_task，按人设产出 3-5 条要点。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"③ 接力"}),"：因为 write_task 声明了 ",e.jsx("code",{children:"context=[research_task]"}),"，研究员的要点被注入撰稿人的上下文。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"④ 撰稿人上场"}),"：writer 基于要点写出约 300 字短文。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"⑤ 汇总返回"}),"：sequential 模式下，kickoff 返回最后一个 Task（write_task）的产出并打印。"]})]})}),e.jsx(t,{children:"sequential 模式 = 一条流水线：Task 按顺序跑，context 决定哪些产出向下游接力。把它想成「研究员把笔记递给撰稿人」就对了。"}),e.jsx("h2",{children:"扩展一：给 Agent 加一个工具"}),e.jsxs("p",{children:["现在两个 Agent 只会「想」，不会「做」。给研究员挂一个工具，它就能在推理过程中调用外部能力。用 ",e.jsx("code",{children:"@tool"})," 装饰一个普通函数即可，函数的 docstring 会作为工具说明被模型读取。"]}),e.jsx(r,{lang:"python",title:"自定义工具并挂到 Agent",code:d}),e.jsx("p",{children:"实际项目里更常见的是搜索工具、读文件工具或调内部 API 的工具——挂上去之后，研究员就能先检索再总结，而不只是凭模型记忆作答。"}),e.jsx("h2",{children:"扩展二：换成 hierarchical 模式"}),e.jsxs("p",{children:["如果任务分配不固定、需要一个「经理」临场调度，把 process 换成 ",e.jsx("code",{children:"Process.hierarchical"}),"。此时",e.jsx("strong",{children:"必须"}),"提供 ",e.jsx("code",{children:"manager_llm"}),"，由它来决定把哪个任务交给哪个 Agent 并整合结果。"]}),e.jsx(r,{lang:"python",title:"hierarchical 变体",code:p}),e.jsxs(i,{variant:"warn",title:"易踩坑",children:["切到 hierarchical 却忘了 ",e.jsx("code",{children:"manager_llm"}),"，会直接报错。sequential 不需要它，hierarchical 必须有。"]}),e.jsx("h2",{children:"扩展三：用 Flow 把 Crew 包起来"}),e.jsxs("p",{children:["当你需要确定性的流程骨架（先选主题、再跑团队、最后落库或发送），就用 Flow 包住 Crew。",e.jsx("code",{children:"@start"})," 标记入口，",e.jsx("code",{children:"@listen"})," 监听上一步完成后触发，state 在步骤间共享。创造性的活儿仍然交给自治的 Crew。"]}),e.jsx(r,{lang:"python",title:"Flow 包裹 Crew 的最小骨架",code:x}),e.jsx("h2",{children:"常见报错与调试"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"模型名忘了 openai/ 前缀"}),"：CrewAI 不知道走哪种协议，会报 provider/路由相关错误。改成 ",e.jsx("code",{children:"openai/qwen-plus"})," 即可。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"base_url 写错或漏写"}),"：请求会打到默认端点导致 401/连接失败。确认是 ",e.jsx("code",{children:"https://dashscope.aliyuncs.com/compatible-mode/v1"}),"，注意结尾的 ",e.jsx("code",{children:"/v1"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"API Key 没设"}),"：",e.jsx("code",{children:'os.environ["DASHSCOPE_API_KEY"]'})," 取不到会直接 KeyError。先 export 再运行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"context 没串上"}),"：撰稿人写出来的东西和研究要点没关系，多半是漏了 ",e.jsx("code",{children:"context=[research_task]"}),"，或写成了别的 Task。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"hierarchical 缺 manager_llm"}),"：层级模式必须显式提供经理模型，否则启动即报错。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"看不懂中间发生了什么"}),"：给 Agent 加 ",e.jsx("code",{children:"verbose=True"}),"，把思考与工具调用全打出来再排查。"]})]}),e.jsx(c,{points:["LLM 里 model 用 openai/qwen-plus（前缀必留）+ 百炼 base_url + 环境变量 key，即可接通国产模型。","两个 Agent 的差异完全来自 role/goal/backstory 人设，共用同一 llm 也能表现不同。","context=[research_task] 是接力的灵魂，决定上游产出是否流向下游。","Process.sequential 顺序执行并返回最后一个 Task 的产出；kickoff 的 inputs 填充 description 占位符。","扩展路径：@tool 给 Agent 加能力 → hierarchical + manager_llm 动态委派 → Flow 包裹 Crew 控制确定性流程。","高频报错集中在 openai/ 前缀、base_url、context 串联、hierarchical 缺 manager_llm。"]})]})}export{u as default};
