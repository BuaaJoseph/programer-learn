import{j as s}from"./index-bcw1GFOG.js";import{L as r,S as o}from"./Summary-CzbI5rAL.js";import{K as t}from"./KeyIdea-BfDRPFR2.js";import{C as l}from"./Callout-Kd5ZZGSH.js";import{C as e}from"./CodeBlock-DTDRATdO.js";import{E as i}from"./Example-C1jxmPta.js";const n=`// sandbox/path-jail.ts —— 把所有文件路径关进一个「围栏」目录
import path from 'node:path'

export class PathJail {
  constructor(private readonly root: string) {}   // 例如 /项目根 或 ~/.forge/workspace/<sid>

  /** 把工具传入的路径解析成真实绝对路径，并确保它没逃出围栏。 */
  resolve(p: string): string {
    const abs = path.resolve(this.root, p)
    const rel = path.relative(this.root, abs)
    if (rel === '' || rel.startsWith('..') || path.isAbsolute(rel)) {
      throw new SandboxError('EACCES', \`拒绝访问：路径逃出了沙箱围栏: \${p}\`)
    }
    return abs
  }
}`,a=`// sandbox/host-bash.ts —— host bash 默认禁用（对照 DeerFlow security.py）
export function isHostBashAllowed(cfg: Config): boolean {
  // 没有真正的容器隔离时，直接在主机跑任意 shell 风险太大 → 默认拒绝
  if (cfg.sandbox.kind !== 'host') return true        // 容器/远程沙箱本身隔离，放行
  return cfg.sandbox.allowHostBash === true           // host 模式必须显式开启
}

const HOST_BASH_DISABLED =
  'host bash 已禁用：当前是非隔离的 host 沙箱。请在 .forge 配置里设 ' +
  'sandbox.allowHostBash=true，或改用容器沙箱后再运行 shell 命令。'`,h=`// middleware/sandbox.ts —— 把文件/命令工具关进围栏，并遮蔽真实路径
export function sandboxMiddleware(cfg: SandboxConfig): Middleware {
  return {
    name: 'sandbox',
    beforeAgent(c) {
      // 懒创建：每个会话一个 jail（host 模式下就是项目根/工作区）
      c.scratch.jail = new PathJail(cfg.root)
    },
    async wrapTool(tu, next) {
      const jail = /* from scratch */ getJail(c)
      if (tu.name === 'bash' && !isHostBashAllowed(cfg)) {
        return toolError(HOST_BASH_DISABLED)
      }
      // 对文件类工具：把 input.path 收进围栏（逃逸即拒）
      if (FILE_TOOLS.has(tu.name) && typeof tu.input.path === 'string') {
        tu.input.path = jail.resolve(tu.input.path)   // 抛 EACCES 即被 errorHealing 转成 tool_result
      }
      const out = await next()
      return maskPaths(out, jail.root)                // 输出里把真实根目录遮蔽成相对路径
    },
  }
}`;function u(){return s.jsxs("article",{children:[s.jsxs(r,{children:["forge 的 ",s.jsx("code",{children:"write"})," / ",s.jsx("code",{children:"bash"})," 工具是直接在你主机上跑的——模型说删哪个文件就删哪个，说",s.jsx("code",{children:"rm -rf /"})," 它也照敲（第 3 卷的危险确认能拦一部分，但那是「问一句」而不是「关进围栏」）。 DeerFlow 在这件事上有一条非常清醒的判断：",s.jsx("strong",{children:"本地直接执行不是安全边界"}),"，所以它默认禁用 host bash，并把所有路径 关进虚拟围栏。这一章我们照搬这套思路，给 forge 的工具执行套上沙箱。"]}),s.jsx("h2",{children:"一、两种隔离强度"}),s.jsx("div",{style:{overflowX:"auto"},children:s.jsxs("table",{children:[s.jsx("thead",{children:s.jsxs("tr",{children:[s.jsx("th",{children:"沙箱模式"}),s.jsx("th",{children:"隔离强度"}),s.jsx("th",{children:"host bash"})]})}),s.jsxs("tbody",{children:[s.jsxs("tr",{children:[s.jsxs("td",{children:[s.jsx("code",{children:"host"}),"（默认，路径围栏）"]}),s.jsx("td",{children:"仅「路径作用域」，非内核隔离"}),s.jsxs("td",{children:[s.jsx("strong",{children:"默认禁用"}),"，需显式开启"]})]}),s.jsxs("tr",{children:[s.jsxs("td",{children:[s.jsx("code",{children:"container"}),"（docker 等）"]}),s.jsx("td",{children:"真正的内核隔离"}),s.jsx("td",{children:"放行（容器内随便跑）"})]})]})]})}),s.jsxs(t,{title:"DeerFlow 的核心论断",children:["DeerFlow 的 ",s.jsx("code",{children:"sandbox/security.py::is_host_bash_allowed"})," 写得很直白：本地 Provider 默认 ",s.jsx("strong",{children:"禁"})," host bash， 必须显式 ",s.jsx("code",{children:"allow_host_bash: true"})," 才放行；而容器化的 aio-sandbox 因为有真隔离，则直接放行。 理由是：本地沙箱只有「路径作用域」而非内核隔离，让模型在主机随意跑 shell 风险太大。我们给 forge 抄这条规则。"]}),s.jsx("h2",{children:"二、路径围栏：拒绝逃逸"}),s.jsx(e,{lang:"ts",title:"sandbox/path-jail.ts",code:n}),s.jsxs("p",{children:["关键就是 ",s.jsx("code",{children:"path.relative(root, abs)"})," 之后判断它",s.jsxs("strong",{children:["没有以 ",s.jsx("code",{children:".."})," 开头、也不是绝对路径"]}),"—— 任何想用 ",s.jsx("code",{children:"../../etc/passwd"})," 或软链接逃出围栏的尝试都会被拒。这对应 DeerFlow ",s.jsx("code",{children:"local_sandbox.py"})," 里用",s.jsx("code",{children:"resolved_path.relative_to(local_root)"})," 失败即抛 ",s.jsx("code",{children:"PermissionError"})," 的逃逸校验。"]}),s.jsx("h2",{children:"三、host bash 门控"}),s.jsx(e,{lang:"ts",title:"sandbox/host-bash.ts",code:a}),s.jsx("h2",{children:"四、写成一个中间件"}),s.jsxs("p",{children:["有了围栏和门控，把它们装进上一章的中间件框架——一个 ",s.jsx("code",{children:"wrapTool"})," 就够了："]}),s.jsx(e,{lang:"ts",title:"middleware/sandbox.ts",code:h}),s.jsxs("ul",{children:[s.jsxs("li",{children:[s.jsx("strong",{children:"bash 门控"}),"：host 模式未放行时，直接返回一条 ",s.jsx("code",{children:"tool_result"})," 错误，根本不执行。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"路径收口"}),"：文件类工具的 ",s.jsx("code",{children:"path"})," 参数先过 ",s.jsx("code",{children:"jail.resolve"}),"，逃逸就抛错（被 c4 的错误自愈中间件转成 tool_result）。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"路径遮蔽"}),"：工具输出里把真实根目录替换成相对路径，避免把主机目录结构泄露给模型——对应 DeerFlow 的 ",s.jsx("code",{children:"mask_local_paths_in_output"}),"。"]})]}),s.jsxs(l,{variant:"warn",title:"围栏不是万能的",children:["和 DeerFlow 一样要诚实：纯路径围栏挡得住「老实」的路径，挡不住 shell 里的变量展开、子 shell、编码绕过。所以它是",s.jsx("strong",{children:"纵深防御的一层，不是边界"}),"。真要跑不可信代码，得上容器（forge 的 ",s.jsx("code",{children:"container"})," 模式，可作为课后扩展）。 但即便只是路径围栏 + 默认禁 host bash，也已经远比「裸在主机上跑」安全。"]}),s.jsxs(i,{title:"和第 3 卷权限的关系",children:["权限（第 3 卷）回答「这个操作要不要问用户」；沙箱回答「这个操作能触达哪些文件、能不能跑 shell」。两者正交、叠加： 一次 ",s.jsx("code",{children:"write"})," 既要通过沙箱围栏（路径合法），又要通过权限策略（用户允许）。生产级 Agent 两道都要有。"]}),s.jsx(o,{points:["forge 的写/执行工具直接跑在主机上，缺乏隔离；DeerFlow 的清醒判断是「本地执行不是安全边界」，默认禁 host bash。","PathJail 用 path.relative 后判断不以 .. 开头、非绝对路径来拒绝逃逸，对应 DeerFlow 的 relative_to 逃逸校验。","isHostBashAllowed：host 模式默认禁 bash、需显式开启；容器模式放行——抄自 DeerFlow security.py。","把围栏+门控+路径遮蔽写成一个 sandbox 中间件（wrapTool）；它与权限正交：一个管「能触达哪」，一个管「要不要问」。"]})]})}export{u as default};
