import{r as d,j as e}from"./index-Bg-_WLwy.js";import{L as x,C as l,a as h,P as p,S as y}from"./Summary-CHYMl3nZ.js";import{K as g}from"./KeyIdea-DdhwDmIP.js";import{E as j}from"./Example-NeqGosrs.js";import{F as f}from"./Figure-CLskvOQH.js";const s=[{id:"wechat",name:"微信支付",desc:"调用微信 SDK 完成支付"},{id:"alipay",name:"支付宝",desc:"调用支付宝 SDK 完成支付"},{id:"card",name:"银行卡",desc:"走银联网关完成支付"}];function m(){const[i,o]=d.useState("alipay"),a=s.find(t=>t.id===i),c=e.jsxs(e.Fragment,{children:[s.map(t=>e.jsx("button",{className:`fig-btn ${i===t.id?"active":""}`,onClick:()=>o(t.id),children:t.name},t.id)),e.jsx("span",{className:"fig-note",children:"运行时切换策略，无 if-else"})]});return e.jsx(f,{caption:"策略模式：把一族可互换的算法各自封装成独立类，运行时按需选择，用多态消灭一长串 if-else。支付方式、促销规则、排序算法都适合。配合工厂/Map 注册可彻底去掉分支。",controls:c,children:e.jsxs("svg",{viewBox:"0 0 460 170",width:"460",role:"img","aria-label":"策略模式",children:[e.jsx("rect",{x:"20",y:"56",width:"100",height:"40",rx:"9",fill:"var(--accent)"}),e.jsx("text",{x:"70",y:"80",textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"12",fontWeight:"700",fill:"#ffffff",children:"PayContext"}),e.jsx("rect",{x:"170",y:"56",width:"110",height:"40",rx:"9",fill:"var(--violet)",fillOpacity:"0.14",stroke:"var(--violet)"}),e.jsx("text",{x:"225",y:"74",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"10",fontWeight:"700",fill:"var(--violet)",children:"PayStrategy"}),e.jsx("text",{x:"225",y:"88",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:"var(--ink-soft)",children:"接口"}),e.jsx("line",{x1:"120",y1:"76",x2:"170",y2:"76",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#st-a)"}),s.map((t,n)=>{const r=t.id===i;return e.jsxs("g",{children:[e.jsx("rect",{x:"330",y:20+n*44,width:"110",height:"34",rx:"7",fill:r?"var(--green)":"var(--green-soft)",stroke:"var(--green-line)",strokeWidth:r?2:1}),e.jsx("text",{x:"385",y:41+n*44,textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"11",fontWeight:r?"700":"400",fill:r?"#ffffff":"var(--green)",children:t.name}),e.jsx("line",{x1:"280",y1:"76",x2:"330",y2:37+n*44,stroke:r?"var(--green)":"var(--border-strong)",strokeWidth:r?2:1,strokeDasharray:r?"0":"4 3",markerEnd:"url(#st-a)"})]},t.id)}),e.jsx("defs",{children:e.jsx("marker",{id:"st-a",markerWidth:"8",markerHeight:"8",refX:"5",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L5,3 L0,6 Z",fill:"var(--ink-faint)"})})}),e.jsx("rect",{x:"20",y:"124",width:"420",height:"40",rx:"8",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsxs("text",{x:"32",y:"148",fontFamily:"var(--sans)",fontSize:"12",fill:"var(--ink)",children:["当前策略：",e.jsx("tspan",{fontWeight:"700",fill:"var(--accent-strong)",children:a.name})," — ",a.desc,"（换策略只需注入不同实现，Context 代码不变）"]})]})})}const u=`// 反例：所有分支挤在一个方法里，每加一种支付方式就要改这里
public class PayService {

    public void pay(String type, long amount) {
        if ("alipay".equals(type)) {
            // 调支付宝 SDK
            System.out.println("支付宝支付 " + amount);
        } else if ("wechat".equals(type)) {
            // 调微信 SDK
            System.out.println("微信支付 " + amount);
        } else if ("unionpay".equals(type)) {
            // 调银联 SDK
            System.out.println("银联支付 " + amount);
        } else {
            throw new IllegalArgumentException("不支持的支付方式: " + type);
        }
    }
}`,S=`// 1. 策略接口：把一族可互换的算法抽象成同一个契约
public interface PayStrategy {
    String type();              // 该策略对应的支付方式标识
    void pay(long amount);      // 真正的算法
}

// 2. 具体策略：每种支付方式各自一个类，互不干扰
public class AlipayStrategy implements PayStrategy {
    public String type() { return "alipay"; }
    public void pay(long amount) {
        System.out.println("支付宝支付 " + amount);
    }
}

public class WechatStrategy implements PayStrategy {
    public String type() { return "wechat"; }
    public void pay(long amount) {
        System.out.println("微信支付 " + amount);
    }
}

// 3. 上下文 Context：用 Map 注册并路由，彻底消灭 if-else
public class PayService {

    private final Map<String, PayStrategy> registry = new HashMap<>();

    // 构造时把所有策略注入进来（Spring 里可直接注入 List 或 Map）
    public PayService(List<PayStrategy> strategies) {
        for (PayStrategy s : strategies) {
            registry.put(s.type(), s);
        }
    }

    public void pay(String type, long amount) {
        PayStrategy strategy = registry.get(type);
        if (strategy == null) {
            throw new IllegalArgumentException("不支持的支付方式: " + type);
        }
        strategy.pay(amount);   // 多态调用，新增支付方式无需改这里
    }
}`;function w(){return e.jsxs(e.Fragment,{children:[e.jsx(x,{children:e.jsxs("p",{children:["一个支付方法里塞满了「如果是支付宝就……否则如果是微信就……」，每接入一种新渠道就要回来改这个方法， 越改越长、越改越怕。策略模式（",e.jsx("em",{children:"Strategy"}),"）做的事只有一句话：把这一族「可以互相替换的算法」 各自封装成独立的类，运行时再挑一个用，从而用",e.jsx("strong",{children:"多态"}),"替代成片的 if-else。"]})}),e.jsx("h2",{children:"它到底解决什么问题"}),e.jsxs("p",{children:["当一段逻辑会随「类型」分出很多分支，而每个分支内部又是一套相对独立的算法时，把它们写在一起就埋了三颗雷： 方法越来越臃肿、改一个分支可能误伤别的分支、新增分支必须修改老代码（违反",e.jsx("em",{children:"开闭原则"}),"）。 策略模式把每个分支抽成一个类，让它们实现同一个接口，调用方只面向接口编程，至于具体用哪个，留到运行时再决定。"]}),e.jsx("h3",{children:"三个角色"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"策略接口（Strategy）"}),"：定义这一族算法的统一契约，比如",e.jsx("code",{children:"pay(amount)"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"具体策略（Concrete Strategy）"}),"：接口的各个实现，一种算法一个类，比如支付宝、微信、银联各一个。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"上下文（Context）"}),"：持有一个策略引用，对外提供入口，把实际工作委托给当前选中的策略。"]})]}),e.jsxs(j,{title:"把 if-else 改成策略",children:[e.jsx("p",{children:"先看一段典型的「随类型分支」的代码，它的问题不在于现在不能跑，而在于每次扩展都得动它："}),e.jsx(l,{lang:"java",title:"反例：if-else 堆叠",code:u}),e.jsx("p",{children:"注意这里的坏味道：方法承担了「判断用哪种」和「具体怎么付」两件事，分支越多耦合越重。 策略模式的思路就是把后者拆出去，让前者退化成一次简单的查表。"})]}),e.jsx(m,{}),e.jsx(g,{title:"如何彻底去掉 if-else：用 Map 路由",children:e.jsxs("p",{children:["很多人以为「策略模式 = 把分支拆成类」，于是写了一堆策略类，却仍在 Context 里用 if-else 决定 new 哪个， 等于白拆。真正消灭 if-else 的关键是",e.jsx("strong",{children:"用 Map 把「类型」映射到「策略实例」"}),"：调用时",e.jsx("code",{children:"registry.get(type)"})," 直接拿到对象再多态调用。在 Spring 里更省事—— 把策略接口的所有实现声明为 Bean，直接注入 ",e.jsx("code",{children:"List<PayStrategy>"})," 或",e.jsx("code",{children:"Map<String, PayStrategy>"}),"，容器会自动收集，新增策略只要加一个 Bean，主流程一行不改。"]})}),e.jsx(h,{variant:"warn",title:"别和状态模式搞混",children:e.jsxs("p",{children:["策略模式和状态模式（",e.jsx("em",{children:"State"}),"）结构几乎一样，都是「接口 + 多个实现 + 上下文委托」，区别在",e.jsx("strong",{children:"意图"}),"： 策略模式里各算法是平等、互斥的，由",e.jsx("strong",{children:"外部"}),"选择一个，彼此之间不会互相切换； 状态模式里各状态有先后流转关系，是",e.jsx("strong",{children:"状态自己"}),"决定下一步切到哪个状态（如订单：待支付 → 已支付 → 已发货）。 一句话：策略是「让你挑一个」，状态是「它自己会变」。"]})}),e.jsx("h2",{children:"常见应用与「面试怎么答」"}),e.jsxs("p",{children:["策略模式在真实代码里随处可见：",e.jsx("strong",{children:"多种支付方式"}),"、",e.jsx("strong",{children:"多种促销规则"}),"（满减、打折、赠品）、",e.jsx("strong",{children:"不同下单渠道"}),"（App、小程序、第三方），以及最常被忽视的—— JDK 里的 ",e.jsx("code",{children:"Comparator"}),"，给 ",e.jsx("code",{children:"Collections.sort"})," 传不同的比较器，本质就是传入不同的排序策略。"]}),e.jsxs("p",{children:["面试被问到时，建议这样组织回答：先一句话点意图（封装一族可互换的算法，运行时选择，用多态替代 if-else）， 再说三个角色，接着主动抛出加分项——「我会用 Map 或 Spring 把策略注册起来，从而连选择分支的 if-else 也一起消灭」， 最后用「和状态模式的区别」收尾，体现你能区分相似模式。能举出 ",e.jsx("code",{children:"Comparator"})," 这种 JDK 例子会更稳。"]}),e.jsxs(p,{title:"用 Map 注册路由实现一族支付策略",children:[e.jsxs("p",{children:["自己动手写一遍：定义 ",e.jsx("code",{children:"PayStrategy"})," 接口，给出至少两个具体策略，再在 Context 里用",e.jsx("code",{children:"Map"})," 注册并路由。重点体会：新增一种支付方式时，你只需要加一个类、注册一次，",e.jsx("code",{children:"pay"})," 方法完全不用动。"]}),e.jsx(l,{lang:"java",title:"StrategyDemo.java",code:S}),e.jsxs("p",{children:["进阶练习：把构造里的手动注册改成 Spring 风格——给每个策略加 ",e.jsx("code",{children:"@Component"}),"， Context 里直接注入 ",e.jsx("code",{children:"List<PayStrategy>"})," 后在构造里转成 Map，体会容器自动收集的爽快。"]})]}),e.jsx(y,{points:["策略模式：把一族可互换的算法各自封装成类，运行时选择其一，用多态替代成片的 if-else。","三个角色：策略接口（统一契约）、具体策略（一种算法一个类）、上下文 Context（持有并委托给当前策略）。","彻底去掉 if-else 的关键是用 Map<类型, 策略> 路由，或让 Spring 把策略注入成 List/Map 自动收集。","典型应用：支付方式、促销规则、不同渠道，以及 JDK 的 Comparator 排序。","与状态模式结构相同但意图不同：策略是外部挑一个且互斥，状态是自身按流转规则切换。","扩展时只加新类、注册一次，主流程不改，天然符合开闭原则。"]})]})}export{w as default};
