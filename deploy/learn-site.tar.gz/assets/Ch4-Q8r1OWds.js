import{j as e}from"./index-DL563RIm.js";import{L as n,S as o}from"./Summary-BrgLcNDp.js";import{K as r}from"./KeyIdea-exK4GrdK.js";import{C as s}from"./Callout-B-8nslAm.js";import{C as t}from"./CodeBlock-DkVyd3P6.js";import{E as i}from"./Example-HxOmIesu.js";const d='"test": "node --import tsx --test test/*.test.ts"',c=`import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { readTool } from '../src/tools/read.js'
import { writeTool } from '../src/tools/write.js'
import { editTool } from '../src/tools/edit.js'

// 工具单测：在临时目录里跑真实的文件读写，验证行为契约。
function tmp(): string {
  return mkdtempSync(join(tmpdir(), 'forge-'))
}

test('write 后 read 能读回内容', async () => {
  const cwd = tmp()
  await writeTool.execute({ path: 'a.txt', content: 'hello' }, { cwd })
  const r = await readTool.execute({ path: 'a.txt' }, { cwd })
  assert.match(r.output, /hello/)
})

test('edit 要求 oldString 唯一：多处命中应报错', async () => {
  const cwd = tmp()
  writeFileSync(join(cwd, 'a.txt'), 'x\\nx\\n')
  const r = await editTool.execute({ path: 'a.txt', oldString: 'x', newString: 'y' }, { cwd })
  assert.equal(r.isError, true)
})

test('edit 唯一命中时正确替换', async () => {
  const cwd = tmp()
  writeFileSync(join(cwd, 'a.txt'), 'foo bar baz')
  const r = await editTool.execute({ path: 'a.txt', oldString: 'bar', newString: 'BAR' }, { cwd })
  assert.notEqual(r.isError, true)
  assert.equal(readFileSync(join(cwd, 'a.txt'), 'utf8'), 'foo BAR baz')
})

test('read 不存在的文件返回错误结果而非抛异常', async () => {
  const cwd = tmp()
  const r = await readTool.execute({ path: 'nope.txt' }, { cwd })
  assert.equal(r.isError, true)
})`,l=`import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Agent } from '../src/agent.js'
import type { Provider, CompleteParams } from '../src/provider/types.js'
import type { AssistantTurn } from '../src/types.js'
import { writeTool } from '../src/tools/write.js'

// 假 Provider：按脚本依次返回预设回合，完全离线——这样能在没有网络/密钥的情况下测主循环。
class FakeProvider implements Provider {
  readonly model = 'fake'
  readonly contextWindow = 100_000
  private i = 0
  constructor(private turns: AssistantTurn[]) {}
  async complete(_p: CompleteParams): Promise<AssistantTurn> {
    return this.turns[this.i++]
  }
  async countTokens(): Promise<number> {
    return 0
  }
}

test('主循环：纯文本回合即停机', async () => {
  const provider = new FakeProvider([
    { content: [{ type: 'text', text: '你好' }], stopReason: 'end_turn', usage: { inputTokens: 1, outputTokens: 1 } },
  ])
  const agent = new Agent({ provider, tools: [], system: '', cwd: process.cwd() })
  const out = await agent.runTurn('hi')
  assert.equal(out, '你好')
})

test('主循环：执行工具后再停机', async () => {
  const cwd = mkdtempSync(join(tmpdir(), 'forge-'))
  const provider = new FakeProvider([
    {
      content: [{ type: 'tool_use', id: 't1', name: 'write', input: { path: 'a.txt', content: 'hi' } }],
      stopReason: 'tool_use',
      usage: { inputTokens: 1, outputTokens: 1 },
    },
    { content: [{ type: 'text', text: '写好了' }], stopReason: 'end_turn', usage: { inputTokens: 1, outputTokens: 1 } },
  ])
  const agent = new Agent({
    provider,
    tools: [writeTool],
    system: '',
    cwd,
    // 测试里放行所有操作，避免卡在确认。
    permissions: { decide: () => ({ decision: 'allow', reason: '' }) },
  })
  const out = await agent.runTurn('写个文件')
  assert.equal(out, '写好了')
})

test('权限为 ask 且无 confirm 时拒绝执行', async () => {
  const cwd = mkdtempSync(join(tmpdir(), 'forge-'))
  const provider = new FakeProvider([
    {
      content: [{ type: 'tool_use', id: 't1', name: 'write', input: { path: 'a.txt', content: 'hi' } }],
      stopReason: 'tool_use',
      usage: { inputTokens: 1, outputTokens: 1 },
    },
    { content: [{ type: 'text', text: '没写成' }], stopReason: 'end_turn', usage: { inputTokens: 1, outputTokens: 1 } },
  ])
  const agent = new Agent({
    provider,
    tools: [writeTool],
    system: '',
    cwd,
    permissions: { decide: () => ({ decision: 'ask', reason: '写文件' }) },
    // 不提供 confirm：ask 应被视为拒绝
  })
  const out = await agent.runTurn('写个文件')
  assert.equal(out, '没写成')
})`,a="npm test",x=`> forge@0.7.0 test
> node --import tsx --test test/*.test.ts

✔ write 后 read 能读回内容 (3.21ms)
✔ edit 要求 oldString 唯一：多处命中应报错 (1.08ms)
✔ edit 唯一命中时正确替换 (1.44ms)
✔ read 不存在的文件返回错误结果而非抛异常 (0.92ms)
✔ 主循环：纯文本回合即停机 (2.10ms)
✔ 主循环：执行工具后再停机 (3.67ms)
✔ 权限为 ask 且无 confirm 时拒绝执行 (2.55ms)

ℹ tests 7
ℹ pass 7
ℹ fail 0
ℹ cancelled 0
ℹ duration_ms 142.3`,h=`import { test, snapshot } from 'node:test'
import { renderToolLine } from '../src/render.js'

// 快照测试：把"渲染出来长啥样"钉死。改动若让输出变了，diff 会立刻报出来。
test('工具调用行渲染快照', (t) => {
  const line = renderToolLine({ name: 'edit', input: { path: 'src/a.ts' } })
  // 第一次跑生成快照文件；之后跑比对，不一致即 fail
  t.assert.snapshot(line)
})`,j=`// 属性测试：不写死具体例子，而是断言"对任意输入都成立的不变量"
test('edit 替换后，oldString 不再出现且长度变化符合预期', () => {
  for (const [text, oldS, newS] of cases()) {
    const cwd = tmp()
    writeFileSync(join(cwd, 'a.txt'), text)
    const before = (text.match(new RegExp(escape(oldS), 'g')) ?? []).length
    if (before !== 1) continue // 只测唯一命中
    editTool.execute({ path: 'a.txt', oldString: oldS, newString: newS }, { cwd })
    const after = readFileSync(join(cwd, 'a.txt'), 'utf8')
    // 不变量：恰好替换一处，长度变化 = newS.length - oldS.length
    assert.equal(after.length, text.length + (newS.length - oldS.length))
  }
})`,p=`name: ci
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '22' }
      - run: npm ci
      - run: npm test
      # 注意：没有任何 API key——假 Provider 让测试完全离线，CI 才能稳定跑`;function k(){return e.jsxs("article",{children:[e.jsx(n,{children:"没有测试的 Agent，你不敢重构、不敢发布——因为它会自己改代码、跑命令，一处退化就可能闹出大事。 但好消息是：forge 的核心是确定性的。主循环、权限闸门、工具行为，给定输入就有确定输出， 完全可以写成自动化测试。这一章我们用 Node 内置的测试运行器，给 Agent 织一张安全网。"}),e.jsx("h2",{children:"为什么 Agent 一定要测"}),e.jsx("p",{children:"Agent 的回归风险比普通程序高一截。它会读写你的文件、执行 shell 命令、修改源码—— 一个工具行为悄悄变了，可能要等到它把某个文件改坏了你才发现。手动验证又特别累： 每次改动都要起一个真实会话，喂一段对话，盯着它一步步走完。这种验证既慢又不可复现。"}),e.jsx("p",{children:"关键在于看清哪些部分是确定性的。模型说什么我们控制不了，但模型之外的那一圈—— 主循环什么时候停机、权限怎么裁决、工具读写出什么结果——全都是普通的 TypeScript 逻辑， 给定输入必有确定输出。这部分不测，等于把最该守住的地基交给运气。"}),e.jsx(r,{children:"能测的部分一定要测。主循环、权限、工具是确定性的——别让它们悄悄退化。 不确定的（模型具体吐什么字）才交给运行时，确定的（流程与行为）交给测试。"}),e.jsx("h2",{children:"Agent 测试的根本难题：非确定性"}),e.jsxs("p",{children:["在动手前必须把这个坎讲透，否则你会写出一堆「时灵时不灵」的脆弱测试。普通函数测试的黄金假设是",e.jsx("strong",{children:"「同输入同输出」"}),"，可 LLM 偏偏违背它：同一句 prompt 调两次，措辞会不同、有时甚至连「调不调工具」 都不一样。这意味着——"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"不能断言模型说了什么"}),"：",e.jsx("code",{children:"assert.equal(out, '已修改 port')"})," 这种断言注定时不时挂，因为措辞本就会变。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"不能在 CI 里真调模型"}),"：要联网、要密钥、要花钱、还慢，而且因为输出不稳定，挂了你都分不清是「真退化」还是「模型今天换了个说法」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"不能依赖外部环境"}),"：网络抖一下、限流一下，测试就红，CI 根本没法当门禁用。"]})]}),e.jsxs("p",{children:["破解之道是把「确定的」和「不确定的」",e.jsx("strong",{children:"切开"}),"：模型这块用",e.jsx("strong",{children:"假 Provider"}),"替换成可控脚本， 于是整条主循环重新变回「同输入同输出」的确定性系统；而模型本身的质量，交给另一类专门的「评测（eval）」去做， 不混进单元测试。这条切割线是整章的核心思想。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"层次"}),e.jsx("th",{children:"测什么"}),e.jsx("th",{children:"用什么"}),e.jsx("th",{children:"进 CI 门禁吗"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"单元/集成"}),e.jsx("td",{children:"主循环、权限、工具（确定性）"}),e.jsx("td",{children:"假 Provider + node:test"}),e.jsx("td",{children:"是，每次必跑"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"快照"}),e.jsx("td",{children:"渲染输出格式不退化"}),e.jsx("td",{children:"node:test 快照"}),e.jsx("td",{children:"是"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"评测 eval"}),e.jsx("td",{children:"真实模型完成任务的质量"}),e.jsx("td",{children:"真 Provider + 评分"}),e.jsx("td",{children:"否，单独跑、看趋势"})]})]})]}),e.jsx("h2",{children:"工具怎么测：在临时目录里跑真实读写"}),e.jsxs("p",{children:["工具是 Agent 最贴近副作用的部分，恰恰也最好测：在一个临时目录里跑真实的文件读写， 然后断言行为符合契约。我们不引第三方测试框架，直接用 Node 自带的"," ",e.jsx("code",{children:"node:test"})," + ",e.jsx("code",{children:"node:assert"}),"，再配 ",e.jsx("code",{children:"tsx"})," 直接跑 TypeScript。 先看 ",e.jsx("code",{children:"package.json"})," 里的 test 脚本："]}),e.jsx(t,{lang:"json",title:"package.json（test 脚本）",code:d}),e.jsxs("p",{children:["这一行有两个关键开关：",e.jsx("code",{children:"node --import tsx"})," 让测试运行器在加载时即时编译 TS， 于是测试文件可以直接写 ",e.jsx("code",{children:".ts"}),"、直接 import 项目里的 TS 模块；",e.jsx("code",{children:"--test"})," 是 Node 内置的测试运行器，会自动发现并跑匹配到的文件。 零额外测试框架，零配置文件——这正是我们想要的轻量。"]}),e.jsxs(s,{variant:"note",children:[e.jsx("strong",{children:"为什么用真实文件而不是 mock fs？"}),"因为工具的价值恰恰在「它真能正确操作文件系统」。mock 掉 fs， 你测的就只是「我以为 fs 怎么工作」，而临时目录里跑真实读写测的是「fs 真的怎么工作」。代价只是几毫秒的磁盘 IO， 换来的是对真实行为的信心——这笔买卖非常划算。临时目录天然隔离、跑完即弃，不污染仓库，所以「真实」并不等于「危险」。"]}),e.jsx(t,{lang:"ts",title:"test/tools.test.ts",code:c}),e.jsx("p",{children:"逐段拆开看它在测什么："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"tmp()"})," 用 ",e.jsx("code",{children:"mkdtempSync"})," 建一个独立的临时目录。每个测试在自己的目录里跑， 副作用互不干扰，跑完也不会污染仓库。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"写读往返"}),"：先 ",e.jsx("code",{children:"writeTool"})," 写入，再 ",e.jsx("code",{children:"readTool"})," 读回， 断言内容能匹配上。这是工具最基本的契约。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"edit 唯一性约束"}),"：当 ",e.jsx("code",{children:"oldString"})," 在文件里命中多处时， edit 必须报错而不是乱改——我们写入 ",e.jsx("code",{children:"x\\nx\\n"})," 制造两处命中，断言"," ",e.jsx("code",{children:"r.isError === true"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"edit 正确替换"}),"：唯一命中时，替换结果必须精确，读回文件断言成"," ",e.jsx("code",{children:"foo BAR baz"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"失败不抛异常"}),"：读一个不存在的文件，工具应返回 ",e.jsx("code",{children:"isError"})," 结果， 而不是抛出异常崩掉主循环——这正是卷 1 给所有工具定下的契约：失败要变成可喂回模型的结果。"]})]}),e.jsxs(s,{variant:"tip",children:[e.jsx("strong",{children:"工程经验：优先测边界与错误路径。"}),"「写了能读回」这种 happy path 当然要测，但真正容易退化、 真正会出事的是",e.jsx("strong",{children:"边界"}),"：多处命中、文件不存在、空内容、路径越界。上面四个测里有三个在测错误/边界—— 这个比例是对的。一条朴素的规律：bug 几乎都藏在 ",e.jsx("code",{children:"if/else"})," 的那个「else」里。"]}),e.jsx("h2",{children:"主循环集成测试：关键是「假 Provider」"}),e.jsxs("p",{children:["测主循环就麻烦在 Provider 身上：真实 Provider 要联网、要密钥、返回还不确定。 把这些塞进测试，结果就是又慢又脆又跑不动 CI。 办法是给主循环喂一个",e.jsx("strong",{children:"假 Provider"}),"——它实现同样的接口，但不联网， 而是按一份预先写好的脚本，一轮一轮返回我们设计好的回合。这样整条主循环完全离线、完全确定。"]}),e.jsx(t,{lang:"ts",title:"test/agent.test.ts",code:l}),e.jsx("p",{children:"逐段讲解："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"FakeProvider"})," 实现了 ",e.jsx("code",{children:"Provider"})," 接口的四样东西：",e.jsx("code",{children:"model"}),"、",e.jsx("code",{children:"contextWindow"}),"、",e.jsx("code",{children:"complete"}),"、",e.jsx("code",{children:"countTokens"}),"—— 正好呼应卷 6 定下的抽象。",e.jsx("code",{children:"complete"})," 不联网，而是从构造时传入的数组里 按下标依次取出下一回合。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"纯文本回合即停"}),"：脚本只有一个 ",e.jsx("code",{children:"end_turn"})," 回合， 断言主循环看到纯文本就停机，把文本作为结果返回。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"执行工具后再停"}),"：脚本是「先 tool_use 让它写文件，再 end_turn」两回合， 权限全放行，断言主循环执行了工具、喂回结果、最后停在第二回合的文本上。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"ask 无 confirm 则拒绝"}),"：权限裁决返回 ",e.jsx("code",{children:"ask"})," 但没提供 confirm 回调， 主循环应当把它当作拒绝、不执行工具，最终走到「没写成」。"]})]}),e.jsxs("p",{children:["这三个测试正好覆盖了主循环的三大核心行为：",e.jsx("strong",{children:"停机条件、工具执行、权限闸门"}),"。 而能用一个几十行的假 Provider 就把整条主循环测起来，全靠卷 1 / 卷 6 那层 Provider 抽象—— 把「怎么拿到下一回合」抽象成接口，测试时就能换成离线脚本。这就是好设计在测试阶段的回报。"]}),e.jsxs(s,{variant:"note",children:[e.jsx("strong",{children:"假 Provider 为什么比「mock 库打桩」更好？"}),"它是一个真实实现了接口的类，类型系统会逼着它和真 Provider 保持同一个契约——接口一改，假 Provider 编译不过，你立刻知道要同步。而 mock 库往往用字符串/任意对象打桩，接口漂移了 它还能「跑过」，给你虚假的安全感。",e.jsx("strong",{children:"用真类型约束的假实现 > 无类型的 mock"}),"，这是 TS 项目里很值钱的一条经验。"]}),e.jsx("h2",{children:"快照测试：把「长啥样」钉死"}),e.jsxs("p",{children:["有些东西不好用 ",e.jsx("code",{children:"assert.equal"})," 一条条写——比如终端渲染出来的那一行带颜色、带截断的输出。 手写期望值又臭又长，还容易写错。这时用",e.jsx("strong",{children:"快照测试"}),"：第一次跑把输出录成快照文件，之后每次跑拿当前输出 和快照比，",e.jsx("strong",{children:"一旦 diff 就报警"}),"。Node 22+ 的 ",e.jsx("code",{children:"node:test"})," 内置了快照能力："]}),e.jsx(t,{lang:"ts",title:"test/render.test.ts（快照）",code:h}),e.jsxs("p",{children:["快照的价值在于「",e.jsx("strong",{children:"意外变更会被立刻揪出来"}),"」：你本来只想改个工具逻辑，结果手滑改了渲染格式， 快照测试当场红给你看。它特别适合守「输出格式」这种「不该变、变了往往是 bug」的东西。"]}),e.jsxs(s,{variant:"warn",children:[e.jsxs("strong",{children:["快照的常见误区：无脑 ",e.jsx("code",{children:"--update"}),"。"]}),"快照红了，正确动作是",e.jsx("strong",{children:"看 diff、判断这变化是不是预期的"}),"—— 是预期的才更新快照，不是预期的就去修代码。养成「红了就 update」的肌肉记忆，快照测试就退化成了橡皮图章，等于没测。 同理，别给快照里塞时间戳、随机 id 这类",e.jsx("strong",{children:"本就会变"}),"的内容，否则它永远红，最后只能被无视。"]}),e.jsx("h2",{children:"属性测试：与其举例，不如断言不变量"}),e.jsxs("p",{children:["逐个写例子总有漏的角落。另一种思路是",e.jsx("strong",{children:"属性测试"}),"：不写死「输入 A 得输出 B」，而是断言 「",e.jsx("strong",{children:"对任意合法输入，某个不变量恒成立"}),"」，然后喂一堆随机/构造的输入去撞它。比如 edit 工具有个天然不变量： 唯一命中替换后，文件长度变化必然等于 ",e.jsx("code",{children:"newString.length - oldString.length"}),"："]}),e.jsx(t,{lang:"ts",title:"test/edit.property.test.ts（属性测试，示意）",code:j}),e.jsx("p",{children:"属性测试常能逼出你举例时根本想不到的边界（空串、超长、含特殊字符）。它不取代举例测试，而是补在它旁边—— 举例测试讲清「典型行为」，属性测试守住「普适规律」。"}),e.jsxs(i,{title:"跑一次测试",children:[e.jsx("p",{children:"一条命令把全部测试跑起来："}),e.jsx(t,{lang:"bash",code:a}),e.jsx("p",{children:"输出大致长这样，最后几行是汇总，7 个测试全绿："}),e.jsx(t,{lang:"text",code:x})]}),e.jsx("h2",{children:"接进 CI：每次推送自动把关"}),e.jsxs("p",{children:["测试的价值在「自动、每次、挡在合并前」。把 ",e.jsx("code",{children:"npm test"})," 接进 CI，每次 push / PR 自动跑， 红了就别想合。最关键的一点前面已经埋好了——",e.jsx("strong",{children:"因为用了假 Provider，整套测试完全离线，CI 里不需要任何 API key"}),"， 这才让 CI 能稳定、免费、秒级地跑："]}),e.jsx(t,{lang:"yaml",title:".github/workflows/ci.yml",code:p}),e.jsxs("p",{children:["留意 ",e.jsx("code",{children:"npm ci"}),"（而非 ",e.jsx("code",{children:"npm install"}),"）：它严格按 lockfile 装、不改 lockfile，保证 CI 装的依赖和你本地一字不差—— 可复现是 CI 的命根子。再强调一遍那条注释：",e.jsx("strong",{children:"没有任何密钥"}),"，正是「确定性切割」带来的红利。"]}),e.jsx(s,{variant:"tip",children:"测试策略：确定性的核心都要测——工具、主循环、权限裁决、压缩触发条件。 但不要去断言「模型说了什么」（那是不确定的），而要断言「行为/流程对不对」： 该停的时候停没停、该执行的工具执行没执行、该拦的操作拦没拦。盯流程，不盯文案。"}),e.jsxs(s,{variant:"note",children:["有了这张网，卷 8 发布前就能用 ",e.jsx("code",{children:"npm test"})," 一键把关，不让退化溜进 release。 它也为毕业项目「用 forge 改造 forge」兜底：让 Agent 改完代码，紧接着跑一遍测试， 立刻知道有没有把东西弄坏——这正是敢让 Agent 动自己代码的底气。"]}),e.jsx("h2",{children:"卷 7 小结"}),e.jsxs("p",{children:["这一卷我们把 forge 从「能跑」推向「敢交付」，靠的是四件套：",e.jsx("strong",{children:"会话持久化"}),"让对话可中断可恢复；",e.jsx("strong",{children:"成本与延迟"}),"让每次调用心里有数；",e.jsx("strong",{children:"可观测性"}),"让出问题时有迹可循；",e.jsx("strong",{children:"测试"}),"让重构和发布有安全网。 这四样都不改变 Agent「能做什么」，但决定了它能不能放心地交到别人手里。"]}),e.jsx(r,{children:"会话持久化 + 成本延迟 + 可观测性 + 测试，这四件套是把工具从「能跑的玩具」 推到「敢交付的产品」的那道坎。下一卷，我们给 forge 打包、发布。"}),e.jsx(o,{points:["Agent 回归风险高（会改代码、跑命令），但核心逻辑是确定性的，必须测。","根本难题是非确定性：不能断言模型措辞、不能在 CI 真调模型；解法是切开确定与不确定，模型用假 Provider 替换，质量交给单独的 eval。","工具单测：用 node:test + node:assert + tsx，在临时目录里跑真实读写（不 mock fs），断言写读往返、edit 唯一性、失败返回 isError 而非抛异常等契约，优先测边界与错误路径。","test 脚本 node --import tsx --test test/*.test.ts，零额外测试框架。","主循环集成测试靠「假 Provider」：实现 Provider 接口、按脚本离线返回回合，覆盖停机、工具执行、权限闸门三大行为；类型约束的假实现优于无类型 mock。","快照测试钉死渲染输出格式，红了要看 diff 别无脑 update；属性测试断言不变量、逼出举例想不到的边界。","接 CI（npm ci + npm test）每次 push 自动把关；因假 Provider 离线，CI 无需任何 API key。","卷 7 四件套（持久化 + 成本延迟 + 可观测性 + 测试）把 forge 推到「敢交付」，下一卷打包发布。"]})]})}export{k as default};
