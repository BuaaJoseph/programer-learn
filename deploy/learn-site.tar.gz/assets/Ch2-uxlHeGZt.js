import{j as e}from"./index-qtIRnDEm.js";import{L as i,S as d}from"./Summary-D7M9FdYM.js";import{K as r}from"./KeyIdea-C5mX38F7.js";import{C as t}from"./Callout-Bvq_rfqV.js";import{C as s}from"./CodeBlock-DsDQiuPI.js";import{E as n}from"./Example-Ba1iSJHN.js";import{P as c}from"./Practice-YnZYrUAA.js";import{P as l}from"./PyRunner-Bx3kKzEt.js";const h=`s = "Hello, Python"

# 索引：第 0 个字符、最后一个字符
print(s[0], s[-1])

# 切片：取一段
print(s[0:5])     # Hello
print(s[7:])      # Python

# 常用方法
print(s.upper())          # 全大写
print(s.replace("Hello", "你好"))
print(len(s), "个字符")

# f-string 拼接
name = "小明"
print(f"{name}说：{s}")`,o=`a = '单引号字符串'
b = "双引号字符串"
c = """三引号
可以跨越
多行"""
print(a)
print(b)
print(c)`,x=`单引号字符串
双引号字符串
三引号
可以跨越
多行`,j=`s = "Python"
print(s[0])    # 第一个字符，下标从 0 开始
print(s[1])    # 第二个字符
print(s[-1])   # 倒数第一个字符
print(len(s))  # 字符串长度（几个字符）`,p=`P
y
n
6`,a=`s = "Python"
print(s[0:3])   # 下标 0、1、2，不含 3
print(s[2:])    # 从下标 2 到结尾
print(s[:4])    # 从开头到下标 3
print(s[::2])   # 每隔一个取一个`,f=`Pyt
thon
Pyth
Pto`,g=`first = "Hello"
second = "World"
print(first + " " + second)   # 用 + 拼接
print("ha" * 3)               # 用 * 重复`,m=`Hello World
hahaha`,y=`s = "  Hello Python  "
print(s.upper())          # 全部大写
print(s.lower())          # 全部小写
print(s.strip())          # 去掉两端空白
print(s.replace("o", "0"))# 替换
print("a,b,c".split(",")) # 按逗号切成列表
print("Python".find("th"))# 找子串的起始下标，找不到返回 -1
print(len("你好"))         # 长度`,u=`  HELLO PYTHON
  hello python
Hello Python
  Hell0 Pyth0n
['a', 'b', 'c']
2
2`,P=`name = "小明"
age = 18
score = 92.5
print(f"我叫{name}，今年{age}岁")
print(f"分数：{score:.1f}")     # 保留 1 位小数
print(f"明年{age + 1}岁")        # 大括号里能写表达式`,C=`我叫小明，今年18岁
分数：92.5
明年19岁`,H=`print("他说：\\"你好\\"")    # \\" 表示一个双引号
print("第一行\\n第二行")       # \\n 换行
print("姓名\\t年龄")           # \\t 制表符（一段空白）
print("路径 C:\\\\Users")      # \\\\ 表示一个反斜杠`,O=`他说："你好"
第一行
第二行
姓名	年龄
路径 C:\\Users`;function R(){return e.jsxs("article",{children:[e.jsxs(i,{children:["字符串就是「一串文字」，是编程中最常打交道的数据之一。这一章讲清楚字符串怎么创建、 怎么用下标和切片取出其中一部分、怎么拼接和重复、最常用的几个处理方法， 以及超好用的 ",e.jsx("strong",{children:"f-string"})," 格式化和转义字符。"]}),e.jsx("h2",{children:"一、创建字符串：三种引号"}),e.jsxs(r,{children:["用引号包起来的文字就是字符串。单引号 ",e.jsx("code",{children:"' '"})," 和双引号 ",e.jsx("code",{children:'" "'})," 效果一样； 三引号 ",e.jsx("code",{children:'""" """'})," 可以写跨多行的文字。"]}),e.jsx(s,{lang:"python",title:"三种引号",code:o}),e.jsx(n,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:x})}),e.jsxs(t,{variant:"tip",children:["什么时候用单、什么时候用双？当文字里本身含有引号时，用另一种把它包起来最省事。 比如内容里有双引号，就用单引号包：",e.jsx("code",{children:`'他说"你好"'`}),"。"]}),e.jsx("h2",{children:"二、索引与切片：取出其中一部分"}),e.jsxs("p",{children:["字符串里每个字符都有一个编号（下标），",e.jsx("strong",{children:"从 0 开始数"}),"。用方括号",e.jsx("code",{children:"[]"})," 加下标就能取出某个字符。负数下标从末尾倒着数。"]}),e.jsx(s,{lang:"python",title:"索引取单个字符",code:j}),e.jsx(n,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:p})}),e.jsxs(t,{variant:"warn",title:"下标从 0 开始",children:["新手最容易搞错：第一个字符是 ",e.jsx("code",{children:"s[0]"})," 不是 ",e.jsx("code",{children:"s[1]"}),"。 长度为 6 的字符串，合法下标是 0 到 5，访问 ",e.jsx("code",{children:"s[6]"})," 会报 ",e.jsx("code",{children:"IndexError"}),"。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"切片"}),"用 ",e.jsx("code",{children:"[开始:结束]"})," 一次取出一段，遵循「含头不含尾」——取到「结束」前一个为止："]}),e.jsx(s,{lang:"python",title:"切片取一段",code:a}),e.jsx(n,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:f})}),e.jsx("h2",{children:"三、拼接与重复"}),e.jsxs("p",{children:["字符串之间用 ",e.jsx("code",{children:"+"})," 连接，用 ",e.jsx("code",{children:"*"})," 重复多次："]}),e.jsx(s,{lang:"python",title:"拼接和重复",code:g}),e.jsx(n,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:m})}),e.jsx("h2",{children:"四、常用字符串方法"}),e.jsxs("p",{children:["字符串自带一堆好用的「方法」，用",e.jsx("strong",{children:"点号"}),"调用，如 ",e.jsx("code",{children:"s.upper()"}),"。 记住：这些方法都",e.jsx("strong",{children:"返回一个新字符串，不会改动原来的"}),"。"]}),e.jsx(s,{lang:"python",title:"常用方法一览",code:y}),e.jsx(n,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:u})}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方法"}),e.jsx("th",{children:"作用"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"upper()"})," / ",e.jsx("code",{children:"lower()"})]}),e.jsx("td",{children:"转大写 / 小写"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"strip()"})}),e.jsx("td",{children:"去掉两端的空格、换行等空白"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"replace(旧, 新)"})}),e.jsx("td",{children:"把所有「旧」替换成「新」"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"split(分隔符)"})}),e.jsx("td",{children:"按分隔符切开，得到一个列表"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"find(子串)"})}),e.jsx("td",{children:"找子串的起始下标，找不到返回 -1"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"len(s)"})}),e.jsx("td",{children:"字符串长度（注意：len 是函数不是方法）"})]})]})]}),e.jsx("h2",{children:"五、f-string：最方便的格式化"}),e.jsxs(r,{children:["f-string 是在字符串前面加一个字母 ",e.jsx("code",{children:"f"}),"，然后在字符串里用大括号 ",e.jsx("code",{children:"{}"}),"嵌入变量或表达式。它是把变量「填」进文字里的最简洁方式，强烈推荐。"]}),e.jsx(s,{lang:"python",title:"f-string 实战",code:P}),e.jsx(n,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:C})}),e.jsxs("p",{children:["大括号里不仅能放变量，还能放运算（如 ",e.jsx("code",{children:"{age + 1}"}),"），还能跟格式说明 （如 ",e.jsx("code",{children:"{score:.1f}"})," 表示保留一位小数）。这比用 ",e.jsx("code",{children:"+"})," 拼接、还要到处",e.jsx("code",{children:"str()"})," 转换方便太多了。"]}),e.jsxs(t,{variant:"tip",children:["想在 f-string 里输出一个真正的大括号，写两个：",e.jsx("code",{children:"{{"})," 显示成 ",e.jsx("code",{children:"{"}),"。"]}),e.jsx("h2",{children:"六、转义字符"}),e.jsxs("p",{children:["有些字符不好直接打出来（比如换行、引号本身），就用反斜杠 ",e.jsx("code",{children:"\\"})," 加一个字母来表示， 叫「转义字符」："]}),e.jsx(s,{lang:"python",title:"常见转义",code:H}),e.jsx(n,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:O})}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"转义"}),e.jsx("th",{children:"表示"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"\\n"})}),e.jsx("td",{children:"换行"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"\\t"})}),e.jsx("td",{children:"制表符（一段对齐用的空白）"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:'\\"'})," / ",e.jsx("code",{children:"\\'"})]}),e.jsx("td",{children:"一个双引号 / 单引号"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"\\\\"})}),e.jsx("td",{children:"一个反斜杠本身"})]})]})]}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」，看看结果。"]}),e.jsx(l,{initialCode:h}),e.jsx(c,{title:"动手练一练",children:e.jsxs("ol",{children:[e.jsx("li",{children:"让用户输入一句英文，把它全部转成大写后打印。"}),e.jsxs("li",{children:["定义 ",e.jsx("code",{children:'email = "test@example.com"'}),"，用 ",e.jsx("code",{children:'split("@")'})," 把用户名和域名分开打印。"]}),e.jsx("li",{children:"用 f-string 打印一句：「我叫XX，身高1.7米」，其中名字和身高用变量填入，身高保留 2 位小数。"})]})}),e.jsx(d,{points:["字符串用单/双引号创建（等价），三引号可写多行；引号里含引号时用另一种包起来。","索引从 0 开始，s[0] 是第一个，负数从末尾数；切片 [开始:结束] 含头不含尾。","+ 拼接字符串，* 重复字符串。","常用方法 upper/lower/strip/replace/split/find 返回新串不改原串，len() 取长度。","f-string（前缀 f）用 {} 嵌入变量和表达式，可带 :.1f 等格式，是最推荐的格式化方式。",'转义字符用反斜杠：\\n 换行、\\t 制表、\\" 引号、\\\\ 反斜杠。']})]})}export{R as default};
