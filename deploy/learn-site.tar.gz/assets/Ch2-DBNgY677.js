import{j as e}from"./index-DL563RIm.js";import{L as n,S as d}from"./Summary-BrgLcNDp.js";import{K as s}from"./KeyIdea-exK4GrdK.js";import{C as i}from"./Callout-B-8nslAm.js";import{C as r}from"./CodeBlock-DkVyd3P6.js";import{E as l}from"./Example-HxOmIesu.js";import{B as c}from"./BuildPipeline-DeIjhQqF.js";import"./Figure-Ueosrsuu.js";const o=`// 第一步：把源码字符串解析成 AST（抽象语法树）
import { add } from './math.js'   // ← 一行字符串

// 解析后大致是这样一棵树（极简示意）：
// ImportDeclaration
//   source: "./math.js"          ← 工具就是读这个字段拿到依赖
//   specifiers: [ add ]
//
// 有了 AST，工具能精确地「看见」每一条 import，
// 而不必用脆弱的正则去猜。后续转换也都在 AST 上做`,t=`// 第二步：加载与转换 —— 一切非 JS 资源都被「翻译」成 JS 模块
// 不同文件类型交给不同 loader / 插件：

import styles from './app.css'    // CSS loader：把样式变成可注入的 JS
import logo from './logo.png'     // 资源 loader：变成一个 URL 字符串或 base64
import data from './data.json'    // JSON：解析成 JS 对象
import App from './App.tsx'       // TS + JSX：编译成普通 JS

// 经过这一步，依赖图里每个节点——无论原本是什么——
// 都变成了「打包器认识的 JS 模块」。这是后面能统一处理的关键`,h=`// 第三、四步：基于依赖图收集模块、给每个模块编号、生成 chunk
// 下面是一个「极简打包器」的核心思路（伪代码）

let ID = 0
function createAsset(filename) {
  const content = fs.readFileSync(filename, 'utf-8')
  const ast = parse(content)              // ① 解析成 AST
  const deps = []                         // ② 收集这个模块的依赖
  walk(ast, (node) => {
    if (node.type === 'ImportDeclaration') deps.push(node.source.value)
  })
  return { id: ID++, filename, deps, code: transform(content) }  // 给模块编号
}

function buildGraph(entry) {              // ③ 从入口递归构建依赖图
  const mainAsset = createAsset(entry)
  const queue = [mainAsset]
  for (const asset of queue) {
    asset.mapping = {}                    // 「这个模块里写的相对路径」→「目标模块编号」
    asset.deps.forEach((relativePath) => {
      const child = createAsset(resolve(asset.filename, relativePath))
      asset.mapping[relativePath] = child.id
      queue.push(child)                   // 入队，循环会继续展开它的依赖
    })
  }
  return queue                            // 一个扁平的模块数组，就是整张图
}`,x=`// 第五步：输出 —— 把所有模块拼成一个带 require 函数的 IIFE
// 这是极简打包器产出的 bundle 长相（简化）：

(function (modules) {
  // 浏览器里没有 require，于是我们自己造一个
  function require(id) {
    const [fn, mapping] = modules[id]
    const module = { exports: {} }
    // 模块内部写的 require('./x')，先经 mapping 翻译成编号，再递归 require
    function localRequire(relativePath) {
      return require(mapping[relativePath])
    }
    fn(localRequire, module, module.exports)   // 执行模块代码，填充 exports
    return module.exports
  }
  require(0)                                   // 从入口模块（编号 0）启动
})({
  // 每个模块 = [包裹成函数的代码, 相对路径→编号 的映射表]
  0: [
    function (require, module, exports) {
      const { add } = require('./math.js')
      console.log(add(1, 2))
    },
    { './math.js': 1 },
  ],
  1: [
    function (require, module, exports) {
      exports.add = (a, b) => a + b
    },
    {},
  ],
})`,j=`// webpack 运行时的核心：__webpack_require__ + 模块缓存（简化）
var installedModules = {}                         // 模块缓存

function __webpack_require__(moduleId) {
  // 命中缓存就直接返回 —— 同一个模块只执行一次（这也是模块单例的来源）
  if (installedModules[moduleId]) {
    return installedModules[moduleId].exports
  }
  var module = (installedModules[moduleId] = { i: moduleId, l: false, exports: {} })

  // 执行模块函数，把 require/module/exports 传进去
  modules[moduleId].call(module.exports, module, module.exports, __webpack_require__)

  module.l = true                                 // 标记已加载
  return module.exports
}

return __webpack_require__(__webpack_require__.s = 0)   // 从入口启动`;function f(){return e.jsxs("article",{children:[e.jsxs(n,{children:["上一章我们拿到了一张",e.jsx("strong",{children:"模块依赖图"}),"，但图里的节点还都是原始源码。 这一章把打包器剩下的活干完：从源码到能部署的 ",e.jsx("code",{children:"bundle"}),"， 中间要经过",e.jsx("strong",{children:"解析、转换、收集、分块、输出"}),"五步。 我们不只讲流程，还会动手「拆解一个极简打包器」——看它如何读入口、找 import、递归、 给模块编号、最后拼成一个带 ",e.jsx("code",{children:"require"})," 函数的 IIFE。 再顺带看清 webpack 运行时在浏览器里到底用什么把模块串起来，以及 HMR 为什么能不刷新页面就更新。"]}),e.jsx("h2",{children:"一、打包五步总览"}),e.jsx("p",{children:"先回到这张流水线图。上一章我们停在「解析依赖图」，这一章把后面的转换、分块、优化、产出补齐。 点开各阶段对照着看，会更有体感。"}),e.jsx(c,{}),e.jsx("p",{children:"把它拆成开发者视角的五个动作，就是下面这张表。后面各节会逐一展开。"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"步骤"}),e.jsx("th",{children:"名称"}),e.jsx("th",{children:"它在做什么"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"①"}),e.jsx("td",{children:"解析（Parse）"}),e.jsx("td",{children:"把每个模块的源码字符串解析成 AST，以便精确读取 import"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"②"}),e.jsx("td",{children:"转换（Transform）"}),e.jsx("td",{children:"loader / 插件把 TS、JSX、CSS、图片都变成 JS 模块"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"③"}),e.jsx("td",{children:"收集（Collect）"}),e.jsx("td",{children:"沿依赖图把所有可达模块收齐，给每个模块编号"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"④"}),e.jsx("td",{children:"分块（Chunk）"}),e.jsx("td",{children:"把模块组织成一个或多个 chunk，并加上运行时"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"⑤"}),e.jsx("td",{children:"输出（Output）"}),e.jsx("td",{children:"拼成最终文件写到 dist/"})]})]})]}),e.jsx("h2",{children:"二、第一步：解析成 AST"}),e.jsxs("p",{children:["打包器拿到一个模块的源码后，第一件事不是直接处理字符串，而是把它",e.jsx("strong",{children:"解析成 AST （抽象语法树）"}),"。AST 是源码的结构化表示——一棵描述「这段代码由哪些语法成分构成」的树。"]}),e.jsx(r,{lang:"js",title:"源码 → AST，依赖关系变得可读",code:o}),e.jsxs(s,{children:["用 AST 而不是正则，是因为只有结构化的树才能",e.jsx("strong",{children:"准确"}),"地识别每一条 import、 区分注释与代码、处理各种边界写法。后续的转换（如 JSX → JS）也都是在 AST 上做节点替换， 再把树",e.jsx("strong",{children:"生成"}),"回字符串。"]}),e.jsx("h2",{children:"三、第二步：加载与转换"}),e.jsxs("p",{children:["依赖图里的节点五花八门：",e.jsx("code",{children:".ts"}),"、",e.jsx("code",{children:".jsx"}),"、",e.jsx("code",{children:".css"}),"、",e.jsx("code",{children:".png"}),"、",e.jsx("code",{children:".json"}),"……但 bundle 最终只能是 JS。于是有了",e.jsx("strong",{children:"转换"}),"这一步：每种文件类型交给对应的 ",e.jsx("strong",{children:"loader / 插件"}),"， 把它「翻译」成打包器认识的 JS 模块。"]}),e.jsx(r,{lang:"js",title:"loader 把一切都变成 JS 模块",code:t}),e.jsxs(s,{children:["「一切皆模块」是打包器的核心抽象：CSS、图片、JSON 在转换后都成了 JS 模块， 因而能",e.jsx("strong",{children:"统一"}),"进入依赖图、统一被收集和优化。loader 负责「单个文件怎么转」， 插件则能介入打包的各个生命周期，做更全局的事。"]}),e.jsx(l,{title:"一张图片是怎么变成模块的",children:e.jsxs("p",{children:[e.jsx("code",{children:"import logo from './logo.png'"})," 经资源 loader 处理后，可能有两种结果： 小图片被转成 ",e.jsx("strong",{children:"base64"})," 内联进 JS（",e.jsx("code",{children:"logo"})," 拿到一段",e.jsx("code",{children:"data:image/png;base64,..."})," 字符串），省一次网络请求；大图片则被",e.jsx("strong",{children:"拷到输出目录"}),"，",e.jsx("code",{children:"logo"})," 拿到它的最终 URL。无论哪种， 对依赖图来说它就是「一个导出了字符串的 JS 模块」。"]})}),e.jsx("h2",{children:"四、第三、四步：手写一个极简打包器"}),e.jsxs("p",{children:["理解打包最好的方式，是看它最朴素的样子。抛开优化与花活，一个打包器的内核只需要四个动作：",e.jsx("strong",{children:"读入口 → 找 import → 递归 → 给模块编号"}),"。下面是这个内核的伪代码。"]}),e.jsx(r,{lang:"js",title:"极简打包器：构建图并给模块编号",code:h}),e.jsx("p",{children:"几个关键设计值得注意："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"每个模块一个数字 id"}),"：用 ",e.jsx("code",{children:"ID++"})," 顺序编号。最终 bundle 里模块之间 不再用文件路径互相引用，而是用这个编号——更短，也避免了路径在浏览器里没意义的问题。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"mapping 表"}),"：模块源码里写的是相对路径（",e.jsx("code",{children:"'./math.js'"}),"）， 但 bundle 里要用编号。于是每个模块都带一张",e.jsx("code",{children:"{ 相对路径: 目标编号 }"})," 的映射表，运行时用它做翻译。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"用队列做广度遍历"}),"：",e.jsx("code",{children:"for (const asset of queue)"})," 里又往",e.jsx("code",{children:"queue"})," 里 push，循环会自然地把整张图展开。真实打包器还会用「已访问集合」 处理循环依赖，避免重复展开。"]})]}),e.jsx("h2",{children:"五、第五步：输出 —— 拼成一个带 require 的 IIFE"}),e.jsxs("p",{children:["图建好、模块编好号，最后一步是",e.jsx("strong",{children:"拼装"}),"。难点在于：浏览器里",e.jsx("strong",{children:"没有"}),e.jsx("code",{children:"require"})," 这个函数。极简打包器的做法是——自己造一个，连同所有模块一起塞进一个",e.jsx("strong",{children:"IIFE（立即执行函数）"}),"里。"]}),e.jsx(r,{lang:"js",title:"极简打包器输出的 bundle 示意",code:x}),e.jsxs(s,{children:["输出产物的结构是：一个 IIFE 接收「模块表」（编号 → [包裹成函数的模块代码, mapping]）， 内部定义一个 ",e.jsx("code",{children:"require(id)"}),"。每个模块代码被包进 ",e.jsx("code",{children:"function(require, module, exports)"}),"， 于是模块里的 ",e.jsx("code",{children:"require('./x')"})," 实际调用的是这个自造的、用 mapping 翻译编号的",e.jsx("code",{children:"localRequire"}),"。从入口模块（编号 0）",e.jsx("code",{children:"require(0)"})," 启动，整个程序就跑起来了。"]}),e.jsxs("p",{children:["这就是打包的「魔法」拆穿后的真相：把多个文件的代码，包成一堆函数， 再配一个能按编号互相调用的 ",e.jsx("code",{children:"require"}),"，塞进一个自执行函数。仅此而已。"]}),e.jsx("h2",{children:"六、真实世界：webpack 运行时"}),e.jsxs("p",{children:["生产级打包器（以 webpack 为例）做的事和上面的极简版",e.jsx("strong",{children:"同构"}),"，只是更健壮。 它注入的那个自造 require 叫 ",e.jsx("code",{children:"__webpack_require__"}),"，并且多了一个关键的东西：",e.jsx("strong",{children:"模块缓存"}),"。"]}),e.jsx(r,{lang:"js",title:"webpack 运行时核心（简化）",code:j}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"__webpack_require__(id)"}),"：和极简版的 ",e.jsx("code",{children:"require"})," 一个角色—— 按编号找到模块函数、执行、返回其 ",e.jsx("code",{children:"exports"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"模块缓存 installedModules"}),"：每个模块",e.jsx("strong",{children:"只执行一次"}),"， 之后的 require 直接返回缓存。这正是「同一个模块在整个应用里是",e.jsx("strong",{children:"单例"}),"」的实现原理—— 多处 import 同一个模块，拿到的是同一份 exports。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"从入口启动"}),"：最后 ",e.jsx("code",{children:"__webpack_require__(0)"}),"（入口编号）点火， 沿着 require 调用链把整张图按需执行起来。"]})]}),e.jsxs(i,{variant:"note",title:"chunk 与 bundle 的区别",children:[e.jsx("strong",{children:"chunk"})," 是打包器内部的「代码块」单位：入口 chunk、动态",e.jsx("code",{children:"import()"})," 拆出的异步 chunk、被多处共享的公共 chunk。 一个 chunk 经输出后写成磁盘上的一个文件，通常就叫一个 ",e.jsx("strong",{children:"bundle"}),"。 分块的意义在于：首屏只加载必要的 chunk，其余按需懒加载，减小首包体积。"]}),e.jsx("h2",{children:"七、HMR：为什么能不刷新就更新"}),e.jsxs("p",{children:["开发时改一行代码，页面局部就更新了、还不丢状态——这就是",e.jsx("strong",{children:"热模块替换（HMR）"}),"。"]}),e.jsxs(s,{children:["HMR 一句话原理：dev server 通过 WebSocket 把「哪个模块变了」推给浏览器里的 HMR 运行时， 运行时只重新拉取并",e.jsx("strong",{children:"替换那一个模块"}),"，再执行模块注册的更新回调（如 React 组件重渲染）， 从而",e.jsx("strong",{children:"不刷新整页、不丢应用状态"}),"地完成更新。"]}),e.jsx("h2",{children:"八、小结"}),e.jsxs("p",{children:["从源码到 bundle，打包器做的事并不神秘：解析成 AST 看清依赖，用 loader 把一切转成 JS 模块， 沿依赖图收集并给模块编号，组织成 chunk，最后拼成一个带自造 ",e.jsx("code",{children:"require"})," 的产物。 真实工具在此之上加了模块缓存、分块、Tree Shaking、HMR 等工程化能力，但内核始终是那一套。 理解了这条主线，后面学 Vite、webpack 的各种配置，就都是在给这条流水线的某一步「拧旋钮」。"]}),e.jsx(d,{points:["打包五步：解析成 AST、加载与转换、基于依赖图收集模块、生成 chunk、输出到 dist。","解析用 AST 而非正则，才能准确识别每条 import；转换让 TS/JSX/CSS/图片都变成 JS 模块（一切皆模块）。","极简打包器内核：读入口→找 import→递归构建图→给每个模块一个数字 id，并为每个模块记录「相对路径→编号」的 mapping。","输出是把模块包成函数、配一个自造 require、塞进 IIFE；从入口模块 require(0) 启动整个程序。","webpack 运行时用 __webpack_require__ 加模块缓存：每个模块只执行一次，这正是模块单例的来源。","chunk 是内部代码块单位、输出后成为 bundle；HMR 靠 dev server 推送变更、运行时只替换变动模块，做到不刷新整页、不丢状态。"]})]})}export{f as default};
