import{j as e}from"./index-BdVncPlI.js";import{L as i,S as s}from"./Summary-Baiwq3-G.js";import{K as o}from"./KeyIdea-Cnr-5ipR.js";import{C as r}from"./Callout-BRUKkrb4.js";import{C as t}from"./CodeBlock-DCdshbU5.js";import{E as l}from"./Example-phQ905Fb.js";const n=`import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Body

// Retrofit 用注解声明式地描述 HTTP API：
// 你只写接口，Retrofit 在运行时生成发请求、解析响应的实现。
interface NoteApi {

    // GET /notes?page=1&size=20
    // suspend 方法直接返回解析好的数据，无需 Call/回调。
    @GET("notes")
    suspend fun listNotes(
        @Query("page") page: Int,
        @Query("size") size: Int = 20
    ): List<NoteDto>

    // GET /notes/{id} —— @Path 把参数填进 URL 路径占位符。
    @GET("notes/{id}")
    suspend fun getNote(@Path("id") id: Long): NoteDto

    // POST /notes，请求体是序列化后的 note 对象。
    @POST("notes")
    suspend fun createNote(@Body note: NoteDto): NoteDto
}`,d=`import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

// DTO（Data Transfer Object）= 网络传输用的数据形状，
// 通常和数据库 Entity 分开，二者各自演化、互不绑死。
// @JsonClass(generateAdapter = true) 让 Moshi 用代码生成（而非反射）解析，更快。
@JsonClass(generateAdapter = true)
data class NoteDto(
    val id: Long,
    val title: String,
    // 服务端字段叫 body，本地属性叫 content，用 @Json 对上。
    @Json(name = "body") val content: String,
    @Json(name = "updated_at") val updatedAt: Long
)`,c=`import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import com.squareup.moshi.Moshi
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor

// OkHttp 拦截器：在请求/响应链路上插一脚。
// 这里加日志拦截器（打印请求与响应）和鉴权拦截器（统一加 token 头）。
val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }

val authInterceptor = okhttp3.Interceptor { chain ->
    val request = chain.request().newBuilder()
        .addHeader("Authorization", "Bearer \${TokenStore.current()}")
        .build()
    chain.proceed(request)
}

val client = OkHttpClient.Builder()
    .addInterceptor(authInterceptor)
    .addInterceptor(logging)
    .build()

val moshi = Moshi.Builder().build()

// converterFactory 负责把 JSON 文本 <-> Kotlin 对象。
val retrofit = Retrofit.Builder()
    .baseUrl("https://api.example.com/")
    .client(client)
    .addConverterFactory(MoshiConverterFactory.create(moshi))
    .build()

val api: NoteApi = retrofit.create(NoteApi::class.java)`,a=`// 用 sealed class 显式表达"成功 / 失败"两种结局，
// 让调用方在编译期就被迫处理失败分支，而不是漏掉 try/catch。
sealed interface Outcome<out T> {
    data class Success<T>(val data: T) : Outcome<T>
    data class Failure(val error: Throwable) : Outcome<Nothing>
}

// 一个小工具：把可能抛异常的网络调用包成 Outcome。
suspend fun <T> runCatchingOutcome(block: suspend () -> T): Outcome<T> =
    try {
        Outcome.Success(block())
    } catch (e: Exception) {
        Outcome.Failure(e)
    }`,h=`import kotlinx.coroutines.flow.Flow

// Repository 同时持有远程（Retrofit）和本地（Room Dao）两个数据源，
// 对上层只暴露统一、干净的接口。
class NoteRepository(
    private val api: NoteApi,
    private val dao: NoteDao
) {
    // 单一可信来源（Single Source of Truth）：UI 永远只看本地数据库的 Flow。
    // 网络只负责"把新数据写进数据库"，写完 Flow 自动发射、UI 自动刷新。
    val notes: Flow<List<NoteEntity>> = dao.observeAll()

    // 先读缓存、再刷新：UI 先拿到本地数据立刻显示（上面的 Flow 已经在供数据），
    // 这里去网络拉最新的写回数据库；成功与否都用 Outcome 表达。
    suspend fun refresh(): Outcome<Unit> = runCatchingOutcome {
        val remote = api.listNotes(page = 1)        // 网络请求（suspend）
        val entities = remote.map { it.toEntity() } // DTO -> Entity
        dao.replaceAll(entities)                    // 写回本地，触发 Flow 刷新
    }

    suspend fun create(title: String, content: String): Outcome<NoteEntity> =
        runCatchingOutcome {
            val created = api.createNote(NoteDto.of(title, content))
            val entity = created.toEntity()
            dao.upsert(entity)   // 远程成功后落本地
            entity
        }
}`,p=`import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// UI 状态：用一个 sealed/data 模型同时表达加载中、数据、错误。
data class NotesUiState(
    val notes: List<NoteEntity> = emptyList(),
    val loading: Boolean = false,
    val errorMessage: String? = null
)

class NotesViewModel(private val repo: NoteRepository) : ViewModel() {

    private val _error = MutableStateFlow<String?>(null)
    private val _loading = MutableStateFlow(false)

    // 把"本地数据 Flow + 加载态 + 错误态"合并成一个 UI 状态流。
    val uiState: StateFlow<NotesUiState> =
        combine(repo.notes, _loading, _error) { notes, loading, error ->
            NotesUiState(notes = notes, loading = loading, errorMessage = error)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), NotesUiState())

    // 进入界面或下拉刷新时调用：去网络刷新，按 Outcome 分支处理。
    fun refresh() {
        viewModelScope.launch {
            _loading.value = true
            when (val r = repo.refresh()) {
                is Outcome.Success -> _error.value = null
                is Outcome.Failure -> _error.value = r.error.message ?: "刷新失败"
            }
            _loading.value = false
        }
    }
}`;function v(){return e.jsxs("article",{children:[e.jsxs(i,{children:["上一章我们把数据存进了本地的 Room 数据库。但绝大多数 App 的数据来自服务器，本地只是缓存。 这一章讲网络层：用 ",e.jsx("strong",{children:"Retrofit"})," 以注解声明式地定义 HTTP API，配合",e.jsx("strong",{children:"协程"}),"让接口方法直接返回数据； 用转换器把 JSON 解析成 Kotlin 对象；再用 ",e.jsx("strong",{children:"Repository 模式"}),'把远程（Retrofit）与本地（Room 缓存） 两个数据源统一起来，做成"先读缓存、再刷新网络"的流程，并用 ',e.jsx("code",{children:"sealed class"})," 把成功与失败表达清楚。"]}),e.jsx("h2",{children:"一、Retrofit：用注解声明 HTTP API"}),e.jsxs("p",{children:["Retrofit 是 Square 出品、Android 上最主流的 HTTP 客户端封装。它的核心思路和 Room 异曲同工： 你",e.jsx("strong",{children:"只写一个接口"}),"，用注解描述每个方法对应哪个 HTTP 请求，Retrofit 在运行时生成真正的实现。 你不必手动拼 URL、设方法、读响应流——这些都交给框架。"]}),e.jsxs(o,{children:["Retrofit 把一次 HTTP 请求映射成一个接口方法：方法上的 ",e.jsx("code",{children:"@GET"}),"/",e.jsx("code",{children:"@POST"})," 决定请求类型与路径， 参数上的 ",e.jsx("code",{children:"@Path"}),"/",e.jsx("code",{children:"@Query"}),"/",e.jsx("code",{children:"@Body"}),' 决定参数怎么进 URL 或请求体。 声明即实现，你专注"要什么数据"，不操心"怎么发请求"。']}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"注解"}),e.jsx("th",{children:"位置"}),e.jsx("th",{children:"作用"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"@GET"})," / ",e.jsx("code",{children:"@POST"})]}),e.jsx("td",{children:"方法"}),e.jsx("td",{children:"声明 HTTP 方法与相对路径"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"@Path"})}),e.jsx("td",{children:"参数"}),e.jsxs("td",{children:["填进 URL 路径占位符，如 ",e.jsxs("code",{children:["notes/","{id}"]})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"@Query"})}),e.jsx("td",{children:"参数"}),e.jsxs("td",{children:["拼成查询串，如 ",e.jsx("code",{children:"?page=1"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"@Body"})}),e.jsx("td",{children:"参数"}),e.jsx("td",{children:"作为请求体（会被序列化成 JSON）"})]})]})]}),e.jsx(t,{lang:"kotlin",title:"NoteApi.kt —— 声明式 HTTP 接口",code:n}),e.jsx("h2",{children:"二、suspend：让接口方法直接返回数据"}),e.jsxs("p",{children:["早期 Retrofit 的方法返回 ",e.jsx("code",{children:"Call<T>"}),"，你得手动 ",e.jsx("code",{children:"enqueue"}),' 一个回调来拿结果， 代码很容易陷进"回调地狱"。和协程集成后，做法干净多了：把接口方法标成 ',e.jsx("code",{children:"suspend"}),"， 直接声明返回 ",e.jsx("code",{children:"List<NoteDto>"})," 这样的",e.jsx("strong",{children:"数据类型"}),"即可。"]}),e.jsxs("p",{children:["调用时 ",e.jsx("code",{children:"val notes = api.listNotes(page = 1)"})," 读起来像同步代码，实际上 Retrofit 在后台 发请求、解析响应，完成后把结果挂起返回，整个过程不阻塞主线程。网络出错（超时、4xx/5xx、解析失败） 会以",e.jsx("strong",{children:"抛异常"}),"的形式冒出来，由调用方用 ",e.jsx("code",{children:"try/catch"})," 或下文的 ",e.jsx("code",{children:"Outcome"})," 接住。"]}),e.jsx("h2",{children:"三、JSON 解析：转换器与 DTO"}),e.jsxs("p",{children:["服务器返回的是 JSON 文本，Kotlin 这边要的是对象。中间的翻译工作交给 ",e.jsx("strong",{children:"转换器"}),"（ConverterFactory）。两种主流选择：",e.jsx("strong",{children:"Moshi"})," 和 Kotlin 官方的 ",e.jsx("strong",{children:"kotlinx.serialization"}),"。 二者都支持代码生成（编译期生成解析逻辑，比反射快、可被 R8 友好裁剪）。"]}),e.jsxs("p",{children:["被解析出来的对象通常叫 ",e.jsx("strong",{children:"DTO"}),'（数据传输对象），它代表"网络传输的形状"， 刻意和数据库 ',e.jsx("code",{children:"Entity"})," 分开：服务端字段名可能是 ",e.jsx("code",{children:"updated_at"})," 这种下划线风格， 用 ",e.jsx("code",{children:"@Json(name = ...)"})," 映射到 Kotlin 的驼峰属性即可。两层分开后，网络协议变了不会直接污染数据库结构。"]}),e.jsx(t,{lang:"kotlin",title:"NoteDto.kt —— 网络层数据对象（Moshi）",code:d}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"转换器"}),e.jsx("th",{children:"特点"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"Moshi"}),e.jsxs("td",{children:["Square 出品，与 Retrofit/OkHttp 同源；用 ",e.jsx("code",{children:"codegen"})," 生成适配器"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"kotlinx.serialization"}),e.jsx("td",{children:"Kotlin 官方，编译期插件生成；多平台友好"})]})]})]}),e.jsx("h2",{children:"四、OkHttp 拦截器与组装 Retrofit"}),e.jsxs("p",{children:["Retrofit 底层用 OkHttp 发请求。OkHttp 的",e.jsx("strong",{children:"拦截器"}),"能在每个请求/响应经过时插一脚， 常见两类：",e.jsx("strong",{children:"日志拦截器"}),"（开发期打印请求与响应，便于调试）和",e.jsx("strong",{children:"鉴权拦截器"}),"（给每个请求统一加上 ",e.jsx("code",{children:"Authorization"})," 头，省得每个接口方法都写一遍）。把 OkHttpClient、 转换器、baseUrl 装进 ",e.jsx("code",{children:"Retrofit.Builder"}),"，最后 ",e.jsx("code",{children:"create"})," 出接口实例即可。"]}),e.jsx(t,{lang:"kotlin",title:"组装 OkHttp + 拦截器 + Retrofit",code:c}),e.jsxs(r,{variant:"warn",title:"日志拦截器别带上线",children:[e.jsx("code",{children:"Level.BODY"})," 会把请求体、响应体、甚至鉴权头打进日志。这在开发期很方便， 但发布版里必须关掉或降级，否则可能把 token、用户隐私写进日志。一般用构建类型（debug/release） 来区分拦截器的日志级别。"]}),e.jsx("h2",{children:"五、错误处理：用 Result / sealed class 表达成功失败"}),e.jsxs("p",{children:["网络一定会失败：断网、超时、服务端 500、JSON 对不上。如果让异常裸奔，调用方很容易忘记 catch， 某次失败就变成崩溃。更稳的做法是用 ",e.jsx("strong",{children:"sealed class"}),"（或 Kotlin 自带的 ",e.jsx("code",{children:"Result"}),'） 把"成功带数据 / 失败带错误"显式建模成一个封闭类型——这样 ',e.jsx("code",{children:"when"}),' 表达式会强制你处理两个分支， 编译器替你盯着"别漏了失败的情况"。']}),e.jsx(t,{lang:"kotlin",title:"Outcome —— 成功/失败的封闭类型",code:a}),e.jsxs(r,{variant:"tip",title:"为什么用 sealed class",children:[e.jsx("code",{children:"sealed interface"})," 把所有可能的子类型在编译期固定下来。对它做 ",e.jsx("code",{children:"when"})," 时， 编译器知道一共就 ",e.jsx("code",{children:"Success"})," 和 ",e.jsx("code",{children:"Failure"}),' 两种，漏掉一个就会警告/报错。 失败再也不会被悄悄忽略——这正是我们想要的"逼着调用方处理错误"。']}),e.jsx("h2",{children:"六、Repository：统一远程与本地两个数据源"}),e.jsxs("p",{children:["现在把网络和上一章的 Room 揉到一起。",e.jsx("strong",{children:"Repository"})," 同时持有 ",e.jsx("code",{children:"api"}),"（远程）和",e.jsx("code",{children:"dao"}),"（本地），对上层只暴露干净接口。这里采用业界常用的 ",e.jsx("strong",{children:"单一可信来源"}),'（Single Source of Truth）模式：UI 永远只读本地数据库的 Flow，网络的唯一职责是"把最新数据写进数据库"。']}),e.jsxs(o,{children:["先读缓存、再刷新：UI 订阅 ",e.jsx("code",{children:"dao.observeAll()"})," 的 Flow，打开页面立刻显示本地缓存（哪怕离线也有内容）； 与此同时 ",e.jsx("code",{children:"refresh()"})," 去网络拉最新数据写回数据库，写入触发 Flow 重新发射，UI 无缝刷新成最新值。"]}),e.jsx(t,{lang:"kotlin",title:"NoteRepository.kt —— 远程 + 本地",code:h}),e.jsxs(l,{title:"一次刷新的完整数据流",children:[e.jsxs("p",{children:["用户打开列表页：UI 立刻 collect 到 ",e.jsx("code",{children:"dao.observeAll()"})," 的本地缓存并渲染——",e.jsx("strong",{children:"零延迟、可离线"}),"。"]}),e.jsxs("p",{children:["同时 ViewModel 触发 ",e.jsx("code",{children:"repo.refresh()"}),"：Retrofit 发 ",e.jsx("code",{children:"GET /notes"}),"（suspend，后台执行）→ 拿到 ",e.jsx("code",{children:"List<NoteDto>"})," → 映射成 Entity → ",e.jsx("code",{children:"dao.replaceAll(...)"})," 写回数据库。 写回的瞬间 Flow 重新发射，列表自动更新成服务器最新数据。若网络失败，返回 ",e.jsx("code",{children:"Outcome.Failure"}),"， 本地缓存原样保留，UI 顶多弹个错误提示而不会白屏崩溃。"]})]}),e.jsx("h2",{children:"七、在 ViewModel 里调用"}),e.jsxs("p",{children:["最后一层是 ViewModel。它在 ",e.jsx("code",{children:"viewModelScope"}),'（生命周期感知的协程作用域）里调用 Repository， 把"本地数据 Flow""加载中""错误信息"合并成一个 ',e.jsx("code",{children:"UiState"})," 暴露给界面。界面只观察这一个状态流， 逻辑全部收口在 ViewModel 里。"]}),e.jsx(t,{lang:"kotlin",title:"NotesViewModel.kt —— 调用 Repository 并管理状态",code:p}),e.jsxs("p",{children:["注意 ",e.jsx("code",{children:"refresh()"})," 里对 ",e.jsx("code",{children:"Outcome"})," 的 ",e.jsx("code",{children:"when"})," 分支：成功就清空错误、失败就把错误消息 放进状态。",e.jsx("code",{children:"viewModelScope"})," 还会在 ViewModel 销毁时自动取消未完成的协程，避免界面已关闭、 网络回调还在跑导致的泄漏与崩溃。"]}),e.jsx("h2",{children:"八、小结"}),e.jsx("p",{children:'至此，一条完整的数据链路打通了：Retrofit 用注解声明 API、suspend 直接返回数据、转换器解析 JSON， OkHttp 拦截器处理日志与鉴权；Repository 把远程与本地统一成单一可信来源，做"先读缓存再刷新"， 并用 sealed class 把成功失败表达清楚；ViewModel 在协程作用域里驱动这一切，向界面输出一个状态流。 本地 + 网络两章合起来，就是 Android 现代数据层的标准骨架。'}),e.jsx(s,{points:["Retrofit 用注解（@GET/@POST/@Path/@Query/@Body）声明式定义 HTTP API，运行时生成实现，你只写接口。","接口方法用 suspend 直接返回数据类型，配合协程在后台发请求、不阻塞主线程；出错以异常形式抛出。","转换器（Moshi 或 kotlinx.serialization）负责 JSON 与 Kotlin 对象互转；DTO 与数据库 Entity 分层，互不绑死。","OkHttp 拦截器在请求/响应链上插一脚，常用于打日志和统一加鉴权头；日志级别需按构建类型区分，别带上线。",'Repository 统一远程（Retrofit）与本地（Room 缓存）数据源，按单一可信来源做"先读缓存、再刷新网络"，用 sealed class/Result 表达成功失败。',"ViewModel 在 viewModelScope 里调用 Repository，把本地 Flow、加载态、错误态合并成 UiState 暴露给界面，并按 Outcome 分支处理错误。"]})]})}export{v as default};
