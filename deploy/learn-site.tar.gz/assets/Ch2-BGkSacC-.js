import{j as e}from"./index-CNCQ9D3g.js";import{L as d,S as i}from"./Summary-B81QYNtK.js";import{K as l}from"./KeyIdea-CJu1AmJK.js";import{E as n}from"./Example-C7EXHAW5.js";import{P as c}from"./Practice-Cem8Avrf.js";import{C as s}from"./Callout-DBjCLF-u.js";import{C as r}from"./CodeBlock-B4ANG3D_.js";import{C as t}from"./CacheProblem-DtGkiRrA.js";import"./Figure-DNCpIpnp.js";const o=`def get_product(product_id):
    key = "product:" + str(product_id)

    # 1. 先查缓存，命中直接返回（绝大多数请求走这里）
    val = redis.get(key)
    if val is not None:
        return deserialize(val)

    # 2. 未命中，说明热点 key 刚刚过期，尝试抢一把互斥锁
    lock_key = "lock:" + key
    # set ... nx ex：只有锁不存在时才能设成功，谁设成功谁负责重建
    got_lock = redis.set(lock_key, "1", nx=True, ex=10)

    if got_lock:
        try:
            # 双重检查：抢到锁后再查一次缓存，可能别人刚重建好(避免重复回源)
            val = redis.get(key)
            if val is not None:
                return deserialize(val)
            # 抢到锁的线程：去数据库重建缓存
            product = db.query_product(product_id)
            redis.set(key, serialize(product), ex=3600)
            return product
        finally:
            redis.delete(lock_key)   # 重建完务必释放锁
    else:
        # 没抢到锁的线程：短暂等待后重试，让它读到刚重建好的缓存
        sleep(50)                    # 毫秒
        return get_product(product_id)`,x=`# 逻辑过期：value 里自带一个「逻辑过期时间」，Redis 上不设真实 TTL（永不物理过期）
# 写入示例： {"data": {...}, "logical_expire_at": 1718500000}

def get_product(product_id):
    key = "product:" + str(product_id)
    obj = redis.get(key)            # 热点 key 永不物理过期，这里一定命中

    if obj["logical_expire_at"] > now():
        return obj["data"]          # 逻辑上没过期，直接返回

    # 逻辑上已过期：抢锁，抢到的线程「异步」重建，自己先返回旧数据
    lock_key = "lock:" + key
    if redis.set(lock_key, "1", nx=True, ex=10):
        submit_async(lambda: rebuild_and_release(product_id, lock_key))

    return obj["data"]              # 不阻塞：所有请求都先拿到旧数据`,h=`# 异步重建任务：查库 → 写回新数据(带新的逻辑过期时间) → 释放锁
def rebuild_and_release(product_id, lock_key):
    key = "product:" + str(product_id)
    try:
        product = db.query_product(product_id)
        obj = {"data": serialize(product),
               "logical_expire_at": now() + 3600}   # 新的逻辑过期时间
        redis.set(key, json.dumps(obj))             # 注意：不设物理 TTL
    finally:
        redis.delete(lock_key)`;function f(){return e.jsxs(e.Fragment,{children:[e.jsx(d,{children:e.jsxs("p",{children:["有一类 key，平时承载着极高的并发——比如一个爆款商品的详情。它一直命中缓存，岁月静好。 可一旦它",e.jsx("strong",{children:"过期的那一瞬间"}),"，成千上万个还在涌入的请求会同时发现缓存没了，于是一起冲向数据库。 这就是 ",e.jsx("em",{children:"cache breakdown"}),"，缓存击穿。"]})}),e.jsx("h2",{children:"什么是缓存击穿"}),e.jsxs("p",{children:["缓存击穿指的是：某个",e.jsx("strong",{children:"超高并发的热点 key"})," 在过期的瞬间，大量请求同时缓存未命中， 于是同一时刻全部穿过缓存压向数据库。这些请求做的是",e.jsx("strong",{children:"同一件事"}),"——都去查同一条数据、 都想把缓存重建出来。数据库在这一瞬间承受了远超平时的并发，很可能被打垮。"]}),e.jsx(s,{variant:"warn",title:"和穿透的关键区别：key 是存在的",children:e.jsxs("p",{children:["击穿和穿透最容易混。记住：穿透查的是",e.jsx("strong",{children:"根本不存在"}),"的数据，缓存永远建不起来； 而击穿查的 key ",e.jsx("strong",{children:"是真实存在"}),"的，只是它刚好过期了，在「过期到被重建」这个极短的空窗期里被并发打穿。 所以击穿是个",e.jsx("strong",{children:"时间点"}),"问题，穿透是个",e.jsx("strong",{children:"数据存在性"}),"问题。"]})}),e.jsxs(n,{title:"秒杀商品详情的热点 key",children:[e.jsxs("p",{children:["某个秒杀爆款，详情页 QPS 高达 5 万。它的缓存 ",e.jsx("code",{children:"product:8848"})," 设了 1 小时过期。 整点到了，这个 key 正好过期："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:["这一毫秒内涌入的几万个请求，全部查 ",e.jsx("code",{children:"product:8848"}),"，全部未命中；"]}),e.jsx("li",{children:"它们各自回查数据库，于是数据库瞬间被几万个「查同一条商品」的请求砸中；"}),e.jsx("li",{children:"更糟的是，每个请求查完都想写回缓存，重复劳动叠加并发，数据库直接被打挂。"})]}),e.jsxs("p",{children:["注意：",e.jsx("code",{children:"product:8848"})," 这条数据在数据库里是真实存在的，问题只在于「重建缓存」这件事 被几万个请求同时做了。"]})]}),e.jsx(t,{}),e.jsx("h2",{children:"两种核心防护"}),e.jsx("h3",{children:"方案一：互斥锁 / 分布式锁"}),e.jsxs("p",{children:["既然几万个请求做的是同一件事，那就",e.jsx("strong",{children:"只让一个去做"}),"。当缓存未命中时，请求先去抢一把锁 （单机用本地锁，分布式环境用 ",e.jsx("em",{children:"Redis"})," 的 ",e.jsx("code",{children:"SET key value NX EX"})," 实现的分布式锁）。 抢到锁的线程才去查数据库、重建缓存；没抢到的线程则",e.jsx("strong",{children:"稍等片刻再重试"}),"，等它们重试时， 缓存往往已经被重建好了，直接命中返回。这样落到数据库的，从几万个降到了",e.jsx("strong",{children:"仅仅一个"}),"。"]}),e.jsxs("p",{children:["实现里有个易漏的细节：抢到锁后",e.jsx("strong",{children:"要再查一次缓存（双重检查）"}),"。因为可能在你抢锁的间隙， 前一个持锁线程刚把缓存重建好了，再查一次就能直接命中、省掉一次回源。另外锁一定要设过期时间防死锁， 重建逻辑要放在 ",e.jsx("code",{children:"finally"})," 里释放锁。"]}),e.jsx("h3",{children:"方案二：逻辑过期（logical expire）"}),e.jsxs("p",{children:["换个思路：既然「物理过期的那一瞬间」最危险，那就",e.jsx("strong",{children:"不设真实的 TTL"}),"，让热点 key 在 Redis 上永不物理过期。 取而代之，在 value 里存一个",e.jsx("strong",{children:"逻辑过期时间"}),"字段。读取时判断这个逻辑时间：没过就正常返回； 逻辑上过期了，就抢锁开一个",e.jsx("strong",{children:"异步任务"}),"去后台重建，而当前请求",e.jsx("strong",{children:"先返回旧数据"}),"，不阻塞。 于是任何请求都不会卡住，也不会有「缓存为空」的空窗。"]}),e.jsx(r,{lang:"python",title:"rebuild_async.py（异步重建任务）",code:h}),e.jsxs(l,{title:"互斥锁 vs 逻辑过期：怎么权衡",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"互斥锁"}),"：实现简单、能保证拿到的",e.jsx("strong",{children:"一定是最新数据"}),"（强一致倾向）；代价是没抢到锁的请求要",e.jsx("strong",{children:"等待/重试"}),"，重建期间响应变慢，极端情况下还可能因为锁没释放好而出问题。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"逻辑过期"}),"：所有请求",e.jsx("strong",{children:"永不阻塞"}),"、吞吐和响应最稳；代价是逻辑过期到异步重建完成之间， 会有请求读到",e.jsx("strong",{children:"旧数据"}),"（牺牲一点一致性换可用性），且实现更复杂、需要常驻内存（key 不会自己消失）。 一句话：要数据新就用互斥锁，要高可用、能容忍短暂旧值就用逻辑过期。"]})]}),e.jsx(s,{variant:"info",title:"第三招：热点 key 干脆不过期 + 后台主动更新",children:e.jsxs("p",{children:["对于「永远的热点」（如首页配置、热门榜单），可以从根上避免击穿：",e.jsx("strong",{children:"不给它设过期时间"}),"， 改由一个后台定时任务",e.jsx("strong",{children:"主动刷新"}),"缓存。这样读请求永远命中、永远不空窗，重建完全脱离用户请求路径。 逻辑过期其实就是这个思路的「按需触发」版本。代价同样是会有短暂旧值、且要保证后台任务别挂。"]})}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方案"}),e.jsx("th",{children:"是否阻塞"}),e.jsx("th",{children:"数据新鲜度"}),e.jsx("th",{children:"实现复杂度"}),e.jsx("th",{children:"适合"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"互斥锁"}),e.jsx("td",{children:"未抢到锁的要等"}),e.jsx("td",{children:"最新"}),e.jsx("td",{children:"低"}),e.jsx("td",{children:"一致性优先"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"逻辑过期"}),e.jsx("td",{children:"不阻塞"}),e.jsx("td",{children:"可能旧值"}),e.jsx("td",{children:"较高"}),e.jsx("td",{children:"可用性优先"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"不过期+后台更新"}),e.jsx("td",{children:"不阻塞"}),e.jsx("td",{children:"可能旧值"}),e.jsx("td",{children:"中"}),e.jsx("td",{children:"永久热点"})]})]})]}),e.jsx("h2",{children:"面试怎么答"}),e.jsxs("p",{children:["先",e.jsx("strong",{children:"定义清楚并强调与穿透的区别"}),"：击穿是单个高并发热点 key 过期瞬间被大量请求打穿，而 key 本身是存在的。 再给两种方案：",e.jsx("strong",{children:"互斥锁"}),"（只放一个线程重建，其余等待，保证新数据但响应变慢，记得双重检查 + finally 释放锁）和",e.jsx("strong",{children:"逻辑过期"}),"（不设真实 TTL，value 存逻辑过期时间，过期后异步重建、先返回旧值，不阻塞但有短暂旧数据）。 最后用一句「一致性优先选互斥锁，可用性优先选逻辑过期」收尾，再补一句「对永远的热点 key 也可以干脆不设过期、靠后台定时更新」。"]}),e.jsxs(c,{title:"用互斥锁重建热点缓存",children:[e.jsxs("p",{children:["核心是用 ",e.jsx("code",{children:"SET lock NX EX"})," 抢锁：抢到的线程去重建，没抢到的稍等后重试。注意重建完一定要在",e.jsx("code",{children:"finally"})," 里释放锁，并给锁设过期时间防止死锁，抢到锁后还要",e.jsx("strong",{children:"双重检查"}),"缓存。"]}),e.jsx(r,{lang:"python",title:"mutex_rebuild.py",code:o}),e.jsx("p",{children:"作为对照，下面是逻辑过期的思路：热点 key 永不物理过期，靠 value 里的逻辑时间判断，过期就异步重建、先返回旧值。"}),e.jsx(r,{lang:"python",title:"logical_expire.py",code:x}),e.jsx("p",{children:"压测建议：用几千个并发同时请求一个刚过期的热点 key，统计真正落到数据库的查询次数——互斥锁应该接近 1 次， 而无防护时会接近并发数。"})]}),e.jsx(i,{points:["缓存击穿：单个超高并发的热点 key 过期瞬间，大量请求同时未命中并冲向数据库。","与穿透的关键区别：击穿的 key 是真实存在的，只是过期了；穿透的数据压根不存在。","防护一是互斥锁/分布式锁：只放一个线程去重建缓存，其余线程等待后重试，落库请求降到一个；抢到锁要双重检查、finally 释放、锁要带过期。","防护二是逻辑过期：不设真实 TTL，value 里存逻辑过期时间，过期后异步重建并先返回旧数据。","互斥锁保证拿到最新数据但重建期响应变慢；逻辑过期永不阻塞但会读到短暂旧值。","选择原则：一致性优先用互斥锁，可用性优先用逻辑过期；永久热点可直接不过期靠后台更新。"]})]})}export{f as default};
