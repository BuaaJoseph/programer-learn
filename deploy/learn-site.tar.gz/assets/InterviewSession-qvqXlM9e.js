import{r as l,j as e,C as re,u as he,P as ve}from"./index-CNCQ9D3g.js";import{r as be,f as Z,l as xe,S as ye,b as je,c as we,a as Se}from"./api-B7y31JYH.js";const ee=[{id:"two-sum-ii",title:"两数之和 II（有序数组）",difficulty:"中等",tags:["数组","双指针"],statement:`给定一个已按升序排列的整数数组 numbers 和目标值 target，请找出两个数使它们相加之和等于 target，返回这两个数的下标（从 1 开始），要求空间复杂度 O(1)。

输入：第一行为目标值 target，第二行为以空格分隔的有序数组。
输出：两个下标，空格分隔。`,sampleInput:`9
2 7 11 15`,sampleOutput:"1 2"},{id:"longest-substring",title:"无重复字符的最长子串",difficulty:"中等",tags:["滑动窗口","哈希"],statement:`给定一个字符串 s，找出其中不含重复字符的最长子串的长度。

输入：一行字符串 s。
输出：最长无重复子串的长度。`,sampleInput:"abcabcbb",sampleOutput:"3"},{id:"add-two-numbers",title:"两个大数相加（字符串）",difficulty:"中等",tags:["字符串","模拟"],statement:`给定两个用字符串表示的非负大整数 a、b（可能超过 long 范围），返回它们之和（字符串）。

输入：两行，分别为 a 和 b。
输出：a + b。`,sampleInput:`99999999999999999999
1`,sampleOutput:"100000000000000000000"},{id:"lru-cache",title:"LRU 缓存机制",difficulty:"中等",tags:["设计","哈希","双向链表"],statement:`设计并实现一个 LRU（最近最少使用）缓存，支持 get 和 put，容量满时淘汰最久未使用的项，均要求 O(1)。

输入：第一行为容量 cap 与操作数 n；接下来 n 行，每行形如 "put 1 1" 或 "get 1"。
输出：每个 get 操作的返回值（未命中输出 -1），空格分隔在一行。`,sampleInput:`2 5
put 1 1
put 2 2
get 1
put 3 3
get 2`,sampleOutput:"1 -1"},{id:"longest-palindrome",title:"最长回文子串",difficulty:"中等",tags:["字符串","动态规划"],statement:`给定字符串 s，返回它的最长回文子串。

输入：一行字符串 s。
输出：最长回文子串（若有多个，输出任意一个）。`,sampleInput:"babad",sampleOutput:"bab"},{id:"three-sum",title:"三数之和",difficulty:"中等",tags:["数组","双指针"],statement:`给定数组 nums，找出所有和为 0 且不重复的三元组，按升序输出。

输入：一行以空格分隔的整数数组。
输出：每行一个三元组（升序、空格分隔）；无解输出空。`,sampleInput:"-1 0 1 2 -1 -4",sampleOutput:`-1 -1 2
-1 0 1`},{id:"container-water",title:"盛最多水的容器",difficulty:"中等",tags:["双指针","贪心"],statement:`给定 n 个非负整数表示柱子高度，找出两条柱子使其与 x 轴构成的容器能盛最多的水，输出最大面积。

输入：一行以空格分隔的高度数组。
输出：最大面积。`,sampleInput:"1 8 6 2 5 4 8 3 7",sampleOutput:"49"},{id:"coin-change",title:"零钱兑换",difficulty:"中等",tags:["动态规划"],statement:`给定硬币面额数组 coins 和总金额 amount，求凑成总金额所需最少硬币数；无法凑成输出 -1。

输入：第一行 amount；第二行硬币面额（空格分隔）。
输出：最少硬币数。`,sampleInput:`11
1 2 5`,sampleOutput:"3"},{id:"word-break",title:"单词拆分",difficulty:"中等",tags:["动态规划","字符串"],statement:`给定字符串 s 和单词字典 wordDict，判断 s 是否能被空格拆分成字典中的单词序列。

输入：第一行 s；第二行字典单词（空格分隔）。
输出：true 或 false。`,sampleInput:`leetcode
leet code`,sampleOutput:"true"},{id:"num-islands",title:"岛屿数量",difficulty:"中等",tags:["DFS","BFS","并查集"],statement:`给定由 '1'（陆地）和 '0'（水）组成的二维网格，计算岛屿数量。岛屿由相邻（上下左右）陆地连接。

输入：第一行 m n；接下来 m 行，每行 n 个 0/1（空格分隔）。
输出：岛屿数量。`,sampleInput:`3 3
1 1 0
0 1 0
0 0 1`,sampleOutput:"2"},{id:"course-schedule",title:"课程表（拓扑排序）",difficulty:"中等",tags:["图","拓扑排序"],statement:`共有 numCourses 门课，先修关系给定为 [a, b]（学 a 前必须先学 b）。判断能否完成所有课程。

输入：第一行 numCourses 与边数 m；接下来 m 行每行两个数 a b。
输出：true 或 false。`,sampleInput:`2 1
1 0`,sampleOutput:"true"},{id:"kth-largest",title:"数组中的第 K 个最大元素",difficulty:"中等",tags:["堆","快速选择"],statement:`在未排序数组中找到第 k 个最大的元素。

输入：第一行 k；第二行数组（空格分隔）。
输出：第 k 大的元素。`,sampleInput:`2
3 2 1 5 6 4`,sampleOutput:"5"},{id:"merge-intervals",title:"合并区间",difficulty:"中等",tags:["排序","区间"],statement:`给定若干区间，合并所有重叠区间。

输入：第一行区间数 n；接下来 n 行每行两个数 start end。
输出：合并后的区间，每行两个数（按起点升序）。`,sampleInput:`4
1 3
2 6
8 10
15 18`,sampleOutput:`1 6
8 10
15 18`},{id:"rotate-image",title:"旋转图像",difficulty:"中等",tags:["数组","矩阵"],statement:`给定 n×n 矩阵，将其原地顺时针旋转 90 度。

输入：第一行 n；接下来 n 行每行 n 个数。
输出：旋转后的矩阵。`,sampleInput:`3
1 2 3
4 5 6
7 8 9`,sampleOutput:`7 4 1
8 5 2
9 6 3`},{id:"subsets",title:"子集",difficulty:"中等",tags:["回溯","位运算"],statement:`给定一个不含重复元素的整数数组 nums，返回其所有可能的子集（幂集）。

输入：一行数组（空格分隔）。
输出：每行一个子集（空格分隔，含空行表示空集），顺序不限。`,sampleInput:"1 2 3",sampleOutput:`
1
2
1 2
3
1 3
2 3
1 2 3`},{id:"permutations",title:"全排列",difficulty:"中等",tags:["回溯"],statement:`给定不含重复数字的数组 nums，返回其所有全排列。

输入：一行数组（空格分隔）。
输出：每行一个排列（空格分隔），顺序不限。`,sampleInput:"1 2 3",sampleOutput:`1 2 3
1 3 2
2 1 3
2 3 1
3 1 2
3 2 1`},{id:"search-rotated",title:"搜索旋转排序数组",difficulty:"中等",tags:["二分查找"],statement:`整数数组 nums 升序排列后在某个未知点旋转，给定 target，存在则返回下标，否则返回 -1，要求 O(log n)。

输入：第一行 target；第二行数组。
输出：下标或 -1。`,sampleInput:`0
4 5 6 7 0 1 2`,sampleOutput:"4"},{id:"product-except-self",title:"除自身以外数组的乘积",difficulty:"中等",tags:["数组","前缀积"],statement:`给定数组 nums，返回数组 answer，其中 answer[i] 等于 nums 中除 nums[i] 之外其余元素的乘积，不能使用除法，O(n)。

输入：一行数组。
输出：结果数组（空格分隔）。`,sampleInput:"1 2 3 4",sampleOutput:"24 12 8 6"},{id:"daily-temperatures",title:"每日温度（单调栈）",difficulty:"中等",tags:["单调栈"],statement:`给定每日温度数组，返回数组 answer，answer[i] 表示第 i 天之后要等多少天才会有更高温度；若不存在则为 0。

输入：一行温度数组。
输出：结果数组（空格分隔）。`,sampleInput:"73 74 75 71 69 72 76 73",sampleOutput:"1 1 4 2 1 1 0 0"},{id:"min-path-sum",title:"最小路径和",difficulty:"中等",tags:["动态规划","矩阵"],statement:`给定 m×n 非负网格，从左上走到右下，每次只能向右或向下，求路径上数字和的最小值。

输入：第一行 m n；接下来 m 行每行 n 个数。
输出：最小路径和。`,sampleInput:`3 3
1 3 1
1 5 1
4 2 1`,sampleOutput:"7"},{id:"unique-paths",title:"不同路径",difficulty:"中等",tags:["动态规划","组合数学"],statement:`m×n 网格，机器人从左上到右下，每次只能向右或向下，求不同路径总数。

输入：一行 m n。
输出：路径数。`,sampleInput:"3 7",sampleOutput:"28"},{id:"max-subarray",title:"最大子数组和",difficulty:"中等",tags:["动态规划","分治"],statement:`给定整数数组 nums，找到具有最大和的连续子数组，返回其和。

输入：一行数组。
输出：最大子数组和。`,sampleInput:"-2 1 -3 4 -1 2 1 -5 4",sampleOutput:"6"},{id:"group-anagrams",title:"字母异位词分组",difficulty:"中等",tags:["哈希","字符串"],statement:`给定字符串数组，把字母异位词组合在一起。

输入：一行若干单词（空格分隔）。
输出：每行一组异位词（空格分隔），组内与组间顺序不限。`,sampleInput:"eat tea tan ate nat bat",sampleOutput:`eat tea ate
tan nat
bat`},{id:"spiral-matrix",title:"螺旋矩阵",difficulty:"中等",tags:["矩阵","模拟"],statement:`给定 m×n 矩阵，按顺时针螺旋顺序返回所有元素。

输入：第一行 m n；接下来 m 行每行 n 个数。
输出：螺旋顺序的所有元素（空格分隔，一行）。`,sampleInput:`3 3
1 2 3
4 5 6
7 8 9`,sampleOutput:"1 2 3 6 9 8 7 4 5"},{id:"jump-game",title:"跳跃游戏",difficulty:"中等",tags:["贪心"],statement:`给定非负整数数组 nums，初始位于下标 0，每个元素代表在该位置可跳跃的最大长度，判断能否到达最后一个下标。

输入：一行数组。
输出：true 或 false。`,sampleInput:"2 3 1 1 4",sampleOutput:"true"},{id:"longest-consecutive",title:"最长连续序列",difficulty:"中等",tags:["哈希","并查集"],statement:`给定未排序数组 nums，找出数字连续的最长序列长度，要求 O(n)。

输入：一行数组。
输出：最长连续序列长度。`,sampleInput:"100 4 200 1 3 2",sampleOutput:"4"},{id:"top-k-frequent",title:"前 K 个高频元素",difficulty:"中等",tags:["堆","哈希"],statement:`给定整数数组 nums 和整数 k，返回出现频率前 k 高的元素（按频率从高到低）。

输入：第一行 k；第二行数组。
输出：前 k 个高频元素（空格分隔）。`,sampleInput:`2
1 1 1 2 2 3`,sampleOutput:"1 2"},{id:"decode-ways",title:"解码方法",difficulty:"中等",tags:["动态规划","字符串"],statement:`数字到字母的映射为 '1'->A ... '26'->Z。给定只含数字的字符串 s，计算它有多少种解码方法。

输入：一行数字字符串 s。
输出：解码方法数。`,sampleInput:"226",sampleOutput:"3"},{id:"validate-bst",title:"验证二叉搜索树",difficulty:"中等",tags:["树","DFS"],statement:`给定二叉树的层序遍历（null 表示空节点），判断它是否是有效的二叉搜索树。

输入：一行层序遍历，节点值或 null，空格分隔。
输出：true 或 false。`,sampleInput:"5 1 4 null null 3 6",sampleOutput:"false"},{id:"gas-station",title:"加油站",difficulty:"中等",tags:["贪心"],statement:`环路上有 n 个加油站，gas[i] 为可加油量，cost[i] 为到下一站的耗油。从某站出发绕一圈，返回可行的起始站下标，无解返回 -1。

输入：第一行 gas 数组；第二行 cost 数组。
输出：起始站下标或 -1。`,sampleInput:`1 2 3 4 5
3 4 5 1 2`,sampleOutput:"3"},{id:"partition-equal",title:"分割等和子集",difficulty:"中等",tags:["动态规划","背包"],statement:`给定只含正整数的非空数组 nums，判断能否将其分割成两个和相等的子集。

输入：一行数组。
输出：true 或 false。`,sampleInput:"1 5 11 5",sampleOutput:"true"},{id:"house-robber-ii",title:"打家劫舍 II（环形）",difficulty:"中等",tags:["动态规划"],statement:`房屋围成一圈，相邻两间不能同时偷。给定每间金额数组 nums，求能偷到的最高金额。

输入：一行数组。
输出：最高金额。`,sampleInput:"2 3 2",sampleOutput:"3"},{id:"find-duplicate",title:"寻找重复数",difficulty:"中等",tags:["双指针","快慢指针"],statement:`给定 n+1 个整数的数组 nums，数字都在 [1, n] 内，存在且仅存在一个重复数，找出它（不修改数组、O(1) 空间）。

输入：一行数组。
输出：重复的数字。`,sampleInput:"1 3 4 2 2",sampleOutput:"2"},{id:"min-window",title:"最小覆盖子串",difficulty:"困难",tags:["滑动窗口","哈希"],statement:`给定字符串 s 和 t，返回 s 中涵盖 t 所有字符的最小子串；不存在则返回空串。

输入：第一行 s；第二行 t。
输出：最小覆盖子串。`,sampleInput:`ADOBECODEBANC
ABC`,sampleOutput:"BANC"},{id:"trapping-rain",title:"接雨水",difficulty:"困难",tags:["双指针","单调栈"],statement:`给定 n 个非负整数表示柱子高度图，计算下雨后能接多少雨水。

输入：一行高度数组。
输出：能接的雨水总量。`,sampleInput:"0 1 0 2 1 0 1 3 2 1 2 1",sampleOutput:"6"},{id:"edit-distance",title:"编辑距离",difficulty:"困难",tags:["动态规划"],statement:`给定两个单词 word1 和 word2，返回将 word1 转换成 word2 所使用的最少操作数（插入/删除/替换）。

输入：两行，分别为 word1 和 word2。
输出：最少操作数。`,sampleInput:`horse
ros`,sampleOutput:"3"},{id:"lis",title:"最长递增子序列",difficulty:"中等",tags:["动态规划","二分"],statement:`给定整数数组 nums，找到其中最长严格递增子序列的长度。

输入：一行数组。
输出：最长递增子序列长度。`,sampleInput:"10 9 2 5 3 7 101 18",sampleOutput:"4"}],V={python:`import sys

def solve(data):
    # data 是按行切分的输入列表；在这里实现你的逻辑并 print 结果
    pass

def main():
    data = sys.stdin.read().split('\\n')
    solve(data)

if __name__ == '__main__':
    main()
`,java:`import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // 在这里读取输入、实现逻辑并 System.out.println 输出结果
        // String line = br.readLine();
    }
}
`};function te(){const t=Math.floor(Math.random()*ee.length);return ee[t]}const Ne={python:["print(","input(","len(","range(","int(","str(","float(","list(","dict(","set(","tuple(","sorted(","reversed(","enumerate(","zip(","map(","filter(","sum(","min(","max(","abs(","round(","any(","all(","isinstance(","append(","extend(","insert(","pop(","remove(","sort(","split(","join(","strip(","replace(","startswith(","endswith(","find(","format(","keys(","values(","items(","get(","setdefault(","def ","class ","return ","import ","from ","for ","while ","if ","elif ","else:","try:","except ","finally:","with ","lambda ","yield ","global ","collections","defaultdict(","Counter(","deque(","heapq","heappush(","heappop(","heapify(","bisect","bisect_left(","bisect_right(","itertools","functools","lru_cache","math","sys.stdin","sys.stdin.read("],java:["public ","private ","protected ","static ","final ","void ","class ","interface ","extends ","implements ","return ","new ","import ","package ","if ","else ","for ","while ","switch ","case ","break;","continue;","try ","catch ","finally ","throw ","throws ","int ","long ","double ","float ","boolean ","char ","byte ","short ","String ","Integer","Long","Double","Boolean","Character","Math.","System.out.println(","System.out.print(","System.out.printf(","List<","ArrayList<","LinkedList<","Map<","HashMap<","TreeMap<","Set<","HashSet<","TreeSet<","Queue<","Deque<","ArrayDeque<","PriorityQueue<","Stack<","Collections.","Arrays.","Arrays.sort(","Arrays.asList(","StringBuilder","append(","toString()","length()","size()","add(","get(","put(","getOrDefault(","containsKey(","contains(","remove(","poll(","offer(","peek(","push(","pop(","BufferedReader","InputStreamReader","readLine()","split(","Integer.parseInt(","Long.parseLong(","String.valueOf(","Math.max(","Math.min(","Math.abs("]};function se(t,a){const o=t.slice(0,a).match(/[A-Za-z_.][A-Za-z0-9_.]*$/);return o?o[0]:""}function ke({initialLang:t="python",onSubmit:a}){const[r,o]=l.useState(t),[d,b]=l.useState({python:V.python,java:V.java}),[u,k]=l.useState(""),[j,f]=l.useState(""),[m,w]=l.useState(!1),[p,S]=l.useState(!1),[C,N]=l.useState({open:!1,items:[],index:0}),A=l.useRef(null),$=d[r],E=s=>b(i=>({...i,[r]:s})),B=l.useMemo(()=>Ne[r]||[],[r]),R=(s,i)=>{const y=se(s,i);if(y.length<1){N({open:!1,items:[],index:0});return}const I=y.toLowerCase(),L=B.filter(M=>M.toLowerCase().startsWith(I)&&M.toLowerCase()!==I).slice(0,8);N(L.length?{open:!0,items:L,index:0}:{open:!1,items:[],index:0})},q=s=>{const i=A.current;if(!i)return;const y=i.selectionStart,I=se($,y),L=y-I.length,M=$.slice(0,L)+s+$.slice(y);E(M);const T=L+s.length;N({open:!1,items:[],index:0}),requestAnimationFrame(()=>{i.focus(),i.selectionStart=i.selectionEnd=T})},P=s=>{E(s.target.value),R(s.target.value,s.target.selectionStart)},J=s=>{if(C.open){if(s.key==="ArrowDown"){s.preventDefault(),N(i=>({...i,index:(i.index+1)%i.items.length}));return}if(s.key==="ArrowUp"){s.preventDefault(),N(i=>({...i,index:(i.index-1+i.items.length)%i.items.length}));return}if(s.key==="Enter"||s.key==="Tab"){s.preventDefault(),q(C.items[C.index]);return}if(s.key==="Escape"){N({open:!1,items:[],index:0});return}}if(s.key==="Tab"){s.preventDefault();const i=s.target,y=i.selectionStart,I=i.selectionEnd,L=$.slice(0,y)+"    "+$.slice(I);E(L),requestAnimationFrame(()=>{i.selectionStart=i.selectionEnd=y+4})}s.key==="Enter"&&(s.ctrlKey||s.metaKey)&&(s.preventDefault(),p||c())},c=async()=>{S(!0),w(!1),f("正在执行…");try{const s=await be({language:r,source:$,stdin:u}),i=s.output||s.stdout||"",y=s.stderr||"",I=[i,y].filter(Boolean).join(`
`);w(!!y&&!i),f(I||"（没有任何输出）")}catch(s){w(!0),f(String((s==null?void 0:s.message)||s))}finally{S(!1)}},U=()=>E(V[r]),O=Math.max(14,$.split(`
`).length+1);return e.jsxs("div",{className:"code-editor",children:[e.jsxs("div",{className:"ce-tabs",children:[["python","java"].map(s=>e.jsx("button",{className:`ce-tab ${s===r?"active":""}`,onClick:()=>{o(s),N({open:!1,items:[],index:0})},children:s==="python"?"Python":"Java"},s)),e.jsxs("div",{className:"ce-tab-actions",children:[e.jsx("button",{className:"btn btn-ghost ce-small",onClick:U,disabled:p,children:"重置模板"}),e.jsx("button",{className:"btn btn-primary ce-small",onClick:c,disabled:p,children:p?"执行中…":"▶ 运行"})]})]}),e.jsxs("div",{className:"ce-editor-wrap",children:[e.jsx("textarea",{ref:A,className:"ce-textarea",value:$,onChange:P,onKeyDown:J,onBlur:()=>setTimeout(()=>N({open:!1,items:[],index:0}),120),spellCheck:!1,rows:O,"aria-label":"代码编辑器"}),C.open&&e.jsx("ul",{className:"ce-suggest",children:C.items.map((s,i)=>e.jsx("li",{className:i===C.index?"active":"",onMouseDown:y=>{y.preventDefault(),q(s)},children:s},s))})]}),e.jsxs("div",{className:"ce-io",children:[e.jsxs("div",{className:"ce-io-col",children:[e.jsx("label",{className:"ce-label",children:"标准输入（stdin，可留空）"}),e.jsx("textarea",{className:"ce-stdin",value:u,onChange:s=>k(s.target.value),spellCheck:!1,rows:4,placeholder:"把样例输入粘到这里，运行时会作为程序的标准输入"})]}),e.jsxs("div",{className:"ce-io-col",children:[e.jsx("label",{className:"ce-label",children:"运行结果"}),e.jsx("pre",{className:`ce-output${m?" is-error":""}`,children:j||"（点击「运行」查看输出）"})]})]}),e.jsxs("div",{className:"ce-bottom",children:[e.jsx("span",{className:"ce-hint",children:"提示：输入时会出现基础库联想（↑↓ 选择，Enter/Tab 补全）；Ctrl/⌘ + Enter 运行。"}),a&&e.jsx("button",{className:"btn btn-primary",onClick:()=>a({language:r,source:$}),children:"提交给面试官点评"})]})]})}function Ce(){return re.map(t=>({slug:t.meta.slug,title:t.meta.title,desc:t.meta.shortTitle||t.meta.subtitle||"",cat:`${t.meta.categoryId}/${t.meta.subCategoryId||""}`}))}function ne(t){return`${typeof window<"u"?window.location.origin:""}/course/${t}`}function ae(t){return re.find(a=>a.meta.slug===t)||null}const $e={A:{label:"A · 非常满意",color:"#0e835a",desc:"语言表达、项目、技术与 Coding 近乎完美，正是公司需要的人才（极难获得）"},B:{label:"B · 优秀人才",color:"#2563eb",desc:"整体优秀，个别方面略有差距，强烈推荐给后续面试官"},C:{label:"C · 通过面试",color:"#b26a09",desc:"项目与技术基础扎实，可继续推进，但缺少特别亮眼的表现"},D:{label:"D · 未通过（可荐他岗）",color:"#c0344d",desc:"部分方面欠缺，本岗位不再推进，其他岗位可继续面试"},E:{label:"E · 不可行",color:"#7a1326",desc:"一个或多个方面表现很差，短期内不建议推进其他岗位"}};function _(t){return $e[t]||{label:t,color:"#454c59",desc:""}}function Oe(t){const a=Z(t.position),r=Ce().map(o=>`${o.slug} | ${o.title}`).join(`
`);return`面试到此结束。现在请你切换为「面试评估官」，基于上面完整的面试对话记录，对这位「${a?a.title:t.position}」候选人做一次严谨、客观的综合评估打分。

# 评分等级（必须从中选一个）
- A：非常满意。语言表达、项目考察、技术技能和 Coding 都基本做到完美，正是公司需要的人才（极难获得）。
- B：优秀人才。在 A 的基础上个别方面有差距，但仍优秀，会强烈推荐给后续面试官。
- C：通过面试。项目考察、技术基础都比较扎实，可继续推进；没有特别亮眼或打动面试官的表现一般定为此级。
- D：未通过，但可推荐其他岗位。综合评估有所欠缺，本岗位不再推进，其他岗位可继续面试。
- E：完全不可行。一个或多个方面表现很差（如项目说不清、追问细节或基础知识基本不了解），短期内不建议推进其他岗位。

# 评估要求
1. 必须「结合面试中的具体问答实例」给出理由，好的与不足的地方都要引用候选人实际说过的话或表现，不能空口无凭。
2. 分维度评估：语言表达、项目考察、技术基础、AI/LLM 编程、Coding 编码。每个维度给 1-5 分并附结合实例的点评。
3. 给出后续需要加强的知识/技能清单，并尽量从下面的「本站课程清单」中挑选相关课程推荐（用 slug）。

# 本站课程清单（slug | 课程名）
${r}

# 输出格式（务必只输出一个 JSON，不要任何额外文字或 markdown 代码块标记）
{
  "grade": "A|B|C|D|E",
  "gradeReason": "为什么定这个等级（结合整体表现，2-4句）",
  "overallSummary": "整体评价（150字左右）",
  "dimensions": [
    {"name": "语言表达", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "项目考察", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "技术基础", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "AI/LLM 编程", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "Coding 编码", "score": 1-5, "comment": "结合实例的点评"}
  ],
  "strengths": [{"point": "亮点", "example": "面试中的具体实例"}],
  "weaknesses": [{"point": "不足", "example": "面试中的具体实例"}],
  "improvements": [{"topic": "需加强的知识/技能", "detail": "具体建议", "courseSlugs": ["相关课程slug"]}],
  "recommendedCourses": [{"slug": "课程slug", "reason": "推荐理由"}]
}`}function Ie(t){if(!t)throw new Error("评估结果为空");let a=t.trim();const r=a.match(/```(?:json)?\s*([\s\S]*?)```/);r&&(a=r[1].trim());const o=a.indexOf("{"),d=a.lastIndexOf("}");return o>=0&&d>o&&(a=a.slice(o,d+1)),JSON.parse(a)}const g=t=>String(t??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");function Ee(t){const a=Math.max(0,Math.min(5,Number(t)||0));return"★".repeat(a)+"☆".repeat(5-a)}function Re(t,a){const r=Z(a.position),o=_(t.grade),d=new Date,b=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")} ${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`,u=(t.dimensions||[]).map(p=>`<tr>
        <td class="dim-name">${g(p.name)}</td>
        <td class="dim-score"><span class="stars">${Ee(p.score)}</span> <b>${g(p.score)}</b>/5</td>
        <td class="dim-comment">${g(p.comment)}</td>
      </tr>`).join(""),k=(t.strengths||[]).map(p=>`<li><div class="pt good">✔ ${g(p.point)}</div>${p.example?`<div class="ex">实例：${g(p.example)}</div>`:""}</li>`).join(""),j=(t.weaknesses||[]).map(p=>`<li><div class="pt bad">✘ ${g(p.point)}</div>${p.example?`<div class="ex">实例：${g(p.example)}</div>`:""}</li>`).join(""),f=(t.improvements||[]).map(p=>{const S=(p.courseSlugs||[]).map(C=>{const N=ae(C);return N?`<a class="course-link" href="${g(ne(C))}" target="_blank" rel="noopener">📘 ${g(N.meta.title)}</a>`:""}).filter(Boolean).join("");return`<li><div class="imp-topic">${g(p.topic)}</div><div class="imp-detail">${g(p.detail)}</div>${S?`<div class="imp-links">${S}</div>`:""}</li>`}).join(""),m=(t.recommendedCourses||[]).map(p=>{const S=ae(p.slug);return S?`<a class="rec-card" href="${g(ne(p.slug))}" target="_blank" rel="noopener">
        <div class="rec-cover">${g(S.meta.cover||"📘")}</div>
        <div class="rec-body"><div class="rec-title">${g(S.meta.title)}</div><div class="rec-reason">${g(p.reason||S.meta.shortTitle||"")}</div></div>
      </a>`:""}).filter(Boolean).join(""),w=(a.skills||[]).map(g).join("、");return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>面试评估报告 · ${g(r?r.title:"")}</title>
<style>
  :root { --ink:#14171f; --soft:#454c59; --faint:#878e9c; --border:#e6e8ec; --bg:#fff; --sub:#f6f7f9; --accent:#4f46e5; }
  * { box-sizing: border-box; }
  body { margin:0; background:#eef0f4; color:var(--ink); font-family:-apple-system,'Segoe UI','Noto Sans SC',system-ui,sans-serif; line-height:1.7; }
  .sheet { max-width:880px; margin:32px auto; background:var(--bg); border-radius:16px; box-shadow:0 12px 40px rgba(20,23,31,.12); overflow:hidden; }
  .head { padding:34px 40px; background:linear-gradient(120deg,#4f46e5,#7c3aed); color:#fff; }
  .head h1 { margin:0 0 6px; font-size:1.6rem; }
  .head .meta { font-size:.9rem; opacity:.9; }
  .body { padding:32px 40px; }
  .grade-box { display:flex; align-items:center; gap:24px; padding:22px 26px; border-radius:14px; background:var(--sub); border:1px solid var(--border); margin-bottom:28px; }
  .grade-badge { width:92px; height:92px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:3rem; font-weight:800; color:#fff; flex-shrink:0; }
  .grade-info .glabel { font-size:1.2rem; font-weight:700; }
  .grade-info .gdesc { color:var(--soft); font-size:.92rem; margin-top:4px; }
  .grade-info .greason { margin-top:10px; font-size:.92rem; }
  h2 { font-size:1.15rem; margin:30px 0 12px; padding-left:12px; border-left:4px solid var(--accent); }
  .summary { background:var(--sub); border-radius:10px; padding:16px 18px; font-size:.95rem; }
  table { width:100%; border-collapse:collapse; font-size:.92rem; }
  th,td { text-align:left; padding:10px 12px; border-bottom:1px solid var(--border); vertical-align:top; }
  th { background:var(--sub); font-size:.82rem; color:var(--soft); }
  .dim-name { font-weight:700; white-space:nowrap; }
  .dim-score { white-space:nowrap; } .stars { color:#f5a623; letter-spacing:1px; }
  ul.list { list-style:none; padding:0; margin:0; }
  ul.list li { padding:12px 0; border-bottom:1px dashed var(--border); }
  .pt { font-weight:700; } .pt.good { color:#0e835a; } .pt.bad { color:#c0344d; }
  .ex { color:var(--soft); font-size:.9rem; margin-top:4px; padding-left:18px; border-left:2px solid var(--border); }
  .imp-topic { font-weight:700; }
  .imp-detail { color:var(--soft); font-size:.92rem; margin:4px 0; }
  .imp-links, .recs { display:flex; flex-wrap:wrap; gap:8px; margin-top:6px; }
  .course-link { display:inline-block; padding:5px 12px; background:#eef0fe; color:#4338ca; border:1px solid #c7cbf7; border-radius:999px; font-size:.84rem; text-decoration:none; }
  .course-link:hover { background:#4f46e5; color:#fff; }
  .recs { margin-top:12px; }
  .rec-card { display:flex; gap:12px; align-items:center; width:calc(50% - 6px); padding:12px 14px; border:1px solid var(--border); border-radius:12px; text-decoration:none; color:inherit; }
  .rec-card:hover { border-color:var(--accent); box-shadow:0 4px 14px rgba(20,23,31,.08); }
  .rec-cover { font-size:1.8rem; } .rec-title { font-weight:700; font-size:.95rem; } .rec-reason { color:var(--soft); font-size:.84rem; }
  .foot { padding:20px 40px; color:var(--faint); font-size:.82rem; border-top:1px solid var(--border); text-align:center; }
  @media print { body{background:#fff;} .sheet{box-shadow:none; margin:0;} }
  @media (max-width:640px){ .rec-card{width:100%;} .body,.head,.foot{padding-left:20px;padding-right:20px;} }
</style>
</head>
<body>
  <div class="sheet">
    <div class="head">
      <h1>面试评估报告</h1>
      <div class="meta">岗位：${g(r?r.title:a.position)} ｜ 考察技能：${w||"—"} ｜ 生成时间：${g(b)}</div>
    </div>
    <div class="body">
      <div class="grade-box">
        <div class="grade-badge" style="background:${o.color}">${g(t.grade)}</div>
        <div class="grade-info">
          <div class="glabel" style="color:${o.color}">${g(o.label)}</div>
          <div class="gdesc">${g(o.desc)}</div>
          <div class="greason">${g(t.gradeReason)}</div>
        </div>
      </div>

      <h2>整体评价</h2>
      <div class="summary">${g(t.overallSummary)}</div>

      <h2>分维度评估</h2>
      <table><thead><tr><th>维度</th><th>评分</th><th>结合实例的点评</th></tr></thead><tbody>${u}</tbody></table>

      <h2>亮点</h2>
      <ul class="list">${k||"<li>（无）</li>"}</ul>

      <h2>不足</h2>
      <ul class="list">${j||"<li>（无）</li>"}</ul>

      <h2>后续需要加强的知识 / 技能</h2>
      <ul class="list">${f||"<li>（无）</li>"}</ul>

      ${m?`<h2>推荐课程</h2><div class="recs">${m}</div>`:""}
    </div>
    <div class="foot">本报告由「编程学习站 · 面试模拟」基于本次面试问答自动生成，仅供学习参考。</div>
  </div>
</body>
</html>`}function Le(t,a="面试评估报告.html"){const r=new Blob([t],{type:"text/html;charset=utf-8"}),o=URL.createObjectURL(r),d=document.createElement("a");d.href=o,d.download=a,document.body.appendChild(d),d.click(),document.body.removeChild(d),setTimeout(()=>URL.revokeObjectURL(o),2e3)}function De(t){const a=new Blob([t],{type:"text/html;charset=utf-8"}),r=URL.createObjectURL(a);window.open(r,"_blank"),setTimeout(()=>URL.revokeObjectURL(r),6e4)}function ze(){return typeof window<"u"&&!!(window.SpeechRecognition||window.webkitSpeechRecognition)}function ie(){return typeof window<"u"&&!!window.speechSynthesis}function Ae({lang:t="zh-CN",onResult:a,onError:r,onEnd:o}={}){const d=window.SpeechRecognition||window.webkitSpeechRecognition;if(!d)return null;const b=new d;return b.lang=t,b.continuous=!0,b.interimResults=!0,b.onresult=u=>{let k="",j="";for(let f=u.resultIndex;f<u.results.length;f++){const m=u.results[f];m.isFinal?j+=m[0].transcript:k+=m[0].transcript}j?a&&a(j,!0):k&&a&&a(k,!1)},b.onerror=u=>r&&r(u),b.onend=()=>o&&o(),b}function Me({lang:t="zh-CN",rate:a=1.05,pitch:r=1}={}){const o=typeof window<"u"?window.speechSynthesis:null;let d=!0,b=[],u=!1;function k(){if(!o)return null;const f=o.getVoices()||[];return f.find(m=>m.lang===t)||f.find(m=>m.lang&&m.lang.startsWith(t.split("-")[0]))||null}function j(){if(!o||u||b.length===0)return;const f=b.shift();if(!f.trim()){j();return}const m=new SpeechSynthesisUtterance(f);m.lang=t,m.rate=a,m.pitch=r;const w=k();w&&(m.voice=w),m.onend=()=>{u=!1,j()},m.onerror=()=>{u=!1,j()},u=!0,o.speak(m)}return{speak(f){if(!o||!d||!f)return;const m=String(f).split(new RegExp("(?<=[。！？.!?；;\\n])")).map(w=>w.trim()).filter(Boolean);b.push(...m.length?m:[f]),j()},stop(){b=[],u=!1,o&&o.cancel()},setEnabled(f){d=f,f||this.stop()},get enabled(){return d}}}function Be(t){const a=String(Math.floor(t/60)).padStart(2,"0"),r=String(t%60).padStart(2,"0");return`${a}:${r}`}function qe(){const t=he(),a=xe(),[r,o]=l.useState([]),[d,b]=l.useState(""),[u,k]=l.useState(!1),[j,f]=l.useState(""),[m,w]=l.useState(""),[p,S]=l.useState(0),[C,N]=l.useState(0),[A,$]=l.useState(!1),[E,B]=l.useState(!1),[R,q]=l.useState((a==null?void 0:a.voice)!==!1),[P,J]=l.useState(!1),[c,U]=l.useState(null),[O,s]=l.useState("idle"),[i,y]=l.useState(null),[I,L]=l.useState(""),[M,T]=l.useState(""),x=l.useRef(null),G=l.useRef(null),D=l.useRef(""),H=l.useRef(null),K=l.useRef(null);l.useEffect(()=>{a||t("/interview",{replace:!0})},[]),l.useEffect(()=>(ie()&&(x.current=Me({lang:"zh-CN"})),x.current&&x.current.setEnabled(R),()=>{x.current&&x.current.stop()}),[]),l.useEffect(()=>{x.current&&x.current.setEnabled(R)},[R]),l.useEffect(()=>{if(!A)return;const n=setInterval(()=>N(h=>h+1),1e3);return()=>clearInterval(n)},[A]),l.useEffect(()=>{H.current&&(H.current.scrollTop=H.current.scrollHeight)},[r,d]);const le=n=>{if(!R||!x.current)return;D.current+=n;const h=D.current,v=h.match(/^[\s\S]*[。！？.!?；;\n]/);v&&(x.current.speak(v[0]),D.current=h.slice(v[0].length))},oe=()=>{R&&x.current&&D.current.trim()&&x.current.speak(D.current),D.current=""},Q=async n=>{k(!0),f(""),b(""),D.current="";const h=new AbortController;K.current=h;try{const v=await Se({messages:n},z=>{b(ge=>ge+z),le(z)},h.signal);oe(),o([...n,{role:"assistant",content:v}]),b("")}catch(v){(v==null?void 0:v.name)!=="AbortError"&&f(String((v==null?void 0:v.message)||v)),b("")}finally{k(!1),K.current=null}},ce=async()=>{const n={role:"system",content:je(a)};$(!0),await Q([n])},F=async n=>{const h=(n??m).trim();if(!h||u)return;x.current&&x.current.stop(),w("");const v=[...r,{role:"user",content:h}];o(v),await Q(v)},de=()=>{if(!ze()){f("当前浏览器不支持语音识别，请用 Chrome / Edge，或直接打字作答");return}if(E){G.current&&G.current.stop();return}x.current&&x.current.stop();const n=Ae({lang:"zh-CN",onResult:(h,v)=>{v&&w(z=>(z?z+" ":"")+h)},onError:()=>B(!1),onEnd:()=>B(!1)});n&&(G.current=n,n.start(),B(!0))},W=()=>{c||U(te()),J(!0),S(4)},ue=async({language:n,source:h})=>{const v=`（编程环节）题目：${c==null?void 0:c.title}
我用 ${n==="java"?"Java":"Python"} 作答，代码如下：

\`\`\`${n}
${h}
\`\`\`

请点评我的思路、时间/空间复杂度和边界处理，并指出可以改进的地方。`;await F(v)},me=async()=>{await F("面试官您好，本次面试到这里，麻烦您对我今天的整体表现做一个总结评价：包括优点、不足，以及针对性的提升建议。")},pe=()=>{K.current&&K.current.abort(),x.current&&x.current.stop()},Y=async()=>{if(x.current&&x.current.stop(),r.filter(n=>n.role!=="system").length<2){T("面试内容太少，请先进行面试再生成报告"),s("error");return}s("loading"),T("");try{const n=[...r,{role:"user",content:Oe(a)}],h=await we({messages:n}),v=Ie(h),z=Re(v,a);y(v),L(z),s("ready")}catch(n){T("生成报告失败："+String((n==null?void 0:n.message)||n)),s("error")}};if(!a)return null;const X=Z(a.position),fe=r.filter(n=>n.role!=="system");return e.jsx(ve,{children:e.jsxs("div",{className:"container iv-session",children:[e.jsxs("div",{className:"iv-bar",children:[e.jsxs("div",{className:"iv-bar-left",children:[e.jsxs("span",{className:"iv-bar-title",children:["模拟面试 · ",X?X.title:""]}),e.jsxs("span",{className:"iv-timer",children:["⏱ ",Be(C)]})]}),e.jsxs("div",{className:"iv-bar-right",children:[ie()&&e.jsx("button",{className:`iv-pill ${R?"on":""}`,onClick:()=>q(n=>!n),title:"面试官语音朗读",children:R?"🔊 语音开":"🔇 语音关"}),e.jsx("button",{className:"btn btn-ghost ce-small",onClick:()=>t("/interview"),children:"退出"})]})]}),e.jsx("div",{className:"iv-stages",children:ye.map((n,h)=>e.jsxs("button",{className:`iv-stage ${h===p?"active":""} ${h<p?"done":""}`,onClick:()=>{S(h),n.id==="coding"&&W()},title:`${n.desc} · 约${n.minutes}分钟`,children:[e.jsx("span",{className:"iv-stage-no",children:h+1}),e.jsx("span",{className:"iv-stage-name",children:n.title}),e.jsxs("span",{className:"iv-stage-min",children:[n.minutes,"min"]})]},n.id))}),e.jsxs("div",{className:`iv-main ${P?"with-code":""}`,children:[e.jsx("div",{className:"iv-chat-col",children:A?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"iv-messages",ref:H,children:[fe.map((n,h)=>e.jsxs("div",{className:`iv-msg ${n.role}`,children:[e.jsx("div",{className:"iv-msg-who",children:n.role==="assistant"?"面试官":"我"}),e.jsx("div",{className:"iv-msg-body",children:n.content})]},h)),d&&e.jsxs("div",{className:"iv-msg assistant",children:[e.jsx("div",{className:"iv-msg-who",children:"面试官"}),e.jsxs("div",{className:"iv-msg-body",children:[d,e.jsx("span",{className:"iv-caret",children:"▍"})]})]}),u&&!d&&e.jsxs("div",{className:"iv-msg assistant",children:[e.jsx("div",{className:"iv-msg-who",children:"面试官"}),e.jsx("div",{className:"iv-msg-body iv-thinking",children:"思考中…"})]})]}),j&&e.jsx("div",{className:"iv-error",children:j}),e.jsxs("div",{className:"iv-input-area",children:[e.jsx("textarea",{className:"iv-answer",value:m,onChange:n=>w(n.target.value),onKeyDown:n=>{n.key==="Enter"&&(n.ctrlKey||n.metaKey)&&(n.preventDefault(),F())},placeholder:E?"正在聆听，请说话…（识别结果会填到这里）":"输入你的回答，或点麦克风语音作答（Ctrl/⌘+Enter 发送）",rows:3,disabled:u}),e.jsxs("div",{className:"iv-input-actions",children:[e.jsx("button",{className:`iv-mic ${E?"on":""}`,onClick:de,disabled:u,title:"语音作答",children:E?"● 停止录音":"🎤 语音"}),e.jsx("div",{className:"iv-spacer"}),u&&e.jsx("button",{className:"btn btn-ghost ce-small",onClick:pe,children:"停止"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>F(),disabled:u||!m.trim(),children:"发送"})]}),e.jsxs("div",{className:"iv-quick",children:[e.jsx("button",{className:"iv-quick-btn",onClick:W,disabled:u,children:"进入编程环节 ⌨️"}),e.jsx("button",{className:"iv-quick-btn",onClick:me,disabled:u,children:"请面试官总结评价"}),e.jsx("button",{className:"iv-quick-btn primary",onClick:Y,disabled:u||O==="loading",children:O==="loading"?"正在生成报告…":"结束并生成评分报告 📄"})]})]})]}):e.jsxs("div",{className:"iv-prestart",children:[e.jsx("p",{children:"准备好了吗？点击下方按钮，面试官将先做自我介绍并请你介绍自己。"}),e.jsx("p",{className:"iv-sub",children:"全程约 1 小时，建议在安静环境、用 Chrome/Edge 浏览器以获得最佳语音体验。"}),e.jsx("button",{className:"btn btn-primary iv-start",onClick:ce,disabled:u,children:u?"面试官准备中…":"开始面试"})]})}),P&&e.jsxs("div",{className:"iv-code-col",children:[e.jsxs("div",{className:"iv-problem",children:[e.jsxs("div",{className:"iv-problem-head",children:[e.jsxs("h3",{children:[c==null?void 0:c.title," ",e.jsx("span",{className:`iv-diff ${c==null?void 0:c.difficulty}`,children:c==null?void 0:c.difficulty})]}),e.jsx("button",{className:"iv-quick-btn",onClick:()=>U(te()),children:"换一题"})]}),e.jsx("div",{className:"iv-problem-tags",children:((c==null?void 0:c.tags)||[]).map(n=>e.jsx("span",{className:"iv-tag",children:n},n))}),e.jsx("pre",{className:"iv-problem-body",children:c==null?void 0:c.statement}),(c==null?void 0:c.sampleInput)!=null&&e.jsxs("div",{className:"iv-sample",children:[e.jsxs("div",{children:[e.jsx("strong",{children:"示例输入"}),e.jsx("pre",{children:c.sampleInput})]}),e.jsxs("div",{children:[e.jsx("strong",{children:"示例输出"}),e.jsx("pre",{children:c.sampleOutput})]})]})]}),e.jsx(ke,{initialLang:"python",onSubmit:ue},c==null?void 0:c.id)]})]}),(O==="ready"||O==="error"||O==="loading")&&e.jsx("div",{className:"iv-modal-mask",onClick:()=>O!=="loading"&&s("idle"),children:e.jsxs("div",{className:"iv-modal",onClick:n=>n.stopPropagation(),children:[O==="loading"&&e.jsxs("div",{className:"iv-modal-loading",children:[e.jsx("div",{className:"iv-spin"}),e.jsx("p",{children:"面试评估官正在结合本次问答为你打分、撰写报告…"})]}),O==="error"&&e.jsxs("div",{className:"iv-modal-body",children:[e.jsx("h3",{children:"生成失败"}),e.jsx("div",{className:"iv-error",children:M}),e.jsxs("div",{className:"iv-modal-actions",children:[e.jsx("button",{className:"btn btn-ghost",onClick:()=>s("idle"),children:"关闭"}),e.jsx("button",{className:"btn btn-primary",onClick:Y,children:"重试"})]})]}),O==="ready"&&i&&e.jsxs("div",{className:"iv-modal-body",children:[e.jsxs("div",{className:"iv-report-grade",children:[e.jsx("div",{className:"iv-grade-badge",style:{background:_(i.grade).color},children:i.grade}),e.jsxs("div",{children:[e.jsx("div",{className:"iv-grade-label",style:{color:_(i.grade).color},children:_(i.grade).label}),e.jsx("div",{className:"iv-grade-desc",children:_(i.grade).desc})]})]}),e.jsx("p",{className:"iv-report-reason",children:i.gradeReason}),e.jsx("p",{className:"iv-report-summary",children:i.overallSummary}),e.jsx("p",{className:"iv-sub",children:"完整报告（含分维度评分、结合实例的亮点与不足、提升建议与课程推荐）可下载或在新窗口查看："}),e.jsxs("div",{className:"iv-modal-actions",children:[e.jsx("button",{className:"btn btn-ghost",onClick:()=>s("idle"),children:"关闭"}),e.jsx("button",{className:"btn btn-ghost",onClick:()=>De(I),children:"在新窗口打开"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>Le(I,`面试评估报告_${i.grade}.html`),children:"下载 HTML 报告"})]})]})]})})]})})}export{qe as default};
