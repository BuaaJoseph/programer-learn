import{r as x,j as e}from"./index-B0-Um9Xw.js";import{L as h,a as j,P as g,C as t,S as f}from"./Summary-CRXglwZ1.js";import{K as v}from"./KeyIdea-zCCzkW7I.js";import{E as u}from"./Example-Djk5fvs9.js";import{F as p}from"./Figure-DKg6w6XJ.js";const a={hungry:{label:"饿汉式",safe:!0,lazy:!1,desc:"类加载时就创建实例(static final)。线程安全、简单；缺点是不管用不用都创建，可能浪费。"},lazyBad:{label:"懒汉式(非线程安全)",safe:!1,lazy:!0,desc:"用时才创建，但多线程下可能创建出多个实例——错误示范。"},dcl:{label:"双重检查锁 DCL",safe:!0,lazy:!0,desc:"两次判空 + synchronized + volatile(防指令重排导致拿到半初始化对象)。懒加载且线程安全。"},holder:{label:"静态内部类",safe:!0,lazy:!0,desc:"利用类加载机制：外部类加载时不创建，调用 getInstance 才加载内部类。懒加载、线程安全、写法优雅。"},enum:{label:"枚举",safe:!0,lazy:!1,desc:"《Effective Java》推荐：天然线程安全、且能防反射和反序列化破坏单例。"}};function m(){const[l,o]=x.useState("dcl"),n=a[l],d=e.jsx(e.Fragment,{children:Object.entries(a).map(([s,i])=>e.jsx("button",{className:`fig-btn ${l===s?"active":""}`,onClick:()=>o(s),children:i.label.split("(")[0]},s))});return e.jsx(p,{caption:"单例保证一个类全局只有一个实例。五种写法各有取舍，面试重点是线程安全与懒加载：DCL 为什么要 volatile、静态内部类为什么优雅、枚举为什么最安全。",controls:d,children:e.jsxs("svg",{viewBox:"0 0 460 180",width:"460",role:"img","aria-label":"单例模式五种写法",children:[Object.entries(a).map(([s,i],c)=>{const r=l===s;return e.jsxs("g",{children:[e.jsx("rect",{x:"20",y:20+c*26,width:"180",height:"22",rx:"5",fill:r?"var(--accent)":"var(--bg-subtle)",stroke:r?"var(--accent-strong)":"var(--border)"}),e.jsx("text",{x:"30",y:35+c*26,fontFamily:"var(--mono)",fontSize:"10",fontWeight:r?"700":"400",fill:r?"#ffffff":"var(--ink)",children:i.label})]},s)}),e.jsxs("g",{transform:"translate(220 24)",children:[e.jsx("rect",{x:"0",y:"0",width:"100",height:"44",rx:"8",fill:n.safe?"var(--green-soft)":"var(--rose-soft)",stroke:n.safe?"var(--green)":"var(--rose)"}),e.jsx("text",{x:"50",y:"20",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"10",fill:"var(--ink-soft)",children:"线程安全"}),e.jsx("text",{x:"50",y:"36",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"13",fontWeight:"700",fill:n.safe?"var(--green)":"var(--rose)",children:n.safe?"✓":"✗"}),e.jsx("rect",{x:"110",y:"0",width:"100",height:"44",rx:"8",fill:n.lazy?"var(--green-soft)":"var(--bg-sunken)",stroke:n.lazy?"var(--green)":"var(--border-strong)"}),e.jsx("text",{x:"160",y:"20",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"10",fill:"var(--ink-soft)",children:"懒加载"}),e.jsx("text",{x:"160",y:"36",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"13",fontWeight:"700",fill:n.lazy?"var(--green)":"var(--ink-faint)",children:n.lazy?"✓":"✗"})]}),e.jsx("rect",{x:"220",y:"80",width:"210",height:"86",rx:"8",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsx("foreignObject",{x:"228",y:"84",width:"194",height:"80",children:e.jsxs("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"11px var(--sans)",color:"var(--ink)",lineHeight:1.35},children:[e.jsxs("strong",{style:{color:"var(--accent-strong)"},children:[n.label,"："]}),n.desc]})})]})})}const y=`// 饿汉式：类加载时就创建实例，天生线程安全，但不能懒加载
public class Hungry {

    // 类加载阶段由 JVM 保证只初始化一次，所以线程安全
    private static final Hungry INSTANCE = new Hungry();

    private Hungry() {}   // 私有构造，禁止外部 new

    public static Hungry getInstance() {
        return INSTANCE;
    }
}`,b=`// 懒汉式（非线程安全）：用时才创建，但多线程下会创建多个实例
public class Lazy {

    private static Lazy instance;

    private Lazy() {}

    public static Lazy getInstance() {
        // 两个线程可能同时通过这个 if，于是各 new 一个
        if (instance == null) {
            instance = new Lazy();
        }
        return instance;
    }
}`,C=`// 静态内部类：既懒加载又线程安全，推荐写法之一
public class Holder {

    private Holder() {}

    // 内部类不会随外部类加载而加载，
    // 只有第一次调用 getInstance 才会触发，实现懒加载
    private static class Inner {
        // 类初始化由 JVM 加锁保证，所以线程安全
        private static final Holder INSTANCE = new Holder();
    }

    public static Holder getInstance() {
        return Inner.INSTANCE;
    }
}`,S=`// 写法一：双重检查锁 DCL
public class Dcl {

    // volatile 必不可少：禁止指令重排，防止拿到半初始化对象
    private static volatile Dcl instance;

    private Dcl() {}

    public static Dcl getInstance() {
        if (instance == null) {               // 第一次检查：避免每次都加锁
            synchronized (Dcl.class) {
                if (instance == null) {       // 第二次检查：防止重复创建
                    instance = new Dcl();
                }
            }
        }
        return instance;
    }
}`,z=`// 写法二：枚举单例，最安全，天然防反射与反序列化
public enum EnumSingleton {

    INSTANCE;

    public void doSomething() {
        System.out.println("枚举单例在工作");
    }
}

// 使用：EnumSingleton.INSTANCE.doSomething();`;function N(){return e.jsxs(e.Fragment,{children:[e.jsx(h,{children:e.jsxs("p",{children:["单例模式（Singleton）要解决的问题只有一句话：",e.jsx("strong",{children:"保证一个类全局只有一个实例， 并提供一个访问它的入口"}),"。听起来简单，却是面试里被追问最深的一个—— 因为它把「私有构造、懒加载、线程安全、指令重排、反射攻击」这些硬核知识点全串了起来。"]})}),e.jsx("h2",{children:"单例的三个共同要件"}),e.jsxs("p",{children:["无论哪种写法，单例都离不开三件事：",e.jsx("strong",{children:"构造方法私有化"}),"（不让外部 new）、",e.jsx("strong",{children:"类内部自己持有唯一实例"}),"、",e.jsx("strong",{children:"对外暴露一个静态获取方法"}),"。 各种写法的差异，本质都在回答两个问题：实例什么时候创建（懒不懒）、多线程下安不安全。"]}),e.jsx("h3",{children:"饿汉式：简单但不懒"}),e.jsxs("p",{children:["实例在类加载时就创建好。JVM 保证类只初始化一次，所以",e.jsx("strong",{children:"天生线程安全"}),"。 缺点是无论用不用都先创建，",e.jsx("strong",{children:"不能懒加载"}),"，可能浪费资源。"]}),e.jsx("h3",{children:"懒汉式：懒但不安全"}),e.jsxs("p",{children:["第一次调用才创建，实现了懒加载，但裸写的判空在多线程下会",e.jsx("strong",{children:"同时通过 if 各创建一个"}),"， 破坏了单例。直接加 ",e.jsx("code",{children:"synchronized"})," 到方法上能解决，但每次获取都加锁，性能差。"]}),e.jsx("h3",{children:"双重检查锁 DCL：为什么必须 volatile"}),e.jsxs("p",{children:["DCL 用两次判空把加锁缩小到「第一次创建」那一瞬间，兼顾性能与安全。关键的坑在",e.jsx("code",{children:"volatile"}),"：",e.jsx("code",{children:"instance = new Dcl()"})," 这一行不是原子的， 它包含「分配内存、初始化对象、把引用指向内存」三步，JVM 可能",e.jsx("strong",{children:"指令重排"}),"， 让「引用先指向内存」而「对象还没初始化完」。此时另一个线程在第一次判空里看到 instance 非空就直接返回，拿到的却是",e.jsx("strong",{children:"半初始化对象"}),"。 加 ",e.jsx("code",{children:"volatile"})," 禁止这种重排，问题才彻底解决。"]}),e.jsx("h3",{children:"静态内部类：又懒又安全"}),e.jsxs("p",{children:["把实例放进一个静态内部类里。外部类加载时",e.jsx("strong",{children:"不会"}),"加载内部类，只有第一次调用 getInstance 引用到内部类，才触发它的初始化——这就实现了懒加载。 而类的初始化过程由 JVM 加锁保证只执行一次，所以又天然线程安全。写法干净，强烈推荐。"]}),e.jsx("h3",{children:"枚举：最安全的写法"}),e.jsxs("p",{children:["《Effective Java》力荐的写法。枚举由 JVM 保证实例唯一且线程安全，更重要的是它能",e.jsx("strong",{children:"天然防反射和防反序列化"}),"：反射创建枚举会被 JDK 主动抛异常， 反序列化也由 JVM 保证返回同一个枚举实例。其他写法都需要额外手段才能堵这两个漏洞。"]}),e.jsx(u,{title:"五种写法对比",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"饿汉式"})," · 线程安全，",e.jsx("strong",{children:"不"}),"懒加载"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"懒汉式（裸）"})," · 懒加载，",e.jsx("strong",{children:"非"}),"线程安全"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"DCL"})," · 懒加载 + 线程安全（必须 volatile）"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"静态内部类"})," · 懒加载 + 线程安全，写法最优雅"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"枚举"})," · 线程安全 + 防反射 / 防反序列化，最安全"]})]})}),e.jsx(m,{}),e.jsx(v,{title:"volatile 防的是「半成品对象」",children:e.jsxs("p",{children:["DCL 里 volatile 的作用常被误说成「保证可见性」。更精确地说，这里它真正解决的是",e.jsx("strong",{children:"指令重排导致的安全发布问题"}),"：禁止「引用赋值」越过「对象初始化」提前发生， 从而保证任何线程看到非空 instance 时，对象一定",e.jsx("strong",{children:"已经完整初始化"}),"。 这是 DCL 面试的标准追问，答出「半初始化对象」这五个字就拿分了。"]})}),e.jsx(j,{variant:"warn",title:"单例不是想用就用",children:e.jsxs("p",{children:["单例把对象生命周期变成全局可见，容易变成",e.jsx("strong",{children:"变相的全局变量"}),"， 带来隐式依赖、难以单元测试、状态共享引发并发问题等隐患。 配置类、连接池、日志器这类「确实全局唯一且无状态或状态可控」的对象才适合用单例， 普通业务对象别滥用。"]})}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["实际开发里我们很少手写单例，因为 ",e.jsx("strong",{children:"Spring 的 Bean 默认就是单例"}),"（singleton 作用域）， 容器帮你保证唯一性，各种 ",e.jsx("code",{children:"@Configuration"})," 配置类、Service、连接池都靠它管理。 面试被问「单例怎么写」，建议主线答",e.jsx("strong",{children:"静态内部类"}),"（优雅）和",e.jsx("strong",{children:"枚举"}),"（最安全）， 再用 DCL 的 volatile 展示你懂底层，最后点一句「工程里一般交给 Spring」。"]}),e.jsxs(g,{title:"手写 DCL 与枚举两种单例",children:[e.jsxs("p",{children:["下面是面试最常要求手写的两种：双重检查锁与枚举。重点记住 DCL 的两次判空和那个 关键的 ",e.jsx("code",{children:"volatile"}),"，以及枚举写法为何能一行解决所有安全问题。"]}),e.jsx(t,{lang:"java",title:"双重检查锁 DCL",code:S}),e.jsx(t,{lang:"java",title:"枚举单例",code:z}),e.jsx("p",{children:"对照参考：饿汉、懒汉、静态内部类三种写法的骨架如下，注意它们在懒加载与线程安全上的取舍。"}),e.jsx(t,{lang:"java",title:"饿汉式",code:y}),e.jsx(t,{lang:"java",title:"懒汉式（非线程安全）",code:b}),e.jsx(t,{lang:"java",title:"静态内部类",code:C})]}),e.jsx(f,{points:["单例三要件：私有构造、内部持有唯一实例、对外暴露静态获取方法，差异都在懒加载与线程安全的取舍。","饿汉式线程安全但不懒；裸懒汉式懒加载但非线程安全，会创建多个实例。","DCL 用两次判空把加锁缩到创建瞬间，volatile 必不可少，作用是禁止指令重排、防止拿到半初始化对象。","静态内部类利用「内部类延迟加载 + JVM 类初始化加锁」做到又懒又安全，是最优雅的写法。","枚举单例最安全，天然防反射与反序列化，是《Effective Java》推荐的首选。","工程中很少手写单例，Spring Bean 默认即单例，配置类、连接池、日志器是典型应用场景。"]})]})}export{N as default};
