import{j as e}from"./index-CBMe5udE.js";import{L as o,S as n}from"./Summary-CEfAQ4SZ.js";import{K as s}from"./KeyIdea-K3hFePn1.js";import{C as r}from"./Callout-3wJQ5WDp.js";import{C as d}from"./CodeBlock-D4LRiuTl.js";import{E as i}from"./Example-CFOi3F9j.js";const c=`import type { AssistantTurn, Message } from '../types.js'
import type { Tool } from '../tools/types.js'

export interface CompleteParams {
  system: string
  messages: Message[]
  tools: Tool[]
  maxTokens: number
  /** 流式文本回调：每收到一段增量文本就调用一次。用于让回答逐字蹦出来。 */
  onTextDelta?: (delta: string) => void
}

export interface Provider {
  /** 这个 provider 当前使用的模型标识，用于展示与日志。 */
  readonly model: string
  /** 这个模型的上下文窗口大小（token 数），用于 token 预算与自动压缩。 */
  readonly contextWindow: number
  /** 发一轮请求，拿回模型这一轮的完整回复。 */
  complete(params: CompleteParams): Promise<AssistantTurn>
  /** 估算给定 system + messages + tools 会占用多少输入 token（用于预算）。 */
  countTokens(params: Omit<CompleteParams, 'onTextDelta' | 'maxTokens'>): Promise<number>
}`,t=`export const DEFAULT_MODEL = 'claude-opus-4-8'

export class ClaudeProvider implements Provider {
  readonly model: string
  readonly contextWindow: number
  // …构造时读 model/contextWindow，apiKey 不传则走环境变量
}`,l=`import type { Provider } from './types.js'
import { ClaudeProvider } from './claude.js'

// Provider 工厂：把「选哪个 LLM」收敛到一处。默认 Claude，新增 Provider 只需在这里注册一行。
// 主循环、工具、CLI 都只依赖 Provider 接口，不关心背后是谁——这就是薄抽象层的价值。
export interface ProviderConfig {
  provider?: string
  model?: string
  contextWindow?: number
}

export function createProvider(cfg: ProviderConfig = {}): Provider {
  const name = cfg.provider ?? 'claude'
  switch (name) {
    case 'claude':
      return new ClaudeProvider({ model: cfg.model, contextWindow: cfg.contextWindow })
    case 'bailian':
      // 百炼（阿里云 DashScope）：OpenAI 兼容接口，默认 Qwen 模型。
      return new BailianProvider({ model: cfg.model, contextWindow: cfg.contextWindow })
    default:
      throw new Error(\`未知 provider「\${name}」。目前内置：claude、bailian。新增 provider 只需实现 Provider 接口并在 createProvider 注册。\`)
  }
}

export type { Provider } from './types.js'`,h=`// ❌ 反例：内核直接依赖具体 SDK，厂商方言外溢到主循环里。
import Anthropic from '@anthropic-ai/sdk'

async function agentLoop(messages: Message[]) {
  const client = new Anthropic()                 // 主循环知道了「我在用 Anthropic」
  const stream = client.messages.stream({        // Anthropic 专有的 API 形状
    model: 'claude-opus-4-8',
    max_tokens: 8192,
    messages: toAnthropicMessages(messages),     // 翻译逻辑散落在主循环
  })
  // …想换成别家？整个主循环都要改
}`,x=`// ✅ 正例：内核只依赖抽象，具体实现由外部注入（依赖倒置）。
class Agent {
  constructor(private provider: Provider) {}      // 只认接口，不认厂商
  async loop(messages: Message[]) {
    const turn = await this.provider.complete({    // 调的是抽象方法
      system, messages, tools, maxTokens,
    })
    // …换厂商？换的是构造时传进来的那个 provider，loop 一行不动
  }
}`,a=`// 测试用的假 Provider：不发任何网络请求，直接返回预设回复。
// 因为内核只依赖 Provider 接口，测试时把真实现换成它即可。
class FakeProvider implements Provider {
  readonly model = 'fake-model'
  readonly contextWindow = 200_000
  constructor(private scripted: AssistantTurn[]) {}
  async complete(): Promise<AssistantTurn> {
    return this.scripted.shift() ?? { content: [{ type: 'text', text: '(空)' }] }
  }
  async countTokens(): Promise<number> {
    return 0 // 测试里不关心真实 token 数
  }
}

// 于是可以脱离网络、零成本、毫秒级地测主循环的行为：
const agent = new Agent({ provider: new FakeProvider([scriptedTurn]) })`;function u(){return e.jsxs("article",{children:[e.jsxs(o,{children:["从卷 1 起，我们写主循环时其实就偷偷做了一件正确的事：把「调用 LLM」这件事，从来没有写成直接 new 一个 Anthropic 客户端， 而是收敛进了一个叫 ",e.jsx("code",{children:"Provider"})," 的接口。主循环、工具调用、CLI——它们谁都不知道背后跑的是 Claude 还是别的什么。 这一章我们把这层抽象彻底讲透，再加一个工厂 ",e.jsx("code",{children:"createProvider"}),"，做到三件事：按配置选 Provider、换模型不动主循环、新增 Provider 只加一行。"]}),e.jsx("h2",{children:"回顾：为什么一开始就抽象"}),e.jsxs("p",{children:["回看前面所有卷的代码，你会发现一个一以贯之的纪律：内核从不直接依赖 Anthropic SDK。 主循环需要发请求，它调的是 ",e.jsx("code",{children:"provider.complete(...)"}),"；token 预算要算占用，调的是 ",e.jsx("code",{children:"provider.countTokens(...)"}),"； 要展示「当前用的是什么模型」，读的是 ",e.jsx("code",{children:"provider.model"}),"；自动压缩要知道窗口多大，读的是 ",e.jsx("code",{children:"provider.contextWindow"}),"。 整个内核眼里只有这四样东西，从来不关心它们背后是 ",e.jsx("code",{children:"messages.stream"})," 还是别的什么 HTTP 调用。"]}),e.jsxs(s,{children:["薄抽象层 = 内核与具体厂商解耦。主循环、工具、CLI 全都只依赖 ",e.jsx("code",{children:"Provider"})," 接口（",e.jsx("code",{children:"model"})," / ",e.jsx("code",{children:"contextWindow"})," /"," ",e.jsx("code",{children:"complete"})," / ",e.jsx("code",{children:"countTokens"}),"），不关心背后是 Claude 还是别人。换模型、换厂商，核心逻辑一行都不用碰。"]}),e.jsxs("p",{children:["这件事在软件工程里有个正式名字：",e.jsx("strong",{children:"依赖倒置原则"}),"（Dependency Inversion Principle，SOLID 里的 D）。它说的是——高层模块（我们的主循环、Agent 逻辑）不该依赖低层模块（某家厂商的 SDK），两者都该依赖于",e.jsx("strong",{children:"抽象"}),"（",e.jsx("code",{children:"Provider"})," 接口）。直觉上「主循环要调 LLM，所以它依赖 Anthropic SDK」是自然的，但这恰恰是把依赖箭头指错了方向。看看下面这组正反对比，差别一眼就出来："]}),e.jsx(d,{lang:"ts",title:"反例：内核直接依赖 SDK",code:h}),e.jsx(d,{lang:"ts",title:"正例：内核依赖抽象，实现外部注入",code:x}),e.jsxs("p",{children:["反例里，",e.jsx("code",{children:"Anthropic"})," 这个名字、",e.jsx("code",{children:"messages.stream"})," 的形状、",e.jsx("code",{children:"max_tokens"})," 这种蛇形命名的参数，全都",e.jsx("strong",{children:"泄进"}),"了主循环。换厂商，意味着主循环要跟着改。正例里，",e.jsx("code",{children:"Agent"})," 构造时被「注入」一个 ",e.jsx("code",{children:"Provider"}),"，它压根不知道、也不需要知道这个 provider 背后是谁——这就是「倒置」：让具体去适配抽象，而不是让抽象去迁就具体。"]}),e.jsxs(r,{variant:"tip",children:["判断一层抽象有没有真正解耦，有个简单的检验：",e.jsx("strong",{children:"在内核代码里搜一下厂商的名字"}),"。如果 ",e.jsx("code",{children:"grep -r 'anthropic'"})," 只在 ",e.jsx("code",{children:"provider/claude.ts"})," 这一个文件里命中，主循环、工具、CLI 全都干净，那这层抽象就立住了。一旦厂商名字开始在内核到处出现，抽象就已经漏了——这是个比任何文档都诚实的健康度指标。"]}),e.jsx("h2",{children:"接口本体：一个 Provider 必须能做的事"}),e.jsx("p",{children:"先看接口的逐字定义。注意它有多薄——对外暴露的只有四样东西，外加一个可选的流式回调。这就是「成为一个 Provider」的全部门槛。"}),e.jsx(d,{lang:"ts",title:"src/provider/types.ts",code:c}),e.jsxs("p",{children:[e.jsx("code",{children:"CompleteParams"})," 描述「发一轮请求要带什么」：系统提示、历史消息、可用工具、本轮最大输出 token，以及一个可选的"," ",e.jsx("code",{children:"onTextDelta"})," 流式回调，让模型的回答能逐字蹦出来而不是憋到最后一次性出现。",e.jsx("code",{children:"Provider"})," 接口本身只有两个只读属性和两个方法。任何模型——不管它是 Claude、是 OpenAI、还是你本地跑的开源模型—— 只要能实现这四样，就能直接插进 forge 跑起来。"]}),e.jsx("h2",{children:"为什么是「薄」抽象，而不是大而全"}),e.jsxs("p",{children:["这层接口刻意做得很薄，这是个值得展开的设计决策。设计抽象层时永远存在一组张力：",e.jsx("strong",{children:"抽象越厚，能暴露的统一能力越多，但能容纳的实现就越少"}),"。如果我们贪心地把「thinking 块」「prompt 缓存」「图片输入」「结构化输出」全塞进接口，那任何一个不支持这些特性的模型就再也无法实现这个接口了——抽象反而成了枷锁。"]}),e.jsxs("p",{children:["薄抽象走的是相反的路：只收敛",e.jsx("strong",{children:"所有 LLM 都必然具备"}),"的最小公共能力——发一轮请求、估算 token、报上自己的型号和窗口。这条最小公共子集几乎对任何对话模型都成立，所以接口的「可实现性」最大。各家独有的高级特性怎么办？答案是",e.jsx("strong",{children:"留在各自的 Provider 实现内部"}),"，作为内部优化（比如 ClaudeProvider 内部该用 prompt 缓存就用，但这事不进接口）。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{}),e.jsx("th",{children:"薄抽象（forge 的选择）"}),e.jsx("th",{children:"厚抽象"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"接口表面积"}),e.jsx("td",{children:"4 样：model / window / complete / countTokens"}),e.jsx("td",{children:"几十个特性方法"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"新增 Provider 成本"}),e.jsx("td",{children:"低（填四样即可）"}),e.jsx("td",{children:"高（很多方法要硬塞或抛 not-supported）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能统一暴露的能力"}),e.jsx("td",{children:"最小公共子集"}),e.jsx("td",{children:"多，但脆弱"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"厂商差异藏在哪"}),e.jsx("td",{children:"各自实现内部"}),e.jsx("td",{children:"容易漏进接口，污染内核"})]})]})]}),e.jsxs(r,{variant:"tip",children:["这有个经典对照：操作系统的设备驱动接口。系统不会为每种打印机的花式功能定义专门的 API——它只定义「写一段字节」这种最小契约，把彩印、双面、装订这些差异关在各家驱动里。",e.jsx("code",{children:"Provider"})," 之于 LLM，正如驱动接口之于硬件：",e.jsx("strong",{children:"用最薄的契约换最广的兼容"}),"。"]}),e.jsx("h2",{children:"默认实现：ClaudeProvider"}),e.jsxs("p",{children:[e.jsx("code",{children:"ClaudeProvider"})," 是这个接口的默认实现，它在卷 0、卷 2、卷 4 里被一步步建成。它的职责说白了就是「翻译」： 把 forge 内部的 ",e.jsx("code",{children:"Message"})," / ",e.jsx("code",{children:"Tool"})," 形状翻译成 Anthropic SDK 认识的形状，调用 ",e.jsx("code",{children:"messages.stream"})," 拿到流式结果， 再把结果翻译回 forge 内部的 ",e.jsx("code",{children:"AssistantTurn"}),"。所有 Anthropic 特有的「方言」——参数名、消息块结构、thinking 块的处理——都被关在这一个类里。"]}),e.jsxs(r,{variant:"note",children:["所有厂商方言都收在 ",e.jsx("code",{children:"claude.ts"})," 这一个文件里。这是抽象的关键纪律：具体厂商的怪癖只允许出现在它自己的 Provider 实现中， 绝不外溢到主循环或工具层。所以以后加新厂商，写的是一个新文件，不会污染任何已有代码。"]}),e.jsx("p",{children:"这里贴一小段它的类声明示意，让你对它的样子有个印象："}),e.jsx(d,{lang:"ts",title:"src/provider/claude.ts（节选）",code:t}),e.jsx("h2",{children:"工厂：把「选哪个 Provider」收敛到一处"}),e.jsxs("p",{children:["有了接口和实现，还差一个问题：运行时到底实例化哪个 Provider？答案不该散落在各处，而该收敛到一个工厂函数里。下面是 ",e.jsx("code",{children:"src/provider/index.ts"})," 的完整内容。"]}),e.jsx(d,{lang:"ts",title:"src/provider/index.ts",code:l}),e.jsxs("p",{children:[e.jsx("code",{children:"createProvider"})," 按配置里的 ",e.jsx("code",{children:"provider"})," 字段选实现，缺省就是 ",e.jsx("code",{children:"claude"}),"； 碰到不认识的名字，它给出一句清晰的报错，并直接告诉调用者扩展方式（实现接口 + 注册一行）。 这正是上一章 ",e.jsx("code",{children:"loadConfig"})," 跑完之后该调用它的地方：配置负责「想要什么」，工厂负责「把它造出来」。"]}),e.jsxs(i,{title:"新增一个 Provider 要改哪里（以接入阿里云百炼为例）",children:[e.jsxs("p",{children:["这不是假设——forge 已经按这个套路接入了",e.jsx("strong",{children:"阿里云百炼（DashScope，Qwen 系列）"}),"。 百炼提供 OpenAI 兼容接口，所以新 Provider 内部用 OpenAI SDK、把 forge 的消息/工具翻译成 OpenAI 格式即可。需要动的地方一共两处："]}),e.jsxs("ol",{children:[e.jsxs("li",{children:["新建一个 class ",e.jsx("code",{children:"BailianProvider"}),"（在 ",e.jsx("code",{children:"src/provider/bailian.ts"}),"），实现 ",e.jsx("code",{children:"Provider"})," 接口——把 ",e.jsx("code",{children:"model"})," / ",e.jsx("code",{children:"contextWindow"})," / ",e.jsx("code",{children:"complete"})," / ",e.jsx("code",{children:"countTokens"})," 这四样填上，把「OpenAI 兼容协议」这套方言全收在这个文件里。"]}),e.jsxs("li",{children:["在 ",e.jsx("code",{children:"createProvider"})," 的 ",e.jsx("code",{children:"switch"})," 里加一个 ",e.jsx("code",{children:"case 'bailian'"}),"，把名字映射到新 class（就是上面代码里那一行）。"]})]}),e.jsxs("p",{children:["就这样。之后只要在配置里写 ",e.jsx("code",{children:'"provider": "bailian", "model": "qwen-max"'}),"，forge 就换用 Qwen 跑了。 主循环、工具、CLI、权限系统、上下文压缩——一行都不用动。它们只认 ",e.jsx("code",{children:"Provider"})," 接口，根本感知不到背后从 Claude 换成了 Qwen。 这就是当初忍着不写「直接 new 一个客户端」、坚持先抽象的回报。"]})]}),e.jsx("h2",{children:"白捡的好处：可测试性"}),e.jsxs("p",{children:["当初为解耦而引入的 ",e.jsx("code",{children:"Provider"})," 接口，还顺手带来一个常被低估的红利：",e.jsx("strong",{children:"主循环变得极易测试"}),"。LLM 调用是出了名的「难测」——它走网络（慢、要联网）、花真金白银（每次调用都计费）、而且",e.jsx("strong",{children:"不确定"}),"（同样的输入，回复可能不一样）。如果主循环直接 new 一个真客户端，那「测一遍主循环逻辑」就等于「真的发一次请求」，慢、贵、还不可复现。"]}),e.jsxs("p",{children:["但因为内核只依赖 ",e.jsx("code",{children:"Provider"})," 接口，我们可以在测试里塞一个",e.jsx("strong",{children:"假 Provider"}),"（测试替身 / test double）：它不发任何请求，直接返回我们预先写好的回复脚本。"]}),e.jsx(d,{lang:"ts",title:"test/fake-provider.ts",code:a}),e.jsxs("p",{children:["于是测「模型要求调工具时，主循环会不会正确执行工具、把结果回灌、再发下一轮」这类逻辑，变成了一个毫秒级、零成本、完全确定的纯逻辑测试——你用脚本精确控制「模型这一轮会说什么」，断言主循环的反应。这就是依赖倒置的连锁回报：",e.jsx("strong",{children:"为换厂商而做的解耦，自动也把「难测的外部依赖」变成了「可注入的可控对象」。"}),"好的抽象往往是这样，你为一个目的引入它，却在别处反复收到红利。"]}),e.jsxs(r,{variant:"note",children:["这呼应一个更普适的经验：",e.jsx("em",{children:"难测，常常是耦合过紧的症状。"}),"当你发现某段逻辑「没法不联网/不动数据库就测」，先别急着写 mock，回头看看是不是依赖箭头指错了方向——把硬依赖换成可注入的接口，可测性往往自然就来了。"]}),e.jsx("h2",{children:"呼应 /model 命令"}),e.jsxs("p",{children:["还记得卷 2 里那个 ",e.jsx("code",{children:"/model"})," 命令吗？它能在会话进行中切换模型。现在你应该看穿它的本质了：它做的事， 无非就是 ",e.jsx("code",{children:"new"})," 一个新的 Provider，然后通过 ",e.jsx("code",{children:"agent.setProvider(...)"})," 塞回 agent。 老的对话历史照旧，下一轮请求自动走新模型。"]}),e.jsxs(r,{variant:"tip",children:["运行时换模型（",e.jsx("code",{children:"/model"}),"）和启动时按配置选模型（",e.jsx("code",{children:"createProvider"}),"），走的是同一套抽象。 前者是「换一个 Provider 实例」，后者是「造第一个 Provider 实例」，落点都是同一个 ",e.jsx("code",{children:"Provider"})," 接口。一套抽象，两个入口。"]}),e.jsx("h2",{children:"厂商差异有多大：抽象成本藏在哪"}),e.jsxs("p",{children:["别天真地以为所有厂商长得一样。统一的接口背后，各家在协议层面的差异其实相当大，而",e.jsx("strong",{children:"这些差异并没有凭空消失，只是被搬进了各自的 Provider 实现里"}),"。下面这张表能让你具体感受「ClaudeProvider 和 BailianProvider 内部到底要消化掉哪些不同」："]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"Anthropic（Claude）"}),e.jsx("th",{children:"OpenAI 兼容（百炼 / Qwen 等）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"消息角色"}),e.jsx("td",{children:"system 独立成参数"}),e.jsx("td",{children:"system 作为 messages 里的一条"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"工具调用块"}),e.jsx("td",{children:"tool_use / tool_result 块"}),e.jsx("td",{children:"tool_calls 字段 + role:tool 消息"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"思考过程"}),e.jsx("td",{children:"原生 thinking 块"}),e.jsx("td",{children:"多数不支持或形式不同"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"token 计数"}),e.jsx("td",{children:"有专门的计数端点"}),e.jsx("td",{children:"常只能本地估算"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"流式事件"}),e.jsx("td",{children:"content_block_delta 等结构"}),e.jsx("td",{children:"OpenAI 的 chunk/delta 结构"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"参数命名"}),e.jsx("td",{children:"maxTokens 风格（SDK 内）"}),e.jsx("td",{children:"max_tokens 蛇形"})]})]})]}),e.jsxs(r,{variant:"warn",children:["关键纪律：",e.jsx("strong",{children:"抽象不是没有成本，成本被你藏进了各自的 Provider 文件里，换来的是内核的纯净。"}),"每个 Provider 实现都要在内部把上表这些差异翻译干净，对外却必须保持那个统一的、薄薄的接口。 所以衡量一个 Provider 写得好不好，标准不是「它支持多少特性」，而是「它有没有把所有厂商怪癖都关在自己这一个文件里、没有一丝外溢」。"]}),e.jsxs(r,{variant:"note",children:[e.jsx("strong",{children:"一个常见误区：以为薄抽象 = 功能阉割。"}),"不是的。薄的是",e.jsx("em",{children:"接口"}),"，不是",e.jsx("em",{children:"实现"}),"。ClaudeProvider 内部完全可以用上 prompt 缓存、thinking、图片输入等全部高级特性——只要这些是它「在统一契约下的内部优化」，对外仍只暴露那四样。换句话说：用最强的实现，藏在最薄的接口后面。"]}),e.jsx("h2",{children:"卷内衔接"}),e.jsxs("p",{children:["把这一章和上一章连起来看：",e.jsx("strong",{children:"配置"}),"负责回答「选什么」（哪个 provider、哪个 model、多大窗口），",e.jsx("strong",{children:"Provider 抽象"}),"负责回答「怎么换」（统一接口 + 工厂）。两者合起来，forge 就不再被锁死在任何一个模型或厂商上了。"]}),e.jsx(s,{children:"配置（选什么）+ Provider 抽象（怎么换）= forge 不被任何单一模型绑架。模型只是一个可插拔的零件，而不是写死在内核里的依赖。"}),e.jsx("p",{children:"下一章我们把「可扩展」这件事从模型本身延伸到工具生态：接入 MCP（Model Context Protocol）， 让 forge 能动态挂载外部工具服务器。如果说 Provider 让你能换「大脑」，那 MCP 就是让你能换「手」。"}),e.jsx(n,{points:["forge 从卷 1 起就把「调用 LLM」收敛进 Provider 接口，内核只认 model / contextWindow / complete / countTokens 四样东西。","Provider 接口很薄：两个只读属性 + complete/countTokens 两个方法，外加可选的 onTextDelta 流式回调。","ClaudeProvider 是默认实现，职责是把 forge 形状翻译成 Anthropic SDK 形状再翻译回来；所有厂商方言都关在 claude.ts 一个文件里。","createProvider 工厂按配置的 provider 字段选实现，默认 claude，未知名字给出清晰报错并指明扩展方式。","新增 Provider 只需两步：实现接口、在 switch 加一个 case；主循环/工具/CLI/权限/压缩一行不动。","/model 运行时换模型和启动时按配置选模型走同一套抽象，落点都是 Provider 接口。","厂商差异（thinking、token 计数、流式结构）由各自 Provider 实现内部消化，对外保持统一接口——这是抽象的难点也是它的价值。","配置（选什么）+ Provider 抽象（怎么换）让 forge 不被单一模型锁死；下一章用 MCP 把扩展从模型延伸到工具生态。"]})]})}export{u as default};
