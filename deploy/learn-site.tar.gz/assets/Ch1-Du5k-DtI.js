import{j as e}from"./index-BdVncPlI.js";import{L as d,S as n}from"./Summary-Baiwq3-G.js";import{K as i}from"./KeyIdea-Cnr-5ipR.js";import{C as s}from"./Callout-BRUKkrb4.js";import{C as r}from"./CodeBlock-DCdshbU5.js";import{E as c}from"./Example-phQ905Fb.js";const l=`import { resolve } from 'node:path'
import type { Tool } from './tools/types.js'

// 权限模型：每次工具调用执行前，先由权限策略裁定 allow / ask / deny。
// 设计原则：只读放行、写操作问一句、明确危险的直接拒绝（Deny > Ask > Allow）。

export type Decision = 'allow' | 'ask' | 'deny'

export interface PermissionResult {
  decision: Decision
  /** 给人看的理由 / 这次操作的摘要，用于确认提示与审计。 */
  reason: string
}

// 一眼就该拒绝的破坏性命令（宁可误伤，也不让 Agent 误删整台机器）。
const DESTRUCTIVE = [
  /\\brm\\s+-[a-z]*r[a-z]*f?\\b.*(\\/|~|\\*)/, // rm -rf / 之类
  /\\bmkfs\\b/,
  /\\bdd\\b.*\\bof=\\/dev\\//,
  /:\\(\\)\\s*\\{.*\\}\\s*;:/, // fork bomb
  /\\bshutdown\\b|\\breboot\\b/,
  />\\s*\\/dev\\/sd/,
]

export interface PermissionPolicy {
  decide(tool: Tool, input: Record<string, unknown>, cwd: string): PermissionResult
}

// 默认策略。后续「扩展性」卷会让它可由配置文件覆盖（按工具/参数加白名单等）。
export const defaultPolicy: PermissionPolicy = {
  decide(tool, input, cwd) {
    // 1) 只读工具：永远放行。
    if (tool.readOnly) return { decision: 'allow', reason: \`\${tool.name}（只读）\` }

    // 2) bash：按命令内容分级。
    if (tool.name === 'bash') {
      const cmd = String(input.command ?? '')
      if (DESTRUCTIVE.some((re) => re.test(cmd))) {
        return { decision: 'deny', reason: \`疑似破坏性命令，已拒绝：\${cmd}\` }
      }
      return { decision: 'ask', reason: \`执行命令：\${cmd}\` }
    }

    // 3) write / edit：写到 .git 或工作目录之外，直接拒绝；否则问一句。
    if (tool.name === 'write' || tool.name === 'edit') {
      const path = String(input.path ?? '')
      const abs = resolve(cwd, path)
      if (path.includes('.git/') || path.startsWith('.git')) {
        return { decision: 'deny', reason: \`拒绝写入 .git 目录：\${path}\` }
      }
      if (!abs.startsWith(resolve(cwd))) {
        return { decision: 'deny', reason: \`拒绝写到工作目录之外：\${path}\` }
      }
      return { decision: 'ask', reason: \`\${tool.name === 'write' ? '写入' : '修改'}文件：\${path}\` }
    }

    // 4) 其它写工具：保守起见，问一句。
    return { decision: 'ask', reason: \`执行 \${tool.name}\` }
  },
}`,o=`// 规则匹配的「最具体优先」示意（卷 6 配置化后的形态）：
// 一条命令可能同时命中多条规则，谁说了算？答案是：deny 永远压过 allow，
// 同档之间则「更具体的规则」覆盖「更宽泛的规则」。
const rules = [
  { match: 'bash:*',            decision: 'ask'   },  // 兜底：所有 bash 默认问
  { match: 'bash:git *',        decision: 'allow' },  // 放宽：git 子命令信得过
  { match: 'bash:git push *',   decision: 'ask'   },  // 收窄：但 push 还是要问
  { match: 'bash:rm -rf *',     decision: 'deny'  },  // 红线：删除直接拒
]

// 对 "git push origin main" 求值：
//   命中 bash:*（ask）、bash:git *（allow）、bash:git push *（ask）
//   按「最具体优先」→ ask 胜出。
// 对 "rm -rf node_modules" 求值：
//   命中 bash:*（ask）、bash:rm -rf *（deny）
//   deny 一票否决 → deny 胜出。`,t=`// 白名单陷阱：看起来人畜无害的前缀匹配，能被轻松绕过。
// 假设你给 "git" 开了白名单（git 我还信不过吗？），于是写了：
if (cmd.startsWith('git ')) return { decision: 'allow', reason: 'git 命令放行' }

// 但下面这些「都以 git 开头」的命令，全都被静默放行了：
//   git commit -m "x"; rm -rf /          ← 分号串了第二条命令
//   git log --oneline | sh               ← 管道把日志喂给 shell
//   git -c core.pager='rm -rf ~' log     ← 用 -c 注入恶意 pager
//   git diff $(rm -rf /)                 ← 命令替换在参数里执行
// 教训：基于「整条命令字符串」的前缀/正则白名单，在 shell 面前几乎必然漏。
// shell 的元字符（; | & $() \`\` 换行）让「这条命令到底会执行什么」无法靠字面判断。`,h=`// —— 安全闸门：执行前先过权限策略 ——
const verdict = this.policy.decide(tool, call.input, this.ctx.cwd)
this.audit.log({ type: 'permission', tool: tool.name, input: call.input, decision: verdict.decision, reason: verdict.reason })
if (verdict.decision === 'deny') {
  const msg = \`已被权限策略拒绝：\${verdict.reason}\`
  this.onEvent?.({ type: 'tool_end', name: call.name, output: msg, isError: true })
  return { type: 'tool_result', tool_use_id: call.id, content: msg, is_error: true }
}
if (verdict.decision === 'ask') {
  const approved = this.confirm ? await this.confirm({ tool: tool.name, input: call.input, reason: verdict.reason }) : false
  this.audit.log({ type: 'confirm', tool: tool.name, reason: verdict.reason, approved })
  if (!approved) {
    const msg = '用户拒绝了这次操作。'
    this.onEvent?.({ type: 'tool_end', name: call.name, output: msg, isError: true })
    return { type: 'tool_result', tool_use_id: call.id, content: msg, is_error: true }
  }
}`;function u(){return e.jsxs("article",{children:[e.jsx(d,{children:e.jsxs("p",{children:["卷 1 里，模型说要调哪个工具，",e.jsx("code",{children:"execOne"})," 就老老实实去执行：要 ",e.jsx("code",{children:"write"})," 就写、要 ",e.jsx("code",{children:"bash"})," 就跑。 这在你自己玩玩时没问题，可一旦这个 Agent 真能动你的文件、真能在你的机器上敲 shell，事情就严肃了—— 它可能误删一整个目录、把没提交的改动覆盖掉、甚至往 ",e.jsx("code",{children:".git"})," 里乱写把仓库搞坏。 卷 3 要在「模型决定调用」和「真正执行」之间插进一道安全闸门。本章先把这道闸门的大脑——",e.jsx("strong",{children:"权限模型"}),"造出来。"]})}),e.jsx("h2",{children:"为什么需要权限"}),e.jsxs("p",{children:["模型不是恶意的，但它会犯错，而且它对「这条命令有多危险」没有体感。你让它「清理一下临时文件」， 它可能生成一句 ",e.jsx("code",{children:"rm -rf"})," 带上一个被它算错的路径；你让它「把配置写到上一级目录」， 它可能真的写到了工作区之外去。问题不在于模型聪不聪明，而在于",e.jsx("strong",{children:"它的每一次工具调用都有真实的、不可逆的副作用"}),"。 删掉的文件不会自己回来，覆盖掉的代码找不回上一版。所以我们不能赌「模型这次不会出错」， 必须在执行前加一道独立的、不依赖模型判断的闸门。"]}),e.jsxs("p",{children:["这里有一个容易被忽略的设计哲学：",e.jsx("strong",{children:"权限闸门和模型必须是两套独立的判断系统"}),"。 如果你把「这条命令危不危险」也交给模型自己判（比如让它在调用前先想一句「我觉得这安全」）， 那等于没设防——出错的恰恰是模型的判断本身，让出错的人给自己签字，毫无意义。 闸门的价值就在于它是",e.jsx("strong",{children:"确定性的、可审查的、不受模型当下状态影响的"}),"一段普通代码： 同样的输入永远给同样的裁定，不会因为 prompt 被诱导、上下文被污染就改主意。 安全机制的第一原则是「不要把守门的钥匙交给被守的对象」。"]}),e.jsx(i,{title:"Deny > Ask > Allow：优先级从严",children:e.jsxs("p",{children:["闸门的裁定不是「行/不行」两档，而是三档，并且优先级",e.jsx("strong",{children:"从严到宽"}),"： 明确危险的操作",e.jsx("strong",{children:"直接拒绝（Deny）"}),"，连问都不问；会改动状态的写操作",e.jsx("strong",{children:"默认先问一句（Ask）"}),"， 让人来拍板；纯只读的操作",e.jsx("strong",{children:"静默放行（Allow）"}),"，不打扰你。 判定时永远先看会不会命中 Deny，再看要不要 Ask，最后才轮到 Allow—— 越危险的判断越靠前，宁可严一点，也不放过一次破坏。"]})}),e.jsxs(s,{variant:"note",title:"和 Claude Code / sandbox 的对比：同一个问题的三种答法",children:[e.jsx("p",{children:"forge 这套「执行前裁定 + 人确认」并不是凭空发明的，业界对「怎么管住会动手的 Agent」大体有三条路线， 各有取舍："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"策略闸门（forge / Claude Code）"}),"：在工具执行前用一套规则裁定 allow/ask/deny， 危险的拦、拿不准的问人。优点是",e.jsx("strong",{children:"颗粒度细、对人透明"}),"——你能看到每一步在干什么； 缺点是规则要靠人维护，黑名单永远不全。Claude Code 的 ",e.jsx("code",{children:"permissions"})," 配置 （",e.jsx("code",{children:"allow / ask / deny"})," 三档 + 工具名/参数匹配）就是这一路，forge 是它的简化版教学实现。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"沙箱隔离（sandbox / 容器）"}),"：干脆把 Agent 关进一个受限环境——只读的根文件系统、 限定的网络、用完即弃的容器。优点是",e.jsx("strong",{children:"就算它想干坏事也出不了笼子"}),"，不依赖规则全不全； 缺点是",e.jsx("strong",{children:"笼子里的破坏照样发生"}),"（删光工作区里的代码沙箱拦不住），而且每次起容器有成本、配置也重。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"事后审计（只记不拦）"}),"：什么都放行，但把每一步记下来事后追责。优点是零打扰、不挡路； 缺点很明显——",e.jsx("strong",{children:"它根本不防，只负责告诉你「已经出事了」"}),"。"]})]}),e.jsxs("p",{children:["成熟的系统从不三选一，而是",e.jsx("strong",{children:"叠着用"}),"：沙箱兜底（最坏情况下也炸不出笼子）+ 策略闸门做细颗粒控制 + 审计留痕事后复盘。forge 这一卷正好把后两层讲透，第三章接审计。这就是纵深防御的雏形。"]})]}),e.jsx("h2",{children:"三种裁定的语义"}),e.jsx("p",{children:"把这三档说清楚，后面的代码就是把它翻译成 TypeScript 而已："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"allow（放行）"}),"：闸门认为这次调用无害，",e.jsx("strong",{children:"静默执行"}),"，用户甚至不会注意到刚才裁定过。 读文件、列目录、搜索这类只读操作都走这条路——它们不改变任何状态，没有问的必要。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"ask（询问）"}),"：闸门拿不准，把决定权交回给人。执行",e.jsx("strong",{children:"暂停"}),"，向用户弹一句确认 （下一章细讲怎么问 y/N），用户点头才继续，摇头就当这次调用失败。写文件、改文件、跑普通 shell 命令都默认走这条。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"deny（拒绝）"}),"：闸门认定这次调用明显危险，",e.jsx("strong",{children:"根本不执行"}),"，连问都不问。 但关键在于它",e.jsx("strong",{children:"怎么拒"}),"——不是抛个异常把进程炸了，而是把「为什么拒」当成工具的执行结果回灌给模型。"]})]}),e.jsx(s,{variant:"note",title:"deny 不是抛异常，而是给模型的反馈",children:e.jsxs("p",{children:["很容易把 deny 写成 ",e.jsx("code",{children:"throw new Error(...)"}),"，但那样模型什么都看不到，整轮对话也可能崩掉。 正确的做法是：构造一个 ",e.jsx("code",{children:"is_error"})," 为真的 ",e.jsx("code",{children:"tool_result"}),"，把拒绝的理由塞进 ",e.jsx("code",{children:"content"}),"， 像一次「失败的工具调用」一样回灌给模型。这样模型就能在下一步看到「我那条 ",e.jsx("code",{children:"rm -rf /"})," 被权限策略拒了，原因是疑似破坏性命令」， 从而",e.jsx("strong",{children:"换一个更安全的做法"}),"——比如先列目录确认、或者改用更精确的路径。 换句话说，这道闸门不只是拦人，它也是给模型的一条反馈通道：拒绝即提示。"]})}),e.jsx("h2",{children:"forge 真实的权限模块"}),e.jsxs("p",{children:["下面是 forge 里 ",e.jsx("code",{children:"src/permissions.ts"})," 的完整内容。它就是上面那套语义的落地：一个 ",e.jsx("code",{children:"Decision"})," 类型、 一个带理由的 ",e.jsx("code",{children:"PermissionResult"}),"、一份破坏性命令黑名单，外加一个默认策略 ",e.jsx("code",{children:"defaultPolicy"}),"。先整体看一遍，再逐段拆。"]}),e.jsx(r,{lang:"ts",title:"src/permissions.ts",code:l}),e.jsx("h3",{children:"PermissionResult 为什么带 reason"}),e.jsxs("p",{children:["裁定结果不只是一个 ",e.jsx("code",{children:"decision"})," 枚举，还附带一段 ",e.jsx("code",{children:"reason"})," 文本。这段理由要被用两次： 一是当裁定是 ",e.jsx("code",{children:"ask"})," 时，它就是弹给用户看的那句确认提示——「执行命令：npm test，确认吗？」； 二是不管裁定是什么，它都会被",e.jsx("strong",{children:"写进审计日志"}),"（本卷第三章），将来你能回查「那次到底拒了什么、为什么放行」。 一个字段，同时服务于「当下问人」和「事后追责」两个场景，所以每条裁定都顺手把摘要拼好。"]}),e.jsx("h3",{children:"DESTRUCTIVE 黑名单各匹配什么"}),e.jsx("p",{children:"这是一组正则，专门盯那些一眼就该拒的破坏性 shell 命令。逐条看："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"/\\brm\\s+-[a-z]*r[a-z]*f?\\b.*(\\/|~|\\*)/"}),"：匹配带递归/强制标志、且作用在",e.jsx("code",{children:"/"}),"、",e.jsx("code",{children:"~"})," 或 ",e.jsx("code",{children:"*"})," 上的 ",e.jsx("code",{children:"rm"}),"，也就是 ",e.jsx("code",{children:"rm -rf /"})," 这种能删半台机器的命令。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"/\\bmkfs\\b/"}),"：",e.jsx("code",{children:"mkfs"})," 是格式化文件系统，跑错盘等于一键清空。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"/\\bdd\\b.*\\bof=\\/dev\\//"}),"：",e.jsx("code",{children:"dd"})," 把数据直接写到 ",e.jsx("code",{children:"/dev/"})," 下的设备节点， 可以绕过文件系统直接糊掉整块硬盘。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"/:\\(\\)\\s*\\{.*\\}\\s*;:/"}),"：经典的 fork bomb ",e.jsx("code",{children:":(){ :|:& };:"}),"，会无限自我复制把系统拖垮。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"/\\bshutdown\\b|\\breboot\\b/"}),"：关机、重启——Agent 没理由动这些。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"/>\\s*\\/dev\\/sd/"}),"：把输出重定向写到 ",e.jsx("code",{children:"/dev/sd"})," 开头的裸盘设备上，同样是绕过文件系统直写磁盘。"]})]}),e.jsxs("p",{children:["这些 ",e.jsx("code",{children:"\\\\b"})," 是单词边界、",e.jsx("code",{children:"\\\\s"})," 是空白、",e.jsx("code",{children:"\\\\/"})," 是转义的斜杠——别被它们吓到， 本质就是「长得像这几种灾难命令」的模式匹配。"]}),e.jsx("h3",{children:"decide 的判定顺序"}),e.jsxs("p",{children:["策略的核心是 ",e.jsx("code",{children:"decide"}),"，它严格按 ",e.jsx("strong",{children:"Deny > Ask > Allow"})," 的优先级一层层往下判："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"第一步，只读工具直接 allow。"}),"每个工具自带一个 ",e.jsx("code",{children:"readOnly"})," 标记，读类工具（read、ls、grep） 一律放行，连后面的逻辑都不用进——只读没有副作用，没什么可拦的。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"第二步，bash 按命令内容分级。"}),"取出 ",e.jsx("code",{children:"input.command"}),"，先拿它去匹配 ",e.jsx("code",{children:"DESTRUCTIVE"})," 黑名单， 命中就 ",e.jsx("code",{children:"deny"}),"；没命中也不放行，而是 ",e.jsx("code",{children:"ask"}),"——shell 能干的事太杂，默认都要人点头。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"第三步，write / edit 做越界检查。"}),"把相对路径用 ",e.jsx("code",{children:"resolve(cwd, path)"})," 解析成绝对路径， 然后两道红线：写 ",e.jsx("code",{children:".git"})," 目录直接 ",e.jsx("code",{children:"deny"}),"，写到工作目录之外直接 ",e.jsx("code",{children:"deny"}),"；都过了才 ",e.jsx("code",{children:"ask"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"第四步，其它写工具兜底 ask。"}),"将来新增的、不在上面三类里的写工具，保守起见一律先问一句，绝不默认放行。"]})]}),e.jsx("h3",{children:"为什么 .git 和工作目录之外要直接 deny"}),e.jsxs("p",{children:["这两条不是「问一句」而是「直接拒」，因为它们几乎不可能是用户的真实意图，破坏性却很大。 往 ",e.jsx("code",{children:".git"})," 里乱写可能损坏对象库、引用，把整个仓库的历史搞坏，这种损坏往往很隐蔽、事后极难修。 而写到工作目录之外（用 ",e.jsx("code",{children:"abs.startsWith(resolve(cwd))"})," 判断），意味着 Agent 正试图碰它本不该碰的地方—— 可能是模型把路径算错了，也可能是被诱导越权。无论哪种，都没有「问一下也许是对的」的余地，直接 ",e.jsx("code",{children:"deny"})," 最安全。"]}),e.jsx(s,{variant:"warn",title:"边界情况：路径前缀判断的一个真实坑",children:e.jsxs("p",{children:[e.jsx("code",{children:"abs.startsWith(resolve(cwd))"})," 看着没问题，其实藏着一个经典越界漏洞。 假设 ",e.jsx("code",{children:"cwd"})," 是 ",e.jsx("code",{children:"/home/user/app"}),"，那么 ",e.jsx("code",{children:"/home/user/app-secrets/key"}),"也会通过 ",e.jsx("code",{children:"startsWith"})," 检查——因为字符串前缀确实匹配，可它根本不在工作区里！ 正确的写法要带上分隔符：判断 ",e.jsx("code",{children:"abs === cwd"})," 或 ",e.jsx("code",{children:"abs.startsWith(cwd + path.sep)"}),"。 另外还要小心符号链接（symlink）——一个看似在工作区内的路径，可能软链到工作区外，",e.jsx("code",{children:"resolve"})," 并不会跟随 symlink，真正较真时得用 ",e.jsx("code",{children:"fs.realpath"})," 先解真身。 安全代码里，「差不多对」往往就等于「有洞」。"]})}),e.jsx("h3",{children:"规则匹配：多条规则命中时谁说了算"}),e.jsxs("p",{children:["现在的 ",e.jsx("code",{children:"defaultPolicy"})," 是一串 if-else，逻辑简单。但等到卷 6 把策略做成可配置的规则列表， 就会冒出一个新问题：",e.jsx("strong",{children:"一条命令同时命中多条规则时，按谁的裁定算？"}),"这是所有权限系统都要回答的核心问题，forge 的答案延续 Deny > Ask > Allow 的精神， 再加一条「最具体优先」："]}),e.jsx(r,{lang:"ts",title:"规则匹配的优先级（卷 6 的形态预览）",code:o}),e.jsxs("p",{children:["两条规则缺一不可：",e.jsx("strong",{children:"deny 一票否决"}),"保证任何时候红线规则都压得住放宽规则， 不会因为你给 ",e.jsx("code",{children:"git"})," 开了白名单就让 ",e.jsx("code",{children:"git ... && rm -rf"})," 溜过去；",e.jsx("strong",{children:"同档最具体优先"}),"让你能先放宽一大类（",e.jsx("code",{children:"git *"})," 全 allow）、再精确收窄个别危险子集 （",e.jsx("code",{children:"git push *"})," 单独 ask）。这套「先宽后窄、deny 封顶」的合并语义，和防火墙规则、 云上 IAM 策略的求值逻辑是同一个思路——显式 deny 永远胜过 allow。"]}),e.jsxs(s,{variant:"warn",title:"白名单陷阱：给 shell 命令开白名单，几乎必然漏",children:[e.jsxs("p",{children:["最诱人也最危险的偷懒，是给「我信得过的命令」开白名单来少敲 y。问题在于：",e.jsx("strong",{children:"shell 命令的字面，和它实际会执行的东西，是两回事。"})]}),e.jsx(r,{lang:"ts",title:"一个看似安全、实则千疮百孔的白名单",code:t}),e.jsxs("p",{children:["分号、管道、",e.jsx("code",{children:"$()"})," 命令替换、反引号、换行……shell 的元字符多到你列不全， 任何基于「整条命令字符串」的前缀或正则白名单，都能被它们绕开。这也是为什么 forge 的默认姿态是",e.jsx("strong",{children:"对所有 bash 一律 ask"}),"，只对最明显的灾难命令 deny——它压根不试图去「白名单某条命令」， 因为它知道这件事在 shell 面前做不干净。真要做命令白名单，得在",e.jsx("strong",{children:"解析过命令结构"}),"之后 （拆出真正的 argv、拒绝任何带元字符的命令），而不是对原始字符串做前缀匹配。"]})]}),e.jsx("h2",{children:"把闸门接进主循环"}),e.jsxs("p",{children:["策略造好了，接下来要把它",e.jsx("strong",{children:"插进执行路径"}),"。位置就在 ",e.jsx("code",{children:"agent.ts"})," 的 ",e.jsx("code",{children:"execOne"})," 里， 在真正调用 ",e.jsx("code",{children:"tool.run"})," 之前。下面这段就是那道闸门："]}),e.jsx(r,{lang:"ts",title:"src/agent.ts（execOne 的安全闸门）",code:h}),e.jsxs("p",{children:["第一行先让策略裁定，拿到 ",e.jsx("code",{children:"verdict"}),"，并立刻 ",e.jsx("code",{children:"this.audit.log"})," 记一笔——不管最后执不执行， 「裁定发生过」这件事先落到审计里。接着分两种拦截情况："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"deny"}),"：不执行，直接构造一个 ",e.jsx("code",{children:"is_error: true"})," 的 ",e.jsx("code",{children:"tool_result"})," 返回， 把理由放进 ",e.jsx("code",{children:"content"}),"。模型下一步就能读到这条「失败」并调整做法（呼应前面那个 Callout）。 同时 ",e.jsx("code",{children:"onEvent"})," 抛一个 ",e.jsx("code",{children:"tool_end"})," 事件，让终端把这次拒绝显示出来。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"ask"}),"：调用 ",e.jsx("code",{children:"this.confirm"})," 向用户征求同意。如果用户拒绝（或压根没接 ",e.jsx("code",{children:"confirm"})," 回调）， 同样返回一个 ",e.jsx("code",{children:"is_error"})," 的结果，内容是「用户拒绝了这次操作」。点头了才会落到这段代码之后的真正执行。"]})]}),e.jsxs("p",{children:["注意一个安全细节：",e.jsx("code",{children:"const approved = this.confirm ? await this.confirm(...) : false"}),"。 要是没装 ",e.jsx("code",{children:"confirm"})," 回调，默认值是 ",e.jsx("code",{children:"false"})," 而不是 ",e.jsx("code",{children:"true"}),"——",e.jsx("strong",{children:"缺省即拒绝"}),"，安全优先。绝不能因为「忘了接确认回调」就让需要确认的操作悄悄放行。"]}),e.jsx(s,{variant:"note",title:"confirm 与 audit 的细节在后两章",children:e.jsxs("p",{children:["这里出现的 ",e.jsx("code",{children:"this.confirm"})," 和 ",e.jsx("code",{children:"this.audit"})," 本章只需知道它们存在、以及在闸门里的位置。",e.jsx("code",{children:"confirm"})," 怎么连到 REPL、怎么读一个 y/N 出来，是",e.jsx("strong",{children:"下一章"}),"的内容；",e.jsx("code",{children:"audit.log"})," 把裁定记到哪、记成什么格式、怎么回查，是",e.jsx("strong",{children:"第三章"}),"的内容。 本章的主角是 ",e.jsx("code",{children:"policy.decide"}),"：闸门的「判」这一半，已经齐了。"]})}),e.jsxs(c,{title:"三种裁定各举一例",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"read package.json → allow"}),"：模型想读一下依赖。",e.jsx("code",{children:"read"})," 是只读工具， 第一步就放行，文件内容直接喂回去，你全程没被打扰。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"edit src/app.ts → ask"}),"：模型要改一个工作区里的源码文件。路径没越界、不在 ",e.jsx("code",{children:".git"}),"， 所以裁定是 ",e.jsx("code",{children:"ask"}),"，终端弹出「修改文件：src/app.ts，确认吗？(y/N)」，等你点头。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:'bash "rm -rf /" → deny'}),"：命中 ",e.jsx("code",{children:"DESTRUCTIVE"})," 第一条正则，直接拒绝，根本不执行。 理由「疑似破坏性命令，已拒绝：rm -rf /」作为 ",e.jsx("code",{children:"is_error"})," 的结果回灌给模型，模型看到后会换个安全的思路重来。"]})]}),e.jsx(s,{variant:"warn",title:"黑名单不是银弹，要靠纵深防御",children:e.jsxs("p",{children:["千万别以为列了六条正则就「安全了」。攻击和事故的形态无穷无尽——换个写法的 ",e.jsx("code",{children:"rm"}),"、拼接出来的危险命令、 黑名单没想到的工具，永远有漏网之鱼。所以 forge 的真正防线不是那份黑名单，而是",e.jsx("strong",{children:"策略的默认姿态"}),"： 只对最明显的破坏 ",e.jsx("code",{children:"deny"}),"，而对",e.jsx("strong",{children:"所有"}),"写操作一律 ",e.jsx("code",{children:"ask"}),"。 黑名单挡住已知的灾难，「写操作默认问一句」挡住未知的风险，人作为最后一道关卡兜底。 多层叠加、互相补位，这就是纵深防御——不指望任何单独一层做到滴水不漏。"]})}),e.jsx(s,{variant:"tip",title:"这套策略以后能由配置覆盖",children:e.jsxs("p",{children:["现在的 ",e.jsx("code",{children:"defaultPolicy"})," 是写死的，但接口 ",e.jsx("code",{children:"PermissionPolicy"})," 已经留好了扩展点。 等到卷 6 的配置系统，你就能用配置文件覆盖默认策略——比如给 ",e.jsx("code",{children:"npm test"}),"、",e.jsx("code",{children:"git status"}),"这类你信得过的命令加白名单，让它们从 ",e.jsx("code",{children:"ask"})," 降级成 ",e.jsx("code",{children:"allow"}),"，实现「免确认」， 少敲很多次 y。安全和顺手之间的平衡，最终交给用户自己调。"]})}),e.jsx("h2",{children:"权限设计的常见误区"}),e.jsx("p",{children:"最后把工程里真实踩过的坑列成一张对照表。它们的共同点是：单看都「能跑」， 放进对抗性或边界场景就出事。"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"常见做法（坑）"}),e.jsx("th",{children:"为什么有问题"}),e.jsx("th",{children:"正确姿态"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"让模型自己判断「这步安不安全」"}),e.jsx("td",{children:"守门的钥匙交给被守的对象，出错的人给自己签字"}),e.jsx("td",{children:"闸门是独立的确定性代码，不受 prompt 影响"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"只做黑名单，命中才拦"}),e.jsx("td",{children:"黑名单永远列不全，换个写法就绕过"}),e.jsx("td",{children:"默认 ask 兜底，黑名单只挡最明显的灾难"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"给整条 shell 命令字符串开前缀白名单"}),e.jsxs("td",{children:["分号 / 管道 / ",e.jsx("code",{children:"$()"})," 能拼接出任意命令"]}),e.jsx("td",{children:"解析出 argv 再判，或干脆只对结构化工具放行"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["用 ",e.jsx("code",{children:"startsWith(cwd)"})," 判越界"]}),e.jsxs("td",{children:[e.jsx("code",{children:"app-secrets"})," 也匹配 ",e.jsx("code",{children:"app"})," 前缀"]}),e.jsxs("td",{children:["带分隔符比较，必要时 ",e.jsx("code",{children:"realpath"})," 解 symlink"]})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:["deny 时 ",e.jsx("code",{children:"throw"})," 抛异常"]}),e.jsx("td",{children:"模型看不到原因，整轮对话可能崩"}),e.jsxs("td",{children:["构造 ",e.jsx("code",{children:"is_error"})," 结果回灌，拒绝即反馈"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"忘了接 confirm 就默认放行"}),e.jsx("td",{children:"问不到人却偷偷执行，安全姿态反了"}),e.jsxs("td",{children:["缺省即拒绝（",e.jsx("code",{children:"... : false"}),"）"]})]})]})]}),e.jsx(n,{points:["能改文件、能跑 shell 的 Agent 副作用不可逆，必须在「模型决定」和「真正执行」之间加一道独立的安全闸门。","守门的闸门必须独立于模型：确定性、可审查、不受 prompt 诱导——别把守门的钥匙交给被守的对象。","裁定分三档，优先级从严：Deny（明确危险，直接拒）> Ask（写操作，先问一句）> Allow（只读，静默放行）。","deny 不抛异常，而是构造 is_error 的 tool_result 把理由回灌给模型——拒绝即反馈，让模型换个安全做法。","permissions.ts：PermissionResult 带 reason（既给人看确认、也写审计）；DESTRUCTIVE 黑名单挡最明显的灾难命令。","decide 严格按只读→bash 分级→write/edit 越界检查→其它默认 ask 的顺序判；写 .git 或工作目录之外直接 deny。","闸门接在 execOne 执行工具之前：deny 直接返回错误结果，ask 调 confirm 征求同意，没有 confirm 回调时默认拒绝。","黑名单永远不全，所以靠纵深防御：写操作一律 ask、最明显的破坏才 deny，人作为最后兜底。","和业界对比：策略闸门（forge/Claude Code）颗粒细、沙箱兜底防越狱、审计只记不拦——成熟系统三层叠用。","规则合并语义：deny 一票否决 + 同档最具体优先（先宽后窄），和防火墙/IAM 同思路；前缀白名单在 shell 面前必漏。","下一章：危险确认——把 ask 的 this.confirm 接到 REPL，看它怎么向用户问出那句 y/N。"]})]})}export{u as default};
