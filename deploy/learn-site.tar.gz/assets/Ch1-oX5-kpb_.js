import{j as e}from"./index-BnUyEu5E.js";import{L as i,S as s}from"./Summary-qZ1-DBVA.js";import{K as o}from"./KeyIdea-DOTgzjr8.js";import{C as n}from"./Callout-DUAtr8Nz.js";import{C as t}from"./CodeBlock-DIEQOVpA.js";import{E as r}from"./Example-BRazL43h.js";import{P as d}from"./Practice-CbyZMrNx.js";import{P as c}from"./PyRunner-BbIE7FL-.js";const h=`# 浏览器里也有一个临时文件系统，可以真的读写文件
# 写入
with open("demo.txt", "w", encoding="utf-8") as f:
    f.write("第一行：学习 Python\\n")
    f.write("第二行：今天很开心\\n")
    f.write("第三行：继续加油\\n")

# 读回全部
with open("demo.txt", "r", encoding="utf-8") as f:
    content = f.read()
print("===== 全部内容 =====")
print(content)

# 逐行读，加上行号
print("===== 逐行编号 =====")
with open("demo.txt", "r", encoding="utf-8") as f:
    for i, line in enumerate(f, start=1):
        print(i, line.strip())`,l=`# 用 open() 打开文件，第二个参数是"模式"
f = open("note.txt", "r")   # r = read，只读（默认）
f = open("note.txt", "w")   # w = write，写入（清空原内容！）
f = open("note.txt", "a")   # a = append，追加（在末尾续写）
f.close()                    # 用完一定要关闭`,x=`# 写入文本：用 "w" 模式
f = open("note.txt", "w", encoding="utf-8")
f.write("第一行\\n")    # \\n 是换行符
f.write("第二行\\n")
f.close()

# 运行后，当前目录会多出一个 note.txt，内容是：
# 第一行
# 第二行`,a=`# 推荐写法：用 with，自动关闭文件
with open("note.txt", "w", encoding="utf-8") as f:
    f.write("学习 Python\\n")
    f.write("今天很开心\\n")
# 离开 with 代码块，文件被自动关闭，不会忘`,j=`# 一次读出全部内容（返回一个字符串）
with open("note.txt", "r", encoding="utf-8") as f:
    content = f.read()
print(content)`,p=`学习 Python
今天很开心`,f=`# 按行读：直接 for 遍历文件对象，一行一行拿
with open("note.txt", "r", encoding="utf-8") as f:
    for line in f:
        print(line.strip())   # strip() 去掉行尾的换行符

# 或者一次性读成列表，每个元素是一行
with open("note.txt", "r", encoding="utf-8") as f:
    lines = f.readlines()
print(lines)`,w=`学习 Python
今天很开心
['学习 Python\\n', '今天很开心\\n']`,g=`# 追加模式 a：不清空，在末尾续写
with open("note.txt", "a", encoding="utf-8") as f:
    f.write("又记了一笔\\n")

# 现在文件里有三行了`,u=`import os

# 相对路径：相对于"当前工作目录"
open("data/note.txt")          # 当前目录下的 data 文件夹里

# 绝对路径：从根目录写全（Windows 用 C:\\\\ 开头）
open("/home/user/note.txt")    # Linux / macOS

# os.path 拼路径（自动用对系统的分隔符，跨平台更安全）
path = os.path.join("data", "logs", "note.txt")
print(path)                    # data/logs/note.txt（Linux）

# 判断文件是否存在
print(os.path.exists("note.txt"))`,m=`from pathlib import Path

p = Path("data") / "note.txt"   # 用 / 拼路径，很直观
print(p)                         # data/note.txt

# pathlib 还能直接读写，超方便
Path("hello.txt").write_text("你好\\n", encoding="utf-8")
print(Path("hello.txt").read_text(encoding="utf-8"))`,y=`# 一个"记笔记到文件"的小程序
# 运行后不断输入笔记，每条追加到 notes.txt，输入 q 退出

FILE = "notes.txt"

def add_note(text):
    with open(FILE, "a", encoding="utf-8") as f:
        f.write(text + "\\n")

def show_notes():
    print("===== 我的笔记 =====")
    with open(FILE, "a", encoding="utf-8"):
        pass                      # 确保文件存在
    with open(FILE, "r", encoding="utf-8") as f:
        for i, line in enumerate(f, start=1):
            print(f"{i}. {line.strip()}")
    print("===================")

while True:
    text = input("输入一条笔记（q 退出）：")
    if text == "q":
        break
    add_note(text)
    print("已保存！")

show_notes()`,P=`输入一条笔记（q 退出）：买牛奶
已保存！
输入一条笔记（q 退出）：写 Python
已保存！
输入一条笔记（q 退出）：q
===== 我的笔记 =====
1. 买牛奶
2. 写 Python
===================`;function v(){return e.jsxs("article",{children:[e.jsx(i,{children:'到目前为止，我们的程序一关就什么都没了——变量只活在内存里。要让数据"留下来"， 就得把它写进文件。这一章我们学最常用的文本文件读写：怎么打开文件、怎么写、怎么读、 怎么按行处理，以及怎么找到文件所在的"路径"。最后写一个能把笔记存进文件的小程序。'}),e.jsx("h2",{children:"一、用 open() 打开文件"}),e.jsxs("p",{children:["Python 用内置函数 ",e.jsx("code",{children:"open()"})," 打开文件。它最少要两个信息：文件名，和你想干什么（模式）。"]}),e.jsx(t,{lang:"python",title:"open 的三种常用模式",code:l}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"模式"}),e.jsx("th",{children:"含义"}),e.jsx("th",{children:"文件不存在时"}),e.jsx("th",{children:"会清空原内容吗"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:'"r"'})}),e.jsx("td",{children:"只读（默认）"}),e.jsx("td",{children:"报错"}),e.jsx("td",{children:"否"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:'"w"'})}),e.jsx("td",{children:"写入"}),e.jsx("td",{children:"自动创建"}),e.jsx("td",{children:e.jsx("strong",{children:"是！会清空"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:'"a"'})}),e.jsx("td",{children:"追加"}),e.jsx("td",{children:"自动创建"}),e.jsx("td",{children:"否，在末尾续写"})]})]})]}),e.jsxs(n,{variant:"warn",title:"w 会清空文件",children:["用 ",e.jsx("code",{children:'"w"'})," 打开一个已有文件，里面的内容会",e.jsx("strong",{children:"立刻被清空"}),"。 想保留旧内容、只往后加，请用 ",e.jsx("code",{children:'"a"'}),"（追加）。"]}),e.jsx("h2",{children:"二、写文本到文件"}),e.jsxs("p",{children:["打开后用 ",e.jsx("code",{children:"write()"})," 写字符串。注意 ",e.jsx("code",{children:"write"})," 不会自动换行，要换行得自己加 ",e.jsx("code",{children:"\\n"}),"。"]}),e.jsx(t,{lang:"python",title:"写入文本",code:x}),e.jsxs(n,{variant:"tip",title:'为什么写 encoding="utf-8"',children:["中文要正确保存，最好都加上 ",e.jsx("code",{children:'encoding="utf-8"'}),"。不加在某些系统上可能出现乱码， 养成习惯总是带上它，最省心。"]}),e.jsx("h2",{children:"三、用 with 自动关闭文件"}),e.jsxs("p",{children:["上面我们手动 ",e.jsx("code",{children:"f.close()"}),"，但万一中间报错就关不掉了。Python 提供了",e.jsx("code",{children:"with"})," 语句：代码块结束（无论正常还是出错）都会",e.jsx("strong",{children:"自动关闭"}),"文件。 这是写文件的标准姿势。"]}),e.jsx(t,{lang:"python",title:"推荐：用 with 打开",code:a}),e.jsxs(o,{children:["以后读写文件，一律用 ",e.jsx("code",{children:"with open(...) as f:"}),'。它帮你管好"用完就关"， 你只管在代码块里读写就行。']}),e.jsx("h2",{children:"四、读取文件内容"}),e.jsx("h3",{children:"读全部：read()"}),e.jsxs("p",{children:[e.jsx("code",{children:"read()"})," 把整个文件读成一个字符串。"]}),e.jsx(t,{lang:"python",title:"一次读出全部",code:j}),e.jsx(t,{lang:"text",title:"运行结果",code:p}),e.jsx("h3",{children:"按行读：for 遍历"}),e.jsxs("p",{children:["文件如果很大，一次全读进内存不划算。更常见的是",e.jsx("strong",{children:"一行一行"}),"处理—— 直接 ",e.jsx("code",{children:"for line in f"})," 遍历文件对象即可，Python 会自动逐行给你。"]}),e.jsx(t,{lang:"python",title:"逐行读取",code:f}),e.jsx(t,{lang:"text",title:"运行结果",code:w}),e.jsxs(n,{variant:"note",title:"行尾的换行符",children:["每行读出来都带着结尾的 ",e.jsx("code",{children:"\\n"}),"。打印时常用 ",e.jsx("code",{children:"line.strip()"}),"去掉首尾空白（包括换行），输出才整齐。"]}),e.jsx("h2",{children:"五、追加内容：a 模式"}),e.jsxs("p",{children:["想在不删除旧内容的前提下往后加，用 ",e.jsx("code",{children:'"a"'}),"。"]}),e.jsx(t,{lang:"python",title:"追加一行",code:g}),e.jsxs(d,{title:"练一练",children:["新建一个 ",e.jsx("code",{children:"diary.txt"}),"，用 ",e.jsx("code",{children:'"w"'})," 写入今天的日期， 再用 ",e.jsx("code",{children:'"a"'})," 追加三条心情，最后用 ",e.jsx("code",{children:"for"})," 遍历打印出来。 观察 ",e.jsx("code",{children:'"w"'})," 和 ",e.jsx("code",{children:'"a"'})," 的区别。"]}),e.jsx("h2",{children:"六、文件路径：相对、绝对、跨平台"}),e.jsxs("p",{children:["程序怎么找到文件？靠",e.jsx("strong",{children:"路径"}),"。路径分两种："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"相对路径"}),'：相对于程序运行时的"当前目录"，如 ',e.jsx("code",{children:"data/note.txt"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"绝对路径"}),"：从根目录写到底，如 ",e.jsx("code",{children:"/home/user/note.txt"}),"（Windows 形如 ",e.jsx("code",{children:"C:\\\\Users\\\\me\\\\note.txt"}),"）。"]})]}),e.jsxs("p",{children:["不同系统的路径分隔符不一样（Linux/macOS 用 ",e.jsx("code",{children:"/"}),"，Windows 用 ",e.jsx("code",{children:"\\\\"}),"）。 别手写拼接，用标准库帮你拼，跨平台更安全。"]}),e.jsx(t,{lang:"python",title:"os.path 处理路径",code:u}),e.jsx("h3",{children:"更现代的 pathlib"}),e.jsxs("p",{children:["Python 3 推荐用 ",e.jsx("code",{children:"pathlib"}),"，它把路径当对象，用 ",e.jsx("code",{children:"/"})," 拼接，还能直接读写。"]}),e.jsx(t,{lang:"python",title:"pathlib 简介",code:m}),e.jsxs(n,{variant:"tip",title:"选哪个",children:["两个都能用。新代码推荐 ",e.jsx("code",{children:"pathlib"}),"，写起来更直观；看到老代码里的 ",e.jsx("code",{children:"os.path"}),"也别慌，它们做的是同一件事。"]}),e.jsx("h2",{children:"七、综合实例：记笔记到文件"}),e.jsxs("p",{children:["把这一章学的串起来：写一个循环，不断接收用户输入的笔记，每条",e.jsx("strong",{children:"追加"}),'到文件， 最后读出全部笔记编号显示。这就是一个最小的"持久化"小工具。']}),e.jsx(t,{lang:"python",title:"note_app.py",code:y}),e.jsx(t,{lang:"text",title:"运行结果",code:P}),e.jsx(r,{title:"这段代码用到了什么",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"add_note"})," 用 ",e.jsx("code",{children:'"a"'})," 追加，所以每次运行都会累积笔记，不会丢。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"show_notes"})," 先用 ",e.jsx("code",{children:'"a"'}),' 模式"碰"一下文件，确保它存在（否则首次读会报错）。']}),e.jsxs("li",{children:["读取时用 ",e.jsx("code",{children:"enumerate(f, start=1)"})," 给每行配上从 1 开始的编号。"]})]})}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」。"]}),e.jsx(c,{initialCode:h}),e.jsx(s,{points:["open(文件名, 模式) 打开文件：r 只读、w 写入（会清空）、a 追加（在末尾续写）。","用 with open(...) as f: 打开，代码块结束自动关闭文件，不会忘记 close。","写用 f.write(字符串)，换行要自己加 \\n；读全部用 f.read()，按行处理直接 for line in f。","逐行读出的内容带 \\n，常配 line.strip() 去掉首尾空白。","路径分相对（基于当前目录）和绝对（从根写起）；用 os.path.join 或 pathlib 拼路径，跨平台更安全。",'处理中文统一加 encoding="utf-8"，避免乱码。']})]})}export{v as default};
