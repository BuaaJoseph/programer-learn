import{j as e}from"./index-D-xLQIFq.js";import{L as i,S as r}from"./Summary-YJHOQU45.js";import{K as o}from"./KeyIdea-D9fwNcvs.js";import{C as d}from"./Callout-Bp0vMJus.js";import{C as n}from"./CodeBlock-DX_K20PW.js";import{E as s}from"./Example-JUHxJgjQ.js";const c=`# 三个包：核心框架 + 接百炼的 OpenAILike + 百炼原生嵌入
pip install llama-index llama-index-llms-openai-like llama-index-embeddings-dashscope

# 百炼控制台拿到的 key，LLM 和嵌入模型都会读它
export DASHSCOPE_API_KEY=sk-xxxxxxxx`,l=`import asyncio
import os

from llama_index.core import Document, Settings, VectorStoreIndex
from llama_index.core.agent.workflow import FunctionAgent
from llama_index.core.tools import QueryEngineTool
from llama_index.embeddings.dashscope import DashScopeEmbedding
from llama_index.llms.openai_like import OpenAILike

Settings.llm = OpenAILike(
    model="qwen-plus",
    api_base="https://dashscope.aliyuncs.com/compatible-mode/v1",
    api_key=os.environ["DASHSCOPE_API_KEY"],
    is_chat_model=True,
    is_function_calling_model=True,
)
Settings.embed_model = DashScopeEmbedding(model_name="text-embedding-v3")

docs = [
    Document(text="forge 是一个用 Node+TypeScript 手写的编码 Agent CLI，核心是一个工具调用主循环。"),
    Document(text="百炼是阿里云的大模型平台，提供 Qwen 系列模型，并兼容 OpenAI 接口。"),
    Document(text="RAG 指检索增强生成：先从知识库检索相关片段，再让模型据此回答。"),
]
index = VectorStoreIndex.from_documents(docs)

query_tool = QueryEngineTool.from_defaults(
    index.as_query_engine(),
    name="docs",
    description="回答关于 forge、百炼、RAG 的问题时，用它检索资料。",
)
agent = FunctionAgent(tools=[query_tool], llm=Settings.llm)


async def main() -> None:
    resp = await agent.run("forge 是用什么语言写的？它的核心是什么？")
    print(resp)


if __name__ == "__main__":
    asyncio.run(main())`,t=`from llama_index.core import SimpleDirectoryReader, VectorStoreIndex

# 把三段内置文本换成「读真实目录」：自动识别 .txt/.md/.pdf/.docx 等
docs = SimpleDirectoryReader("./docs").load_data()
index = VectorStoreIndex.from_documents(docs)

# 其余完全不变：as_query_engine → QueryEngineTool → FunctionAgent`,x=`# 对照：不要 Agent，直接用 query engine
# 适合「问一句答一句、不需要决策何时检索」的纯 RAG 场景
qe = index.as_query_engine()
print(qe.query("forge 是用什么语言写的？"))
# query engine 内部固定执行「检索 → 生成」，不会像 Agent 那样判断「要不要查」`,h=`from llama_index.core import StorageContext, load_index_from_storage

# 建好索引后落盘，避免每次启动都重新嵌入（嵌入要花钱花时间）
index.storage_context.persist(persist_dir="./storage")

# 下次直接从磁盘加载，秒级恢复
storage = StorageContext.from_defaults(persist_dir="./storage")
index = load_index_from_storage(storage)  # embed_model 仍取 Settings.embed_model`;function u(){return e.jsxs("article",{children:[e.jsx(i,{children:"理论讲完，动手。这一章我们把几段文档建成索引，做一个真正能「查你文档」的 Agent —— 它不会上来就瞎编，而是在需要时先检索资料再回答。一个完整的小程序， 把数据层和 Agent 层串起来，跑在百炼上。"}),e.jsx("h2",{children:"一、要做什么"}),e.jsxs("p",{children:["目标是一个最小可跑的 ",e.jsx("strong",{children:"chat-with-your-docs"})," 助手：喂给它三段文本当 「你的文档」，建成向量索引，再把索引包成一个名叫 ",e.jsx("code",{children:"docs"})," 的工具交给",e.jsx("code",{children:"FunctionAgent"}),"。当你问「forge 是用什么写的」，Agent 会自己决定调用",e.jsx("code",{children:"docs"})," 工具去检索，拿到答案再组织成回复。整条主线就是上一章那条：",e.jsx("strong",{children:"文档 → 索引 → 工具 → Agent"}),"。"]}),e.jsx("h2",{children:"二、安装与环境"}),e.jsx(n,{lang:"bash",code:c}),e.jsxs("p",{children:["三个包分别是：核心 ",e.jsx("code",{children:"llama-index"}),"、接百炼用的",e.jsx("code",{children:"llama-index-llms-openai-like"}),"、百炼原生嵌入",e.jsx("code",{children:"llama-index-embeddings-dashscope"}),"。注意 LlamaIndex 把各种集成拆成了独立 小包，",e.jsx("strong",{children:"用哪个集成就要装哪个包"})," —— 这点后面调试章节会再强调。",e.jsx("code",{children:"DASHSCOPE_API_KEY"})," 在百炼控制台获取，LLM 和嵌入模型都会读它。"]}),e.jsx("h2",{children:"三、完整代码"}),e.jsx(n,{lang:"python",title:"examples/agent-frameworks/06-llamaindex/chat_with_docs.py",code:l}),e.jsx("h2",{children:"四、逐段讲解"}),e.jsx("h3",{children:"1. Settings 全局配置"}),e.jsxs("p",{children:[e.jsx("code",{children:"Settings"})," 是 LlamaIndex 的",e.jsx("strong",{children:"全局配置单例"}),"，设一次后处处生效。 把 ",e.jsx("code",{children:"Settings.llm"})," 和 ",e.jsx("code",{children:"Settings.embed_model"})," 配好，后面建索引、 建 Agent 就不用再到处传 ",e.jsx("code",{children:"llm="})," 参数 —— 框架内部默认就取这两个全局值。这是 LlamaIndex 「约定优于配置」的体现。"]}),e.jsx("h3",{children:"2. LLM 与 is_chat_model 坑"}),e.jsxs("p",{children:["我们用 ",e.jsx("code",{children:"OpenAILike"})," 指向百炼的兼容端点 ",e.jsx("code",{children:"compatible-mode/v1"}),"。",e.jsx("code",{children:"OpenAILike"})," 的意思就是「一个长得像 OpenAI 接口、但不是官方 OpenAI」的服务。"]}),e.jsxs(d,{variant:"warn",children:[e.jsx("strong",{children:"核心坑：is_chat_model=True。"})," 百炼兼容模式只暴露",e.jsx("code",{children:"/chat/completions"}),"。如果不写这一行，",e.jsx("code",{children:"OpenAILike"})," 会默认把请求 打到老式的 ",e.jsx("code",{children:"/completions"})," 端点，结果就是一个莫名其妙的 ",e.jsx("strong",{children:"404"}),"。",e.jsx("code",{children:"is_function_calling_model=True"})," 则告诉框架这个模型支持函数调用，",e.jsx("code",{children:"FunctionAgent"})," 才能真正用上工具 —— 不写它，Agent 可能退化成不会调工具。"]}),e.jsx("h3",{children:"3. 嵌入为何需要"}),e.jsxs("p",{children:[e.jsx("code",{children:"Settings.embed_model"})," 设成百炼原生的 ",e.jsx("code",{children:"DashScopeEmbedding"}),"（",e.jsx("code",{children:"text-embedding-v3"}),"）。为什么 RAG 一定要嵌入？因为检索的本质是「找语义 相近的片段」，而计算机不懂语义、只会算数。嵌入模型就是那个「",e.jsx("strong",{children:"文字 → 向量"}),"」 的翻译器，把每段文字变成一串数字（向量），语义相近的文字向量也相近，于是「找相似文字」 就变成了「算向量距离」。"]}),e.jsxs(o,{children:["建索引和查询时",e.jsx("strong",{children:"必须用同一个嵌入模型"}),"。如果建索引用 A、查询用 B，两套 向量空间对不上，检索结果就是一堆噪声。所以嵌入模型一旦定了，就别中途换。"]}),e.jsx("h3",{children:"4. from_documents 做了什么"}),e.jsxs("p",{children:[e.jsx("code",{children:"Document(text=...)"})," 把每段文字包成文档对象。",e.jsx("code",{children:"VectorStoreIndex.from_documents(docs)"})," 一行完成了三件事：",e.jsx("strong",{children:"切块"}),"（把长文档切成小片 Node）、",e.jsx("strong",{children:"嵌入"}),"（每片调嵌入模型 变成向量）、",e.jsx("strong",{children:"建索引"}),"（存进向量库便于检索）。这一行背后其实就是完整的 ingestion 流程，只是被高度封装了。"]}),e.jsx("h3",{children:"5. QueryEngineTool"}),e.jsxs("p",{children:[e.jsx("code",{children:"index.as_query_engine()"})," 得到一个检索问答引擎 —— 对它提问，它会先检索再让 LLM 生成回答。但我们不直接用它，而是用 ",e.jsx("code",{children:"QueryEngineTool.from_defaults"}),"把它",e.jsx("strong",{children:"包成一个工具"}),"。这里的 ",e.jsx("code",{children:"name"})," 和 ",e.jsx("code",{children:"description"}),"至关重要：它们是 Agent 判断「",e.jsx("strong",{children:"该不该调这个工具"}),"」的唯一依据，描述要写清楚 「什么时候用它」，否则 Agent 可能该查的时候不查、不该查的时候乱查。"]}),e.jsx("h3",{children:"6. FunctionAgent 与 async run"}),e.jsxs("p",{children:[e.jsx("code",{children:"FunctionAgent(tools=[query_tool], llm=...)"})," 创建 Agent，它负责",e.jsx("strong",{children:"决策"}),"：要不要查、查完怎么答。最后 ",e.jsx("code",{children:"await agent.run(...)"}),"发起一轮对话 —— 注意 ",e.jsx("code",{children:"run"})," 是",e.jsx("strong",{children:"异步"}),"的，所以要包在",e.jsx("code",{children:"async def main"})," 里，用 ",e.jsx("code",{children:"asyncio.run(main())"})," 启动。忘了",e.jsx("code",{children:"await"})," 是新手最常见的错（见调试章节）。"]}),e.jsxs(o,{children:["一条主线：",e.jsx("strong",{children:"文档 → Document → VectorStoreIndex（切块+嵌入+索引）→ as_query_engine → QueryEngineTool → FunctionAgent"}),"。数据层产出一个工具， Agent 层消费这个工具，接缝就在 QueryEngineTool。"]}),e.jsx("h2",{children:"五、预期输出"}),e.jsxs(s,{title:"一次检索增强问答",children:[e.jsx("p",{children:"当你运行这段程序，问出「forge 是用什么语言写的？它的核心是什么？」："}),e.jsxs("ol",{children:[e.jsxs("li",{children:["Agent 收到问题，判断这需要查资料，于是调用 ",e.jsx("code",{children:"docs"})," 工具；"]}),e.jsx("li",{children:"查询引擎把问题嵌入成向量，在索引里召回最相关的那条 —— 关于 forge 的描述；"}),e.jsxs("li",{children:["Agent 拿到检索片段，据此回答：「forge 用 ",e.jsx("strong",{children:"Node + TypeScript"})," 写成， 核心是一个",e.jsx("strong",{children:"工具调用主循环"}),"。」"]})]}),e.jsxs("p",{children:["关键在于：这个答案",e.jsx("strong",{children:"来自你的文档，而不是模型凭记忆瞎编"}),"。换一个你文档里 没写的问题（比如「forge 的作者是谁」），Agent 检索不到对应片段，要么如实说不知道， 要么明确表示资料里没有 —— 这正是 RAG「有据可依」的价值。"]})]}),e.jsx("h2",{children:"六、变体一：读真实目录"}),e.jsxs("p",{children:["三段内置文本只是 demo。真实项目里你不会手写 ",e.jsx("code",{children:"Document"}),"，而是用",e.jsx("code",{children:"SimpleDirectoryReader"})," 一次性读入整个目录，它会自动识别",e.jsx("code",{children:".txt"})," / ",e.jsx("code",{children:".md"})," / ",e.jsx("code",{children:".pdf"})," / ",e.jsx("code",{children:".docx"})," 等格式："]}),e.jsx(n,{lang:"python",code:t}),e.jsxs("p",{children:["换掉的只有「造数据」那两行，",e.jsx("code",{children:"QueryEngineTool"})," 和 ",e.jsx("code",{children:"FunctionAgent"}),"的部分一字不改 —— 这正是分层设计的好处：数据来源换了，上层逻辑无感。"]}),e.jsx("h2",{children:"七、变体二：纯 query engine 与持久化"}),e.jsx("h3",{children:"不用 Agent，直接查"}),e.jsx("p",{children:"如果你的场景就是「问一句答一句」，根本不需要 Agent 去决策「要不要查」，那直接用 query engine 更轻："}),e.jsx(n,{lang:"python",code:x}),e.jsxs("p",{children:["区别在于：query engine ",e.jsx("strong",{children:"每次都固定执行「检索 → 生成」"}),"；而 Agent 会先 判断「这个问题要不要查文档」，可能直接答、也可能调多个工具。需要决策和多工具，才上 Agent。"]}),e.jsx("h3",{children:"持久化索引：别每次都重新嵌入"}),e.jsxs("p",{children:["嵌入是要",e.jsx("strong",{children:"花钱花时间"}),"的（每段文本都得调一次嵌入接口）。文档不变时，建好的 索引应该落盘，下次直接加载："]}),e.jsx(n,{lang:"python",code:h}),e.jsx("h2",{children:"八、常见报错与调试"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"404 / 接口找不到"}),"：十有八九是漏了 ",e.jsx("code",{children:"is_chat_model=True"}),"， 请求被打到 ",e.jsx("code",{children:"/completions"})," 而百炼只有 ",e.jsx("code",{children:"/chat/completions"}),"。 这是头号坑，先查这个。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"嵌入相关报错（401 / 模型不存在）"}),"：检查 ",e.jsx("code",{children:"DASHSCOPE_API_KEY"}),"是否设置正确，以及嵌入模型名是否写对（",e.jsx("code",{children:"text-embedding-v3"}),"）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"ModuleNotFoundError / ImportError"}),"：LlamaIndex 把集成拆成独立小包，",e.jsx("strong",{children:"找不到包就装对应集成包"})," —— 用 ",e.jsx("code",{children:"OpenAILike"})," 要装",e.jsx("code",{children:"llama-index-llms-openai-like"}),"，用 ",e.jsx("code",{children:"DashScopeEmbedding"})," 要装",e.jsx("code",{children:"llama-index-embeddings-dashscope"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Agent 不调工具 / 直接瞎答"}),"：检查 ",e.jsx("code",{children:"is_function_calling_model=True"}),"有没有写；再看 ",e.jsx("code",{children:"QueryEngineTool"})," 的 ",e.jsx("code",{children:"description"})," 是否写清楚了 「什么时候用它」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"协程没跑 / 返回 coroutine 对象"}),"：",e.jsx("code",{children:"agent.run"})," 是异步的， 忘了 ",e.jsx("code",{children:"await"})," 会拿到一个协程对象而不是结果，记得包在 ",e.jsx("code",{children:"async"})," 函数 里并用 ",e.jsx("code",{children:"asyncio.run"})," 启动。"]})]}),e.jsxs(d,{variant:"tip",children:["想再进一步：给 ",e.jsx("code",{children:"AgentWorkflow"})," 配多个工具和多个 Agent 做协作；想编排 「检索 → 生成 → 校验」流水线，就上 Workflows（",e.jsx("code",{children:"@step"})," + ",e.jsx("code",{children:"Event"}),"）， 把每一步显式建模成事件，还能接 OpenTelemetry / Phoenix 看每步耗时。"]}),e.jsx(r,{points:["一个程序串起两层：用 Document + VectorStoreIndex.from_documents 把文档切块、嵌入、建索引（数据层），用 FunctionAgent 决策何时检索、怎么回答（Agent 层）。","接缝是 QueryEngineTool：index.as_query_engine() 得到查询引擎，再 from_defaults 包成带 name/description 的工具交给 Agent；name/description 是 Agent 判断「该不该调」的唯一依据。","接百炼三件套：OpenAILike(is_chat_model=True, is_function_calling_model=True) 做 LLM、DashScopeEmbedding 做嵌入、DASHSCOPE_API_KEY 环境变量；建索引和查询必须用同一个嵌入模型。","变体：SimpleDirectoryReader 读真实目录、纯 query engine 不用 Agent（每次固定检索→生成）、persist/load 持久化索引避免重复嵌入花钱。","调试清单：404 查 is_chat_model、嵌入报错查 key/模型名、ImportError 装对应集成包、Agent 不调工具查 is_function_calling_model 和 description、协程没跑查 await/asyncio.run。"]})]})}export{u as default};
