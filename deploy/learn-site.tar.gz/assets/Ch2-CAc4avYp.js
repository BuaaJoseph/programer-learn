import{j as e}from"./index-I8-WI4LI.js";import{L as t,S as o}from"./Summary-BMIdTn04.js";import{K as s}from"./KeyIdea-Xbvwo63C.js";import{C as n}from"./Callout-ZgrsOCpc.js";import{C as r}from"./CodeBlock-CK6ncc4Q.js";import{E as i}from"./Example-CPIFvVrE.js";const c=`# 1. 安装依赖（LangGraph 1.x + 接百炼用的 langchain-openai）
pip install -U langgraph langchain-openai

# 2. 配置百炼（阿里云 DashScope）API Key
export DASHSCOPE_API_KEY="sk-你的key"

# 3. 运行示例
python examples/agent-frameworks/04-langgraph/react_memory_hitl.py`,a=`import os

from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.prebuilt import create_react_agent
from langgraph.types import Command, interrupt

llm = ChatOpenAI(
    model="qwen-plus",
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    api_key=os.environ["DASHSCOPE_API_KEY"],
)


def get_balance() -> str:
    """查询账户余额（只读，无需审批）。"""
    return "当前余额：1000 元。"


def transfer_money(to: str, amount: float) -> str:
    """给某人转账。执行前会触发人工审批。"""
    decision = interrupt({"action": "transfer", "to": to, "amount": amount})
    if decision == "approve":
        return f"已向 {to} 转账 {amount} 元。"
    return "用户拒绝了这笔转账。"


agent = create_react_agent(
    model=llm,
    tools=[get_balance, transfer_money],
    checkpointer=InMemorySaver(),
)


def main() -> None:
    config = {"configurable": {"thread_id": "user-1"}}

    r1 = agent.invoke({"messages": [{"role": "user", "content": "我还有多少钱？"}]}, config)
    print("助手:", r1["messages"][-1].content)

    r2 = agent.invoke({"messages": [{"role": "user", "content": "给张三转 200 元"}]}, config)
    if "__interrupt__" in r2:
        req = r2["__interrupt__"][0].value
        print("需要审批:", req)
        r3 = agent.invoke(Command(resume="approve"), config)
        print("助手:", r3["messages"][-1].content)


if __name__ == "__main__":
    main()`,d=`from typing import Annotated, TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from langgraph.checkpoint.memory import InMemorySaver


class State(TypedDict):
    messages: Annotated[list, add_messages]


tools = [get_balance, transfer_money]
llm_with_tools = llm.bind_tools(tools)


def call_model(state: State) -> dict:
    return {"messages": [llm_with_tools.invoke(state["messages"])]}


def should_continue(state: State) -> str:
    """路由函数：模型要调工具就去 tools，否则结束。"""
    last = state["messages"][-1]
    if getattr(last, "tool_calls", None):
        return "tools"
    return END


graph = StateGraph(State)
graph.add_node("model", call_model)
graph.add_node("tools", ToolNode(tools))   # 预制工具节点，自动执行 tool_calls
graph.add_edge(START, "model")
graph.add_conditional_edges("model", should_continue, {"tools": "tools", END: END})
graph.add_edge("tools", "model")           # 工具跑完回到 model —— ReAct 循环

app = graph.compile(checkpointer=InMemorySaver())
# 这张手画的图，效果等价于上面的 create_react_agent，但每条边都在你掌控之中`,l=`from langgraph.checkpoint.sqlite import SqliteSaver

# 把存档落到磁盘文件，重启进程后记忆与断点依然在
with SqliteSaver.from_conn_string("checkpoints.sqlite") as saver:
    agent = create_react_agent(model=llm, tools=tools, checkpointer=saver)
    agent.invoke({"messages": [...]}, {"configurable": {"thread_id": "user-1"}})`;function j(){return e.jsxs("article",{children:[e.jsxs(t,{children:["理论讲完，这一章我们把 LangGraph 跑起来：一个接百炼 qwen-plus 的「账户助手」Agent， 既能查余额（只读直接答），又能转账（高风险，先暂停等人审批再执行）。 一份代码同时演示了三件硬核能力——",e.jsx("strong",{children:"记忆、人在回路、续跑"}),"。 我们逐行拆，再手写一版等价的 StateGraph 体会「显式控制」。"]}),e.jsx("h2",{children:"安装与环境"}),e.jsxs("p",{children:["本示例用 ",e.jsx("code",{children:"langchain-openai"})," 的 ",e.jsx("code",{children:"ChatOpenAI"})," 以 OpenAI 兼容模式接入 阿里云百炼（DashScope）。先装依赖、配 Key，再运行："]}),e.jsx(r,{lang:"bash",title:"安装与运行",code:c}),e.jsxs(n,{children:["百炼提供了 OpenAI 兼容端点，所以不需要专门的 SDK：只要把 ",e.jsx("code",{children:"base_url"})," 指向",e.jsx("code",{children:"https://dashscope.aliyuncs.com/compatible-mode/v1"}),"，",e.jsx("code",{children:"model"})," 填",e.jsx("code",{children:"qwen-plus"}),"，",e.jsx("code",{children:"api_key"})," 用你的 DASHSCOPE_API_KEY 即可。"]}),e.jsx("h2",{children:"完整示例代码"}),e.jsx(r,{lang:"python",title:"examples/agent-frameworks/04-langgraph/react_memory_hitl.py",code:a}),e.jsxs(s,{children:["盯住三条主线：",e.jsx("strong",{children:"thread_id"})," 串起记忆、",e.jsx("strong",{children:"interrupt"})," 拦下高风险动作、",e.jsx("strong",{children:"Command(resume)"})," 把人的决定喂回去续跑。三者都建立在 checkpointer 之上。"]}),e.jsx("h2",{children:"逐段拆解"}),e.jsx("h3",{children:"① 接入百炼模型"}),e.jsxs("p",{children:[e.jsx("code",{children:"ChatOpenAI"})," 三个参数就够：",e.jsx("code",{children:'model="qwen-plus"'})," 选模型、",e.jsx("code",{children:"base_url"})," 指向百炼兼容端点、",e.jsx("code",{children:"api_key"})," 从环境变量读。 从这里拿到的 ",e.jsx("code",{children:"llm"})," 与任何 OpenAI 模型用法完全一致，下游代码不必关心底层是谁。"]}),e.jsx("h3",{children:"② 两个工具：只读 vs 高风险"}),e.jsxs("p",{children:[e.jsx("code",{children:"get_balance"})," 是只读查询，直接返回结果，无需审批。",e.jsx("code",{children:"transfer_money"})," 是高风险操作，函数体里第一件事就是调用",e.jsx("code",{children:"interrupt(...)"}),"——把「要给谁转多少」的描述抛出去暂停。 关键点：",e.jsx("strong",{children:"interrupt 写在工具内部"}),"，所以模型一旦决定调这个工具， 执行立刻被拦在「真正转账」之前。",e.jsx("code",{children:"decision"})," 拿到的是外部 resume 进来的值， 是 ",e.jsx("code",{children:'"approve"'})," 才真正执行，否则拒绝。"]}),e.jsx(n,{children:"函数的 docstring（如「执行前会触发人工审批」）会被当作工具说明传给模型， 模型靠它判断何时该调哪个工具。写清楚 docstring 是让 Agent 选对工具的关键。"}),e.jsx("h3",{children:"③ create_react_agent 组装"}),e.jsxs("p",{children:["一行把 ",e.jsx("code",{children:"model"}),"、",e.jsx("code",{children:"tools"}),"、",e.jsx("code",{children:"checkpointer"})," 装进去， 内部就建好了「模型 → 条件边 → 工具 → 模型」的 ReAct 循环图。这里传了",e.jsx("code",{children:"InMemorySaver()"}),"——它既是记忆的来源，也是 interrupt 能暂停/续跑的前提 （没有 checkpointer，interrupt 根本无处保存暂停时的状态）。"]}),e.jsx("h3",{children:"④ thread_id：记忆的钥匙"}),e.jsxs("p",{children:[e.jsx("code",{children:'config = {"configurable": {"thread_id": "user-1"}}'}),"。 三次 invoke 都带同一个 config，于是它们共享同一条会话历史。 正因如此，第二次问「给张三转 200 元」时，Agent 记得前面查余额的上下文； 第三次 resume 续跑时，它也知道自己正卡在哪笔转账上。",e.jsx("strong",{children:"thread_id 一致 = 记忆连续"}),"。"]}),e.jsx("h3",{children:"⑤ 第一轮：只读查询，一步到位"}),e.jsxs("p",{children:["「我还有多少钱？」→ 模型决定调 ",e.jsx("code",{children:"get_balance"})," → 工具直接返回余额 → 模型把结果整理成自然语言。整个过程没有暂停，",e.jsx("code",{children:'r1["messages"][-1].content'})," 就是最终答复。"]}),e.jsx("h3",{children:"⑥ 第二轮：触发中断"}),e.jsxs("p",{children:["「给张三转 200 元」→ 模型决定调 ",e.jsx("code",{children:'transfer_money(to="张三", amount=200)'})," → 工具体内 ",e.jsx("code",{children:"interrupt(...)"})," 触发，整张图",e.jsx("strong",{children:"暂停"}),"。 这次 invoke 的返回 ",e.jsx("code",{children:"r2"})," 里不会有最终答复，而是带上",e.jsx("code",{children:"__interrupt__"})," 这个键。代码用 ",e.jsx("code",{children:'if "__interrupt__" in r2'})," 检测到了暂停， 从 ",e.jsx("code",{children:'r2["__interrupt__"][0].value'})," 取出抛出的 payload（就是那个",e.jsx("code",{children:'{"action": "transfer", "to": "张三", "amount": 200}'})," 字典），打印给人看。"]}),e.jsx("h3",{children:"⑦ 第三轮：Command(resume) 续跑"}),e.jsxs("p",{children:["人看完后批准。",e.jsx("code",{children:'agent.invoke(Command(resume="approve"), config)'}),"—— 注意这次",e.jsx("strong",{children:"不传新消息"}),"，只传一个 ",e.jsx("code",{children:'Command(resume="approve")'}),"， 且 config 仍是同一个 thread_id。图从暂停处醒来，",e.jsx("code",{children:"transfer_money"})," 里的 ",e.jsx("code",{children:"decision"})," 收到 ",e.jsx("code",{children:'"approve"'}),"， 于是真正执行转账，返回「已向 张三 转账 200 元」，模型整理成最终答复。 如果这里传的是 ",e.jsx("code",{children:'Command(resume="reject")'}),"，则走拒绝分支。"]}),e.jsx("h2",{children:"预期输出"}),e.jsxs(i,{title:"终端打印（示意）",children:["助手: 当前余额：1000 元。",e.jsx("br",{}),"需要审批: ","{'action': 'transfer', 'to': '张三', 'amount': 200}",e.jsx("br",{}),"助手: 已向 张三 转账 200 元。"]}),e.jsxs("p",{children:["三行分别对应：只读查询的答复、被拦下的审批请求、人批准后续跑的结果。 把 ",e.jsx("code",{children:'resume="approve"'})," 改成 ",e.jsx("code",{children:'"reject"'}),"，最后一行会变成「用户拒绝了这笔转账」。"]}),e.jsx("h2",{children:"对照：手写一版等价的 StateGraph"}),e.jsxs("p",{children:[e.jsx("code",{children:"create_react_agent"})," 把图藏起来了。为了体会「显式控制」，我们不用预制件， 改用 ",e.jsx("code",{children:"StateGraph + add_node + add_conditional_edges"})," 亲手画出同样的 ReAct 循环—— 这下每条边都在你眼皮底下："]}),e.jsx(r,{lang:"python",title:"手写 StateGraph（等价骨架）",code:d}),e.jsxs("p",{children:["对比一下：预制件一行搞定，胜在快；手写版多了十几行，胜在",e.jsx("strong",{children:"每一步路由都可改"}),"—— 想加「转账失败自动重试」「先过一道风控节点」「按金额走不同审批路径」， 直接在图里加节点、改路由函数即可。这就是 LangGraph 用「写多点代码」换来的控制力。"]}),e.jsx("h2",{children:"常见报错与调试"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"没记忆 / Agent 失忆"}),"：compile 或 create_react_agent 时忘了传",e.jsx("code",{children:"checkpointer"}),"。没有它就没有跨轮记忆，interrupt 也无法暂停续跑。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"thread_id 不一致"}),"：每轮 invoke 用了不同的 thread_id（或干脆没传 config）， 会被当成全新会话，记忆断裂、resume 找不到要恢复的状态。三轮必须用同一个 config。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"interrupt 后没 resume"}),"：检测到 ",e.jsx("code",{children:"__interrupt__"})," 却没有用",e.jsx("code",{children:"Command(resume=...)"})," 续跑，图会一直卡在暂停态，转账永远不执行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"base_url 写错"}),"：百炼兼容端点必须是",e.jsx("code",{children:"https://dashscope.aliyuncs.com/compatible-mode/v1"}),"； 少写 ",e.jsx("code",{children:"/compatible-mode/v1"})," 或 Key 没设环境变量，会报 401 / 连接错误。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"resume 时还传新消息"}),"：续跑只需 ",e.jsx("code",{children:"Command(resume=...)"}),"， 不要同时塞 messages，否则可能扰乱暂停点的状态。"]})]}),e.jsx("h2",{children:"进阶方向"}),e.jsx("h3",{children:"用 SqliteSaver 真正落盘"}),e.jsxs("p",{children:[e.jsx("code",{children:"InMemorySaver"})," 一重启就清空。生产里换成 ",e.jsx("code",{children:"SqliteSaver"}),"（或",e.jsx("code",{children:"PostgresSaver"}),"），存档落到磁盘/数据库，重启后凭 thread_id 仍能恢复记忆与暂停点："]}),e.jsx(r,{lang:"python",title:"SqliteSaver 持久化",code:l}),e.jsx("h3",{children:"把审批做成独立节点"}),e.jsxs("p",{children:["本例把 ",e.jsx("code",{children:"interrupt"})," 写在工具内部，简单直接。更工程化的做法是手写图时新增一个",e.jsx("strong",{children:"专门的审批节点"}),"：高风险工具调用先路由到该节点 interrupt， 审批通过再路由到真正执行的节点。这样审批逻辑与业务逻辑解耦，也方便统一加审计日志。"]}),e.jsx("h3",{children:"用 LangSmith 追踪"}),e.jsxs("p",{children:["设置 ",e.jsx("code",{children:"LANGSMITH_TRACING=true"})," 与 ",e.jsx("code",{children:"LANGSMITH_API_KEY"})," 后， 每次运行的每个节点输入输出、每次工具调用、暂停与续跑，都会在 LangSmith 里可视化回放—— 排查「模型为什么选错工具」「在哪一步卡住」时极其有用。"]}),e.jsx(o,{points:["示例用 ChatOpenAI 接百炼 qwen-plus（base_url 指向 compatible-mode/v1），create_react_agent 组装出带工具的 ReAct Agent。","checkpointer + 同一 thread_id 提供跨轮记忆；三次 invoke 共享会话历史，缺一不可。",'高风险工具内部调 interrupt() 暂停，返回值带 __interrupt__；用 Command(resume="approve") 续跑（不传新消息）把人的决定喂回。',"手写 StateGraph（add_node/ToolNode/add_conditional_edges）可画出等价 ReAct 循环，换来对每条边的显式控制，便于加重试/风控/分级审批。","常见坑：忘传 checkpointer、thread_id 不一致、interrupt 后没 resume、base_url 写错；进阶用 SqliteSaver 落盘、审批独立成节点、LangSmith 追踪。"]})]})}export{j as default};
