import{j as e}from"./index-BAhU_Xet.js";import{L as l,S as o}from"./Summary-DeCBcqSp.js";import{K as r}from"./KeyIdea-DnEcW4Ye.js";import{C as n}from"./Callout-OljS8ooD.js";import{C as s}from"./CodeBlock-ClAC9vi8.js";import{E as c}from"./Example-D5OEBxRp.js";const i=`// 原始值：按值复制，两个变量互不相干
let a = 10
let b = a      // 把 10 这个值复制一份给 b
b = 20         // 改 b
console.log(a) // 10 ← a 毫发无损

let s1 = "hi"
let s2 = s1
s2 = "bye"
console.log(s1) // "hi"`,t=`// 引用类型：复制的是「引用」，两个变量指向同一个对象
let obj1 = { count: 1 }
let obj2 = obj1       // obj2 和 obj1 指向堆里同一个对象
obj2.count = 99       // 通过 obj2 改对象
console.log(obj1.count) // 99 ← obj1 也「变了」，因为本来就是同一个

// 数组同理
let arr1 = [1, 2, 3]
let arr2 = arr1
arr2.push(4)
console.log(arr1)     // [1, 2, 3, 4] ← 意外共享`,d=`// === 比较引用类型时，比的是「是不是同一个对象」，不是内容
{} === {}                       // false（两个不同的新对象）
[] === []                       // false
[1, 2] === [1, 2]               // false（内容相同，但不是同一个）

const a = { x: 1 }
const b = a
a === b                         // true（同一个引用）

// 想比内容，需要自己写比较，或序列化（有局限，见后文）
JSON.stringify({a:1}) === JSON.stringify({a:1}) // true`,j=`const original = { name: "Tom", info: { age: 18 } }

// 三种常见浅拷贝方式
const copy1 = { ...original }              // 展开运算符（最常用）
const copy2 = Object.assign({}, original)  // Object.assign
// 数组：
const arr = [1, 2, 3]
const arrCopy1 = [...arr]                  // 展开
const arrCopy2 = arr.slice()               // slice()

// 第一层是「独立」的
copy1.name = "Jerry"
console.log(original.name)  // "Tom" ← 第一层互不影响

// 但嵌套对象仍然共享！
copy1.info.age = 99
console.log(original.info.age) // 99 ← info 是同一个引用，被改了`,a=`const original = { name: "Tom", info: { age: 18 }, tags: ["a", "b"] }

// 方式一：structuredClone（现代浏览器 / Node 17+ 内置，推荐）
const deep1 = structuredClone(original)
deep1.info.age = 99
console.log(original.info.age) // 18 ← 嵌套也独立了

// 方式二：JSON 法（简单但有坑，见 Callout）
const deep2 = JSON.parse(JSON.stringify(original))

// 方式三：手写递归（理解原理用）
function deepClone(value) {
  if (value === null || typeof value !== "object") return value // 原始值直接返回
  if (Array.isArray(value)) return value.map(deepClone)
  const result = {}
  for (const key in value) {
    if (Object.prototype.hasOwnProperty.call(value, key)) {
      result[key] = deepClone(value[key]) // 递归处理每个属性
    }
  }
  return result
}`,h=`const obj = {
  fn: () => 1,          // 函数
  und: undefined,       // undefined
  sym: Symbol("s"),     // symbol
  date: new Date(),     // 日期
  nan: NaN,             // NaN
  inf: Infinity,        // Infinity
}

console.log(JSON.parse(JSON.stringify(obj)))
// {
//   date: "2026-06-17T...",  ← Date 变成了字符串！
//   nan: null,               ← NaN 变 null
//   inf: null,               ← Infinity 变 null
// }
// fn / und / sym 三个属性「凭空消失」——JSON 不支持它们
// 此外：循环引用会直接抛错 TypeError`,x=`// 函数传参是「按共享传递」：传进去的是引用的副本

// 1) 改对象的属性 —— 外部能看到（因为指向同一个对象）
function mutate(o) { o.count = 99 }
const obj = { count: 1 }
mutate(obj)
console.log(obj.count) // 99 ← 被改了

// 2) 重新赋值参数 —— 外部看不到（只是把局部的引用副本指向别处）
function reassign(o) { o = { count: 0 } }
const obj2 = { count: 1 }
reassign(obj2)
console.log(obj2.count) // 1 ← 不受影响`,u=`// 不可变更新：不改原对象，而是基于它造一个新对象

const state = { user: { name: "Tom" }, count: 1 }

// ❌ 直接改（在 React/Vue 里可能不触发更新，且破坏可预测性）
// state.count = 2

// ✅ 用展开创建新对象，只覆盖要变的字段
const next = { ...state, count: 2 }

// 嵌套更新：逐层展开
const next2 = {
  ...state,
  user: { ...state.user, name: "Jerry" },
}

// 数组同理：用 map / filter / 展开，而不是 push / splice
const list = [1, 2, 3]
const added = [...list, 4]          // 而非 list.push(4)
const removed = list.filter(x => x !== 2)
const updated = list.map(x => (x === 2 ? 20 : x))`;function N(){return e.jsxs("article",{children:[e.jsxs(l,{children:["上一章讲值与类型，这一章我们深入到一个让无数人栽跟头的话题：",e.jsx("strong",{children:"值类型与引用类型"}),"。 为什么 ",e.jsx("code",{children:"b = a"})," 后改 ",e.jsx("code",{children:"b"})," 有时影响 ",e.jsx("code",{children:"a"}),"、有时不影响？为什么",e.jsx("code",{children:"{} === {}"})," 是 ",e.jsx("code",{children:"false"}),"？为什么「拷贝」了对象，改副本却动了原件？ 理解了「栈与堆、值与引用」这一套心智模型，这些谜题会瞬间清晰， 也为后面理解 React / Vue 的「不可变更新」打下地基。"]}),e.jsx("h2",{children:"一、值类型 vs 引用类型"}),e.jsxs(r,{children:[e.jsx("strong",{children:"原始值"}),"（七种原始类型）按",e.jsx("strong",{children:"值"}),"存储与复制，可粗略理解为「存在栈上」；",e.jsx("strong",{children:"对象 / 数组 / 函数"}),"是引用类型，对象本体「存在堆上」，变量里持有的只是",e.jsx("strong",{children:"指向它的引用（地址）"}),"。赋值、传参时复制的，是值还是引用，决定了一切行为差异。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"值类型（原始值）"}),e.jsx("th",{children:"引用类型（对象）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"包含"}),e.jsx("td",{children:"string / number / boolean / null / undefined / symbol / bigint"}),e.jsx("td",{children:"object / array / function / Date / ..."})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"存储"}),e.jsx("td",{children:"值本身（概念上在栈）"}),e.jsx("td",{children:"本体在堆，变量持有引用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"赋值 / 传参"}),e.jsx("td",{children:"复制值本身"}),e.jsx("td",{children:"复制引用（仍指向同一本体）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"可变性"}),e.jsx("td",{children:"不可变"}),e.jsx("td",{children:"可变"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"=== 比较"}),e.jsx("td",{children:"比值是否相等"}),e.jsx("td",{children:"比是否同一个引用"})]})]})]}),e.jsx("h2",{children:"二、值类型：按值复制，互不相干"}),e.jsxs("p",{children:["原始值赋给另一个变量时，复制的是",e.jsx("strong",{children:"值本身"}),"。从此两个变量各持一份， 改一个绝不影响另一个。"]}),e.jsx(s,{lang:"js",title:"原始值：按值复制",code:i}),e.jsx("h2",{children:"三、引用类型：复制引用导致的「意外共享」"}),e.jsxs("p",{children:["对象不一样。",e.jsx("code",{children:"obj2 = obj1"})," 复制的不是对象内容，而是那个",e.jsx("strong",{children:"引用"}),"—— 两个变量像两个标签，贴在堆里",e.jsx("strong",{children:"同一个对象"}),"上。于是通过任意一个标签去改对象， 另一个「看到的」也变了。这就是著名的「意外共享」bug 的根源。"]}),e.jsx(s,{lang:"js",title:"引用类型：意外共享",code:t}),e.jsxs(n,{variant:"warn",title:"区分「改对象」与「重新赋值」",children:[e.jsx("code",{children:"obj2.count = 99"})," 是",e.jsx("strong",{children:"修改对象本体"}),"，会影响所有指向它的变量； 而 ",e.jsx("code",{children:"obj2 = {}"})," 是",e.jsx("strong",{children:"让 obj2 改指向一个新对象"}),"， 原来的 ",e.jsx("code",{children:"obj1"})," 不受影响。一个动本体，一个动标签，结果天差地别。"]}),e.jsx("h2",{children:"四、比较：比的是引用，不是内容"}),e.jsxs("p",{children:["引用类型用 ",e.jsx("code",{children:"==="}),"（或 ",e.jsx("code",{children:"=="}),"）比较时，问的是「",e.jsx("strong",{children:"是不是同一个对象"}),"」， 而非「内容是否相同」。所以两个长得一模一样的新对象永远不相等。"]}),e.jsx(s,{lang:"js",title:"对象比较的是引用",code:d}),e.jsxs("p",{children:["想比较「内容」，要么逐字段递归对比，要么序列化成字符串再比（如",e.jsx("code",{children:"JSON.stringify(a) === JSON.stringify(b)"}),"）——但后者依赖属性顺序、 且无法处理函数等，只能用于简单数据。"]}),e.jsx("h2",{children:"五、浅拷贝：只复制第一层"}),e.jsxs("p",{children:["既然直接赋值会共享，那就「拷贝」。最常用的是",e.jsx("strong",{children:"浅拷贝（shallow copy）"}),"： 展开运算符 ",e.jsx("code",{children:"{ ...obj }"}),"、",e.jsx("code",{children:"Object.assign({}, obj)"}),"、 数组的 ",e.jsx("code",{children:"arr.slice()"})," / ",e.jsx("code",{children:"[...arr]"}),"。"]}),e.jsxs(r,{children:["浅拷贝只复制",e.jsx("strong",{children:"第一层"}),"属性。第一层的原始值是独立的副本， 但第一层里若是",e.jsx("strong",{children:"嵌套对象"}),"，复制的仍是那个嵌套对象的",e.jsx("strong",{children:"引用"}),"—— 于是嵌套层依旧共享。这是浅拷贝最大的局限。"]}),e.jsx(s,{lang:"js",title:"浅拷贝及其局限",code:j}),e.jsx("h2",{children:"六、深拷贝：连嵌套一起复制"}),e.jsxs("p",{children:["要让嵌套层也彻底独立，需要",e.jsx("strong",{children:"深拷贝（deep copy）"}),"。现代环境首选内置的",e.jsx("code",{children:"structuredClone()"}),"；老办法是 ",e.jsx("code",{children:"JSON.parse(JSON.stringify(obj))"}),"（坑多）； 理解原理可以手写递归。"]}),e.jsx(s,{lang:"js",title:"三种深拷贝方式",code:a}),e.jsxs(n,{variant:"warn",title:"JSON 深拷贝的坑",children:[e.jsx("code",{children:"JSON.parse(JSON.stringify(obj))"})," 看似方便，但会悄悄丢数据或出错： 函数、",e.jsx("code",{children:"undefined"}),"、",e.jsx("code",{children:"symbol"})," 属性会直接",e.jsx("strong",{children:"消失"}),"；",e.jsx("code",{children:"Date"})," 变成字符串；",e.jsx("code",{children:"NaN"})," / ",e.jsx("code",{children:"Infinity"})," 变成 ",e.jsx("code",{children:"null"}),"； 遇到",e.jsx("strong",{children:"循环引用"}),"直接抛 ",e.jsx("code",{children:"TypeError"}),"。只适合纯粹的 JSON 安全数据。"]}),e.jsx(s,{lang:"js",title:"JSON 深拷贝丢数据演示",code:h}),e.jsxs(c,{title:"该用哪种拷贝？",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"只改第一层"}),"（如更新一个扁平配置对象的某个字段）：浅拷贝足够，用展开运算符。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"有嵌套且要彻底隔离"}),"，且数据可能含 Date / Map / 循环引用：用",e.jsx("code",{children:"structuredClone"}),"。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"数据是纯 JSON、且确定不含函数 / undefined / Date"}),"：JSON 法可用，但要清楚它的边界。"]})]}),e.jsx("h2",{children:"七、函数传参：按共享传递"}),e.jsxs("p",{children:["JS 的传参方式常被简化说成「值传递」，更准确的说法是",e.jsx("strong",{children:"按共享传递（call by sharing）"}),"： 传进函数的是",e.jsx("strong",{children:"引用的副本"}),"。这导致两种看似矛盾的现象，其实和第三节是一回事——",e.jsx("strong",{children:"改对象本体"}),"外部可见，",e.jsx("strong",{children:"给参数重新赋值"}),"外部不可见。"]}),e.jsx(s,{lang:"js",title:"按共享传递的两种表现",code:x}),e.jsx("h2",{children:"八、不可变更新：与 React / Vue 的呼应"}),e.jsxs("p",{children:["理解了「引用共享」，就能理解现代前端框架为什么强调",e.jsx("strong",{children:"不可变更新（immutable update）"}),"： 不去原地修改对象，而是",e.jsx("strong",{children:"基于旧对象创建一个新对象"}),"。"]}),e.jsxs("p",{children:["原因有两点：其一，React 靠",e.jsx("strong",{children:"比较前后引用是否改变"}),"来决定要不要重渲染—— 若你原地改了对象（引用没变），它可能",e.jsx("strong",{children:"察觉不到变化"}),"而漏更新； 其二，不可变让状态变化",e.jsx("strong",{children:"可预测、可追溯"}),"，调试与时间旅行都更容易。"]}),e.jsx(s,{lang:"js",title:"不可变更新的写法",code:u}),e.jsxs(n,{variant:"tip",title:"一句话原则",children:["在 React / Vue（尤其 React）里，",e.jsx("strong",{children:"永远不要原地 mutate 状态"}),"。 用展开运算符、",e.jsx("code",{children:"map"})," / ",e.jsx("code",{children:"filter"})," 等返回",e.jsx("strong",{children:"新对象 / 新数组"}),"， 让引用发生改变，框架才能正确感知更新。这正是本章「引用」知识在工程里的直接落地。"]}),e.jsx("h2",{children:"九、易错点小结"}),e.jsxs("ul",{children:[e.jsxs("li",{children:["对象赋值复制的是",e.jsx("strong",{children:"引用"}),"，不是内容；改一个会影响所有指向它的变量。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"{} === {}"})," 为 ",e.jsx("code",{children:"false"}),"：对象比较的是「是否同一个」，不是内容。"]}),e.jsxs("li",{children:["浅拷贝只独立第一层，",e.jsx("strong",{children:"嵌套对象仍共享"}),"。"]}),e.jsxs("li",{children:["深拷贝优先 ",e.jsx("code",{children:"structuredClone"}),"；JSON 法会丢函数 / undefined / symbol，变形 Date / NaN / Infinity，且循环引用报错。"]}),e.jsx("li",{children:"传参是按共享传递：改属性外部可见，重新赋值外部不可见。"}),e.jsx("li",{children:"框架里要不可变更新：返回新对象 / 新数组，靠引用变化触发更新。"})]}),e.jsx(o,{points:["原始值按值复制、互不相干；对象 / 数组 / 函数是引用类型，变量持有指向堆中本体的引用。","对象赋值只复制引用，导致「意外共享」——通过任一变量改对象本体，其它变量都受影响。","引用类型用 === 比的是「是否同一个对象」而非内容，故 {} === {} 与 [] === [] 都为 false。","浅拷贝（展开 / Object.assign / slice）只独立第一层，嵌套对象仍共享引用。","深拷贝首选 structuredClone；JSON 法会丢失函数 / undefined / symbol、变形 Date / NaN / Infinity、循环引用报错；也可手写递归。","函数传参是「按共享传递」：修改对象属性外部可见，给参数重新赋值外部不可见。","不可变更新（返回新对象 / 新数组）是 React/Vue 正确感知状态变化的前提，切勿原地 mutate。"]})]})}export{N as default};
