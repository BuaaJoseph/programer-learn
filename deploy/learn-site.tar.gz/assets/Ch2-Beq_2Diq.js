import{j as e}from"./index-B0-Um9Xw.js";import{L as s,C as r,a as c,P as n,S as t}from"./Summary-CRXglwZ1.js";import{K as o}from"./KeyIdea-zCCzkW7I.js";import{E as i}from"./Example-Djk5fvs9.js";const d=`// Java IO 流就是装饰器模式最经典的现实案例
// FileInputStream 是「被装饰的核心」，外面层层包裹装饰器

InputStream in =
    new BufferedInputStream(          // 装饰：加缓冲
        new FileInputStream("a.txt") // 核心：从文件读字节
    );

// 想再加「读基本类型」的能力？再套一层就行，原有代码不用动
DataInputStream din =
    new DataInputStream(
        new BufferedInputStream(
            new FileInputStream("a.txt")));

int b = din.readInt();   // 缓冲 + 读 int，能力一层层叠加`,l=`// 1. 抽象组件：定义统一接口
interface Coffee {
    double cost();
    String desc();
}

// 2. 具体组件：被装饰的核心对象
class SimpleCoffee implements Coffee {
    public double cost() { return 10.0; }
    public String desc() { return "原味咖啡"; }
}

// 3. 抽象装饰类：实现同一接口，并持有一个 Coffee 引用（组合）
abstract class CoffeeDecorator implements Coffee {
    protected final Coffee coffee;   // 持有被装饰对象
    protected CoffeeDecorator(Coffee coffee) {
        this.coffee = coffee;
    }
}

// 4. 具体装饰：在转发调用的基础上叠加自己的功能
class MilkDecorator extends CoffeeDecorator {
    public MilkDecorator(Coffee coffee) { super(coffee); }
    public double cost() { return coffee.cost() + 3.0; }
    public String desc() { return coffee.desc() + " + 牛奶"; }
}

class SugarDecorator extends CoffeeDecorator {
    public SugarDecorator(Coffee coffee) { super(coffee); }
    public double cost() { return coffee.cost() + 1.0; }
    public String desc() { return coffee.desc() + " + 糖"; }
}

class Demo {
    public static void main(String[] args) {
        // 像套娃一样动态组合：原味 -> 加奶 -> 加糖
        Coffee c = new SugarDecorator(new MilkDecorator(new SimpleCoffee()));
        System.out.println(c.desc() + " = " + c.cost());
        // 输出：原味咖啡 + 牛奶 + 糖 = 14.0
    }
}`;function f(){return e.jsxs(e.Fragment,{children:[e.jsx(s,{children:e.jsxs("p",{children:["这三个模式都属于",e.jsx("em",{children:"结构型"}),"模式，都在围着「一个已有对象」做文章，初学时极易混淆。 但它们的目的截然不同：装饰器要",e.jsx("strong",{children:"给对象加功能"}),"，适配器要",e.jsx("strong",{children:"把接口转个样"}),"， 外观要",e.jsx("strong",{children:"把一堆复杂东西藏到一个简单入口后面"}),"。记住意图，就再也不会混了。"]})}),e.jsx("h2",{children:"装饰器模式：动态叠加功能"}),e.jsxs("p",{children:[e.jsx("em",{children:"装饰器"}),"（Decorator）的意图是：",e.jsx("strong",{children:"在不修改原类、不写一堆子类的前提下，动态地给对象增加功能"}),"。 它的精髓是",e.jsx("strong",{children:"组合而非继承"}),"——装饰器实现和被装饰对象相同的接口，同时",e.jsx("strong",{children:"持有"}),"一个被装饰对象的引用， 在转发调用的前后插入自己的增强逻辑。这样就能像套娃一样把多个装饰器层层嵌套，功能自由组合。"]}),e.jsxs("p",{children:["为什么不用继承？因为如果靠子类来组合功能，「加奶」「加糖」「加奶又加糖」「加奶加糖加香草」……会发生",e.jsx("strong",{children:"子类爆炸"}),"。装饰器把这些功能拆成一个个可叠加的小装饰，运行期想怎么组合就怎么组合。"]}),e.jsx("h3",{children:"最经典的例子：Java IO 流的装饰器链"}),e.jsxs("p",{children:["Java 的 IO 体系就是装饰器模式的活教科书。",e.jsx("code",{children:"FileInputStream"})," 负责最基础的「从文件读字节」， 但它没有缓冲、读起来慢。于是用 ",e.jsx("code",{children:"BufferedInputStream"})," 把它",e.jsx("strong",{children:"包一层"}),"，加上缓冲能力； 想再读 int、double 等基本类型，就再套一层 ",e.jsx("code",{children:"DataInputStream"}),"。"]}),e.jsx(r,{lang:"java",title:"IoDecoratorChain.java",code:d}),e.jsxs(i,{title:"为什么是装饰器而不是继承",children:[e.jsx("p",{children:"假设 IO 用继承实现，那「带缓冲的文件流」「带缓冲又能读基本类型的文件流」「网络流的对应版本」…… 每种组合都得是一个新类，数量呈指数爆炸。"}),e.jsxs("p",{children:["而装饰器把「缓冲」「读基本类型」做成独立的装饰类，",e.jsx("code",{children:"FileInputStream"}),"、",e.jsx("code",{children:"SocketInputStream"})," 这些核心流都能被同样地包裹——",e.jsx("strong",{children:"能力可复用、可任意组合"}),"， 这正是装饰器优于继承的地方。"]})]}),e.jsx("h2",{children:"适配器模式：转换不兼容的接口"}),e.jsxs("p",{children:[e.jsx("em",{children:"适配器"}),"（Adapter）的意图是：",e.jsx("strong",{children:"把一个类的接口转换成客户端期望的另一种接口"}),"， 让原本因为接口不匹配而无法协作的两个东西能配合工作。它解决的是「接口对不上」的问题—— 好比把欧标插头通过转换头插进国标插座，",e.jsx("strong",{children:"不改变任何一方，只在中间做转换"}),"。"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"SLF4J 适配各日志框架"}),"——SLF4J 只是一套日志门面接口， 底层真正干活的可能是 Log4j、Logback、JUL。中间的 ",e.jsx("code",{children:"slf4j-log4j12"})," 之类的桥接包 就是适配器，把 SLF4J 的调用翻译成对应框架的 API。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"InputStreamReader"}),"——它把面向",e.jsx("strong",{children:"字节"}),"的 ",e.jsx("code",{children:"InputStream"}),"适配成面向",e.jsx("strong",{children:"字符"}),"的 ",e.jsx("code",{children:"Reader"}),"，中间顺带做编码转换，是 JDK 里的标准适配器。"]})]}),e.jsx("h2",{children:"外观模式：给复杂子系统一个统一入口"}),e.jsxs("p",{children:[e.jsx("em",{children:"外观"}),"（Facade）的意图是：",e.jsx("strong",{children:"为一组复杂的子系统提供一个统一、简化的高层入口"}),"， 让客户端不必了解内部的一堆类是怎么协作的，只跟这一个「门面」打交道。它降低了客户端与子系统之间的耦合。"]}),e.jsxs("p",{children:["最典型的就是 Spring MVC 的 ",e.jsx("code",{children:"DispatcherServlet"}),"：一个 HTTP 请求进来，它在背后协调",e.jsx("code",{children:"HandlerMapping"}),"、",e.jsx("code",{children:"HandlerAdapter"}),"、",e.jsx("code",{children:"ViewResolver"})," 等一堆组件， 但对你来说，复杂流程都被这一个「前端控制器」挡在了后面。你只管写 Controller，剩下的调度它全包了。"]}),e.jsx(o,{title:"三者意图区别（一句话记牢）",children:e.jsxs("p",{children:[e.jsx("strong",{children:"装饰器"}),"：接口不变，",e.jsx("strong",{children:"增强功能"}),"（同一个接口，能力变强）。",e.jsx("strong",{children:"适配器"}),"：接口改变，",e.jsx("strong",{children:"转换适配"}),"（把 A 接口包成 B 接口）。",e.jsx("strong",{children:"外观"}),"：接口简化，",e.jsx("strong",{children:"统一入口"}),"（把一堆接口收成一个简单接口）。 换句话说：装饰器关心「能力」，适配器关心「兼容」，外观关心「简化」。"]})}),e.jsxs(c,{variant:"warn",title:"别把装饰器和适配器搞反",children:[e.jsxs("p",{children:["面试常考它们的差别，关键看",e.jsx("strong",{children:"接口变没变"}),"："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"装饰器"}),"包裹后，对外暴露的还是",e.jsx("strong",{children:"同一个接口"}),"，只是行为被增强了—— 你照样把它当 ",e.jsx("code",{children:"InputStream"})," 用。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"适配器"}),"包裹后，对外暴露的是",e.jsx("strong",{children:"一个新接口"}),"——",e.jsx("code",{children:"InputStreamReader"})," 进去是 ",e.jsx("code",{children:"InputStream"}),"，出来是 ",e.jsx("code",{children:"Reader"}),"，接口变了。"]})]})]}),e.jsxs(n,{title:"手写一个装饰器：给咖啡加料",children:[e.jsxs("p",{children:["下面用「咖啡加料」实现一套完整的装饰器：",e.jsx("code",{children:"Coffee"})," 是抽象组件，",e.jsx("code",{children:"SimpleCoffee"})," 是被装饰的核心，",e.jsx("code",{children:"CoffeeDecorator"})," 是抽象装饰类（持有 Coffee 引用），",e.jsx("code",{children:"MilkDecorator"}),"、",e.jsx("code",{children:"SugarDecorator"})," 是具体装饰。复制到本地跑一遍， 体会「组合而非继承」是怎么让功能自由叠加的。"]}),e.jsx(r,{lang:"java",title:"CoffeeDecorator.java",code:l}),e.jsxs("p",{children:["进阶练习：再写一个 ",e.jsx("code",{children:"VanillaDecorator"}),"（加香草），然后任意调整嵌套顺序， 看看 ",e.jsx("code",{children:"desc"})," 和 ",e.jsx("code",{children:"cost"})," 的结果如何随组合变化——这正是装饰器链的灵活之处。"]})]}),e.jsx(t,{points:["装饰器：在不改原类的前提下动态叠加功能，核心是「组合而非继承」，可层层嵌套避免子类爆炸。","Java IO 流是装饰器的经典案例，如 BufferedInputStream 套 FileInputStream 再套 DataInputStream。","适配器：把一个类的接口转换成客户端期望的另一种接口，解决「接口对不上」的兼容问题。","适配器的现实例子：SLF4J 桥接各日志框架、InputStreamReader 把字节流适配成字符流。","外观：为复杂子系统提供统一简化的高层入口，如 Spring MVC 的 DispatcherServlet 调度一切。","三者意图区别：装饰器增强功能（接口不变）、适配器转换接口（接口变）、外观简化入口（接口收敛）。"]})]})}export{f as default};
