import{j as e}from"./index-Bkb6eOY7.js";import{L as t,S as i}from"./Summary-Dj-Y5ESD.js";import{K as s}from"./KeyIdea-N6HVLWjp.js";import{C as c}from"./Callout-FpvHzM97.js";import{C as r}from"./CodeBlock-BQqVtp_3.js";import{E as d}from"./Example-iLfTRUEi.js";const n=`# 用 Vite 脚手架创建一个 React 工程
npm create vite@latest my-app

# 交互式选择里：
#   Select a framework  ->  React
#   Select a variant    ->  JavaScript（或 TypeScript，本课用 JavaScript）

cd my-app
npm install      # 安装依赖
npm run dev      # 启动开发服务器，默认 http://localhost:5173`,o=`my-app/
├─ index.html          # 唯一的 HTML 入口，里面有 <div id="root"></div>
├─ package.json        # 依赖与脚本（dev / build / preview）
├─ vite.config.js      # Vite 配置
└─ src/
   ├─ main.jsx         # JS 入口：把 React 挂到 #root 上
   ├─ App.jsx          # 根组件
   ├─ App.css          # 组件样式
   └─ index.css        # 全局样式`,l=`// src/main.jsx —— 整个应用的挂载链路
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import './index.css'

// ① 找到 index.html 里的 <div id="root">
// ② createRoot 在它上面建立一个 React 渲染根
// ③ render 把 <App /> 这棵组件树渲染进去
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>
)`,p=`// src/App.jsx —— 你的第一个函数组件
function App() {
  // 函数组件 = 一个返回 JSX 的普通函数
  return (
    <div className="app">
      <h1>你好，React</h1>
      <p>这是我的第一个组件。</p>
    </div>
  )
}

// 默认导出，供 main.jsx 导入
export default App`,x=`// src/Hello.jsx —— 一个带 props 的最小可复用组件
function Hello({ name }) {
  return <p>你好，{name}！</p>
}

export default Hello`,j=`// src/App.jsx —— 导入并使用 Hello
import Hello from './Hello.jsx'

function App() {
  return (
    <div>
      <Hello name="小明" />
      <Hello name="小红" />   {/* 同一组件，传不同 props 复用 */}
    </div>
  )
}

export default App`,h=`// 大小写决定 React 怎么解读这个标签：
return <div><App /></div>      // App 大写 -> 当作「组件」，调用 App() 函数
// return <div><app /></div>   // app 小写 -> 当作原生 HTML 标签 <app>，不是你的组件！`;function v(){return e.jsxs("article",{children:[e.jsxs(t,{children:["上一章我们建立了 React 的心智模型，这一章把它落地：用现代脚手架 ",e.jsx("strong",{children:"Vite"}),"搭一个能跑的工程，理清从 ",e.jsx("code",{children:"index.html"})," 到屏幕上那行字之间的",e.jsx("strong",{children:"挂载链路"}),"， 然后亲手写出、导出、复用你的第一个",e.jsx("strong",{children:"函数组件"}),"。读完你会清楚地知道： 一个 React 应用是怎么从「一个空 div」长成「一棵组件树」的。"]}),e.jsx("h2",{children:"一、为什么用 Vite"}),e.jsxs("p",{children:["浏览器只认 HTML / CSS / JS，并不直接认 JSX 和模块化的源码，所以 React 工程需要一套",e.jsx("strong",{children:"构建工具"}),"把源码转译、打包。",e.jsx("strong",{children:"Vite"})," 是当下最主流的选择： 启动快（开发期按需编译，秒开），配置少，对 React 开箱即用。它取代了早年笨重的 Create React App，成为新项目的默认脚手架。"]}),e.jsx(c,{variant:"note",title:"Vite 与 React 是两回事",children:"Vite 是构建 / 开发工具，React 是 UI 库。Vite 负责「把你的源码变成浏览器能跑的东西、 并提供开发服务器」；React 负责「组件与渲染」。本课用 Vite 当工程底座，重点学 React 本身。"}),e.jsx("h2",{children:"二、创建工程"}),e.jsxs("p",{children:["确保装了 Node.js（建议 18+），然后一行命令创建工程。",e.jsx("code",{children:"npm create vite@latest"}),"会拉起一个交互式向导，让你选框架和语言变体——框架选 ",e.jsx("strong",{children:"React"}),"，变体本课选",e.jsx("strong",{children:"JavaScript"}),"。"]}),e.jsx(r,{lang:"bash",title:"创建并启动一个 Vite + React 工程",code:n}),e.jsxs("p",{children:["三步走：",e.jsx("code",{children:"npm install"})," 装依赖，",e.jsx("code",{children:"npm run dev"})," 起开发服务器， 浏览器打开它打印出的地址（默认 ",e.jsx("code",{children:"http://localhost:5173"}),"），就能看到 Vite 自带的 示例页面。开发服务器支持",e.jsx("strong",{children:"热更新"}),"：你改源码并保存，浏览器会自动局部刷新， 无需手动重载。"]}),e.jsx("h2",{children:"三、目录结构与挂载链路"}),e.jsx("p",{children:"新工程的关键文件不多，先认清它们各自的职责："}),e.jsx(r,{lang:"text",title:"Vite + React 的基本目录结构",code:o}),e.jsxs("p",{children:["理解一个 React 应用，最重要的是看懂它的",e.jsx("strong",{children:"挂载链路"}),"——React 这棵组件树到底是 从哪里、怎么接到页面上的。链路分三站："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"index.html"}),"：整个站点唯一的 HTML 文件，里面有一个空的",e.jsx("code",{children:'<div id="root"></div>'}),"，这是 React 的「落脚点」；它还用",e.jsx("code",{children:'<script type="module" src="/src/main.jsx">'})," 引入 JS 入口。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"src/main.jsx"}),"：JS 入口。它找到那个 ",e.jsx("code",{children:"#root"})," 节点， 建立 React 渲染根，并把根组件 ",e.jsx("code",{children:"<App />"})," 渲染进去。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"src/App.jsx"}),"：根组件，应用的界面从这里开始，往下展开成整棵组件树。"]})]}),e.jsx(r,{lang:"jsx",title:"src/main.jsx：把 App 渲染到 root 上",code:l}),e.jsxs(s,{children:["挂载链路一句话：",e.jsx("code",{children:"index.html"})," 里有个空的 ",e.jsx("code",{children:"#root"}),"，",e.jsx("code",{children:"main.jsx"})," 用 ",e.jsx("code",{children:"createRoot(document.getElementById('root'))"}),"在它上面建一个 React 根，再 ",e.jsx("code",{children:".render(<App />)"})," 把组件树渲染进去。 从此页面这块区域就交给 React 管理了。"]}),e.jsx("h2",{children:"四、第一个函数组件"}),e.jsxs("p",{children:["现在看主角 ",e.jsx("code",{children:"App"}),"。在现代 React 里，",e.jsx("strong",{children:"组件就是一个返回 JSX 的函数"}),"—— 没有别的玄机。它接收输入（props），返回一段描述「该长什么样」的 JSX。"]}),e.jsx(r,{lang:"jsx",title:"src/App.jsx：一个返回 JSX 的函数",code:p}),e.jsxs(s,{children:["函数组件 = 接收 ",e.jsx("code",{children:"props"}),"、返回 JSX 的普通 JavaScript 函数。 它本质上就是上一章说的那个 ",e.jsx("code",{children:"f"}),"——把状态 / 输入映射成界面描述。 React 在需要时调用它，拿到返回的 JSX 去更新界面。"]}),e.jsx("h3",{children:"组件名为什么必须大写开头"}),e.jsxs("p",{children:["这是一条",e.jsx("strong",{children:"硬性规则"}),"，不是风格偏好。JSX 在编译后，遇到标签时要决定： 这是一个原生 HTML 标签（如 ",e.jsx("code",{children:"<div>"}),"），还是你自定义的组件？React 用",e.jsx("strong",{children:"首字母大小写"}),"来区分——小写开头当作原生标签，大写开头当作组件去调用你的函数。"]}),e.jsx(r,{lang:"jsx",title:"大小写决定标签的含义",code:h}),e.jsxs(c,{variant:"warn",title:"组件名写成小写会渲染不出来",children:["如果你把组件命名为 ",e.jsx("code",{children:"app"})," 并写 ",e.jsx("code",{children:"<app />"}),"，React 会把它当成一个名叫 app 的原生 HTML 标签来处理——结果就是你的组件根本没被调用，页面上什么也不显示， 且通常不会报明显的错。",e.jsx("strong",{children:"组件名一律大写开头"}),"（PascalCase），这是必须记住的铁律。"]}),e.jsx("h2",{children:"五、导出与导入：把组件拼起来"}),e.jsxs("p",{children:["组件要在别处被使用，就得",e.jsx("strong",{children:"导出"}),"；使用方再",e.jsx("strong",{children:"导入"}),"它。上面",e.jsx("code",{children:"App.jsx"})," 末尾的 ",e.jsx("code",{children:"export default App"})," 就是默认导出，",e.jsx("code",{children:"main.jsx"})," 里的 ",e.jsx("code",{children:"import App from './App.jsx'"})," 就是对应的导入。 这正是组件化「组合」的机制：每个组件住在自己的文件里，通过 import / export 拼装成树。"]}),e.jsxs(d,{title:"写一个可复用组件并在 App 里用两次",children:[e.jsxs("p",{children:["新建 ",e.jsx("code",{children:"src/Hello.jsx"}),"，写一个接收 ",e.jsx("code",{children:"name"})," 的小组件并默认导出："]}),e.jsx(r,{lang:"jsx",title:"src/Hello.jsx",code:x}),e.jsxs("p",{children:["回到 ",e.jsx("code",{children:"App.jsx"}),"，导入它，用不同 props 渲染两次——这就是「复用」："]}),e.jsx(r,{lang:"jsx",title:"src/App.jsx：导入并复用 Hello",code:j}),e.jsx("p",{children:"保存后，借助热更新，浏览器里会立刻出现「你好，小明！」和「你好，小红！」两行。 同一个组件函数，靠不同的 props 输出不同的界面——这就是组件复用最朴素的样子。"})]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"写法"}),e.jsx("th",{children:"导出"}),e.jsx("th",{children:"导入"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"默认导出（一个文件一个主组件，最常用）"}),e.jsx("td",{children:e.jsx("code",{children:"export default App"})}),e.jsx("td",{children:e.jsx("code",{children:"import App from './App.jsx'"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"具名导出（一个文件导出多个东西）"}),e.jsx("td",{children:e.jsx("code",{children:"export function Hello() "})}),e.jsx("td",{children:e.jsx("code",{children:"import { Hello } from './Hello.jsx'"})})]})]})]}),e.jsx("h2",{children:"六、新 JSX 转换：不必再 import React"}),e.jsxs("p",{children:["你也许在老教程里见过每个组件文件顶部都写着 ",e.jsx("code",{children:"import React from 'react'"}),"。 本课的示例里却没有这一行——这不是漏写。",e.jsx("strong",{children:"React 17"})," 起引入了",e.jsx("strong",{children:"新的 JSX 转换"}),"：编译工具会自动注入运行时所需的导入，你写 JSX 不必再手动 ",e.jsx("code",{children:"import React"}),"。"]}),e.jsxs(s,{children:["在 React 17+ 与 Vite 这类现代工具链下，",e.jsx("strong",{children:"写 JSX 不需要再 import React"}),"。 只有当你直接用到 React 命名空间下的 API（如 ",e.jsx("code",{children:"React.memo"}),"）时才需要导入对应的东西， 而即便那样，更常见的写法也是按需具名导入（如 ",e.jsx("code",{children:"import { useState } from 'react'"}),"）。"]}),e.jsx("h2",{children:"七、StrictMode：开发期的「双调用」检查"}),e.jsxs("p",{children:["回看 ",e.jsx("code",{children:"main.jsx"}),"，",e.jsx("code",{children:"<App />"})," 被包在 ",e.jsx("code",{children:"<StrictMode>"})," 里。",e.jsx("strong",{children:"严格模式"}),"是 React 内建的一个开发期辅助工具，本身不渲染任何界面， 作用是帮你",e.jsx("strong",{children:"提前暴露潜在问题"}),"：使用了过时 API 会警告，更重要的是它会",e.jsx("strong",{children:"故意把某些函数调用两次"}),"（组件渲染、部分 Hook 的初始化等）。"]}),e.jsxs(c,{variant:"note",title:"为什么要故意双调用",children:["React 期望你的组件渲染是「纯」的——同样的输入算出同样的输出，且不在渲染过程中制造副作用。 StrictMode 在开发期故意调两次，如果你的组件依赖「只跑一次」的副作用（比如在渲染里改了外部变量）， 双调用就会让 bug 当场现形。它",e.jsx("strong",{children:"只在开发环境生效"}),"，生产构建里不会双调用， 也不影响性能。看到控制台里日志打了两遍，别慌，这是它在工作。"]}),e.jsx("h2",{children:"八、把整条链路串起来"}),e.jsx("p",{children:"到这里，一个最小 React 应用的全貌就清晰了，自上而下："}),e.jsxs("ol",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"index.html"})," 提供一个空的 ",e.jsx("code",{children:"#root"})," 容器，并加载 ",e.jsx("code",{children:"main.jsx"}),"。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"main.jsx"})," 用 ",e.jsx("code",{children:"createRoot(#root).render(<App />)"})," 把组件树挂上去，外面裹一层 ",e.jsx("code",{children:"StrictMode"}),"。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"App"})," 这个函数组件返回 JSX，并可组合 ",e.jsx("code",{children:"Hello"})," 等子组件，向下展开成整棵树。"]}),e.jsxs("li",{children:["每个组件靠 ",e.jsx("code",{children:"export"})," / ",e.jsx("code",{children:"import"})," 拼装，靠 ",e.jsx("code",{children:"props"})," 复用，名字一律大写开头。"]}),e.jsxs("li",{children:["Vite 在背后转译 JSX、提供热更新；React 17+ 的新转换让你免写 ",e.jsx("code",{children:"import React"}),"。"]})]}),e.jsxs(c,{variant:"tip",children:["建议你现在就照着本章把工程跑起来，把 ",e.jsx("code",{children:"App.jsx"})," 改成自己的内容、新建一个组件试试复用。 下一卷我们将正式进入 JSX 的细节与 props、state 的用法，让组件「活」起来、能响应交互。"]}),e.jsx(i,{points:["用 npm create vite@latest 创建工程，框架选 React；npm install 装依赖、npm run dev 起开发服务器（默认 5173），支持热更新。","挂载链路：index.html 的空 #root -> main.jsx 用 createRoot(#root).render(<App />) 建根并渲染组件树 -> App 是根组件向下展开。","函数组件就是「接收 props、返回 JSX 的普通函数」，本质即上一章的 f：把输入映射成界面描述。","组件名必须大写开头：JSX 用首字母大小写区分原生标签（小写）与自定义组件（大写），写成小写会被当 HTML 标签而渲染不出来。","组件靠 export 导出、import 导入来组合复用；默认导出与具名导出对应不同的导入写法。","React 17+ 的新 JSX 转换让你不必再 import React；StrictMode 是开发期辅助，会故意双调用以暴露不纯的副作用，仅在开发环境生效。"]})]})}export{v as default};
