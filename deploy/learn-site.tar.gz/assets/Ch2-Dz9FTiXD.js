import{j as e}from"./index-DraKZMSn.js";import{L as d,S as i}from"./Summary-D7nqkGRf.js";import{K as t}from"./KeyIdea-C2HcfWY0.js";import{C as r}from"./Callout-BE-nWzIM.js";import{C as s}from"./CodeBlock-BiqAHAS8.js";import{E as n}from"./Example-yyME7alB.js";import{R as c}from"./RenderCycle-D9h5H4zt.js";import"./Figure-BqzlOW-g.js";const o=`function Parent() {
  const [n, setN] = useState(0)
  return (
    <div>
      <button onClick={() => setN(n + 1)}>+1</button>
      {/* Parent 因自身 state 变化而重渲染时，
          Child 默认也会跟着重渲染——哪怕它的 props 一点没变 */}
      <Child />
    </div>
  )
}`,l=`// 1) 不同类型 => 整棵子树直接替换（卸载旧的、挂载新的）
isLoggedIn ? <Dashboard /> : <LoginForm />
// 从 Dashboard 切到 LoginForm：React 不会试图复用，
// 直接销毁 Dashboard 及其全部子节点与状态，再全新挂载 LoginForm。

// 2) 同类型 => 复用 DOM 节点，只更新变化的 props
<button className="a" />  ->  <button className="b" />
// 还是同一个 <button>，React 只把 className 从 a 改成 b，
// 节点本身（以及它内部的状态）保留下来。`,x=`// ❌ 用数组下标当 key：增删 / 排序时会出错
{todos.map((todo, i) => (
  <TodoItem key={i} todo={todo} />
))}

// ✅ 用数据本身稳定的唯一 id 当 key
{todos.map((todo) => (
  <TodoItem key={todo.id} todo={todo} />
))}`,h=`// 一个会「串值」的列表：每行带一个非受控输入框
function Row({ label }) {
  return (
    <li>
      {label}：<input defaultValue="" placeholder="备注" />
    </li>
  )
}

function List({ rows }) {
  return (
    <ul>
      {rows.map((r, i) => (
        // ❌ key={i}：删头部一行后，下标会整体前移
        <Row key={i} label={r.label} />
      ))}
    </ul>
  )
}`,j=`function List({ rows }) {
  return (
    <ul>
      {rows.map((r) => (
        // ✅ key={r.id}：身份跟着数据走，删谁就只删谁那一行的输入框
        <Row key={r.id} label={r.label} />
      ))}
    </ul>
  )
}`,a=`const [count, setCount] = useState(0)

// 传入与当前完全相同的值（Object.is 比较）
setCount(0)   // 当前就是 0 => React 直接 bail out，不触发这一次重渲染
setCount(1)   // 值变了 => 正常调度重渲染

// 注意：对象 / 数组即便内容看着一样，引用不同也算「变了」
const [obj, setObj] = useState({ a: 1 })
setObj({ a: 1 })  // 新对象，引用不同 => 仍会重渲染`;function b(){return e.jsxs("article",{children:[e.jsxs(d,{children:["上一章我们看清了「一次更新走过 Render → Reconcile → Commit 三相」。这一章聚焦其中的 Reconcile： 组件到底",e.jsx("strong",{children:"什么时候"}),"重渲染、diff ",e.jsx("strong",{children:"改了什么"}),"、以及那个被无数人用错的",e.jsx("code",{children:"key"})," 究竟在背后做什么。最后用一个「输入框串值」的翻车现场，把抽象的规则砸实。"]}),e.jsx("h2",{children:"一、组件什么时候重渲染"}),e.jsxs("p",{children:["重渲染（re-render）指的是 React ",e.jsx("strong",{children:"再次调用"}),"组件函数、算出一棵新元素树—— 注意，这只是上一章说的 Render 阶段，并不等于真实 DOM 一定会改。一个组件会重渲染， 通常出于以下三种原因之一。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"触发原因"}),e.jsx("th",{children:"说明"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"自身 state 变化"}),e.jsxs("td",{children:["调用了 ",e.jsx("code",{children:"setState"})," / ",e.jsx("code",{children:"dispatch"}),"，且值确实变了。"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"父组件重渲染"}),e.jsxs("td",{children:["父组件重渲染，其下的子组件默认",e.jsx("strong",{children:"全部"}),"跟着重渲染。"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"订阅的 context 变化"}),e.jsxs("td",{children:["组件用了某个 ",e.jsx("code",{children:"useContext"}),"，而该 context 的 value 变了。"]})]})]})]}),e.jsx(s,{lang:"jsx",title:"父组件重渲染会带动子组件",code:o}),e.jsxs(t,{children:["最常被误解的一点：",e.jsx("strong",{children:"父组件重渲染，它的子组件默认会全部重渲染"}),"，哪怕子组件的 props 一个字都没变。重渲染是",e.jsx("strong",{children:"沿组件树向下传播"}),"的，而不是「只重渲染数据变了的那个」。 React 默认",e.jsx("strong",{children:"不会"}),"帮你自动跳过「props 没变」的子组件。"]}),e.jsx("h2",{children:"二、为什么「全部重渲染」通常并不慢"}),e.jsxs("p",{children:["听到「父一渲染，子全重渲染」，很多人第一反应是「那不是很浪费？」。实际上它通常不慢，原因在于： 重渲染只是",e.jsx("strong",{children:"在内存里重新调用函数、重新跑 diff"}),"，这部分对现代 JS 引擎来说很便宜； 真正昂贵的是",e.jsx("strong",{children:"操作真实 DOM"}),"，而 diff 之后如果发现没有实际变化，Commit 阶段就",e.jsx("strong",{children:"几乎什么都不做"}),"。"]}),e.jsxs("p",{children:["换句话说：「重渲染」≠「改 DOM」。一次没带来真实改动的重渲染，代价主要是一点点纯计算。 所以默认不要急着到处加优化——只有当某个组件的 render 本身确实重（大列表、复杂计算、昂贵子树） 且被频繁带动时，才值得出手。具体怎么减少不必要的重渲染（",e.jsx("code",{children:"React.memo"}),"、",e.jsx("code",{children:"useMemo"}),"、",e.jsx("code",{children:"useCallback"}),"、状态下沉等），是后面性能优化卷（r8）的主题，这里只先剧透方向。"]}),e.jsxs(r,{variant:"note",title:"先量，再优化",children:["在加 ",e.jsx("code",{children:"memo"})," 之前，先用 React DevTools 的 Profiler 看清「到底是哪个组件慢、慢在哪一次重渲染」。 盲目套优化反而会增加心智负担和 bug 面——过早优化是这里最常见的坑。"]}),e.jsx("h2",{children:"三、diff 的三条启发式规则"}),e.jsxs("p",{children:["理论上比对两棵树的最优算法成本很高，React 为此用了三条",e.jsx("strong",{children:"启发式假设"}),"把它压到近线性， 这也正是 Reconcile 阶段「改了什么」的判定依据。"]}),e.jsx("h3",{children:"规则一：类型不同，整棵子树直接替换"}),e.jsxs("p",{children:["同一位置上，如果元素的 ",e.jsx("code",{children:"type"})," 变了（比如从 ",e.jsx("code",{children:"<div>"})," 变成 ",e.jsx("code",{children:"<span>"}),"， 或从组件 A 变成组件 B），React ",e.jsx("strong",{children:"不会"}),"尝试复用，而是把旧子树整个卸载、新子树全新挂载—— 旧节点里的 DOM 与组件状态全部丢弃。"]}),e.jsx("h3",{children:"规则二：类型相同，复用节点、只更新 props"}),e.jsxs("p",{children:["同一位置类型不变，React 就",e.jsx("strong",{children:"复用"}),"已有的 DOM 节点 / 组件实例，只把变化的 props 更新上去，组件内部的 state 得以保留。这是最常见、也最高效的情况。"]}),e.jsx(s,{lang:"jsx",title:"规则一与规则二",code:l}),e.jsx("h3",{children:"规则三：列表靠 key 匹配身份"}),e.jsxs("p",{children:["渲染一个列表时，React 默认按",e.jsx("strong",{children:"位置（下标）"}),"逐个比对同位置的新旧元素。但当列表会发生 增、删、排序时，光靠位置就会错位。",e.jsx("code",{children:"key"})," 的作用，是给每个列表项一个",e.jsx("strong",{children:"稳定的身份标签"}),"， 让 React 跨越位置变化，认出「这还是原来那一项」，从而正确地复用 / 移动 / 删除，而不是错配。"]}),e.jsx("h2",{children:"四、key 是什么，以及用 index 当 key 的坑"}),e.jsxs(t,{children:[e.jsx("code",{children:"key"})," 不是给你看的，是给 React 用来",e.jsx("strong",{children:"在同一层兄弟节点之间标识身份"}),"的。 它必须在兄弟之间",e.jsx("strong",{children:"唯一且稳定"}),"——「稳定」意味着同一条数据无论排到哪个位置， 它的 key 都不变。用数组下标 ",e.jsx("code",{children:"index"})," 当 key，恰恰违背了「稳定」：一旦增删 / 排序， 下标会重新分配，React 就会把张冠李戴。"]}),e.jsx(s,{lang:"jsx",title:"index 当 key vs 用稳定 id",code:x}),e.jsxs("p",{children:["为什么 index 当 key 会出错？因为 React 是",e.jsx("strong",{children:"按 key 来决定复用哪个节点"}),"的。 当你在列表头部删掉一项，后面所有项的下标都会前移一格——于是「key=1」这个标签， 在删除前后指向的是",e.jsx("strong",{children:"两条不同的数据"}),"。React 以为「key=1 还在」，便把原本属于另一条数据的 DOM 节点、内部状态留给了它。对纯静态文本，你可能只看到内容串了一格； 但只要列表项里藏着",e.jsx("strong",{children:"自己的状态"}),"（输入框、勾选、展开/收起、动画），就会出现明显的「串值」。"]}),e.jsx("h2",{children:"五、翻车现场：输入框串值对照例"}),e.jsx("p",{children:"下面这个列表，每一行带一个非受控输入框（输入框的内容是它自己的内部状态，不在 React state 里）。"}),e.jsx(s,{lang:"jsx",title:"问题版：key={'{i}'} 导致串值",code:h}),e.jsxs(n,{title:"按下「删除第一行」时发生了什么",children:[e.jsx("p",{children:"初始三行，你在每个输入框里分别填了备注："}),e.jsxs("ul",{children:[e.jsxs("li",{children:["第 0 行「苹果」，输入框里写了 ",e.jsx("code",{children:"买 3 个"}),"（这是该 DOM 输入框的内部状态）"]}),e.jsxs("li",{children:["第 1 行「香蕉」，输入框里写了 ",e.jsx("code",{children:"买 5 根"})]}),e.jsxs("li",{children:["第 2 行「橙子」，输入框里写了 ",e.jsx("code",{children:"买 2 个"})]})]}),e.jsxs("p",{children:["现在删掉第 0 行「苹果」。数据上只剩「香蕉、橙子」两行，",e.jsx("strong",{children:"本应"}),"显示 ",e.jsx("code",{children:"买 5 根"})," 和",e.jsx("code",{children:"买 2 个"}),"。但因为 key 用的是 index：删除后「香蕉」的下标从 1 变成 0、「橙子」从 2 变成 1。 React 按 key 比对，发现「key=0 还在、key=1 还在，只是 key=2 没了」，于是它",e.jsx("strong",{children:"复用"}),"了 原来 key=0 和 key=1 那两个输入框 DOM——可那俩输入框里装的还是",e.jsx("strong",{children:"「苹果」和「香蕉」的备注"}),"！"]}),e.jsxs("p",{children:["结果：标签文字（来自 props，会更新）正确地显示「香蕉、橙子」，但输入框内容（DOM 自身状态，被错误复用） 却串成了 ",e.jsx("code",{children:"买 3 个"}),"、",e.jsx("code",{children:"买 5 根"}),"。文字和输入框对不上，这就是经典的「输入框串值」。"]})]}),e.jsx(s,{lang:"jsx",title:"修复版：key={'{r.id}'} 让身份跟着数据走",code:j}),e.jsxs("p",{children:["换成稳定的 ",e.jsx("code",{children:"r.id"})," 后，删掉「苹果」那行，React 发现「id=苹果」这个 key 消失了， 便精准卸载它对应的输入框；「香蕉」「橙子」的 key 没变，它们各自的输入框被原样保留，内容纹丝不动。 身份跟着数据走，串值问题随之消失。"]}),e.jsxs(r,{variant:"warn",title:"什么时候 index 当 key 才勉强可以",children:["只有当列表",e.jsx("strong",{children:"纯静态、永不增删与排序、且列表项自身没有任何内部状态"}),"时，用 index 当 key 才不会出问题。 但这种条件很苛刻也很容易在日后被打破，所以实践上的建议很简单：",e.jsx("strong",{children:"优先用数据本身稳定的唯一 id"}),"。"]}),e.jsx("h2",{children:"六、key 还能当「重置」开关用"}),e.jsxs("p",{children:["既然 key 决定身份，那么",e.jsx("strong",{children:"主动改变 key"})," 就是在告诉 React「这已经不是原来那个组件了， 请把它整个卸载重建」。这是一个非常实用的小技巧：当你希望某个组件",e.jsx("strong",{children:"彻底重置内部状态"}),"时， 给它一个会变化的 key 即可，比换一堆 props 或在 effect 里手动清状态都干净。"]}),e.jsx(n,{title:"切换用户时重置整张表单",children:e.jsxs("p",{children:["一个编辑表单 ",e.jsx("code",{children:"<ProfileForm userId={id} />"}),"，内部用 state 暂存用户的输入。切换到另一个用户后， 表单里却残留着上一个用户的内容。最省事的修法是 ",e.jsx("code",{children:"<ProfileForm key={id} userId={id} />"}),"：",e.jsx("code",{children:"id"})," 一变，key 随之变，React 直接卸载旧表单、挂载一个全新的，内部 state 自然回到初始值。 这正是「key 即身份」这条规则反过来为我们所用。"]})}),e.jsx("h2",{children:"七、setState 传相同值会 bail out"}),e.jsxs("p",{children:["重渲染并非「调了 setState 就一定发生」。当你传给 setter 的值与当前 state ",e.jsx("strong",{children:"完全相同"}),"（React 用 ",e.jsx("code",{children:"Object.is"})," 比较），React 会",e.jsx("strong",{children:"跳过（bail out）"}),"这一次更新， 不再重新渲染该组件。这能省下没必要的计算。"]}),e.jsx(s,{lang:"jsx",title:"相同值触发 bail out",code:a}),e.jsxs(r,{variant:"note",title:"对象 / 数组要小心引用",children:["bail out 靠的是 ",e.jsx("code",{children:"Object.is"})," 这种「引用相等」式比较。两个内容看起来一样的",e.jsx("strong",{children:"新对象"}),"引用不同，会被判为「变了」而照常重渲染。这也是为什么状态尽量保持不可变更新、且别在 render 里 随手新建对象传下去——后者会让下游的 ",e.jsx("code",{children:"memo"})," 优化全部失效（r8 会细讲）。"]}),e.jsx("h2",{children:"八、关于 context 触发的重渲染"}),e.jsxs("p",{children:["三种触发原因里，context 这一条最容易埋雷。当某个 ",e.jsx("code",{children:"Context.Provider"})," 的 ",e.jsx("code",{children:"value"})," 变化时，",e.jsx("strong",{children:"所有"}),"消费该 context（用了对应 ",e.jsx("code",{children:"useContext"}),"）的组件都会重渲染，无论它们藏在树里多深、 中间隔了多少层。这本是 context 的设计目的，但配合「render 里随手新建对象」就会出问题。"]}),e.jsx(n,{title:"一个常见的 context 性能陷阱",children:e.jsxs("p",{children:["如果你写 ",e.jsx("code",{children:"<Ctx.Provider value={{ user, setUser }}>"}),"，那么 Provider 每次重渲染都会 新建一个 ",e.jsx("code",{children:"{ user, setUser }"})," 对象——引用每次都变，于是",e.jsx("strong",{children:"每一个"}),"消费者都被迫重渲染， 哪怕 ",e.jsx("code",{children:"user"})," 实际没动。解法是把这个 value 用 ",e.jsx("code",{children:"useMemo"})," 缓存起来，让引用在依赖不变时保持稳定。 这又一次印证了上一节的提醒：",e.jsx("strong",{children:"引用稳定性"}),"是 React 性能的隐形主线（r8 详谈）。"]})}),e.jsx("h2",{children:"九、把流程图再看一眼"}),e.jsx("p",{children:"本章讲的「何时重渲染、diff 改了什么」对应的正是下图里的 ② Render 与 ③ 调和两步。 再点开走一遍，把「触发 → 算新树 → diff 比对 → 提交」的链路与本章规则对上号。"}),e.jsx(c,{}),e.jsx(i,{points:["组件重渲染的三种原因：自身 state 变化、父组件重渲染、所订阅的 context 变化。","父组件重渲染时子组件默认全部跟着重渲染（不看 props 是否变）；但它通常不慢，因为重渲染只是内存计算，没真实改动的 Commit 几乎什么都不做。","diff 三条启发式：类型不同整棵子树替换；类型相同复用节点只更新 props；列表靠 key 匹配身份。","key 用于在兄弟节点间标识身份，必须唯一且稳定；用数组 index 当 key 在增删/排序时会让身份错位。","经典翻车：列表项带自身状态（如输入框）时用 index 当 key，删除一行会因节点被错误复用而导致「串值」，换成稳定 id 即修复。","setState 传入与当前 Object.is 相等的值会 bail out 跳过重渲染；但新对象/数组引用不同仍会触发——减少不必要重渲染的系统方法见 r8。"]})]})}export{b as default};
