import{j as e}from"./index-CVHWXZpb.js";import{L as i,S as d}from"./Summary-CJTCDEeZ.js";import{K as r}from"./KeyIdea-XVLVSS4B.js";import{C as s}from"./Callout-DCq22jZW.js";import{C as n}from"./CodeBlock-ljkh5ShG.js";import{E as t}from"./Example-BSuN_UvG.js";import{P as o}from"./Practice-D2QRX8ZH.js";import{P as l}from"./PyRunner-DI0kjGpk.js";const c=`fruits = ["苹果", "香蕉", "橙子"]

# 增：在末尾添加
fruits.append("葡萄")
print("添加后：", fruits)

# 改：修改某个位置
fruits[0] = "西瓜"
print("修改后：", fruits)

# 删：删掉某个元素
fruits.remove("香蕉")
print("删除后：", fruits)

# 查 + 切片
print("第一个：", fruits[0])
print("前两个：", fruits[0:2])

# 排序（不改变原列表）
nums = [3, 1, 4, 1, 5, 9, 2]
print("排序：", sorted(nums))`,x=`fruits = ["苹果", "香蕉", "橙子"]
nums = [10, 20, 30, 40]
mixed = [1, "你好", 3.14, True]   # 一个列表里可以放不同类型
empty = []                        # 空列表
print(fruits)
print(len(fruits))                # 列表里有几个元素`,h=`['苹果', '香蕉', '橙子']
3`,j=`fruits = ["苹果", "香蕉", "橙子", "葡萄"]
print(fruits[0])     # 第一个，下标从 0 开始
print(fruits[-1])    # 倒数第一个
print(fruits[1:3])   # 切片，含头不含尾
fruits[0] = "西瓜"    # 修改某个元素
print(fruits)`,p=`苹果
葡萄
['香蕉', '橙子']
['西瓜', '香蕉', '橙子', '葡萄']`,m=`nums = [1, 2, 3]
nums.append(4)        # 末尾追加
print(nums)
nums.insert(0, 99)    # 在下标 0 处插入
print(nums)
nums.pop()            # 删掉最后一个（并返回它）
print(nums)
nums.remove(99)       # 按值删除（删第一个匹配的）
print(nums)`,u=`[1, 2, 3, 4]
[99, 1, 2, 3, 4]
[99, 1, 2, 3]
[1, 2, 3]`,a=`fruits = ["苹果", "香蕉", "橙子"]
for f in fruits:
    print("我爱吃", f)`,f=`我爱吃 苹果
我爱吃 香蕉
我爱吃 橙子`,g=`nums = [3, 1, 4, 1, 5, 9, 2]
print(len(nums))      # 长度
nums.sort()           # 原地排序（从小到大）
print(nums)
nums.reverse()        # 原地反转
print(nums)
print(9 in nums)      # 9 在列表里吗
print(7 in nums)`,y=`7
[1, 1, 2, 3, 4, 5, 9]
[9, 5, 4, 3, 2, 1, 1]
True
False`,v=`# 用嵌套列表表示一个 2x3 的表格
matrix = [
    [1, 2, 3],
    [4, 5, 6],
]
print(matrix[0])      # 第一行
print(matrix[0][1])   # 第一行第二个元素
print(matrix[1][2])`,C=`[1, 2, 3]
2
6`,O=`point = (3, 5)        # 元组用圆括号
print(point[0])
print(point[1])

# 元组不可变：下面这行会报错
# point[0] = 99   ->  TypeError

# 常见用途：函数返回多个值、坐标、固定不变的一组数据
x, y = point          # 拆包：把元组的两个值分别给 x 和 y
print(x, y)`,P=`3
5
3 5`;function w(){return e.jsxs("article",{children:[e.jsxs(i,{children:["到目前为止我们一次只存一个数据。但现实里数据常常成批出现：一串学生名字、一组成绩…… 这就要用",e.jsx("strong",{children:"列表"}),"来装。这一章讲列表的创建、取值、增删改、遍历和常用操作， 以及它的「亲戚」——不可变的",e.jsx("strong",{children:"元组"}),"。"]}),e.jsx("h2",{children:"一、列表是什么"}),e.jsxs(r,{children:["列表（list）是一串",e.jsx("strong",{children:"有序"}),"的数据，用方括号 ",e.jsx("code",{children:"[]"})," 把元素括起来、 用逗号隔开。它可以装任意类型，长度随时可变，是 Python 里最常用的容器。"]}),e.jsx(n,{lang:"python",title:"创建列表",code:x}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:h})}),e.jsx("h2",{children:"二、索引、切片与修改"}),e.jsxs("p",{children:["和字符串一样，列表也用下标取值，",e.jsx("strong",{children:"从 0 开始"}),"，负数从末尾数，切片「含头不含尾」。 不同的是，列表可以",e.jsx("strong",{children:"改"}),"某个位置的值："]}),e.jsx(n,{lang:"python",title:"取值、切片、修改",code:j}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:p})}),e.jsx("h2",{children:"三、增、删、改"}),e.jsx("p",{children:"列表是「活」的，可以随时往里加、往外删。最常用的几个方法："}),e.jsx(n,{lang:"python",title:"append / insert / pop / remove",code:m}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:u})}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方法"}),e.jsx("th",{children:"作用"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"append(x)"})}),e.jsx("td",{children:"在末尾追加一个元素"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"insert(i, x)"})}),e.jsx("td",{children:"在下标 i 处插入 x"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"pop()"})}),e.jsxs("td",{children:["删除并返回最后一个；",e.jsx("code",{children:"pop(i)"})," 删指定位置"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"remove(x)"})}),e.jsx("td",{children:"删除第一个值为 x 的元素"})]})]})]}),e.jsxs(s,{variant:"warn",title:"remove 删的是「值」，pop 删的是「位置」",children:[e.jsx("code",{children:'remove("苹果")'})," 是按内容删；",e.jsx("code",{children:"pop(2)"})," 是按下标删。 用 ",e.jsx("code",{children:"remove"})," 删一个不存在的值会报错，删之前可以先用 ",e.jsx("code",{children:"in"})," 判断一下。"]}),e.jsx("h2",{children:"四、遍历列表"}),e.jsxs("p",{children:["用 ",e.jsx("code",{children:"for ... in"})," 可以把列表里的元素一个个拿出来处理（循环下一章会细讲，这里先体会用法）："]}),e.jsx(n,{lang:"python",title:"遍历每个元素",code:a}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:f})}),e.jsx("h2",{children:"五、常用操作"}),e.jsx(n,{lang:"python",title:"len / sort / reverse / in",code:g}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:y})}),e.jsxs(s,{variant:"tip",children:[e.jsx("code",{children:"sort()"})," 和 ",e.jsx("code",{children:"reverse()"})," 是",e.jsx("strong",{children:"原地"}),"修改列表本身、返回 ",e.jsx("code",{children:"None"}),"。 如果想保留原列表、得到一个排好序的新列表，用 ",e.jsx("code",{children:"sorted(nums)"}),"（不改原列表）。"]}),e.jsx("h2",{children:"六、嵌套列表"}),e.jsx("p",{children:"列表里还能放列表，形成「表格」结构，常用来表示矩阵、棋盘等。用两个下标访问："}),e.jsx(n,{lang:"python",title:"嵌套列表（二维）",code:v}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:C})}),e.jsx("h2",{children:"七、元组：不可变的列表"}),e.jsxs(r,{children:["元组（tuple）和列表很像，但用",e.jsx("strong",{children:"圆括号"})," ",e.jsx("code",{children:"()"}),"，而且",e.jsx("strong",{children:"创建后不能修改"}),"（不能增删改元素）。它适合存放「一组固定不变」的数据。"]}),e.jsx(n,{lang:"python",title:"元组与拆包",code:O}),e.jsx(t,{title:"运行结果",children:e.jsx(n,{lang:"text",title:"运行结果",code:P})}),e.jsxs("p",{children:["元组的常见用途：表示坐标 ",e.jsx("code",{children:"(x, y)"}),"、作为函数的多个返回值（下一卷会用到）、 以及当你想确保数据「不被改动」时。"]}),e.jsxs(s,{variant:"note",title:"列表 vs 元组",children:["简单记：会变的、要增删的用",e.jsx("strong",{children:"列表"}),"（方括号）；固定不变的用",e.jsx("strong",{children:"元组"}),"（圆括号）。 元组因为不可变，还能当字典的「键」（下一章会讲），列表则不行。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」，看看结果。"]}),e.jsx(l,{initialCode:c}),e.jsx(o,{title:"动手练一练",children:e.jsxs("ol",{children:[e.jsxs("li",{children:["创建一个含 5 个数字的列表，用 ",e.jsx("code",{children:"sort()"})," 排序后打印，再用 ",e.jsx("code",{children:"sorted()"})," 对比看原列表有没有变。"]}),e.jsxs("li",{children:["往列表末尾 ",e.jsx("code",{children:"append"})," 一个新元素，再用 ",e.jsx("code",{children:"pop()"})," 把它删掉。"]}),e.jsxs("li",{children:["用嵌套列表表示三个同学的「姓名+成绩」，如 ",e.jsx("code",{children:'[["小明", 90], ["小红", 85]]'}),"，遍历打印每个人的名字和分数。"]})]})}),e.jsx(d,{points:["列表用方括号创建，有序、可变、可装任意类型，len() 取长度。","索引从 0 开始、负数从末尾数、切片含头不含尾；列表元素可直接赋值修改。","增删改：append 末尾加、insert 指定位置插、pop 按位置删、remove 按值删。","for ... in 遍历；常用 sort/reverse（原地改）、in 判断存在；sorted() 不改原列表返回新列表。","列表可嵌套表示二维表格，用两个下标 matrix[行][列] 访问。","元组用圆括号、创建后不可变，适合固定数据、坐标、函数多返回值，可拆包赋值。"]})]})}export{w as default};
