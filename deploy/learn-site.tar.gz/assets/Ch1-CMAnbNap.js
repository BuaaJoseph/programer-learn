import{j as e}from"./index-4Gnvy4Pk.js";import{L as o,S as s}from"./Summary-8JJJpz6g.js";import{K as r}from"./KeyIdea-6LAlCalL.js";import{C as n}from"./Callout-BfcJpdBu.js";import{C as t}from"./CodeBlock-Bq_ox3wh.js";import{E as l}from"./Example-DoUEk5_G.js";const h=`// prop drilling：theme 要从最外层一路手动往下传
function App() {
  const [theme, setTheme] = useState('light')
  return <Page theme={theme} setTheme={setTheme} />
}

function Page({ theme, setTheme }) {
  // Page 自己根本用不到 theme，纯粹是个「二传手」
  return <Toolbar theme={theme} setTheme={setTheme} />
}

function Toolbar({ theme, setTheme }) {
  // Toolbar 也用不到，继续往下传
  return <ThemeButton theme={theme} setTheme={setTheme} />
}

function ThemeButton({ theme, setTheme }) {
  // 直到这里才真正用到
  return (
    <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>
      当前：{theme}
    </button>
  )
}`,i=`// 状态提升：两个兄弟组件要共享同一份输入值，
// 就把 value 提升到它们最近的公共父级 Form 里。
function Form() {
  const [value, setValue] = useState('')
  return (
    <>
      <Input value={value} onChange={setValue} />
      <Preview value={value} />
    </>
  )
}

function Input({ value, onChange }) {
  return <input value={value} onChange={(e) => onChange(e.target.value)} />
}

function Preview({ value }) {
  return <p>实时预览：{value}</p>
}`,x=`import { createContext, useContext, useState } from 'react'

// 1. 创建 Context，参数是「没有 Provider 时」的默认值
const ThemeContext = createContext('light')

// 2. 在顶层用 Provider 提供值
function App() {
  const [theme, setTheme] = useState('light')
  return (
    <ThemeContext.Provider value={theme}>
      <Page />
    </ThemeContext.Provider>
  )
}

// 3. 任意深度的后代直接用 useContext 取值，
//    中间的 Page / Toolbar 完全不用管 theme
function ThemeButton() {
  const theme = useContext(ThemeContext)
  return <button>当前：{theme}</button>
}`,c=`// 反例：value 每次 render 都是「新对象」，
// 即使 theme / setTheme 没变，引用也变了，
// 所有 useContext 的消费者都会跟着重渲染。
function App() {
  const [theme, setTheme] = useState('light')
  return (
    // {} 字面量每次 render 都是新引用 ☠️
    <ThemeContext.Provider value={{ theme, setTheme }}>
      <Page />
    </ThemeContext.Provider>
  )
}`,d=`import { createContext, useContext, useMemo, useState } from 'react'

const ThemeContext = createContext(null)

function App() {
  const [theme, setTheme] = useState('light')

  // 用 useMemo 包住 value：只有 theme 真正变化时才产出新对象，
  // 引用稳定，消费者不会被「无意义的新引用」带着重渲染。
  const value = useMemo(() => ({ theme, setTheme }), [theme])

  return (
    <ThemeContext.Provider value={value}>
      <Page />
    </ThemeContext.Provider>
  )
}`,u=`// 按关注点拆分：把「不常变的 setter」和「常变的 state」分开，
// 只读 setter 的组件不会因为 state 变化而重渲染。
const ThemeStateContext = createContext('light')
const ThemeSetterContext = createContext(() => {})

function App() {
  const [theme, setTheme] = useState('light')
  return (
    <ThemeSetterContext.Provider value={setTheme}>
      <ThemeStateContext.Provider value={theme}>
        <Page />
      </ThemeStateContext.Provider>
    </ThemeSetterContext.Provider>
  )
}

// 只切换主题、不显示主题的按钮，只订阅 setter，theme 变了它不重渲染
function ToggleButton() {
  const setTheme = useContext(ThemeSetterContext)
  return <button onClick={() => setTheme((t) => (t === 'light' ? 'dark' : 'light'))}>切换</button>
}`,a=`// theme-context.jsx —— 一个可复用的完整 ThemeContext 例子
import { createContext, useContext, useMemo, useState, useCallback } from 'react'

const ThemeContext = createContext(null)

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState('light')

  const toggle = useCallback(() => {
    setTheme((t) => (t === 'light' ? 'dark' : 'light'))
  }, [])

  // value 用 useMemo 稳定引用；依赖里包含会变的 theme 和稳定的 toggle
  const value = useMemo(() => ({ theme, toggle }), [theme, toggle])

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>
}

// 自定义 Hook：封装「必须在 Provider 内使用」的校验，调用方更省心
export function useTheme() {
  const ctx = useContext(ThemeContext)
  if (ctx === null) {
    throw new Error('useTheme 必须在 <ThemeProvider> 内部使用')
  }
  return ctx
}`,m=`// 业务组件里使用，完全感受不到 prop 传递的存在
import { ThemeProvider, useTheme } from './theme-context.jsx'

function App() {
  return (
    <ThemeProvider>
      <Page />
    </ThemeProvider>
  )
}

function ThemeButton() {
  const { theme, toggle } = useTheme()
  return (
    <button data-theme={theme} onClick={toggle}>
      当前主题：{theme}（点击切换）
    </button>
  )
}`;function P(){return e.jsxs("article",{children:[e.jsxs(o,{children:["一提到「状态管理」，很多人第一反应就是装 Redux 或 Zustand。但在你引入任何第三方库之前， React 已经内置了两件趁手的工具：",e.jsx("strong",{children:"状态提升"}),"和 ",e.jsx("strong",{children:"Context API"}),"。 这一章我们先把原生方案用好——讲清 prop drilling 的痛点、状态提升的取舍、Context 的正确用法， 以及最容易踩的「重渲染陷阱」。看懂这一章，你才能判断「到底要不要上状态库」。"]}),e.jsx("h2",{children:"一、问题的起点：prop drilling"}),e.jsxs("p",{children:["React 的数据是",e.jsx("strong",{children:"单向自上而下"}),"流动的：父组件通过 props 把数据传给子组件。 当一份数据只在父子之间传递时，这套机制清爽好用。但现实里经常出现这种情况： 某个数据在",e.jsx("strong",{children:"很深的后代"}),"才被用到，而它和数据源之间隔着好几层「根本用不到这份数据」 的中间组件。"]}),e.jsxs("p",{children:["这些中间组件被迫接收 props 再原样往下传，纯粹充当「二传手」。这种",e.jsx("strong",{children:"逐层透传"}),"的现象就叫 ",e.jsx("strong",{children:"prop drilling"}),"（属性钻取 / 逐层穿透）。它的代价是：中间组件 的接口被无关 props 污染、重构时改一处要动一长串、可读性和可维护性双双下降。"]}),e.jsx(t,{lang:"jsx",title:"prop drilling：Page 和 Toolbar 只是「二传手」",code:h}),e.jsx(n,{variant:"info",title:"prop drilling 本身不是 bug",children:"逐层传一两层 props 是完全正常的，不必为了「消灭 props」而过度设计。只有当层级很深、 中间组件明显被无关 props 拖累时，才需要考虑下面的方案。先识别问题，再选工具。"}),e.jsx("h2",{children:"二、第一招：状态提升（Lifting State Up）"}),e.jsxs(r,{children:["当多个组件需要共享同一份状态时，把这份状态",e.jsx("strong",{children:"提升到它们最近的公共父级"}),"， 由父级持有 state，再用 props 把「值」和「修改值的函数」分发下去。这是 React 官方推荐 的",e.jsx("strong",{children:"第一选择"}),"，也是最符合单向数据流的做法。"]}),e.jsxs("p",{children:["典型场景：两个兄弟组件要保持同步——一个负责输入，一个负责展示。它们各自持有 state 会失同步， 于是把 state 挪到它们的公共父级 ",e.jsx("code",{children:"Form"}),"，让父级成为这份数据的",e.jsx("strong",{children:"唯一真相来源"}),"（single source of truth）。"]}),e.jsx(t,{lang:"jsx",title:"状态提升：把 value 放到公共父级 Form",code:i}),e.jsxs("p",{children:["状态提升解决了「兄弟共享」，但它",e.jsx("strong",{children:"不能解决深层透传"}),"。如果公共父级离消费者很远， 提升之后照样要 prop drilling 一长串。这时就该请出第二招——Context。"]}),e.jsx("h2",{children:"三、第二招：Context API"}),e.jsx("p",{children:"Context 让你绕过中间层，把数据「直达」任意深度的后代，专门用来对付 prop drilling。 它由三件套组成："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"createContext(defaultValue)"}),"：创建一个 Context 对象，参数是没有 Provider 包裹时的默认值。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"<Context.Provider value={...}>"}),"：在组件树某处提供值，包裹住需要访问它的子树。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"useContext(Context)"}),"：在任意后代里读取最近一个 Provider 提供的值。"]})]}),e.jsx(t,{lang:"jsx",title:"Context 三件套：create / Provider / useContext",code:x}),e.jsxs("p",{children:["注意上面 ",e.jsx("code",{children:"Page"})," 和 ",e.jsx("code",{children:"Toolbar"})," 都消失在视野之外了——它们不再需要声明、 接收、转发 ",e.jsx("code",{children:"theme"}),"。数据从 Provider「跳」到了真正的消费者手里， 中间层彻底解脱。这就是 Context 的核心价值。"]}),e.jsx("h2",{children:"四、关键澄清：Context 不是状态管理库"}),e.jsxs(r,{children:["Context 只负责",e.jsx("strong",{children:"传递（distribution）"}),"，不负责",e.jsx("strong",{children:"高效更新"}),"。 它解决的是「数据怎么跨层送到」的问题，而不是「数据变化时如何只更新该更新的部分」。 把 Context 当成 Redux 的替代品，是初学者最常见的误解。"]}),e.jsxs("p",{children:["Context 自身没有任何「选择性订阅」机制：你没法说「我只关心 value 里的某个字段」。 只要 Provider 的 ",e.jsx("code",{children:"value"})," 变了，",e.jsx("strong",{children:"所有"}),"用了 ",e.jsx("code",{children:"useContext"})," 的 消费者都会重渲染——这正是下一节要讲的陷阱根源。真正的状态库（Redux/Zustand）会做细粒度的 选择性订阅，这是它们和 Context 的本质区别。"]}),e.jsx("h2",{children:"五、Context 的重渲染陷阱"}),e.jsxs("p",{children:["这是 Context 用错的重灾区。要点只有一句：",e.jsx("strong",{children:"Provider 的 value 引用一变， 所有消费者全部重渲染"}),"。而很多人不知不觉就让 value「每次都变」。"]}),e.jsx("h3",{children:"陷阱一：value 用对象字面量"}),e.jsxs("p",{children:["当你写 ",e.jsx("code",{children:"value={{ theme, setTheme }}"})," 时，这个对象是在每次 ",e.jsx("code",{children:"App"})," 渲染时",e.jsx("strong",{children:"新建"}),"的。即使 ",e.jsx("code",{children:"theme"})," 和 ",e.jsx("code",{children:"setTheme"})," 都没变，对象的引用也变了。 React 用 ",e.jsx("code",{children:"Object.is"})," 比较 value 的新旧引用，发现「不一样」，于是触发",e.jsx("strong",{children:"全部"}),"消费者重渲染——哪怕它们用的字段压根没动。"]}),e.jsx(t,{lang:"jsx",title:"反例：每次 render 都是新对象引用",code:c}),e.jsx("h3",{children:"解法一：用 useMemo 包住 value"}),e.jsxs("p",{children:["给 value 套一层 ",e.jsx("code",{children:"useMemo"}),"，只有当依赖项真的变化时才产出新对象。引用稳定了， 消费者就不会被「无意义的新引用」带着空转。"]}),e.jsx(t,{lang:"jsx",title:"解法：useMemo 稳定 value 引用",code:d}),e.jsx("h3",{children:"解法二：按关注点拆分多个 Context"}),e.jsxs("p",{children:["即便 value 引用稳定了，只要 ",e.jsx("code",{children:"theme"})," 真的变了，所有读 ",e.jsx("code",{children:"theme"})," 的组件 都得重渲染——这没问题。但有些组件只用 ",e.jsx("code",{children:"setTheme"}),"（比如一个纯粹的切换按钮）， 它本不该因为 ",e.jsx("code",{children:"theme"})," 变化而重渲染。把",e.jsx("strong",{children:"不常变的 setter"})," 和",e.jsx("strong",{children:"常变的 state"})," 拆进两个 Context，就能让「只读 setter」的组件免于无谓重渲染。"]}),e.jsx(t,{lang:"jsx",title:"拆分 Context：state 与 setter 分家",code:u}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"陷阱"}),e.jsx("th",{children:"表现"}),e.jsx("th",{children:"解法"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"value 是对象字面量"}),e.jsx("td",{children:"每次 render 新引用，消费者全量重渲染"}),e.jsx("td",{children:"useMemo 包裹 value"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"state 和 setter 混在一个 value"}),e.jsx("td",{children:"state 变化拖累只用 setter 的组件"}),e.jsx("td",{children:"拆成多个 Context"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"把高频变化的值放进 Context"}),e.jsx("td",{children:"每次变化触发整棵子树重渲染"}),e.jsx("td",{children:"改用真正的状态库 / 局部 state"})]})]})]}),e.jsxs(n,{variant:"warn",title:"不要把高频变化的值塞进 Context",children:["鼠标坐标、滚动位置、每帧动画值这类",e.jsx("strong",{children:"高频变化"}),"的数据放进 Context， 会让整棵消费子树疯狂重渲染。Context 适合",e.jsx("strong",{children:"低频"}),"全局值；高频共享状态 应交给专门的状态库（它们有细粒度订阅）或保持在局部。"]}),e.jsx("h2",{children:"六、Context 的适用边界"}),e.jsxs("p",{children:["总结下来，Context 最适合那种",e.jsx("strong",{children:"「全局、低频变化、很多地方要读」"}),"的值。 典型代表："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"主题（theme）"}),"：亮 / 暗模式，全站都要读，但很少切换。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"语言 / 国际化（locale）"}),"：当前语言环境，切换频率极低。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"当前用户 / 登录态"}),"：用户信息、权限，登录后基本不动。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"路由信息"}),"：很多路由库内部就是用 Context 把路由状态传给整棵树。"]})]}),e.jsx("p",{children:"这些值的共同点是：变化不频繁，所以「全量重渲染」的代价可以接受；而它们又散落在树的各个角落 被读取，正好发挥 Context「跨层直达」的长处。反过来，频繁变化、需要细粒度更新的复杂业务状态， 就不该硬塞进 Context——那是下一章状态库的舞台。"}),e.jsx("h2",{children:"七、完整示例：一个可复用的 ThemeContext"}),e.jsxs("p",{children:["把前面的最佳实践串起来，做一个真正能用的 ",e.jsx("code",{children:"ThemeProvider"}),"。要点有三： 用 ",e.jsx("code",{children:"useMemo"})," 稳定 value、用 ",e.jsx("code",{children:"useCallback"})," 稳定 toggle、 再封装一个 ",e.jsx("code",{children:"useTheme"})," 自定义 Hook 把「必须在 Provider 内使用」的校验藏起来。"]}),e.jsx(t,{lang:"jsx",title:"theme-context.jsx：完整可复用实现",code:a}),e.jsx(t,{lang:"jsx",title:"业务组件里的用法",code:m}),e.jsxs(l,{title:"为什么要封装 useTheme 自定义 Hook",children:[e.jsxs("p",{children:["直接暴露 ",e.jsx("code",{children:"useContext(ThemeContext)"})," 的话，调用方拿到的可能是默认值 ",e.jsx("code",{children:"null"}),"， 一旦忘了套 Provider，就会在「读 ",e.jsx("code",{children:"ctx.theme"}),"」时报一句莫名其妙的错。"]}),e.jsxs("p",{children:["封装成 ",e.jsx("code",{children:"useTheme"})," 后，校验集中在一处：没在 Provider 内使用就",e.jsx("strong",{children:"立刻"}),"抛出一句人话错误信息。调用方代码更短，出错也更好排查。这是社区里 Context 的标准封装套路。"]})]}),e.jsxs(n,{variant:"tip",children:["下一章我们进入真正的状态管理库：Redux Toolkit 与 Zustand。你会看到它们如何用",e.jsx("strong",{children:"细粒度订阅"}),"解决 Context 解决不了的「高效更新」问题，以及两种截然不同的设计范式。"]}),e.jsx(s,{points:["prop drilling 指数据逐层透传，中间组件被迫当「二传手」，层级很深时才需要处理，浅层透传是正常的。","状态提升是官方第一选择：把共享状态放到最近公共父级，作为唯一真相来源，但解决不了深层透传。","Context 三件套 createContext / Provider / useContext 让数据跨层直达任意后代，专治 prop drilling。","Context 只负责「传递」不负责「高效更新」，它没有选择性订阅，不是 Redux 的替代品。","重渲染陷阱：value 用对象字面量每次新引用导致消费者全量重渲染，用 useMemo 稳定 value、按关注点拆分多个 Context。","Context 适用边界是主题 / 语言 / 当前用户这类全局且低频变化的值；高频变化的复杂状态应交给专门的状态库。"]})]})}export{P as default};
