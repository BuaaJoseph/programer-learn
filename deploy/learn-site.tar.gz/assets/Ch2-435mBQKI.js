import{j as e}from"./index-DL563RIm.js";import{L as r,S as d}from"./Summary-BrgLcNDp.js";import{K as i}from"./KeyIdea-exK4GrdK.js";import{C as t}from"./Callout-B-8nslAm.js";import{C as s}from"./CodeBlock-DkVyd3P6.js";import{E as n}from"./Example-HxOmIesu.js";const o=`# 1. 安装 PydanticAI（含常用 provider）
pip install "pydantic-ai"

# 2. 配置百炼（DashScope）API Key
#    在阿里云百炼控制台开通后获取 sk- 开头的 key
export DASHSCOPE_API_KEY="sk-你的密钥"

# 3. 运行示例
python examples/agent-frameworks/03-pydantic-ai/ticket_triage.py`,c=`import os
from dataclasses import dataclass

from pydantic import BaseModel, Field
from pydantic_ai import Agent, RunContext
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider

model = OpenAIChatModel(
    "qwen-plus",
    provider=OpenAIProvider(
        base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
        api_key=os.environ["DASHSCOPE_API_KEY"],
    ),
)


@dataclass
class SupportDeps:
    """注入给 Agent 的依赖：当前客户 + 一个模拟数据库。"""
    customer_id: str
    balances: dict


class Triage(BaseModel):
    """结构化输出：工单分级结果。"""
    severity: int = Field(ge=1, le=5, description="严重度 1-5")
    needs_human: bool = Field(description="是否需要转人工")
    summary: str = Field(description="一句话摘要")


support_agent = Agent(
    model,
    deps_type=SupportDeps,
    output_type=Triage,
    system_prompt=(
        "你是客服工单分级助手。根据用户问题判断严重度(1-5)、是否需要转人工，"
        "并给出简要摘要。涉及金额纠纷时可查询客户余额辅助判断。"
    ),
)


@support_agent.tool
def get_balance(ctx: RunContext[SupportDeps]) -> str:
    """查询当前客户的账户余额。"""
    bal = ctx.deps.balances.get(ctx.deps.customer_id, 0)
    return f"客户 {ctx.deps.customer_id} 余额：{bal} 元"


def main() -> None:
    deps = SupportDeps(customer_id="C001", balances={"C001": 12.5})
    result = support_agent.run_sync("我被重复扣费两次，非常生气，要求立刻处理！", deps=deps)
    triage = result.output
    print("严重度:", triage.severity)
    print("需转人工:", triage.needs_human)
    print("摘要:", triage.summary)


if __name__ == "__main__":
    main()`,l=`model = OpenAIChatModel(
    "qwen-plus",
    provider=OpenAIProvider(
        base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
        api_key=os.environ["DASHSCOPE_API_KEY"],
    ),
)`,p=`@dataclass
class SupportDeps:
    customer_id: str
    balances: dict`,a=`class Triage(BaseModel):
    severity: int = Field(ge=1, le=5, description="严重度 1-5")
    needs_human: bool = Field(description="是否需要转人工")
    summary: str = Field(description="一句话摘要")`,h=`support_agent = Agent(
    model,
    deps_type=SupportDeps,
    output_type=Triage,
    system_prompt="你是客服工单分级助手。...",
)`,x=`@support_agent.tool
def get_balance(ctx: RunContext[SupportDeps]) -> str:
    bal = ctx.deps.balances.get(ctx.deps.customer_id, 0)
    return f"客户 {ctx.deps.customer_id} 余额：{bal} 元"`,j=`deps = SupportDeps(customer_id="C001", balances={"C001": 12.5})
result = support_agent.run_sync("我被重复扣费两次，非常生气，要求立刻处理！", deps=deps)
triage = result.output            # 类型为 Triage
print(triage.severity, triage.needs_human, triage.summary)`,u=`严重度: 5
需转人工: True
摘要: 客户反映被重复扣费两次，情绪激烈，要求立即处理，疑似计费故障。`,m=`from pydantic_ai.models.test import TestModel
from triage import support_agent, SupportDeps  # 导入上面的 Agent

def test_triage_is_valid():
    # 用 override 换成假模型 + 假依赖，不调真实大模型，CI 里也能跑
    fake = SupportDeps(customer_id="C999", balances={"C999": 0})
    with support_agent.override(model=TestModel()):
        result = support_agent.run_sync("订单状态查询", deps=fake)

    triage = result.output
    # 不关心模型说了啥，只断言"输出一定是合规的 Triage"
    assert 1 <= triage.severity <= 5
    assert isinstance(triage.needs_human, bool)
    assert isinstance(triage.summary, str)`,_=`from datetime import date
from pydantic_ai import RunContext

# 变体一：动态 system_prompt —— 每次运行时把客户编号注入提示
@support_agent.system_prompt
def add_customer_context(ctx: RunContext[SupportDeps]) -> str:
    return f"当前处理的是客户 {ctx.deps.customer_id} 的工单，请结合其账户情况判断。"


# 变体二：再加一个不需要上下文的纯函数工具（@tool_plain）
@support_agent.tool_plain
def today() -> str:
    """返回当前日期，便于模型判断时效性问题。"""
    return date.today().isoformat()`;function S(){return e.jsxs("article",{children:[e.jsxs(r,{children:["理论讲完，这一章我们把一个真实可跑的 Demo 拆到每一行：一个「客服工单分级」Agent， 接百炼的 Qwen，输入一句用户抱怨，输出一个已校验的 ",e.jsx("code",{children:"Triage"})," 对象（严重度、是否转人工、摘要）。 它麻雀虽小，却完整覆盖了 PydanticAI 的四大件：模型适配、依赖注入、结构化输出、工具调用。 最后我们还会补上可测试性、变体扩展和踩坑清单。"]}),e.jsx("h2",{children:"一、安装与环境"}),e.jsxs("p",{children:["只需要一个包和一个环境变量。我们用 OpenAI 兼容协议接百炼，所以模型 key 用 ",e.jsx("code",{children:"DASHSCOPE_API_KEY"}),"。"]}),e.jsx(s,{lang:"bash",title:"安装与运行",children:o}),e.jsxs(t,{variant:"tip",children:["百炼提供「OpenAI 兼容模式」端点，所以可以直接复用 OpenAI 的 SDK 形态， 只需把 ",e.jsx("code",{children:"base_url"})," 指到 ",e.jsx("code",{children:"compatible-mode/v1"})," 即可。"]}),e.jsx("h2",{children:"二、完整源码"}),e.jsx("p",{children:"下面是完整示例，先通读一遍建立整体印象，后面我们逐段拆解。"}),e.jsx(s,{lang:"python",title:"examples/agent-frameworks/03-pydantic-ai/ticket_triage.py",children:c}),e.jsx("h2",{children:"三、逐段讲解"}),e.jsx("h3",{children:"1. 模型适配：接百炼 Qwen"}),e.jsx(s,{lang:"python",title:"模型",children:l}),e.jsxs("p",{children:[e.jsx("code",{children:"OpenAIChatModel"})," 是当前的模型类（旧 ",e.jsx("code",{children:"OpenAIModel"})," 已改名）。 我们给它一个 ",e.jsx("code",{children:"OpenAIProvider"}),"，把 ",e.jsx("code",{children:"base_url"})," 指向百炼兼容端点、",e.jsx("code",{children:"api_key"})," 从环境变量读。模型名用 ",e.jsx("code",{children:'"qwen-plus"'}),"——一个性价比不错、支持工具调用的型号。"]}),e.jsx("h3",{children:"2. 依赖：deps_type 注入的数据"}),e.jsx(s,{lang:"python",title:"依赖",children:p}),e.jsxs("p",{children:[e.jsx("code",{children:"SupportDeps"})," 是一个普通 dataclass，承载本次运行需要的外部数据：当前客户编号、 以及一个模拟数据库（这里用 dict 代替真实 DB）。真实项目里这里会放数据库连接、HTTP 客户端、配置对象等。 关键点是——这些东西从外部注入，工具不在自己体内硬编码它们。"]}),e.jsx("h3",{children:"3. 结构化输出：Triage 模型"}),e.jsx(s,{lang:"python",title:"输出 schema",children:a}),e.jsxs("p",{children:["这是整个 Demo 的灵魂。我们用 ",e.jsx("code",{children:"Field"})," 给约束：",e.jsx("code",{children:"severity"})," 必须是 1~5 的整数 （",e.jsx("code",{children:"ge=1, le=5"}),"），",e.jsx("code",{children:"needs_human"})," 是布尔，",e.jsx("code",{children:"summary"})," 是字符串。",e.jsx("code",{children:"description"})," 会作为提示传给模型，告诉它每个字段是什么意思。模型的回答会被强制塞进这个形状， 不合规就重试。"]}),e.jsx("h3",{children:"4. 组装 Agent"}),e.jsx(s,{lang:"python",title:"Agent",children:h}),e.jsxs("p",{children:["一行构造，把模型、依赖类型、输出类型、系统提示全绑定。注意 ",e.jsx("code",{children:"deps_type=SupportDeps"}),"与 ",e.jsx("code",{children:"output_type=Triage"})," 是泛型参数，它们会让后面工具里的 ",e.jsx("code",{children:"ctx.deps"})," 和最终的",e.jsx("code",{children:"result.output"})," 都带上正确类型。"]}),e.jsx("h3",{children:"5. 工具：用 ctx.deps 查余额"}),e.jsx(s,{lang:"python",title:"工具",children:x}),e.jsxs("p",{children:[e.jsx("code",{children:"@support_agent.tool"})," 注册了一个带上下文的工具。注意参数 ",e.jsx("code",{children:"ctx: RunContext[SupportDeps]"}),"—— 框架会把运行时上下文传进来，里面的 ",e.jsx("code",{children:"ctx.deps"})," 就是我们 ",e.jsx("code",{children:"run"})," 时注入的 ",e.jsx("code",{children:"SupportDeps"})," 实例。 模型在判断「金额纠纷」时，会自己决定调用这个工具去查余额，再据此分级。"]}),e.jsx("h3",{children:"6. 运行：拿到类型化结果"}),e.jsx(s,{lang:"python",title:"运行",children:j}),e.jsxs("p",{children:[e.jsx("code",{children:"run_sync(..., deps=deps)"})," 把依赖注入并同步运行。返回值 ",e.jsx("code",{children:"result.output"}),"的类型就是 ",e.jsx("code",{children:"Triage"}),"——可以直接 ",e.jsx("code",{children:"triage.severity"})," 这样用，不需要任何解析。 这正是结构化输出的价值兑现处。"]}),e.jsx("h2",{children:"四、预期输出"}),e.jsx("p",{children:"用户那句话情绪激烈、涉及重复扣费，模型大概率判定为高严重度、需要转人工。运行结果类似："}),e.jsxs(n,{title:"控制台输出（数值随模型判断略有浮动）",children:[e.jsx(s,{lang:"bash",title:"stdout",children:u}),e.jsxs("p",{children:["关键不在具体数字，而在于：无论模型怎么回答，",e.jsx("code",{children:"severity"})," 一定落在 1~5、",e.jsx("code",{children:"needs_human"})," 一定是布尔——因为 schema 替你兜底了。"]})]}),e.jsx("h2",{children:"五、可测试性：用 override 写一个断言"}),e.jsxs("p",{children:["生产级 Agent 必须能进 CI。PydanticAI 的 ",e.jsx("code",{children:"override"})," 让你在测试里换掉真实模型与依赖， 既不烧 token、也不依赖网络，还能断言输出契约。"]}),e.jsx(s,{lang:"python",title:"test_triage.py",children:m}),e.jsxs(i,{children:["测试断言的是「契约」而非「具体措辞」：只要输出始终是合规的 ",e.jsx("code",{children:"Triage"}),"， Agent 的下游就永远安全。这种测试稳定、快速、可重复——是工程化的分水岭。"]}),e.jsx("h2",{children:"六、变体：动态提示 + 第二个工具"}),e.jsxs("p",{children:["在原 Demo 上做两处常见扩展：用动态 ",e.jsx("code",{children:"system_prompt"})," 把客户上下文注入提示； 再加一个不需要上下文的纯函数工具。"]}),e.jsx(s,{lang:"python",title:"变体扩展",children:_}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"动态 system_prompt"}),"：每次 ",e.jsx("code",{children:"run"})," 都按 ",e.jsx("code",{children:"ctx.deps"})," 重新生成那段提示，把「当前客户」这种随上下文变化的信息喂给模型。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"@tool_plain"}),"：",e.jsx("code",{children:"today()"})," 不需要 ",e.jsx("code",{children:"RunContext"}),"，是纯函数工具，适合「取当前时间」这类无副作用、无依赖的能力。"]})]}),e.jsx("h2",{children:"七、常见报错与调试"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsxs("strong",{children:[e.jsx("code",{children:"base_url"})," 写错"]}),"：百炼兼容端点是 ",e.jsx("code",{children:".../compatible-mode/v1"}),"， 少写 ",e.jsx("code",{children:"/v1"})," 或拼成原生 DashScope 路径都会 404 / 401。先用 curl 验通端点再跑代码。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:[e.jsx("code",{children:"output_type"})," 校验反复失败"]}),"：模型多次给不出合规结构，会触发重试上限并抛错。 通常是字段约束太苛刻、",e.jsx("code",{children:"description"})," 写得不清楚，或模型能力不足。先放宽约束、补清字段说明，必要时换更强的模型。"]}),e.jsxs("li",{children:[e.jsxs("strong",{children:[e.jsx("code",{children:"deps"})," 忘传"]}),"：用了 ",e.jsx("code",{children:"deps_type"})," 却在 ",e.jsx("code",{children:"run"})," 时没传 ",e.jsx("code",{children:"deps="}),"， 工具里访问 ",e.jsx("code",{children:"ctx.deps"})," 就会出错。凡是声明了依赖，每次运行都要注入。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"模型不支持工具调用"}),"：选的型号若不支持 function calling，",e.jsx("code",{children:"@agent.tool"})," 不会被调用， 分级会缺少余额信息。优先选明确支持工具调用的型号（如 qwen-plus / qwen-max）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"环境变量没设"}),"：",e.jsx("code",{children:'os.environ["DASHSCOPE_API_KEY"]'})," 缺失会直接 ",e.jsx("code",{children:"KeyError"}),"， 运行前确认已 ",e.jsx("code",{children:"export"}),"。"]})]}),e.jsx("h2",{children:"八、接百炼小结：OpenAIProvider vs AlibabaProvider"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方式"}),e.jsx("th",{children:"写法"}),e.jsx("th",{children:"适用"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"OpenAI 兼容"}),e.jsx("td",{children:e.jsx("code",{children:'OpenAIChatModel("qwen-plus", provider=OpenAIProvider(base_url=兼容端点, api_key=...))'})}),e.jsx("td",{children:"本 Demo 用法，通用、可控、和接其它 OpenAI 兼容服务写法一致"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"官方原生"}),e.jsx("td",{children:e.jsx("code",{children:'OpenAIChatModel("qwen-max", provider=AlibabaProvider(api_key=...))'})}),e.jsx("td",{children:"少配一个 base_url，由框架内置百炼端点"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"字符串简写"}),e.jsxs("td",{children:[e.jsx("code",{children:'Agent("alibaba:qwen-max")'})," + 环境变量 ",e.jsx("code",{children:"ALIBABA_API_KEY"})]}),e.jsx("td",{children:"最省事，快速起步 / 脚本"})]})]})]}),e.jsxs(t,{variant:"tip",children:["三种写法等价，选哪种看口味。",e.jsx("code",{children:"OpenAIProvider"})," 显式可控、迁移其它兼容服务最顺手；",e.jsx("code",{children:"AlibabaProvider"})," 与字符串简写更简洁。"]}),e.jsx(d,{points:["一个完整的工单分级 Agent：OpenAIChatModel + OpenAIProvider 接百炼 qwen-plus，输入一句抱怨，输出已校验的 Triage 对象。","四大件齐活：模型适配（base_url 接 compatible-mode/v1）、依赖注入（SupportDeps + ctx.deps）、结构化输出（Triage + Field 约束）、工具调用（@tool 查余额）。","result.output 是带类型的 Triage，直接 triage.severity 使用；无论模型怎么答，字段约束都替你兜底。","override(model=TestModel()) 让 Agent 在测试里换假模型/假依赖，断言输出契约而非措辞，可进 CI、不烧 token。","变体：@agent.system_prompt 按 ctx.deps 动态生成提示；@tool_plain 注册无需上下文的纯函数工具。","踩坑清单：base_url 少写 /v1、output_type 反复校验失败、忘传 deps、模型不支持工具调用、环境变量未设。",'接百炼三选一：OpenAIProvider（显式可控）、AlibabaProvider（少配端点）、Agent("alibaba:qwen-max") 简写（最省事）。']})]})}export{S as default};
