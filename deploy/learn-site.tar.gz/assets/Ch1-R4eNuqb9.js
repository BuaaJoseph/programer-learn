import{r as a,j as e}from"./index-Bs06kW3a.js";import{L as x,S as h}from"./Summary-CLAN1smq.js";import{K as j}from"./KeyIdea-iVczm-9t.js";import{E as p}from"./Example-XOtO_AMb.js";import{P as g}from"./Practice-CjxPZLe_.js";import{C as t}from"./Callout-BCaSeUge.js";import{C as n}from"./CodeBlock-BUaxuxwl.js";import{F as v}from"./Figure-DMI_ICUv.js";const l={static:{label:"静态代理",desc:"手写一个代理类，实现与目标相同的接口，方法里调用目标并加增强。简单直观，但每个接口都要写一个代理类，难维护。"},jdk:{label:"JDK 动态代理",desc:"运行时用 Proxy + InvocationHandler 生成代理对象，要求目标必须实现接口。Spring AOP 默认对接口用它。"},cglib:{label:"CGLIB",desc:"运行时生成目标类的子类来代理，不要求接口(基于继承)。无接口的类用它；final 类/方法不能被代理。"}};function m(){const[r,c]=a.useState("jdk"),s=l[r],o=e.jsx(e.Fragment,{children:Object.entries(l).map(([i,d])=>e.jsx("button",{className:`fig-btn ${r===i?"active":""}`,onClick:()=>c(i),children:d.label},i))});return e.jsx(v,{caption:"代理模式：不改原类的前提下增强它(加日志、事务、权限、缓存、远程调用)。Spring AOP、RPC、MyBatis Mapper 全靠它。三种实现：静态手写、JDK 动态(基于接口)、CGLIB(基于继承)。",controls:o,children:e.jsxs("svg",{viewBox:"0 0 460 170",width:"460",role:"img","aria-label":"代理模式",children:[e.jsx("rect",{x:"20",y:"50",width:"80",height:"40",rx:"9",fill:"var(--accent-soft)",stroke:"var(--accent-line)"}),e.jsx("text",{x:"60",y:"74",textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"12",fill:"var(--ink)",children:"调用方"}),e.jsx("rect",{x:"150",y:"40",width:"150",height:"60",rx:"10",fill:"var(--accent)"}),e.jsx("text",{x:"225",y:"62",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"11",fontWeight:"700",fill:"#ffffff",children:"代理对象"}),e.jsx("text",{x:"225",y:"78",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:"#ffffff",children:r==="jdk"?"Proxy(实现接口)":r==="cglib"?"目标子类":"手写代理类"}),e.jsx("text",{x:"225",y:"92",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:"#ffffff",children:"前置增强 → 调用 → 后置增强"}),e.jsx("rect",{x:"350",y:"50",width:"90",height:"40",rx:"9",fill:"var(--green-soft)",stroke:"var(--green-line)"}),e.jsx("text",{x:"395",y:"74",textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"11",fill:"var(--green)",children:"目标对象"}),e.jsx("line",{x1:"100",y1:"70",x2:"150",y2:"70",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#px-a)"}),e.jsx("line",{x1:"300",y1:"70",x2:"350",y2:"70",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#px-a)"}),e.jsx("defs",{children:e.jsx("marker",{id:"px-a",markerWidth:"8",markerHeight:"8",refX:"5",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L5,3 L0,6 Z",fill:"var(--ink-faint)"})})}),e.jsx("rect",{x:"20",y:"116",width:"420",height:"48",rx:"8",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsx("foreignObject",{x:"28",y:"120",width:"404",height:"42",children:e.jsxs("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"11.5px var(--sans)",color:"var(--ink)",lineHeight:1.35},children:[e.jsxs("strong",{style:{color:"var(--accent-strong)"},children:[s.label,"："]}),s.desc]})})]})})}const f=`// 1. 共同的接口
interface UserService {
    void save(String name);
}

// 2. 真实对象
class UserServiceImpl implements UserService {
    public void save(String name) {
        System.out.println("保存用户：" + name);
    }
}

// 3. 静态代理类：实现同一个接口，内部持有真实对象
class UserServiceProxy implements UserService {
    private final UserService target;

    public UserServiceProxy(UserService target) {
        this.target = target;
    }

    public void save(String name) {
        System.out.println("[日志] 方法开始");   // 增强：前置
        target.save(name);                       // 委托给真实对象
        System.out.println("[日志] 方法结束");   // 增强：后置
    }
}`,y=`import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class JdkProxyDemo {

    interface UserService {
        void save(String name);
    }

    static class UserServiceImpl implements UserService {
        public void save(String name) {
            System.out.println("保存用户：" + name);
        }
    }

    // InvocationHandler：所有被代理方法的调用都会进到这里的 invoke
    static class LogHandler implements InvocationHandler {
        private final Object target;

        LogHandler(Object target) {
            this.target = target;
        }

        public Object invoke(Object proxy, Method method, Object[] args)
                throws Throwable {
            System.out.println("[日志] 调用 " + method.getName());
            Object result = method.invoke(target, args);  // 反射调用真实方法
            System.out.println("[日志] 调用结束");
            return result;
        }
    }

    public static void main(String[] args) {
        UserService real = new UserServiceImpl();

        UserService proxy = (UserService) Proxy.newProxyInstance(
                real.getClass().getClassLoader(),   // 类加载器
                real.getClass().getInterfaces(),     // 要实现的接口数组
                new LogHandler(real));               // 调用处理器

        proxy.save("张三");   // 实际走的是 LogHandler.invoke
    }
}`,S=`import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;
import java.lang.reflect.Method;

// 目标类：没有实现任何接口，JDK 动态代理无能为力
class UserService {
    public void save(String name) {
        System.out.println("保存用户：" + name);
    }
}

public class CglibProxyDemo {

    // MethodInterceptor：所有被代理方法都会进到 intercept
    static class LogInterceptor implements MethodInterceptor {
        public Object intercept(Object obj, Method method,
                                Object[] args, MethodProxy proxy) throws Throwable {
            System.out.println("[日志] 调用 " + method.getName());
            // 注意用 invokeSuper（调父类方法），而不是 invoke，否则会无限递归
            Object result = proxy.invokeSuper(obj, args);
            System.out.println("[日志] 调用结束");
            return result;
        }
    }

    public static void main(String[] args) {
        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(UserService.class);     // 设父类：生成它的子类
        enhancer.setCallback(new LogInterceptor());
        UserService proxy = (UserService) enhancer.create();
        proxy.save("李四");   // 走的是子类重写后的方法 -> intercept
    }
}`,u=`// AOP 经典陷阱：类内部自调用，事务/切面失效
@Service
public class OrderService {

    @Transactional
    public void create(Order order) {
        // ...
        this.audit(order);   // 走的是 this（真实对象），没经过代理！
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void audit(Order order) {
        // 期望它开一个新事务，但因为是自调用，@Transactional 完全不生效
    }
}

// 解法：①注入自己的代理 ②AopContext.currentProxy() ③拆成两个 Bean`;function w(){return e.jsxs(e.Fragment,{children:[e.jsx(x,{children:e.jsxs("p",{children:["有时候我们想给一个对象的方法「悄悄」加点东西——比如打日志、开事务、做权限校验、把远程调用包装成本地调用—— 但又不想去改它原来的代码。",e.jsx("em",{children:"代理模式"}),"（Proxy）就是为此而生：给真实对象配一个「替身」， 外部通过替身访问，替身在调用前后插入增强逻辑，再把真正的活儿转交给真实对象。"]})}),e.jsx("h2",{children:"什么是代理模式"}),e.jsxs("p",{children:["代理模式的意图是：",e.jsx("strong",{children:"为另一个对象提供一个替身或占位符，以控制对这个对象的访问"}),"。 关键词是「控制访问」——代理和真实对象长得一样（实现同一个接口），调用方根本感觉不到中间多了一层， 但代理可以决定要不要放行、在前后做什么、甚至延迟创建真实对象。"]}),e.jsxs("p",{children:["它由三个角色构成：",e.jsx("em",{children:"Subject"}),"（共同接口）、",e.jsx("em",{children:"RealSubject"}),"（真实对象）、",e.jsx("em",{children:"Proxy"}),"（代理对象，持有真实对象的引用）。代理实现了和真实对象相同的接口，所以可以无缝替换原对象。"]}),e.jsx("h3",{children:"代理的四种常见类型"}),e.jsx("p",{children:"按「控制访问」的目的不同，代理在 GoF 里分出几种典型用途，理解它们有助于在面试里举出对的例子："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"远程代理（Remote Proxy）"}),"：为「在另一台机器上的对象」提供本地替身， 代理在背后做序列化与网络传输。RPC 框架 Dubbo、Feign 就是它。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"虚拟代理（Virtual Proxy）"}),"：延迟创建开销大的对象，先给个轻量替身，真正用到时才创建。 Hibernate 的懒加载、图片占位符都是它。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"保护代理（Protection Proxy）"}),"：在访问前做权限校验，决定放不放行。权限切面、网关鉴权属于它。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"智能引用代理（Smart Reference）"}),"：在访问时附带额外动作，如引用计数、缓存、日志、加锁。"]})]}),e.jsx("h3",{children:"静态代理：手写一个替身类"}),e.jsx("p",{children:"最朴素的做法是手写一个代理类，让它实现和目标相同的接口，内部持有真实对象，在转发调用的前后插入逻辑。 以「给 save 方法加日志」为例："}),e.jsx(n,{lang:"java",title:"StaticProxy.java",code:f}),e.jsxs("p",{children:["静态代理的优点是直观、好调试；缺点也很明显：",e.jsx("strong",{children:"一个接口要写一个代理类"}),"， 接口里多一个方法，代理类就得跟着改。如果系统里有几十个 Service 都要加日志，就得写几十个几乎一样的代理类—— 这显然不可接受，于是有了「动态代理」。"]}),e.jsxs(p,{title:"一句话区分静态与动态",children:[e.jsxs("p",{children:["静态代理：代理类是你",e.jsx("strong",{children:"编译期手写"}),"好的 .java 文件。"]}),e.jsxs("p",{children:["动态代理：代理类是",e.jsx("strong",{children:"运行期由 JVM 临时生成"}),"的字节码，你只写一段「拦截逻辑」， 剩下的样板代码框架替你造。下面两种动态代理是面试的绝对高频考点。"]})]}),e.jsx(m,{}),e.jsx("h3",{children:"JDK 动态代理：Proxy + InvocationHandler"}),e.jsxs("p",{children:["JDK 自带的动态代理由 ",e.jsx("code",{children:"java.lang.reflect.Proxy"})," 和 ",e.jsx("code",{children:"InvocationHandler"})," 两个核心类协作完成。 你不再为每个接口手写代理类，而是把增强逻辑统一写进 ",e.jsx("code",{children:"InvocationHandler.invoke"})," 里： 被代理对象的",e.jsx("strong",{children:"任何方法"}),"被调用，都会先进到这个 ",e.jsx("code",{children:"invoke"})," 方法。"]}),e.jsxs("p",{children:["它的硬性前提是：",e.jsx("strong",{children:"目标对象必须实现接口"}),"。因为 JDK 生成的代理类，本质是「实现了同一组接口」的一个新类， 靠接口这条线和真实对象对齐。没有接口，JDK 动态代理就无能为力。"]}),e.jsx("h3",{children:"CGLIB：生成子类，无需接口"}),e.jsxs("p",{children:["如果目标类没有实现任何接口怎么办？",e.jsx("em",{children:"CGLIB"}),"（Code Generation Library）给出了另一条路： 它在运行期",e.jsx("strong",{children:"动态生成目标类的子类"}),"，通过重写父类的方法来织入增强逻辑， 靠的是「继承」而不是「接口」。所以 CGLIB ",e.jsx("strong",{children:"无需接口"}),"，可以直接代理普通类。"]}),e.jsxs("p",{children:["代价是：因为基于继承，CGLIB 不能代理 ",e.jsx("code",{children:"final"})," 类（不能被继承），也不能拦截 ",e.jsx("code",{children:"final"}),"、",e.jsx("code",{children:"private"})," 方法（不能被重写）。它通过 ",e.jsx("code",{children:"MethodInterceptor"})," 的 ",e.jsx("code",{children:"intercept"}),"方法拦截调用，思路和 ",e.jsx("code",{children:"InvocationHandler"})," 类似。"]}),e.jsx(n,{lang:"java",title:"CglibProxyDemo.java（无接口也能代理）",code:S}),e.jsxs("p",{children:["注意上面的关键细节：CGLIB 拦截里要调 ",e.jsx("code",{children:"proxy.invokeSuper(obj, args)"}),"（调用父类方法）， 而不是 ",e.jsx("code",{children:"method.invoke(obj, args)"}),"——后者会在子类代理对象上再次触发拦截，造成",e.jsx("strong",{children:"无限递归 StackOverflow"}),"。 这是 CGLIB 手写时最常见的坑。"]}),e.jsx("h2",{children:"JDK 动态代理 vs CGLIB 对比表"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"JDK 动态代理"}),e.jsx("th",{children:"CGLIB"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"实现机制"}),e.jsx("td",{children:"运行期生成实现接口的代理类"}),e.jsx("td",{children:"运行期生成目标类的子类"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"依赖关系"}),e.jsx("td",{children:"基于接口（implements）"}),e.jsx("td",{children:"基于继承（extends）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"前提"}),e.jsx("td",{children:"目标必须实现接口"}),e.jsx("td",{children:"无需接口，但类不能 final"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"拦截入口"}),e.jsx("td",{children:"InvocationHandler.invoke"}),e.jsx("td",{children:"MethodInterceptor.intercept"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"不能代理"}),e.jsx("td",{children:"没有接口的类"}),e.jsx("td",{children:"final 类、final/private 方法"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"是否内置"}),e.jsx("td",{children:"JDK 自带"}),e.jsx("td",{children:"需引入字节码库（ASM）"})]})]})]}),e.jsx(j,{title:"三者怎么选",children:e.jsxs("p",{children:[e.jsx("strong",{children:"静态代理"}),"——一对一手写，简单但不可扩展，实际工程基本不用。",e.jsx("strong",{children:"JDK 动态代理"}),"——基于接口、用反射，JDK 原生支持，目标有接口时首选。",e.jsx("strong",{children:"CGLIB"}),"——基于继承生成子类，目标没接口时用它，但不能代理 final。 一句口诀：",e.jsx("strong",{children:"有接口走 JDK，没接口走 CGLIB"}),"。"]})}),e.jsxs(t,{variant:"warn",title:"Spring AOP 到底用哪种",children:[e.jsxs("p",{children:["这是面试最爱追问的点：Spring AOP 会",e.jsx("strong",{children:"智能选择"}),"—— 目标对象实现了接口，默认用 JDK 动态代理；没有实现接口，就退化到 CGLIB。"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:["Spring Boot 2.x 起，",e.jsx("code",{children:"spring.aop.proxy-target-class"})," 默认为 ",e.jsx("code",{children:"true"}),"， 也就是",e.jsx("strong",{children:"默认一律用 CGLIB"}),"，省去「必须面向接口编程」带来的踩坑。"]}),e.jsxs("li",{children:["正因为基于代理，AOP 有个经典陷阱：",e.jsx("strong",{children:"同一个类内部方法自调用，事务/切面会失效"}),"—— 因为自调用走的是 ",e.jsx("code",{children:"this"}),"（真实对象），根本没经过代理那一层。"]})]})]}),e.jsx("h3",{children:"自调用失效：原理与三种解法"}),e.jsxs("p",{children:["这是工作中真正会踩、面试也最爱深挖的坑。Spring 注入给你的是",e.jsx("strong",{children:"代理对象"}),"， 切面逻辑（开事务、记日志）都织在代理上。可一旦在类内部用 ",e.jsx("code",{children:"this.xxx()"})," 调另一个方法， 走的是真实对象自己的引用，绕过了代理，切面自然不触发："]}),e.jsx(n,{lang:"java",title:"自调用导致 @Transactional 失效",code:u}),e.jsxs("p",{children:["三种常见解法：①把被调用的方法",e.jsx("strong",{children:"拆到另一个 Bean"}),"，通过注入调用（最干净）； ②",e.jsx("strong",{children:"注入自己的代理"}),"（",e.jsx("code",{children:"@Autowired private OrderService self;"})," 再调 ",e.jsx("code",{children:"self.audit()"}),"）； ③开启 ",e.jsx("code",{children:"exposeProxy=true"})," 后用 ",e.jsx("code",{children:"((OrderService) AopContext.currentProxy()).audit()"}),"。 根因都一样：必须让调用",e.jsx("strong",{children:"经过代理那一层"}),"，切面才会生效。"]}),e.jsx("h2",{children:"代理模式在实际中的应用"}),e.jsx("p",{children:"代理是框架里最常见的设计模式之一，下面这些场景几乎都是它在背后撑着："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Spring AOP / 声明式事务"}),"——",e.jsx("code",{children:"@Transactional"}),"、日志、权限切面， 本质都是给目标方法套一层代理，在前后开关事务、记录日志。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"RPC 远程代理"}),"——Dubbo、Feign 给你一个本地接口，你调它就像调本地方法， 代理在背后帮你做序列化、网络传输、反序列化（这叫",e.jsx("em",{children:"远程代理"}),"）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"MyBatis Mapper 代理"}),"——你只写一个 Mapper 接口、没有实现类， MyBatis 用 JDK 动态代理生成实现，把方法调用翻译成 SQL 执行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"懒加载 / 虚拟代理"}),"——Hibernate 用代理实现延迟加载：先给个轻量替身， 真正访问字段时才去查数据库。"]})]}),e.jsx("h3",{children:"代理模式 vs 装饰器模式"}),e.jsxs("p",{children:["两者结构很像（都持有目标对象、都实现同一接口），但",e.jsx("strong",{children:"意图不同"}),"：",e.jsx("em",{children:"代理"}),"关注的是",e.jsx("strong",{children:"控制访问"}),"——要不要让你访问、何时创建、是不是远程调用， 通常代理自己负责创建/管理真实对象；",e.jsx("em",{children:"装饰器"}),"关注的是",e.jsx("strong",{children:"增强功能"}),"—— 在不改原类的前提下叠加新能力，目标对象一般由外部传进来，强调可以层层嵌套。 简单记：",e.jsx("strong",{children:"代理是「替你把门」，装饰器是「给你加料」"}),"。"]}),e.jsx("h3",{children:"代理 vs 适配器 vs 外观（结构型三兄弟）"}),e.jsx("p",{children:"这三个都「包了一层」，但意图完全不同，常被一起对比："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"代理"}),"：接口不变，",e.jsx("strong",{children:"控制访问"}),"（要不要让你访问、何时创建）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"适配器"}),"：接口",e.jsx("strong",{children:"改变"}),"，把 A 接口转成客户端要的 B 接口，解决兼容。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"装饰器"}),"：接口不变，",e.jsx("strong",{children:"增强功能"}),"，强调可层层叠加。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"外观"}),"：把一堆子系统接口",e.jsx("strong",{children:"收敛成一个"}),"简单入口，强调简化。"]})]}),e.jsx("p",{children:"一句话钩子：代理控访问、适配转接口、装饰加功能、外观做简化。"}),e.jsx(t,{variant:"warn",title:"代理不是免费的",children:e.jsxs("p",{children:["代理虽好，但每加一层都有",e.jsx("strong",{children:"性能与可调试性"}),"成本：反射调用比直接调用慢、 调用栈里多了一堆 ",e.jsx("code",{children:"$Proxy"})," / ",e.jsx("code",{children:"$$EnhancerBySpringCGLIB$$"})," 帧，排查问题更绕。 因此别滥用——只有真正需要「在不改源码的前提下统一织入横切逻辑」时才用代理， 简单场景直接调用就好，否则又是一种过度设计。"]})}),e.jsxs(g,{title:"手写一个 JDK 动态代理",children:[e.jsxs("p",{children:["下面是一个完整可运行的 JDK 动态代理例子：用 ",e.jsx("code",{children:"InvocationHandler"})," 给 ",e.jsx("code",{children:"UserService"}),"的所有方法统一加上日志。把它复制到本地跑一遍，观察 ",e.jsx("code",{children:"proxy.save"})," 调用是如何被 ",e.jsx("code",{children:"invoke"}),"拦截、再反射转发到真实对象的。"]}),e.jsx(n,{lang:"java",title:"JdkProxyDemo.java",code:y}),e.jsxs("p",{children:["进阶练习：把目标类的接口去掉，你会发现 ",e.jsx("code",{children:"Proxy.newProxyInstance"})," 直接报错—— 这时只能换 CGLIB。再试着在 ",e.jsx("code",{children:"invoke"})," 里用 try-finally 包住，模拟「事务提交/回滚」的开关。"]})]}),e.jsx(h,{points:["代理模式：给真实对象配一个实现相同接口的替身，以控制对它的访问，调用方无感知。","静态代理是编译期手写的代理类，一接口一类，简单但无法扩展，工程上基本不用。","JDK 动态代理基于 Proxy + InvocationHandler，用反射拦截调用，前提是目标必须实现接口。","CGLIB 运行期生成目标类的子类、靠继承织入增强，无需接口，但不能代理 final 类与 final/private 方法。","口诀「有接口走 JDK，没接口走 CGLIB」；Spring Boot 默认用 CGLIB，且类内自调用会让 AOP 失效。","代理按用途分四种：远程代理（RPC）、虚拟代理（懒加载）、保护代理（鉴权）、智能引用代理（计数/缓存）。","自调用失效根因是走 this 绕过代理，三种解法：拆 Bean、注入自身代理、AopContext.currentProxy()。","CGLIB 手写要用 invokeSuper 而非 invoke，否则无限递归 StackOverflow。","应用遍布 Spring AOP/事务、RPC 远程代理、MyBatis Mapper、懒加载；与装饰器的区别是「代理控制访问、装饰增强功能」。"]})]})}export{w as default};
