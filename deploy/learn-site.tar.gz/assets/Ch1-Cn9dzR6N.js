import{j as s}from"./index-BAhU_Xet.js";import{L as c,S as n}from"./Summary-DeCBcqSp.js";import{K as r}from"./KeyIdea-DnEcW4Ye.js";import{C as t}from"./Callout-OljS8ooD.js";import{C as e}from"./CodeBlock-ClAC9vi8.js";import{E as i}from"./Example-D5OEBxRp.js";const d=`// struct 是值类型：赋值会"复制"出一份独立的数据
struct PointStruct {
    var x: Int
    var y: Int
}

var a = PointStruct(x: 1, y: 2)
var b = a          // 这里发生的是"复制"，b 是 a 的一份独立拷贝
b.x = 99           // 只改了 b 自己

print(a.x)         // 1   —— a 完全不受影响
print(b.x)         // 99`,l=`// class 是引用类型：赋值只是"共享同一个实例"的引用
class PointClass {
    var x: Int
    var y: Int
    init(x: Int, y: Int) { self.x = x; self.y = y }
}

let a = PointClass(x: 1, y: 2)
let b = a          // a 和 b 指向"同一个对象"
b.x = 99           // 通过 b 改，其实改的就是那唯一的实例

print(a.x)         // 99  —— a 也跟着变了！
print(b.x)         // 99`,x=`struct Counter {
    private(set) var value = 0

    // 值类型里要"修改自身存储属性"的方法，必须标 mutating
    mutating func increment() {
        value += 1
    }
}

var c = Counter()  // 用 var 才能调用 mutating 方法
c.increment()
print(c.value)     // 1

let fixed = Counter()
// fixed.increment()  // ❌ 编译错误：let 修饰的值类型是完全不可变的`,h=`struct Size { var w: Int; var h: Int }

// let 修饰值类型 => 连里面的属性都不能改（深层不可变）
let s = Size(w: 10, h: 20)
// s.w = 30        // ❌ 编译报错

// 对比：let 修饰引用类型 => 引用本身不能改，但对象内部仍可变
class Box { var n = 0 }
let box = Box()
box.n = 5          // ✅ 合法：box 这个"引用"没变，变的是它指向的对象
// box = Box()     // ❌ 不能让 box 指向另一个实例`,j=`// 写时复制（Copy-on-Write）：标准库集合的优化
var arr1 = [1, 2, 3]
var arr2 = arr1        // 此刻并未真的复制底层缓冲区，二者共享同一份存储

// 只有当你"准备写"其中一个时，才真正分裂出独立拷贝
arr2.append(4)         // 触发复制：arr2 拿到独立缓冲区，arr1 不受影响

print(arr1)            // [1, 2, 3]
print(arr2)            // [1, 2, 3, 4]
// 语义上仍是值类型（互不影响），但只读共享时省去了复制开销`,o=`import SwiftUI

// SwiftUI 的 View 几乎全是 struct（值类型）
struct CounterView: View {
    // @State 持有的也是值类型；值变化 => SwiftUI 重新计算 body 并 diff
    @State private var count = 0

    var body: some View {
        VStack {
            Text("当前：\\(count)")
            Button("加一") { count += 1 }
        }
    }
}`,a=`// 引用类型由 ARC（自动引用计数）管理生命周期：
// 计数归零即释放。两个对象互相强引用 => 计数永不归零 => 内存泄漏。
class Person {
    var pet: Pet?
}
class Pet {
    weak var owner: Person?   // 用 weak 打破循环引用，避免泄漏
}`;function S(){return s.jsxs("article",{children:[s.jsxs(c,{children:["Swift 把类型分成两大阵营：",s.jsx("strong",{children:"值类型"}),"（struct、enum、以及所有基础类型）和",s.jsx("strong",{children:"引用类型"}),"（class）。它们看上去都能存数据、都能定义方法，但在「赋值、传参、共享」 这件事上行为截然不同——这一条区别，是理解 Swift「值语义」与 SwiftUI 为何长这样的总开关。 这一章我们把它讲透：复制 vs 共享、写时复制优化、mutating 与不可变、ARC 与循环引用， 以及到底什么时候该用 struct、什么时候非 class 不可。"]}),s.jsx("h2",{children:"一、两种类型，两种世界观"}),s.jsxs(r,{children:[s.jsx("strong",{children:"值类型"}),"在赋值或传参时会",s.jsx("strong",{children:"复制"}),"一份独立的数据，副本与原值互不影响；",s.jsx("strong",{children:"引用类型"}),"在赋值或传参时只是",s.jsx("strong",{children:"共享"}),"同一个实例的引用，通过任一引用修改， 其它引用都会「看见」这次修改。一句话：值类型谈的是「内容相等」，引用类型谈的是「身份相同」。"]}),s.jsxs("p",{children:["在 Swift 里，用 ",s.jsx("code",{children:"struct"})," 或 ",s.jsx("code",{children:"enum"})," 定义的类型是值类型；用 ",s.jsx("code",{children:"class"}),"定义的类型是引用类型。绝大多数你天天用的东西——",s.jsx("code",{children:"Int"}),"、",s.jsx("code",{children:"Double"}),"、",s.jsx("code",{children:"Bool"}),"、",s.jsx("code",{children:"String"}),"、",s.jsx("code",{children:"Array"}),"、",s.jsx("code",{children:"Dictionary"}),"、",s.jsx("code",{children:"Set"}),"——背后全是 struct，都是值类型。这与很多语言「对象默认是引用」的直觉相反， 也正是 Swift 风格的根基。"]}),s.jsx("h2",{children:"二、眼见为实：改副本不影响原值 vs 改引用互相影响"}),s.jsx("p",{children:"最能说明问题的，是把同一段「赋值再修改」分别用 struct 和 class 跑一遍，观察原值有没有跟着变。"}),s.jsx(e,{lang:"swift",title:"struct：复制，各自独立",code:d}),s.jsxs("p",{children:["上面 ",s.jsx("code",{children:"b = a"})," 复制出了一份全新的 ",s.jsx("code",{children:"PointStruct"}),"，改 ",s.jsx("code",{children:"b.x"})," 跟",s.jsx("code",{children:"a"})," 毫无关系。换成 class，结果就完全反过来："]}),s.jsx(e,{lang:"swift",title:"class：共享，互相影响",code:l}),s.jsxs("p",{children:["注意 class 版本里我用的是 ",s.jsx("code",{children:"let a"})," 和 ",s.jsx("code",{children:"let b"}),"，依然能改 ",s.jsx("code",{children:"b.x"}),"。 这不是 bug——对引用类型，",s.jsx("code",{children:"let"})," 锁的是「引用本身不能再指向别的实例」， 而实例",s.jsx("strong",{children:"内部"}),"的 ",s.jsx("code",{children:"var"})," 属性照样能改。这点我们第五节会细讲。"]}),s.jsx(i,{title:"一个真实场景里的踩坑",children:s.jsxs("p",{children:["假设你有一个购物车 ",s.jsx("code",{children:"cart"}),"，想「先备份当前状态再做实验性修改」。如果购物车是 struct，",s.jsx("code",{children:"let backup = cart"})," 就是一份安全快照，怎么改 ",s.jsx("code",{children:"cart"})," 都伤不到",s.jsx("code",{children:"backup"}),"。但如果购物车是 class，",s.jsx("code",{children:"backup"})," 和 ",s.jsx("code",{children:"cart"})," 指向同一个对象， 你以为留了后路，实际「备份」会跟着一起变——这是引用类型最常见的隐蔽 bug。"]})}),s.jsx("h2",{children:"三、值类型为何「安全」：没有意外的远程修改"}),s.jsxs("p",{children:["值语义最大的好处是",s.jsx("strong",{children:"本地推理"}),"（local reasoning）：当你拿到一个值类型变量， 你可以确信「除非我自己动它，否则没人能偷偷改它」。函数把 struct 当参数收进去，收到的是副本， 函数内部怎么折腾都不会波及调用方的原值。这消除了一整类「某处的修改莫名其妙影响到另一处」的 并发与共享 bug，也让代码更容易测试和并发安全。"]}),s.jsx("p",{children:"引用类型则相反：把一个对象传给好几个地方后，任何一方的修改对其他持有者都是可见的。 这种「共享可变状态」在需要协作时很强大，但也意味着你必须时刻警惕「谁还握着这个引用」。"}),s.jsx("h2",{children:"四、写时复制（CoW）：值语义不等于「每次都真复制」"}),s.jsxs("p",{children:["有人会担心：",s.jsx("code",{children:"Array"})," 是值类型，那把一个百万元素的数组赋值给另一个变量， 岂不是每次都要把一百万个元素拷一遍？答案是",s.jsx("strong",{children:"不会"}),"。标准库集合用",s.jsx("strong",{children:"写时复制（Copy-on-Write，CoW）"}),"做了优化。"]}),s.jsxs(r,{children:["写时复制的策略是：",s.jsx("strong",{children:"只读时共享底层存储，真正要写入时才分裂出独立拷贝"}),"。 于是「赋值」这一步几乎零成本（只共享一个缓冲区），只有当你",s.jsx("strong",{children:"修改"}),"其中一份时， 才发生一次实际复制——但对外表现出来的语义，仍然是纯粹的值语义（两份互不影响）。"]}),s.jsx(e,{lang:"swift",title:"Array 的写时复制行为",code:j}),s.jsxs("p",{children:["CoW 让 Swift 在「值语义的安全」和「引用共享的性能」之间拿到了两全。需要强调的是： CoW 是 ",s.jsx("code",{children:"Array"})," / ",s.jsx("code",{children:"Dictionary"})," / ",s.jsx("code",{children:"Set"})," / ",s.jsx("code",{children:"String"}),"这些标准库类型",s.jsx("strong",{children:"内部实现"}),"的优化，你自己写的普通 struct 默认",s.jsx("strong",{children:"不"}),"自动具备 CoW（要手动用一个 class 包裹的存储 + ",s.jsx("code",{children:"isKnownUniquelyReferenced"})," 才能实现）， 但日常几乎用不到这种手写优化。"]}),s.jsx("h2",{children:"五、mutating 与不可变性"}),s.jsxs("p",{children:["值类型的方法默认",s.jsx("strong",{children:"不能"}),"修改自身的存储属性，因为「修改一个值」在概念上等于 「换成一个新值」。如果一个方法确实需要改自身属性，必须显式标注 ",s.jsx("code",{children:"mutating"}),"。"]}),s.jsx(e,{lang:"swift",title:"mutating 方法",code:x}),s.jsxs("p",{children:["这也解释了为什么 ",s.jsx("code",{children:"mutating"})," 方法只能在用 ",s.jsx("code",{children:"var"})," 声明的实例上调用： 调用它本质上是「把旧值替换成改过的新值」，而 ",s.jsx("code",{children:"let"})," 的值是不允许被替换的。"]}),s.jsxs("p",{children:["关于 ",s.jsx("code",{children:"let"}),"，值类型和引用类型的「不可变」深度完全不同，这是新手最容易混淆的点："]}),s.jsx(e,{lang:"swift",title:"let 在值类型 vs 引用类型上的差异",code:h}),s.jsxs("table",{children:[s.jsx("thead",{children:s.jsxs("tr",{children:[s.jsx("th",{children:"声明"}),s.jsx("th",{children:"能换成别的实例吗"}),s.jsx("th",{children:"能改实例内部属性吗"})]})}),s.jsxs("tbody",{children:[s.jsxs("tr",{children:[s.jsxs("td",{children:[s.jsx("code",{children:"let"})," + 值类型"]}),s.jsx("td",{children:"不能"}),s.jsxs("td",{children:[s.jsx("strong",{children:"不能"}),"（深层不可变）"]})]}),s.jsxs("tr",{children:[s.jsxs("td",{children:[s.jsx("code",{children:"var"})," + 值类型"]}),s.jsx("td",{children:"能"}),s.jsx("td",{children:"能"})]}),s.jsxs("tr",{children:[s.jsxs("td",{children:[s.jsx("code",{children:"let"})," + 引用类型"]}),s.jsx("td",{children:"不能"}),s.jsxs("td",{children:[s.jsx("strong",{children:"能"}),"（引用不变，对象可变）"]})]}),s.jsxs("tr",{children:[s.jsxs("td",{children:[s.jsx("code",{children:"var"})," + 引用类型"]}),s.jsx("td",{children:"能"}),s.jsx("td",{children:"能"})]})]})]}),s.jsx("h2",{children:"六、struct vs class 对比总表"}),s.jsxs("table",{children:[s.jsx("thead",{children:s.jsxs("tr",{children:[s.jsx("th",{children:"维度"}),s.jsx("th",{children:"struct（值类型）"}),s.jsx("th",{children:"class（引用类型）"})]})}),s.jsxs("tbody",{children:[s.jsxs("tr",{children:[s.jsx("td",{children:"赋值 / 传参"}),s.jsx("td",{children:"复制独立副本"}),s.jsx("td",{children:"共享同一实例的引用"})]}),s.jsxs("tr",{children:[s.jsx("td",{children:"相等语义"}),s.jsxs("td",{children:["看内容（可自动合成 ",s.jsx("code",{children:"Equatable"}),"）"]}),s.jsxs("td",{children:["看身份（",s.jsx("code",{children:"==="})," 比较是否同一对象）"]})]}),s.jsxs("tr",{children:[s.jsx("td",{children:"内存管理"}),s.jsx("td",{children:"无需 ARC，随作用域自动释放"}),s.jsx("td",{children:"由 ARC 引用计数管理"})]}),s.jsxs("tr",{children:[s.jsx("td",{children:"继承"}),s.jsx("td",{children:"不支持类继承"}),s.jsx("td",{children:"支持继承与多态"})]}),s.jsxs("tr",{children:[s.jsx("td",{children:"可变性控制"}),s.jsxs("td",{children:[s.jsx("code",{children:"let"})," 即深层不可变；改自身需 ",s.jsx("code",{children:"mutating"})]}),s.jsxs("td",{children:[s.jsx("code",{children:"let"})," 仅锁引用，内部仍可变"]})]}),s.jsxs("tr",{children:[s.jsx("td",{children:"身份概念"}),s.jsx("td",{children:"无身份，只有值"}),s.jsx("td",{children:"有唯一身份"})]}),s.jsxs("tr",{children:[s.jsx("td",{children:"典型用途"}),s.jsx("td",{children:"建模数据、状态、SwiftUI View"}),s.jsx("td",{children:"需共享 / 身份 / 继承 / OC 互操作"})]})]})]}),s.jsx("h2",{children:"七、SwiftUI 为什么偏爱 struct"}),s.jsxs("p",{children:["SwiftUI 里的视图——",s.jsx("code",{children:"Text"}),"、",s.jsx("code",{children:"VStack"}),"、你自己写的",s.jsx("code",{children:"struct ContentView: View"}),"——几乎清一色是 struct。这不是巧合， 而是值语义和声明式 UI 的天作之合。"]}),s.jsxs(r,{children:["SwiftUI 的核心是「",s.jsx("strong",{children:"状态驱动视图"}),"」：状态一变，框架重新计算 ",s.jsx("code",{children:"body"}),"得到一棵新的视图描述，再和旧的做 ",s.jsx("strong",{children:"diff"}),"，只把真正变化的部分更新到屏幕。 值语义让「新旧两棵视图树」成为两份独立、可放心比较的快照，状态变化变得",s.jsx("strong",{children:"可预测、可比较"}),"， 这正是高效 diff 的前提。"]}),s.jsx(e,{lang:"swift",title:"SwiftUI View 是 struct",code:o}),s.jsx("p",{children:"因为 View 是轻量的值类型，SwiftUI 可以毫无心理负担地频繁创建、丢弃、重建它们——它们只是对 「界面此刻应该长什么样」的廉价描述，而非真正持有屏幕资源的重对象。如果 View 是 class， 共享可变状态会让「这棵树和上一棵是不是同一份」变得难以判断，diff 也就无从谈起。"}),s.jsxs(t,{variant:"tip",title:"经验法则",children:["在 Swift / SwiftUI 里，",s.jsx("strong",{children:"默认先用 struct"}),"。先把数据、模型、视图都建成值类型， 只有当你遇到「确实需要引用类型」的明确信号时，再升级为 class。"]}),s.jsx("h2",{children:"八、那 class 什么时候才必要？"}),s.jsx("p",{children:"值类型虽好，但有几类需求是 struct 天生满足不了的，这时候 class 才是对的工具："}),s.jsxs("ul",{children:[s.jsxs("li",{children:[s.jsx("strong",{children:"需要身份（identity）"}),"：当「是不是同一个东西」本身有意义，比如一个网络连接、 一个数据库会话、一个被多处观察的共享控制器——你关心的是「这一个实例」，而非它当前的值。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"需要共享可变状态"}),"：多个地方要持有并修改",s.jsx("strong",{children:"同一份"}),"数据（如全局的用户登录态、 一个被多个视图共享的 ViewModel），引用语义恰好提供了「改一处、处处可见」。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"需要继承与多态"}),"：要建立类的层级、用基类引用调用子类重写的方法时，只有 class 能做到。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"Objective-C 互操作"}),"：需要桥接到 OC API、用 ",s.jsx("code",{children:"@objc"}),"、继承",s.jsx("code",{children:"NSObject"}),"（如某些 UIKit / 系统框架类型）时，必须是 class。"]})]}),s.jsx("h2",{children:"九、ARC 与循环引用（一句话版）"}),s.jsxs("p",{children:["引用类型的生命周期由 ",s.jsx("strong",{children:"ARC（自动引用计数）"}),"管理：有几个强引用指向一个对象， 它的计数就是几，计数归零时对象被释放。隐患在于",s.jsx("strong",{children:"循环引用"}),"——两个对象互相强引用， 计数永远到不了零，于是谁也释放不掉，造成内存泄漏。解法是把其中一条引用改成",s.jsx("code",{children:"weak"}),"（或 ",s.jsx("code",{children:"unowned"}),"）来打破环。"]}),s.jsx(e,{lang:"swift",title:"用 weak 打破循环引用",code:a}),s.jsxs(t,{variant:"warn",title:"值类型没有这个烦恼",children:["struct / enum 不参与 ARC，也就根本不存在引用循环这回事——这又是「默认用值类型」的一个理由。 循环引用是引用类型独有的负担，闭包捕获 ",s.jsx("code",{children:"self"})," 时尤其常见（用",s.jsx("code",{children:"[weak self]"})," 捕获列表处理），后续讲闭包时会再遇到。"]}),s.jsx(n,{points:["struct/enum 是值类型：赋值与传参会复制独立副本，改副本不影响原值；class 是引用类型：赋值只是共享同一实例，通过任一引用修改其它引用都会看见。","值语义带来本地推理与安全：拿到一个值就能确信没人会偷偷改它，天然规避共享可变状态的一类 bug。","写时复制（CoW）是标准库集合的优化：只读时共享底层存储，真要写入时才分裂拷贝，对外仍是纯值语义，兼顾安全与性能。","mutating 让值类型方法可改自身（仅限 var 实例）；let 修饰值类型是深层不可变，修饰引用类型只锁引用、对象内部仍可变。","SwiftUI 偏爱 struct：值语义让新旧视图树成为可放心比较的独立快照，使状态可预测、便于 diff 高效更新。","class 在需要身份、共享可变状态、继承多态、或 Objective-C 互操作时才必要；引用类型由 ARC 管理，互相强引用会造成循环引用泄漏，用 weak 打破。"]})]})}export{S as default};
