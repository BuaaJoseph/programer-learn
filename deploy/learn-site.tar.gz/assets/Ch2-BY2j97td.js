import{j as e}from"./index-CVHWXZpb.js";import{L as d,S as i}from"./Summary-CJTCDEeZ.js";import{K as r}from"./KeyIdea-XVLVSS4B.js";import{C as n}from"./Callout-DCq22jZW.js";import{C as t}from"./CodeBlock-ljkh5ShG.js";import{E as s}from"./Example-BSuN_UvG.js";import{P as c}from"./Practice-D2QRX8ZH.js";import{P as l}from"./PyRunner-DI0kjGpk.js";const o=`# 字典：增、改、查、遍历
scores = {"语文": 88, "数学": 95}
scores["英语"] = 90        # 增
scores["语文"] = 92        # 改
print("数学成绩：", scores["数学"])   # 查

for subject, score in scores.items():
    print(f"{subject}: {score}")

# 集合：去重 + 交并
a = {1, 2, 3, 3, 2}        # 重复会自动去掉
b = {3, 4, 5}
print("去重后：", a)
print("交集：", a & b)
print("并集：", a | b)`,x=`student = {
    "name": "小明",
    "age": 18,
    "score": 92,
}
print(student)
print(student["name"])   # 用键取值
print(student["age"])`,h=`{'name': '小明', 'age': 18, 'score': 92}
小明
18`,j=`student = {"name": "小明", "age": 18}
print(student.get("name"))        # 等同于 student["name"]
print(student.get("phone"))       # 键不存在，返回 None，不报错
print(student.get("phone", "未填")) # 不存在时返回默认值
# print(student["phone"])         # 这样写键不存在会直接 KeyError`,a=`小明
None
未填`,p=`d = {"a": 1, "b": 2}
d["c"] = 3        # 新增：键不存在就添加
d["a"] = 100      # 修改：键已存在就更新
del d["b"]        # 删除
print(d)`,g="{'a': 100, 'c': 3}",u=`student = {"name": "小明", "age": 18, "score": 92}
for key in student:               # 直接遍历得到的是「键」
    print(key, "=", student[key])

print("---")
for k, v in student.items():      # items() 同时拿键和值
    print(k, "->", v)

print(list(student.keys()))       # 所有键
print(list(student.values()))     # 所有值`,m=`name = 小明
age = 18
score = 92
---
name -> 小明
age -> 18
score -> 92
['name', 'age', 'score']
['小明', '18', '92']`,y=`users = {
    "u1": {"name": "小明", "age": 18},
    "u2": {"name": "小红", "age": 20},
}
print(users["u1"]["name"])    # 一层层取
print(users["u2"]["age"])`,f=`小明
20`,C=`s = {1, 2, 3, 2, 1}     # 集合用花括号，自动去重
print(s)
nums = [1, 1, 2, 3, 3, 3]
print(set(nums))         # 用 set() 给列表去重
empty = set()            # 注意：空集合要用 set()，{} 是空字典`,b=`{1, 2, 3}
{1, 2, 3}`,k=`a = {1, 2, 3, 4}
b = {3, 4, 5, 6}
print(a & b)    # 交集：两边都有的
print(a | b)    # 并集：两边合起来
print(a - b)    # 差集：a 有但 b 没有的
print(3 in a)   # 判断元素是否在集合里（非常快）`,O=`{3, 4}
{1, 2, 3, 4, 5, 6}
{1, 2}
True`;function L(){return e.jsxs("article",{children:[e.jsxs(d,{children:["列表用「位置」找数据，但很多时候我们想用「名字」找——比如用「name」拿到名字、用「age」拿到年龄。 这就是",e.jsx("strong",{children:"字典"}),"的用武之地：键值对的集合。这一章讲字典的创建、取值、增删改、遍历和嵌套， 再介绍另一个容器——擅长去重和集合运算的",e.jsx("strong",{children:"集合"}),"。"]}),e.jsx("h2",{children:"一、字典是什么"}),e.jsxs(r,{children:["字典（dict）存的是",e.jsx("strong",{children:"键值对"}),"（key: value）：每个「值」都有一个「键」做标签， 用键就能取出值。用",e.jsx("strong",{children:"花括号"})," ",e.jsx("code",{children:"{}"})," 创建，键和值之间用冒号，对与对之间用逗号。"]}),e.jsx(t,{lang:"python",title:"创建字典、用键取值",code:x}),e.jsx(s,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:h})}),e.jsxs(n,{variant:"note",title:"键通常用字符串",children:["键一般是字符串（也可以是数字、元组），且",e.jsx("strong",{children:"不能重复"}),"；值可以是任意类型。 字典适合表示「一个有多种属性的东西」，比如一个学生、一件商品。"]}),e.jsx("h2",{children:"二、用 get 安全取值"}),e.jsxs("p",{children:["直接用 ",e.jsx("code",{children:'d["键"]'})," 取值时，如果键不存在会直接报 ",e.jsx("code",{children:"KeyError"}),"。 更安全的做法是用 ",e.jsx("code",{children:"get()"}),"，键不存在时返回 ",e.jsx("code",{children:"None"})," 或你指定的默认值，不报错："]}),e.jsx(t,{lang:"python",title:"get 安全取值",code:j}),e.jsx(s,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:a})}),e.jsxs(n,{variant:"tip",children:["不确定键在不在的时候，优先用 ",e.jsx("code",{children:"get"}),"，能避免程序因为 ",e.jsx("code",{children:"KeyError"})," 直接崩溃。"]}),e.jsx("h2",{children:"三、增、删、改"}),e.jsxs("p",{children:["字典的增和改都用 ",e.jsx("code",{children:'d["键"] = 值'}),"：键不存在就",e.jsx("strong",{children:"新增"}),"，键已存在就",e.jsx("strong",{children:"修改"}),"。 删除用 ",e.jsx("code",{children:"del"}),"："]}),e.jsx(t,{lang:"python",title:"增删改",code:p}),e.jsx(s,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:g})}),e.jsx("h2",{children:"四、遍历字典"}),e.jsxs("p",{children:["遍历字典有几种方式，最常用的是 ",e.jsx("code",{children:"items()"}),"，能同时拿到键和值："]}),e.jsx(t,{lang:"python",title:"遍历键、键值对",code:u}),e.jsx(s,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:m})}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"写法"}),e.jsx("th",{children:"得到"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"for k in d"})}),e.jsx("td",{children:"每个键"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"d.keys()"})}),e.jsx("td",{children:"所有键"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"d.values()"})}),e.jsx("td",{children:"所有值"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"d.items()"})}),e.jsx("td",{children:"每个 (键, 值) 对"})]})]})]}),e.jsx("h2",{children:"五、嵌套字典"}),e.jsx("p",{children:"字典的值也可以是字典，用来表示更复杂的结构（这也是网络数据 JSON 的常见形态，做 AI、爬虫时天天见）："}),e.jsx(t,{lang:"python",title:"嵌套字典",code:y}),e.jsx(s,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:f})}),e.jsx("h2",{children:"六、集合：去重与集合运算"}),e.jsxs(r,{children:["集合（set）也用花括号，但里面只有「值」没有「键」，而且元素",e.jsx("strong",{children:"不重复、无序"}),"。 它最拿手两件事：",e.jsx("strong",{children:"去重"}),"和",e.jsx("strong",{children:"集合运算"}),"（交、并、差）。"]}),e.jsx(t,{lang:"python",title:"创建集合与去重",code:C}),e.jsx(s,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:b})}),e.jsxs(n,{variant:"warn",title:"空集合不能写成 {}",children:[e.jsx("code",{children:"{}"})," 是一个",e.jsx("strong",{children:"空字典"}),"，不是空集合！要创建空集合必须用 ",e.jsx("code",{children:"set()"}),"。"]}),e.jsx("p",{children:"集合运算用几个简单符号就能完成，处理「两组数据有什么交集 / 合在一起 / 谁多出来」非常方便："}),e.jsx(t,{lang:"python",title:"交、并、差与 in",code:k}),e.jsx(s,{title:"运行结果",children:e.jsx(t,{lang:"text",title:"运行结果",code:O})}),e.jsxs(n,{variant:"tip",children:["用 ",e.jsx("code",{children:"in"})," 判断某个值是否存在时，集合比列表",e.jsx("strong",{children:"快得多"}),"。 当你只关心「在不在」、且数据量大时，优先用集合。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」，看看结果。"]}),e.jsx(l,{initialCode:o}),e.jsx(c,{title:"动手练一练",children:e.jsxs("ol",{children:[e.jsx("li",{children:"建一个字典记录一件商品的名称、价格、库存，然后把价格改成打 9 折后的值并打印。"}),e.jsxs("li",{children:["用 ",e.jsx("code",{children:"items()"})," 遍历这个商品字典，按「键：值」的格式逐行打印。"]}),e.jsxs("li",{children:["给一个有重复元素的列表去重（用 ",e.jsx("code",{children:"set()"}),"），再用 ",e.jsx("code",{children:"&"})," 求出两个集合的共同元素。"]})]})}),e.jsx(i,{points:["字典是键值对集合，用花括号 {键: 值} 创建，用 d[键] 取值；键不重复，常用字符串做键。","取值优先用 d.get(键, 默认值)，键不存在不报错；直接 d[键] 取不存在的键会 KeyError。","增和改都用 d[键] = 值（不存在则新增），删用 del d[键]。","遍历：for k in d 得键；keys()/values()/items() 分别拿键/值/键值对，items 最常用。","字典可嵌套，对应网络数据 JSON 结构，用多层下标访问。","集合用花括号、元素不重复无序，擅长去重（set()）和交并差（& | -）；空集合要写 set()，in 判断很快。"]})]})}export{L as default};
