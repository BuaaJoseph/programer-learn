import{r as a,j as e,C as Ee,u as tt,P as nt}from"./index-BdVncPlI.js";import{r as st,f as ge,l as at,g as it,S as rt,b as lt,c as Ce,a as ke,t as ot,d as ct,e as dt}from"./api-yTEyUW0L.js";const Re=[{id:"two-sum-ii",title:"两数之和 II（有序数组）",difficulty:"中等",tags:["数组","双指针"],statement:`给定一个已按升序排列的整数数组 numbers 和目标值 target，请找出两个数使它们相加之和等于 target，返回这两个数的下标（从 1 开始），要求空间复杂度 O(1)。

输入：第一行为目标值 target，第二行为以空格分隔的有序数组。
输出：两个下标，空格分隔。`,sampleInput:`9
2 7 11 15`,sampleOutput:"1 2"},{id:"longest-substring",title:"无重复字符的最长子串",difficulty:"中等",tags:["滑动窗口","哈希"],statement:`给定一个字符串 s，找出其中不含重复字符的最长子串的长度。

输入：一行字符串 s。
输出：最长无重复子串的长度。`,sampleInput:"abcabcbb",sampleOutput:"3"},{id:"add-two-numbers",title:"两个大数相加（字符串）",difficulty:"中等",tags:["字符串","模拟"],statement:`给定两个用字符串表示的非负大整数 a、b（可能超过 long 范围），返回它们之和（字符串）。

输入：两行，分别为 a 和 b。
输出：a + b。`,sampleInput:`99999999999999999999
1`,sampleOutput:"100000000000000000000"},{id:"lru-cache",title:"LRU 缓存机制",difficulty:"中等",tags:["设计","哈希","双向链表"],statement:`设计并实现一个 LRU（最近最少使用）缓存，支持 get 和 put，容量满时淘汰最久未使用的项，均要求 O(1)。

输入：第一行为容量 cap 与操作数 n；接下来 n 行，每行形如 "put 1 1" 或 "get 1"。
输出：每个 get 操作的返回值（未命中输出 -1），空格分隔在一行。`,sampleInput:`2 5
put 1 1
put 2 2
get 1
put 3 3
get 2`,sampleOutput:"1 -1"},{id:"longest-palindrome",title:"最长回文子串",difficulty:"中等",tags:["字符串","动态规划"],statement:`给定字符串 s，返回它的最长回文子串。

输入：一行字符串 s。
输出：最长回文子串（若有多个，输出任意一个）。`,sampleInput:"babad",sampleOutput:"bab"},{id:"three-sum",title:"三数之和",difficulty:"中等",tags:["数组","双指针"],statement:`给定数组 nums，找出所有和为 0 且不重复的三元组，按升序输出。

输入：一行以空格分隔的整数数组。
输出：每行一个三元组（升序、空格分隔）；无解输出空。`,sampleInput:"-1 0 1 2 -1 -4",sampleOutput:`-1 -1 2
-1 0 1`},{id:"container-water",title:"盛最多水的容器",difficulty:"中等",tags:["双指针","贪心"],statement:`给定 n 个非负整数表示柱子高度，找出两条柱子使其与 x 轴构成的容器能盛最多的水，输出最大面积。

输入：一行以空格分隔的高度数组。
输出：最大面积。`,sampleInput:"1 8 6 2 5 4 8 3 7",sampleOutput:"49"},{id:"coin-change",title:"零钱兑换",difficulty:"中等",tags:["动态规划"],statement:`给定硬币面额数组 coins 和总金额 amount，求凑成总金额所需最少硬币数；无法凑成输出 -1。

输入：第一行 amount；第二行硬币面额（空格分隔）。
输出：最少硬币数。`,sampleInput:`11
1 2 5`,sampleOutput:"3"},{id:"word-break",title:"单词拆分",difficulty:"中等",tags:["动态规划","字符串"],statement:`给定字符串 s 和单词字典 wordDict，判断 s 是否能被空格拆分成字典中的单词序列。

输入：第一行 s；第二行字典单词（空格分隔）。
输出：true 或 false。`,sampleInput:`leetcode
leet code`,sampleOutput:"true"},{id:"num-islands",title:"岛屿数量",difficulty:"中等",tags:["DFS","BFS","并查集"],statement:`给定由 '1'（陆地）和 '0'（水）组成的二维网格，计算岛屿数量。岛屿由相邻（上下左右）陆地连接。

输入：第一行 m n；接下来 m 行，每行 n 个 0/1（空格分隔）。
输出：岛屿数量。`,sampleInput:`3 3
1 1 0
0 1 0
0 0 1`,sampleOutput:"2"},{id:"course-schedule",title:"课程表（拓扑排序）",difficulty:"中等",tags:["图","拓扑排序"],statement:`共有 numCourses 门课，先修关系给定为 [a, b]（学 a 前必须先学 b）。判断能否完成所有课程。

输入：第一行 numCourses 与边数 m；接下来 m 行每行两个数 a b。
输出：true 或 false。`,sampleInput:`2 1
1 0`,sampleOutput:"true"},{id:"kth-largest",title:"数组中的第 K 个最大元素",difficulty:"中等",tags:["堆","快速选择"],statement:`在未排序数组中找到第 k 个最大的元素。

输入：第一行 k；第二行数组（空格分隔）。
输出：第 k 大的元素。`,sampleInput:`2
3 2 1 5 6 4`,sampleOutput:"5"},{id:"merge-intervals",title:"合并区间",difficulty:"中等",tags:["排序","区间"],statement:`给定若干区间，合并所有重叠区间。

输入：第一行区间数 n；接下来 n 行每行两个数 start end。
输出：合并后的区间，每行两个数（按起点升序）。`,sampleInput:`4
1 3
2 6
8 10
15 18`,sampleOutput:`1 6
8 10
15 18`},{id:"rotate-image",title:"旋转图像",difficulty:"中等",tags:["数组","矩阵"],statement:`给定 n×n 矩阵，将其原地顺时针旋转 90 度。

输入：第一行 n；接下来 n 行每行 n 个数。
输出：旋转后的矩阵。`,sampleInput:`3
1 2 3
4 5 6
7 8 9`,sampleOutput:`7 4 1
8 5 2
9 6 3`},{id:"subsets",title:"子集",difficulty:"中等",tags:["回溯","位运算"],statement:`给定一个不含重复元素的整数数组 nums，返回其所有可能的子集（幂集）。

输入：一行数组（空格分隔）。
输出：每行一个子集（空格分隔，含空行表示空集），顺序不限。`,sampleInput:"1 2 3",sampleOutput:`
1
2
1 2
3
1 3
2 3
1 2 3`},{id:"permutations",title:"全排列",difficulty:"中等",tags:["回溯"],statement:`给定不含重复数字的数组 nums，返回其所有全排列。

输入：一行数组（空格分隔）。
输出：每行一个排列（空格分隔），顺序不限。`,sampleInput:"1 2 3",sampleOutput:`1 2 3
1 3 2
2 1 3
2 3 1
3 1 2
3 2 1`},{id:"search-rotated",title:"搜索旋转排序数组",difficulty:"中等",tags:["二分查找"],statement:`整数数组 nums 升序排列后在某个未知点旋转，给定 target，存在则返回下标，否则返回 -1，要求 O(log n)。

输入：第一行 target；第二行数组。
输出：下标或 -1。`,sampleInput:`0
4 5 6 7 0 1 2`,sampleOutput:"4"},{id:"product-except-self",title:"除自身以外数组的乘积",difficulty:"中等",tags:["数组","前缀积"],statement:`给定数组 nums，返回数组 answer，其中 answer[i] 等于 nums 中除 nums[i] 之外其余元素的乘积，不能使用除法，O(n)。

输入：一行数组。
输出：结果数组（空格分隔）。`,sampleInput:"1 2 3 4",sampleOutput:"24 12 8 6"},{id:"daily-temperatures",title:"每日温度（单调栈）",difficulty:"中等",tags:["单调栈"],statement:`给定每日温度数组，返回数组 answer，answer[i] 表示第 i 天之后要等多少天才会有更高温度；若不存在则为 0。

输入：一行温度数组。
输出：结果数组（空格分隔）。`,sampleInput:"73 74 75 71 69 72 76 73",sampleOutput:"1 1 4 2 1 1 0 0"},{id:"min-path-sum",title:"最小路径和",difficulty:"中等",tags:["动态规划","矩阵"],statement:`给定 m×n 非负网格，从左上走到右下，每次只能向右或向下，求路径上数字和的最小值。

输入：第一行 m n；接下来 m 行每行 n 个数。
输出：最小路径和。`,sampleInput:`3 3
1 3 1
1 5 1
4 2 1`,sampleOutput:"7"},{id:"unique-paths",title:"不同路径",difficulty:"中等",tags:["动态规划","组合数学"],statement:`m×n 网格，机器人从左上到右下，每次只能向右或向下，求不同路径总数。

输入：一行 m n。
输出：路径数。`,sampleInput:"3 7",sampleOutput:"28"},{id:"max-subarray",title:"最大子数组和",difficulty:"中等",tags:["动态规划","分治"],statement:`给定整数数组 nums，找到具有最大和的连续子数组，返回其和。

输入：一行数组。
输出：最大子数组和。`,sampleInput:"-2 1 -3 4 -1 2 1 -5 4",sampleOutput:"6"},{id:"group-anagrams",title:"字母异位词分组",difficulty:"中等",tags:["哈希","字符串"],statement:`给定字符串数组，把字母异位词组合在一起。

输入：一行若干单词（空格分隔）。
输出：每行一组异位词（空格分隔），组内与组间顺序不限。`,sampleInput:"eat tea tan ate nat bat",sampleOutput:`eat tea ate
tan nat
bat`},{id:"spiral-matrix",title:"螺旋矩阵",difficulty:"中等",tags:["矩阵","模拟"],statement:`给定 m×n 矩阵，按顺时针螺旋顺序返回所有元素。

输入：第一行 m n；接下来 m 行每行 n 个数。
输出：螺旋顺序的所有元素（空格分隔，一行）。`,sampleInput:`3 3
1 2 3
4 5 6
7 8 9`,sampleOutput:"1 2 3 6 9 8 7 4 5"},{id:"jump-game",title:"跳跃游戏",difficulty:"中等",tags:["贪心"],statement:`给定非负整数数组 nums，初始位于下标 0，每个元素代表在该位置可跳跃的最大长度，判断能否到达最后一个下标。

输入：一行数组。
输出：true 或 false。`,sampleInput:"2 3 1 1 4",sampleOutput:"true"},{id:"longest-consecutive",title:"最长连续序列",difficulty:"中等",tags:["哈希","并查集"],statement:`给定未排序数组 nums，找出数字连续的最长序列长度，要求 O(n)。

输入：一行数组。
输出：最长连续序列长度。`,sampleInput:"100 4 200 1 3 2",sampleOutput:"4"},{id:"top-k-frequent",title:"前 K 个高频元素",difficulty:"中等",tags:["堆","哈希"],statement:`给定整数数组 nums 和整数 k，返回出现频率前 k 高的元素（按频率从高到低）。

输入：第一行 k；第二行数组。
输出：前 k 个高频元素（空格分隔）。`,sampleInput:`2
1 1 1 2 2 3`,sampleOutput:"1 2"},{id:"decode-ways",title:"解码方法",difficulty:"中等",tags:["动态规划","字符串"],statement:`数字到字母的映射为 '1'->A ... '26'->Z。给定只含数字的字符串 s，计算它有多少种解码方法。

输入：一行数字字符串 s。
输出：解码方法数。`,sampleInput:"226",sampleOutput:"3"},{id:"validate-bst",title:"验证二叉搜索树",difficulty:"中等",tags:["树","DFS"],statement:`给定二叉树的层序遍历（null 表示空节点），判断它是否是有效的二叉搜索树。

输入：一行层序遍历，节点值或 null，空格分隔。
输出：true 或 false。`,sampleInput:"5 1 4 null null 3 6",sampleOutput:"false"},{id:"gas-station",title:"加油站",difficulty:"中等",tags:["贪心"],statement:`环路上有 n 个加油站，gas[i] 为可加油量，cost[i] 为到下一站的耗油。从某站出发绕一圈，返回可行的起始站下标，无解返回 -1。

输入：第一行 gas 数组；第二行 cost 数组。
输出：起始站下标或 -1。`,sampleInput:`1 2 3 4 5
3 4 5 1 2`,sampleOutput:"3"},{id:"partition-equal",title:"分割等和子集",difficulty:"中等",tags:["动态规划","背包"],statement:`给定只含正整数的非空数组 nums，判断能否将其分割成两个和相等的子集。

输入：一行数组。
输出：true 或 false。`,sampleInput:"1 5 11 5",sampleOutput:"true"},{id:"house-robber-ii",title:"打家劫舍 II（环形）",difficulty:"中等",tags:["动态规划"],statement:`房屋围成一圈，相邻两间不能同时偷。给定每间金额数组 nums，求能偷到的最高金额。

输入：一行数组。
输出：最高金额。`,sampleInput:"2 3 2",sampleOutput:"3"},{id:"find-duplicate",title:"寻找重复数",difficulty:"中等",tags:["双指针","快慢指针"],statement:`给定 n+1 个整数的数组 nums，数字都在 [1, n] 内，存在且仅存在一个重复数，找出它（不修改数组、O(1) 空间）。

输入：一行数组。
输出：重复的数字。`,sampleInput:"1 3 4 2 2",sampleOutput:"2"},{id:"min-window",title:"最小覆盖子串",difficulty:"困难",tags:["滑动窗口","哈希"],statement:`给定字符串 s 和 t，返回 s 中涵盖 t 所有字符的最小子串；不存在则返回空串。

输入：第一行 s；第二行 t。
输出：最小覆盖子串。`,sampleInput:`ADOBECODEBANC
ABC`,sampleOutput:"BANC"},{id:"trapping-rain",title:"接雨水",difficulty:"困难",tags:["双指针","单调栈"],statement:`给定 n 个非负整数表示柱子高度图，计算下雨后能接多少雨水。

输入：一行高度数组。
输出：能接的雨水总量。`,sampleInput:"0 1 0 2 1 0 1 3 2 1 2 1",sampleOutput:"6"},{id:"edit-distance",title:"编辑距离",difficulty:"困难",tags:["动态规划"],statement:`给定两个单词 word1 和 word2，返回将 word1 转换成 word2 所使用的最少操作数（插入/删除/替换）。

输入：两行，分别为 word1 和 word2。
输出：最少操作数。`,sampleInput:`horse
ros`,sampleOutput:"3"},{id:"lis",title:"最长递增子序列",difficulty:"中等",tags:["动态规划","二分"],statement:`给定整数数组 nums，找到其中最长严格递增子序列的长度。

输入：一行数组。
输出：最长递增子序列长度。`,sampleInput:"10 9 2 5 3 7 101 18",sampleOutput:"4"}],me={python:`import sys

def solve(data):
    # data 是按行切分的输入列表；在这里实现你的逻辑并 print 结果
    pass

def main():
    data = sys.stdin.read().split('\\n')
    solve(data)

if __name__ == '__main__':
    main()
`,java:`import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // 在这里读取输入、实现逻辑并 System.out.println 输出结果
        // String line = br.readLine();
    }
}
`};function Ie(){const n=Math.floor(Math.random()*Re.length);return Re[n]}const ut={python:["print(","input(","len(","range(","int(","str(","float(","list(","dict(","set(","tuple(","sorted(","reversed(","enumerate(","zip(","map(","filter(","sum(","min(","max(","abs(","round(","any(","all(","isinstance(","append(","extend(","insert(","pop(","remove(","sort(","split(","join(","strip(","replace(","startswith(","endswith(","find(","format(","keys(","values(","items(","get(","setdefault(","def ","class ","return ","import ","from ","for ","while ","if ","elif ","else:","try:","except ","finally:","with ","lambda ","yield ","global ","collections","defaultdict(","Counter(","deque(","heapq","heappush(","heappop(","heapify(","bisect","bisect_left(","bisect_right(","itertools","functools","lru_cache","math","sys.stdin","sys.stdin.read("],java:["public ","private ","protected ","static ","final ","void ","class ","interface ","extends ","implements ","return ","new ","import ","package ","if ","else ","for ","while ","switch ","case ","break;","continue;","try ","catch ","finally ","throw ","throws ","int ","long ","double ","float ","boolean ","char ","byte ","short ","String ","Integer","Long","Double","Boolean","Character","Math.","System.out.println(","System.out.print(","System.out.printf(","List<","ArrayList<","LinkedList<","Map<","HashMap<","TreeMap<","Set<","HashSet<","TreeSet<","Queue<","Deque<","ArrayDeque<","PriorityQueue<","Stack<","Collections.","Arrays.","Arrays.sort(","Arrays.asList(","StringBuilder","append(","toString()","length()","size()","add(","get(","put(","getOrDefault(","containsKey(","contains(","remove(","poll(","offer(","peek(","push(","pop(","BufferedReader","InputStreamReader","readLine()","split(","Integer.parseInt(","Long.parseLong(","String.valueOf(","Math.max(","Math.min(","Math.abs("]};function Oe(n,s){const l=n.slice(0,s).match(/[A-Za-z_.][A-Za-z0-9_.]*$/);return l?l[0]:""}function pt({initialLang:n="python",onSubmit:s}){const[r,l]=a.useState(n),[g,v]=a.useState({python:me.python,java:me.java}),[u,w]=a.useState(""),[I,y]=a.useState(""),[p,m]=a.useState(!1),[c,x]=a.useState(!1),[j,C]=a.useState({open:!1,items:[],index:0}),H=a.useRef(null),E=g[r],M=i=>v(b=>({...b,[r]:i})),P=a.useMemo(()=>ut[r]||[],[r]),z=(i,b)=>{const R=Oe(i,b);if(R.length<1){C({open:!1,items:[],index:0});return}const $=R.toLowerCase(),T=P.filter(B=>B.toLowerCase().startsWith($)&&B.toLowerCase()!==$).slice(0,8);C(T.length?{open:!0,items:T,index:0}:{open:!1,items:[],index:0})},Q=i=>{const b=H.current;if(!b)return;const R=b.selectionStart,$=Oe(E,R),T=R-$.length,B=E.slice(0,T)+i+E.slice(R);M(B);const re=T+i.length;C({open:!1,items:[],index:0}),requestAnimationFrame(()=>{b.focus(),b.selectionStart=b.selectionEnd=re})},K=i=>{M(i.target.value),z(i.target.value,i.target.selectionStart)},ae=i=>{if(j.open){if(i.key==="ArrowDown"){i.preventDefault(),C(b=>({...b,index:(b.index+1)%b.items.length}));return}if(i.key==="ArrowUp"){i.preventDefault(),C(b=>({...b,index:(b.index-1+b.items.length)%b.items.length}));return}if(i.key==="Enter"||i.key==="Tab"){i.preventDefault(),Q(j.items[j.index]);return}if(i.key==="Escape"){C({open:!1,items:[],index:0});return}}if(i.key==="Tab"){i.preventDefault();const b=i.target,R=b.selectionStart,$=b.selectionEnd,T=E.slice(0,R)+"    "+E.slice($);M(T),requestAnimationFrame(()=>{b.selectionStart=b.selectionEnd=R+4})}i.key==="Enter"&&(i.ctrlKey||i.metaKey)&&(i.preventDefault(),c||O())},O=async()=>{x(!0),m(!1),y("正在执行…");try{const i=await st({language:r,source:E,stdin:u}),b=i.output||i.stdout||"",R=i.stderr||"",$=[b,R].filter(Boolean).join(`
`);m(!!R&&!b),y($||"（没有任何输出）")}catch(i){m(!0),y(String((i==null?void 0:i.message)||i))}finally{x(!1)}},ie=()=>M(me[r]),G=Math.max(14,E.split(`
`).length+1);return e.jsxs("div",{className:"code-editor",children:[e.jsxs("div",{className:"ce-tabs",children:[["python","java"].map(i=>e.jsx("button",{className:`ce-tab ${i===r?"active":""}`,onClick:()=>{l(i),C({open:!1,items:[],index:0})},children:i==="python"?"Python":"Java"},i)),e.jsxs("div",{className:"ce-tab-actions",children:[e.jsx("button",{className:"btn btn-ghost ce-small",onClick:ie,disabled:c,children:"重置模板"}),e.jsx("button",{className:"btn btn-primary ce-small",onClick:O,disabled:c,children:c?"执行中…":"▶ 运行"})]})]}),e.jsxs("div",{className:"ce-editor-wrap",children:[e.jsx("textarea",{ref:H,className:"ce-textarea",value:E,onChange:K,onKeyDown:ae,onBlur:()=>setTimeout(()=>C({open:!1,items:[],index:0}),120),spellCheck:!1,rows:G,"aria-label":"代码编辑器"}),j.open&&e.jsx("ul",{className:"ce-suggest",children:j.items.map((i,b)=>e.jsx("li",{className:b===j.index?"active":"",onMouseDown:R=>{R.preventDefault(),Q(i)},children:i},i))})]}),e.jsxs("div",{className:"ce-io",children:[e.jsxs("div",{className:"ce-io-col",children:[e.jsx("label",{className:"ce-label",children:"标准输入（stdin，可留空）"}),e.jsx("textarea",{className:"ce-stdin",value:u,onChange:i=>w(i.target.value),spellCheck:!1,rows:4,placeholder:"把样例输入粘到这里，运行时会作为程序的标准输入"})]}),e.jsxs("div",{className:"ce-io-col",children:[e.jsx("label",{className:"ce-label",children:"运行结果"}),e.jsx("pre",{className:`ce-output${p?" is-error":""}`,children:I||"（点击「运行」查看输出）"})]})]}),e.jsxs("div",{className:"ce-bottom",children:[e.jsx("span",{className:"ce-hint",children:"提示：输入时会出现基础库联想（↑↓ 选择，Enter/Tab 补全）；Ctrl/⌘ + Enter 运行。"}),s&&e.jsx("button",{className:"btn btn-primary",onClick:()=>s({language:r,source:E}),children:"提交给面试官点评"})]})]})}function mt(){return Ee.map(n=>({slug:n.meta.slug,title:n.meta.title,desc:n.meta.shortTitle||n.meta.subtitle||"",cat:`${n.meta.categoryId}/${n.meta.subCategoryId||""}`}))}function Le(n){return`${typeof window<"u"?window.location.origin:""}/course/${n}`}function $e(n){return Ee.find(s=>s.meta.slug===n)||null}const ft={A:{label:"A · 非常满意",color:"#0e835a",desc:"语言表达、项目、技术与 Coding 近乎完美，正是公司需要的人才（极难获得）"},B:{label:"B · 优秀人才",color:"#2563eb",desc:"整体优秀，个别方面略有差距，强烈推荐给后续面试官"},C:{label:"C · 通过面试",color:"#b26a09",desc:"项目与技术基础扎实，可继续推进，但缺少特别亮眼的表现"},D:{label:"D · 未通过（可荐他岗）",color:"#c0344d",desc:"部分方面欠缺，本岗位不再推进，其他岗位可继续面试"},E:{label:"E · 不可行",color:"#7a1326",desc:"一个或多个方面表现很差，短期内不建议推进其他岗位"}};function Y(n){return ft[n]||{label:n,color:"#454c59",desc:""}}function gt(n){const s=ge(n.position),r=mt().map(l=>`${l.slug} | ${l.title}`).join(`
`);return`面试到此结束。现在请你切换为「面试评估官」，基于上面完整的面试对话记录，对这位「${s?s.title:n.position}」候选人做一次严谨、客观的综合评估打分。

# 评分等级（必须从中选一个）
- A：非常满意。语言表达、项目考察、技术技能和 Coding 都基本做到完美，正是公司需要的人才（极难获得）。
- B：优秀人才。在 A 的基础上个别方面有差距，但仍优秀，会强烈推荐给后续面试官。
- C：通过面试。项目考察、技术基础都比较扎实，可继续推进；没有特别亮眼或打动面试官的表现一般定为此级。
- D：未通过，但可推荐其他岗位。综合评估有所欠缺，本岗位不再推进，其他岗位可继续面试。
- E：完全不可行。一个或多个方面表现很差（如项目说不清、追问细节或基础知识基本不了解），短期内不建议推进其他岗位。

# 评估要求
1. 必须「结合面试中的具体问答实例」给出理由，好的与不足的地方都要引用候选人实际说过的话或表现，不能空口无凭。
2. 分维度评估：语言表达、项目考察、技术基础、AI/LLM 编程、Coding 编码。每个维度给 1-5 分并附结合实例的点评。
3. 给出后续需要加强的知识/技能清单，并尽量从下面的「本站课程清单」中挑选相关课程推荐（用 slug）。

# 本站课程清单（slug | 课程名）
${r}

# 输出格式（务必只输出一个 JSON，不要任何额外文字或 markdown 代码块标记）
{
  "grade": "A|B|C|D|E",
  "gradeReason": "为什么定这个等级（结合整体表现，2-4句）",
  "overallSummary": "整体评价（150字左右）",
  "dimensions": [
    {"name": "语言表达", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "项目考察", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "技术基础", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "AI/LLM 编程", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "Coding 编码", "score": 1-5, "comment": "结合实例的点评"}
  ],
  "strengths": [{"point": "亮点", "example": "面试中的具体实例"}],
  "weaknesses": [{"point": "不足", "example": "面试中的具体实例"}],
  "improvements": [{"topic": "需加强的知识/技能", "detail": "具体建议", "courseSlugs": ["相关课程slug"]}],
  "recommendedCourses": [{"slug": "课程slug", "reason": "推荐理由"}]
}`}function bt(n){if(!n)throw new Error("评估结果为空");let s=n.trim();const r=s.match(/```(?:json)?\s*([\s\S]*?)```/);r&&(s=r[1].trim());const l=s.indexOf("{"),g=s.lastIndexOf("}");return l>=0&&g>l&&(s=s.slice(l,g+1)),JSON.parse(s)}const S=n=>String(n??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");function ht(n){const s=Math.max(0,Math.min(5,Number(n)||0));return"★".repeat(s)+"☆".repeat(5-s)}function vt(n,s){const r=ge(s.position),l=Y(n.grade),g=new Date,v=`${g.getFullYear()}-${String(g.getMonth()+1).padStart(2,"0")}-${String(g.getDate()).padStart(2,"0")} ${String(g.getHours()).padStart(2,"0")}:${String(g.getMinutes()).padStart(2,"0")}`,u=(n.dimensions||[]).map(c=>`<tr>
        <td class="dim-name">${S(c.name)}</td>
        <td class="dim-score"><span class="stars">${ht(c.score)}</span> <b>${S(c.score)}</b>/5</td>
        <td class="dim-comment">${S(c.comment)}</td>
      </tr>`).join(""),w=(n.strengths||[]).map(c=>`<li><div class="pt good">✔ ${S(c.point)}</div>${c.example?`<div class="ex">实例：${S(c.example)}</div>`:""}</li>`).join(""),I=(n.weaknesses||[]).map(c=>`<li><div class="pt bad">✘ ${S(c.point)}</div>${c.example?`<div class="ex">实例：${S(c.example)}</div>`:""}</li>`).join(""),y=(n.improvements||[]).map(c=>{const x=(c.courseSlugs||[]).map(j=>{const C=$e(j);return C?`<a class="course-link" href="${S(Le(j))}" target="_blank" rel="noopener">📘 ${S(C.meta.title)}</a>`:""}).filter(Boolean).join("");return`<li><div class="imp-topic">${S(c.topic)}</div><div class="imp-detail">${S(c.detail)}</div>${x?`<div class="imp-links">${x}</div>`:""}</li>`}).join(""),p=(n.recommendedCourses||[]).map(c=>{const x=$e(c.slug);return x?`<a class="rec-card" href="${S(Le(c.slug))}" target="_blank" rel="noopener">
        <div class="rec-cover">${S(x.meta.cover||"📘")}</div>
        <div class="rec-body"><div class="rec-title">${S(x.meta.title)}</div><div class="rec-reason">${S(c.reason||x.meta.shortTitle||"")}</div></div>
      </a>`:""}).filter(Boolean).join(""),m=(s.skills||[]).map(S).join("、");return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>面试评估报告 · ${S(r?r.title:"")}</title>
<style>
  :root { --ink:#14171f; --soft:#454c59; --faint:#878e9c; --border:#e6e8ec; --bg:#fff; --sub:#f6f7f9; --accent:#4f46e5; }
  * { box-sizing: border-box; }
  body { margin:0; background:#eef0f4; color:var(--ink); font-family:-apple-system,'Segoe UI','Noto Sans SC',system-ui,sans-serif; line-height:1.7; }
  .sheet { max-width:880px; margin:32px auto; background:var(--bg); border-radius:16px; box-shadow:0 12px 40px rgba(20,23,31,.12); overflow:hidden; }
  .head { padding:34px 40px; background:linear-gradient(120deg,#4f46e5,#7c3aed); color:#fff; }
  .head h1 { margin:0 0 6px; font-size:1.6rem; }
  .head .meta { font-size:.9rem; opacity:.9; }
  .body { padding:32px 40px; }
  .grade-box { display:flex; align-items:center; gap:24px; padding:22px 26px; border-radius:14px; background:var(--sub); border:1px solid var(--border); margin-bottom:28px; }
  .grade-badge { width:92px; height:92px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:3rem; font-weight:800; color:#fff; flex-shrink:0; }
  .grade-info .glabel { font-size:1.2rem; font-weight:700; }
  .grade-info .gdesc { color:var(--soft); font-size:.92rem; margin-top:4px; }
  .grade-info .greason { margin-top:10px; font-size:.92rem; }
  h2 { font-size:1.15rem; margin:30px 0 12px; padding-left:12px; border-left:4px solid var(--accent); }
  .summary { background:var(--sub); border-radius:10px; padding:16px 18px; font-size:.95rem; }
  table { width:100%; border-collapse:collapse; font-size:.92rem; }
  th,td { text-align:left; padding:10px 12px; border-bottom:1px solid var(--border); vertical-align:top; }
  th { background:var(--sub); font-size:.82rem; color:var(--soft); }
  .dim-name { font-weight:700; white-space:nowrap; }
  .dim-score { white-space:nowrap; } .stars { color:#f5a623; letter-spacing:1px; }
  ul.list { list-style:none; padding:0; margin:0; }
  ul.list li { padding:12px 0; border-bottom:1px dashed var(--border); }
  .pt { font-weight:700; } .pt.good { color:#0e835a; } .pt.bad { color:#c0344d; }
  .ex { color:var(--soft); font-size:.9rem; margin-top:4px; padding-left:18px; border-left:2px solid var(--border); }
  .imp-topic { font-weight:700; }
  .imp-detail { color:var(--soft); font-size:.92rem; margin:4px 0; }
  .imp-links, .recs { display:flex; flex-wrap:wrap; gap:8px; margin-top:6px; }
  .course-link { display:inline-block; padding:5px 12px; background:#eef0fe; color:#4338ca; border:1px solid #c7cbf7; border-radius:999px; font-size:.84rem; text-decoration:none; }
  .course-link:hover { background:#4f46e5; color:#fff; }
  .recs { margin-top:12px; }
  .rec-card { display:flex; gap:12px; align-items:center; width:calc(50% - 6px); padding:12px 14px; border:1px solid var(--border); border-radius:12px; text-decoration:none; color:inherit; }
  .rec-card:hover { border-color:var(--accent); box-shadow:0 4px 14px rgba(20,23,31,.08); }
  .rec-cover { font-size:1.8rem; } .rec-title { font-weight:700; font-size:.95rem; } .rec-reason { color:var(--soft); font-size:.84rem; }
  .foot { padding:20px 40px; color:var(--faint); font-size:.82rem; border-top:1px solid var(--border); text-align:center; }
  @media print { body{background:#fff;} .sheet{box-shadow:none; margin:0;} }
  @media (max-width:640px){ .rec-card{width:100%;} .body,.head,.foot{padding-left:20px;padding-right:20px;} }
</style>
</head>
<body>
  <div class="sheet">
    <div class="head">
      <h1>面试评估报告</h1>
      <div class="meta">岗位：${S(r?r.title:s.position)} ｜ 考察技能：${m||"—"} ｜ 生成时间：${S(v)}</div>
    </div>
    <div class="body">
      <div class="grade-box">
        <div class="grade-badge" style="background:${l.color}">${S(n.grade)}</div>
        <div class="grade-info">
          <div class="glabel" style="color:${l.color}">${S(l.label)}</div>
          <div class="gdesc">${S(l.desc)}</div>
          <div class="greason">${S(n.gradeReason)}</div>
        </div>
      </div>

      <h2>整体评价</h2>
      <div class="summary">${S(n.overallSummary)}</div>

      <h2>分维度评估</h2>
      <table><thead><tr><th>维度</th><th>评分</th><th>结合实例的点评</th></tr></thead><tbody>${u}</tbody></table>

      <h2>亮点</h2>
      <ul class="list">${w||"<li>（无）</li>"}</ul>

      <h2>不足</h2>
      <ul class="list">${I||"<li>（无）</li>"}</ul>

      <h2>后续需要加强的知识 / 技能</h2>
      <ul class="list">${y||"<li>（无）</li>"}</ul>

      ${p?`<h2>推荐课程</h2><div class="recs">${p}</div>`:""}
    </div>
    <div class="foot">本报告由「编程学习站 · 面试模拟」基于本次面试问答自动生成，仅供学习参考。</div>
  </div>
</body>
</html>`}function xt(n,s="面试评估报告.html"){const r=new Blob([n],{type:"text/html;charset=utf-8"}),l=URL.createObjectURL(r),g=document.createElement("a");g.href=l,g.download=s,document.body.appendChild(g),g.click(),document.body.removeChild(g),setTimeout(()=>URL.revokeObjectURL(l),2e3)}function yt(n){const s=new Blob([n],{type:"text/html;charset=utf-8"}),r=URL.createObjectURL(s);window.open(r,"_blank"),setTimeout(()=>URL.revokeObjectURL(r),6e4)}function St(){return typeof window<"u"&&!!(window.SpeechRecognition||window.webkitSpeechRecognition)}function J(){return typeof window<"u"&&!!window.speechSynthesis}function wt({lang:n="zh-CN",onResult:s,onError:r,onEnd:l}={}){const g=window.SpeechRecognition||window.webkitSpeechRecognition;if(!g)return null;const v=new g;return v.lang=n,v.continuous=!0,v.interimResults=!0,v.onresult=u=>{let w="",I="";for(let y=u.resultIndex;y<u.results.length;y++){const p=u.results[y];p.isFinal?I+=p[0].transcript:w+=p[0].transcript}I?s&&s(I,!0):w&&s&&s(w,!1)},v.onerror=u=>r&&r(u),v.onend=()=>l&&l(),v}function Me(n){return String(n).split(new RegExp("(?<=[。！？.!?；;\\n])")).map(s=>s.trim()).filter(Boolean)}const jt=[[/\bJVM\b/gi,"J V M"],[/\bJDK\b/gi,"J D K"],[/\bJRE\b/gi,"J R E"],[/\bGC\b/gi,"G C"],[/\bJIT\b/gi,"J I T"],[/\bAOP\b/gi,"A O P"],[/\bIOC\b/gi,"I O C"],[/\bRPC\b/gi,"R P C"],[/\bMQ\b/gi,"M Q"],[/\bSQL\b/gi,"S Q L"],[/\bNIO\b/gi,"N I O"],[/\bBIO\b/gi,"B I O"],[/\bXML\b/gi,"X M L"],[/\bHTTPS\b/gi,"H T T P S"],[/\bHTTP\b/gi,"H T T P"],[/\bTCP\b/gi,"T C P"],[/\bUDP\b/gi,"U D P"],[/\bDNS\b/gi,"D N S"],[/\bCDN\b/gi,"C D N"],[/\bAPI\b/gi,"A P I"],[/\bSDK\b/gi,"S D K"],[/\bCSS\b/gi,"C S S"],[/\bDOM\b/gi,"D O M"],[/\bJWT\b/gi,"J W T"],[/\bORM\b/gi,"O R M"],[/\bMVC\b/gi,"M V C"],[/\bMVVM\b/gi,"M V V M"],[/\bMVCC\b/gi,"M V C C"],[/\bWAL\b/gi,"W A L"],[/\bLRU\b/gi,"L R U"],[/\bLFU\b/gi,"L F U"],[/\bFIFO\b/gi,"fai fo"],[/\bQPS\b/gi,"Q P S"],[/\bTPS\b/gi,"T P S"],[/\bOOM\b/gi,"O O M"],[/\bCPU\b/gi,"C P U"],[/\bGPU\b/gi,"G P U"],[/\bAQS\b/gi,"A Q S"],[/\bCAS\b/gi,"C A S"],[/\bLLM\b/gi,"L L M"],[/\bRAG\b/gi,"拉格"],[/\bSFT\b/gi,"S F T"],[/\bRLHF\b/gi,"R L H F"],[/\bLoRA\b/gi,"楼拉"],[/\bKV\b/gi,"K V"],[/\bHTML\b/gi,"H T M L"],[/\bACID\b/gi,"A C I D"],[/\bCAP\b/gi,"C A P"],[/\bRedis\b/gi,"瑞迪斯"],[/\bMySQL\b/gi,"My S Q L"],[/\bNginx\b/gi,"Engine X"],[/\bKafka\b/gi,"卡夫卡"],[/\bRabbitMQ\b/gi,"Rabbit M Q"],[/\bNetty\b/gi,"奈提"],[/\bZooKeeper\b/gi,"Zoo Keeper"],[/\bElasticSearch\b/gi,"Elastic Search"],[/\bTomcat\b/gi,"汤姆Cat"],[/\bLinux\b/gi,"里纳克斯"],[/\bPython\b/gi,"派森"],[/\bThreadLocal\b/gi,"Thread Local"],[/\bArrayList\b/gi,"Array List"],[/\bHashMap\b/gi,"Hash Map"],[/\bB\+?Tree\b/gi,"B 加 Tree"]];function Nt(n){let s=n;for(const[r,l]of jt)s=s.replace(r,l);return s}function Te(n){return String(n).replace(/```[\s\S]*?```/g,"，").replace(/`([^`]+)`/g,"$1").replace(/\*\*([^*]+)\*\*/g,"$1").replace(/\*([^*]+)\*/g,"$1").replace(/__([^_]+)__/g,"$1").replace(/(^|\s)_([^_]+)_(?=\s|$)/g,"$1$2").replace(/~~([^~]+)~~/g,"$1").replace(/\[([^\]]+)\]\([^)]*\)/g,"$1").replace(/^\s{0,3}#{1,6}\s+/gm,"").replace(/^\s{0,3}>\s?/gm,"").replace(/^\s*[-*+]\s+/gm,"").replace(/[`*_#>~|]/g,"").replace(/[ \t]{2,}/g," ")}const Ct=/(kangkang|yunyang|yunxi|yunjian|yunfeng|liang|male|男)/i,kt=/(xiaoxiao|huihui|yaoyao|mei-?jia|tingting|sin-?ji|xiaoyi|female|女)/i;function Rt(n,s){const r=(n.name||"").toLowerCase();let l=0;return n.lang&&n.lang.toLowerCase().startsWith(s.split("-")[0])&&(l+=10),n.localService===!1&&(l+=5),/google/.test(r)&&(l+=4),/(natural|neural|premium|enhanced|online)/.test(r)&&(l+=4),Ct.test(r)?l+=5:kt.test(r)&&(l-=3),l}function It(){return typeof window>"u"||!window.speechSynthesis?[]:(window.speechSynthesis.getVoices()||[]).filter(n=>n.lang&&n.lang.toLowerCase().startsWith("zh")).map(n=>({name:n.name,voiceURI:n.voiceURI,lang:n.lang,local:n.localService}))}function fe({lang:n="zh-CN",rate:s=1,pitch:r=1}={}){const l=typeof window<"u"?window.speechSynthesis:null;let g=!0,v=[],u=!1,w=null;function I(){if(!l)return null;const p=l.getVoices()||[];if(w){const x=p.find(j=>j.voiceURI===w);if(x)return x}let m=null,c=-1;for(const x of p){const j=Rt(x,n);j>c&&(m=x,c=j)}return c>=10?m:null}function y(){if(!l||u||v.length===0)return;const p=v.shift();if(!p.trim()){y();return}const m=new SpeechSynthesisUtterance(Nt(p));m.lang=n,m.rate=s,m.pitch=r;const c=I();c&&(m.voice=c),m.onend=()=>{u=!1,y()},m.onerror=()=>{u=!1,y()},u=!0,l.speak(m)}return{kind:"browser",speak(p){if(!l||!g||!p)return;const m=Te(p),c=Me(m);v.push(...c.length?c:[m]),y()},stop(){v=[],u=!1,l&&l.cancel()},setEnabled(p){g=p,p||this.stop()},setVoiceURI(p){w=p||null},setRate(p){p&&(s=p)},get enabled(){return g}}}function Ot({synthesize:n,onUnavailable:s}){let r=!0,l=[],g=0,v=!1,u=null,w=null,I=!1,y=!1;async function p(){for(v=!0;g<l.length;){const m=l[g];let c=null;try{c=await m.promise}catch{c=null}if(!r)break;if(c&&c.byteLength){I=!0;const x=URL.createObjectURL(new Blob([c],{type:"audio/mpeg"}));w=x;const j=new Audio(x);u=j,await new Promise(C=>{j.onended=C,j.onerror=C,j.play().catch(()=>C())}),w&&(URL.revokeObjectURL(w),w=null),u=null}else!I&&!y&&(y=!0,s&&s());g++}v=!1}return{kind:"cloud",speak(m){if(!(!r||!m)){for(const c of Me(Te(m))){const x=new AbortController;l.push({promise:n(c,x.signal),ac:x})}v||p()}},stop(){for(const m of l)try{m.ac.abort()}catch{}if(l=[],g=0,v=!1,u){try{u.pause()}catch{}u=null}w&&(URL.revokeObjectURL(w),w=null)},setEnabled(m){r=m,m||this.stop()},setVoiceURI(){},setRate(){},get enabled(){return r}}}function Lt(n){const s=String(Math.floor(n/60)).padStart(2,"0"),r=String(n%60).padStart(2,"0");return`${s}:${r}`}function Tt(){const n=tt(),s=at(),[r,l]=a.useState([]),[g,v]=a.useState(""),[u,w]=a.useState(!1),[I,y]=a.useState(""),[p,m]=a.useState(""),[c,x]=a.useState(0),[j,C]=a.useState(0),[H,E]=a.useState(!1),[M,P]=a.useState(!1),[z,Q]=a.useState(!1),[K,ae]=a.useState("browser"),[O,ie]=a.useState((s==null?void 0:s.voice)!==!1),[G,i]=a.useState("browser"),[b,R]=a.useState([]),[$,T]=a.useState(()=>localStorage.getItem("interview.voiceURI")||""),[B,re]=a.useState(()=>Number(localStorage.getItem("interview.rate"))||1.15),[be,Ae]=a.useState(!1),[h,he]=a.useState(null),[A,_]=a.useState("idle"),[U,Ue]=a.useState(null),[ve,De]=a.useState(""),[Pe,le]=a.useState(""),f=a.useRef(null),V=a.useRef(null),F=a.useRef(""),ee=a.useRef(null),te=a.useRef(null),xe=a.useRef(O),oe=a.useRef($),q=a.useRef(B),ne=a.useRef(null),ce=a.useRef(null),se=a.useRef(""),D=a.useRef(""),W=a.useRef(null),ze=()=>{if(y("云端语音调用失败，已临时回退到浏览器语音（可能不是男声）。请到「面试模拟」设置页点「测试连通性」查看原因，多为 INTERVIEW_TTS_MODEL 不被中转支持，改成 tts-1 即可。"),!J())return;try{f.current&&f.current.stop()}catch{}const t=fe({lang:"zh-CN",rate:q.current});t.setEnabled(xe.current),t.setRate(q.current),oe.current&&t.setVoiceURI(oe.current),f.current=t,i("browser")};a.useEffect(()=>{s||n("/interview",{replace:!0})},[]),a.useEffect(()=>{let t=!1;return it().then(o=>{t||(o!=null&&o.sttConfigured&&ae("cloud"),o!=null&&o.ttsConfigured?(f.current=Ot({synthesize:(d,k)=>dt(d,k,q.current),onUnavailable:ze}),i("cloud")):J()&&(f.current=fe({lang:"zh-CN",rate:q.current}),i("browser")),f.current&&(f.current.setEnabled(O),f.current.setRate(q.current),$&&f.current.setVoiceURI($)))}).catch(()=>{t||J()&&(f.current=fe({lang:"zh-CN"}),f.current.setEnabled(O))}),()=>{t=!0,f.current&&f.current.stop()}},[]),a.useEffect(()=>{var o,d;if(!J())return;const t=()=>R(It());return t(),(d=(o=window.speechSynthesis).addEventListener)==null||d.call(o,"voiceschanged",t),()=>{var k,L;return(L=(k=window.speechSynthesis).removeEventListener)==null?void 0:L.call(k,"voiceschanged",t)}},[]),a.useEffect(()=>{xe.current=O,f.current&&f.current.setEnabled(O)},[O]),a.useEffect(()=>()=>{clearTimeout(W.current);try{V.current&&V.current.stop()}catch{}},[]);const Be=t=>{T(t),oe.current=t,localStorage.setItem("interview.voiceURI",t||""),f.current&&f.current.setVoiceURI(t)},_e=t=>{re(t),q.current=t,localStorage.setItem("interview.rate",String(t)),f.current&&f.current.setRate(t),f.current&&f.current.stop()};a.useEffect(()=>{if(!H)return;const t=setInterval(()=>C(o=>o+1),1e3);return()=>clearInterval(t)},[H]),a.useEffect(()=>{ee.current&&(ee.current.scrollTop=ee.current.scrollHeight)},[r,g]);const Ve=t=>{if(!O||!f.current)return;F.current+=t;const o=F.current,d=o.match(/^[\s\S]*[。！？.!?；;\n]/);d&&(f.current.speak(d[0]),F.current=o.slice(d[0].length))},Fe=()=>{O&&f.current&&F.current.trim()&&f.current.speak(F.current),F.current=""},ye=t=>{const o=ct[t];o!=null&&(x(d=>o>d?o:d),t==="coding"&&de())},Se=async t=>{w(!0),y(""),v(""),F.current="";const o=new AbortController;te.current=o;let d="",k=0,L=!1;try{const N=await Ce({messages:t},et=>{d+=et;const{stage:ue,clean:pe}=ke(d);if(ue&&!L&&(L=!0,ye(ue)),!ue&&/^\s*\[/.test(d)&&!d.includes(`
`)&&d.length<40)return;v(pe);const Ne=pe.slice(k);Ne&&(k=pe.length,Ve(Ne))},o.signal),{stage:X,clean:Ye}=ke(N);X&&!L&&ye(X),Fe(),l([...t,{role:"assistant",content:Ye}]),v("")}catch(N){(N==null?void 0:N.name)!=="AbortError"&&y(String((N==null?void 0:N.message)||N)),v("")}finally{w(!1),te.current=null}},He=async()=>{const t={role:"system",content:lt(s)};E(!0),await Se([t])},Z=async t=>{const o=(t??p).trim();if(!o||u)return;f.current&&f.current.stop(),m("");const d=[...r,{role:"user",content:o}];l(d),await Se(d)},Ke=t=>{var o;if(t.key==="Enter"&&!((o=t.nativeEvent)!=null&&o.isComposing||t.keyCode===229)){if(t.altKey||t.shiftKey){t.preventDefault();const d=t.target,k=d.selectionStart,L=d.selectionEnd,N=p.slice(0,k)+`
`+p.slice(L);m(N),requestAnimationFrame(()=>{d.selectionStart=d.selectionEnd=k+1});return}t.preventDefault(),!u&&p.trim()&&Z()}},qe=async()=>{f.current&&f.current.stop();let t;try{t=await navigator.mediaDevices.getUserMedia({audio:!0})}catch{y("无法访问麦克风，请检查浏览器权限");return}ce.current=t;const o=typeof MediaRecorder<"u"&&MediaRecorder.isTypeSupported("audio/webm")?"audio/webm":typeof MediaRecorder<"u"&&MediaRecorder.isTypeSupported("audio/mp4")?"audio/mp4":"",d=o?new MediaRecorder(t,{mimeType:o}):new MediaRecorder(t),k=[];d.ondataavailable=L=>{L.data&&L.data.size&&k.push(L.data)},d.onstop=async()=>{ce.current&&ce.current.getTracks().forEach(N=>N.stop()),P(!1);const L=new Blob(k,{type:d.mimeType||"audio/webm"});if(L.size){Q(!0);try{const N=await ot(L);N&&m(X=>(X?X+" ":"")+N)}catch(N){y("语音转写失败："+String((N==null?void 0:N.message)||N))}finally{Q(!1)}}},ne.current=d,d.start(),P(!0)},Je=()=>{try{ne.current&&ne.current.state!=="inactive"&&ne.current.stop()}catch{}},Qe=()=>{if(z)return;if(K==="cloud"){M?Je():qe();return}if(!St()){y("当前浏览器不支持语音识别，请用 Chrome / Edge，或直接打字作答");return}if(M){V.current&&V.current.stop();return}f.current&&f.current.stop(),se.current=p?p.trim()+" ":"",D.current="";const t=()=>{clearTimeout(W.current),W.current=setTimeout(()=>{const d=(se.current+D.current).trim();try{V.current&&V.current.stop()}catch{}d&&!u&&Z(d)},2500)},o=wt({lang:"zh-CN",onResult:(d,k)=>{k?(D.current=(D.current?D.current+" ":"")+d,m(se.current+D.current)):m(se.current+(D.current?D.current+" ":"")+d),t()},onError:()=>{clearTimeout(W.current),P(!1)},onEnd:()=>{clearTimeout(W.current),P(!1)}});o&&(V.current=o,o.start(),P(!0))},de=()=>{h||he(Ie()),Ae(!0),x(4)},Ge=async({language:t,source:o})=>{const d=`（编程环节）题目：${h==null?void 0:h.title}
我用 ${t==="java"?"Java":"Python"} 作答，代码如下：

\`\`\`${t}
${o}
\`\`\`

请点评我的思路、时间/空间复杂度和边界处理，并指出可以改进的地方。`;await Z(d)},We=async()=>{await Z("面试官您好，本次面试到这里，麻烦您对我今天的整体表现做一个总结评价：包括优点、不足，以及针对性的提升建议。")},Ze=()=>{te.current&&te.current.abort(),f.current&&f.current.stop()},we=async()=>{if(f.current&&f.current.stop(),r.filter(t=>t.role!=="system").length<2){le("面试内容太少，请先进行面试再生成报告"),_("error");return}_("loading"),le("");try{const t=[...r,{role:"user",content:gt(s)}],o=await Ce({messages:t,maxTokens:4096},()=>{}),d=bt(o),k=vt(d,s);Ue(d),De(k),_("ready")}catch(t){le("生成报告失败："+String((t==null?void 0:t.message)||t)),_("error")}};if(!s)return null;const je=ge(s.position),Xe=r.filter(t=>t.role!=="system");return e.jsx(nt,{children:e.jsxs("div",{className:"container iv-session",children:[e.jsxs("div",{className:"iv-bar",children:[e.jsxs("div",{className:"iv-bar-left",children:[e.jsxs("span",{className:"iv-bar-title",children:["模拟面试 · ",je?je.title:""]}),e.jsxs("span",{className:"iv-timer",children:["⏱ ",Lt(j)]})]}),e.jsxs("div",{className:"iv-bar-right",children:[(G==="cloud"||J())&&e.jsx("button",{className:`iv-pill ${O?"on":""}`,onClick:()=>ie(t=>!t),title:"面试官语音朗读",children:O?"🔊 语音开":"🔇 语音关"}),O&&(G==="cloud"||J())&&e.jsx("select",{className:"iv-voice-select",value:String(B),onChange:t=>_e(Number(t.target.value)),title:"面试官语速",children:[["0.9","0.9x 慢"],["1","1.0x"],["1.15","1.15x"],["1.3","1.3x"],["1.5","1.5x 快"],["1.75","1.75x 很快"]].map(([t,o])=>e.jsxs("option",{value:t,children:["🐢 ",o]},t))}),G==="cloud"?e.jsx("span",{className:"iv-pill on",title:"使用云端神经语音",children:"✨ 自然语音"}):O&&b.length>0&&e.jsxs("select",{className:"iv-voice-select",value:$,onChange:t=>Be(t.target.value),title:"选择语音音色（建议选带 Google/在线/Natural 的更自然）",children:[e.jsx("option",{value:"",children:"默认音色（自动挑最优）"}),b.map(t=>e.jsxs("option",{value:t.voiceURI,children:[t.name,t.local?"（本地）":"（在线）"]},t.voiceURI))]}),e.jsx("button",{className:"btn btn-ghost ce-small",onClick:()=>n("/interview"),children:"退出"})]})]}),e.jsx("div",{className:"iv-stages",children:rt.map((t,o)=>e.jsxs("button",{className:`iv-stage ${o===c?"active":""} ${o<c?"done":""}`,onClick:()=>{x(o),t.id==="coding"&&de()},title:`${t.desc} · 约${t.minutes}分钟`,children:[e.jsx("span",{className:"iv-stage-no",children:o+1}),e.jsx("span",{className:"iv-stage-name",children:t.title}),e.jsxs("span",{className:"iv-stage-min",children:[t.minutes,"min"]})]},t.id))}),e.jsxs("div",{className:`iv-main ${be?"with-code":""}`,children:[e.jsx("div",{className:"iv-chat-col",children:H?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"iv-messages",ref:ee,children:[Xe.map((t,o)=>e.jsxs("div",{className:`iv-msg ${t.role}`,children:[e.jsx("div",{className:"iv-msg-who",children:t.role==="assistant"?"面试官":"我"}),e.jsx("div",{className:"iv-msg-body",children:t.content})]},o)),g&&e.jsxs("div",{className:"iv-msg assistant",children:[e.jsx("div",{className:"iv-msg-who",children:"面试官"}),e.jsxs("div",{className:"iv-msg-body",children:[g,e.jsx("span",{className:"iv-caret",children:"▍"})]})]}),u&&!g&&e.jsxs("div",{className:"iv-msg assistant",children:[e.jsx("div",{className:"iv-msg-who",children:"面试官"}),e.jsx("div",{className:"iv-msg-body iv-thinking",children:"思考中…"})]})]}),I&&e.jsx("div",{className:"iv-error",children:I}),e.jsxs("div",{className:"iv-input-area",children:[e.jsx("textarea",{className:"iv-answer",value:p,onChange:t=>m(t.target.value),onKeyDown:Ke,placeholder:z?"正在转写录音…":M?K==="cloud"?"正在录音，再次点击麦克风停止并转写…":"正在聆听，边说边出字，停顿约 2.5 秒自动发送…":"输入你的回答（Enter 发送，Alt+Enter 换行），或点麦克风语音作答",rows:3,disabled:u||z}),e.jsxs("div",{className:"iv-input-actions",children:[e.jsx("button",{className:`iv-mic ${M?"on":""}`,onClick:Qe,disabled:u||z,title:K==="cloud"?"语音作答（Whisper 识别）":"语音作答",children:z?"转写中…":M?K==="cloud"?"● 停止并转写":"● 停止录音":"🎤 语音"}),e.jsx("span",{className:"iv-kbd-hint",children:"Enter 发送 · Alt+Enter 换行"}),e.jsx("div",{className:"iv-spacer"}),u&&e.jsx("button",{className:"btn btn-ghost ce-small",onClick:Ze,children:"停止"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>Z(),disabled:u||!p.trim(),children:"发送"})]}),e.jsxs("div",{className:"iv-quick",children:[e.jsx("button",{className:"iv-quick-btn",onClick:de,disabled:u,children:"进入编程环节 ⌨️"}),e.jsx("button",{className:"iv-quick-btn",onClick:We,disabled:u,children:"请面试官总结评价"}),e.jsx("button",{className:"iv-quick-btn primary",onClick:we,disabled:u||A==="loading",children:A==="loading"?"正在生成报告…":"结束并生成评分报告 📄"})]})]})]}):e.jsxs("div",{className:"iv-prestart",children:[e.jsx("p",{children:"准备好了吗？点击下方按钮，面试官将先做自我介绍并请你介绍自己。"}),e.jsx("p",{className:"iv-sub",children:"全程约 1 小时，建议在安静环境、用 Chrome/Edge 浏览器以获得最佳语音体验。"}),e.jsx("button",{className:"btn btn-primary iv-start",onClick:He,disabled:u,children:u?"面试官准备中…":"开始面试"})]})}),be&&e.jsxs("div",{className:"iv-code-col",children:[e.jsxs("div",{className:"iv-problem",children:[e.jsxs("div",{className:"iv-problem-head",children:[e.jsxs("h3",{children:[h==null?void 0:h.title," ",e.jsx("span",{className:`iv-diff ${h==null?void 0:h.difficulty}`,children:h==null?void 0:h.difficulty})]}),e.jsx("button",{className:"iv-quick-btn",onClick:()=>he(Ie()),children:"换一题"})]}),e.jsx("div",{className:"iv-problem-tags",children:((h==null?void 0:h.tags)||[]).map(t=>e.jsx("span",{className:"iv-tag",children:t},t))}),e.jsx("pre",{className:"iv-problem-body",children:h==null?void 0:h.statement}),(h==null?void 0:h.sampleInput)!=null&&e.jsxs("div",{className:"iv-sample",children:[e.jsxs("div",{children:[e.jsx("strong",{children:"示例输入"}),e.jsx("pre",{children:h.sampleInput})]}),e.jsxs("div",{children:[e.jsx("strong",{children:"示例输出"}),e.jsx("pre",{children:h.sampleOutput})]})]})]}),e.jsx(pt,{initialLang:"python",onSubmit:Ge},h==null?void 0:h.id)]})]}),(A==="ready"||A==="error"||A==="loading")&&e.jsx("div",{className:"iv-modal-mask",onClick:()=>A!=="loading"&&_("idle"),children:e.jsxs("div",{className:"iv-modal",onClick:t=>t.stopPropagation(),children:[A==="loading"&&e.jsxs("div",{className:"iv-modal-loading",children:[e.jsx("div",{className:"iv-spin"}),e.jsx("p",{children:"面试评估官正在结合本次问答为你打分、撰写报告…"})]}),A==="error"&&e.jsxs("div",{className:"iv-modal-body",children:[e.jsx("h3",{children:"生成失败"}),e.jsx("div",{className:"iv-error",children:Pe}),e.jsxs("div",{className:"iv-modal-actions",children:[e.jsx("button",{className:"btn btn-ghost",onClick:()=>_("idle"),children:"关闭"}),e.jsx("button",{className:"btn btn-primary",onClick:we,children:"重试"})]})]}),A==="ready"&&U&&e.jsxs("div",{className:"iv-modal-body",children:[e.jsxs("div",{className:"iv-report-grade",children:[e.jsx("div",{className:"iv-grade-badge",style:{background:Y(U.grade).color},children:U.grade}),e.jsxs("div",{children:[e.jsx("div",{className:"iv-grade-label",style:{color:Y(U.grade).color},children:Y(U.grade).label}),e.jsx("div",{className:"iv-grade-desc",children:Y(U.grade).desc})]})]}),e.jsx("p",{className:"iv-report-reason",children:U.gradeReason}),e.jsx("p",{className:"iv-report-summary",children:U.overallSummary}),e.jsx("p",{className:"iv-sub",children:"完整报告（含分维度评分、结合实例的亮点与不足、提升建议与课程推荐）可下载或在新窗口查看："}),e.jsxs("div",{className:"iv-modal-actions",children:[e.jsx("button",{className:"btn btn-ghost",onClick:()=>_("idle"),children:"关闭"}),e.jsx("button",{className:"btn btn-ghost",onClick:()=>yt(ve),children:"在新窗口打开"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>xt(ve,`面试评估报告_${U.grade}.html`),children:"下载 HTML 报告"})]})]})]})})]})})}export{Tt as default};
