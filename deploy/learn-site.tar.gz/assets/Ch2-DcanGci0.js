import{r as c,j as e}from"./index-B0-Um9Xw.js";import{L as a,a as o,P as x,C as n,S as h}from"./Summary-CRXglwZ1.js";import{K as j}from"./KeyIdea-zCCzkW7I.js";import{E as l}from"./Example-Djk5fvs9.js";import{F as p}from"./Figure-DKg6w6XJ.js";const u=["短信服务","邮件服务","积分服务","日志服务"];function b(){const[r,t]=c.useState(!1),d=e.jsxs(e.Fragment,{children:[e.jsx("button",{className:"fig-btn",onClick:()=>t(!0),children:"主题发布事件 ▸"}),e.jsx("button",{className:"fig-btn",onClick:()=>t(!1),children:"重置"}),e.jsx("span",{className:"fig-note",children:"一次发布，所有订阅者收到"})]});return e.jsx(p,{caption:"观察者模式(发布-订阅)：被观察的「主题」状态变化时，自动通知所有订阅它的「观察者」。一对多、松耦合——主题不关心有谁订阅。如「下单成功」事件触发发短信/加积分/记日志。",controls:d,children:e.jsxs("svg",{viewBox:"0 0 460 180",width:"460",role:"img","aria-label":"观察者模式",children:[e.jsx("rect",{x:"30",y:"60",width:"110",height:"50",rx:"10",fill:r?"var(--accent)":"var(--accent-soft)",stroke:"var(--accent-strong)"}),e.jsx("text",{x:"85",y:"82",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"11",fontWeight:"700",fill:r?"#ffffff":"var(--ink)",children:"主题 Subject"}),e.jsx("text",{x:"85",y:"98",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:r?"#ffffff":"var(--ink-soft)",children:"订单已支付"}),u.map((s,i)=>e.jsxs("g",{children:[e.jsx("rect",{x:"320",y:16+i*38,width:"120",height:"30",rx:"7",fill:r?"var(--green-soft)":"var(--bg-subtle)",stroke:r?"var(--green)":"var(--border-strong)"}),e.jsxs("text",{x:"380",y:36+i*38,textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"11",fill:r?"var(--green)":"var(--ink-soft)",children:[s,r?" ✓":""]}),e.jsx("line",{x1:"140",y1:"85",x2:"320",y2:31+i*38,stroke:r?"var(--green)":"var(--border-strong)",strokeWidth:r?2:1,strokeDasharray:r?"0":"4 3",markerEnd:"url(#ob-a)"})]},s)),e.jsx("defs",{children:e.jsx("marker",{id:"ob-a",markerWidth:"8",markerHeight:"8",refX:"5",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L5,3 L0,6 Z",fill:r?"var(--green)":"var(--ink-faint)"})})}),r&&e.jsx("text",{x:"180",y:"150",fontFamily:"var(--mono)",fontSize:"10",fill:"var(--green)",children:"notifyObservers() → 逐个回调 update()"}),e.jsx("text",{x:"20",y:"172",fontFamily:"var(--mono)",fontSize:"9",fill:"var(--ink-faint)",children:"Spring 的 ApplicationEvent、MQ 的发布订阅都是这个思想；要新增订阅者，主题代码不用改。"})]})})}const m=`// 观察者接口：所有关心「下单成功」的下游都实现它
public interface OrderListener {
    void onOrderPaid(String orderId);
}

// 具体观察者：各干各的，互不知道对方存在
public class SmsListener implements OrderListener {
    public void onOrderPaid(String orderId) {
        System.out.println("给用户发短信，订单 " + orderId);
    }
}

public class StockListener implements OrderListener {
    public void onOrderPaid(String orderId) {
        System.out.println("通知仓库扣减库存，订单 " + orderId);
    }
}

public class PointListener implements OrderListener {
    public void onOrderPaid(String orderId) {
        System.out.println("给用户增加积分，订单 " + orderId);
    }
}

// 主题（被观察者）：维护观察者列表，状态变化时一对多地通知
public class OrderSubject {

    private final List<OrderListener> listeners = new ArrayList<>();

    public void subscribe(OrderListener listener) {
        listeners.add(listener);
    }

    // 下单成功后调用：挨个通知，主题不关心下游具体是谁
    public void paid(String orderId) {
        for (OrderListener listener : listeners) {
            listener.onOrderPaid(orderId);
        }
    }
}

// 使用：新增一方通知只要 subscribe 一个观察者，paid 方法不用改
public class Demo {
    public static void main(String[] args) {
        OrderSubject subject = new OrderSubject();
        subject.subscribe(new SmsListener());
        subject.subscribe(new StockListener());
        subject.subscribe(new PointListener());
        subject.paid("NO-20260616-001");
    }
}`,f=`// 处理器抽象：持有下一个处理器，每个决定自己处理还是往下传
public abstract class Handler {

    protected Handler next;

    public Handler setNext(Handler next) {
        this.next = next;
        return next;   // 返回 next 便于链式拼装
    }

    public abstract void handle(Request request);

    protected void passToNext(Request request) {
        if (next != null) {
            next.handle(request);
        }
    }
}

// 具体处理器：登录校验
public class AuthHandler extends Handler {
    public void handle(Request request) {
        if (request.getToken() == null) {
            System.out.println("拦截：未登录");
            return;            // 链在这里终止，不再往下传
        }
        System.out.println("登录校验通过");
        passToNext(request);   // 交给链上的下一个
    }
}

// 具体处理器：限流
public class RateLimitHandler extends Handler {
    public void handle(Request request) {
        System.out.println("限流校验通过");
        passToNext(request);
    }
}

// 组装并使用过滤器链
public class Demo {
    public static void main(String[] args) {
        Handler auth = new AuthHandler();
        auth.setNext(new RateLimitHandler());   // auth -> rateLimit
        auth.handle(new Request("token-abc"));
    }
}`;function k(){return e.jsxs(e.Fragment,{children:[e.jsx(a,{children:e.jsxs("p",{children:["上一章用策略模式干掉了 if-else。这一章再打包三个高频行为型模式： 观察者（",e.jsx("em",{children:"Observer"}),"）让「一处变化、多方响应」自动发生； 模板方法（",e.jsx("em",{children:"Template Method"}),"）把「流程固定、步骤可变」固化进父类； 责任链（",e.jsx("em",{children:"Chain of Responsibility"}),"）让请求沿一条处理器链层层流过。 它们在 Spring、JDK、网关里到处都是，面试里也常被串起来考。"]})}),e.jsx("h2",{children:"观察者模式：一处变化，多方响应"}),e.jsxs("p",{children:["观察者模式又叫",e.jsx("em",{children:"发布订阅"}),"，描述的是一对多的依赖：当一个对象（主题、被观察者）的状态发生变化时， 所有依赖它的对象（观察者）都会自动收到通知。主题只持有一份观察者列表，挨个通知， 并不关心下游具体是谁、要做什么——这就是它带来的",e.jsx("strong",{children:"松耦合"}),"。"]}),e.jsxs("p",{children:["最典型的场景就是「下单成功通知多方」：支付完成后，要发短信、扣库存、加积分、推数据…… 如果把这些全写进支付方法，每加一个下游就要改一次核心流程；用观察者后，支付方法只负责 「广播一条已支付事件」，谁关心谁去订阅。Spring 的事件机制（",e.jsx("code",{children:"ApplicationEvent"})," +",e.jsx("code",{children:"ApplicationListener"})," / ",e.jsx("code",{children:"@EventListener"}),"）和各种事件总线，本质都是观察者。"]}),e.jsxs(l,{title:"下单成功通知多方",children:[e.jsx("p",{children:"想象支付完成这一刻：短信服务想发提醒、仓库想扣库存、积分服务想加分。它们彼此并不认识， 只是都「订阅」了同一件事。主题广播一次，三方各自响应："}),e.jsxs("ul",{children:[e.jsx("li",{children:"主题（订单）只喊一句「订单 NO-001 已支付」。"}),e.jsx("li",{children:"短信、库存、积分三个观察者各自被回调，做自己的事。"})]}),e.jsx("p",{children:"以后要再加一个「通知风控」，只需写一个新的观察者并订阅，订单的支付逻辑一行都不用动。"})]}),e.jsx(b,{}),e.jsx(j,{title:"松耦合的代价与好处",children:e.jsxs("p",{children:["观察者的精髓是",e.jsx("strong",{children:"主题不依赖具体观察者"}),"，只依赖统一的观察者接口，因此下游可以随意增删。 但松耦合是把双刃剑：通知链路变成隐式的，「这条事件到底触发了什么」散落在各个订阅者里， 排查时不如直接调用直观。所以用 Spring 事件时，建议给监听器起清晰的名字、留好日志， 让「发布了什么、谁消费了」可追溯。"]})}),e.jsx("h2",{children:"模板方法模式：流程固定，步骤可变"}),e.jsxs("p",{children:["模板方法把一个算法的",e.jsx("strong",{children:"骨架"}),"定义在父类的一个方法里，其中固定不变的步骤直接写死， 会变化的步骤声明成抽象方法交给子类实现；还可以留一些",e.jsx("em",{children:"钩子方法"}),"（hook，有默认空实现）， 子类按需覆盖。这样「整体流程不变、个别步骤定制」的需求就被优雅地表达出来。"]}),e.jsxs("p",{children:["JDK 和框架里全是它的身影：各种 ",e.jsx("code",{children:"AbstractList"}),"、",e.jsx("code",{children:"AbstractMap"})," 等",e.jsx("code",{children:"AbstractXxx"})," 把通用逻辑放在抽象类、留几个抽象方法给子类；",e.jsx("code",{children:"AQS"}),"（AbstractQueuedSynchronizer）定义了加锁/释放的骨架， 把 ",e.jsx("code",{children:"tryAcquire"}),"、",e.jsx("code",{children:"tryRelease"})," 留给 ",e.jsx("code",{children:"ReentrantLock"})," 等子类实现。 你写过的「父类定义 process()，里面调几个 doXxx() 抽象方法」就是模板方法。"]}),e.jsx(o,{variant:"warn",title:"模板方法的两个坑",children:e.jsxs("p",{children:["一是",e.jsx("strong",{children:"骨架方法常应设为 final"}),"，防止子类把整个流程覆盖掉，那就失去了「固定流程」的意义； 二是别把太多步骤都做成抽象方法，否则子类要实现一大堆，复用反而变成负担—— 把真正稳定的留在父类，只把会变的下放给子类。"]})}),e.jsx("h2",{children:"责任链模式：请求沿链层层流过"}),e.jsxs("p",{children:["责任链把多个处理器串成一条链，请求从链头进入，每个处理器决定",e.jsx("strong",{children:"自己处理掉、还是传给下一个"}),"， 发送方不需要知道最终是谁处理的。它最适合「一串校验/拦截/加工要按顺序执行，且每段都可能中断」的场景。 Servlet 的 ",e.jsx("code",{children:"Filter"})," 链、Spring MVC 的拦截器（",e.jsx("code",{children:"HandlerInterceptor"}),"）、 Netty 的 ",e.jsx("code",{children:"pipeline"}),"、各类网关的过滤器，全是责任链。"]}),e.jsxs(l,{title:"过滤器链：一个请求的层层关卡",children:[e.jsx("p",{children:"一个 HTTP 请求进来，要依次过几道关："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"登录校验"}),"：没带 token 直接拦下，链终止。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"限流"}),"：超过阈值就拒绝，否则放行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"日志/鉴权"}),"：记录后继续往后传，直到真正的业务处理器。"]})]}),e.jsx("p",{children:"每道关只管自己那一段，处理完调用「传给下一个」。要插一道新关卡，只需写一个处理器并接进链里， 其余处理器毫不知情——这正是责任链的扩展力。"})]}),e.jsx("h2",{children:"三者意图对比与「面试怎么答」"}),e.jsxs("p",{children:["别把这三个混为一谈，它们意图各异：",e.jsx("strong",{children:"观察者"}),"是「一对多的通知」，强调状态变化后广播；",e.jsx("strong",{children:"模板方法"}),"是「复用流程骨架」，强调固定流程 + 可变步骤；",e.jsx("strong",{children:"责任链"}),"是「请求沿链传递」，强调多个处理器顺序处理且可中断。 面试里若被连问，可以这样收束：观察者解耦的是「发布方与多个订阅方」， 责任链解耦的是「请求与多个处理者」，模板方法解耦的是「不变流程与可变实现」。 每个都配一个框架例子（Spring 事件 / AQS / Servlet Filter），回答立刻有分量。"]}),e.jsxs(x,{title:"任选其一手写：观察者 或 责任链",children:[e.jsxs("p",{children:["先实现观察者：定义观察者接口，写几个具体观察者，再让主题维护列表、状态变化时一对多通知。 重点体会主题完全不依赖具体观察者，新增一方只需 ",e.jsx("code",{children:"subscribe"}),"。"]}),e.jsx(n,{lang:"java",title:"ObserverDemo.java",code:m}),e.jsxs("p",{children:["再挑战责任链：让每个处理器持有 ",e.jsx("code",{children:"next"}),"，自己决定处理或调用",e.jsx("code",{children:"passToNext"})," 往下传，注意中途 ",e.jsx("code",{children:"return"})," 就能让链终止。"]}),e.jsx(n,{lang:"java",title:"ChainDemo.java",code:f})]}),e.jsx(h,{points:["观察者：发布订阅、一对多，主题状态变化时通知所有观察者，主题不依赖具体观察者，实现松耦合，如 Spring 的 ApplicationEvent 与事件总线。","模板方法：父类定义算法骨架（常设 final），可变步骤做成抽象方法、可选步骤做成钩子方法交给子类，如 AQS 与各种 AbstractXxx。","责任链：请求沿处理器链传递，每个处理器决定自己处理或传给下一个，可中途中断，如 Servlet Filter、拦截器、Netty pipeline、网关。","三者意图不同：观察者是一对多通知，模板方法是复用流程骨架，责任链是请求顺序流过。","它们都通过面向接口/抽象编程来降低耦合，让新增下游、新增关卡、新增子类时主流程不改。","面试时各配一个框架例子（Spring 事件 / AQS / Servlet Filter），并点清各自解耦的是谁与谁。"]})]})}export{k as default};
