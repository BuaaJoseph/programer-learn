import{r as i,j as e,C as Qe,u as He,P as Je}from"./index-D-xLQIFq.js";import{r as Ge,g as We,a as Ze,c as Xe,t as Ye,s as et}from"./api-D_l1pztv.js";import{f as Ne,l as tt,S as nt,b as st,p as xe,a as it}from"./session-C6pSx66Y.js";const Se=[{id:"two-sum-ii",title:"两数之和 II（有序数组）",difficulty:"中等",tags:["数组","双指针"],statement:`给定一个已按升序排列的整数数组 numbers 和目标值 target，请找出两个数使它们相加之和等于 target，返回这两个数的下标（从 1 开始），要求空间复杂度 O(1)。

输入：第一行为目标值 target，第二行为以空格分隔的有序数组。
输出：两个下标，空格分隔。`,sampleInput:`9
2 7 11 15`,sampleOutput:"1 2"},{id:"longest-substring",title:"无重复字符的最长子串",difficulty:"中等",tags:["滑动窗口","哈希"],statement:`给定一个字符串 s，找出其中不含重复字符的最长子串的长度。

输入：一行字符串 s。
输出：最长无重复子串的长度。`,sampleInput:"abcabcbb",sampleOutput:"3"},{id:"add-two-numbers",title:"两个大数相加（字符串）",difficulty:"中等",tags:["字符串","模拟"],statement:`给定两个用字符串表示的非负大整数 a、b（可能超过 long 范围），返回它们之和（字符串）。

输入：两行，分别为 a 和 b。
输出：a + b。`,sampleInput:`99999999999999999999
1`,sampleOutput:"100000000000000000000"},{id:"lru-cache",title:"LRU 缓存机制",difficulty:"中等",tags:["设计","哈希","双向链表"],statement:`设计并实现一个 LRU（最近最少使用）缓存，支持 get 和 put，容量满时淘汰最久未使用的项，均要求 O(1)。

输入：第一行为容量 cap 与操作数 n；接下来 n 行，每行形如 "put 1 1" 或 "get 1"。
输出：每个 get 操作的返回值（未命中输出 -1），空格分隔在一行。`,sampleInput:`2 5
put 1 1
put 2 2
get 1
put 3 3
get 2`,sampleOutput:"1 -1"},{id:"longest-palindrome",title:"最长回文子串",difficulty:"中等",tags:["字符串","动态规划"],statement:`给定字符串 s，返回它的最长回文子串。

输入：一行字符串 s。
输出：最长回文子串（若有多个，输出任意一个）。`,sampleInput:"babad",sampleOutput:"bab"},{id:"three-sum",title:"三数之和",difficulty:"中等",tags:["数组","双指针"],statement:`给定数组 nums，找出所有和为 0 且不重复的三元组，按升序输出。

输入：一行以空格分隔的整数数组。
输出：每行一个三元组（升序、空格分隔）；无解输出空。`,sampleInput:"-1 0 1 2 -1 -4",sampleOutput:`-1 -1 2
-1 0 1`},{id:"container-water",title:"盛最多水的容器",difficulty:"中等",tags:["双指针","贪心"],statement:`给定 n 个非负整数表示柱子高度，找出两条柱子使其与 x 轴构成的容器能盛最多的水，输出最大面积。

输入：一行以空格分隔的高度数组。
输出：最大面积。`,sampleInput:"1 8 6 2 5 4 8 3 7",sampleOutput:"49"},{id:"coin-change",title:"零钱兑换",difficulty:"中等",tags:["动态规划"],statement:`给定硬币面额数组 coins 和总金额 amount，求凑成总金额所需最少硬币数；无法凑成输出 -1。

输入：第一行 amount；第二行硬币面额（空格分隔）。
输出：最少硬币数。`,sampleInput:`11
1 2 5`,sampleOutput:"3"},{id:"word-break",title:"单词拆分",difficulty:"中等",tags:["动态规划","字符串"],statement:`给定字符串 s 和单词字典 wordDict，判断 s 是否能被空格拆分成字典中的单词序列。

输入：第一行 s；第二行字典单词（空格分隔）。
输出：true 或 false。`,sampleInput:`leetcode
leet code`,sampleOutput:"true"},{id:"num-islands",title:"岛屿数量",difficulty:"中等",tags:["DFS","BFS","并查集"],statement:`给定由 '1'（陆地）和 '0'（水）组成的二维网格，计算岛屿数量。岛屿由相邻（上下左右）陆地连接。

输入：第一行 m n；接下来 m 行，每行 n 个 0/1（空格分隔）。
输出：岛屿数量。`,sampleInput:`3 3
1 1 0
0 1 0
0 0 1`,sampleOutput:"2"},{id:"course-schedule",title:"课程表（拓扑排序）",difficulty:"中等",tags:["图","拓扑排序"],statement:`共有 numCourses 门课，先修关系给定为 [a, b]（学 a 前必须先学 b）。判断能否完成所有课程。

输入：第一行 numCourses 与边数 m；接下来 m 行每行两个数 a b。
输出：true 或 false。`,sampleInput:`2 1
1 0`,sampleOutput:"true"},{id:"kth-largest",title:"数组中的第 K 个最大元素",difficulty:"中等",tags:["堆","快速选择"],statement:`在未排序数组中找到第 k 个最大的元素。

输入：第一行 k；第二行数组（空格分隔）。
输出：第 k 大的元素。`,sampleInput:`2
3 2 1 5 6 4`,sampleOutput:"5"},{id:"merge-intervals",title:"合并区间",difficulty:"中等",tags:["排序","区间"],statement:`给定若干区间，合并所有重叠区间。

输入：第一行区间数 n；接下来 n 行每行两个数 start end。
输出：合并后的区间，每行两个数（按起点升序）。`,sampleInput:`4
1 3
2 6
8 10
15 18`,sampleOutput:`1 6
8 10
15 18`},{id:"rotate-image",title:"旋转图像",difficulty:"中等",tags:["数组","矩阵"],statement:`给定 n×n 矩阵，将其原地顺时针旋转 90 度。

输入：第一行 n；接下来 n 行每行 n 个数。
输出：旋转后的矩阵。`,sampleInput:`3
1 2 3
4 5 6
7 8 9`,sampleOutput:`7 4 1
8 5 2
9 6 3`},{id:"subsets",title:"子集",difficulty:"中等",tags:["回溯","位运算"],statement:`给定一个不含重复元素的整数数组 nums，返回其所有可能的子集（幂集）。

输入：一行数组（空格分隔）。
输出：每行一个子集（空格分隔，含空行表示空集），顺序不限。`,sampleInput:"1 2 3",sampleOutput:`
1
2
1 2
3
1 3
2 3
1 2 3`},{id:"permutations",title:"全排列",difficulty:"中等",tags:["回溯"],statement:`给定不含重复数字的数组 nums，返回其所有全排列。

输入：一行数组（空格分隔）。
输出：每行一个排列（空格分隔），顺序不限。`,sampleInput:"1 2 3",sampleOutput:`1 2 3
1 3 2
2 1 3
2 3 1
3 1 2
3 2 1`},{id:"search-rotated",title:"搜索旋转排序数组",difficulty:"中等",tags:["二分查找"],statement:`整数数组 nums 升序排列后在某个未知点旋转，给定 target，存在则返回下标，否则返回 -1，要求 O(log n)。

输入：第一行 target；第二行数组。
输出：下标或 -1。`,sampleInput:`0
4 5 6 7 0 1 2`,sampleOutput:"4"},{id:"product-except-self",title:"除自身以外数组的乘积",difficulty:"中等",tags:["数组","前缀积"],statement:`给定数组 nums，返回数组 answer，其中 answer[i] 等于 nums 中除 nums[i] 之外其余元素的乘积，不能使用除法，O(n)。

输入：一行数组。
输出：结果数组（空格分隔）。`,sampleInput:"1 2 3 4",sampleOutput:"24 12 8 6"},{id:"daily-temperatures",title:"每日温度（单调栈）",difficulty:"中等",tags:["单调栈"],statement:`给定每日温度数组，返回数组 answer，answer[i] 表示第 i 天之后要等多少天才会有更高温度；若不存在则为 0。

输入：一行温度数组。
输出：结果数组（空格分隔）。`,sampleInput:"73 74 75 71 69 72 76 73",sampleOutput:"1 1 4 2 1 1 0 0"},{id:"min-path-sum",title:"最小路径和",difficulty:"中等",tags:["动态规划","矩阵"],statement:`给定 m×n 非负网格，从左上走到右下，每次只能向右或向下，求路径上数字和的最小值。

输入：第一行 m n；接下来 m 行每行 n 个数。
输出：最小路径和。`,sampleInput:`3 3
1 3 1
1 5 1
4 2 1`,sampleOutput:"7"},{id:"unique-paths",title:"不同路径",difficulty:"中等",tags:["动态规划","组合数学"],statement:`m×n 网格，机器人从左上到右下，每次只能向右或向下，求不同路径总数。

输入：一行 m n。
输出：路径数。`,sampleInput:"3 7",sampleOutput:"28"},{id:"max-subarray",title:"最大子数组和",difficulty:"中等",tags:["动态规划","分治"],statement:`给定整数数组 nums，找到具有最大和的连续子数组，返回其和。

输入：一行数组。
输出：最大子数组和。`,sampleInput:"-2 1 -3 4 -1 2 1 -5 4",sampleOutput:"6"},{id:"group-anagrams",title:"字母异位词分组",difficulty:"中等",tags:["哈希","字符串"],statement:`给定字符串数组，把字母异位词组合在一起。

输入：一行若干单词（空格分隔）。
输出：每行一组异位词（空格分隔），组内与组间顺序不限。`,sampleInput:"eat tea tan ate nat bat",sampleOutput:`eat tea ate
tan nat
bat`},{id:"spiral-matrix",title:"螺旋矩阵",difficulty:"中等",tags:["矩阵","模拟"],statement:`给定 m×n 矩阵，按顺时针螺旋顺序返回所有元素。

输入：第一行 m n；接下来 m 行每行 n 个数。
输出：螺旋顺序的所有元素（空格分隔，一行）。`,sampleInput:`3 3
1 2 3
4 5 6
7 8 9`,sampleOutput:"1 2 3 6 9 8 7 4 5"},{id:"jump-game",title:"跳跃游戏",difficulty:"中等",tags:["贪心"],statement:`给定非负整数数组 nums，初始位于下标 0，每个元素代表在该位置可跳跃的最大长度，判断能否到达最后一个下标。

输入：一行数组。
输出：true 或 false。`,sampleInput:"2 3 1 1 4",sampleOutput:"true"},{id:"longest-consecutive",title:"最长连续序列",difficulty:"中等",tags:["哈希","并查集"],statement:`给定未排序数组 nums，找出数字连续的最长序列长度，要求 O(n)。

输入：一行数组。
输出：最长连续序列长度。`,sampleInput:"100 4 200 1 3 2",sampleOutput:"4"},{id:"top-k-frequent",title:"前 K 个高频元素",difficulty:"中等",tags:["堆","哈希"],statement:`给定整数数组 nums 和整数 k，返回出现频率前 k 高的元素（按频率从高到低）。

输入：第一行 k；第二行数组。
输出：前 k 个高频元素（空格分隔）。`,sampleInput:`2
1 1 1 2 2 3`,sampleOutput:"1 2"},{id:"decode-ways",title:"解码方法",difficulty:"中等",tags:["动态规划","字符串"],statement:`数字到字母的映射为 '1'->A ... '26'->Z。给定只含数字的字符串 s，计算它有多少种解码方法。

输入：一行数字字符串 s。
输出：解码方法数。`,sampleInput:"226",sampleOutput:"3"},{id:"validate-bst",title:"验证二叉搜索树",difficulty:"中等",tags:["树","DFS"],statement:`给定二叉树的层序遍历（null 表示空节点），判断它是否是有效的二叉搜索树。

输入：一行层序遍历，节点值或 null，空格分隔。
输出：true 或 false。`,sampleInput:"5 1 4 null null 3 6",sampleOutput:"false"},{id:"gas-station",title:"加油站",difficulty:"中等",tags:["贪心"],statement:`环路上有 n 个加油站，gas[i] 为可加油量，cost[i] 为到下一站的耗油。从某站出发绕一圈，返回可行的起始站下标，无解返回 -1。

输入：第一行 gas 数组；第二行 cost 数组。
输出：起始站下标或 -1。`,sampleInput:`1 2 3 4 5
3 4 5 1 2`,sampleOutput:"3"},{id:"partition-equal",title:"分割等和子集",difficulty:"中等",tags:["动态规划","背包"],statement:`给定只含正整数的非空数组 nums，判断能否将其分割成两个和相等的子集。

输入：一行数组。
输出：true 或 false。`,sampleInput:"1 5 11 5",sampleOutput:"true"},{id:"house-robber-ii",title:"打家劫舍 II（环形）",difficulty:"中等",tags:["动态规划"],statement:`房屋围成一圈，相邻两间不能同时偷。给定每间金额数组 nums，求能偷到的最高金额。

输入：一行数组。
输出：最高金额。`,sampleInput:"2 3 2",sampleOutput:"3"},{id:"find-duplicate",title:"寻找重复数",difficulty:"中等",tags:["双指针","快慢指针"],statement:`给定 n+1 个整数的数组 nums，数字都在 [1, n] 内，存在且仅存在一个重复数，找出它（不修改数组、O(1) 空间）。

输入：一行数组。
输出：重复的数字。`,sampleInput:"1 3 4 2 2",sampleOutput:"2"},{id:"min-window",title:"最小覆盖子串",difficulty:"困难",tags:["滑动窗口","哈希"],statement:`给定字符串 s 和 t，返回 s 中涵盖 t 所有字符的最小子串；不存在则返回空串。

输入：第一行 s；第二行 t。
输出：最小覆盖子串。`,sampleInput:`ADOBECODEBANC
ABC`,sampleOutput:"BANC"},{id:"trapping-rain",title:"接雨水",difficulty:"困难",tags:["双指针","单调栈"],statement:`给定 n 个非负整数表示柱子高度图，计算下雨后能接多少雨水。

输入：一行高度数组。
输出：能接的雨水总量。`,sampleInput:"0 1 0 2 1 0 1 3 2 1 2 1",sampleOutput:"6"},{id:"edit-distance",title:"编辑距离",difficulty:"困难",tags:["动态规划"],statement:`给定两个单词 word1 和 word2，返回将 word1 转换成 word2 所使用的最少操作数（插入/删除/替换）。

输入：两行，分别为 word1 和 word2。
输出：最少操作数。`,sampleInput:`horse
ros`,sampleOutput:"3"},{id:"lis",title:"最长递增子序列",difficulty:"中等",tags:["动态规划","二分"],statement:`给定整数数组 nums，找到其中最长严格递增子序列的长度。

输入：一行数组。
输出：最长递增子序列长度。`,sampleInput:"10 9 2 5 3 7 101 18",sampleOutput:"4"}],de={python:`import sys

def solve(data):
    # data 是按行切分的输入列表；在这里实现你的逻辑并 print 结果
    pass

def main():
    data = sys.stdin.read().split('\\n')
    solve(data)

if __name__ == '__main__':
    main()
`,java:`import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // 在这里读取输入、实现逻辑并 System.out.println 输出结果
        // String line = br.readLine();
    }
}
`};function we(){const a=Math.floor(Math.random()*Se.length);return Se[a]}const at={python:["print(","input(","len(","range(","int(","str(","float(","list(","dict(","set(","tuple(","sorted(","reversed(","enumerate(","zip(","map(","filter(","sum(","min(","max(","abs(","round(","any(","all(","isinstance(","append(","extend(","insert(","pop(","remove(","sort(","split(","join(","strip(","replace(","startswith(","endswith(","find(","format(","keys(","values(","items(","get(","setdefault(","def ","class ","return ","import ","from ","for ","while ","if ","elif ","else:","try:","except ","finally:","with ","lambda ","yield ","global ","collections","defaultdict(","Counter(","deque(","heapq","heappush(","heappop(","heapify(","bisect","bisect_left(","bisect_right(","itertools","functools","lru_cache","math","sys.stdin","sys.stdin.read("],java:["public ","private ","protected ","static ","final ","void ","class ","interface ","extends ","implements ","return ","new ","import ","package ","if ","else ","for ","while ","switch ","case ","break;","continue;","try ","catch ","finally ","throw ","throws ","int ","long ","double ","float ","boolean ","char ","byte ","short ","String ","Integer","Long","Double","Boolean","Character","Math.","System.out.println(","System.out.print(","System.out.printf(","List<","ArrayList<","LinkedList<","Map<","HashMap<","TreeMap<","Set<","HashSet<","TreeSet<","Queue<","Deque<","ArrayDeque<","PriorityQueue<","Stack<","Collections.","Arrays.","Arrays.sort(","Arrays.asList(","StringBuilder","append(","toString()","length()","size()","add(","get(","put(","getOrDefault(","containsKey(","contains(","remove(","poll(","offer(","peek(","push(","pop(","BufferedReader","InputStreamReader","readLine()","split(","Integer.parseInt(","Long.parseLong(","String.valueOf(","Math.max(","Math.min(","Math.abs("]};function je(a,r){const c=a.slice(0,r).match(/[A-Za-z_.][A-Za-z0-9_.]*$/);return c?c[0]:""}function rt({initialLang:a="python",onSubmit:r}){const[o,c]=i.useState(a),[S,h]=i.useState({python:de.python,java:de.java}),[d,x]=i.useState(""),[O,v]=i.useState(""),[p,m]=i.useState(!1),[b,w]=i.useState(!1),[j,k]=i.useState({open:!1,items:[],index:0}),F=i.useRef(null),L=S[o],M=s=>h(f=>({...f,[o]:s})),D=i.useMemo(()=>at[o]||[],[o]),U=(s,f)=>{const N=je(s,f);if(N.length<1){k({open:!1,items:[],index:0});return}const E=N.toLowerCase(),T=D.filter($=>$.toLowerCase().startsWith(E)&&$.toLowerCase()!==E).slice(0,8);k(T.length?{open:!0,items:T,index:0}:{open:!1,items:[],index:0})},Q=s=>{const f=F.current;if(!f)return;const N=f.selectionStart,E=je(L,N),T=N-E.length,$=L.slice(0,T)+s+L.slice(N);M($);const ie=T+s.length;k({open:!1,items:[],index:0}),requestAnimationFrame(()=>{f.focus(),f.selectionStart=f.selectionEnd=ie})},K=s=>{M(s.target.value),U(s.target.value,s.target.selectionStart)},ne=s=>{if(j.open){if(s.key==="ArrowDown"){s.preventDefault(),k(f=>({...f,index:(f.index+1)%f.items.length}));return}if(s.key==="ArrowUp"){s.preventDefault(),k(f=>({...f,index:(f.index-1+f.items.length)%f.items.length}));return}if(s.key==="Enter"||s.key==="Tab"){s.preventDefault(),Q(j.items[j.index]);return}if(s.key==="Escape"){k({open:!1,items:[],index:0});return}}if(s.key==="Tab"){s.preventDefault();const f=s.target,N=f.selectionStart,E=f.selectionEnd,T=L.slice(0,N)+"    "+L.slice(E);M(T),requestAnimationFrame(()=>{f.selectionStart=f.selectionEnd=N+4})}s.key==="Enter"&&(s.ctrlKey||s.metaKey)&&(s.preventDefault(),b||C())},C=async()=>{w(!0),m(!1),v("正在执行…");try{const s=await Ge({language:o,source:L,stdin:d}),f=s.output||s.stdout||"",N=s.stderr||"",E=[f,N].filter(Boolean).join(`
`);m(!!N&&!f),v(E||"（没有任何输出）")}catch(s){m(!0),v(String((s==null?void 0:s.message)||s))}finally{w(!1)}},se=()=>M(de[o]),H=Math.max(14,L.split(`
`).length+1);return e.jsxs("div",{className:"code-editor",children:[e.jsxs("div",{className:"ce-tabs",children:[["python","java"].map(s=>e.jsx("button",{className:`ce-tab ${s===o?"active":""}`,onClick:()=>{c(s),k({open:!1,items:[],index:0})},children:s==="python"?"Python":"Java"},s)),e.jsxs("div",{className:"ce-tab-actions",children:[e.jsx("button",{className:"btn btn-ghost ce-small",onClick:se,disabled:b,children:"重置模板"}),e.jsx("button",{className:"btn btn-primary ce-small",onClick:C,disabled:b,children:b?"执行中…":"▶ 运行"})]})]}),e.jsxs("div",{className:"ce-editor-wrap",children:[e.jsx("textarea",{ref:F,className:"ce-textarea",value:L,onChange:K,onKeyDown:ne,onBlur:()=>setTimeout(()=>k({open:!1,items:[],index:0}),120),spellCheck:!1,rows:H,"aria-label":"代码编辑器"}),j.open&&e.jsx("ul",{className:"ce-suggest",children:j.items.map((s,f)=>e.jsx("li",{className:f===j.index?"active":"",onMouseDown:N=>{N.preventDefault(),Q(s)},children:s},s))})]}),e.jsxs("div",{className:"ce-io",children:[e.jsxs("div",{className:"ce-io-col",children:[e.jsx("label",{className:"ce-label",children:"标准输入（stdin，可留空）"}),e.jsx("textarea",{className:"ce-stdin",value:d,onChange:s=>x(s.target.value),spellCheck:!1,rows:4,placeholder:"把样例输入粘到这里，运行时会作为程序的标准输入"})]}),e.jsxs("div",{className:"ce-io-col",children:[e.jsx("label",{className:"ce-label",children:"运行结果"}),e.jsx("pre",{className:`ce-output${p?" is-error":""}`,children:O||"（点击「运行」查看输出）"})]})]}),e.jsxs("div",{className:"ce-bottom",children:[e.jsx("span",{className:"ce-hint",children:"提示：输入时会出现基础库联想（↑↓ 选择，Enter/Tab 补全）；Ctrl/⌘ + Enter 运行。"}),r&&e.jsx("button",{className:"btn btn-primary",onClick:()=>r({language:o,source:L}),children:"提交给面试官点评"})]})]})}function Ce(){return Qe.map(a=>({slug:a.meta.slug,title:a.meta.title,desc:a.meta.shortTitle||a.meta.subtitle||"",cat:`${a.meta.categoryId}/${a.meta.subCategoryId||""}`}))}function lt(a){const r=Ne(a.position),o=Ce().map(c=>`${c.slug} | ${c.title}`).join(`
`);return`面试到此结束。现在请你切换为「面试评估官」，基于上面完整的面试对话记录，对这位「${r?r.title:a.position}」候选人做一次严谨、客观的综合评估打分。

# 评分等级（必须从中选一个）
- A：非常满意。语言表达、项目考察、技术技能和 Coding 都基本做到完美，正是公司需要的人才（极难获得）。
- B：优秀人才。在 A 的基础上个别方面有差距，但仍优秀，会强烈推荐给后续面试官。
- C：通过面试。项目考察、技术基础都比较扎实，可继续推进；没有特别亮眼或打动面试官的表现一般定为此级。
- D：未通过，但可推荐其他岗位。综合评估有所欠缺，本岗位不再推进，其他岗位可继续面试。
- E：完全不可行。一个或多个方面表现很差（如项目说不清、追问细节或基础知识基本不了解），短期内不建议推进其他岗位。

# 评估要求
1. 必须「结合面试中的具体问答实例」给出理由，好的与不足的地方都要引用候选人实际说过的话或表现，不能空口无凭。
2. 分维度评估：语言表达、项目考察、技术基础、AI/LLM 编程、Coding 编码。每个维度给 1-5 分并附结合实例的点评。
3. 给出后续需要加强的知识/技能清单，并尽量从下面的「本站课程清单」中挑选相关课程推荐（用 slug）。

# 本站课程清单（slug | 课程名）
${o}

# 输出格式（务必只输出一个 JSON，不要任何额外文字或 markdown 代码块标记）
{
  "grade": "A|B|C|D|E",
  "gradeReason": "为什么定这个等级（结合整体表现，2-4句）",
  "overallSummary": "整体评价（150字左右）",
  "dimensions": [
    {"name": "语言表达", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "项目考察", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "技术基础", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "AI/LLM 编程", "score": 1-5, "comment": "结合实例的点评"},
    {"name": "Coding 编码", "score": 1-5, "comment": "结合实例的点评"}
  ],
  "strengths": [{"point": "亮点", "example": "面试中的具体实例"}],
  "weaknesses": [{"point": "不足", "example": "面试中的具体实例"}],
  "improvements": [{"topic": "需加强的知识/技能", "detail": "具体建议", "courseSlugs": ["相关课程slug"]}],
  "recommendedCourses": [{"slug": "课程slug", "reason": "推荐理由"}]
}`}function ct(){return typeof window<"u"&&!!(window.SpeechRecognition||window.webkitSpeechRecognition)}function q(){return typeof window<"u"&&!!window.speechSynthesis}function ot({lang:a="zh-CN",onResult:r,onError:o,onEnd:c}={}){const S=window.SpeechRecognition||window.webkitSpeechRecognition;if(!S)return null;const h=new S;return h.lang=a,h.continuous=!0,h.interimResults=!0,h.onresult=d=>{let x="",O="";for(let v=d.resultIndex;v<d.results.length;v++){const p=d.results[v];p.isFinal?O+=p[0].transcript:x+=p[0].transcript}O?r&&r(O,!0):x&&r&&r(x,!1)},h.onerror=d=>o&&o(d),h.onend=()=>c&&c(),h}function Ie(a){return String(a).split(new RegExp("(?<=[。！？.!?；;\\n])")).map(r=>r.trim()).filter(Boolean)}const ut=[[/\bJVM\b/gi,"J V M"],[/\bJDK\b/gi,"J D K"],[/\bJRE\b/gi,"J R E"],[/\bGC\b/gi,"G C"],[/\bJIT\b/gi,"J I T"],[/\bAOP\b/gi,"A O P"],[/\bIOC\b/gi,"I O C"],[/\bRPC\b/gi,"R P C"],[/\bMQ\b/gi,"M Q"],[/\bSQL\b/gi,"S Q L"],[/\bNIO\b/gi,"N I O"],[/\bBIO\b/gi,"B I O"],[/\bXML\b/gi,"X M L"],[/\bHTTPS\b/gi,"H T T P S"],[/\bHTTP\b/gi,"H T T P"],[/\bTCP\b/gi,"T C P"],[/\bUDP\b/gi,"U D P"],[/\bDNS\b/gi,"D N S"],[/\bCDN\b/gi,"C D N"],[/\bAPI\b/gi,"A P I"],[/\bSDK\b/gi,"S D K"],[/\bCSS\b/gi,"C S S"],[/\bDOM\b/gi,"D O M"],[/\bJWT\b/gi,"J W T"],[/\bORM\b/gi,"O R M"],[/\bMVC\b/gi,"M V C"],[/\bMVVM\b/gi,"M V V M"],[/\bMVCC\b/gi,"M V C C"],[/\bWAL\b/gi,"W A L"],[/\bLRU\b/gi,"L R U"],[/\bLFU\b/gi,"L F U"],[/\bFIFO\b/gi,"fai fo"],[/\bQPS\b/gi,"Q P S"],[/\bTPS\b/gi,"T P S"],[/\bOOM\b/gi,"O O M"],[/\bCPU\b/gi,"C P U"],[/\bGPU\b/gi,"G P U"],[/\bAQS\b/gi,"A Q S"],[/\bCAS\b/gi,"C A S"],[/\bLLM\b/gi,"L L M"],[/\bRAG\b/gi,"拉格"],[/\bSFT\b/gi,"S F T"],[/\bRLHF\b/gi,"R L H F"],[/\bLoRA\b/gi,"楼拉"],[/\bKV\b/gi,"K V"],[/\bHTML\b/gi,"H T M L"],[/\bACID\b/gi,"A C I D"],[/\bCAP\b/gi,"C A P"],[/\bRedis\b/gi,"瑞迪斯"],[/\bMySQL\b/gi,"My S Q L"],[/\bNginx\b/gi,"Engine X"],[/\bKafka\b/gi,"卡夫卡"],[/\bRabbitMQ\b/gi,"Rabbit M Q"],[/\bNetty\b/gi,"奈提"],[/\bZooKeeper\b/gi,"Zoo Keeper"],[/\bElasticSearch\b/gi,"Elastic Search"],[/\bTomcat\b/gi,"汤姆Cat"],[/\bLinux\b/gi,"里纳克斯"],[/\bPython\b/gi,"派森"],[/\bThreadLocal\b/gi,"Thread Local"],[/\bArrayList\b/gi,"Array List"],[/\bHashMap\b/gi,"Hash Map"],[/\bB\+?Tree\b/gi,"B 加 Tree"]];function dt(a){let r=a;for(const[o,c]of ut)r=r.replace(o,c);return r}function Re(a){return String(a).replace(/```[\s\S]*?```/g,"，").replace(/`([^`]+)`/g,"$1").replace(/\*\*([^*]+)\*\*/g,"$1").replace(/\*([^*]+)\*/g,"$1").replace(/__([^_]+)__/g,"$1").replace(/(^|\s)_([^_]+)_(?=\s|$)/g,"$1$2").replace(/~~([^~]+)~~/g,"$1").replace(/\[([^\]]+)\]\([^)]*\)/g,"$1").replace(/^\s{0,3}#{1,6}\s+/gm,"").replace(/^\s{0,3}>\s?/gm,"").replace(/^\s*[-*+]\s+/gm,"").replace(/[`*_#>~|]/g,"").replace(/[ \t]{2,}/g," ")}const mt=/(kangkang|yunyang|yunxi|yunjian|yunfeng|liang|male|男)/i,pt=/(xiaoxiao|huihui|yaoyao|mei-?jia|tingting|sin-?ji|xiaoyi|female|女)/i;function ft(a,r){const o=(a.name||"").toLowerCase();let c=0;return a.lang&&a.lang.toLowerCase().startsWith(r.split("-")[0])&&(c+=10),a.localService===!1&&(c+=5),/google/.test(o)&&(c+=4),/(natural|neural|premium|enhanced|online)/.test(o)&&(c+=4),mt.test(o)?c+=5:pt.test(o)&&(c-=3),c}function gt(){return typeof window>"u"||!window.speechSynthesis?[]:(window.speechSynthesis.getVoices()||[]).filter(a=>a.lang&&a.lang.toLowerCase().startsWith("zh")).map(a=>({name:a.name,voiceURI:a.voiceURI,lang:a.lang,local:a.localService}))}function me({lang:a="zh-CN",rate:r=1,pitch:o=1}={}){const c=typeof window<"u"?window.speechSynthesis:null;let S=!0,h=[],d=!1,x=null;function O(){if(!c)return null;const p=c.getVoices()||[];if(x){const w=p.find(j=>j.voiceURI===x);if(w)return w}let m=null,b=-1;for(const w of p){const j=ft(w,a);j>b&&(m=w,b=j)}return b>=10?m:null}function v(){if(!c||d||h.length===0)return;const p=h.shift();if(!p.trim()){v();return}const m=new SpeechSynthesisUtterance(dt(p));m.lang=a,m.rate=r,m.pitch=o;const b=O();b&&(m.voice=b),m.onend=()=>{d=!1,v()},m.onerror=()=>{d=!1,v()},d=!0,c.speak(m)}return{kind:"browser",speak(p){if(!c||!S||!p)return;const m=Re(p),b=Ie(m);h.push(...b.length?b:[m]),v()},stop(){h=[],d=!1,c&&c.cancel()},setEnabled(p){S=p,p||this.stop()},setVoiceURI(p){x=p||null},setRate(p){p&&(r=p)},get enabled(){return S}}}function bt({synthesize:a,onUnavailable:r}){let o=!0,c=[],S=0,h=!1,d=null,x=null,O=!1,v=!1;async function p(){for(h=!0;S<c.length;){const m=c[S];let b=null;try{b=await m.promise}catch{b=null}if(!o)break;if(b&&b.byteLength){O=!0;const w=URL.createObjectURL(new Blob([b],{type:"audio/mpeg"}));x=w;const j=new Audio(w);d=j,await new Promise(k=>{j.onended=k,j.onerror=k,j.play().catch(()=>k())}),x&&(URL.revokeObjectURL(x),x=null),d=null}else!O&&!v&&(v=!0,r&&r());S++}h=!1}return{kind:"cloud",speak(m){if(!(!o||!m)){for(const b of Ie(Re(m))){const w=new AbortController;c.push({promise:a(b,w.signal),ac:w})}h||p()}},stop(){for(const m of c)try{m.ac.abort()}catch{}if(c=[],S=0,h=!1,d){try{d.pause()}catch{}d=null}x&&(URL.revokeObjectURL(x),x=null)},setEnabled(m){o=m,m||this.stop()},setVoiceURI(){},setRate(){},get enabled(){return o}}}function ht(a){const r=String(Math.floor(a/60)).padStart(2,"0"),o=String(a%60).padStart(2,"0");return`${r}:${o}`}function wt(){const a=He(),r=tt(),[o,c]=i.useState([]),[S,h]=i.useState(""),[d,x]=i.useState(!1),[O,v]=i.useState(""),[p,m]=i.useState(""),[b,w]=i.useState(0),[j,k]=i.useState(0),[F,L]=i.useState(!1),[M,D]=i.useState(!1),[U,Q]=i.useState(!1),[K,ne]=i.useState("browser"),[C,se]=i.useState((r==null?void 0:r.voice)!==!1),[H,s]=i.useState("browser"),[f,N]=i.useState([]),[E,T]=i.useState(()=>localStorage.getItem("interview.voiceURI")||""),[$,ie]=i.useState(()=>Number(localStorage.getItem("interview.rate"))||1.15),[pe,ke]=i.useState(!1),[g,fe]=i.useState(null),[A,V]=i.useState("idle"),[Oe,ae]=i.useState(""),u=i.useRef(null),B=i.useRef(null),_=i.useRef(""),Z=i.useRef(null),X=i.useRef(null),ge=i.useRef(C),re=i.useRef(E),z=i.useRef($),Y=i.useRef(null),le=i.useRef(null),ee=i.useRef(""),P=i.useRef(""),J=i.useRef(null),Ee=()=>{if(v("云端语音调用失败，已临时回退到浏览器语音（可能不是男声）。请到「面试模拟」设置页点「测试连通性」查看原因，多为 INTERVIEW_TTS_MODEL 不被中转支持，改成 tts-1 即可。"),!q())return;try{u.current&&u.current.stop()}catch{}const t=me({lang:"zh-CN",rate:z.current});t.setEnabled(ge.current),t.setRate(z.current),re.current&&t.setVoiceURI(re.current),u.current=t,s("browser")};i.useEffect(()=>{r||a("/interview",{replace:!0})},[]),i.useEffect(()=>{let t=!1;return We().then(n=>{t||(n!=null&&n.sttConfigured&&ne("cloud"),n!=null&&n.ttsConfigured?(u.current=bt({synthesize:(l,I)=>et(l,I,z.current),onUnavailable:Ee}),s("cloud")):q()&&(u.current=me({lang:"zh-CN",rate:z.current}),s("browser")),u.current&&(u.current.setEnabled(C),u.current.setRate(z.current),E&&u.current.setVoiceURI(E)))}).catch(()=>{t||q()&&(u.current=me({lang:"zh-CN"}),u.current.setEnabled(C))}),()=>{t=!0,u.current&&u.current.stop()}},[]),i.useEffect(()=>{var n,l;if(!q())return;const t=()=>N(gt());return t(),(l=(n=window.speechSynthesis).addEventListener)==null||l.call(n,"voiceschanged",t),()=>{var I,R;return(R=(I=window.speechSynthesis).removeEventListener)==null?void 0:R.call(I,"voiceschanged",t)}},[]),i.useEffect(()=>{ge.current=C,u.current&&u.current.setEnabled(C)},[C]),i.useEffect(()=>()=>{clearTimeout(J.current);try{B.current&&B.current.stop()}catch{}},[]);const Le=t=>{T(t),re.current=t,localStorage.setItem("interview.voiceURI",t||""),u.current&&u.current.setVoiceURI(t)},Me=t=>{ie(t),z.current=t,localStorage.setItem("interview.rate",String(t)),u.current&&u.current.setRate(t),u.current&&u.current.stop()};i.useEffect(()=>{if(!F)return;const t=setInterval(()=>k(n=>n+1),1e3);return()=>clearInterval(t)},[F]),i.useEffect(()=>{Z.current&&(Z.current.scrollTop=Z.current.scrollHeight)},[o,S]);const Te=t=>{if(!C||!u.current)return;_.current+=t;const n=_.current,l=n.match(/^[\s\S]*[。！？.!?；;\n]/);l&&(u.current.speak(l[0]),_.current=n.slice(l[0].length))},Ae=()=>{C&&u.current&&_.current.trim()&&u.current.speak(_.current),_.current=""},be=t=>{const n=it[t];n!=null&&(w(l=>n>l?n:l),t==="coding"&&ce())},he=async t=>{x(!0),v(""),h(""),_.current="";const n=new AbortController;X.current=n;let l="",I=0,R=!1;try{const y=await Xe({messages:t},qe=>{l+=qe;const{stage:oe,clean:ue}=xe(l);if(oe&&!R&&(R=!0,be(oe)),!oe&&/^\s*\[/.test(l)&&!l.includes(`
`)&&l.length<40)return;h(ue);const ye=ue.slice(I);ye&&(I=ue.length,Te(ye))},n.signal),{stage:W,clean:ze}=xe(y);W&&!R&&be(W),Ae(),c([...t,{role:"assistant",content:ze}]),h("")}catch(y){(y==null?void 0:y.name)!=="AbortError"&&v(String((y==null?void 0:y.message)||y)),h("")}finally{x(!1),X.current=null}},Pe=async()=>{const t={role:"system",content:st(r)};L(!0),await he([t])},G=async t=>{const n=(t??p).trim();if(!n||d)return;u.current&&u.current.stop(),m("");const l=[...o,{role:"user",content:n}];c(l),await he(l)},De=t=>{var n;if(t.key==="Enter"&&!((n=t.nativeEvent)!=null&&n.isComposing||t.keyCode===229)){if(t.altKey||t.shiftKey){t.preventDefault();const l=t.target,I=l.selectionStart,R=l.selectionEnd,y=p.slice(0,I)+`
`+p.slice(R);m(y),requestAnimationFrame(()=>{l.selectionStart=l.selectionEnd=I+1});return}t.preventDefault(),!d&&p.trim()&&G()}},Ue=async()=>{u.current&&u.current.stop();let t;try{t=await navigator.mediaDevices.getUserMedia({audio:!0})}catch{v("无法访问麦克风，请检查浏览器权限");return}le.current=t;const n=typeof MediaRecorder<"u"&&MediaRecorder.isTypeSupported("audio/webm")?"audio/webm":typeof MediaRecorder<"u"&&MediaRecorder.isTypeSupported("audio/mp4")?"audio/mp4":"",l=n?new MediaRecorder(t,{mimeType:n}):new MediaRecorder(t),I=[];l.ondataavailable=R=>{R.data&&R.data.size&&I.push(R.data)},l.onstop=async()=>{le.current&&le.current.getTracks().forEach(y=>y.stop()),D(!1);const R=new Blob(I,{type:l.mimeType||"audio/webm"});if(R.size){Q(!0);try{const y=await Ye(R);y&&m(W=>(W?W+" ":"")+y)}catch(y){v("语音转写失败："+String((y==null?void 0:y.message)||y))}finally{Q(!1)}}},Y.current=l,l.start(),D(!0)},$e=()=>{try{Y.current&&Y.current.state!=="inactive"&&Y.current.stop()}catch{}},Ve=()=>{if(U)return;if(K==="cloud"){M?$e():Ue();return}if(!ct()){v("当前浏览器不支持语音识别，请用 Chrome / Edge，或直接打字作答");return}if(M){B.current&&B.current.stop();return}u.current&&u.current.stop(),ee.current=p?p.trim()+" ":"",P.current="";const t=()=>{clearTimeout(J.current),J.current=setTimeout(()=>{const l=(ee.current+P.current).trim();try{B.current&&B.current.stop()}catch{}l&&!d&&G(l)},2500)},n=ot({lang:"zh-CN",onResult:(l,I)=>{I?(P.current=(P.current?P.current+" ":"")+l,m(ee.current+P.current)):m(ee.current+(P.current?P.current+" ":"")+l),t()},onError:()=>{clearTimeout(J.current),D(!1)},onEnd:()=>{clearTimeout(J.current),D(!1)}});n&&(B.current=n,n.start(),D(!0))},ce=()=>{g||fe(we()),ke(!0),w(4)},Be=async({language:t,source:n})=>{const l=`（编程环节）题目：${g==null?void 0:g.title}
我用 ${t==="java"?"Java":"Python"} 作答，代码如下：

\`\`\`${t}
${n}
\`\`\`

请点评我的思路、时间/空间复杂度和边界处理，并指出可以改进的地方。`;await G(l)},_e=async()=>{await G("面试官您好，本次面试到这里，麻烦您对我今天的整体表现做一个总结评价：包括优点、不足，以及针对性的提升建议。")},Fe=()=>{X.current&&X.current.abort(),u.current&&u.current.stop()},ve=async()=>{u.current&&u.current.stop();const t=o.filter(n=>n.role!=="system");if(t.length<2){ae("面试内容太少，请先进行面试再生成报告"),V("error");return}V("loading"),ae("");try{const n=[...o,{role:"user",content:lt(r)}];await Ze({messages:n,conversation:t,positionTitle:te?te.title:r.position,skills:r.skills||[],courses:Ce()}),V("submitted")}catch(n){ae("提交报告失败："+String((n==null?void 0:n.message)||n)),V("error")}};if(!r)return null;const te=Ne(r.position),Ke=o.filter(t=>t.role!=="system");return e.jsx(Je,{children:e.jsxs("div",{className:"container iv-session",children:[e.jsxs("div",{className:"iv-bar",children:[e.jsxs("div",{className:"iv-bar-left",children:[e.jsxs("span",{className:"iv-bar-title",children:["模拟面试 · ",te?te.title:""]}),e.jsxs("span",{className:"iv-timer",children:["⏱ ",ht(j)]})]}),e.jsxs("div",{className:"iv-bar-right",children:[(H==="cloud"||q())&&e.jsx("button",{className:`iv-pill ${C?"on":""}`,onClick:()=>se(t=>!t),title:"面试官语音朗读",children:C?"🔊 语音开":"🔇 语音关"}),C&&(H==="cloud"||q())&&e.jsx("select",{className:"iv-voice-select",value:String($),onChange:t=>Me(Number(t.target.value)),title:"面试官语速",children:[["0.9","0.9x 慢"],["1","1.0x"],["1.15","1.15x"],["1.3","1.3x"],["1.5","1.5x 快"],["1.75","1.75x 很快"]].map(([t,n])=>e.jsxs("option",{value:t,children:["🐢 ",n]},t))}),H==="cloud"?e.jsx("span",{className:"iv-pill on",title:"使用云端神经语音",children:"✨ 自然语音"}):C&&f.length>0&&e.jsxs("select",{className:"iv-voice-select",value:E,onChange:t=>Le(t.target.value),title:"选择语音音色（建议选带 Google/在线/Natural 的更自然）",children:[e.jsx("option",{value:"",children:"默认音色（自动挑最优）"}),f.map(t=>e.jsxs("option",{value:t.voiceURI,children:[t.name,t.local?"（本地）":"（在线）"]},t.voiceURI))]}),e.jsx("button",{className:"btn btn-ghost ce-small",onClick:()=>a("/interview"),children:"退出"})]})]}),e.jsx("div",{className:"iv-stages",children:nt.map((t,n)=>e.jsxs("button",{className:`iv-stage ${n===b?"active":""} ${n<b?"done":""}`,onClick:()=>{w(n),t.id==="coding"&&ce()},title:`${t.desc} · 约${t.minutes}分钟`,children:[e.jsx("span",{className:"iv-stage-no",children:n+1}),e.jsx("span",{className:"iv-stage-name",children:t.title}),e.jsxs("span",{className:"iv-stage-min",children:[t.minutes,"min"]})]},t.id))}),e.jsxs("div",{className:`iv-main ${pe?"with-code":""}`,children:[e.jsx("div",{className:"iv-chat-col",children:F?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"iv-messages",ref:Z,children:[Ke.map((t,n)=>e.jsxs("div",{className:`iv-msg ${t.role}`,children:[e.jsx("div",{className:"iv-msg-who",children:t.role==="assistant"?"面试官":"我"}),e.jsx("div",{className:"iv-msg-body",children:t.content})]},n)),S&&e.jsxs("div",{className:"iv-msg assistant",children:[e.jsx("div",{className:"iv-msg-who",children:"面试官"}),e.jsxs("div",{className:"iv-msg-body",children:[S,e.jsx("span",{className:"iv-caret",children:"▍"})]})]}),d&&!S&&e.jsxs("div",{className:"iv-msg assistant",children:[e.jsx("div",{className:"iv-msg-who",children:"面试官"}),e.jsx("div",{className:"iv-msg-body iv-thinking",children:"思考中…"})]})]}),O&&e.jsx("div",{className:"iv-error",children:O}),e.jsxs("div",{className:"iv-input-area",children:[e.jsx("textarea",{className:"iv-answer",value:p,onChange:t=>m(t.target.value),onKeyDown:De,placeholder:U?"正在转写录音…":M?K==="cloud"?"正在录音，再次点击麦克风停止并转写…":"正在聆听，边说边出字，停顿约 2.5 秒自动发送…":"输入你的回答（Enter 发送，Alt+Enter 换行），或点麦克风语音作答",rows:3,disabled:d||U}),e.jsxs("div",{className:"iv-input-actions",children:[e.jsx("button",{className:`iv-mic ${M?"on":""}`,onClick:Ve,disabled:d||U,title:K==="cloud"?"语音作答（Whisper 识别）":"语音作答",children:U?"转写中…":M?K==="cloud"?"● 停止并转写":"● 停止录音":"🎤 语音"}),e.jsx("span",{className:"iv-kbd-hint",children:"Enter 发送 · Alt+Enter 换行"}),e.jsx("div",{className:"iv-spacer"}),d&&e.jsx("button",{className:"btn btn-ghost ce-small",onClick:Fe,children:"停止"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>G(),disabled:d||!p.trim(),children:"发送"})]}),e.jsxs("div",{className:"iv-quick",children:[e.jsx("button",{className:"iv-quick-btn",onClick:ce,disabled:d,children:"进入编程环节 ⌨️"}),e.jsx("button",{className:"iv-quick-btn",onClick:_e,disabled:d,children:"请面试官总结评价"}),e.jsx("button",{className:"iv-quick-btn primary",onClick:ve,disabled:d||A==="loading",children:A==="loading"?"正在生成报告…":"结束并生成评分报告 📄"})]})]})]}):e.jsxs("div",{className:"iv-prestart",children:[e.jsx("p",{children:"准备好了吗？点击下方按钮，面试官将先做自我介绍并请你介绍自己。"}),e.jsx("p",{className:"iv-sub",children:"全程约 1 小时，建议在安静环境、用 Chrome/Edge 浏览器以获得最佳语音体验。"}),e.jsx("button",{className:"btn btn-primary iv-start",onClick:Pe,disabled:d,children:d?"面试官准备中…":"开始面试"})]})}),pe&&e.jsxs("div",{className:"iv-code-col",children:[e.jsxs("div",{className:"iv-problem",children:[e.jsxs("div",{className:"iv-problem-head",children:[e.jsxs("h3",{children:[g==null?void 0:g.title," ",e.jsx("span",{className:`iv-diff ${g==null?void 0:g.difficulty}`,children:g==null?void 0:g.difficulty})]}),e.jsx("button",{className:"iv-quick-btn",onClick:()=>fe(we()),children:"换一题"})]}),e.jsx("div",{className:"iv-problem-tags",children:((g==null?void 0:g.tags)||[]).map(t=>e.jsx("span",{className:"iv-tag",children:t},t))}),e.jsx("pre",{className:"iv-problem-body",children:g==null?void 0:g.statement}),(g==null?void 0:g.sampleInput)!=null&&e.jsxs("div",{className:"iv-sample",children:[e.jsxs("div",{children:[e.jsx("strong",{children:"示例输入"}),e.jsx("pre",{children:g.sampleInput})]}),e.jsxs("div",{children:[e.jsx("strong",{children:"示例输出"}),e.jsx("pre",{children:g.sampleOutput})]})]})]}),e.jsx(rt,{initialLang:"python",onSubmit:Be},g==null?void 0:g.id)]})]}),(A==="submitted"||A==="error"||A==="loading")&&e.jsx("div",{className:"iv-modal-mask",onClick:()=>A!=="loading"&&V("idle"),children:e.jsxs("div",{className:"iv-modal",onClick:t=>t.stopPropagation(),children:[A==="loading"&&e.jsxs("div",{className:"iv-modal-loading",children:[e.jsx("div",{className:"iv-spin"}),e.jsx("p",{children:"正在提交本次面试，生成报告中…"})]}),A==="error"&&e.jsxs("div",{className:"iv-modal-body",children:[e.jsx("h3",{children:"提交失败"}),e.jsx("div",{className:"iv-error",children:Oe}),e.jsxs("div",{className:"iv-modal-actions",children:[e.jsx("button",{className:"btn btn-ghost",onClick:()=>V("idle"),children:"关闭"}),e.jsx("button",{className:"btn btn-primary",onClick:ve,children:"重试"})]})]}),A==="submitted"&&e.jsxs("div",{className:"iv-modal-body",children:[e.jsx("h3",{children:"📄 报告生成中"}),e.jsxs("p",{className:"iv-report-summary",children:["本次面试已结束，评估报告正在后台生成（约 1–2 分钟）。完成后会",e.jsx("strong",{children:"发送邮件通知"}),"到你的注册邮箱， 内含下载链接；你也可以随时在",e.jsx("strong",{children:"个人中心"}),"查看本次记录与完整报告。"]}),e.jsxs("div",{className:"iv-modal-actions",children:[e.jsx("button",{className:"btn btn-ghost",onClick:()=>V("idle"),children:"继续留在本页"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>a("/me/interviews"),children:"去个人中心 →"})]})]})]})})]})})}export{wt as default};
