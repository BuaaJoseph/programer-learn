import{r as x,j as e}from"./index-D-xLQIFq.js";import{L as a,S as h}from"./Summary-YJHOQU45.js";import{K as j}from"./KeyIdea-D9fwNcvs.js";import{E as u}from"./Example-JUHxJgjQ.js";import{P as p}from"./Practice-Cvuj-BXK.js";import{C as n}from"./Callout-Bp0vMJus.js";import{C as i}from"./CodeBlock-DX_K20PW.js";import{F as f}from"./Figure-BR5aUEEr.js";const l=[{side:"c",desc:"① 调用接口方法，被动态代理(Proxy)拦截"},{side:"c",desc:"② 把方法名、参数等封装成请求对象，序列化成字节"},{side:"net",desc:"③ 通过网络(通常长连接)把字节发给服务端"},{side:"p",desc:"④ 服务端收到字节，反序列化还原成请求对象"},{side:"p",desc:"⑤ 通过反射找到真正的实现方法并执行"},{side:"p",desc:"⑥ 把返回值序列化"},{side:"net",desc:"⑦ 网络回传给消费端"},{side:"c",desc:"⑧ 消费端反序列化得到结果，代理把它当作方法返回值交还"}];function g(){const[d,c]=x.useState(0),r=l[d],o=e.jsxs(e.Fragment,{children:[e.jsx("button",{className:"fig-btn",onClick:()=>c(s=>Math.min(s+1,l.length-1)),children:"下一步 ▸"}),e.jsx("button",{className:"fig-btn",onClick:()=>c(0),children:"重来"}),e.jsx("span",{className:"fig-note",children:`第 ${d+1}/${l.length} 步`})]});return e.jsx(f,{caption:"一次 RPC 调用的全过程，8 步走完 consumer ↔ provider。任何 RPC 框架(Dubbo/gRPC/Thrift)都是这套骨架，区别只在序列化、协议与治理。",controls:o,children:e.jsxs("svg",{viewBox:"0 0 460 200",width:"460",role:"img","aria-label":"RPC 调用全过程",children:[e.jsx("rect",{x:"20",y:"30",width:"130",height:"100",rx:"10",fill:r.side==="c"?"var(--accent)":"var(--accent-soft)",stroke:"var(--accent-line)"}),e.jsx("text",{x:"85",y:"50",textAnchor:"middle",fontFamily:"var(--display)",fontSize:"13",fontWeight:"700",fill:r.side==="c"?"#ffffff":"var(--accent-strong)",children:"Consumer"}),["Proxy 代理","序列化","网络客户端"].map((s,t)=>e.jsx("text",{x:"85",y:72+t*18,textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"9",fill:r.side==="c"?"#ffffff":"var(--ink-soft)",children:s},s)),e.jsx("rect",{x:"310",y:"30",width:"130",height:"100",rx:"10",fill:r.side==="p"?"var(--green)":"var(--green-soft)",stroke:"var(--green-line)"}),e.jsx("text",{x:"375",y:"50",textAnchor:"middle",fontFamily:"var(--display)",fontSize:"13",fontWeight:"700",fill:r.side==="p"?"#ffffff":"var(--green)",children:"Provider"}),["网络服务端","反序列化","反射执行"].map((s,t)=>e.jsx("text",{x:"375",y:72+t*18,textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"9",fill:r.side==="p"?"#ffffff":"var(--ink-soft)",children:s},s)),e.jsx("line",{x1:"150",y1:"66",x2:"310",y2:"66",stroke:r.side==="net"?"var(--violet)":"var(--border-strong)",strokeWidth:r.side==="net"?2.5:1.4,markerEnd:"url(#rf-a)"}),e.jsx("line",{x1:"310",y1:"96",x2:"150",y2:"96",stroke:r.side==="net"?"var(--violet)":"var(--border-strong)",strokeWidth:r.side==="net"?2.5:1.4,markerEnd:"url(#rf-a)"}),e.jsx("text",{x:"230",y:"60",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"9",fill:"var(--ink-faint)",children:"request bytes"}),e.jsx("text",{x:"230",y:"110",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"9",fill:"var(--ink-faint)",children:"response bytes"}),e.jsx("defs",{children:e.jsx("marker",{id:"rf-a",markerWidth:"8",markerHeight:"8",refX:"5",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L5,3 L0,6 Z",fill:"var(--ink-faint)"})})}),e.jsx("rect",{x:"20",y:"150",width:"420",height:"40",rx:"8",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsx("foreignObject",{x:"28",y:"152",width:"404",height:"36",children:e.jsx("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"12.5px var(--sans)",color:"var(--ink)",lineHeight:1.35},children:r.desc})})]})})}const m=`// 消费端的代理对象，拦截所有接口方法调用
public class RpcProxy implements InvocationHandler {

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        // 第 2 步：封装请求，把「调谁、调什么、参数、版本」装进一个对象
        RpcRequest request = new RpcRequest();
        request.setInterfaceName(method.getDeclaringClass().getName());
        request.setMethodName(method.getName());
        request.setParameterTypes(method.getParameterTypes());
        request.setArguments(args);
        request.setVersion("1.0.0");

        // 第 2 步续：序列化成字节
        byte[] data = serializer.serialize(request);

        // 第 3 步：通过网络发出去（长连接 + NIO），拿到字节响应
        byte[] respData = client.send(data);

        // 第 8 步：把响应字节反序列化成结果对象
        RpcResponse response = serializer.deserialize(respData, RpcResponse.class);
        if (response.getException() != null) {
            throw response.getException();
        }
        return response.getResult();   // 由代理把结果原样返回，调用方无感
    }
}`,v=`// 同步 vs 异步：底层 8 步不变，区别只在「线程要不要原地等」

// —— 同步：发出请求后，业务线程阻塞在这里，直到响应回来 ——
User user = userService.getById(1L);   // 这一行可能卡 50ms

// —— 异步：发出请求立刻拿到 future，业务线程继续干别的 ——
CompletableFuture<User> future = RpcContext.getContext()
        .asyncCall(() -> userService.getById(1L));
future.whenComplete((user, ex) -> {
    if (ex != null) log.error("调用失败", ex);
    else log.info("拿到用户: {}", user.getName());
});
// 业务线程不阻塞，可以同时发起 N 个调用再统一等结果，吞吐成倍提升

// 关键点：异步不是「8 步变少了」，而是把第 3~8 步交给 IO 线程去等，
// 业务线程在第 3 步发出后就返回了，避免「一核等一包」的浪费`,y=`// 长连接 + 多路复用：一条 TCP 上同时跑很多请求，靠 requestId 对号入座
public class NettyClient {
    // requestId -> 等待结果的 future，全局唯一标识每次调用
    private final Map<Long, CompletableFuture<Response>> pending = new ConcurrentHashMap<>();
    private final AtomicLong idGen = new AtomicLong(0);

    public CompletableFuture<Response> send(Request req) {
        long id = idGen.incrementAndGet();
        req.setRequestId(id);
        CompletableFuture<Response> future = new CompletableFuture<>();
        pending.put(id, future);           // 先登记
        channel.writeAndFlush(req);        // 异步发出，不阻塞
        return future;
    }

    // IO 线程收到任意一个响应时回调：按 requestId 找到对应 future 唤醒
    public void onResponse(Response resp) {
        CompletableFuture<Response> future = pending.remove(resp.getRequestId());
        if (future != null) future.complete(resp);   // 哪怕响应乱序回来也能配对
    }
}`;function w(){return e.jsxs(e.Fragment,{children:[e.jsx(a,{children:e.jsxs("p",{children:["上一章我们知道 ",e.jsx("code",{children:"userService.getById(1)"})," 注入的是个代理对象。这一章我们就把这次调用 按下慢放键，看看从「调用方按下回车」到「拿到返回值」中间，到底走了哪 8 步、每一步在干什么。 搞清楚这条主线，后面所有的序列化、注册中心、负载均衡，都能挂到这条线上理解。"]})}),e.jsx("h2",{children:"一次 RPC 调用的 8 步"}),e.jsxs("p",{children:["我们用一次具体调用走完：消费端的订单服务调 ",e.jsx("code",{children:"userService.getById(1)"}),"， 提供端在另一台机器上执行后把 User 返回。整个链路可以拆成 8 步："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"1. 动态代理拦截"}),"：",e.jsx("code",{children:"userService"})," 是代理对象，方法调用被它的 ",e.jsx("code",{children:"invoke"})," 拦下，业务代码以为这是本地调用。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"2. 封装请求并序列化"}),"：代理把「接口名、方法名、参数类型、参数值、版本号」装进一个请求对象，再序列化成字节流。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"3. 网络发送"}),"：通过和提供端之间的连接把字节发出去，通常是一条复用的",e.jsx("em",{children:"长连接"}),"，底层用 ",e.jsx("em",{children:"NIO"}),"（Dubbo 用 Netty）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"4. 服务端反序列化"}),"：提供端收到字节，反序列化还原成请求对象，知道「要调哪个接口的哪个方法、参数是什么」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"5. 反射定位并执行"}),"：服务端根据接口名和版本找到真正的实现类实例，用",e.jsx("em",{children:"反射"}),"调用对应方法，真正执行 ",e.jsx("code",{children:"getById(1)"})," 查库。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"6. 返回值序列化"}),"：把执行得到的 User 对象（或抛出的异常）包成响应对象，序列化成字节。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"7. 网络回传"}),"：响应字节沿着原来的连接送回消费端。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"8. 消费端反序列化并返回"}),"：消费端收到字节，反序列化成响应对象，由代理把结果 ",e.jsx("code",{children:"return"})," 给业务代码。"]})]}),e.jsxs(u,{title:"getById(1) 走完这 8 步",children:[e.jsxs("p",{children:["订单服务执行到 ",e.jsx("code",{children:"userService.getById(1)"}),"：代理拦下调用（1）， 封装成「接口=UserService、方法=getById、参数=1、版本=1.0.0」并序列化（2）， 通过到用户服务那台机器的长连接发出去（3）。"]}),e.jsxs("p",{children:["用户服务那台机器收到字节、反序列化（4），找到 ",e.jsx("code",{children:"UserServiceImpl"})," 实例、 反射调用 ",e.jsx("code",{children:"getById"}),"、查库得到 ",e.jsx("code",{children:"User(id=1, name=张三)"}),"（5）， 把它序列化（6）、沿连接送回（7）。订单服务这边反序列化拿到 User 对象（8）， 代理把它 return 出去。业务代码全程只看到一个返回的 User，看不到中间这 7 步。"]})]}),e.jsx(g,{}),e.jsx("h3",{children:"每一步背后的「为什么」"}),e.jsx("p",{children:"把流程背下来不难，难的是说清每一步为什么非这么设计不可。这正是面试官追问的地方："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"为什么请求里要带「版本号」？"}),"同一个接口可能同时部署多个版本（灰度、A/B），版本号让消费端精确选到想要的那一组提供者，不会串到旧版本上。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"为什么要带「参数类型」而不只是参数值？"}),"Java 有方法重载，",e.jsx("code",{children:"getById(Long)"})," 和 ",e.jsx("code",{children:"getById(String)"})," 同名，只有靠参数类型才能在提供端反射时唯一定位到那个方法。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"为什么用长连接而不是每次新建连接？"}),"TCP 三次握手 + 慢启动开销大，高频调用下反复建连会把延迟和资源吃光，长连接复用 + 心跳保活才划算。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"为什么一条连接上能跑多个并发请求？"}),"靠",e.jsx("em",{children:"多路复用"}),"：每个请求带一个全局唯一的 ",e.jsx("code",{children:"requestId"}),"，响应回来时按 id 配对，哪怕乱序返回也不会认错。"]})]}),e.jsx("h2",{children:"长连接与请求多路复用"}),e.jsxs("p",{children:["第 3 步「网络发送」看着简单，其实是 RPC 性能的命门。如果每次调用都新建 TCP 连接，光握手就要一个 RTT， 高 QPS 下连接数会爆炸。Dubbo 的做法是：消费端到每个提供端维持",e.jsx("strong",{children:"少量长连接"}),"， 所有请求",e.jsx("strong",{children:"复用"}),"这些连接并发跑。这就引出一个问题——一条连接上同时飞着十个请求， 响应回来怎么知道是哪个请求的？答案是给每个请求打一个全局唯一的 ",e.jsx("code",{children:"requestId"}),"， 发出前登记到一张 ",e.jsx("code",{children:"Map"})," 里，响应带着同一个 id 回来时按 id 找到对应的 future 唤醒："]}),e.jsx(i,{lang:"java",title:"requestId 实现请求-响应配对",code:y}),e.jsx(n,{variant:"note",title:"这就是为什么响应可以乱序回来",children:e.jsxs("p",{children:["有了 ",e.jsx("code",{children:"requestId"}),"，提供端处理快的请求可以先回、处理慢的后回，连接上的响应顺序和请求顺序无关。 这也是「一个慢请求不会阻塞同连接上其它请求」的前提——前提是提供端用了线程池并发处理， 否则 Dubbo 默认的 IO 线程被一个慢任务占住，照样会拖累整条连接。"]})}),e.jsx("h2",{children:"同步调用与异步调用"}),e.jsxs("p",{children:["默认的同步调用最直观，但业务线程会阻塞在网络往返上——一次调用 50ms，这个线程这 50ms 什么也干不了。 如果一个请求要串行调好几个下游，延迟会线性累加。异步调用就是来解决这个的：发出请求立刻拿到",e.jsx("code",{children:"CompletableFuture"}),"，线程继续往下跑，可以同时发起多个调用再统一收割结果："]}),e.jsx(i,{lang:"java",title:"同步 vs 异步调用",code:v}),e.jsxs("p",{children:["要强调的是：",e.jsx("strong",{children:"异步并没有减少那 8 步"}),"，只是把「等响应」从业务线程挪到了 IO 线程。 对提供端来说同步异步毫无区别，它只管收请求、执行、回响应。"]}),e.jsx(j,{title:"两个代理，一个反射",children:e.jsxs("p",{children:["这条链路里有三个最关键的技术点。",e.jsx("strong",{children:"消费端靠动态代理"}),"把本地方法调用变成网络请求；",e.jsx("strong",{children:"提供端靠反射"}),"把网络请求变回本地方法调用； 中间",e.jsx("strong",{children:"靠序列化"}),"让对象能在网络上传输。 说穿了，RPC 就是「代理把调用打包发出去，反射在对端拆包执行，序列化负责打包拆包」。"]})}),e.jsx(n,{variant:"note",title:"同步还是异步",children:e.jsxs("p",{children:["上面描述的是",e.jsx("strong",{children:"同步调用"}),"：发出请求后线程阻塞等响应回来。Dubbo 也支持",e.jsx("strong",{children:"异步调用"}),"， 发出请求后立刻返回一个 ",e.jsx("code",{children:"CompletableFuture"}),"，结果到了再回调，线程不用干等。 但不管同步异步，底层这 8 步的本质是一样的，区别只在「消费端线程要不要原地等结果」。"]})}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["被问「讲一下一次 RPC 调用的过程」时，按这条主线答最清楚：",e.jsx("strong",{children:"消费端动态代理拦截 → 封装请求并序列化 → 通过长连接发出 → 服务端反序列化 → 反射定位实现并执行 → 返回值序列化 → 网络回传 → 消费端反序列化由代理返回"}),"。 能把「代理负责消费端、反射负责服务端、序列化贯穿全程」这条逻辑说出来，就说明你真的理解了， 而不是背流程。"]}),e.jsx(n,{variant:"warn",title:"面试追问与常见误区",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"「动态代理是 JDK 还是 CGLIB？」"}),"接口有用 JDK 动态代理（基于 ",e.jsx("code",{children:"InvocationHandler"}),"），无接口才退化到 CGLIB 生成子类。Dubbo 默认走 JDK 代理，因为它要求面向接口编程。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"「序列化失败会发生在哪一步？」"}),"第 2 步（参数序列化）和第 6 步（返回值序列化）。常见原因是对象没实现 ",e.jsx("code",{children:"Serializable"}),"、字段是不可序列化类型、消费提供两端的类版本不一致。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"「超时算在哪一步？」"}),"从第 3 步发出到第 8 步收到的总耗时超过配置的 timeout 就触发，默认 1000ms。注意超时只在消费端生效，提供端可能还在继续执行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"误区：以为提供端收到超时通知就会停。"}),"不会。消费端超时只是自己不等了，提供端那次执行照样跑完，所以幂等性很重要（后续章节讲）。"]})]})}),e.jsxs(p,{title:"手写代理 invoke 的骨架",children:[e.jsxs("p",{children:["理解 RPC 最快的方式，是自己画一遍代理的 ",e.jsx("code",{children:"invoke"})," 方法骨架。 下面这段伪代码（去掉了连接管理、超时等细节）把消费端的第 2、3、8 步串了起来："]}),e.jsx(i,{lang:"java",title:"RpcProxy.invoke 骨架",code:m}),e.jsxs("p",{children:["注意这里 ",e.jsx("code",{children:"client.send"})," 是同步阻塞的；如果改成异步，就把它换成返回 future、 并让 ",e.jsx("code",{children:"invoke"})," 直接返回这个 future。下一章我们深入第 2 步的核心——序列化， 看看为什么 Dubbo 默认不用 Java 原生序列化。"]})]}),e.jsx(h,{points:["一次 RPC 调用的 8 步：代理拦截 → 封装请求并序列化 → 网络发送 → 服务端反序列化 → 反射执行 → 返回值序列化 → 网络回传 → 消费端反序列化并返回。","请求里要带「接口名、方法名、参数类型、参数值、版本号」，对端才能精确定位到要执行的方法。","消费端靠动态代理把本地调用变成网络请求，提供端靠反射把网络请求变回本地调用。","序列化贯穿全程：参数和返回值都要在对象和字节流之间来回转换。","网络通信通常用复用的长连接加 NIO（Dubbo 基于 Netty），避免频繁建连。","同步调用阻塞等结果，异步调用返回 future 后回调，底层 8 步本质一致。"]})]})}export{w as default};
