import{j as e}from"./index-BnUyEu5E.js";import{L as t,S as s}from"./Summary-qZ1-DBVA.js";import{K as d}from"./KeyIdea-DOTgzjr8.js";import{C as i}from"./Callout-DUAtr8Nz.js";import{C as r}from"./CodeBlock-DIEQOVpA.js";import{E as n}from"./Example-BRazL43h.js";const l=`// 抽象类：可以有状态、构造器、具体方法，表达「is-a」
abstract class Shape {
    protected String name;          // 可以有实例字段
    Shape(String name) { this.name = name; }  // 可以有构造器
    abstract double area();         // 抽象方法：留给子类实现
    String describe() { return name + " 面积=" + area(); }  // 具体方法
}

// 接口：表达「能做什么」的能力契约
interface Drawable {
    int LAYER = 0;                  // 隐式 public static final 常量
    void draw();                    // 隐式 public abstract
    default void clear() { System.out.println("清空"); }  // Java 8 默认方法
}

class Circle extends Shape implements Drawable {
    double r;
    Circle(double r) { super("圆"); this.r = r; }
    @Override double area() { return Math.PI * r * r; }
    @Override public void draw() { System.out.println("画圆"); }
}`,c=`public class Outer {
    private int x = 10;

    // 1) 成员内部类：持有外部类实例的引用，可访问外部私有成员
    class Member {
        void show() { System.out.println(x); }
    }

    // 2) 静态内部类：不持有外部实例，相当于普通顶层类的命名空间
    static class Nested {
        void show() { System.out.println("不依赖 Outer 实例"); }
    }

    void method() {
        // 3) 局部内部类：定义在方法体内
        class Local { void run() {} }

        // 4) 匿名内部类：定义并实例化一个一次性子类/实现
        Runnable r = new Runnable() {
            @Override public void run() { System.out.println(x); }
        };
        r.run();
    }
}`,h=`// 设计一个不可变类的要点
public final class Point {              // 1) 类用 final，禁止继承篡改
    private final int x;                // 2) 字段全部 private final
    private final int y;

    public Point(int x, int y) {        // 3) 构造时一次性赋值
        this.x = x;
        this.y = y;
    }

    public int getX() { return x; }     // 4) 只提供 getter，不提供 setter
    public int getY() { return y; }

    // 5) 如需「修改」，返回新对象而非改自身
    public Point withX(int nx) { return new Point(nx, y); }
}`,x=`public final class Holder {
    private final int[] data;           // 引用 final，但数组内容可变！

    public Holder(int[] src) {
        this.data = src.clone();        // 防御性拷贝：不直接存外部引用
    }
    public int[] getData() {
        return data.clone();            // 返回副本，避免外部改动内部数组
    }
}`;function v(){return e.jsxs("article",{children:[e.jsx(t,{children:"类型设计是 Java 面试里区分「会写」和「懂设计」的分水岭。本章围绕四道高频题展开： 接口与抽象类怎么选、四种内部类各自的用途、如何设计一个真正不可变的类、四种访问修饰符的可见范围。 每道题都讲清原理、给可运行代码，并点出最容易踩的坑。"}),e.jsx("h2",{children:"一、接口 vs 抽象类"}),e.jsxs(d,{children:["抽象类回答「",e.jsx("strong",{children:"它是什么"}),"」（is-a，可带状态与默认实现，单继承）； 接口回答「",e.jsx("strong",{children:"它能做什么"}),"」（can-do，能力契约，可多实现）。 当多个类共享状态和实现细节时用抽象类；当只想约定一组行为、且需要被不相关的类共同具备时用接口。"]}),e.jsx("h3",{children:"面试题 1：接口和抽象类有什么区别，怎么选？"}),e.jsx(r,{lang:"java",title:"抽象类与接口的对照",code:l}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"抽象类"}),e.jsx("th",{children:"接口"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"关键字"}),e.jsxs("td",{children:[e.jsx("code",{children:"abstract class"})," / ",e.jsx("code",{children:"extends"})]}),e.jsxs("td",{children:[e.jsx("code",{children:"interface"})," / ",e.jsx("code",{children:"implements"})]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"多继承"}),e.jsx("td",{children:"单继承（一个父类）"}),e.jsx("td",{children:"可实现多个接口"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"字段"}),e.jsx("td",{children:"可有任意实例字段"}),e.jsxs("td",{children:["只能是 ",e.jsx("code",{children:"public static final"})," 常量"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"构造器"}),e.jsx("td",{children:"有（供子类 super 调用）"}),e.jsx("td",{children:"没有"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"方法实现"}),e.jsx("td",{children:"可有具体方法"}),e.jsx("td",{children:"Java 8+ 可有 default/static 方法"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"语义"}),e.jsx("td",{children:"is-a（强血缘关系）"}),e.jsx("td",{children:"can-do（能力/角色）"})]})]})]}),e.jsxs("p",{children:["选择经验：如果几个类",e.jsx("strong",{children:"本质上是同一族"}),"、共享字段和大量公共实现，用抽象类； 如果只是想给一组",e.jsx("strong",{children:"可能毫不相关"}),"的类约定共同行为（如「可比较」「可序列化」），用接口。 现代 Java 倾向「优先用接口」，因为它更灵活、不占用唯一的继承名额。"]}),e.jsxs(i,{variant:"tip",title:"面试追问：Java 8 后接口能有方法体，那它和抽象类还有区别吗？",children:["有，本质区别没变：接口",e.jsx("strong",{children:"不能有实例字段、不能有构造器、不能保存对象状态"}),"， 默认方法只是为了在不破坏已有实现类的前提下给接口「平滑加方法」。抽象类能管状态，接口管行为，这条分界依旧成立。"]}),e.jsx("h2",{children:"二、内部类"}),e.jsx("h3",{children:"面试题 2：内部类有哪几种？各自什么用途？"}),e.jsx("p",{children:"Java 有四种内部类，区别在于「定义位置」和「是否持有外部类实例引用」："}),e.jsx(r,{lang:"java",title:"四种内部类",code:c}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"类型"}),e.jsx("th",{children:"位置"}),e.jsx("th",{children:"持有外部实例"}),e.jsx("th",{children:"典型用途"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"成员内部类"}),e.jsx("td",{children:"类内、方法外"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"需要紧密访问外部对象状态的辅助类"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"静态内部类"}),e.jsx("td",{children:"类内、加 static"}),e.jsx("td",{children:"否"}),e.jsx("td",{children:"逻辑归属外部类但不依赖其实例（如 Builder、Node）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"局部内部类"}),e.jsx("td",{children:"方法体内"}),e.jsx("td",{children:"是（限定作用域）"}),e.jsx("td",{children:"只在某方法内复用一次的小类"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"匿名内部类"}),e.jsx("td",{children:"表达式中"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"一次性实现接口/抽象类（回调、监听器）"})]})]})]}),e.jsxs(i,{variant:"warn",title:"易错点：成员内部类与内存泄漏",children:["非静态内部类会",e.jsx("strong",{children:"隐式持有外部类实例的引用"}),"。如果一个长生命周期的对象（如线程、监听器） 是非静态内部类的实例，它会让外部对象迟迟无法被回收，造成内存泄漏。 所以「不需要访问外部实例」时，优先用",e.jsx("strong",{children:"静态内部类"}),"。这也是为什么很多工具类里 Node、Entry 都是 static。"]}),e.jsxs(i,{variant:"note",title:"匿名内部类与 Lambda 的关系",children:["Java 8 的 Lambda 表达式在很多场景可替代「实现单方法接口的匿名内部类」，更简洁。 但二者不完全等价：Lambda 没有自己的 ",e.jsx("code",{children:"this"}),"（指向外部实例），也不会生成独立的 .class， 而匿名内部类有自己的 this 且会编译出一个 ",e.jsx("code",{children:"Outer$1.class"}),"。只有函数式接口才能用 Lambda 替代。"]}),e.jsx("h2",{children:"三、不可变类"}),e.jsx("h3",{children:"面试题 3：如何设计一个不可变（immutable）类？"}),e.jsxs("p",{children:["不可变类指对象一旦创建，状态就不能再改变（如 ",e.jsx("code",{children:"String"}),"、",e.jsx("code",{children:"Integer"}),"、",e.jsx("code",{children:"BigDecimal"}),"）。 它的好处是天生线程安全、可安全共享、可放心做缓存键。设计要点有五条："]}),e.jsx(r,{lang:"java",title:"不可变类的五个要点",code:h}),e.jsxs("ol",{children:[e.jsxs("li",{children:["类声明为 ",e.jsx("code",{children:"final"}),"，防止子类继承后破坏不可变性；"]}),e.jsxs("li",{children:["所有字段 ",e.jsx("code",{children:"private final"}),"，构造后不可重新赋值；"]}),e.jsx("li",{children:"只在构造器里赋值一次；"}),e.jsx("li",{children:"不提供任何 setter；"}),e.jsxs("li",{children:["需要「修改」时返回一个新对象（如 ",e.jsx("code",{children:"String"})," 的所有变换方法）。"]})]}),e.jsxs(i,{variant:"warn",title:"最容易漏的坑：可变字段要做防御性拷贝",children:["如果字段是一个可变对象（数组、List、Date），仅仅加 ",e.jsx("code",{children:"final"})," 是不够的——",e.jsx("code",{children:"final"})," 只锁住「引用不能改指向」，锁不住「被指对象内部可变」。 必须在构造时",e.jsx("strong",{children:"拷贝传入的可变对象"}),"，在 getter 里",e.jsx("strong",{children:"返回副本"}),"， 否则外部仍能通过引用篡改内部状态。"]}),e.jsx(r,{lang:"java",title:"可变字段的防御性拷贝",code:x}),e.jsx(n,{title:"为什么不可变天生线程安全？",children:e.jsx("p",{children:"多线程的根本问题是「共享可变状态」。不可变对象状态创建后永不改变， 所以无论多少线程同时读它，都不可能读到「写到一半」的中间态，自然无需加锁。 这也是为什么并发编程提倡「能用不可变就用不可变」。"})}),e.jsx("h2",{children:"四、访问修饰符"}),e.jsx("h3",{children:"面试题 4：四种访问修饰符的可见范围？"}),e.jsxs("p",{children:["Java 有四种访问级别，从最严到最松依次是 ",e.jsx("code",{children:"private"}),"、默认（package-private，不写修饰符）、",e.jsx("code",{children:"protected"}),"、",e.jsx("code",{children:"public"}),"。记忆口诀是「类内 → 同包 → 子类 → 全局」逐级放开。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"修饰符"}),e.jsx("th",{children:"同类"}),e.jsx("th",{children:"同包"}),e.jsx("th",{children:"子类（不同包）"}),e.jsx("th",{children:"其他包"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"private"})}),e.jsx("td",{children:"可"}),e.jsx("td",{children:"不可"}),e.jsx("td",{children:"不可"}),e.jsx("td",{children:"不可"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"默认（不写）"}),e.jsx("td",{children:"可"}),e.jsx("td",{children:"可"}),e.jsx("td",{children:"不可"}),e.jsx("td",{children:"不可"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"protected"})}),e.jsx("td",{children:"可"}),e.jsx("td",{children:"可"}),e.jsx("td",{children:"可"}),e.jsx("td",{children:"不可"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"public"})}),e.jsx("td",{children:"可"}),e.jsx("td",{children:"可"}),e.jsx("td",{children:"可"}),e.jsx("td",{children:"可"})]})]})]}),e.jsxs(i,{variant:"note",title:"protected 的两个细节",children:["其一，",e.jsx("code",{children:"protected"})," 比默认级别",e.jsx("strong",{children:"多放开了「不同包的子类」"}),"，但子类只能通过",e.jsx("strong",{children:"自身或子类类型的引用"}),"访问父类的 protected 成员，不能通过父类类型的引用随意访问。 其二，顶层类（非内部类）只能用 ",e.jsx("code",{children:"public"})," 或默认两种修饰符，不能用 private/protected 修饰顶层类。"]}),e.jsx(i,{variant:"tip",title:"设计建议：最小可见性原则",children:"始终用「能满足需求的最小可见性」。字段优先 private，需要时再通过方法放开； 这能减少耦合、保护封装，也让后续重构内部实现时不影响外部调用方。面试被问到设计原则时， 这一条配合封装一起讲很自然。"}),e.jsx("h3",{children:"面试题 5：static 关键字能修饰哪些东西？各是什么含义？"}),e.jsxs("p",{children:["访问修饰符常和 ",e.jsx("code",{children:"static"})," 一起出现，这道题把 static 的用法补全：static 表示「属于类、不属于实例」。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"修饰对象"}),e.jsx("th",{children:"含义"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"静态字段"}),e.jsx("td",{children:"类级别共享，所有实例共用一份"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"静态方法"}),e.jsx("td",{children:"用类名直接调，无 this，不能访问实例成员"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"静态代码块"}),e.jsx("td",{children:"类首次加载时执行一次，常用于初始化静态资源"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"静态内部类"}),e.jsx("td",{children:"不持有外部实例引用（见上文内部类）"})]})]})]}),e.jsxs(i,{variant:"note",title:"static 不能修饰局部变量",children:[e.jsx("code",{children:"static"})," 不能修饰方法内的局部变量（局部变量随方法栈帧创建销毁，谈不上「类级别」）。 它修饰的是类成员。另外静态成员在类初始化时就绪、生命周期与类相同，这也是它能被「类名直接访问」的原因。"]}),e.jsx(s,{points:["抽象类表达 is-a、可带状态与构造器、单继承；接口表达 can-do、无实例状态、可多实现；共享实现用抽象类，约定能力用接口。","Java 8 后接口可有 default/static 方法，但仍无实例字段和构造器，这是它与抽象类的本质分界。","四种内部类：成员/静态/局部/匿名；非静态内部类隐式持有外部实例易致内存泄漏，不依赖外部实例就用静态内部类。","不可变类五要点：类 final、字段 private final、只构造时赋值、无 setter、修改返回新对象；可变字段必须做防御性拷贝。","不可变对象天生线程安全，因为没有可被并发修改的共享可变状态。","访问修饰符 private < 默认 < protected < public 逐级放开；遵循最小可见性原则保护封装。"]})]})}export{v as default};
