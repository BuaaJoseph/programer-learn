import{j as e}from"./index-bcw1GFOG.js";import{L as t,S as n}from"./Summary-CzbI5rAL.js";import{K as i}from"./KeyIdea-BfDRPFR2.js";import{E as l}from"./Example-C1jxmPta.js";import{P as d}from"./Practice-DbjK1PhF.js";import{C as r}from"./Callout-Kd5ZZGSH.js";import{C as s}from"./CodeBlock-DTDRATdO.js";const c=`from dataclasses import dataclass

# 价格按「每百万 token」算，输入/输出分开计费（数值仅为示意，请以实际为准）。
@dataclass
class ModelTier:
    name: str
    in_price: float    # 输入价：USD / 1M tokens
    out_price: float   # 输出价：USD / 1M tokens（通常是输入的 3~5 倍）

TIERS = {
    'small':  ModelTier('haiku',  0.80,  4.00),
    'medium': ModelTier('sonnet', 3.00, 15.00),
    'large':  ModelTier('opus',  15.00, 75.00),
}


def estimate_cost(tier_key, tokens_in, tokens_out):
    t = TIERS[tier_key]
    return (tokens_in * t.in_price + tokens_out * t.out_price) / 1_000_000


def route_model(task: str, *, needs_reasoning: bool, input_len: int) -> str:
    # 分级路由：用任务特征选最小够用的模型，而不是无脑上最强的。
    if task in ('classify', 'extract', 'format', 'route'):
        return 'small'                      # 结构化、判别类任务，小模型足矣
    if needs_reasoning or input_len > 8000:
        return 'large'                      # 多步推理 / 超长上下文才动用大模型
    return 'medium'                          # 默认中档：日常对话、改写、总结


if __name__ == '__main__':
    # 假设一天 10 万次请求，平均 input 1500 / output 400 token
    n, t_in, t_out = 100_000, 1500, 400

    all_large = n * estimate_cost('large', t_in, t_out)

    # 分级路由后的真实占比：60% 小、30% 中、10% 大
    mixed = (
        0.6 * n * estimate_cost('small',  t_in, t_out)
        + 0.3 * n * estimate_cost('medium', t_in, t_out)
        + 0.1 * n * estimate_cost('large',  t_in, t_out)
    )

    print(f'全用大模型:   USD {all_large:,.0f} / 天')
    print(f'分级路由:     USD {mixed:,.0f} / 天')
    print(f'省下:         {(1 - mixed / all_large):.0%}')`,o=`# prompt 缓存：把每次都一样的前缀（系统提示 + 知识库）标记为可缓存
# 命中后这部分输入 token 大幅打折，且省去重复处理的延迟。
from anthropic import Anthropic

client = Anthropic()

SYSTEM_PROMPT = open('big_system_prompt.txt').read()   # 几千 token，每次都一样
KB_SNIPPET    = open('product_kb.txt').read()          # 知识库，很少变

def answer(user_msg):
    return client.messages.create(
        model='claude-sonnet-4-5',
        max_tokens=300,
        system=[
            # 把稳定不变的大段前缀标记为缓存断点：第二次起命中折扣
            {'type': 'text', 'text': SYSTEM_PROMPT,
             'cache_control': {'type': 'ephemeral'}},
            {'type': 'text', 'text': KB_SNIPPET,
             'cache_control': {'type': 'ephemeral'}},
        ],
        messages=[{'role': 'user', 'content': user_msg}],   # 变化的部分放最后
    )
# 关键纪律：把「稳定的放前面、变化的放后面」。
# 缓存按前缀匹配，一旦前面有一个字节变了，后面全部失效、白缓存。`;function g(){return e.jsxs(e.Fragment,{children:[e.jsx(t,{children:e.jsxs("p",{children:["Demo 跑通和上线运营之间，隔着一张账单和一条延迟曲线。一个看起来很聪明的多 Agent 系统， 可能在真实流量下每天烧掉四位数美金、让用户等上十几秒。本章讲两件最现实的事： 钱花在哪、时间耗在哪，以及怎么在",e.jsx("strong",{children:"不明显牺牲质量"}),"的前提下把它们压下来。"]})}),e.jsx("h2",{children:"账单是怎么算出来的"}),e.jsxs("p",{children:["LLM 按 ",e.jsx("em",{children:"token"})," 计费，而且",e.jsx("strong",{children:"输入 token 和输出 token 分别计价"}),"。关键的反直觉点是：",e.jsx("strong",{children:"输出通常比输入贵 3 到 5 倍"}),"。原因在于生成是自回归的——每吐一个输出 token 都要把 整段上下文重新前向计算一遍，算力开销远大于一次性读入的输入。"]}),e.jsx("p",{children:"所以「让模型少说废话」不只是体验问题，更是直接省钱。一个动辄输出三百字解释的 Agent， 和一个只回必要结论的 Agent，账单可能差一倍。"}),e.jsx(r,{variant:"warn",title:"多 Agent / 多轮会让账单滚雪球",children:e.jsxs("p",{children:["单次调用看着便宜，但 Agent 系统的成本是",e.jsx("strong",{children:"乘出来的"}),"。每多一个 Agent、每多一轮对话， 都意味着把",e.jsx("strong",{children:"越滚越长的上下文"}),"重新喂一遍。一个协调器 + 三个专家 Agent 的系统， 处理一个请求可能产生七八次 LLM 调用，而且每次都带着前面累积的全部历史。 上下文越长，单次输入 token 越多，再乘以调用次数——成本不是加法，是",e.jsx("strong",{children:"近乎平方级"}),"的增长。 这就是为什么「能用一次调用解决就别用两次」。"]})}),e.jsx("h3",{children:"输出为什么贵：一个值得记住的机制"}),e.jsxs("p",{children:["输入 token 是模型",e.jsx("strong",{children:"一次性并行读入"}),"的：几千 token 的 prompt 在一次前向传播里就吃进去了。 而输出是",e.jsx("strong",{children:"自回归逐字生成"}),"的——每吐一个 token，都要把「已有上下文 + 已生成的部分」 重新跑一遍前向计算。换句话说，生成 400 个输出 token，约等于做了 400 次递增的前向计算， 算力远高于读入。这就是输出单价是输入 3~5 倍的物理根源，也是为什么",e.jsx("strong",{children:"压缩输出长度"}),"是性价比极高的优化：让 Agent「只回结论、不复述问题、不写客套」，账单立竿见影。"]}),e.jsx("h3",{children:"先量后优：别凭感觉优化"}),e.jsxs("p",{children:["优化的第一条铁律和普通性能调优一样：",e.jsx("strong",{children:"先 profile，再动手"}),"。在没有数据之前就去「优化」， 十有八九是在改一个根本不重要的地方。上一章的 trace 此刻就派上用场了——把每个 span 的 token 数和耗时 聚合起来，你会立刻看到真相：往往 80% 的成本集中在某一两类调用上，80% 的延迟卡在某一个慢工具上。",e.jsx("strong",{children:"优化那两个，别动其余的。"})]}),e.jsxs(l,{title:"profile 之后常见的真相",children:[e.jsx("p",{children:"给一个客服 Agent 做一周的 trace 聚合，结果往往长这样："}),e.jsxs("ul",{children:[e.jsx("li",{children:"62% 的成本来自「生成最终回复」这一步——因为它用了大模型且输出很长。"}),e.jsx("li",{children:"71% 的 P95 延迟来自一次外部订单查询工具——网络往返慢。"}),e.jsx("li",{children:"每次请求平均重复携带了 4000 token 的历史，其中大半已无关。"})]}),e.jsx("p",{children:"看到这张表，优化方向就不用猜了：回复步骤换分级模型、订单查询加缓存、历史做裁剪。 其余的代码一行都不用碰。"})]}),e.jsx("h2",{children:"六招砍成本与延迟"}),e.jsx("p",{children:"下面六招按性价比从高到低排，多数项目用前三招就能砍掉一大半开销："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"裁剪上下文"}),"：别把全部历史无脑塞进去。做摘要、只留最近 N 轮、只检索相关片段。 上下文短了，输入 token 直接下降，延迟也跟着降。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"模型分级路由"}),"：判别/分类/格式化这类活儿交给小模型，只有需要多步推理时才动用大模型。 这是省钱最猛的一招，详见本章 Practice。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"prompt 缓存"}),"：系统提示、知识库片段这些每次都一样的前缀，用 ",e.jsx("em",{children:"prompt caching"}),"缓存起来，命中后这部分输入 token 大幅打折，延迟也降。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"并行调用"}),"：互不依赖的多个工具/检索，别串行等待，用并发一起发出去，总延迟取最慢的那个而非求和。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"流式输出"}),"：用 ",e.jsx("em",{children:"streaming"})," 边生成边返回。它不降低总成本，但让用户在几百毫秒内就看到 第一个字，",e.jsx("strong",{children:"体感延迟"}),"大幅改善——这往往比真实延迟更影响满意度。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"减少调用次数"}),"：能合并的步骤合并，能一轮搞定就别两轮。每砍掉一次 LLM 调用， 省的是一整段上下文的输入成本加一次网络往返。"]})]}),e.jsx("h2",{children:"把 prompt 缓存吃透"}),e.jsxs("p",{children:["六招里最容易「装了却没生效」的就是 prompt 缓存。它的原理是",e.jsx("strong",{children:"按前缀做匹配"}),"： 系统提示、知识库这些每次请求都一字不差的大段前缀，第一次照常计费，之后命中就大幅打折、 还省去重复处理的延迟。但它有一条铁律——",e.jsx("strong",{children:"稳定的内容放前面，变化的内容放后面"}),"。 缓存是前缀匹配，只要前面有一个字节变了，后面全部失效。"]}),e.jsx(s,{lang:"python",title:"prompt_cache.py",code:o}),e.jsx(r,{variant:"warn",title:"缓存最常见的两个失效坑",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"把动态内容混在前缀里"}),"——比如在系统提示里拼进当前时间、用户名。 这等于每次请求前缀都不同，缓存永远不命中，白白付了缓存写入的成本。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"前缀太短不划算"}),"——缓存有最小长度门槛，几十 token 的前缀缓存了也省不下什么。 缓存只对「又大又稳」的前缀（大段系统提示、长知识库）才真正划算。"]})]})}),e.jsx("h2",{children:"延迟和成本不是一回事"}),e.jsx("p",{children:"新手常把这两件事混为一谈，其实它们的优化手段方向不同，甚至会冲突。下面这张表把六招按 「主要省成本还是省延迟」分了类："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"手段"}),e.jsx("th",{children:"省成本"}),e.jsx("th",{children:"省延迟"}),e.jsx("th",{children:"注意"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"裁剪上下文"}),e.jsx("td",{children:"强"}),e.jsx("td",{children:"强"}),e.jsx("td",{children:"裁过头会丢信息，伤质量"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"模型分级路由"}),e.jsx("td",{children:"强"}),e.jsx("td",{children:"中"}),e.jsx("td",{children:"小模型也更快"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"prompt 缓存"}),e.jsx("td",{children:"强"}),e.jsx("td",{children:"中"}),e.jsx("td",{children:"前缀必须稳定"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"并行调用"}),e.jsx("td",{children:"无"}),e.jsx("td",{children:"强"}),e.jsx("td",{children:"不省钱，只压总耗时"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"流式输出"}),e.jsx("td",{children:"无"}),e.jsx("td",{children:"仅体感"}),e.jsx("td",{children:"总延迟不变，首字更快"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"减少调用次数"}),e.jsx("td",{children:"强"}),e.jsx("td",{children:"强"}),e.jsx("td",{children:"合并步骤可能升复杂度"})]})]})]}),e.jsxs("p",{children:["看清这张表你就明白：",e.jsx("strong",{children:"并行和流式只动延迟、不动账单"}),"，而裁剪、分级、缓存、减少调用 才是真正省钱的四招。优化前先想清楚你当下最痛的是哪个指标，别用省延迟的招去解决成本问题。"]}),e.jsx(i,{title:"质量 × 成本 × 延迟：三角权衡",children:e.jsxs("p",{children:["这三者是一个",e.jsx("strong",{children:"不可能三角"}),"：想又快又便宜，质量大概率打折；想最高质量又便宜， 就得忍受延迟（比如让小模型多想几轮）；想又快又好，那就准备好付钱。 工程的本质不是「全都要」，而是",e.jsx("strong",{children:"针对每一类任务"}),"选定一个合适的点。 简单分类任务可以果断牺牲质量上限换成本，核心退款决策则反过来不惜成本保质量。 没有放之四海皆准的配置，只有「这个场景该站在三角的哪个角」。"]})}),e.jsx("h2",{children:"这对做 Agent / 工程实践意味着什么"}),e.jsxs("p",{children:["成本和延迟不是上线后再操心的「运维问题」，它们应该是",e.jsx("strong",{children:"架构决策"}),"的一部分。 在设计每一个 Agent 步骤时就问自己：这步真的需要大模型吗？这段上下文能裁吗？这几个调用能并行吗？ 把分级路由、上下文裁剪、缓存做进框架，而不是散落在各处临时补丁。 而所有这些判断的依据，都来自上一章那套 trace——",e.jsx("strong",{children:"先量，后优，再验证"}),"，形成闭环。"]}),e.jsxs(d,{title:"分级路由的成本对比与实现",children:[e.jsx("p",{children:"先看一张对比表，直观感受分级路由能省多少（数值按「全用大模型」与「6/3/1 分级」对比，单价为示意）："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"全用大模型"}),"：每天约 USD 5,250"]}),e.jsxs("li",{children:[e.jsx("code",{children:"分级路由(60% 小 / 30% 中 / 10% 大)"}),"：每天约 USD 1,400"]}),e.jsxs("li",{children:[e.jsx("code",{children:"节省"}),"：约 73%"]})]}),e.jsxs("p",{children:["下面这段代码实现了一个 ",e.jsx("code",{children:"route_model"})," 函数：按任务类型和是否需要推理选择最小够用的模型， 并算出两种策略一天的成本对比。注意输出价是输入价的约 5 倍，这正是「让模型少废话」省钱的根据。"]}),e.jsx(s,{lang:"python",title:"cost_routing.py",code:c}),e.jsxs("p",{children:["把 ",e.jsx("code",{children:"route_model"})," 接到协调器里：每次调用前先判定任务难度，再决定喂给哪个档位的模型。 配合上一章的 trace，你还能持续观测各档位的真实占比，反过来校准路由规则。"]})]}),e.jsx(n,{points:["LLM 按 token 计费，输入与输出分开算，且输出通常比输入贵 3~5 倍，所以让模型少废话能直接省钱。","多 Agent/多轮会重复携带越滚越长的上下文，成本近乎平方级增长，能一次解决就别两次。","优化铁律：先 profile 后优化，用 trace 聚合找出占大头的成本与延迟热点，只优化那少数几个。","六招：裁剪上下文、模型分级路由、prompt 缓存、并行调用、流式输出改善体感延迟、减少调用次数。","质量×成本×延迟是不可能三角，工程要做的是为每类任务选定合适的点，而非全都要。","成本与延迟是架构决策，应把分级路由/裁剪/缓存做进框架，并用 trace 闭环验证效果。"]})]})}export{g as default};
