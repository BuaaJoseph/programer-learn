import{j as e}from"./index-BnUyEu5E.js";import{L as n,S as i}from"./Summary-qZ1-DBVA.js";import{K as r}from"./KeyIdea-DOTgzjr8.js";import{C as t}from"./Callout-DUAtr8Nz.js";import{C as s}from"./CodeBlock-DIEQOVpA.js";import{E as c}from"./Example-BRazL43h.js";const d=`// Counter.jsx —— 被测组件
import { useState } from 'react'

export default function Counter() {
  const [count, setCount] = useState(0)
  return (
    <div>
      <p>当前计数：{count}</p>
      <button onClick={() => setCount((c) => c + 1)}>加一</button>
    </div>
  )
}`,l=`// Counter.test.jsx —— 用 React Testing Library 测点击计数
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, it, expect } from 'vitest'
import Counter from './Counter.jsx'

describe('Counter', () => {
  it('点击按钮后计数加一', async () => {
    const user = userEvent.setup()
    render(<Counter />)                       // 把组件渲染进测试用的 DOM

    // 按用户视角找元素：用「可见文本 / 角色」，而不是 class / id
    expect(screen.getByText('当前计数：0')).toBeInTheDocument()

    const button = screen.getByRole('button', { name: '加一' })
    await user.click(button)                  // 模拟真实用户点击
    await user.click(button)

    // 断言用户「看得见」的结果，而不是内部 state
    expect(screen.getByText('当前计数：2')).toBeInTheDocument()
  })
})`,x=`// 测异步 + mock 请求：等异步内容出现、把网络请求替换成假数据
import { render, screen } from '@testing-library/react'
import { vi } from 'vitest'
import UserCard from './UserCard.jsx'

vi.spyOn(global, 'fetch').mockResolvedValue({
  json: async () => ({ name: '小明' }),        // mock：不发真请求，返回假数据
})

it('加载完成后显示用户名', async () => {
  render(<UserCard id={1} />)
  // findBy* 会等待元素出现（内部带重试），适合异步渲染
  expect(await screen.findByText('小明')).toBeInTheDocument()
})`,o=`// 端到端（Playwright）：开一个真浏览器，像真人一样走完整流程
import { test, expect } from '@playwright/test'

test('用户能登录并看到首页', async ({ page }) => {
  await page.goto('http://localhost:5173/login')
  await page.getByLabel('邮箱').fill('a@b.com')
  await page.getByLabel('密码').fill('123456')
  await page.getByRole('button', { name: '登录' }).click()
  await expect(page.getByText('欢迎回来')).toBeVisible()
})`,h=`// 可访问性：用语义标签 + aria + 键盘可达，机器和用户都更友好
function SearchBar() {
  return (
    <form role="search">
      <label htmlFor="q">搜索</label>
      <input id="q" type="search" aria-label="搜索关键词" />
      {/* 用 <button> 而非 <div onClick>，天生可聚焦、可回车触发 */}
      <button type="submit">搜索</button>
    </form>
  )
}`;function m(){return e.jsxs("article",{children:[e.jsxs(n,{children:["这是整门课的最后一章，分两半。前半补上工程化里最后一块拼图——",e.jsx("strong",{children:"测试"}),"： 测试金字塔在前端长什么样、React Testing Library 的核心哲学、怎么测交互与异步、 端到端测试与可访问性各是什么。后半把这门课走过的所有领域汇成一张",e.jsx("strong",{children:"React 生态地图"}),"，再给一条进阶学习路径，为你这段学习收束。"]}),e.jsx("h2",{children:"一、测试金字塔在前端的样子"}),e.jsxs(r,{children:["测试金字塔的主张是：",e.jsx("strong",{children:"底层多、上层少"}),"。大量便宜又快的单元测试垫底， 中间是数量适中的集成测试，顶上是少量但昂贵的端到端测试。越往上，越接近真实用户， 但也越慢、越脆、越难维护——所以要「少而精」。"]}),e.jsx("p",{children:"把这个金字塔翻译到前端，三层大致是这样："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"层级"}),e.jsx("th",{children:"测什么"}),e.jsx("th",{children:"工具"}),e.jsx("th",{children:"特点"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("strong",{children:"单元测试"}),"（底，最多）"]}),e.jsx("td",{children:"单个函数、Hook、小组件的逻辑"}),e.jsx("td",{children:"Vitest / Jest"}),e.jsx("td",{children:"快、稳、便宜，秒级跑完成百上千个"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("strong",{children:"集成测试"}),"（中）"]}),e.jsx("td",{children:"几个组件协作、组件 + 状态 + 请求"}),e.jsx("td",{children:"RTL + Vitest"}),e.jsx("td",{children:"更接近真实使用，前端测试的主力区"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("strong",{children:"端到端测试"}),"（顶，最少）"]}),e.jsx("td",{children:"真浏览器里走完整用户流程"}),e.jsx("td",{children:"Playwright / Cypress"}),e.jsx("td",{children:"最真实，但慢、易碎，只覆盖关键路径"})]})]})]}),e.jsx("p",{children:"前端有个值得注意的现实：用 React Testing Library 写的「组件测试」往往横跨单元与集成之间—— 它渲染真实组件、模拟真实交互，比纯函数单测更有价值。所以前端的金字塔， 实践中常常是一个「中间偏胖」的形状，主力火力压在 RTL 组件 / 集成测试上。"}),e.jsx("h2",{children:"二、React Testing Library 的哲学"}),e.jsxs(r,{children:["React Testing Library（RTL）只有一句核心哲学：",e.jsx("strong",{children:"测试越接近用户使用软件的方式， 越能给你信心"}),"。所以它鼓励你按",e.jsx("strong",{children:"用户视角"}),"去找元素和断言—— 查可见文本、查无障碍角色（role）、查标签，而",e.jsx("strong",{children:"不是"}),"去查 class、id 或组件内部 state 这些实现细节。"]}),e.jsxs("p",{children:["为什么避开实现细节？因为实现会变。你把一个 ",e.jsx("code",{children:'<div className="btn-primary">'}),"重构成 ",e.jsx("code",{children:"<button>"}),"，功能没变，但如果测试是按 ",e.jsx("code",{children:".btn-primary"})," 找的， 它就会无谓地挂掉。反之，如果测试是按「名为『提交』的按钮」找的，重构不影响它——",e.jsx("strong",{children:"测试只在功能真的坏了时才失败"}),"，这正是好测试该有的样子。"]}),e.jsx("p",{children:"RTL 的三个高频工具："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"render"}),"：把组件渲染进一个测试用的 DOM 容器。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"screen"}),"：统一的查询入口，配合 ",e.jsx("code",{children:"getByRole"})," /",e.jsx("code",{children:"getByText"})," / ",e.jsx("code",{children:"getByLabelText"})," / ",e.jsx("code",{children:"findByText"})," 等找元素。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"userEvent"}),"：模拟真实用户操作（点击、输入、键盘），比老的",e.jsx("code",{children:"fireEvent"})," 更贴近真实行为（它会触发 hover、focus 等完整事件链）。"]})]}),e.jsxs(t,{variant:"tip",title:"查询优先级：优先 getByRole",children:["RTL 推荐的查询优先级大致是：",e.jsx("code",{children:"getByRole"})," ＞ ",e.jsx("code",{children:"getByLabelText"})," ＞",e.jsx("code",{children:"getByText"})," ＞ …… 最后才是兜底的 ",e.jsx("code",{children:"getByTestId"}),"。 优先用 role / label，既贴近用户与辅助技术看到的界面，又顺带逼着你把可访问性写好。"]}),e.jsx("h2",{children:"三、实战：测一个按钮点击计数"}),e.jsx("p",{children:"先看被测的组件，一个最简单的计数器："}),e.jsx(s,{lang:"jsx",title:"被测组件 Counter.jsx",code:d}),e.jsxs("p",{children:["再看测试。注意它",e.jsx("strong",{children:"从头到尾都站在用户视角"}),"：用「名为『加一』的按钮」找元素、 用 ",e.jsx("code",{children:"userEvent"})," 模拟点击、断言「页面上看得见的文字」从 0 变成 2—— 全程不碰组件内部的 ",e.jsx("code",{children:"count"})," state。"]}),e.jsx(s,{lang:"jsx",title:"Counter.test.jsx：用 RTL 测点击计数",code:l}),e.jsxs(c,{title:"读懂这个测试的三段式：渲染 → 操作 → 断言",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"渲染"}),"：",e.jsx("code",{children:"render(<Counter />)"})," 把组件挂进测试 DOM。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"操作"}),"：",e.jsx("code",{children:"screen.getByRole('button', ...)"})," 找到按钮，",e.jsx("code",{children:"user.click(button)"})," 模拟两次点击。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"断言"}),"：",e.jsx("code",{children:"screen.getByText('当前计数：2')"})," 验证用户最终 看见的是「2」。测的是",e.jsx("strong",{children:"用户能观察到的结果"}),"，而非内部状态——这就是 RTL 哲学的落地。"]})]}),e.jsx("h2",{children:"四、测异步与 mock 请求（一句话）"}),e.jsxs("p",{children:["组件常常要异步拉数据。测异步时，用 ",e.jsx("code",{children:"findBy*"})," 系列查询——它会",e.jsx("strong",{children:"自动等待"}),"元素出现（内部带重试与超时）；同时把真实网络请求",e.jsx("strong",{children:"mock 掉"}),"（用 ",e.jsx("code",{children:"vi.fn()"})," / ",e.jsx("code",{children:"vi.spyOn"})," 或 MSW 拦截）， 让测试不依赖真后端、稳定又快。"]}),e.jsx(s,{lang:"jsx",title:"测异步 + mock fetch",code:x}),e.jsx("h2",{children:"五、端到端测试（一句话）"}),e.jsxs("p",{children:[e.jsx("strong",{children:"端到端（E2E）"}),"测试用 Playwright 或 Cypress 开一个",e.jsx("strong",{children:"真实浏览器"}),"， 像真人一样点击、输入、跳转，验证「登录→下单→支付」这类完整关键流程能跑通——最真实， 但也最慢最脆，所以只覆盖核心路径，数量保持在金字塔顶端。"]}),e.jsx(s,{lang:"js",title:"Playwright 端到端：走完整登录流程",code:o}),e.jsx("h2",{children:"六、可访问性（a11y）简述"}),e.jsx("p",{children:"可访问性（accessibility，常缩写 a11y）让残障用户也能用你的应用，同时顺带改善 SEO 和 测试体验。三条最常落地的实践："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"语义标签"}),"：用 ",e.jsx("code",{children:"<button>"}),"、",e.jsx("code",{children:"<nav>"}),"、",e.jsx("code",{children:"<main>"}),"、",e.jsx("code",{children:"<label>"})," 等，而不是一律用",e.jsx("code",{children:"<div>"})," 拼。语义标签自带角色与键盘行为。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"aria 属性"}),"：当语义标签不够表达时，用 ",e.jsx("code",{children:"aria-label"}),"、",e.jsx("code",{children:"aria-expanded"})," 等补充信息，让屏幕阅读器读得懂。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"键盘可达"}),"：所有可交互元素都要能用 ",e.jsx("code",{children:"Tab"})," 聚焦、用回车 / 空格触发。 用 ",e.jsx("code",{children:"<button>"})," 就自动满足，用 ",e.jsx("code",{children:"<div onClick>"})," 则不行。"]})]}),e.jsx(s,{lang:"jsx",title:"可访问的搜索框",code:h}),e.jsxs(t,{variant:"info",title:"a11y 和 RTL 是一对好搭档",children:["写好可访问性，RTL 的 ",e.jsx("code",{children:"getByRole"})," / ",e.jsx("code",{children:"getByLabelText"})," 就更好用—— 因为它们查的正是无障碍角色与标签。可以说，把界面写得对辅助技术友好， 测试也会跟着变好写。两件事互相成全。"]}),e.jsx("h2",{children:"七、React 生态地图"}),e.jsx("p",{children:"走到这里，这门课覆盖的领域可以汇成一张地图。每个领域都有几个主流选择， 括号里是这门课重点讲过或最值得先掌握的："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"领域"}),e.jsx("th",{children:"主流选择"}),e.jsx("th",{children:"一句话定位"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"构建工具"}),e.jsx("td",{children:e.jsx("strong",{children:"Vite"})}),e.jsx("td",{children:"极快的开发服务器与打包，现代 React 项目默认起点"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"状态管理"}),e.jsxs("td",{children:["Context / ",e.jsx("strong",{children:"Redux Toolkit"})," / ",e.jsx("strong",{children:"Zustand"})]}),e.jsx("td",{children:"从内置 Context 到轻量 Zustand 到规范的 RTK，按规模选"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"路由"}),e.jsx("td",{children:e.jsx("strong",{children:"React Router"})}),e.jsx("td",{children:"SPA 路由的事实标准"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"服务端数据"}),e.jsx("td",{children:e.jsx("strong",{children:"TanStack Query"})}),e.jsx("td",{children:"请求缓存、重试、失效、后台刷新，管「服务端状态」的利器"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"UI 组件库"}),e.jsxs("td",{children:["MUI / antd / ",e.jsx("strong",{children:"shadcn/ui"})]}),e.jsx("td",{children:"从成套设计体系到可复制进项目的组件，按风格与控制度选"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"测试"}),e.jsxs("td",{children:[e.jsx("strong",{children:"RTL"})," + ",e.jsx("strong",{children:"Vitest"})," / Playwright"]}),e.jsx("td",{children:"组件与单元测试用 RTL+Vitest，端到端用 Playwright"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"全栈框架"}),e.jsxs("td",{children:[e.jsx("strong",{children:"Next.js"})," / Remix"]}),e.jsx("td",{children:"需要 SSR/SSG/RSC、要 SEO 或全栈一体时上场"})]})]})]}),e.jsx("h2",{children:"八、一条进阶学习路径"}),e.jsx("p",{children:"地图很大，但有先后。一条务实的进阶顺序："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"1. 夯实基础"}),"：把组件、Hooks、状态提升、列表与 key、受控组件 这些核心心智模型练到肌肉记忆——这是一切的地基。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"2. 工程化骨架"}),"：用 Vite 起项目，配上 React Router 做路由， 引入一个状态方案（先 Context / Zustand，规模大了再上 RTK）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"3. 数据层"}),"：用 TanStack Query 接管服务端数据， 理解「服务端状态 ≠ 客户端状态」，告别手写 loading / error / 缓存。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"4. 质量保障"}),"：用 RTL + Vitest 给关键组件补测试， 再用 Playwright 守住一两条核心流程，养成测试习惯。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"5. 渲染架构"}),"：当项目需要 SEO 或好首屏，学 Next.js 与 RSC， 掌握 SSR/SSG/ISR 的取舍（上一章讲过）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"6. 持续打磨"}),"：可访问性、性能优化（memo / 代码分割 / 懒加载）、 TypeScript——这些会让你从「能写」走向「写得好」。"]})]}),e.jsxs(t,{variant:"tip",title:"别想着一口吃成胖子",children:["生态地图上的工具不必一次学完。真正的成长来自",e.jsx("strong",{children:"带着真实项目去用"}),"： 遇到状态乱了再认真学状态管理，遇到请求满天飞再上 TanStack Query， 遇到要 SEO 再学 Next。工具是用来解决问题的，按需引入，才记得牢、用得对。"]}),e.jsx("h2",{children:"九、收束：你已经走完这门课"}),e.jsx("p",{children:"从最初的「JSX 是什么、组件怎么写」，到状态与 Hooks、列表与表单、路由与数据、 状态管理、性能、再到渲染架构与测试——你已经把现代 React 开发的主干完整地走了一遍。 剩下的，是在真实项目里把这些知识反复磨成手感。React 生态一直在演进， 但你这门课打下的心智模型（声明式 UI、单向数据流、组件组合、按需引入工具）是稳定的根基。 带着它，去做点真东西吧。"}),e.jsx(i,{points:["前端测试金字塔：底层大量单元测试（Vitest/Jest）、中层集成测试（RTL）、顶层少量端到端（Playwright/Cypress）；前端实践中常中间偏胖。","RTL 的核心哲学：测试越接近用户使用方式越有信心；按可见文本 / role / label 查找与断言，不碰 class、id、内部 state 等实现细节。","RTL 三件套：render 渲染组件、screen 查询元素、userEvent 模拟真实交互；查询优先 getByRole。","测点击计数的范式是「渲染→操作→断言」，断言用户看得见的结果而非内部状态。","测异步用 findBy* 自动等待，mock 请求让测试不依赖真后端；E2E 用真浏览器走关键流程，只覆盖核心路径。","可访问性靠语义标签 + aria + 键盘可达；写好 a11y 也让 getByRole/getByLabelText 更好用，互相成全。","React 生态地图：构建 Vite、状态 Context/RTK/Zustand、路由 React Router、数据 TanStack Query、UI MUI/antd/shadcn、测试 RTL/Vitest/Playwright、框架 Next/Remix。","进阶路径：基础 → Vite+路由+状态 → TanStack Query 数据层 → RTL/Playwright 测试 → Next/RSC 渲染架构 → a11y/性能/TS 打磨；按需引入，带真实项目去学。"]})]})}export{m as default};
