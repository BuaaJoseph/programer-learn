import{j as e}from"./index-I8-WI4LI.js";import{L as o,S as s}from"./Summary-BMIdTn04.js";import{K as a}from"./KeyIdea-Xbvwo63C.js";import{C as t}from"./Callout-ZgrsOCpc.js";import{C as r}from"./CodeBlock-CK6ncc4Q.js";import{E as n}from"./Example-CPIFvVrE.js";const d=`// 老套路：组件挂载后才在 useEffect 里取数
function PostDetail() {
  const { id } = useParams()
  const [post, setPost] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    fetch('/api/posts/' + id)
      .then((r) => r.json())
      .then(setPost)
      .finally(() => setLoading(false))
  }, [id])

  if (loading) return <p>加载中...</p>
  return <h1>{post.title}</h1>
}
// 问题：先渲染空壳 → 再发请求 → 再渲染内容，出现「闪一下」的瀑布流`,i=`import { createBrowserRouter, RouterProvider } from 'react-router-dom'

// Data Router：把路由配置写成一个数据结构（数组），而不是 JSX 树
const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      {
        path: 'posts/:id',
        element: <PostDetail />,
        // loader：进入这个路由「之前」就去取数
        loader: async ({ params }) => {
          const res = await fetch('/api/posts/' + params.id)
          if (!res.ok) throw new Response('未找到', { status: 404 })
          return res.json()
        },
      },
    ],
  },
])

// 用 RouterProvider 挂载，而不是 <BrowserRouter>
function App() {
  return <RouterProvider router={router} />
}`,c=`import { useLoaderData } from 'react-router-dom'

// 组件不再自己 fetch，进来时数据已经备好
function PostDetail() {
  const post = useLoaderData()  // 直接拿到 loader 返回的数据
  return (
    <article>
      <h1>{post.title}</h1>
      <p>{post.body}</p>
    </article>
  )
}
// 没有 loading 闪屏：导航时框架会等 loader 完成再切换视图`,l=`import { Form, redirect, useNavigation } from 'react-router-dom'

// action：处理表单「写」操作（新增 / 编辑 / 删除）
const newPostRoute = {
  path: 'posts/new',
  element: <NewPost />,
  action: async ({ request }) => {
    // request 是标准 Request，formData() 拿到提交的字段
    const form = await request.formData()
    const title = form.get('title')
    const res = await fetch('/api/posts', {
      method: 'POST',
      body: JSON.stringify({ title }),
    })
    const created = await res.json()
    // 提交成功后重定向到详情页
    return redirect('/posts/' + created.id)
  },
}

function NewPost() {
  const nav = useNavigation()  // 读取导航 / 提交状态
  const submitting = nav.state === 'submitting'
  return (
    // 用 React Router 的 <Form>，提交会触发同路径的 action，而非整页刷新
    <Form method="post">
      <input name="title" placeholder="标题" />
      <button disabled={submitting}>{submitting ? '提交中...' : '发布'}</button>
    </Form>
  )
}`,u=`import { useRouteError, isRouteErrorResponse } from 'react-router-dom'

// loader / action 里抛出的错误，会被最近的 errorElement 捕获
const route = {
  path: 'posts/:id',
  element: <PostDetail />,
  loader: postLoader,
  errorElement: <PostError />,  // loader 抛错时渲染它，而不是让整个应用崩
}

function PostError() {
  const error = useRouteError()  // 拿到抛出的错误对象
  // 区分「HTTP 响应式错误」和「真正的 JS 异常」
  if (isRouteErrorResponse(error)) {
    return <h1>{error.status} —— {error.statusText}</h1>
  }
  return <h1>出错了：{error.message}</h1>
}`,h=`import { Suspense } from 'react'
import { useLoaderData, Await, defer } from 'react-router-dom'

// defer：让慢数据「流式」返回——快数据先到先渲染，慢数据用占位符等
const route = {
  path: 'dashboard',
  loader: () => {
    return defer({
      user: getUser(),            // 快，await 等它
      stats: getStatsSlow(),      // 慢，先不 await，作为 Promise 透传
    })
  },
  element: <Dashboard />,
}

function Dashboard() {
  const { user, stats } = useLoaderData()
  return (
    <div>
      <h1>{user.name}</h1>
      {/* Await 配合 Suspense：stats 到了再渲染，没到时显示 fallback */}
      <Suspense fallback={<p>统计加载中...</p>}>
        <Await resolve={stats}>{(s) => <Stats data={s} />}</Await>
      </Suspense>
    </div>
  )
}`,x=`// 路由级 lazy：把某个路由的组件 + loader + action 拆成独立代码块，按需加载
const router = createBrowserRouter([
  {
    path: '/dashboard',
    // lazy 返回一个动态 import，命中该路由时才下载这块代码
    lazy: () => import('./routes/dashboard.jsx'),
  },
])

// ./routes/dashboard.jsx —— 导出约定的字段，框架会自动接上
export function loader({ params }) {
  return fetchDashboard()
}
export function action({ request }) {
  return saveDashboard(request)
}
// 注意：约定导出名为 Component（而非 default），框架用它当 element
export function Component() {
  const data = useLoaderData()
  return <DashboardView data={data} />
}`,j=`import { createBrowserRouter, RouterProvider } from 'react-router-dom'

// 一张带 loader + action + lazy 的完整路由表
const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    errorElement: <RootError />,        // 全局兜底：任何子路由抛错都能接住
    children: [
      { index: true, element: <Home /> },

      // 文章列表：进入前 loader 取数
      {
        path: 'posts',
        element: <PostList />,
        loader: async () => fetch('/api/posts').then((r) => r.json()),
      },

      // 文章详情：动态参数 + loader + 局部 errorElement
      {
        path: 'posts/:id',
        element: <PostDetail />,
        loader: async ({ params }) => {
          const res = await fetch('/api/posts/' + params.id)
          if (!res.ok) throw new Response('Not Found', { status: 404 })
          return res.json()
        },
        errorElement: <PostError />,
      },

      // 新建文章：action 处理 <Form> 提交
      {
        path: 'posts/new',
        element: <NewPost />,
        action: async ({ request }) => {
          const form = await request.formData()
          await fetch('/api/posts', { method: 'POST', body: form })
          return redirect('/posts')
        },
      },

      // 重型后台：路由级 lazy 做代码分割，命中才下载
      {
        path: 'admin',
        lazy: () => import('./routes/admin.jsx'),
      },

      { path: '*', element: <NotFound /> },
    ],
  },
])

export default function App() {
  return <RouterProvider router={router} />
}`;function E(){return e.jsxs("article",{children:[e.jsxs(o,{children:["上一章我们用 ",e.jsx("code",{children:"<Routes>"})," / ",e.jsx("code",{children:"<Route>"})," 把 URL 映射到了组件。 但「取数据」这件事还散落在各个组件的 ",e.jsx("code",{children:"useEffect"})," 里：先渲染空壳、再发请求、 再补上内容，到处是 loading 闪屏。React Router 从 v6.4 起引入了",e.jsx("strong",{children:"数据路由（Data Router）"}),"，把取数、表单提交、报错、懒加载统统收进路由配置。 这一章讲透 loader / action / errorElement / defer / lazy 这套数据 API， 以及它和 Remix、Next 等框架的关系。"]}),e.jsx("h2",{children:"一、痛点：取数为什么不该写在 useEffect 里"}),e.jsxs("p",{children:["在传统写法里，组件得先挂载、再在 ",e.jsx("code",{children:"useEffect"})," 里 fetch。结果是一条",e.jsx("strong",{children:"渲染瀑布流"}),"：空壳 → loading → 数据。每进一个页面都闪一下； 嵌套组件各自取数时，瀑布层层叠加，体验更糟。"]}),e.jsx(r,{lang:"jsx",title:"老套路：useEffect 里取数的瀑布流",code:d}),e.jsxs(a,{children:["Data Router 的核心思路是",e.jsx("strong",{children:"「先取数，后渲染」"}),"：把取数提前到 「进入路由之前」。导航被点击时，框架先跑该路由的 loader，等数据就绪再切换视图， 组件一挂载就能直接拿到数据，没有空壳闪屏。"]}),e.jsx("h2",{children:"二、Data Router：createBrowserRouter + RouterProvider"}),e.jsxs("p",{children:["要用上这套能力，得换一种声明路由的方式。不再用 JSX 包 ",e.jsx("code",{children:"<BrowserRouter>"}),"， 而是用 ",e.jsx("code",{children:"createBrowserRouter"})," 把路由写成",e.jsx("strong",{children:"一个数据结构（对象数组）"}),"， 再用 ",e.jsx("code",{children:"<RouterProvider router={router} />"})," 挂载。正因为路由是数据，框架才能在 渲染前就「读懂」每条路由挂了哪个 loader、要不要懒加载。"]}),e.jsx(r,{lang:"jsx",title:"createBrowserRouter：把路由写成数据",code:i}),e.jsxs(t,{variant:"info",title:"为什么必须是数据形态",children:["声明式 ",e.jsx("code",{children:"<Routes>"})," 是 JSX，框架要等组件渲染时才知道路由长什么样， 没法在导航前预先取数。",e.jsx("code",{children:"createBrowserRouter"})," 接收的是普通对象数组， 框架在任何渲染之前就拥有完整路由图，于是能做「进页面前先跑 loader」这类提前调度。"]}),e.jsx("h2",{children:"三、loader：进入路由前取数，useLoaderData 读取"}),e.jsxs("p",{children:[e.jsx("code",{children:"loader"})," 是挂在路由上的",e.jsx("strong",{children:"取数函数"}),"。导航到该路由时，框架先 await 它， 拿到的返回值就成了这条路由的数据。组件里用 ",e.jsx("code",{children:"useLoaderData()"})," 直接读， 不再需要自己 fetch、不再需要 loading 分支。loader 收到的参数里有",e.jsx("code",{children:"params"}),"（路径动态段）和 ",e.jsx("code",{children:"request"}),"（标准 Request，可读查询串）。"]}),e.jsx(r,{lang:"jsx",title:"useLoaderData：组件直接拿数据",code:c}),e.jsxs("p",{children:["想给「正在导航、数据还没到」一个反馈？用 ",e.jsx("code",{children:"useNavigation()"})," 读全局导航状态 （",e.jsx("code",{children:"idle"})," / ",e.jsx("code",{children:"loading"})," / ",e.jsx("code",{children:"submitting"}),"），在布局层显示一条进度条即可， 不必每个组件各写一套 loading。"]}),e.jsx("h2",{children:"四、action 与 Form：处理表单提交"}),e.jsxs("p",{children:["loader 管「读」，",e.jsx("code",{children:"action"})," 管「写」——新增、编辑、删除。配套的是 React Router 的",e.jsx("code",{children:"<Form>"})," 组件：它长得像原生表单，但提交时不会整页刷新，而是触发",e.jsx("strong",{children:"同路径的 action"}),"。action 收到标准 ",e.jsx("code",{children:"Request"}),"，用",e.jsx("code",{children:"request.formData()"})," 取字段，处理完常用 ",e.jsx("code",{children:"redirect()"})," 跳转。 提交完成后，框架还会",e.jsx("strong",{children:"自动重新跑相关 loader"}),"，让列表等数据保持最新。"]}),e.jsx(r,{lang:"jsx",title:"action + Form：声明式的表单写操作",code:l}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"能力"}),e.jsx("th",{children:"loader"}),e.jsx("th",{children:"action"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"方向"}),e.jsx("td",{children:"读（GET 语义）"}),e.jsx("td",{children:"写（POST / PUT / DELETE 语义）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"触发时机"}),e.jsx("td",{children:"进入路由前自动触发"}),e.jsx("td",{children:"提交 Form 或调 submit 时触发"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"读取数据"}),e.jsx("td",{children:e.jsx("code",{children:"useLoaderData()"})}),e.jsx("td",{children:e.jsx("code",{children:"useActionData()"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"提交后"}),e.jsx("td",{children:"—"}),e.jsx("td",{children:"自动重跑相关 loader，刷新数据"})]})]})]}),e.jsx("h2",{children:"五、errorElement 与 useRouteError：路由级错误边界"}),e.jsxs("p",{children:["loader / action 里抛出的错误，不该让整个应用白屏。给路由配",e.jsx("code",{children:"errorElement"}),"，抛错时就渲染它，而不是正常的 ",e.jsx("code",{children:"element"}),"。 错误组件里用 ",e.jsx("code",{children:"useRouteError()"})," 拿到错误对象，并用",e.jsx("code",{children:"isRouteErrorResponse()"})," 区分「抛出的 Response（如 404）」和「真正的 JS 异常」。 错误会",e.jsx("strong",{children:"冒泡"}),"到最近的 errorElement，所以在根路由放一个就能全局兜底。"]}),e.jsx(r,{lang:"jsx",title:"errorElement + useRouteError：优雅报错",code:u}),e.jsxs(t,{variant:"warn",title:"抛 Response 还是抛 Error",children:["在 loader 里遇到「资源不存在」这类业务情况，推荐 ",e.jsxs("code",{children:["throw new Response(..., ","{ status: 404 }",")"]}),"， 这样 ",e.jsx("code",{children:"isRouteErrorResponse"})," 能识别成 HTTP 式错误并读到 status； 而代码 bug 抛出的普通 ",e.jsx("code",{children:"Error"})," 走另一分支。两者分开处理，错误页才能给出贴切提示。"]}),e.jsx("h2",{children:"六、defer / Await：慢数据流式返回"}),e.jsxs("p",{children:["如果一个页面里既有快数据（用户信息）又有慢数据（统计报表），全等齐再渲染就太慢。",e.jsx("code",{children:"defer()"})," 让你把慢数据当 Promise ",e.jsx("strong",{children:"透传"}),"而不 await：快数据先渲染， 慢数据用 ",e.jsx("code",{children:"<Await>"})," 包起来配合 ",e.jsx("code",{children:"<Suspense>"}),"，到了再补上、 没到时显示占位符。一句话：",e.jsx("strong",{children:"关键内容秒开，次要内容流式补齐"}),"。"]}),e.jsx(r,{lang:"jsx",title:"defer + Await：流式数据",code:h}),e.jsx("h2",{children:"七、路由级 lazy：按需加载，做代码分割"}),e.jsxs("p",{children:["把所有页面的代码塞进一个大 bundle，首屏会很重。",e.jsx("code",{children:"route.lazy"})," 让你给路由配一个",e.jsx("strong",{children:"动态 import"}),"：只有当用户真正导航到该路由时，才下载这块代码（含它的组件、 loader、action）。重型后台、低频页面用它，能显著减小首屏体积。"]}),e.jsx(r,{lang:"jsx",title:"route.lazy：路由级代码分割",code:x}),e.jsxs(t,{variant:"info",title:"与 r8 懒加载呼应",children:["这正是后面 r8 卷讲的「懒加载 / 代码分割」在路由层的落地。组件级你会用",e.jsx("code",{children:"React.lazy"})," + ",e.jsx("code",{children:"<Suspense>"})," 拆单个组件；路由级则用",e.jsx("code",{children:"route.lazy"})," 拆「整页连带它的数据逻辑」。两者都基于打包器的动态",e.jsx("code",{children:"import()"})," 切分代码块，只是切分的粒度不同——路由级往往是性价比最高的第一刀。"]}),e.jsx("h2",{children:"八、综合示例：带 loader + action + lazy 的路由表"}),e.jsx("p",{children:"把读、写、报错、分割都放进一张表里，就是一个生产味道的路由配置："}),e.jsx(r,{lang:"jsx",title:"完整路由表：loader + action + errorElement + lazy",code:j}),e.jsxs(n,{title:"跟着一次操作走一遍数据流",children:[e.jsxs("p",{children:["用户点进 ",e.jsx("code",{children:"/posts/2"}),"：框架先跑该路由 loader 去 ",e.jsx("code",{children:"/api/posts/2"})," 取数； 若返回 404，loader 抛 Response，被 ",e.jsx("code",{children:"PostError"})," 接住；正常则数据就绪后 渲染 PostDetail，组件里 ",e.jsx("code",{children:"useLoaderData()"})," 直接拿到文章。"]}),e.jsxs("p",{children:["用户在 ",e.jsx("code",{children:"/posts/new"})," 提交 Form：触发该路由 action，POST 到后端， 成功后 ",e.jsx("code",{children:"redirect('/posts')"}),"，框架顺带重跑 posts 的 loader，列表立刻含新文章。"]}),e.jsxs("p",{children:["用户首次点进 ",e.jsx("code",{children:"/admin"}),"：此时才下载 admin 那块代码（lazy），不拖慢首屏。"]})]}),e.jsx("h2",{children:"九、与框架的关系：Remix / React Router 框架模式 / Next"}),e.jsxs("p",{children:["loader / action 这套设计并非凭空而来——它源自 ",e.jsx("strong",{children:"Remix"}),"（同一个团队的全栈框架）， 后来被吸收进 React Router。在 React Router v7 里，库本身又长出了「框架模式」， 和 Remix 进一步融合，能做服务端渲染、嵌套数据加载等。"]}),e.jsxs("p",{children:["而 ",e.jsx("strong",{children:"Next.js"})," 走的是另一条路：App Router 里用服务端组件 + ",e.jsx("code",{children:"async"}),"组件直接在服务端取数，约定式文件路由。两者目标相近（取数贴近路由、减少瀑布流）， 但落点不同——React Router 的 Data Router 主打",e.jsx("strong",{children:"纯客户端也能用的数据路由"}),"， 而 Next / Remix 把取数推到了服务端。本卷我们聚焦纯前端，所以用 Data Router 这一侧。"]}),e.jsx("h2",{children:"十、小结"}),e.jsx("p",{children:"Data Router 把「数据」抬到了和「路由」同等的位置：进页面前 loader 取好数、Form 提交走 action、出错有 errorElement 兜底、慢数据用 defer 流式补齐、重型页用 lazy 按需加载。 组件因此回归本职——专心渲染。至此 r6 卷的路由两章就齐了：第一章解决「URL 映射组件」， 这一章解决「路由层面管数据」。"}),e.jsx(s,{points:["Data Router 用 createBrowserRouter（路由写成数据）+ RouterProvider 挂载，换来「先取数后渲染」的能力，消除 useEffect 取数的瀑布流闪屏。","loader 在进入路由前取数，组件用 useLoaderData 直接读，无需自写 fetch 与 loading 分支；useNavigation 读全局导航状态。","action 配 <Form> 处理写操作，用 request.formData 取字段、redirect 跳转，提交后框架自动重跑相关 loader 刷新数据。","errorElement + useRouteError 做路由级错误边界，isRouteErrorResponse 区分 HTTP 响应错误与 JS 异常，错误冒泡到最近的 errorElement。","defer + Await + Suspense 让慢数据流式返回，快内容先渲染；route.lazy 做路由级代码分割，命中才下载该页代码，与 r8 懒加载呼应。","loader/action 源自 Remix，已并入 React Router（v7 有框架模式）；Next App Router 走服务端取数的另一条路，本卷聚焦纯前端的 Data Router。"]})]})}export{E as default};
