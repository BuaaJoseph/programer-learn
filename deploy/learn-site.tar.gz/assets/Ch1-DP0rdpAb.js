import{j as e}from"./index-qtIRnDEm.js";import{L as n,S as d}from"./Summary-D7M9FdYM.js";import{K as t}from"./KeyIdea-C5mX38F7.js";import{C as r}from"./Callout-Bvq_rfqV.js";import{C as s}from"./CodeBlock-DsDQiuPI.js";import{E as i}from"./Example-Ba1iSJHN.js";const c=`<!-- 纯客户端渲染（CSR）下，服务器吐回的 HTML 几乎是空的 -->
<!doctype html>
<html>
  <head><title>我的应用</title></head>
  <body>
    <div id="root"></div>              <!-- 一个空壳 -->
    <script src="/assets/bundle.js"><\/script>
    <!-- 浏览器要：下载 bundle → 执行 React → 拉数据 → 才画出内容 -->
  </body>
</html>`,l=`// SSR：服务器在响应请求时，先把 React 组件渲染成 HTML 字符串
import { renderToString } from 'react-dom/server'
import App from './App.jsx'

app.get('*', async (req, res) => {
  const data = await fetchData(req.url)       // 服务端先把数据准备好
  const html = renderToString(<App data={data} />)  // 组件 → HTML 字符串
  res.send(\`
    <!doctype html>
    <html>
      <body>
        <div id="root">\${html}</div>          <!-- 首屏内容已经在 HTML 里 -->
        <script>window.__DATA__ = \${JSON.stringify(data)}<\/script>
        <script src="/assets/bundle.js"><\/script>
      </body>
    </html>\`)
})`,h=`// 客户端：不是重新渲染，而是「注水」——给已有的 HTML 接上事件
import { hydrateRoot } from 'react-dom/client'
import App from './App.jsx'

// 服务端塞进来的数据，客户端首屏必须用同一份，否则结构对不上
const data = window.__DATA__

hydrateRoot(
  document.getElementById('root'),
  <App data={data} />,
)`,o=`function Clock() {
  // 反例：服务端渲染出的时间，和客户端注水时的时间不可能一样
  // 服务端 HTML 是 "12:00:00"，客户端注水时已是 "12:00:03"
  // → React 警告 "Hydration failed / Text content did not match"
  return <span>{new Date().toLocaleTimeString()}</span>
}

// 正解：首屏先渲染稳定值，挂载后再用 effect 切到真实值
function Clock() {
  const [time, setTime] = React.useState(null)
  React.useEffect(() => {
    const id = setInterval(() => setTime(new Date().toLocaleTimeString()), 1000)
    return () => clearInterval(id)
  }, [])
  return <span>{time ?? '加载中…'}</span>
}`,x=`app/
├─ layout.jsx          // 根布局：包裹所有页面（<html><body>）
├─ page.jsx            // 路由 "/"
├─ about/
│  └─ page.jsx         // 路由 "/about"
└─ blog/
   └─ [slug]/
      └─ page.jsx      // 动态路由 "/blog/:slug"

// App Router 里，page.jsx 默认就是「服务端组件」`,j=`// app/posts/page.jsx —— 默认是 React Server Component（RSC）
// 没有 'use client'：这段代码只在服务端跑，不会进客户端 bundle
import db from '@/lib/db'

export default async function Posts() {
  // 服务端组件可以直接 await，直接访问数据库 / 文件系统
  const posts = await db.post.findMany()
  return (
    <ul>
      {posts.map((p) => (
        <li key={p.id}>{p.title}</li>
      ))}
    </ul>
  )
}`,a=`// app/components/LikeButton.jsx —— 客户端组件
'use client'                       // 这一行声明：我要在浏览器里跑
import { useState } from 'react'

export default function LikeButton() {
  const [n, setN] = useState(0)    // 有状态 / 事件 → 必须是客户端组件
  return <button onClick={() => setN(n + 1)}>赞 {n}</button>
}`;function T(){return e.jsxs("article",{children:[e.jsxs(n,{children:["到这里，你已经会用 React 组件、Hooks、状态管理、路由和数据请求搭出一个像样的应用。 但这些应用有一个共同前提：所有渲染都发生在",e.jsx("strong",{children:"浏览器"}),"里。这一章我们把视角抬高， 看看渲染到底可以发生在",e.jsx("strong",{children:"哪里、什么时候"}),"——CSR、SSR、SSG、ISR 四种策略， 注水（hydration）这个关键概念，以及把它们整合在一起的全栈框架 Next.js 与它带来的 React Server Components（RSC）。这是从「写组件」迈向「设计渲染架构」的一章。"]}),e.jsx("h2",{children:"一、纯客户端渲染（CSR）的短板"}),e.jsxs("p",{children:["我们到目前为止写的应用（用 Vite + React Router 那种）几乎都是 ",e.jsx("strong",{children:"CSR"}),"： 服务器返回一个几乎空白的 HTML，里面只有一个 ",e.jsx("code",{children:'<div id="root">'})," 和一个",e.jsx("code",{children:"<script>"}),"。真正的页面内容，要等浏览器把 JS bundle 下载完、执行 React、 再去拉数据，才一点点画出来。"]}),e.jsx(s,{lang:"html",title:"CSR 下服务器返回的 HTML 几乎是空壳",code:c}),e.jsx("p",{children:"这种「先给空壳，再用 JS 填」的模式，在三类场景下会暴露明显短板："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"首屏白屏"}),"：从「服务器返回」到「用户看见内容」之间隔着 下载 JS、解析执行、发请求、等响应好几步。网络越慢、bundle 越大，用户盯着白屏的时间越长。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"SEO 不友好"}),"：很多爬虫拿到的就是那个空壳 HTML，里面没有正文。 虽然现代搜索引擎能执行部分 JS，但并不可靠，也不及时，内容站很吃亏。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"慢设备吃力"}),"：所有渲染计算都压在用户的设备上。低端手机解析执行 一大坨 JS 很慢，首屏可交互时间（TTI）被进一步拉长。"]})]}),e.jsxs("p",{children:["解决思路很自然：",e.jsx("strong",{children:"把一部分渲染工作挪到服务器"}),"，让用户第一时间就拿到 带内容的 HTML。这就引出了下面四种渲染策略。"]}),e.jsx("h2",{children:"二、四种渲染策略：CSR / SSR / SSG / ISR"}),e.jsxs(t,{children:["渲染策略的本质，是回答两个问题：HTML 在",e.jsx("strong",{children:"哪里"}),"生成（浏览器还是服务器）， 以及",e.jsx("strong",{children:"什么时候"}),"生成（用户请求时，还是构建时提前生成）。四种策略就是这两个 维度的不同组合。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"策略"}),e.jsx("th",{children:"HTML 何时 / 何地生成"}),e.jsx("th",{children:"首屏"}),e.jsx("th",{children:"SEO"}),e.jsx("th",{children:"典型场景"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("strong",{children:"CSR"})," 客户端渲染"]}),e.jsx("td",{children:"浏览器运行时生成"}),e.jsx("td",{children:"慢（先白屏）"}),e.jsx("td",{children:"差"}),e.jsx("td",{children:"后台管理、登录后才看的应用"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("strong",{children:"SSR"})," 服务端渲染"]}),e.jsx("td",{children:"每次请求时在服务器生成"}),e.jsx("td",{children:"快（首屏即内容）"}),e.jsx("td",{children:"好"}),e.jsx("td",{children:"内容随用户 / 时间变化的页面"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("strong",{children:"SSG"})," 静态站点生成"]}),e.jsx("td",{children:"构建时提前生成好"}),e.jsx("td",{children:"最快（纯静态文件）"}),e.jsx("td",{children:"好"}),e.jsx("td",{children:"博客、文档、营销页"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("strong",{children:"ISR"})," 增量静态再生"]}),e.jsx("td",{children:"构建时生成 + 按周期在后台重建"}),e.jsx("td",{children:"最快"}),e.jsx("td",{children:"好"}),e.jsx("td",{children:"内容会更新但不需实时的站（如商品页）"})]})]})]}),e.jsxs("p",{children:["简单记：",e.jsx("strong",{children:"CSR 在浏览器"}),"，",e.jsx("strong",{children:"SSR 在每次请求"}),"，",e.jsx("strong",{children:"SSG 在构建时一次性"}),"，",e.jsx("strong",{children:"ISR 是 SSG 加了「过期自动重建」"}),"。 SSR 内容最新但每次请求都要算；SSG 最快但内容是「上次构建时」的快照； ISR 在两者间取平衡——大部分时间发静态文件，过了设定的时间窗才在后台悄悄重建一次。"]}),e.jsxs(i,{title:"同一个博客，三种策略下会怎样",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"SSG"}),"：构建时把每篇文章渲染成 HTML 文件。访问飞快，但发新文章要重新构建部署。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"ISR"}),"：同样先发静态文件，但设 ",e.jsx("code",{children:"revalidate=60"}),"， 60 秒后第一个访问者触发后台重建，新内容随后生效——不用手动重新部署。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"SSR"}),"：每次访问都现场渲染，永远最新，代价是每个请求都消耗服务器算力。 博客这种「内容不常变」的场景，SSG / ISR 通常比 SSR 更划算。"]})]}),e.jsx("h2",{children:"三、SSR 是怎么工作的：renderToString"}),e.jsxs("p",{children:["SSR 的核心 API 是 ",e.jsx("code",{children:"react-dom/server"})," 里的 ",e.jsx("code",{children:"renderToString"}),"（或流式版",e.jsx("code",{children:"renderToPipeableStream"}),"）。它在服务器上把 React 组件树「跑一遍」， 产出纯 HTML 字符串，塞进响应里发给浏览器。"]}),e.jsx(s,{lang:"js",title:"服务端：把组件渲染成 HTML 字符串",code:l}),e.jsxs("p",{children:["注意两个细节：① 服务端要先",e.jsx("strong",{children:"准备好数据"}),"再渲染，否则渲染出来的还是空的； ② 用到的数据要一并塞进 HTML（这里挂在 ",e.jsx("code",{children:"window.__DATA__"})," 上）， 因为客户端马上要用",e.jsx("strong",{children:"同一份数据"}),"来「注水」。这就引出下一节。"]}),e.jsx("h2",{children:"四、注水（hydration）与「不匹配」的坑"}),e.jsxs(t,{children:["注水（hydration）是指：浏览器拿到服务端已经渲染好的 HTML 后，React 不会把它推倒重画， 而是",e.jsx("strong",{children:"复用这些 DOM 节点，只给它们接上事件监听和内部状态"}),"，让这段静态 HTML 「活」过来、变得可交互。就像给一具已经成形的躯体注入水分使其复活。"]}),e.jsxs("p",{children:["客户端用的是 ",e.jsx("code",{children:"hydrateRoot"})," 而不是 ",e.jsx("code",{children:"createRoot"}),"。区别在于：",e.jsx("code",{children:"createRoot"})," 假设容器是空的、从零画起；",e.jsx("code",{children:"hydrateRoot"})," 假设容器里 已经有服务端渲染好的 HTML，它去",e.jsx("strong",{children:"匹配并接管"}),"这些节点。"]}),e.jsx(s,{lang:"js",title:"客户端：注水而非重新渲染",code:h}),e.jsxs("p",{children:["这里有一个新手必踩的坑——",e.jsx("strong",{children:"hydration 不匹配（hydration mismatch）"}),"。 React 注水时会假定「客户端首次渲染出来的结构，应当和服务端发来的 HTML 完全一致」。 一旦对不上，React 会报警告，并可能丢弃服务端 HTML 改为客户端重画，性能与体验双输。"]}),e.jsx(s,{lang:"jsx",title:"hydration 不匹配：反例与正解",code:o}),e.jsxs(r,{variant:"warn",title:"哪些写法会导致 hydration 不匹配",children:["常见元凶：直接渲染 ",e.jsx("code",{children:"Date.now()"})," / ",e.jsx("code",{children:"Math.random()"})," 这类 每次都不同的值；读取只有浏览器才有的 ",e.jsx("code",{children:"window"})," / ",e.jsx("code",{children:"localStorage"})," 来 决定首屏内容；以及服务端和客户端用了不同的数据。原则是：",e.jsx("strong",{children:"首屏渲染必须是确定的、两端一致的"}),"，「只有浏览器才知道」的东西放进",e.jsx("code",{children:"useEffect"})," 里、挂载之后再处理。"]}),e.jsx("h2",{children:"五、Next.js 是什么"}),e.jsxs("p",{children:["手写 SSR 服务器、管理路由、处理数据获取、配置打包……这些拼起来很繁琐。",e.jsx("strong",{children:"Next.js"})," 就是把这些都打包好的",e.jsx("strong",{children:"React 全栈框架"}),"—— 它在 React 之上提供了一整套「开箱即用」的渲染与工程能力，是当下最主流的 React 框架。 它的几个核心能力："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"文件路由"}),"：不用手写路由表，目录结构就是路由。",e.jsx("code",{children:"app/about/page.jsx"})," 自动对应 ",e.jsx("code",{children:"/about"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"App Router"}),"：新一代路由体系（基于 ",e.jsx("code",{children:"app/"})," 目录）， 默认拥抱服务端组件，支持嵌套布局、加载态、错误边界等。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"灵活的渲染策略"}),"：同一个框架里，你可以按页面选择 SSR / SSG / ISR， 上一节那张表里的策略它都支持。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"数据获取"}),"：服务端组件里可以直接 ",e.jsx("code",{children:"await"})," 拉数据， 还内置了请求缓存与重新校验（revalidate）机制。"]})]}),e.jsx(s,{lang:"text",title:"App Router：目录即路由",code:x}),e.jsx("h2",{children:"六、React Server Components（RSC）"}),e.jsxs(t,{children:["React Server Components 的核心思想是：让一部分组件",e.jsx("strong",{children:"只在服务端渲染"}),"， 它们的代码",e.jsx("strong",{children:"完全不进客户端 bundle"}),"（零客户端 JS），还能直接访问数据库、 文件系统等服务端资源。需要交互的部分，再用 ",e.jsx("code",{children:"'use client'"})," 显式标成客户端组件。"]}),e.jsxs("p",{children:["在 App Router 里，组件",e.jsx("strong",{children:"默认是服务端组件（RSC）"}),"。它们只在服务器上运行一次， 把结果发给浏览器，自己的代码（以及它 import 的库）都不会增加客户端 bundle 体积。"]}),e.jsx(s,{lang:"jsx",title:"服务端组件：直接 await 拉数据，零客户端 JS",code:j}),e.jsxs("p",{children:["但服务端组件",e.jsx("strong",{children:"不能"}),"用 ",e.jsx("code",{children:"useState"}),"、",e.jsx("code",{children:"useEffect"}),"、 事件处理器这些「浏览器里才有意义」的东西。一旦组件需要交互，就要在文件顶部加一行",e.jsx("code",{children:"'use client'"}),"，把它声明为",e.jsx("strong",{children:"客户端组件"}),"。"]}),e.jsx(s,{lang:"jsx",title:"客户端组件：用 'use client' 声明",code:a}),e.jsxs(r,{variant:"tip",title:"服务端组件 vs 客户端组件，怎么分",children:["默认走服务端组件（更省、更快、能直连数据源）；只有当组件需要",e.jsx("strong",{children:"状态、事件、生命周期、浏览器 API"})," 时，才用 ",e.jsx("code",{children:"'use client'"})," 把它 以及它的交互子树划到客户端。常见做法是：外层用服务端组件拉数据， 把数据当 props 传给内层的小块客户端组件去做交互——尽量把 ",e.jsx("code",{children:"'use client'"}),"推到叶子节点，客户端 bundle 就最小。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"能力"}),e.jsx("th",{children:"服务端组件（默认）"}),e.jsx("th",{children:"客户端组件（'use client'）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"进客户端 bundle"}),e.jsx("td",{children:"否（零 JS）"}),e.jsx("td",{children:"是"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"直接访问数据库 / 文件"}),e.jsx("td",{children:"可以"}),e.jsx("td",{children:"不可以"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"useState / useEffect"}),e.jsx("td",{children:"不能用"}),e.jsx("td",{children:"能用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"onClick 等事件"}),e.jsx("td",{children:"不能用"}),e.jsx("td",{children:"能用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"访问 window / localStorage"}),e.jsx("td",{children:"不能用"}),e.jsx("td",{children:"能用"})]})]})]}),e.jsx("h2",{children:"七、流式 SSR（streaming）一句话"}),e.jsxs("p",{children:[e.jsx("strong",{children:"流式 SSR"}),"：服务器不必等整页都渲染完才发，而是把 HTML 分块（chunk） 边渲染边推给浏览器——慢的数据区域先用占位骨架顶着（配合 ",e.jsx("code",{children:"<Suspense>"}),"）， 数据就绪后再把那一块补上。用户更早看到内容，慢接口不再拖垮整页首屏。"]}),e.jsx("h2",{children:"八、什么时候你需要 Next，什么时候纯 SPA 就够"}),e.jsx("p",{children:"渲染架构没有银弹，要按场景选。下面是一条务实的判断线："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"你的场景"}),e.jsx("th",{children:"建议"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"内容站、博客、文档、营销官网（要 SEO）"}),e.jsx("td",{children:"Next（SSG / ISR）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"电商、需要 SEO 且内容会变的页面"}),e.jsx("td",{children:"Next（SSR / ISR）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"想前后端一体、用一个框架搞定路由 + 接口"}),e.jsx("td",{children:"Next（全栈）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"登录后才看的后台管理系统 / 内部工具"}),e.jsx("td",{children:"纯 SPA（Vite + React Router）就够"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"无需 SEO、首屏白屏可接受的工具型应用"}),e.jsx("td",{children:"纯 SPA 更轻、心智更简单"})]})]})]}),e.jsxs("p",{children:["一句话总结这条判断线：",e.jsx("strong",{children:"需要 SEO、需要好首屏、想要全栈一体，就上 Next"}),"； 反之，登录后才用、不在乎搜索引擎收录的后台系统，",e.jsx("strong",{children:"纯 SPA 反而更省事"}),"—— 不用养服务器、不用操心 hydration、构建和部署都更简单。别为了「显得先进」而给一个 后台管理系统硬套 SSR。"]}),e.jsxs(r,{variant:"tip",children:["下一章是本课的收束章：我们补上工程化里最后一块拼图——",e.jsx("strong",{children:"测试"}),"， 再用一张「React 生态地图」把这门课走过的构建、状态、路由、数据、UI、测试、框架 各个领域串成一张可带走的全景图，并给出一条进阶学习路径。"]}),e.jsx(d,{points:["CSR 把渲染全压在浏览器：服务器只发空壳 HTML，导致首屏白屏、SEO 差、慢设备吃力。","四种渲染策略：CSR（浏览器运行时）、SSR（每次请求时服务端生成）、SSG（构建时一次性生成）、ISR（SSG + 按周期后台重建）。","SSR 用 renderToString 在服务端产出 HTML；首屏即内容，但每个请求都要算。","hydration（注水）= 浏览器复用服务端 HTML 节点、只接上事件与状态使其可交互；用 hydrateRoot 而非 createRoot。","hydration 不匹配是大坑：Date/random、window、两端数据不一致都会触发；首屏要确定且两端一致，浏览器专属逻辑放进 useEffect。","Next.js 是 React 全栈框架：文件路由、App Router、可按页选 SSR/SSG/ISR、服务端直接取数。","RSC（服务端组件）默认只在服务端渲染、零客户端 JS、能直连数据源；需要交互时用 'use client' 划为客户端组件，尽量下推到叶子。","流式 SSR 把 HTML 分块边渲染边推，配合 Suspense 让慢区域先占位。","内容站 / SEO / 全栈选 Next；登录后看、无需 SEO 的后台系统纯 SPA 更省事。"]})]})}export{T as default};
