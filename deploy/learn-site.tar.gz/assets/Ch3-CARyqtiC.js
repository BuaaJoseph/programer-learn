import{r as l,j as e}from"./index-C4u1Qi4f.js";import{L as c,C as n,a as o,P as d,S as a}from"./Summary-DjSaQefZ.js";import{K as x}from"./KeyIdea-BS4xPn0s.js";import{E as h}from"./Example-DNWIRw6O.js";import{F as j}from"./Figure-D2qsSgWq.js";const p={jdk:{label:"JDK 动态代理",cond:"目标类实现了接口",how:"运行时生成一个实现同样接口的代理类(Proxy)，内部持有目标对象，通过 InvocationHandler 转发并织入切面。",limit:"只能代理接口里的方法。"},cglib:{label:"CGLIB 代理",cond:"目标类没有接口",how:"运行时生成目标类的子类，重写方法、在调用前后织入切面(基于继承)。",limit:"final 类/方法无法被代理(不能被继承/重写)。"}};function f(){const[r,s]=l.useState("jdk"),i=p[r],t=e.jsxs(e.Fragment,{children:[e.jsx("button",{className:`fig-btn ${r==="jdk"?"active":""}`,onClick:()=>s("jdk"),children:"JDK 动态代理"}),e.jsx("button",{className:`fig-btn ${r==="cglib"?"active":""}`,onClick:()=>s("cglib"),children:"CGLIB"}),e.jsx("span",{className:"fig-note",children:i.cond})]});return e.jsx(j,{caption:"AOP(如 @Transactional、日志、权限)靠动态代理实现：调用方拿到的其实是代理对象，它在调用真实方法前后插入切面逻辑。Spring 默认：有接口用 JDK 动态代理、无接口用 CGLIB。",controls:t,children:e.jsxs("svg",{viewBox:"0 0 460 190",width:"460",role:"img","aria-label":"AOP 动态代理",children:[e.jsx("rect",{x:"20",y:"64",width:"80",height:"44",rx:"9",fill:"var(--accent-soft)",stroke:"var(--accent-line)"}),e.jsx("text",{x:"60",y:"90",textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"11",fill:"var(--ink)",children:"调用方"}),e.jsx("rect",{x:"150",y:"50",width:"150",height:"72",rx:"10",fill:"var(--accent)"}),e.jsx("text",{x:"225",y:"70",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"11",fontWeight:"700",fill:"#ffffff",children:"代理对象"}),e.jsx("text",{x:"225",y:"86",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:"#ffffff",children:r==="jdk"?"Proxy(实现接口)":"目标类的子类"}),e.jsx("text",{x:"225",y:"104",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:"#ffffff",children:"前置切面 → 调用 → 后置切面"}),e.jsx("rect",{x:"350",y:"64",width:"90",height:"44",rx:"9",fill:"var(--green-soft)",stroke:"var(--green-line)"}),e.jsx("text",{x:"395",y:"84",textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"11",fill:"var(--green)",children:"目标对象"}),e.jsx("text",{x:"395",y:"98",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:"var(--ink-soft)",children:"真实业务"}),e.jsx("line",{x1:"100",y1:"86",x2:"150",y2:"86",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#ap-a)"}),e.jsx("line",{x1:"300",y1:"86",x2:"350",y2:"86",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#ap-a)"}),e.jsx("defs",{children:e.jsx("marker",{id:"ap-a",markerWidth:"8",markerHeight:"8",refX:"5",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L5,3 L0,6 Z",fill:"var(--ink-faint)"})})}),e.jsx("rect",{x:"20",y:"138",width:"420",height:"48",rx:"8",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsx("foreignObject",{x:"28",y:"142",width:"404",height:"42",children:e.jsxs("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"11.5px var(--sans)",color:"var(--ink)",lineHeight:1.35},children:[e.jsxs("strong",{style:{color:"var(--accent-strong)"},children:[i.label,"："]}),i.how," ",e.jsx("span",{style:{color:"var(--rose)"},children:i.limit})]})})]})})}const g=`@Service
public class OrderService {

    @Transactional
    public void createOrder(Order order) {
        save(order);
        // 同类内部直接调用，走的是原始对象 this，不经过代理
        // 于是 updateStock 上的 @Transactional 完全失效！
        updateStock(order);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateStock(Order order) {
        stockMapper.reduce(order.getSku());
    }
}`,m=`@Service
public class OrderService {

    // 注入自己的代理对象（或抽到另一个 Bean 里）
    @Autowired
    private OrderService self;

    @Transactional
    public void createOrder(Order order) {
        save(order);
        // 通过代理对象调用，@Transactional 才会生效
        self.updateStock(order);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateStock(Order order) {
        stockMapper.reduce(order.getSku());
    }
}`,u=`@Aspect          // 声明这是一个切面
@Component       // 别忘了交给容器管理
public class TimingAspect {

    // 切点：拦截 service 包下所有 public 方法
    @Around("execution(* com.demo.service..*(..))")
    public Object timing(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.currentTimeMillis();
        try {
            // 放行，执行被代理的目标方法
            return pjp.proceed();
        } finally {
            long cost = System.currentTimeMillis() - start;
            String name = pjp.getSignature().toShortString();
            System.out.println(name + " 耗时 " + cost + "ms");
        }
    }
}`;function P(){return e.jsxs(e.Fragment,{children:[e.jsx(c,{children:e.jsxs("p",{children:["事务、日志、权限校验这类逻辑，散落在每个方法里既重复又碍眼。",e.jsx("em",{children:"AOP"}),"（面向切面编程）的思路是：把这些「横切关注点」抽出来集中管理， 再由框架在运行时悄悄织回到目标方法周围。它的底层魔法只有一个词——",e.jsx("strong",{children:"动态代理"}),"： 容器给你的不是原始对象，而是一个套了壳的代理，壳上挂着你的增强逻辑。"]})}),e.jsx("h2",{children:"AOP 的几个核心概念"}),e.jsx("p",{children:"先把术语理顺，面试常要你解释它们的关系："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"切面"}),"（Aspect）：横切逻辑的载体，比如「记录耗时」这件事打包成的一个类。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"连接点"}),"（JoinPoint）：程序执行中可以被插入的点，在 Spring 里就是「方法的执行」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"切点"}),"（Pointcut）：用表达式筛选出「到底要拦哪些连接点」，比如 service 包下所有方法。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"通知"}),"（Advice）：在切点上具体要做的事，以及做的时机（方法前、后、环绕等）。"]})]}),e.jsxs("p",{children:["典型用途就是那几样：",e.jsx("strong",{children:"事务管理"}),"（",e.jsx("code",{children:"@Transactional"})," 本质就是 AOP）、",e.jsx("strong",{children:"统一日志"}),"、",e.jsx("strong",{children:"权限校验"}),"、性能监控等。凡是「和业务无关、却到处都要写」的逻辑，都适合用 AOP。"]}),e.jsx("h2",{children:"两种动态代理：JDK 与 CGLIB"}),e.jsx("p",{children:"Spring AOP 在运行时生成代理，有两种实现方式，到底用哪种取决于目标类有没有实现接口："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"JDK 动态代理"}),"：目标类",e.jsx("strong",{children:"实现了接口"}),"时使用， 基于",e.jsx("strong",{children:"接口"}),"生成一个实现同样接口的代理类。它是 JDK 自带能力（",e.jsx("code",{children:"Proxy"})," + ",e.jsx("code",{children:"InvocationHandler"}),"）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"CGLIB 代理"}),"：目标类",e.jsx("strong",{children:"没有接口"}),"时使用， 通过",e.jsx("strong",{children:"继承"}),"目标类、生成一个子类来做代理，在子类里重写方法插入增强。"]})]}),e.jsxs(h,{title:"@Transactional 内部调用为什么失效",children:[e.jsxs("p",{children:["这是 AOP 最经典的坑。下面这段代码里，",e.jsx("code",{children:"updateStock"})," 上的事务注解形同虚设："]}),e.jsx(n,{lang:"java",title:"OrderService.java（有 bug）",code:g}),e.jsxs("p",{children:["原因在于 AOP 增强是挂在",e.jsx("strong",{children:"代理对象"}),"上的。外部调用 ",e.jsx("code",{children:"createOrder"}),"时走的是代理，没问题；但在 ",e.jsx("code",{children:"createOrder"})," 内部直接写 ",e.jsx("code",{children:"updateStock(order)"}),"， 等价于 ",e.jsx("code",{children:"this.updateStock(order)"}),"，调用的是",e.jsx("strong",{children:"原始对象"}),"， 根本没经过代理，于是 ",e.jsx("code",{children:"updateStock"})," 上的事务、日志等增强统统失效。 这就是「同类内部方法自调用导致 AOP 失效」。"]})]}),e.jsx(f,{}),e.jsx(x,{title:"Spring Boot 默认强制用 CGLIB",children:e.jsxs("p",{children:["早期 Spring 的规则是「有接口用 JDK、无接口用 CGLIB」。但从 Spring Boot 2.x 起， 自动配置",e.jsx("strong",{children:"默认强制使用 CGLIB"}),"（",e.jsx("code",{children:"proxy-target-class=true"}),"）， 即便目标类实现了接口也走 CGLIB。这样做是为了行为统一、避免「注入接口能拿到代理、注入实现类却拿不到」之类的坑。 想改回 JDK 代理可以把这个开关设为 ",e.jsx("code",{children:"false"}),"，但通常没必要。"]})}),e.jsx("h3",{children:"常见的通知类型"}),e.jsx("p",{children:"在切点上挂的「通知」按时机分几种，记住对应注解即可："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"@Before"}),"：目标方法执行前。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"@AfterReturning"}),"：正常返回后。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"@AfterThrowing"}),"：抛异常后。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"@After"}),"：无论成功失败都执行（类似 finally）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"@Around"}),"：最强大的一种，包裹整个方法执行，能在前后都插逻辑、 能改返回值、甚至决定要不要放行（通过 ",e.jsx("code",{children:"ProceedingJoinPoint.proceed()"}),"）。"]})]}),e.jsxs(o,{variant:"warn",title:"两个容易栽的坑",children:[e.jsxs("p",{children:["第一，",e.jsx("strong",{children:"同类内部自调用"}),"：如上例，类内部方法互相调用绕过了代理，增强会失效。 解法是注入自身代理后用 ",e.jsx("code",{children:"self.xxx()"})," 调用，或干脆把方法拆到另一个 Bean 里。"]}),e.jsxs("p",{children:["第二，",e.jsx("strong",{children:"final 方法 / final 类不能被 CGLIB 代理"}),"： CGLIB 靠生成子类、重写方法来增强，而 ",e.jsx("code",{children:"final"})," 方法无法被重写、",e.jsx("code",{children:"final"}),"类无法被继承，因此挂在它们上的 AOP 不会生效（也可能直接报错）。同理，private 方法也代理不到。"]})]}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["被问「AOP 原理」，先讲它解决什么（把横切逻辑抽出来，无侵入地织回目标方法）， 再说核心机制是动态代理，分 JDK（基于接口）和 CGLIB（基于继承子类）两种， 并点出 Spring Boot 默认强制 CGLIB。最后主动抛出那个高频坑——「同类内部自调用导致",e.jsx("code",{children:"@Transactional"})," 失效」，并给出修复方案，面试官基本就满意了。"]}),e.jsxs(d,{title:"自定义 @Aspect 切面记录方法耗时",children:[e.jsx("p",{children:"写一个环绕通知，拦截 service 包下所有方法并打印执行耗时，亲手体会 AOP 是怎么「插」进去的："}),e.jsx(n,{lang:"java",title:"TimingAspect.java",code:u}),e.jsxs("p",{children:["跑起来后，故意制造一次「同类内部自调用」（在一个被拦截的方法里直接调另一个被拦截的方法）， 你会发现内部那次调用的耗时",e.jsx("strong",{children:"没被打印"}),"——这就亲眼验证了自调用绕过代理的失效问题。 再按上一节的办法注入 ",e.jsx("code",{children:"self"})," 改用 ",e.jsx("code",{children:"self.xxx()"})," 调用，日志就回来了。"]}),e.jsx(n,{lang:"java",title:"修复自调用：注入自身代理",code:m})]}),e.jsx(a,{points:["AOP 把事务、日志、权限等横切逻辑抽成切面，由框架在运行时织回目标方法，核心机制是动态代理。","核心概念：切面（Aspect）、连接点（JoinPoint）、切点（Pointcut，筛选拦哪些）、通知（Advice，做什么和何时做）。","两种代理：目标有接口用 JDK 动态代理（基于接口），无接口用 CGLIB（基于继承生成子类）。","Spring Boot 默认强制使用 CGLIB（proxy-target-class=true），即使有接口也不走 JDK 代理。","通知类型：@Before/@AfterReturning/@AfterThrowing/@After/@Around，其中 @Around 最灵活，可控制是否放行。","两大坑：同类内部自调用绕过代理导致 AOP 失效（用 self 代理调用修复）；final 方法/类无法被 CGLIB 代理。"]})]})}export{P as default};
