import{j as e}from"./index-Bkb6eOY7.js";import{L as l,S as d}from"./Summary-Dj-Y5ESD.js";import{K as n}from"./KeyIdea-N6HVLWjp.js";import{C as r}from"./Callout-FpvHzM97.js";import{C as s}from"./CodeBlock-BQqVtp_3.js";import{E as t}from"./Example-iLfTRUEi.js";import{P as i}from"./Practice-CL62kf51.js";import{P as a}from"./PyRunner-D0JYPDVw.js";const o=`# 综合：lambda + map / filter + sorted(key=)
nums = [5, 2, 8, 1, 9, 3]

# map：每个数平方
squares = list(map(lambda x: x * x, nums))
print("平方:", squares)

# filter：只留大于 3 的
big = list(filter(lambda x: x > 3, nums))
print("大于3:", big)

# sorted：按字典字段排序
people = [{"name": "小明", "age": 18},
          {"name": "小红", "age": 16},
          {"name": "小刚", "age": 20}]
by_age = sorted(people, key=lambda p: p["age"])
for p in by_age:
    print(p["name"], p["age"])`,c=`def total(*nums):          # *nums 收集任意多个位置参数，变成元组
    print(nums)            # 看看它长什么样
    return sum(nums)

print(total(1, 2, 3))
print(total(10, 20, 30, 40))`,x=`(1, 2, 3)
6
(10, 20, 30, 40)
100`,h=`def show(**info):          # **info 收集任意多个关键字参数，变成字典
    print(info)
    for k, v in info.items():
        print(f"{k}: {v}")

show(name="小明", age=18, city="杭州")`,j=`{'name': '小明', 'age': 18, 'city': '杭州'}
name: 小明
age: 18
city: 杭州`,m=`def demo(a, *args, **kwargs):
    print("a =", a)
    print("args =", args)
    print("kwargs =", kwargs)

demo(1, 2, 3, x=10, y=20)`,p=`a = 1
args = (2, 3)
kwargs = {'x': 10, 'y': 20}`,g=`# 普通函数
def square(x):
    return x * x

# 等价的 lambda（匿名函数）
square2 = lambda x: x * x

print(square(5))
print(square2(5))`,u=`25
25`,f=`nums = [1, 2, 3, 4]
# map：对每个元素套用一个函数
result = map(lambda x: x * x, nums)
print(list(result))      # map 结果要用 list() 转成列表查看`,b="[1, 4, 9, 16]",y=`nums = [1, 2, 3, 4, 5, 6]
# filter：只保留让函数返回 True 的元素
evens = filter(lambda x: x % 2 == 0, nums)
print(list(evens))`,k="[2, 4, 6]",w=`students = [
    {"name": "小明", "score": 90},
    {"name": "小红", "score": 85},
    {"name": "小刚", "score": 95},
]
# 用 key 指定按哪个字段排序
by_score = sorted(students, key=lambda s: s["score"], reverse=True)
for s in by_score:
    print(s["name"], s["score"])`,C=`小刚 95
小明 90
小红 85`,v=`def shout(text):
    return text.upper() + "!"

def whisper(text):
    return text.lower() + "..."

def apply(func, text):       # func 是「一个函数」
    return func(text)        # 在内部调用它

print(apply(shout, "Hello"))
print(apply(whisper, "Hello"))`,O=`HELLO!
hello...`;function F(){return e.jsxs("article",{children:[e.jsxs(l,{children:["这一章把函数玩得更花一点：用 ",e.jsx("code",{children:"*args"})," 和 ",e.jsx("code",{children:"**kwargs"})," 接收任意数量的参数； 用 ",e.jsx("code",{children:"lambda"})," 写「一次性」的小函数；用 ",e.jsx("code",{children:"map"}),"、",e.jsx("code",{children:"filter"}),"、",e.jsx("code",{children:"sorted"}),"这些「高阶函数」批量处理数据；最后理解一个很有用的思想——",e.jsx("strong",{children:"函数本身也能当数据传来传去"}),"。 这个思想在后面做 AI Agent 时尤其重要。"]}),e.jsx("h2",{children:"一、*args：接收任意多个位置参数"}),e.jsxs(n,{children:["在参数名前加一个星号 ",e.jsx("code",{children:"*"}),"（习惯叫 ",e.jsx("code",{children:"*args"}),"），它会把传进来的",e.jsx("strong",{children:"多个位置参数 打包成一个元组"}),"。这样函数就能接收「不确定个数」的参数。"]}),e.jsx(s,{lang:"python",title:"*args 收集多个参数",code:c}),e.jsx(t,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:x})}),e.jsx("h2",{children:"二、**kwargs：接收任意多个关键字参数"}),e.jsxs("p",{children:["两个星号 ",e.jsx("code",{children:"**"}),"（习惯叫 ",e.jsx("code",{children:"**kwargs"}),"）则把传进来的",e.jsx("strong",{children:"关键字参数打包成字典"}),"："]}),e.jsx(s,{lang:"python",title:"**kwargs 收集关键字参数",code:h}),e.jsx(t,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:j})}),e.jsxs("p",{children:["普通参数、",e.jsx("code",{children:"*args"}),"、",e.jsx("code",{children:"**kwargs"})," 可以一起用，顺序是固定的："]}),e.jsx(s,{lang:"python",title:"三者一起用",code:m}),e.jsx(t,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:p})}),e.jsxs(r,{variant:"note",title:"名字不是固定的",children:[e.jsx("code",{children:"args"})," 和 ",e.jsx("code",{children:"kwargs"})," 只是约定俗成的名字，真正起作用的是 ",e.jsx("code",{children:"*"})," 和 ",e.jsx("code",{children:"**"}),"。 你写 ",e.jsx("code",{children:"*nums"}),"、",e.jsx("code",{children:"**info"})," 也完全可以。"]}),e.jsx("h2",{children:"三、lambda：一次性的小函数"}),e.jsxs(n,{children:[e.jsx("code",{children:"lambda"})," 用来快速定义一个",e.jsx("strong",{children:"简短的匿名函数"}),"（没有名字的函数）。 格式：",e.jsx("code",{children:"lambda 参数: 表达式"}),"，表达式的结果就是返回值。适合那种「就用一次、不值得专门 def」的小逻辑。"]}),e.jsx(s,{lang:"python",title:"lambda 对比普通函数",code:g}),e.jsx(t,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:u})}),e.jsxs(r,{variant:"warn",title:"lambda 只能写简单逻辑",children:["lambda 里只能放一个表达式，不能写多行、不能写 if/for 语句块。逻辑稍复杂就老实用 ",e.jsx("code",{children:"def"}),"。 lambda 的主战场是「临时丢给别的函数当参数」，见下面。"]}),e.jsx("h2",{children:"四、高阶函数：map / filter / sorted"}),e.jsxs("p",{children:["「高阶函数」就是",e.jsx("strong",{children:"能接收另一个函数当参数"}),"的函数。它们常和 lambda 搭配，批量处理数据。"]}),e.jsx("h3",{children:"map：对每个元素做同样处理"}),e.jsx(s,{lang:"python",title:"map",code:f}),e.jsx(t,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:b})}),e.jsx("h3",{children:"filter：筛选出满足条件的元素"}),e.jsx(s,{lang:"python",title:"filter",code:y}),e.jsx(t,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:k})}),e.jsxs(r,{variant:"tip",children:[e.jsx("code",{children:"map"})," 和 ",e.jsx("code",{children:"filter"})," 的结果需要用 ",e.jsx("code",{children:"list()"})," 转一下才能直接打印查看。 其实这两件事用列表推导式也能做，而且很多人觉得推导式更直观，可以对照上一卷复习。"]}),e.jsx("h3",{children:"sorted(key=...)：按指定规则排序"}),e.jsxs("p",{children:[e.jsx("code",{children:"sorted"})," 的 ",e.jsx("code",{children:"key"})," 参数接收一个函数，告诉它「按什么排」。这是 lambda 最常见的用武之地："]}),e.jsx(s,{lang:"python",title:"按字典字段排序",code:w}),e.jsx(t,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:C})}),e.jsx("h2",{children:"五、把函数当参数传"}),e.jsx("p",{children:"在 Python 里，函数和数字、字符串一样是「值」，可以赋给变量、放进列表、当参数传给别的函数。 理解这一点，你才真正读懂了高阶函数："}),e.jsx(s,{lang:"python",title:"函数作为参数",code:v}),e.jsx(t,{title:"运行结果",children:e.jsx(s,{lang:"text",title:"运行结果",code:O})}),e.jsx(r,{variant:"note",title:"为什么这对学 AI Agent 重要",children:"后面做 Agent 时，我们会把一个个「工具函数」交给框架，由框架在需要时调用—— 这正是「把函数当参数 / 当数据传递」的思想。现在打好这个底，后面会很顺。"}),e.jsxs("p",{children:[e.jsx("strong",{children:"动手试试："}),"改改下面的代码再点「运行」。"]}),e.jsx(a,{initialCode:o}),e.jsx(i,{title:"动手练一练",children:e.jsxs("ol",{children:[e.jsxs("li",{children:["写一个 ",e.jsx("code",{children:"average(*nums)"})," 函数，能接收任意多个数字并返回它们的平均值。"]}),e.jsxs("li",{children:["用 ",e.jsx("code",{children:"filter"})," + lambda 从一个列表里筛出所有大于 60 的分数。"]}),e.jsxs("li",{children:["有一个 ",e.jsx("code",{children:'[("苹果", 5), ("香蕉", 3), ("橙子", 8)]'})," 的列表，用 ",e.jsx("code",{children:"sorted"})," + lambda 按第二个元素（数量）从大到小排序。"]})]})}),e.jsx(d,{points:["*args 把多个位置参数打包成元组，**kwargs 把多个关键字参数打包成字典，让函数接收不定数量参数。","args/kwargs 只是习惯名，关键是 * 和 **；可与普通参数一起用，顺序固定。","lambda 参数: 表达式 定义匿名小函数，只能放一个表达式，适合临时传给别的函数。","高阶函数能接收函数当参数：map 逐个处理、filter 筛选、sorted(key=...) 按规则排序，常配 lambda。","map/filter 结果用 list() 查看；这两件事也可用列表推导式完成。","函数本身就是值，可赋给变量、当参数传递——这是高阶函数的本质，也是后续学 Agent 工具调用的基础。"]})]})}export{F as default};
