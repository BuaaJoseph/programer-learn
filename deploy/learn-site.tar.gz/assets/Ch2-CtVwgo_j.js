import{r as x,j as e}from"./index-4Gnvy4Pk.js";import{L as f,S as j}from"./Summary-8JJJpz6g.js";import{K as p}from"./KeyIdea-6LAlCalL.js";import{E as m}from"./Example-DoUEk5_G.js";import{P as u}from"./Practice-B3Zrc-xC.js";import{C as h}from"./Callout-BfcJpdBu.js";import{C as o}from"./CodeBlock-Bq_ox3wh.js";import{F as g}from"./Figure-DjFYQXdx.js";const a=[1,2,3,4,1,2,5];function y(){const s=[],l=[];let d=0;for(const n of a){let i=!1;const r=s.indexOf(n);r!==-1?(s.splice(r,1),s.push(n)):(i=!0,d++,s.length>=3&&s.shift(),s.push(n)),l.push({page:n,frames:[...s],fault:i})}return{steps:l,faults:d}}function L(){const s=[],l=[];let d=0;for(const n of a){let i=!1;s.includes(n)||(i=!0,d++,s.length>=3&&s.shift(),s.push(n)),l.push({page:n,frames:[...s],fault:i})}return{steps:l,faults:d}}function R(){const[s,l]=x.useState("lru"),{steps:d,faults:n}=s==="lru"?y():L(),i=e.jsxs(e.Fragment,{children:[e.jsx("button",{className:`fig-btn ${s==="fifo"?"active":""}`,onClick:()=>l("fifo"),children:"FIFO"}),e.jsx("button",{className:`fig-btn ${s==="lru"?"active":""}`,onClick:()=>l("lru"),children:"LRU"}),e.jsxs("span",{className:"fig-note",children:["3 个页框 · 缺页 ",n," 次"]})]});return e.jsx(g,{caption:"物理内存装不下所有页时，要按算法换出某一页。FIFO 换最早进来的(可能换掉热页、有 Belady 异常)；LRU 换最久没用的(更贴近实际，但要记录访问时间)。看相同访问序列下两者的缺页差异。",controls:i,children:e.jsxs("svg",{viewBox:"0 0 460 190",width:"460",role:"img","aria-label":"页面置换算法",children:[e.jsxs("text",{x:"20",y:"24",fontFamily:"var(--mono)",fontSize:"10",fill:"var(--ink-soft)",children:["访问序列：",a.join(" "),"　（",s==="lru"?"LRU":"FIFO","）"]}),d.map((r,t)=>e.jsxs("g",{children:[e.jsx("rect",{x:20+t*62,y:"40",width:"54",height:"22",rx:"4",fill:r.fault?"var(--rose)":"var(--green)"}),e.jsx("text",{x:47+t*62,y:"56",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"11",fontWeight:"700",fill:"#ffffff",children:r.page}),[0,1,2].map(c=>e.jsxs("g",{children:[e.jsx("rect",{x:20+t*62,y:68+c*26,width:"54",height:"22",rx:"3",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsx("text",{x:47+t*62,y:84+c*26,textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"10",fill:"var(--ink)",children:r.frames[c]??""})]},c)),e.jsx("text",{x:47+t*62,y:"158",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"8",fill:r.fault?"var(--rose)":"var(--green)",children:r.fault?"缺页":"命中"})]},t)),e.jsx("text",{x:"20",y:"180",fontFamily:"var(--mono)",fontSize:"10",fill:"var(--ink-faint)",children:"红=缺页(换入)，绿=命中。LRU 通常比 FIFO 缺页更少；Clock 是 LRU 的近似实现。"})]})})}const F=`# 双向链表 + 哈希表实现 O(1) 的 LRU
class Node:
    def __init__(self, key=0, val=0):
        self.key, self.val = key, val
        self.prev = self.next = None

class LRUCache:
    def __init__(self, capacity):
        self.cap = capacity
        self.map = {}                 # key -> Node，O(1) 定位
        self.head, self.tail = Node(), Node()   # 哑头哑尾
        self.head.next, self.tail.prev = self.tail, self.head

    def _remove(self, node):
        node.prev.next, node.next.prev = node.next, node.prev

    def _add_front(self, node):       # 插到头部 = 最近使用
        node.next = self.head.next
        node.prev = self.head
        self.head.next.prev = node
        self.head.next = node

    def get(self, key):
        if key not in self.map:
            return -1
        node = self.map[key]
        self._remove(node)            # 命中就挪到头部
        self._add_front(node)
        return node.val

    def put(self, key, val):
        if key in self.map:
            self._remove(self.map[key])
        node = Node(key, val)
        self.map[key] = node
        self._add_front(node)
        if len(self.map) > self.cap:  # 超容量，淘汰尾部（最久未用）
            lru = self.tail.prev
            self._remove(lru)
            del self.map[lru.key]`,U=`# 访问序列（页号）：7 0 1 2 0 3 0 4 2 3 0 3 2
# 物理页框数 = 3，统计三种算法各缺页几次

seq = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2]

def fifo(seq, k):
    frames, queue, miss = set(), [], 0
    for p in seq:
        if p not in frames:
            miss += 1
            if len(frames) >= k:           # 满了就换出最早进来的
                old = queue.pop(0)
                frames.discard(old)
            frames.add(p); queue.append(p)
    return miss

# FIFO=10  LRU=9  OPT=7（OPT 是不可实现的理论下限）
print('FIFO 缺页:', fifo(seq, 3))`,O=`# Clock（二次机会）：环形数组 + 一个指针 + 每页一个访问位
def clock_replace(frames, ref_bits, hand, new_page):
    while True:
        if ref_bits[hand] == 0:        # 找到访问位为 0 的，换它
            frames[hand] = new_page
            ref_bits[hand] = 1         # 新页刚进来，置 1
            hand = (hand + 1) % len(frames)
            return hand
        ref_bits[hand] = 0             # 给它第二次机会：清零、跳过
        hand = (hand + 1) % len(frames)
# 命中时只需把对应页的访问位置 1，几乎零成本 —— 这就是它比 LRU 省的地方`;function B(){return e.jsxs(e.Fragment,{children:[e.jsx(f,{children:e.jsxs("p",{children:["缺页中断来了，可物理页框已经满了，操作系统必须先",e.jsx("strong",{children:"换出"}),"一页腾地方，才能把新页调进来。 换出哪一页，直接决定了后面会不会马上又把它换回来、缺页率高不高。这道「踢谁」的选择题， 就是",e.jsx("em",{children:"页面置换算法"}),"（page replacement）要回答的。"]})}),e.jsx("h2",{children:"评判标准：缺页越少越好"}),e.jsxs("p",{children:["换页要读写磁盘，比访存慢几个数量级，所以一个置换算法好不好，几乎就看它在相同访问序列、相同页框数下",e.jsx("strong",{children:"缺页次数"}),"有多少。理想情况是：换出去的恰好是「以后最久都不会再用」的那一页。这听起来简单， 难点在于谁也不知道未来，所以各种算法本质上都是在",e.jsx("em",{children:"猜未来"}),"。"]}),e.jsxs("p",{children:["换出还有个常被忽略的细节：换出脏页（被改过的）必须先写回磁盘才能丢，换出干净页可以直接丢。所以实际算法会优先 淘汰",e.jsx("strong",{children:"既最久未用又干净"}),"的页——这正是页表项里 ",e.jsx("code",{children:"D"}),"（dirty）标志位的用武之地。Linux 还把页分成 活跃和非活跃两条链表，先从非活跃链表里找受害者，进一步降低误踢热页的概率。"]}),e.jsx("h2",{children:"几种经典算法"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"OPT（最优）"}),"：换出「未来最长时间内不会被访问」的页。它需要预知未来，",e.jsx("em",{children:"无法实现"}),"， 只作为衡量其他算法的理论下限存在。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"FIFO（先进先出）"}),"：换出最早进入内存的页。实现最简单（一个队列），但「来得早」不等于「以后用不到」， 常常把热页误踢掉，还会出现 Belady 异常。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"LRU（最近最少使用）"}),"：换出「最久没被访问」的页，用「最近的过去」来预测「最近的将来」， 符合局部性，效果好，是工程里最常用的近似。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Clock（时钟/二次机会）"}),"：LRU 的高效近似。给每页一个访问位，淘汰时像时钟指针一样扫一圈， 访问位为 1 的清零并跳过（给第二次机会），为 0 的才换出，避免了 LRU 维护精确顺序的开销。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"LFU（最不经常使用）"}),"：换出访问",e.jsx("em",{children:"次数"}),"最少的页。对长期热点友好，但对「曾经很火、现在冷了」的页反应迟钝， 且要维护计数。"]})]}),e.jsx("p",{children:"为什么 LRU 在硬件上几乎不直接做精确版？因为精确 LRU 要给每次访存都更新一个全局时间戳或调整链表， 而访存太频繁，硬件代价吃不消。Clock 只在淘汰时扫指针、命中时置一个位，把成本压到几乎为零，这才是真实系统的选择。"}),e.jsx(o,{lang:"python",title:"clock.py",code:O}),e.jsxs(m,{title:"同一序列，三种算法对比",children:[e.jsxs("p",{children:["固定 3 个页框，访问序列 ",e.jsx("code",{children:"7 0 1 2 0 3 0 4 2 3 0 3 2"}),"，跑下来缺页次数大致是：",e.jsx("strong",{children:"OPT 最少（理论下限），LRU 次之，FIFO 最多"}),"。可以用下面的代码亲手统计 FIFO， 再对照感受 LRU 为什么更聪明。"]}),e.jsx(o,{lang:"python",title:"compare.py",code:U}),e.jsx("p",{children:"关键差别在那些「中途又被回访」的页：LRU 因为刚访问过会把它留住，FIFO 却可能因为它进来得早而把它换出， 结果没多久又缺页换回来。"})]}),e.jsx(R,{}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"算法"}),e.jsx("th",{children:"淘汰依据"}),e.jsx("th",{children:"是否可实现"}),e.jsx("th",{children:"缺点"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"OPT"}),e.jsx("td",{children:"未来最久不用"}),e.jsx("td",{children:"否（要预知未来）"}),e.jsx("td",{children:"仅作理论下限"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"FIFO"}),e.jsx("td",{children:"进入最早"}),e.jsx("td",{children:"是，最简单"}),e.jsx("td",{children:"误踢热页、Belady 异常"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"LRU"}),e.jsx("td",{children:"最久未访问"}),e.jsx("td",{children:"是，但维护贵"}),e.jsx("td",{children:"精确版硬件代价高"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Clock"}),e.jsx("td",{children:"访问位为 0"}),e.jsx("td",{children:"是，常用"}),e.jsx("td",{children:"近似、略逊精确 LRU"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"LFU"}),e.jsx("td",{children:"访问次数最少"}),e.jsx("td",{children:"是"}),e.jsx("td",{children:"对冷却的旧热点反应慢"})]})]})]}),e.jsx(h,{variant:"warn",title:"Belady 异常：加页框反而更糟",children:e.jsxs("p",{children:["直觉上页框越多、缺页应该越少。但 ",e.jsx("strong",{children:"FIFO 会出现反例"}),"：某些访问序列下，把页框从 3 个增加到 4 个， 缺页次数",e.jsx("em",{children:"不降反升"}),"，这就是 ",e.jsx("em",{children:"Belady 异常"}),"。根因是 FIFO 的淘汰顺序和「未来是否还会用」毫无关系， 加页框反而打乱了原本侥幸合适的换出节奏。LRU、OPT 这类满足「栈性质」的算法不会有这个毛病——这也是面试爱考的点。"]})}),e.jsx(h,{variant:"info",title:"什么是栈性质",children:e.jsxs("p",{children:["满足",e.jsx("strong",{children:"栈性质"}),"的算法保证：用 n 个页框时驻留的页集合，一定是用 n+1 个页框时驻留集合的子集—— 换句话说页框越多，留住的页只增不减，所以缺页只会更少、不会反弹，天然免疫 Belady 异常。LRU/OPT 满足它， FIFO 不满足。被追问「为什么 LRU 没有 Belady 异常」时，答到「栈性质」这个词就到位了。"]})}),e.jsx("h2",{children:"LRU 的实现与 Redis 的联系"}),e.jsxs("p",{children:["精确 LRU 要求每次访问都能 O(1) 地把某页标记为「最新」，并能 O(1) 地找出「最旧」。标准做法是",e.jsx("strong",{children:"双向链表 + 哈希表"}),"：哈希表用 key 直接定位到链表节点，链表头是最近使用、尾是最久未用； 命中就把节点挪到头部，淘汰就摘掉尾部。Java 里的 ",e.jsx("code",{children:"LinkedHashMap"})," 本质就是这个结构，开启访问序后能直接当 LRU 缓存用。"]}),e.jsxs("p",{children:["有意思的是 ",e.jsx("em",{children:"Redis"})," 的 LRU 并非精确实现：精确 LRU 要给每个 key 维护链表指针，内存开销大。Redis 用的是",e.jsx("strong",{children:"近似 LRU"}),"——随机采样若干 key，淘汰其中最久未访问的那个，用很小的代价换取接近 LRU 的效果， 这和操作系统用 Clock 近似 LRU 是同一种工程权衡思路。"]}),e.jsxs("p",{children:["再补一个真实演进：Redis 后来还提供 ",e.jsx("strong",{children:"LFU"})," 淘汰策略，并给计数器加了「随时间衰减」的机制， 解决了纯 LFU「旧热点冷了也赖着不走」的毛病。MySQL 的 InnoDB 缓冲池则用",e.jsx("strong",{children:"分段 LRU"}),"（young/old 两区，新页先进 old 区，被再次访问才升入 young 区），专门防全表扫描这种「一次性大量访问」把真正的热页全冲掉—— 这个问题叫",e.jsx("strong",{children:"缓存污染"}),"，是纯 LRU 的经典软肋。"]}),e.jsx(p,{title:"工作集与抖动",children:e.jsxs("p",{children:["一个进程在某段时间内频繁访问的页的集合，叫它的",e.jsx("em",{children:"工作集"}),"（working set）。只要分给它的物理页框能装下工作集， 缺页就很少；一旦页框不够、连工作集都装不下，进程就会",e.jsx("strong",{children:"不停缺页、不停换页"}),"，CPU 大部分时间花在搬页上、 几乎不干正事，这种现象叫",e.jsx("em",{children:"抖动"}),"（thrashing）。解决办法是按工作集大小分配页框， 页框实在不够时干脆挂起部分进程，而不是让所有进程一起抖动。"]})}),e.jsxs("p",{children:["抖动在生产环境很常见也很危险：内存吃紧时系统疯狂换页（swap），",e.jsx("code",{children:"top"})," 里 CPU 的 ",e.jsx("code",{children:"wa"}),"（IO 等待）飙高、 负载暴涨但吞吐归零，看起来「卡死」其实是在拼命搬页。所以数据库、JVM 服务器常常",e.jsx("strong",{children:"直接关闭 swap"}),"或调小 ",e.jsx("code",{children:"swappiness"}),"，宁可触发 OOM Killer 快速杀掉一个进程，也不让整机陷入抖动慢性死亡。"]}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["被问页面置换，先建立坐标系：",e.jsx("strong",{children:"OPT 是理论下限、不可实现；LRU 是好用的近似；FIFO 简单但有 Belady 异常； Clock 是 LRU 的高效近似"}),"。然后准备好三个高频追问：手写 LRU（双向链表+哈希）、解释 Belady 异常为什么只在 FIFO 出现、 以及抖动的成因与缓解。能顺带提一句「Redis 用近似 LRU、操作系统用 Clock，都是为了省维护成本」，会很加分。"]}),e.jsxs(u,{title:"手写一个 O(1) 的 LRU",children:[e.jsxs("p",{children:["这是面试出现频率极高的题。核心是",e.jsx("strong",{children:"哈希表负责 O(1) 定位、双向链表负责 O(1) 维护使用顺序"}),"： 命中或写入就把节点移到头部，容量超了就摘掉尾节点。"]}),e.jsx(o,{lang:"python",title:"lru_cache.py",code:F}),e.jsxs("p",{children:["想偷懒可以直接用 ",e.jsx("code",{children:"collections.OrderedDict"})," 或 Java 的 ",e.jsx("code",{children:"LinkedHashMap"}),"， 但面试官通常要你手写链表，目的就是考你对「为什么这两个数据结构配合能做到 O(1)」的理解。"]})]}),e.jsx(j,{points:["缺页且页框满时要换出一页，目标是让总缺页次数最少；换出策略就是页面置换算法。","实际换出优先选既久未用又干净的页，脏页要先写回磁盘，靠页表的 dirty 位区分。","OPT 换出未来最久不用的页，是不可实现的理论下限；LRU 用最近的过去预测将来，是常用的好近似。","FIFO 实现最简单但会出现 Belady 异常（加页框反而缺页更多），因为它不满足栈性质。","Clock（二次机会）是 LRU 的高效近似，命中只置位、淘汰才扫指针，避免维护精确顺序；LFU 按访问次数淘汰。","LRU 的经典实现是双向链表+哈希表做到 O(1)；Redis 用随机采样近似 LRU，InnoDB 用分段 LRU 防缓存污染。","工作集装不进物理页框就会抖动，CPU 忙于换页吞吐归零，生产上常关 swap 或靠 OOM Killer 兜底。"]})]})}export{B as default};
