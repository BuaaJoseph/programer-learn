import{r as h,j as e}from"./index-BdVncPlI.js";import{L as j,S as x}from"./Summary-Baiwq3-G.js";import{K as m}from"./KeyIdea-Cnr-5ipR.js";import{E as p}from"./Example-phQ905Fb.js";import{P as g}from"./Practice-CD-79usu.js";import{C as l}from"./Callout-BRUKkrb4.js";import{C as o}from"./CodeBlock-DCdshbU5.js";import{F as u}from"./Figure-YSBQF7O5.js";const d=[{role:"system",label:"system",color:"var(--ink-soft)",body:"你是编码 Agent，可用 Read/Edit/Bash… 工具。行为规范、安全规则、输出格式。",note:"每轮都带、隐藏、最稳定"},{role:"tools",label:"tools 定义",color:"var(--violet)",body:"[Read, Edit, Bash, Grep, Glob, Task, TodoWrite, …] 的 name/description/参数 schema",note:"描述就是给模型看的说明书"},{role:"claude.md",label:"CLAUDE.md",color:"var(--amber)",body:"项目规范：用 2 空格、测试用 vitest、API 在 src/api/…",note:"压缩后会被重新注入"},{role:"history",label:"对话历史",color:"var(--accent)",body:"user: 帮我重构 auth\\nassistant: (工具调用 Grep)\\n…一轮轮累积",note:"增长最快"},{role:"toolresult",label:"上一轮工具结果",color:"var(--green)",body:"tool_result: src/auth.js 的内容 / 测试输出 / 报错堆栈",note:"模型据此决定下一步"}];function f(){const[i,c]=h.useState(0),r=d[i],a=e.jsx(e.Fragment,{children:d.map((t,s)=>e.jsx("button",{className:`fig-btn ${i===s?"active":""}`,onClick:()=>c(s),children:t.label},s))});return e.jsx(u,{caption:"Agent 的每一轮，本质是把一个 messages 数组发给 LLM：system + 工具定义 + CLAUDE.md + 历史 + 上一轮工具结果，拼成完整上下文。模型读完它，输出「下一个工具调用」或「最终文本」。点各部分看它装了什么。",controls:a,children:e.jsxs("svg",{viewBox:"0 0 460 210",width:"460",role:"img","aria-label":"一次 LLM 调用解剖",children:[d.map((t,s)=>{const n=i===s;return e.jsxs("g",{onClick:()=>c(s),style:{cursor:"pointer"},children:[e.jsx("rect",{x:"20",y:18+s*30,width:"180",height:"26",rx:"5",fill:n?t.color:"var(--bg-subtle)",stroke:n?t.color:"var(--border)",strokeWidth:n?2:1}),e.jsx("text",{x:"30",y:35+s*30,fontFamily:"var(--mono)",fontSize:"11",fontWeight:"700",fill:n?"#ffffff":"var(--ink)",children:t.label})]},s)}),e.jsx("text",{x:"20",y:"190",fontFamily:"var(--mono)",fontSize:"9",fill:"var(--ink-faint)",children:"↑ 拼成一个请求发给 LLM"}),e.jsx("path",{d:"M205 90 L230 90",stroke:"var(--ink-faint)",strokeWidth:"1.5",markerEnd:"url(#lt-a)"}),e.jsx("defs",{children:e.jsx("marker",{id:"lt-a",markerWidth:"8",markerHeight:"8",refX:"5",refY:"3",orient:"auto",children:e.jsx("path",{d:"M0,0 L5,3 L0,6 Z",fill:"var(--ink-faint)"})})}),e.jsx("rect",{x:"234",y:"18",width:"212",height:"180",rx:"10",fill:"var(--bg-subtle)",stroke:"var(--border)"}),e.jsx("text",{x:"246",y:"38",fontFamily:"var(--mono)",fontSize:"12",fontWeight:"700",fill:r.color,children:r.label}),e.jsx("rect",{x:"244",y:"46",width:"192",height:"96",rx:"6",fill:"var(--bg-code)"}),e.jsx("foreignObject",{x:"252",y:"52",width:"176",height:"84",children:e.jsx("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"10px var(--mono)",color:"#d8dcec",lineHeight:1.35,whiteSpace:"pre-wrap"},children:r.body})}),e.jsx("foreignObject",{x:"244",y:"150",width:"194",height:"44",children:e.jsxs("div",{xmlns:"http://www.w3.org/1999/xhtml",style:{font:"11px var(--sans)",color:"var(--ink-soft)",lineHeight:1.3},children:["说明：",r.note]})})]})})}const y=`messages = [
  // 1) system prompt：你是谁、规则、风格（每轮都带，但内容固定）
  { role: "system", content: "你是一个编码 Agent……" },

  // 2) 工具定义：每个工具的 name / description / 参数 schema
  //    （description 本质是写给模型看的「说明书」）
  tools = [
    { name: "Read",  description: "读取一个文件……", input_schema: {...} },
    { name: "Edit",  description: "对文件做精确替换……", input_schema: {...} },
    { name: "Bash",  description: "执行一条 shell 命令……", input_schema: {...} },
    ...
  ],

  // 3) CLAUDE.md：项目约定，作为上下文注入
  { role: "user", content: "<project-memory>本项目用 jest 测试……</project-memory>" },

  // 4) 对话历史：从你的第一句指令开始，逐轮累积
  { role: "user",      content: "帮我重构 auth 模块……" },
  { role: "assistant", content: [ { type: "tool_use", name: "Grep", input: {...} } ] },

  // 5) 上一轮的工具结果：刚刚执行完的那次调用返回了什么
  { role: "user", content: [ { type: "tool_result", content: "auth.js: 600 行……" } ] },
]`,A=`// 重构任务进行到第 5 轮时，这一轮发出去的 messages（示意）
[
  system:    "你是编码 Agent……"                  // 几百 token，固定
  tools:     [Read, Edit, Bash, Grep, TodoWrite]  // 上千 token，固定
  CLAUDE.md: "用 jest；不要提交到 main……"          // 固定

  // —— 以下是越滚越长的部分 ——
  user:      "帮我重构 auth 模块……"               // 第 1 轮
  assistant: [tool_use Grep …]                     // 第 1 轮模型的动作
  user:      [tool_result "auth 在 4 处被引用"]     // 第 1 轮结果
  assistant: [tool_use Read src/auth.js]           // 第 2 轮
  user:      [tool_result "<auth.js 全文 600 行>"]  // 第 2 轮结果（很占 token）
  assistant: [tool_use TodoWrite …]                // 第 2 轮
  user:      [tool_result "Todo 已记录"]            // 第 3 轮
  assistant: "auth.js 被 4 处引用，要保留兼容入口吗？" // 第 3 轮：发问
  user:      "保留 auth.js 当兼容入口"              // 你的回答
  assistant: [tool_use Edit src/login.js …]        // 第 4 轮
  user:      [tool_result "已创建 login.js"]        // ← 第 4 轮结果

  //  ↑ 模型读完上面这一切，现在要输出「第 5 轮的动作」
]`,L=`// 一个工具定义的真实样子：name + description + input_schema
{
  name: "Edit",
  description: "对一个已存在的文件做精确字符串替换。" +
    "调用前必须先 Read 过该文件。old_string 必须在文件中唯一，" +
    "否则用 replace_all。不要用它创建新文件——那是 Write 的活。",
  input_schema: {
    type: "object",
    properties: {
      file_path:   { type: "string", description: "要修改的文件绝对路径" },
      old_string:  { type: "string", description: "要被替换掉的原文" },
      new_string:  { type: "string", description: "替换成的新文本" },
    },
    required: ["file_path", "old_string", "new_string"],
  },
}`,k=`# 第 12 轮时，一次调用的 token 大致分布（示意）
system prompt     ~  600   固定
工具定义           ~ 2,000  固定
CLAUDE.md         ~  400   固定
———————————————————————————————
对话历史           ~ 3,500  随轮次增长
工具结果(含全文)    ~ 9,000  ← 大头！auth.js 全文被反复带着
———————————————————————————————
合计              ~15,500  每一轮都重发一遍`;function R(){return e.jsxs(e.Fragment,{children:[e.jsx(j,{children:e.jsxs("p",{children:["上一章说，Agent 是一轮轮收敛的。那「一轮」具体是什么？答案朴素到惊人：",e.jsx("strong",{children:"一轮，就是一次 LLM 调用"}),"。 而一次 LLM 调用，本质是把一个 ",e.jsx("em",{children:"messages"})," 数组发给模型，模型读完，输出「下一个工具调用」或「最终文本」。 这一章我们把这个数组彻底拆开——搞懂里面装了什么，你就搞懂了 Agent 的「燃料」是怎么烧的。"]})}),e.jsx("h2",{children:"一次调用，发出去的是什么"}),e.jsxs("p",{children:["模型本身是无状态的：它不「记得」上一轮，每一轮都是把",e.jsx("strong",{children:"当前全部上下文"}),"重新发一遍。这个上下文， 就是一个 messages 数组，固定由五部分拼成："]}),e.jsx(o,{lang:"javascript",title:"一次 LLM 调用的 messages 结构",code:y}),e.jsxs("p",{children:[e.jsx("strong",{children:"为什么模型要设计成无状态的"}),"？因为无状态的服务才好水平扩展、好缓存、好容错——任意一台机器拿到这个 完整的 messages 数组，都能算出完全相同的下一步，不依赖「上一次是哪台机器、记得什么」。代价是： 所有「记忆」都得由调用方（也就是 harness）显式地塞进 messages。Agent 的「记性」不在模型里，在那个不断增长的数组里。"]}),e.jsx("h3",{children:"逐块看：每一部分干什么"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"system prompt"}),"：定义 Agent 的身份、行为规则、输出风格。每轮都带，但内容基本固定。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"工具定义"}),"：列出模型这一轮",e.jsx("em",{children:"可以"}),"调用的工具，每个含 ",e.jsx("code",{children:"name"}),"、",e.jsx("code",{children:"description"}),"、 参数 ",e.jsx("code",{children:"schema"}),"。关键认知——",e.jsx("code",{children:"description"})," 不是给人看的注释，它是",e.jsx("strong",{children:"写给模型看的说明书"}),"： 模型完全靠这段文字来判断「这个工具是干嘛的、什么时候该用、参数怎么填」。description 写得烂，模型就会用错工具。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"CLAUDE.md"}),"：项目级约定（用什么测试框架、什么不能碰），作为上下文注入，相当于常驻的项目备忘。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"对话历史"}),"：从你的第一句指令起，你说的、模型每轮的动作，逐轮累积。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"上一轮工具结果"}),"：刚执行完的那次工具调用返回了什么（文件内容、命令输出、报错），塞回来让模型看见。"]})]}),e.jsx(f,{}),e.jsx("h2",{children:"工具定义长什么样：description 才是灵魂"}),e.jsxs("p",{children:["上面反复强调「description 是写给模型看的说明书」，到底什么意思？看一个 ",e.jsx("code",{children:"Edit"})," 工具定义的真实形态："]}),e.jsx(o,{lang:"javascript",title:"一个工具定义：name + description + input_schema",code:L}),e.jsxs("p",{children:["注意 description 里那几句：",e.jsx("em",{children:"「调用前必须先 Read 过」「old_string 必须唯一」「不要用它创建新文件」"}),"。 这些不是注释，而是模型在",e.jsx("strong",{children:"决定要不要用、怎么用这个工具时唯一的依据"}),"。模型不会去读 Edit 的源码， 它只读这段文字。所以工具作者写 description，本质是在",e.jsx("em",{children:"给模型编程"}),"——你怎么描述，模型就怎么理解和使用。"]}),e.jsx(l,{variant:"warn",title:"常见误区：把工具行为问题当成模型问题",children:e.jsxs("p",{children:["当 Agent 频繁用错某个工具（比如老是不先 Read 就 Edit、老是把参数填错），很多人第一反应是「模型太笨」。 但实战经验是：",e.jsx("strong",{children:"八成是 description 没写清楚"}),"。把约束、前置条件、反例写进 description， 模型的行为往往立刻就对了。改 prompt 比换模型便宜太多——遇到工具用错，先回去审 description。"]})}),e.jsxs("p",{children:[e.jsx("strong",{children:"边界情况：工具不是越多越好"}),"。每多挂一个工具，工具定义这块就多占几百上千 token，",e.jsx("em",{children:"每一轮都带着"}),"； 而且工具越多，模型越容易「挑花眼」选错。所以成熟的 Agent 会克制工具数量，宁可几个职责清晰的强工具， 也不堆一堆功能重叠的弱工具。这也是为什么有的 Agent 用同一个 ",e.jsx("code",{children:"Bash"})," 工具跑各种命令， 而不是给每个命令都做一个专用工具。"]}),e.jsx("h2",{children:"举例：重构任务的第 5 轮长什么样"}),e.jsxs("p",{children:["抽象的结构不好记，我们把上一章那个重构任务，停在",e.jsx("strong",{children:"第 5 轮开始前"}),"，看看这一刻发给模型的 messages 实际长什么样："]}),e.jsx(o,{lang:"javascript",title:"第 5 轮的 messages（示意）",code:A}),e.jsxs("p",{children:["看清楚了吗？前三块（system / tools / CLAUDE.md）几乎一字没变；真正在",e.jsx("strong",{children:"疯长"}),"的，是后面的对话历史 和工具结果——每多走一轮，就多压进去一对「模型的动作 + 执行的结果」。模型就是读着这一整坨， 才知道「我已经拆了 login.js，下一步该拆 session.js 还是补测试」。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"注意一个容易被忽略的细节"}),"：",e.jsx("code",{children:"tool_use"})," 是 ",e.jsx("code",{children:"assistant"})," 角色发出的（模型提议调用）， 而 ",e.jsx("code",{children:"tool_result"})," 是以 ",e.jsx("code",{children:"user"})," 角色塞回去的（环境给的反馈）。也就是说，工具的执行结果， 在模型眼里是「用户那一侧给我的新信息」。这个 ",e.jsx("code",{children:"assistant 提议 → user 回结果"})," 的配对， 是整个对话历史的基本节拍，一轮一对，规规整整地往下排。"]}),e.jsx(m,{title:"模型凭什么决定下一步",children:e.jsxs("p",{children:["模型决策的依据，",e.jsx("strong",{children:"百分之百来自这个 messages 数组"}),"，没有别的。它不会回忆、不会查库、不会偷看磁盘—— 凡是没塞进 messages 的信息，对它就不存在。所以「让 Agent 表现好」的本质，永远是",e.jsx("strong",{children:"把对的东西放进上下文、把没用的挤出去"}),"。这也是为什么 Agent 工程的核心就是上下文工程。"]})}),e.jsx("h2",{children:"token 花在哪：为什么历史和结果增长最快"}),e.jsxs("p",{children:["每一轮调用都按 messages 的总长度计费和计 token。三块固定部分（system / tools / CLAUDE.md）是一笔常数开销； 真正失控的是",e.jsx("strong",{children:"累积的对话历史"}),"和",e.jsx("strong",{children:"工具结果"}),"——尤其工具结果：一次 ",e.jsx("code",{children:"Read"})," 整个 600 行的 auth.js，就能塞进去几千个 token，而且",e.jsx("strong",{children:"之后每一轮都还带着它"}),"。"]}),e.jsx(o,{lang:"text",title:"第 12 轮时的 token 分布（示意）",code:k}),e.jsx(p,{title:"同一份文件内容，被重复计费",children:e.jsxs("p",{children:["第 2 轮模型 Read 了 auth.js 全文（约 4000 token）。到了第 5、第 8、第 12 轮，只要这条 tool_result 还在历史里，这 4000 token 就被",e.jsx("strong",{children:"反复发送、反复计费"}),"。这就是为什么长会话越到后面越贵、越慢—— 不是模型变笨了，是它每轮要重读的「卷宗」越来越厚。"]})}),e.jsxs("p",{children:[e.jsx("strong",{children:"这里要破除一个误区"}),"：很多人以为「模型记住了前面的内容，所以后面不用再发」。恰恰相反—— 正因为模型",e.jsx("em",{children:"不记得"}),"，每一轮才必须把全部历史",e.jsx("strong",{children:"重新发一遍"}),"。第 12 轮和第 1 轮， 在模型看来是两次完全独立的、无关联的调用，关联全靠 messages 里那坨被重发的历史。 理解这点，你才会真正在意「别往历史里塞没用的大块内容」。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"缓解手段的预告"}),"：既然固定的前缀（system / tools / CLAUDE.md）每轮一字不变， 就可以用",e.jsx("em",{children:"提示缓存"}),"（prompt caching）把这段缓存住，避免重复计算，省时省钱。 而对疯长的历史，则有压缩、裁剪、子 Agent 隔离等办法。这些都是后面的主题，这里你只需先有个数：",e.jsx("strong",{children:"固定前缀可缓存，增长的历史才是真正的负担。"})]}),e.jsx(l,{variant:"warn",title:"上下文是有上限的",children:e.jsxs("p",{children:["messages 的总长度受",e.jsx("strong",{children:"上下文窗口"}),"限制（比如 200K token）。历史和工具结果无限增长，迟早会撞顶。 这正是后面要讲的压缩、裁剪、子 Agent 隔离等机制存在的根本原因——它们都是在跟「上下文越滚越大」这件事作斗争。 现在你只需记住：每多读一个大文件、每多跑一轮，都在往这个会越来越满的桶里加水。"]})}),e.jsx(l,{variant:"warn",title:"边界情况：撞到上限之前，质量就开始下滑",children:e.jsxs("p",{children:["别以为「没撞满 200K 就没事」。实践中，上下文越长，模型越容易",e.jsx("strong",{children:"忽略中间段的信息"}),"（业界常说的「lost in the middle」）——关键约束如果埋在一大堆文件内容中间，模型可能就漏看了。 所以控制上下文长度，不只是为了省钱，更是为了",e.jsx("em",{children:"让模型把注意力放在该放的地方"}),"。 又长又脏的上下文，本身就会拖垮决策质量。"]})}),e.jsx("h2",{children:"这对你意味着什么"}),e.jsxs("p",{children:["知道了 token 的去向，你就有了几条实用直觉。第一，",e.jsx("strong",{children:"别让 Agent 漫无目的地 Read 大文件"}),"： 能 Grep 定位、只读相关片段，就别整文件吞，因为它会一直挂在上下文里。第二，",e.jsx("strong",{children:"长会话适时另起炉灶"}),"： 当一个任务彻底做完，开新会话比在塞满的旧会话里继续更快更省。第三，理解了「模型只看 messages」， 你就明白",e.jsx("strong",{children:"把上下文喂对"}),"才是让 Agent 变强的真正杠杆，而不是反复念「请认真一点」。"]}),e.jsxs("p",{children:["第四条，给写工具/写 prompt 的人：",e.jsx("strong",{children:"把好钢用在 description 和 CLAUDE.md 上"}),"。 这两块是你能直接「编程」模型行为的地方，而且写一次、每轮生效。与其在对话里一遍遍纠正它， 不如把那条纠正",e.jsx("em",{children:"沉淀"}),"进 CLAUDE.md，让它从第一轮起就知道。"]}),e.jsxs(g,{title:"用伪 JSON 写出一轮 messages",children:[e.jsxs("p",{children:["挑你自己的一个小任务（比如「给 README 加一节安装说明」），假设 Agent 已经走到第 3 轮， 用伪 JSON ",e.jsx("strong",{children:"手写出"}),"这一轮的 messages 数组：标出 system、tools、CLAUDE.md， 以及前两轮累积的 ",e.jsx("code",{children:"tool_use"})," 和 ",e.jsx("code",{children:"tool_result"}),"。"]}),e.jsx("p",{children:"写完数一数：哪一块最长？如果让任务再多走 5 轮，最先撑爆上下文的会是哪一块？ (提示：几乎一定是工具结果。) 这个练习能把「上下文工程」从抽象概念变成你手上的肌肉记忆。"})]}),e.jsx(x,{points:["一轮 = 一次 LLM 调用 = 把一个 messages 数组发给模型，模型输出下一个工具调用或最终文本。","messages 固定五块：system prompt、工具定义、CLAUDE.md、对话历史、上一轮工具结果。","模型是无状态的：它不记得上一轮，每轮都把全部历史重新发一遍，关联全靠 messages 里被重发的内容。","工具的 description 是写给模型看的说明书，模型靠它判断何时用、怎么用；用错工具往往是 description 没写清。","tool_use 由 assistant 发出、tool_result 以 user 角色塞回，一轮一对构成对话历史的基本节拍。","system/tools/CLAUDE.md 是常数开销（可被提示缓存），历史和工具结果随轮次累积、增长最快、被反复计费。","上下文不仅有窗口上限，过长还会让模型漏看中间信息，控制长度既省钱也提质。","把上下文喂对才是让 Agent 变强的杠杆；该沉淀的约束写进 CLAUDE.md，而不是对话里反复念。"]})]})}export{R as default};
