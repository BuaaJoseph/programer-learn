import{j as e}from"./index-BdVncPlI.js";import{L as i,S as c}from"./Summary-Baiwq3-G.js";import{K as s}from"./KeyIdea-Cnr-5ipR.js";import{C as r}from"./Callout-BRUKkrb4.js";import{C as t}from"./CodeBlock-DCdshbU5.js";import{E as n}from"./Example-phQ905Fb.js";const o=`// Redux 的单向数据流（概念）：
//
//   View ──dispatch(action)──▶ Reducer ──返回新 state──▶ Store ──通知──▶ View
//
// action 是「描述发生了什么」的纯对象：
const incrementAction = { type: 'counter/increment', payload: 1 }

// reducer 是 (state, action) => newState 的纯函数，
// 必须「不可变更新」：返回新对象，绝不修改原 state。
function counterReducer(state = { value: 0 }, action) {
  switch (action.type) {
    case 'counter/increment':
      return { ...state, value: state.value + action.payload } // 新对象
    default:
      return state
  }
}`,d=`// counterSlice.js —— Redux Toolkit 用 createSlice 把样板压到最小
import { createSlice, configureStore } from '@reduxjs/toolkit'

const counterSlice = createSlice({
  name: 'counter',
  initialState: { value: 0 },
  reducers: {
    // 注意：这里「看起来」在直接修改 state.value！
    // RTK 内置 Immer，会把这段「可变写法」翻译成不可变更新。
    increment: (state) => {
      state.value += 1
    },
    decrement: (state) => {
      state.value -= 1
    },
    incrementBy: (state, action) => {
      state.value += action.payload
    },
  },
})

// createSlice 自动生成同名 action creators
export const { increment, decrement, incrementBy } = counterSlice.actions

// configureStore 自动接好 reducer、DevTools、thunk 中间件
export const store = configureStore({
  reducer: { counter: counterSlice.reducer },
})`,l=`// 组件里：useSelector 读 state，useDispatch 派发 action
import { Provider, useSelector, useDispatch } from 'react-redux'
import { store, increment, decrement, incrementBy } from './counterSlice.js'

function Counter() {
  // useSelector 带选择器：只订阅 state.counter.value，它变才重渲染
  const value = useSelector((s) => s.counter.value)
  const dispatch = useDispatch()
  return (
    <div>
      <span>计数：{value}</span>
      <button onClick={() => dispatch(increment())}>+1</button>
      <button onClick={() => dispatch(decrement())}>-1</button>
      <button onClick={() => dispatch(incrementBy(5))}>+5</button>
    </div>
  )
}

// Redux 需要在顶层套一个 Provider
export default function App() {
  return (
    <Provider store={store}>
      <Counter />
    </Provider>
  )
}`,a=`// store.js —— Zustand：create 一个「就是 Hook」的 store
import { create } from 'zustand'

export const useCounterStore = create((set) => ({
  value: 0,
  // 直接在 store 里写「方法」，没有 action 类型、没有 reducer、没有 dispatch
  increment: () => set((s) => ({ value: s.value + 1 })),
  decrement: () => set((s) => ({ value: s.value - 1 })),
  incrementBy: (n) => set((s) => ({ value: s.value + n })),
}))`,u=`// 组件里：直接 useStore，传选择器精确订阅，无 Provider
import { useCounterStore } from './store.js'

function Counter() {
  // 只订阅 value 字段：value 变才重渲染，其他字段变化不影响
  const value = useCounterStore((s) => s.value)
  // 取方法同理，方法引用稳定，不会引起重渲染
  const increment = useCounterStore((s) => s.increment)
  const incrementBy = useCounterStore((s) => s.incrementBy)
  return (
    <div>
      <span>计数：{value}</span>
      <button onClick={increment}>+1</button>
      <button onClick={() => incrementBy(5)}>+5</button>
    </div>
  )
}

// 不需要任何 Provider 包裹，直接用
export default function App() {
  return <Counter />
}`,x=`// 购物车：RTK 版（写可变代码、产出不可变更新）
import { createSlice } from '@reduxjs/toolkit'

const cartSlice = createSlice({
  name: 'cart',
  initialState: { items: [] },
  reducers: {
    addItem: (state, action) => {
      const exist = state.items.find((i) => i.id === action.payload.id)
      if (exist) {
        exist.qty += 1 // Immer 接管，安全
      } else {
        state.items.push({ ...action.payload, qty: 1 }) // push 也安全
      }
    },
    removeItem: (state, action) => {
      state.items = state.items.filter((i) => i.id !== action.payload)
    },
  },
})
export const { addItem, removeItem } = cartSlice.actions`,h=`// 购物车：Zustand 版（同样逻辑，更少仪式）
import { create } from 'zustand'

export const useCartStore = create((set) => ({
  items: [],
  addItem: (product) =>
    set((s) => {
      const exist = s.items.find((i) => i.id === product.id)
      if (exist) {
        return {
          items: s.items.map((i) =>
            i.id === product.id ? { ...i, qty: i.qty + 1 } : i
          ),
        }
      }
      return { items: [...s.items, { ...product, qty: 1 }] }
    }),
  removeItem: (id) =>
    set((s) => ({ items: s.items.filter((i) => i.id !== id) })),
}))`;function R(){return e.jsxs("article",{children:[e.jsxs(i,{children:["上一章我们用好了 Context 这把原生工具，也看清了它的天花板：只负责传递、没有细粒度更新。 当应用变大、状态变复杂，就该请出专门的状态管理库。这一章我们对比两种主流范式——",e.jsx("strong",{children:"Redux Toolkit"}),"（结构严谨、可追踪）与 ",e.jsx("strong",{children:"Zustand"}),"（极简、零样板）， 用同一个计数器和购物车给你两份对照代码，让你能根据项目规模做出选择。"]}),e.jsx("h2",{children:"一、什么时候才真的需要状态库"}),e.jsxs("p",{children:["先泼盆冷水：",e.jsx("strong",{children:"大多数应用其实用不上状态库"}),"。局部 ",e.jsx("code",{children:"useState"})," + 状态提升 + Context 已经能覆盖很多场景。只有当下面这些信号同时出现时，才值得引入："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"状态规模大、结构复杂"}),"：很多模块共享一大坨相互关联的状态。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"跨页 / 跨路由共享"}),"：状态要在多个页面之间长期存活、保持一致。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"交互复杂"}),"：一个动作会牵动多处状态联动更新。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"需要可追踪 / 可调试"}),"：希望能回看「状态怎么一步步变成现在这样」，做时间旅行调试。"]})]}),e.jsxs(r,{variant:"warn",title:"不要为了用而用",children:["给一个只有几个表单的小应用套上 Redux，往往是",e.jsx("strong",{children:"过度工程"}),"：样板代码比业务逻辑还多。 先问「原生方案是否真的扛不住了」，再决定上不上库。"]}),e.jsx("h2",{children:"二、Redux 核心概念"}),e.jsxs(s,{children:["Redux 的世界观：整个应用的状态存在",e.jsx("strong",{children:"单一 store"})," 里；要改状态，只能",e.jsx("strong",{children:"dispatch 一个 action"}),"（描述「发生了什么」的纯对象）；",e.jsx("strong",{children:"reducer"})," 这个纯函数根据 action 算出",e.jsx("strong",{children:"新"})," state（绝不修改旧的）。 数据严格",e.jsx("strong",{children:"单向流动"}),"，每一次变化都可被记录、回放。"]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"单一 store"}),"：全应用一棵状态树，唯一真相来源。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"action"}),"：",e.jsx("code",{children:"{ type, payload }"})," 形式的纯对象，只描述「发生了什么」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"reducer"}),"：",e.jsxs("code",{children:["(state, action) =",">"," newState"]})," 的纯函数，决定状态如何变。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"单向数据流"}),"：View 派发 action，reducer 算新 state，store 更新，View 重渲染。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"不可变（immutable）"}),"：reducer 必须返回新对象，不能就地修改原 state。"]})]}),e.jsx(t,{lang:"js",title:"Redux 概念：action / reducer / 不可变更新",code:o}),e.jsxs("p",{children:["这套约束带来了 Redux 最大的卖点：",e.jsx("strong",{children:"可预测、可追踪、可调试"}),"。配合 Redux DevTools， 你能逐条看到 action 历史、做时间旅行。代价则是",e.jsx("strong",{children:"样板代码多"}),"——光是定义 action 类型、 action creator、reducer 就要写一堆，这也是经典 Redux 被诟病的地方。"]}),e.jsx("h2",{children:"三、Redux Toolkit：把样板降下来"}),e.jsxs("p",{children:["Redux Toolkit（RTK）是",e.jsx("strong",{children:"官方推荐的现代 Redux 写法"}),"，专门解决「样板太多」的痛点。 两个核心 API："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"createSlice"}),"：一次性定义一块状态的 initialState、reducers，并",e.jsx("strong",{children:"自动生成"})," action creators。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"configureStore"}),"：自动接好 reducer、Redux DevTools、thunk 中间件，开箱即用。"]})]}),e.jsxs(s,{children:["RTK 内置 ",e.jsx("strong",{children:"Immer"}),"，让你在 reducer 里",e.jsx("strong",{children:"写「看起来在直接修改」的可变代码"}),"（",e.jsx("code",{children:"state.value += 1"}),"、",e.jsx("code",{children:"state.items.push(...)"}),"），Immer 在背后把它翻译成",e.jsx("strong",{children:"不可变更新"}),"。一句话：",e.jsx("strong",{children:"写可变代码、产出不可变更新"}),"， 既保留 Redux 的不可变保证，又省掉满屏的展开运算符。"]}),e.jsx(t,{lang:"js",title:"createSlice + configureStore（含 Immer）",code:d}),e.jsxs(r,{variant:"info",title:"Immer 的边界",children:["Immer 的「可变写法」只在 ",e.jsx("code",{children:"createSlice"})," / ",e.jsx("code",{children:"createReducer"})," 提供的 reducer 函数内部生效。在这些函数",e.jsx("strong",{children:"之外"}),"（比如普通工具函数里）改 state， 依旧要老老实实手动不可变更新。"]}),e.jsx("h3",{children:"在组件里用：useSelector / useDispatch"}),e.jsxs("p",{children:["通过 ",e.jsx("code",{children:"react-redux"})," 连接 React。",e.jsx("code",{children:"useSelector(selector)"})," 订阅 store 的一部分—— 只有",e.jsx("strong",{children:"选中的那部分"}),"变化才会让组件重渲染，这就是 Context 给不了的细粒度订阅；",e.jsx("code",{children:"useDispatch()"})," 拿到 dispatch 去派发 action。顶层需要套 ",e.jsx("code",{children:"<Provider store={store}>"}),"。"]}),e.jsx(t,{lang:"jsx",title:"计数器：RTK 在组件里的用法",code:l}),e.jsx("h2",{children:"四、Zustand：极简范式"}),e.jsxs("p",{children:["Zustand（德语「状态」）走的是另一条路：",e.jsx("strong",{children:"把仪式感降到几乎为零"}),"。 你用 ",e.jsx("code",{children:"create"})," 定义一个 store，它返回的",e.jsx("strong",{children:"本身就是一个 Hook"}),"。 没有 Provider、没有 action 类型、没有 reducer、没有 dispatch——state 和修改它的方法直接写在一起。"]}),e.jsx(t,{lang:"js",title:"Zustand：create 一个就是 Hook 的 store",code:a}),e.jsxs("p",{children:["在组件里，直接调用这个 Hook 并传一个",e.jsx("strong",{children:"选择器"}),"：",e.jsxs("code",{children:["useCounterStore((s) =",">"," s.value)"]}),"。 和 RTK 的 ",e.jsx("code",{children:"useSelector"})," 一样，它做",e.jsx("strong",{children:"精确订阅"}),"——只有 ",e.jsx("code",{children:"value"})," 变化 才重渲染。最大的区别是：",e.jsx("strong",{children:"不需要任何 Provider 包裹"}),"，store 是模块级单例，import 进来就能用。"]}),e.jsx(t,{lang:"jsx",title:"计数器：Zustand 在组件里的用法（无 Provider）",code:u}),e.jsx("h2",{children:"五、同一个购物车，两份对照"}),e.jsx("p",{children:"计数器太简单，换个更有结构的例子——购物车的「加入 / 移除商品」，更能看出两种范式的手感差异。"}),e.jsx(n,{title:"RTK 版购物车",children:e.jsxs("p",{children:["靠 Immer，你能在 reducer 里直接 ",e.jsx("code",{children:"exist.qty += 1"})," 和",e.jsx("code",{children:"state.items.push(...)"}),"，读起来像在改普通对象，实际产出的是不可变更新。"]})}),e.jsx(t,{lang:"js",title:"购物车：Redux Toolkit 版",code:x}),e.jsx(n,{title:"Zustand 版购物车",children:e.jsxs("p",{children:["Zustand 没有内置 Immer（可选装中间件），所以这里用展开 / ",e.jsx("code",{children:"map"})," / ",e.jsx("code",{children:"filter"}),"手动做不可变更新。代码更扁平：没有 slice、没有 action 类型，方法就挂在 store 上。"]})}),e.jsx(t,{lang:"js",title:"购物车：Zustand 版",code:h}),e.jsx("h2",{children:"六、两者对比：怎么选"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"Redux Toolkit"}),e.jsx("th",{children:"Zustand"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"样板量"}),e.jsx("td",{children:"中（RTK 已大幅削减，但仍有 slice/Provider）"}),e.jsx("td",{children:"极少（store 即 Hook）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"学习曲线"}),e.jsx("td",{children:"较陡（action/reducer/单向流概念多）"}),e.jsx("td",{children:"平缓（会用 Hook 就会用）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Provider"}),e.jsx("td",{children:"需要顶层 Provider"}),e.jsx("td",{children:"不需要，模块级单例"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"不可变更新"}),e.jsx("td",{children:"内置 Immer，写可变代码"}),e.jsx("td",{children:"默认手动，可选 Immer 中间件"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"调试工具"}),e.jsx("td",{children:"强，官方 DevTools / 时间旅行"}),e.jsx("td",{children:"有 devtools 中间件，生态稍弱"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"细粒度订阅"}),e.jsx("td",{children:"useSelector 选择器"}),e.jsx("td",{children:"useStore 选择器"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"适用规模"}),e.jsx("td",{children:"大型 / 团队 / 需严格规范与可追踪"}),e.jsx("td",{children:"中小型 / 快速开发 / 追求轻量"})]})]})]}),e.jsxs(r,{variant:"tip",title:"一句话选型",children:["要",e.jsx("strong",{children:"规范、可追踪、团队协作、强调试"}),"，选 Redux Toolkit； 要",e.jsx("strong",{children:"轻、快、少仪式"}),"，选 Zustand。两者都做细粒度订阅，性能上都远胜「用 Context 当状态库」。"]}),e.jsx("h2",{children:"七、视野之外：还有别的范式"}),e.jsx("p",{children:"状态管理的世界不止这两家，了解一下另外两类思路有助于建立全景："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"原子化（Jotai / Recoil）"}),"：把状态拆成一个个极小的「原子（atom）」， 组件按需订阅某几个原子。自底向上组合，天然细粒度，心智更接近 ",e.jsx("code",{children:"useState"})," 的分布式版本。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"服务端状态另当别论"}),"：从后端接口拉来的数据（带缓存、重新验证、加载 / 错误态、 后台刷新）",e.jsx("strong",{children:"不该"}),"硬塞进 Redux / Zustand 这类客户端状态库。它有专门的解法——",e.jsx("strong",{children:"TanStack Query"}),"，我们会在 ",e.jsx("strong",{children:"r7"})," 卷专门讲。"]})]}),e.jsxs(r,{variant:"info",title:"客户端状态 vs 服务端状态",children:["一个关键区分：",e.jsx("strong",{children:"客户端状态"}),"（UI 开关、表单、购物车这类你自己拥有的状态）交给 Redux / Zustand / Jotai；",e.jsx("strong",{children:"服务端状态"}),"（接口数据）交给 TanStack Query。 混为一谈是很多项目状态层混乱的根源。"]}),e.jsx(c,{points:["大多数应用用不上状态库；只有状态规模大、跨页共享、交互复杂、需可追踪时才值得引入。","Redux 核心：单一 store、action（描述发生了什么）、reducer（纯函数算新 state）、单向数据流、不可变更新。","Redux Toolkit 用 createSlice/configureStore 削减样板，内置 Immer 让你「写可变代码、产出不可变更新」。","组件里 RTK 用 useSelector（细粒度订阅）+ useDispatch，需顶层 Provider；Zustand 用 create 出一个就是 Hook 的 store，useStore(s=>s.x) 精确订阅，无 Provider、无 action 样板。","选型：要规范 / 可追踪 / 强调试选 Redux Toolkit，要轻量 / 少仪式选 Zustand，两者都做细粒度订阅。","Jotai/Recoil 提供原子化的细粒度思路；服务端状态（接口数据）不该塞进客户端状态库，应交给 TanStack Query（见 r7）。"]})]})}export{R as default};
