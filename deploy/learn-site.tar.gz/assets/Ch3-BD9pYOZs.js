import{j as e}from"./index-CBMe5udE.js";import{L as t,S as o}from"./Summary-CEfAQ4SZ.js";import{K as i}from"./KeyIdea-K3hFePn1.js";import{C as s}from"./Callout-3wJQ5WDp.js";import{C as r}from"./CodeBlock-D4LRiuTl.js";import{E as n}from"./Example-CFOi3F9j.js";const l=`package com.example.bailian;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

@Component
public class WeatherTools {

    @Tool(description = "查询某个城市的当前天气")
    public WeatherInfo getWeather(@ToolParam(description = "城市名，例如 北京") String city) {
        return new WeatherInfo(city, 26, "晴");
    }
}`,a=`package com.example.bailian;

public record WeatherInfo(String city, int tempC, String desc) {
}`,d=`package com.example.bailian;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AskController {

    private final ChatClient chat;

    public AskController(ChatClient.Builder builder, WeatherTools tools) {
        this.chat = builder.defaultTools(tools).build();
    }

    @GetMapping("/ask")
    public WeatherInfo ask(@RequestParam String q) {
        return chat.prompt()
                .user(q)
                .call()
                .entity(WeatherInfo.class);
    }
}`,c=`curl "http://localhost:8080/ask?q=北京今天天气怎么样"

# 预期 JSON（字段对应 WeatherInfo record）：
# {"city":"北京","tempC":26,"desc":"晴"}`,h=`// 1) 建一个内存向量库并灌入文档
@Bean
SimpleVectorStore vectorStore(EmbeddingModel embeddingModel) {
    SimpleVectorStore store = SimpleVectorStore.builder(embeddingModel).build();
    store.add(List.of(
            new Document("公司年假为每年 15 天，入职满一年起算。"),
            new Document("报销需在月底前提交，超过 500 元需经理审批。")
    ));
    return store;
}

// 2) 给 ChatClient 挂上 QuestionAnswerAdvisor，问答自动检索
ChatClient chat = builder
        .defaultAdvisors(new QuestionAnswerAdvisor(vectorStore))
        .build();

String ans = chat.prompt()
        .user("年假有多少天？")   // 框架先检索相关文档，再连同问题发给模型
        .call()
        .content();`,p=`// 多轮记忆：把历史对话自动注入 prompt
ChatMemory chatMemory = MessageWindowChatMemory.builder().build();

ChatClient chat = builder
        .defaultAdvisors(
                MessageChatMemoryAdvisor.builder(chatMemory).build())
        .build();

// 用 conversationId 区分不同会话
chat.prompt().user("我叫小杜")
        .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, "user-42"))
        .call().content();

chat.prompt().user("我叫什么名字？")  // 同一会话能记起「小杜」
        .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, "user-42"))
        .call().content();`,j=`<dependency>
    <groupId>com.alibaba.cloud.ai</groupId>
    <artifactId>spring-ai-alibaba-starter-dashscope</artifactId>
</dependency>`,x=`spring:
  ai:
    dashscope:
      api-key: \${AI_DASHSCOPE_API_KEY}
      chat:
        options:
          model: qwen-plus`;function S(){return e.jsxs("article",{children:[e.jsxs(t,{children:["本章把 Ch2 的最小工程升级为「能调用工具 + 返回结构化结果」的智能接口：模型自己判断该不该查天气， 框架自动执行 ",e.jsx("code",{children:"@Tool"})," 方法，再把结果以 ",e.jsx("code",{children:"WeatherInfo"})," 对象直接返回。随后加餐 RAG、 多轮记忆与 Spring AI Alibaba 原生接百炼，给出两条路径的取舍。"]}),e.jsx("h2",{children:"一、目标：一个会查天气的结构化接口"}),e.jsxs("p",{children:["我们要做的 ",e.jsx("code",{children:"/ask"})," 接口：用户问「北京天气怎么样」，模型识别出需要查天气、决定调用 ",e.jsx("code",{children:'getWeather("北京")'}),"， 框架执行工具拿到数据回传模型，模型再把答案整理成 ",e.jsx("code",{children:"WeatherInfo"})," 结构返回。三段代码搞定。"]}),e.jsx("h2",{children:"二、WeatherTools：声明一个工具"}),e.jsx(r,{lang:"java",title:"WeatherTools.java",code:l}),e.jsx("p",{children:"逐点拆解："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"@Component"}),"：让它成为 Spring Bean，可被注入到 Controller。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"@Tool(description=...)"}),"：把方法暴露为模型可调用的工具，description 是给模型看的「这工具能干嘛」，模型靠它判断何时调用。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"@ToolParam(description=...)"}),"：描述参数语义，框架据此 + 方法签名自动生成 JSON Schema，模型才知道要传什么。"]}),e.jsxs("li",{children:["返回 ",e.jsx("code",{children:"WeatherInfo"}),"：工具结果会被序列化后回传模型。这里返回写死的示例数据，真实场景换成调用天气 API。"]})]}),e.jsx("h2",{children:"三、WeatherInfo：结构化返回类型"}),e.jsx(r,{lang:"java",title:"WeatherInfo.java",code:a}),e.jsxs("p",{children:["用 Java ",e.jsx("code",{children:"record"})," 一行定义不可变数据类，三个字段 ",e.jsx("code",{children:"city / tempC / desc"}),"。它身兼两职： 既是工具的返回类型，又是接口的结构化输出类型——下面 ",e.jsx("code",{children:".entity(WeatherInfo.class)"})," 会用到。"]}),e.jsx("h2",{children:"四、AskController：工具 + 结构化输出一条链"}),e.jsx(r,{lang:"java",title:"AskController.java",code:d}),e.jsx("p",{children:"关键三处："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"构造注入"}),"：",e.jsx("code",{children:"ChatClient.Builder"})," 由 starter 自动装配，",e.jsx("code",{children:"WeatherTools"})," 由容器注入。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"defaultTools(tools)"})}),"：把工具对象注册给这个 ChatClient，之后每次对话模型都可调用它。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:e.jsx("code",{children:"prompt().user(q).call().entity(WeatherInfo.class)"})}),"：一条链完成「构建请求 → 调用（含工具循环）→ 把最终回复映射成 WeatherInfo」。"]})]}),e.jsxs(i,{title:"模型自动决定调用工具",children:["你没有写任何「if 用户问天气 then 调 getWeather」的逻辑。是模型读了 ",e.jsx("code",{children:"@Tool"})," 的 description 后",e.jsx("strong",{children:"自主决定"}),"要不要调、传什么参数，框架负责执行与回传。这就是工具调用（function calling）的本质。"]}),e.jsx("h2",{children:"五、验证：curl 与预期 JSON"}),e.jsx(r,{lang:"bash",title:"curl 验证 /ask",code:c}),e.jsx(n,{title:"一次 /ask 请求里发生了什么",children:e.jsxs("ol",{children:[e.jsx("li",{children:"请求带 q=「北京今天天气怎么样」到达 Controller。"}),e.jsxs("li",{children:[e.jsx("code",{children:"call()"})," 把问题 + 工具 schema 发给百炼 Qwen 模型。"]}),e.jsx("li",{children:"模型返回「请调用 getWeather，参数 city=北京」。"}),e.jsxs("li",{children:["框架执行 ",e.jsx("code",{children:'WeatherTools.getWeather("北京")'}),"，得到 ",e.jsx("code",{children:'WeatherInfo("北京",26,"晴")'}),"，回传模型。"]}),e.jsxs("li",{children:["模型据工具结果生成最终回复；",e.jsx("code",{children:".entity(WeatherInfo.class)"})," 把它解析成对象，序列化为 JSON 返回。"]})]})}),e.jsx("h2",{children:"六、进阶：RAG advisor 文档问答"}),e.jsxs("p",{children:["让模型基于你的私有文档回答，只需建一个 ",e.jsx("code",{children:"VectorStore"})," 并挂上 ",e.jsx("code",{children:"QuestionAnswerAdvisor"}),"："]}),e.jsxs(s,{variant:"tip",title:"RAG 的最小心智",children:["建库灌文档 → 给 ChatClient 装 ",e.jsx("code",{children:"QuestionAnswerAdvisor(vectorStore)"})," → 正常提问。 Advisor 会在调用模型前自动检索最相关的文档，拼进上下文，模型据此作答。你的业务代码几乎不变。"]}),e.jsx(r,{lang:"java",title:"QuestionAnswerAdvisor + SimpleVectorStore",code:h}),e.jsxs("p",{children:[e.jsx("code",{children:"SimpleVectorStore"})," 是内存版，适合教学与小规模；生产可换 PgVector / Redis / Milvus， 代码层面只换 Bean，",e.jsx("code",{children:"QuestionAnswerAdvisor"})," 用法不变——这正是 VectorStore 抽象的价值。"]}),e.jsx("h2",{children:"七、进阶：ChatMemory advisor 多轮记忆"}),e.jsxs("p",{children:["默认每次 ",e.jsx("code",{children:"call()"})," 都是无状态的。要让模型记住上下文，挂 ",e.jsx("code",{children:"MessageChatMemoryAdvisor"}),"："]}),e.jsx(r,{lang:"java",title:"MessageChatMemoryAdvisor 多轮记忆",code:p}),e.jsxs("p",{children:["用 ",e.jsx("code",{children:"conversationId"})," 隔离不同用户/会话的历史。Advisor 在每次请求前把该会话的历史消息注入 prompt， 实现「记得上文」。记忆与 RAG 可同时挂多个 Advisor，组成拦截链。"]}),e.jsx("h2",{children:"八、加餐：Spring AI Alibaba 原生接百炼"}),e.jsx("p",{children:"除了 Ch2 的 OpenAI 兼容路径，阿里还提供官方原生 starter，体验更顺滑："}),e.jsx(r,{lang:"xml",title:"引入 Spring AI Alibaba starter",code:j}),e.jsx(r,{lang:"yaml",title:"原生 DashScope 配置（无 base-url 坑）",code:x}),e.jsxs(s,{variant:"note",title:"原生路径的优势",children:["配置节点在 ",e.jsx("code",{children:"spring.ai.dashscope"})," 下，",e.jsx("code",{children:"api-key"})," 用 ",e.jsx("code",{children:"${AI_DASHSCOPE_API_KEY}"}),"。 它原生对接 DashScope，",e.jsx("strong",{children:"无需写 base-url，也就没有 Ch2 的双 v1 坑"}),"； 还支持 Qwen 多模态、Embedding，以及更重型的 Agent-Graph 编排。"]}),e.jsx("h3",{children:"两条路径取舍"}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"维度"}),e.jsx("th",{children:"路径 A：OpenAI 兼容"}),e.jsx("th",{children:"路径 B：Spring AI Alibaba"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"依赖"}),e.jsx("td",{children:"spring-ai-starter-model-openai"}),e.jsx("td",{children:"spring-ai-alibaba-starter-dashscope"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"配置节点"}),e.jsx("td",{children:"spring.ai.openai + base-url"}),e.jsx("td",{children:"spring.ai.dashscope（无 base-url）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"base-url 坑"}),e.jsx("td",{children:"有（双 v1 → 404）"}),e.jsx("td",{children:"无"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"可移植性"}),e.jsx("td",{children:"强：换任何 OpenAI 兼容服务只改 yml"}),e.jsx("td",{children:"绑定 DashScope"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"能力"}),e.jsx("td",{children:"对话/工具/结构化"}),e.jsx("td",{children:"额外：多模态、Embedding、Agent-Graph"})]})]})]}),e.jsx("p",{children:"简单说：要通用与可迁移选 A；要吃透 Qwen 全部能力、做复杂 Agent 编排选 B。"}),e.jsx("h2",{children:"九、卷七小结"}),e.jsx(i,{title:"本卷一句话",children:"Spring AI 把 AI 变成「被 Spring 管理的依赖」：ChatClient 是入口，@Tool 让模型动手，.entity() 拿结构化结果， Advisor 链插入记忆与 RAG；接百炼记牢 base-url 别带 /v1，要省心就用 Spring AI Alibaba 原生 starter。"}),e.jsx(o,{points:["@Tool/@ToolParam 让方法成为模型可调用工具，框架据签名+注解自动生成 JSON Schema。","ChatClient.builder().defaultTools(tools) 注册工具；模型自主决定何时调用、传什么参数。","prompt().user(q).call().entity(WeatherInfo.class) 一条链完成请求、工具循环与结构化映射。","RAG：建 SimpleVectorStore 灌文档 + 挂 QuestionAnswerAdvisor，提问自动检索增强。","多轮记忆：MessageChatMemoryAdvisor + conversationId，自动把历史注入 prompt。","Spring AI Alibaba（spring-ai-alibaba-starter-dashscope）原生接百炼，无 base-url 坑，支持多模态/Embedding/Agent-Graph。","两条路径取舍：要通用可迁移选 OpenAI 兼容；要 Qwen 全能力与复杂编排选 Spring AI Alibaba。"]})]})}export{S as default};
