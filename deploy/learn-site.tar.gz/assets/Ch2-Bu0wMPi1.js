import{j as e}from"./index-6B4LaKrF.js";import{L as c,S as l}from"./Summary-CdadMIHa.js";import{K as n}from"./KeyIdea-Dk7JleQ-.js";import{E as i}from"./Example-BJvFbdam.js";import{P as d}from"./Practice-B0a6ljMe.js";import{C as s}from"./Callout-Bc-_Rgy3.js";import{C as r}from"./CodeBlock-CsqKASm5.js";const t=`@Service
class OrderService {

    public void createOrder() {
        // 同类内部直接调 this.saveLog()，走的是原始对象、不是代理对象，
        // @Transactional 完全不生效！
        saveLog();
    }

    @Transactional
    public void saveLog() {
        // 这里的事务注解被「绕过」了
        logMapper.insert(new Log());
        throw new RuntimeException("出错也不会回滚");
    }
}`,o=`@Service
class OrderService {
    @Autowired
    private LogService logService;

    @Transactional   // 默认 REQUIRED：加入当前事务
    public void createOrder() {
        orderMapper.insert(order);
        try {
            logService.writeLog();   // 内部开了独立事务
        } catch (Exception e) {
            // 即使写日志失败，订单事务也不被它牵连
        }
        // 这里抛异常，order 会回滚，但上面已提交的日志不受影响
    }
}

@Service
class LogService {
    // REQUIRES_NEW：挂起外层事务，开一个全新的独立事务，独立提交/回滚
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void writeLog() {
        logMapper.insert(new Log());
    }
}`,h=`@Service
class AccountService {

    @Transactional   // 外层事务（REQUIRED）
    public void transfer() {
        accountMapper.deduct("A", 100);   // 扣款
        try {
            pointService.addPoints();     // NESTED：基于 savepoint
        } catch (Exception e) {
            // 内层回滚只回到 savepoint，扣款不受影响、外层继续
            log.warn("积分失败但不影响转账");
        }
        accountMapper.add("B", 100);      // 加款
        // 若这里抛异常，外层回滚会连 NESTED 内层一起回滚
    }
}

@Service
class PointService {
    @Transactional(propagation = Propagation.NESTED)
    public void addPoints() {
        pointMapper.insert(/* ... */);
        if (somethingWrong) throw new RuntimeException();
    }
}`,a=`// 编程式事务：用 TransactionTemplate，绕开注解失效的种种坑
@Service
class BatchService {
    @Autowired
    private TransactionTemplate txTemplate;

    public void run() {
        // 只把真正需要事务的代码包进 execute，边界由自己精确控制
        txTemplate.execute(status -> {
            orderMapper.insert(order);
            stockMapper.reduce(sku);
            // 想回滚时主动标记，比抛异常更灵活
            if (needRollback) status.setRollbackOnly();
            return null;
        });
    }
}`;function T(){return e.jsxs(e.Fragment,{children:[e.jsx(c,{children:e.jsxs("p",{children:["声明式事务用起来只是一个 ",e.jsx("code",{children:"@Transactional"})," 注解，但面试官真正想考的是它背后的两件事：",e.jsx("em",{children:"propagation"}),"（传播行为）决定「方法之间事务怎么组合」，而",e.jsx("strong",{children:"事务失效场景"}),"则是踩坑重灾区—— 很多人写了注解却发现根本没回滚。这一章把传播行为讲透，再把失效的坑一次性列清。"]})}),e.jsx("h2",{children:"声明式事务的本质：AOP 代理"}),e.jsxs("p",{children:[e.jsx("code",{children:"@Transactional"})," 之所以能「自动开启、自动提交、出错回滚」，靠的是 Spring AOP： 容器为你的 Bean 生成一个",e.jsx("strong",{children:"代理对象"}),"，调用被注解的方法时，代理会先开启事务，方法正常返回则提交、 抛异常则回滚。理解这一点是后面所有「失效场景」的钥匙——",e.jsx("strong",{children:"只有走代理的调用，事务才生效"}),"。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"事务和连接、线程的关系"}),"是更深一层的考点。代理「开启事务」的实质，是从",e.jsx("code",{children:"DataSource"})," 取一个数据库连接、把它的 ",e.jsx("code",{children:"autoCommit"})," 关掉， 然后把这个连接绑定到当前线程的 ",e.jsx("strong",{children:"ThreadLocal"}),"（由 ",e.jsx("code",{children:"TransactionSynchronizationManager"})," 管理）。 之后同一线程里 MyBatis/JdbcTemplate 执行 SQL 时，会从 ThreadLocal 取出",e.jsx("strong",{children:"同一个连接"}),"， 所有操作才在同一个事务里。方法正常结束代理调 ",e.jsx("code",{children:"commit"}),"，异常则 ",e.jsx("code",{children:"rollback"}),"，最后解绑并归还连接。 理解了「事务 = 一个连接的 autoCommit=false + 绑定线程」，你就能秒懂为什么「换线程事务就丢」。"]}),e.jsx("h3",{children:"七种传播行为"}),e.jsxs("p",{children:[e.jsx("em",{children:"propagation"})," 描述「当前方法的事务该如何与调用它的外层事务协作」，共七种，最常考的是前三种："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"REQUIRED（默认）"}),"：外层有事务就加入，没有就新建。两者同生共死，任一回滚则全部回滚。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"REQUIRES_NEW"}),"：无论外层有没有事务，都",e.jsx("em",{children:"挂起"}),"外层、开一个全新的独立事务，独立提交、独立回滚，互不牵连。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"NESTED"}),"：在外层事务里开一个",e.jsx("em",{children:"嵌套事务"}),"（基于 savepoint）。内层回滚只回到 savepoint，不影响外层；但外层回滚会带着内层一起回。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"SUPPORTS"}),"：有事务就用，没有就以非事务方式运行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"NOT_SUPPORTED"}),"：以非事务方式运行，有事务则挂起。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"MANDATORY"}),"：必须在已有事务中运行，否则抛异常。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"NEVER"}),"：必须在非事务中运行，存在事务则抛异常。"]})]}),e.jsxs("p",{children:["一句话记 REQUIRES_NEW 与 NESTED 的区别：前者是",e.jsx("strong",{children:"两个完全独立"}),"的事务（外层回滚不影响已提交的内层）； 后者是",e.jsx("strong",{children:"父子关系"}),"（外层回滚会连内层一起回，内层回滚只回到 savepoint）。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"传播行为"}),e.jsx("th",{children:"外层有事务时"}),e.jsx("th",{children:"外层无事务时"}),e.jsx("th",{children:"内层回滚影响外层?"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"REQUIRED"}),e.jsx("td",{children:"加入外层"}),e.jsx("td",{children:"新建"}),e.jsx("td",{children:"是（同一个事务）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"REQUIRES_NEW"}),e.jsx("td",{children:"挂起外层、开新事务"}),e.jsx("td",{children:"新建"}),e.jsx("td",{children:"否（完全独立）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"NESTED"}),e.jsx("td",{children:"开 savepoint 子事务"}),e.jsx("td",{children:"新建"}),e.jsx("td",{children:"否（但外层回滚会带回内层）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"SUPPORTS"}),e.jsx("td",{children:"加入外层"}),e.jsx("td",{children:"非事务运行"}),e.jsx("td",{children:"—"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"NOT_SUPPORTED"}),e.jsx("td",{children:"挂起外层、非事务运行"}),e.jsx("td",{children:"非事务运行"}),e.jsx("td",{children:"—"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"MANDATORY"}),e.jsx("td",{children:"加入外层"}),e.jsx("td",{children:"抛异常"}),e.jsx("td",{children:"是"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"NEVER"}),e.jsx("td",{children:"抛异常"}),e.jsx("td",{children:"非事务运行"}),e.jsx("td",{children:"—"})]})]})]}),e.jsx(s,{variant:"info",title:"NESTED 的隐藏前提与坑",children:e.jsxs("p",{children:[e.jsx("code",{children:"NESTED"})," 基于数据库的 ",e.jsx("strong",{children:"savepoint"}),"，因此它要求底层连接和驱动支持 savepoint （MySQL InnoDB 支持），且整个嵌套",e.jsx("strong",{children:"共用同一个物理连接"}),"——这点和 ",e.jsx("code",{children:"REQUIRES_NEW"}),"截然不同（后者会真正再取一个连接）。一个常见误判：以为 ",e.jsx("code",{children:"NESTED"})," 内层提交后就「板上钉钉」了， 其实不然，",e.jsx("strong",{children:"外层一旦回滚，内层那段也会跟着回滚"}),"，因为它本质只是外层事务里的一个保存点。 真正要「内层无论如何都独立落库」，必须用 ",e.jsx("code",{children:"REQUIRES_NEW"}),"。"]})}),e.jsx("h3",{children:"隔离级别"}),e.jsxs("p",{children:[e.jsx("em",{children:"isolation"})," 控制并发事务间的可见性，对应数据库的四个标准级别：",e.jsx("code",{children:"READ_UNCOMMITTED"}),"（脏读）、",e.jsx("code",{children:"READ_COMMITTED"}),"（解决脏读）、",e.jsx("code",{children:"REPEATABLE_READ"}),"（解决不可重复读，MySQL 默认）、",e.jsx("code",{children:"SERIALIZABLE"}),"（最严、解决幻读但性能最差）。 Spring 默认用 ",e.jsx("code",{children:"DEFAULT"}),"，即跟随底层数据库的隔离级别。"]}),e.jsx(s,{variant:"warn",title:"REQUIRES_NEW 用不好会自己锁死自己",children:e.jsxs("p",{children:["一个真实生产事故：外层事务已经锁了某行（比如 ",e.jsx("code",{children:"SELECT ... FOR UPDATE"}),"）， 内层用 ",e.jsx("code",{children:"REQUIRES_NEW"})," 开新事务、又去更新",e.jsx("strong",{children:"同一行"}),"。由于两个事务用的是",e.jsx("strong",{children:"不同的物理连接"}),"，内层会一直等外层释放锁，而外层又在等内层方法返回—— 活生生造出一个",e.jsx("strong",{children:"自我死锁"}),"，最终超时回滚。所以 ",e.jsx("code",{children:"REQUIRES_NEW"})," 虽好， 但要警惕「父子事务操作同一批数据」的场景，它不是「越独立越安全」。"]})}),e.jsxs(i,{title:"内部方法调用导致事务不生效",children:[e.jsxs("p",{children:["下面这段代码是最经典的「事务莫名不回滚」：",e.jsx("code",{children:"createOrder()"})," 内部直接调用了同类的",e.jsx("code",{children:"saveLog()"}),"。由于是 ",e.jsx("code",{children:"this.saveLog()"}),"，走的是",e.jsx("strong",{children:"原始对象"}),"而非代理对象， 代理织入的事务逻辑被整个绕开，",e.jsx("code",{children:"@Transactional"})," 形同虚设。"]}),e.jsx(r,{lang:"java",title:"同类自调用，事务失效",code:t}),e.jsxs("p",{children:["解法：把方法拆到另一个 Bean 里调用，或注入自身代理（",e.jsx("code",{children:"AopContext.currentProxy()"})," 或自注入）， 让调用重新经过代理。"]})]}),e.jsx(n,{title:"默认只回滚运行时异常",children:e.jsxs("p",{children:["Spring 的默认回滚策略只覆盖 ",e.jsx("em",{children:"RuntimeException"})," 和 ",e.jsx("em",{children:"Error"}),"。 也就是说，如果你的方法抛的是",e.jsx("strong",{children:"受检异常"}),"（checked exception，如 ",e.jsx("code",{children:"IOException"}),"、",e.jsx("code",{children:"SQLException"}),"），事务",e.jsx("strong",{children:"不会回滚"}),"，数据照样提交。想让受检异常也回滚， 必须显式声明 ",e.jsx("code",{children:"@Transactional(rollbackFor = Exception.class)"}),"。这是最隐蔽的失效场景之一， 因为代码没报错、注解也在，数据却悄悄落库了。"]})}),e.jsxs(s,{variant:"warn",title:"事务失效的经典场景清单",children:[e.jsx("p",{children:"记住这一串，面试和排错都够用："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"方法非 public"}),"：Spring 默认只对 public 方法织入事务，private 或 protected 不生效。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"同类内部自调用"}),"：",e.jsx("code",{children:"this.method()"})," 不走代理，事务被绕过（上面的例子）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"异常被 catch 吞掉"}),"：方法内 try-catch 后没有重新抛出，代理感知不到异常，自然不回滚。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"抛检查异常"}),"：默认只对运行时异常回滚，受检异常需配置 ",e.jsx("code",{children:"rollbackFor = Exception.class"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"多线程"}),"：事务靠 ThreadLocal 绑定连接，新开线程拿不到同一个连接，事务不共享。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"数据库引擎不支持"}),"：如 MySQL 用 MyISAM 引擎本身不支持事务，注解再多也没用（须用 InnoDB）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Bean 没被 Spring 管理"}),"：自己 new 出来的对象不是代理，注解无效。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"方法被 final/static 修饰"}),"：CGLIB 靠子类重写增强，final/static 方法无法被重写，事务织不进去。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"没配事务管理器或没开 @EnableTransactionManagement"}),"：纯 Spring 项目里忘了开启，注解就是个摆设（Spring Boot 已自动开启）。"]})]})]}),e.jsxs(i,{title:"编程式事务：当注解实在不靠谱时",children:[e.jsxs("p",{children:["声明式事务踩坑后，很多人转向",e.jsx("strong",{children:"编程式事务"}),"（",e.jsx("code",{children:"TransactionTemplate"}),"）。 它的优势是",e.jsx("strong",{children:"事务边界由你手写代码精确圈定"}),"，不依赖代理、不存在自调用失效， 还能用 ",e.jsx("code",{children:"setRollbackOnly()"})," 主动控制回滚而非靠抛异常："]}),e.jsx(r,{lang:"java",title:"BatchService.java（编程式事务）",code:a}),e.jsxs("p",{children:["选型建议：日常优先用 ",e.jsx("code",{children:"@Transactional"}),"（简洁），但在「事务范围需精细控制」「循环里逐条小事务提交」 「想缩小事务粒度避免长事务占连接」这些场景，编程式事务更可控。",e.jsx("strong",{children:"长事务"}),"是性能杀手—— 它长时间占着数据库连接和行锁，务必把事务方法里的远程调用、文件 IO 这类慢操作挪出去。"]})]}),e.jsxs(n,{title:"NESTED 实战：主流程稳、子流程可败",children:[e.jsx("p",{children:"转账加积分是 NESTED 的经典用例——转账必须成功，积分失败可以容忍。看这段："}),e.jsx(r,{lang:"java",title:"AccountService.java（NESTED 用法）",code:h}),e.jsxs("p",{children:["内层积分用 ",e.jsx("code",{children:"NESTED"})," 开 savepoint，失败时 catch 住只回滚到 savepoint，转账主流程照常推进。 若换成 ",e.jsx("code",{children:"REQUIRED"}),"，内层一抛异常会把整个外层事务标记为 rollback-only，连转账也一起黄了。"]})]}),e.jsx("h2",{children:"实战 / 面试怎么答"}),e.jsxs("p",{children:["先点出根：「声明式事务靠 ",e.jsx("strong",{children:"AOP 代理"}),"，所以一切让调用",e.jsx("em",{children:"不经过代理"}),"或让代理",e.jsx("em",{children:"感知不到异常"}),"的情况，都会导致失效。」 然后分两条线展开：传播行为重点讲清 REQUIRED / REQUIRES_NEW / NESTED 的区别；失效场景按上面的清单逐条列出， 每条都能补一句「为什么」。能讲出「ThreadLocal 绑连接、默认只回滚运行时异常需 ",e.jsx("code",{children:"rollbackFor"}),"」这种细节，会显得很扎实。"]}),e.jsxs(d,{title:"REQUIRES_NEW 示例 + 失效场景自测",children:[e.jsx("p",{children:"用 REQUIRES_NEW 实现「主业务回滚、日志照样落库」：外层订单事务失败时，内层日志事务因为独立提交而不受影响。"}),e.jsx(r,{lang:"java",title:"OrderService.java",code:o}),e.jsx("p",{children:"动手把下面每条失效场景都复现一遍，亲眼确认「没回滚」："}),e.jsxs("ul",{children:[e.jsxs("li",{children:["把 ",e.jsx("code",{children:"@Transactional"})," 方法改成 ",e.jsx("code",{children:"private"}),"，观察不再回滚。"]}),e.jsxs("li",{children:["同类里用 ",e.jsx("code",{children:"this.xxx()"})," 调用带事务的方法，确认失效。"]}),e.jsx("li",{children:"方法内 try-catch 吞掉异常，确认数据已提交。"}),e.jsxs("li",{children:["抛一个受检异常（如 ",e.jsx("code",{children:"IOException"}),"），确认默认不回滚，再加 ",e.jsx("code",{children:"rollbackFor = Exception.class"})," 后回滚。"]})]})]}),e.jsx(l,{points:["声明式事务的本质是 AOP 代理：只有经过代理的调用，@Transactional 才生效。","七种传播行为重点记三种：REQUIRED 加入当前事务，REQUIRES_NEW 挂起外层开独立事务，NESTED 基于 savepoint 的嵌套事务。","REQUIRES_NEW 是两个独立事务互不牵连；NESTED 是父子关系，外层回滚会连带内层。","隔离级别对应数据库四级，默认 DEFAULT 跟随数据库（MySQL InnoDB 默认 REPEATABLE_READ）。","失效场景：非 public、同类自调用、异常被吞、抛检查异常未配 rollbackFor、多线程、引擎不支持、Bean 未被管理。","事务本质=取一个连接关掉 autoCommit 并绑定到线程 ThreadLocal，所以换线程事务必丢、长事务长期占连接和锁。","REQUIRES_NEW 用不同物理连接，父子操作同一行可能自我死锁；NESTED 共用连接、外层回滚会带回内层。","注解失效或边界要精控时改用编程式事务 TransactionTemplate，可 setRollbackOnly 主动回滚、不受自调用影响。","面试落点：先讲清「靠代理」这个根，再用它推导每一种失效原因，最后给出对应解法。"]})]})}export{T as default};
