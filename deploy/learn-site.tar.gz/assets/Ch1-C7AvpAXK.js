import{r as d,j as e}from"./index-C4u1Qi4f.js";import{L as h,a as x,P as k,C as c,S as j}from"./Summary-DjSaQefZ.js";import{K as m}from"./KeyIdea-BS4xPn0s.js";import{E as f}from"./Example-DNWIRw6O.js";import{F as b}from"./Figure-D2qsSgWq.js";const a=[{key:"confirm",name:"生产者确认",ok:"publisher confirm 收到 broker 应答，确认发达",bad:"没开 confirm：网络丢了也以为成功 → 丢消息"},{key:"persist",name:"持久化",ok:"队列与消息都持久化到磁盘，broker 重启不丢",bad:"没持久化：broker 一重启，内存里的消息全没 → 丢消息"},{key:"ack",name:"消费者 ack",ok:"处理成功才手动 ack，broker 才删除消息",bad:"自动 ack：刚拿到就被标记完成，消费中崩溃 → 丢消息"}];function u(){const[n,s]=d.useState(null),t=e.jsxs(e.Fragment,{children:[a.map(r=>e.jsx("button",{className:`fig-btn ${n===r.key?"active":""}`,onClick:()=>s(n===r.key?null:r.key),children:n===r.key?`✓ ${r.name}失效`:`让${r.name}失效`},r.key)),e.jsx("span",{className:"fig-note",children:n?"这一环失效 → 消息丢失":"三道防线齐全 → 不丢"})]});return e.jsx(b,{caption:"一条消息从生产到消费要过三关：发到 broker(生产者确认)、存到磁盘(持久化)、被成功消费(手动 ack)。任一关失守都会丢消息。点按钮模拟某环失效。",controls:t,children:e.jsxs("svg",{viewBox:"0 0 460 200",width:"460",role:"img","aria-label":"消息可靠投递三道防线",children:[a.map((r,o)=>{const i=n===r.key,l=20+o*150;return e.jsxs("g",{children:[e.jsx("rect",{x:l,y:"30",width:"120",height:"60",rx:"10",fill:i?"var(--rose-soft)":"var(--green-soft)",stroke:i?"var(--rose)":"var(--green-line)",strokeWidth:i?2:1}),e.jsx("circle",{cx:l+60,cy:"50",r:"12",fill:i?"var(--rose)":"var(--green)"}),e.jsx("text",{x:l+60,y:"55",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"12",fontWeight:"700",fill:"#ffffff",children:i?"✕":"✓"}),e.jsx("text",{x:l+60,y:"80",textAnchor:"middle",fontFamily:"var(--sans)",fontSize:"12",fontWeight:"600",fill:"var(--ink)",children:r.name}),o<2&&e.jsx("text",{x:l+132,y:"64",textAnchor:"middle",fontFamily:"var(--mono)",fontSize:"14",fill:"var(--ink-faint)",children:"▸"})]},r.key)}),e.jsx("rect",{x:"20",y:"110",width:"420",height:"76",rx:"10",fill:n?"var(--rose-soft)":"var(--green-soft)",stroke:n?"var(--rose-line)":"var(--green-line)"}),e.jsx("text",{x:"34",y:"132",fontFamily:"var(--display)",fontSize:"14",fontWeight:"700",fill:n?"var(--rose)":"var(--green)",children:n?"✕ 消息可能丢失":"✓ 消息不丢"}),a.map((r,o)=>e.jsxs("text",{x:"34",y:150+o*13,fontFamily:"var(--sans)",fontSize:"10.5",fill:"var(--ink-soft)",children:["· ",r.name,"：",n===r.key?r.bad:r.ok]},r.key))]})})}const g=`import com.rabbitmq.client.Channel;
import com.rabbitmq.client.MessageProperties;

// 1) 生产者端：开启 publisher confirm
channel.confirmSelect();

// 2) 声明持久化的交换机和队列（durable = true）
channel.exchangeDeclare("order.exchange", "direct", true);
channel.queueDeclare("order.queue", true, false, false, null);
channel.queueBind("order.queue", "order.exchange", "create");

// 3) 发消息时把消息也设成持久化（deliveryMode = 2）
channel.basicPublish(
    "order.exchange",
    "create",
    MessageProperties.PERSISTENT_TEXT_PLAIN,   // deliveryMode = 2
    "order-1001".getBytes()
);

// 4) 等 broker 回执，确认这条消息确实落到了队列
if (channel.waitForConfirms(5000)) {
    System.out.println("broker 已确认收下");
} else {
    System.out.println("没收到确认，需要重发或记录补偿");
}`,y=`// 消费者端：关闭 autoAck，改成手动 ack
boolean autoAck = false;
channel.basicQos(1);   // 一次只取一条，处理完再取下一条

channel.basicConsume("order.queue", autoAck, (tag, delivery) -> {
    long deliveryTag = delivery.getEnvelope().getDeliveryTag();
    try {
        handle(new String(delivery.getBody()));   // 真正的业务处理
        // 处理成功，才告诉 broker 可以删消息了
        channel.basicAck(deliveryTag, false);
    } catch (Exception e) {
        // 处理失败：拒绝并重新入队，留给下一次重试
        channel.basicNack(deliveryTag, false, true);
    }
}, tag -> {});`;function F(){return e.jsxs(e.Fragment,{children:[e.jsx(h,{children:e.jsxs("p",{children:["“消息会不会丢”是 RabbitMQ 面试的第一道硬菜。答案是：一条消息从生产者出发，到被消费者成功处理， 要经过三段旅程，",e.jsx("strong",{children:"每一段都可能丢"}),"。想做到不丢，就得在三个环节各设一道防线，缺一不可。 这一节把三道防线一次讲透。"]})}),e.jsx("h2",{children:"消息会在哪三个环节丢"}),e.jsx("p",{children:"把一条消息的一生拆开看，它要走三步：生产者把消息发给 broker、broker 把消息存起来、broker 再把消息投给消费者。 对应三个丢失点："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"生产者 → broker"}),"：网络抖动、broker 宕机，消息根本没到，生产者却以为发成功了。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"broker 存储期间"}),"：消息只在内存里，broker 一重启就没了。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"broker → 消费者"}),"：消费者刚拿到消息、还没处理完就崩了，消息却已经从队列删除。"]})]}),e.jsx("h3",{children:"第一道防线：生产者确认 publisher confirm"}),e.jsxs("p",{children:["要确保消息真的到了 broker，靠的是 ",e.jsx("em",{children:"publisher confirm"}),"（发布确认）机制。开启后，broker 每收下一条消息， 就回一个 ack 给生产者；如果消息进不了队列，则回 nack。生产者据此判断是否要重发。"]}),e.jsxs("p",{children:["另一种方案是 ",e.jsx("em",{children:"transaction"}),"（事务），但事务是同步阻塞的，每次提交都要和 broker 一来一回， 吞吐会掉一个数量级。所以生产环境基本都用 confirm，几乎不用事务。"]}),e.jsx("h3",{children:"第二道防线：三件套持久化"}),e.jsxs("p",{children:["消息确认到了 broker，还要保证 broker 重启后它还在。这需要三处同时持久化：",e.jsx("strong",{children:"交换机持久化"}),"（exchangeDeclare 的 durable=true）、",e.jsx("strong",{children:"队列持久化"}),"（queueDeclare 的 durable=true）、 以及",e.jsx("strong",{children:"消息持久化"}),"（投递时设 ",e.jsx("code",{children:"deliveryMode=2"}),"）。三者缺一，重启后都可能丢。"]}),e.jsx("h3",{children:"第三道防线：消费者手动 ack"}),e.jsxs("p",{children:["默认的 ",e.jsx("em",{children:"autoAck"})," 是「broker 把消息推给消费者的那一刻就当作已消费、立刻删除」。一旦消费者拿到消息后崩溃， 消息就再也找不回来了。正确做法是关闭 autoAck，改成",e.jsx("strong",{children:"手动 ack"}),"：业务处理成功才 ack， 失败就 nack/reject 让消息重新入队或进死信。"]}),e.jsxs(f,{title:"一条订单消息走完三道防线",children:[e.jsx("p",{children:"下单服务发出「订单 1001 已创建」这条消息："}),e.jsxs("ul",{children:[e.jsx("li",{children:"发出后等到 broker 的 confirm 回执，确认消息落到了队列（第一道）；"}),e.jsx("li",{children:"交换机、队列、消息都持久化，即便此刻 broker 重启，消息仍躺在磁盘上（第二道）；"}),e.jsx("li",{children:"库存服务取走消息、扣完库存后才 ack；若扣库存时进程被 kill，消息会重回队列被重投（第三道）。"})]}),e.jsx("p",{children:"三道防线都立住了，这条消息才算「绝不会丢」。"})]}),e.jsx(u,{}),e.jsx(m,{title:"不丢 = 三段链路各自闭环",children:e.jsxs("p",{children:["可靠投递不是一个开关，而是",e.jsx("strong",{children:"三段链路各自闭环"}),"：每一段都要有「对方确认收到」的回执， 中间环节还要能扛住重启。任何一段只发不确认，整条链路就漏了。记住这条主线，三道防线的代码细节自然就串起来了。"]})}),e.jsx(x,{variant:"warn",title:"只持久化、不开 confirm 也会丢",children:e.jsxs("p",{children:["常见误区是「我把队列和消息都设成持久化了，应该不会丢吧」。其实持久化是异步刷盘的—— 消息可能还在操作系统的页缓存里没落盘，broker 就宕机了。所以持久化必须和 publisher confirm 配合： broker 只有在",e.jsx("strong",{children:"真正刷盘后"}),"才回 confirm，这时生产者才能安心。"]})}),e.jsx("h2",{children:"面试怎么答 / 实战要点"}),e.jsx("p",{children:"被问「RabbitMQ 怎么保证消息不丢」，别只背名词，按三段链路答：“消息分三段可能丢，所以设三道防线—— 生产端开 publisher confirm 拿回执（事务太慢不用），存储端把交换机、队列、消息都持久化（deliveryMode=2）， 消费端关 autoAck 改手动 ack、处理成功才确认。三者缺一不可。” 这样答既有结构又显原理。"}),e.jsxs(k,{title:"搭一条不丢消息的最小链路",children:[e.jsx("p",{children:"用 RabbitMQ Java 客户端把三道防线一次配齐：生产端开 confirm + 持久化发送，消费端手动 ack。 先跑通正常流程，再故意在消费时抛异常，观察消息是否被重新投递。"}),e.jsx(c,{lang:"java",title:"ReliableProducer.java",code:g}),e.jsx("p",{children:"消费端关闭 autoAck，处理成功才 ack，失败 nack 重新入队："}),e.jsx(c,{lang:"java",title:"ReliableConsumer.java",code:y}),e.jsxs("p",{children:["进阶：把 ",e.jsx("code",{children:"waitForConfirms"})," 换成异步的 ",e.jsx("code",{children:"addConfirmListener"}),"， 用一个有序集合记录未确认的 deliveryTag，体会高吞吐下「批量异步确认」是怎么做的。"]})]}),e.jsx(j,{points:["一条消息有三个丢失点：生产者到 broker、broker 存储期间、broker 到消费者，要分别设防。","第一道：生产者开 publisher confirm 拿 broker 回执；事务也能保证但同步阻塞、性能差，基本不用。","第二道：交换机、队列、消息三件套都要持久化，消息靠 deliveryMode=2，缺一在重启后都可能丢。","第三道：消费者关闭 autoAck 改手动 ack，业务成功才 ack，失败 nack/reject 重新入队或进死信。","持久化是异步刷盘，必须和 confirm 配合：broker 刷盘后才回 confirm，生产者才真正安全。","三道防线缺一不可，面试按“三段链路各自闭环”这条主线作答最稳。"]})]})}export{F as default};
