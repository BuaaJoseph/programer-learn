import{j as s}from"./index-DL563RIm.js";import{L as i,S as t}from"./Summary-BrgLcNDp.js";import{K as d}from"./KeyIdea-exK4GrdK.js";import{E as r}from"./Example-HxOmIesu.js";import{P as l}from"./Practice-r6liJb9j.js";import{C as e}from"./Callout-B-8nslAm.js";import{C as n}from"./CodeBlock-DkVyd3P6.js";const c=`def should_finetune(case):
    """一个粗糙但好用的决策清单：返回该走哪条路。
    输入 case 是一个描述需求的字典。"""

    # 1) 先问：问题出在「知识」还是「行为」？
    if case['need'] == 'fresh_facts':
        # 需要最新的、私有的、会变的事实 -> 这是 RAG 的活
        return 'RAG'

    # 2) 行为问题：能不能用 prompt 说清楚？
    if case['can_describe_in_prompt'] and case['volume'] == 'low':
        # 规则能写进 system prompt，调用量也不大 -> 先 prompt
        return 'PROMPT'

    # 3) 行为稳定、且满足下面任一条，才考虑微调
    finetune_signals = [
        case['need'] == 'fixed_style',      # 固定风格/语气/格式
        case['need'] == 'strict_format',    # 必须严格结构化输出
        case['need'] == 'cut_token_cost',   # 用小模型省 token
        case['need'] == 'distill',          # 蒸馏大模型能力到小模型
    ]
    if any(finetune_signals) and case['has_labeled_data']:
        return 'FINETUNE'

    # 4) 默认：先把 prompt 和 RAG 榨干，别急着微调
    return 'PROMPT_THEN_RAG'`,h=`# 同一个任务，三条路线的「全成本」粗算（数量级感受，不是精确账）
routes = {
    'prompt': {
        '上线时间': '小时级',
        '一次性成本': '几乎为 0（写写改改）',
        '每次调用成本': '高 —— 长 prompt 把示例和规则都塞进 token',
        '维护成本': '极低，改一行字符串即可',
        '可解释性': '高，逻辑全在明面上',
    },
    'rag': {
        '上线时间': '天级（要搭检索、切块、向量库）',
        '一次性成本': '中（建索引、调召回）',
        '每次调用成本': '中 —— 检索片段也占 token，但比堆全量示例省',
        '维护成本': '中，换文档库 / 重建索引即可，不用碰模型',
        '可解释性': '高，能看到检索到了哪些片段',
    },
    'finetune': {
        '上线时间': '周级（数据标注 + 训练 + 评测 + 上线）',
        '一次性成本': '高（标注 + 算力 + 实验迭代）',
        '每次调用成本': '低 —— prompt 可以写得很短，规则已内化进权重',
        '维护成本': '高，换基座要重训，加行为要重训，得管模型版本',
        '可解释性': '低，行为被压进参数，难定位',
    },
}

# 一句话：prompt/RAG 是「前期便宜、单次贵」，微调是「前期贵、单次便宜」。
# 调用量越大，微调摊薄一次性成本的优势才显现 —— 这是个盈亏平衡点问题。
for name, c in routes.items():
    print(name, '->', c['每次调用成本'])`;function R(){return s.jsxs(s.Fragment,{children:[s.jsx(i,{children:s.jsxs("p",{children:["很多团队一遇到「模型表现不够好」，第一反应就是「那我们微调一个吧」。这往往是最贵、最慢、最容易翻车的选择。 在动手之前，你需要先想清楚一件事：你到底是想改变模型的",s.jsx("strong",{children:"行为"}),"，还是想给它补充",s.jsx("strong",{children:"知识"}),"？ 这一章不写代码，只帮你把这个判断做对。"]})}),s.jsx("h2",{children:"改变模型行为的三层"}),s.jsx("p",{children:"想让一个大模型按你的意思办事，你能动的东西其实只有三层，从轻到重排列："}),s.jsxs("ul",{children:[s.jsxs("li",{children:[s.jsx("strong",{children:"Prompt"}),"——改的是「题面」。你不碰模型，只是把任务、规则、示例写进上下文里，让冻结的参数在更好的引导下作答。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"RAG"}),"——改的是「资料」。你在推理时临时检索外部文档塞进上下文，给模型补上它参数里没有的事实。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"微调"}),"（fine-tuning）——改的是「权重」。你真的去更新模型参数，把某种行为永久地刻进它体内。"]})]}),s.jsxs("p",{children:["前两层都是在",s.jsx("em",{children:"推理时"}),"动上下文，模型本身一个字节都没变；只有第三层是真正改了模型。理解这个分层， 是做技术选型的起点。"]}),s.jsxs("p",{children:["为什么要按「轻→重」排？因为这三层的",s.jsx("strong",{children:"可逆性"}),"天差地别。Prompt 错了，删掉那段字符串就回到原点， 损失只有几分钟；RAG 召回脏数据，重建一次索引就干净了，模型没受任何污染；而微调一旦把某种坏行为压进权重， 你无法「撤销」某一条样本的影响，只能拿更多数据再训一轮去覆盖它，甚至重新从基座开始。越往下，犯错的代价越不可逆， 所以越往后再用。这背后其实是一个朴素的工程原则：",s.jsx("em",{children:"把不确定性留在容易回滚的地方"}),"。"]}),s.jsxs("p",{children:["还有一个常被忽略的维度——",s.jsx("strong",{children:"谁能改它"}),"。Prompt 产品经理就能改，RAG 运营换文档就能更新，而微调必须由 懂训练的工程师走一整套流水线。把逻辑放在越「轻」的层，能动手的人就越多，团队的迭代带宽就越宽。这也是为什么成熟团队 会刻意抵抗「一遇到问题就微调」的冲动：每沉淀一条到权重里，就等于把这条逻辑从「全员可改」降级成「专人可改」。"]}),s.jsx("h3",{children:"一句话记住核心判断"}),s.jsxs("p",{children:[s.jsx("strong",{children:"微调改行为，RAG 注事实。"}),"这八个字能挡掉大半的错误决策。如果你的痛点是「模型不知道我们公司上周发布的新规」， 那是知识缺口，再怎么微调也是徒劳——你今天微调进去的事实，下周又过期了。反过来，如果痛点是「不管我怎么写 prompt， 它的语气就是不像我们品牌」，那再多检索文档也救不了，这是行为问题，才该考虑微调。"]}),s.jsxs("p",{children:["为什么微调灌事实这么不靠谱？从原理看，微调是在用梯度下降微调一个庞大概率分布，它学到的是「在这种上下文下， 下一个 token 大概率是什么」的",s.jsx("strong",{children:"统计倾向"}),"，而不是一张可查询的事实表。你训练几条「我们公司退款期是 30 天」， 模型确实会更容易说出「30 天」，但它并不「知道」这是一条可被更新的事实——当政策改成 15 天，你没法定点修改， 只能再喂一批新样本去稀释旧倾向，而旧的「30 天」记忆往往还会零星冒出来。这就是为什么会变、要精确、需溯源的信息， 天生属于 RAG 的地盘：检索到什么就说什么，改文档即生效，还能把出处贴给用户看。"]}),s.jsxs(r,{title:"同一个症状，不同的解法",children:[s.jsx("p",{children:"客服机器人「答得不好」，拆开看可能是三种完全不同的病："}),s.jsxs("ul",{children:[s.jsxs("li",{children:["答案",s.jsx("strong",{children:"事实错误"}),"（报错了退款政策的天数）→ 知识问题 → 用 ",s.jsx("em",{children:"RAG"})," 把最新政策文档检索进来。"]}),s.jsxs("li",{children:["答案",s.jsx("strong",{children:"语气太机械"}),"（不像我们温暖的品牌调性）→ 行为问题，但能描述清楚 → 先在 ",s.jsx("em",{children:"system prompt"})," 里写风格要求。"]}),s.jsxs("li",{children:["语气要求",s.jsx("strong",{children:"极其细腻、prompt 写到几百字还是不稳"}),"，而且每天几百万次调用 → 这才轮到 ",s.jsx("em",{children:"微调"}),"。"]})]})]}),s.jsx(d,{title:"决策顺序：prompt → RAG → 微调",children:s.jsxs("p",{children:["这三层不是平行的选项，而是有",s.jsx("strong",{children:"先后顺序"}),"的阶梯：永远先用最便宜的 prompt 试，不行再上 RAG， 实在还不行才动微调。原因很现实——微调最贵：它需要标注数据、训练算力、版本管理、上线后还要持续维护一套自己的模型。 prompt 改一行就能上线，RAG 换个文档库就生效，而微调的每次迭代都是以天甚至周计的工程。",s.jsx("strong",{children:"把微调放在最后"}),"， 不是因为它没用，而是因为它的成本应该匹配它的收益。"]})}),s.jsx(e,{variant:"warn",title:"别用微调去做这两件事",children:s.jsxs("ul",{children:[s.jsxs("li",{children:[s.jsx("strong",{children:"别用微调灌输事实"}),"——模型不会因为你训练过几条数据就「记住」某个事实，它只是把统计规律调了调； 想灌进去新知识需要海量重复样本，且无法精确控制，还会引入幻觉。事实交给 RAG。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"别用微调替代能力"}),"——如果基座模型本身不会写代码，微调几千条样本也教不会它编程；微调是「塑形」已有能力， 不是「凭空长出」新能力。"]})]})}),s.jsx("h2",{children:"什么场景才真该微调"}),s.jsx("p",{children:"说了这么多「先别微调」，那到底什么时候该微调？下面四类场景是微调真正发光的地方："}),s.jsxs("ul",{children:[s.jsxs("li",{children:[s.jsx("strong",{children:"固定风格 / 格式"}),"——你要的输出有非常稳定的结构或腔调（比如永远输出某种 JSON schema、永远用某种法律文书口吻）， 用 prompt 描述要写很长还不稳，微调能把这种「定式」固化下来。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"领域语气"}),"——医疗、法律、金融等领域有自己的措辞习惯和谨慎度，微调能让模型自然地说「行话」。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"降低 token 成本"}),"——如果你每次调用都要塞几千 token 的示例和规则，微调可以把这些「内化」进权重， 从此 prompt 写得很短就能达到同样效果，高频调用下省下的钱非常可观。"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"蒸馏"}),"（distillation）——用大而贵的模型生成高质量数据，再去微调一个小而快的模型，让小模型在你这个具体任务上逼近大模型， 兼顾质量和成本。"]})]}),s.jsx("h3",{children:"盈亏平衡：微调到底什么时候才「划算」"}),s.jsxs("p",{children:["前面说微调最贵，但「贵」要分前期和长期看。Prompt 和 RAG 是",s.jsx("strong",{children:"前期便宜、单次贵"}),"——不用训练，但每次调用都拖着长长的 示例和检索片段，token 一直在烧钱。微调反过来，是",s.jsx("strong",{children:"前期贵、单次便宜"}),"——一次性砸下标注和算力，但之后 prompt 可以缩到极短， 规则已经内化进权重。所以是否微调，本质是一道盈亏平衡题：调用量越大、单次省下的 token 越多，那笔一次性投入摊薄得越快。 每天几百次调用，怎么算都是 prompt 划算；每天几百万次、且每次能砍掉几千 token，微调的账才翻得过来。"]}),s.jsxs("table",{children:[s.jsx("thead",{children:s.jsxs("tr",{children:[s.jsx("th",{children:"维度"}),s.jsx("th",{children:"Prompt"}),s.jsx("th",{children:"RAG"}),s.jsx("th",{children:"微调"})]})}),s.jsxs("tbody",{children:[s.jsxs("tr",{children:[s.jsx("td",{children:"上线速度"}),s.jsx("td",{children:"小时级"}),s.jsx("td",{children:"天级"}),s.jsx("td",{children:"周级"})]}),s.jsxs("tr",{children:[s.jsx("td",{children:"一次性成本"}),s.jsx("td",{children:"几乎为 0"}),s.jsx("td",{children:"中"}),s.jsx("td",{children:"高"})]}),s.jsxs("tr",{children:[s.jsx("td",{children:"单次调用成本"}),s.jsx("td",{children:"高（长 prompt）"}),s.jsx("td",{children:"中"}),s.jsx("td",{children:"低（短 prompt）"})]}),s.jsxs("tr",{children:[s.jsx("td",{children:"更新事实"}),s.jsx("td",{children:"改字符串"}),s.jsx("td",{children:"换文档（最佳）"}),s.jsx("td",{children:"要重训（最差）"})]}),s.jsxs("tr",{children:[s.jsx("td",{children:"可解释 / 可回滚"}),s.jsx("td",{children:"高"}),s.jsx("td",{children:"高"}),s.jsx("td",{children:"低"})]})]})]}),s.jsxs(r,{title:"蒸馏的真实玩法",children:[s.jsx("p",{children:"一个意图分类任务，原本直接调大模型，准确率 95%，但每条 0.02 元、延迟 1.5 秒，扛不住高并发。做法是：先用大模型给 10 万条真实 query 打上标签（这步贵但只做一次），再用这 10 万条去微调一个小模型。结果小模型准确率 93%、每条 0.0002 元、 延迟 80 毫秒。损失 2 个点的准确率，换来约 100 倍成本下降和近 20 倍提速——这就是蒸馏的典型收益结构：用大模型的「判断力」 换小模型的「经济性」。注意它仍是微调，所以仍受「改行为不改知识」约束：分类边界变了要重训，但这恰恰是稳定高频的行为， 正中微调下怀。"}),s.jsx(n,{lang:"python",title:"route_cost.py",code:h})]}),s.jsx(e,{variant:"info",title:"一个反直觉的事实",children:s.jsxs("p",{children:["很多人以为微调能「提升智力」，让模型变得更聪明。基本不会。微调改的是",s.jsx("strong",{children:"分布的偏好"}),"，不是",s.jsx("strong",{children:"能力的天花板"}),"。 基座不会做的推理，微调后大概率还是不会；它只会让模型在你的任务上「更愿意按某种方式作答」。想要更强的推理能力， 应该换更大的基座或改进 prompt（比如让它分步思考），而不是寄望于微调。把微调当成「调音」，别当成「升级 CPU」。"]})}),s.jsx("h2",{children:"这对做 Agent / 工程实践意味着什么"}),s.jsxs("p",{children:["在 Agent 系统里，模型只是其中一环，外面还包着工具调用、检索、记忆、编排。盲目微调会让这一环变成",s.jsx("strong",{children:"难以维护的黑盒"}),"： 换基座要重训，加新行为要重训，出了问题难以定位。工程上的健康做法是——尽量把",s.jsx("strong",{children:"可变的东西"}),"（事实、规则、工具说明） 留在上下文里，用 prompt 和 RAG 解决，只把",s.jsx("strong",{children:"真正稳定且高频"}),"的行为沉淀为微调。这样系统的大部分逻辑都是 「看得见、改得动」的，迭代速度才快。微调是终点，不是起点。"]}),s.jsxs("p",{children:["还有一类极常见的误区值得专门点名——",s.jsx("strong",{children:"「数据飞轮」幻觉"}),"。很多团队以为只要把线上对话日志一股脑喂回去微调， 模型就会越用越聪明。现实是：未经清洗的日志里混着用户的错误问法、模型自己的幻觉回答、矛盾的标注，直接拿来训练， 等于把噪声和坏行为也一起固化进权重，模型只会越训越偏。真正的飞轮需要一道严格的",s.jsx("strong",{children:"数据筛选与标注关卡"}),"： 只保留高质量、被人工或规则确认过的样本。微调的上限从来不由数据量决定，而由数据质量决定——一万条精挑的样本， 通常胜过十万条原始日志。"]}),s.jsx("p",{children:"最后给一个落地时的决策节奏，照着走基本不会错：先用 prompt 把任务说清楚并跑出一条能用的基线；基线之上若发现是事实/时效问题， 加 RAG；若 RAG 也补不齐、确认是稳定的行为或成本问题，再收集并清洗标注数据、小规模微调试水、用独立评测集量化收益， 确认 ROI 为正才放大。每一步都先问「上一步真的榨干了吗」，能省下的不只是钱，还有未来维护的精力。"}),s.jsxs(l,{title:"先跑一遍决策清单",children:[s.jsx("p",{children:"把你手头那个「想微调」的需求，套进下面这个判断函数走一遍。重点不是这段代码本身，而是它逼你回答的那几个问题： 你缺的是事实还是行为？能不能用 prompt 描述清楚？有没有标注数据？"}),s.jsx(n,{lang:"python",title:"should_finetune.py",code:c}),s.jsxs("p",{children:["如果跑下来结果是 ",s.jsx("code",{children:"PROMPT"})," 或 ",s.jsx("code",{children:"RAG"}),"，恭喜你省下了一大笔训练成本；只有当它返回 ",s.jsx("code",{children:"FINETUNE"}),"， 再翻开后面几章正式动手。"]})]}),s.jsx(t,{points:["改变模型行为有三层：prompt 改「题面」、RAG 改「资料」、微调改「权重」；前两层不动模型，只有微调真改参数。","核心判断只有八个字：微调改行为，RAG 注事实——事实缺口别指望靠微调补。","决策有先后顺序：先 prompt、再 RAG、最后才微调，因为微调最贵、最慢、最难维护。","别用微调灌事实或凭空造能力；微调是给已有能力「塑形」，不是长出新能力。","真该微调的场景：固定风格/格式、领域语气、降低 token 成本、蒸馏小模型。","工程上把可变的东西留在上下文，只把稳定高频的行为沉淀为微调，系统才迭代得快。"]})]})}export{R as default};
