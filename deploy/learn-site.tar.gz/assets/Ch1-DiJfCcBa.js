import{j as e}from"./index-Bkb6eOY7.js";import{L as i,S as c}from"./Summary-Dj-Y5ESD.js";import{K as s}from"./KeyIdea-N6HVLWjp.js";import{C as n}from"./Callout-FpvHzM97.js";import{C as r}from"./CodeBlock-BQqVtp_3.js";import{E as d}from"./Example-iLfTRUEi.js";import{R as t}from"./RenderCycle-CY9EBXO7.js";import"./Figure-CA62yyrP.js";const l=`// 直接操作真实 DOM：又啰嗦又容易出错
function renderList(items) {
  const ul = document.getElementById('list')
  ul.innerHTML = ''                       // 一把全清，丢掉所有已有状态
  for (const it of items) {
    const li = document.createElement('li')
    li.textContent = it.name              // 漏一处就和数据对不上
    if (it.done) li.classList.add('done') // 状态分支全靠手动同步
    ul.appendChild(li)                    // 每次 append 都可能触发回流
  }
}
// 数据一变，你得自己想清楚「哪几个节点要改、怎么改、改的顺序」——
// 这正是 UI bug 的高发区。`,h=`// 声明式：你只描述「这一份数据应该长成什么样」
function List({ items }) {
  return (
    <ul>
      {items.map((it) => (
        <li key={it.id} className={it.done ? 'done' : ''}>
          {it.name}
        </li>
      ))}
    </ul>
  )
}
// 数据变了，你只管返回新的「应有样子」，
// 由 React 去算出真实 DOM 要做哪些最小改动。`,o=`// JSX 只是语法糖，编译后是普通对象（React 元素）
const el = <h1 className="title">Hi</h1>

// 约等于：
const el2 = {
  type: 'h1',                       // 字符串 => 原生标签；函数 => 组件
  props: { className: 'title', children: 'Hi' },
  key: null,
  // ...React 内部还会挂别的字段
}
// 元素是「不可变的描述」，不是真实 DOM 节点本身。
// 一次 render 产出的就是这样一棵「元素树」。`,x=`// ❌ 渲染阶段里干副作用——大忌
function Bad({ id }) {
  fetch('/api/log?id=' + id)          // 发请求：render 可能被丢弃/重跑，会重复触发
  document.title = 'Detail ' + id     // 直接改 DOM：和 React 的提交时机打架
  window.scrollTo(0, 0)               // 同上
  return <div>...</div>
}

// ✅ 副作用放进 Effect，由 React 在 commit 后按规则调度
function Good({ id }) {
  useEffect(() => {
    fetch('/api/log?id=' + id)
    document.title = 'Detail ' + id
  }, [id])
  return <div>...</div>
}`,j=`// 直观理解：Fiber 把「递归遍历组件树」改写成「遍历一张链表」
// 每个 Fiber 节点大致带这些指针，于是遍历可以随时停下、之后再接着走：
const fiber = {
  type: App,          // 对应的组件 / 标签
  child: <Fiber>,     // 第一个子节点
  sibling: <Fiber>,   // 下一个兄弟节点
  return: <Fiber>,    // 父节点（处理完自己后往哪回）
  alternate: <Fiber>, // 指向上一次的 Fiber，用于本次 diff 复用
  flags: 'Update',    // 本节点要做的副作用（插入/更新/删除…）
}`;function M(){return e.jsxs("article",{children:[e.jsx(i,{children:"这一卷我们钻进 React 的发动机舱，看清「数据一变，屏幕为什么就跟着变」的全过程。 本章先建立最重要的心智模型：虚拟 DOM 是什么、为什么需要它，以及一次更新会依次经过 Render、Reconcile、Commit 三个阶段。理解了这条主线，后面讲 key、讲性能优化才不会是死记硬背。"}),e.jsx("h2",{children:"一、为什么要有虚拟 DOM"}),e.jsxs("p",{children:["浏览器里真正显示在屏幕上的是",e.jsx("strong",{children:"真实 DOM"}),"——一棵由浏览器维护的节点树。 直接用 ",e.jsx("code",{children:"document.createElement"}),"、",e.jsx("code",{children:"appendChild"}),"、改 ",e.jsx("code",{children:"innerHTML"}),"去操作它，有两个老大难问题。其一是",e.jsx("strong",{children:"慢"}),"：DOM 操作会牵动浏览器的样式计算、 布局回流与重绘，频繁、零散地改往往很贵；其二是",e.jsx("strong",{children:"易错"}),"：你得自己在脑子里维护 「当前界面是什么样、数据变了之后哪几个节点该改、按什么顺序改」，这是命令式代码里最容易出 bug 的地方。"]}),e.jsx(r,{lang:"jsx",title:"命令式操作真实 DOM：又啰嗦又易错",code:l}),e.jsxs("p",{children:["React 的思路是换一种写法：你不再告诉浏览器「怎么一步步改」，而是",e.jsx("strong",{children:"声明"}),"「这份数据对应的界面应该长什么样」。剩下「真实 DOM 到底要做哪些改动」的脏活，交给 React。"]}),e.jsx(r,{lang:"jsx",title:"声明式：只描述「应有的样子」",code:h}),e.jsxs(s,{children:["虚拟 DOM 是一棵用普通 JavaScript 对象描述界面的",e.jsx("strong",{children:"轻量树"}),"。React 在内存里 先算出这棵「应有的样子」的树，再和上一次的树比对，得出对真实 DOM 的",e.jsx("strong",{children:"最小改动集合"}),"， 最后才一次性落到屏幕上。它的价值不是「天生比手写 DOM 快」，而是",e.jsx("strong",{children:"把命令式的脏活 变成可被框架自动、批量、最小化处理的声明式问题"}),"。"]}),e.jsx("h2",{children:"二、React 元素：JSX 背后的对象"}),e.jsxs("p",{children:["要理解虚拟 DOM，先看它的最小单位——",e.jsx("strong",{children:"React 元素"}),"。我们写的 JSX 只是语法糖， 编译后会变成普通的 JavaScript 对象。"]}),e.jsx(r,{lang:"jsx",title:"JSX 编译后就是普通对象",code:o}),e.jsxs("p",{children:["关键点：元素是",e.jsx("strong",{children:"不可变的描述"}),"，它本身不是真实 DOM 节点，创建一个元素几乎不花钱。 其中 ",e.jsx("code",{children:"type"})," 决定了它是什么——字符串（如 ",e.jsx("code",{children:"'h1'"}),"）代表原生标签， 函数代表一个组件。一次渲染所产出的，就是这样一棵层层嵌套的元素树。"]}),e.jsx("h2",{children:"三、一次更新的三相流程"}),e.jsx("p",{children:"当某个组件需要更新（下一章细讲「何时」触发），React 会依次走过三个阶段。先点开下面这张图， 每个阶段点一下看它在做什么，再回到正文逐相拆解。"}),e.jsx(t,{}),e.jsx("h3",{children:"Render（渲染阶段）：算出新的元素树"}),e.jsxs("p",{children:["React 调用相关组件函数，执行其中的逻辑，",e.jsx("strong",{children:"算出"}),"一棵新的 React 元素树。 这一阶段是",e.jsx("strong",{children:"纯计算"}),"：给定相同的 props 与 state，应当返回相同的结果， 并且",e.jsx("strong",{children:"不产生任何副作用"}),"——不改 DOM、不发请求、不操作外部变量。"]}),e.jsxs("p",{children:["为什么要这么纯？因为在 Fiber 架构下，Render 阶段是",e.jsx("strong",{children:"可被中断、恢复，甚至整段丢弃"}),"的。 React 可能算到一半，发现来了更高优先级的更新（比如用户正在打字），就先把当前这次半成品丢掉， 转头处理紧急的，之后再重新算。如果你在渲染里发了请求或改了 DOM，这些副作用就会被重复触发、 或在错误的时机发生——界面与数据从此对不上。"]}),e.jsxs(n,{variant:"warn",title:"render 阶段必须是纯的",children:["永远不要在组件函数体（渲染过程中）里直接改 DOM、发网络请求、写全局变量或操作订阅。 这些副作用一律放进 ",e.jsx("code",{children:"useEffect"})," / ",e.jsx("code",{children:"useLayoutEffect"}),"，由 React 在 commit 之后按规则去跑。把这条当成红线。"]}),e.jsx(r,{lang:"jsx",title:"渲染里干副作用 vs 放进 Effect",code:x}),e.jsx("h3",{children:"Reconcile（调和阶段）：diff 比对，标记改动"}),e.jsxs("p",{children:["有了新算出的元素树，React 把它和上一次的 Fiber 树",e.jsx("strong",{children:"逐层比对（diff）"}),"， 靠节点的",e.jsx("strong",{children:"类型"}),"和 ",e.jsx("strong",{children:"key"})," 判断「这个节点是能复用并更新，还是要新建 / 删除」， 从而得出一份「最小真实改动集合」，把每个要做的动作（插入、更新、删除）",e.jsx("strong",{children:"标记"}),"到 对应节点的 effect 上。这一阶段同样属于「可中断」的工作，和 Render 一起合称为 render 阶段的工作。 diff 的具体启发式规则，是下一章的主角。"]}),e.jsx("h3",{children:"Commit（提交阶段）：一次性改真实 DOM"}),e.jsxs("p",{children:["前面两阶段都只在内存里算账，屏幕一点没动。到了 Commit，React 才把调和阶段标记好的改动",e.jsx("strong",{children:"同步、一次性"}),"地应用到真实 DOM 上——这一步",e.jsx("strong",{children:"不可中断"}),"，必须一鼓作气 完成，否则用户会看到「改了一半」的界面。提交完成后，React 按既定顺序运行各类副作用： 先处理 ",e.jsx("code",{children:"ref"})," 的挂载 / 卸载，再同步跑 ",e.jsx("code",{children:"useLayoutEffect"}),"（此时 DOM 已更新但浏览器还没绘制， 适合读取布局），最后异步调度 ",e.jsx("code",{children:"useEffect"}),"。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"阶段"}),e.jsx("th",{children:"在做什么"}),e.jsx("th",{children:"能否中断"}),e.jsx("th",{children:"有无副作用"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"Render"}),e.jsx("td",{children:"调用组件算出新元素树（纯计算）"}),e.jsx("td",{children:"可中断 / 恢复 / 丢弃"}),e.jsx("td",{children:"必须无副作用"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Reconcile"}),e.jsx("td",{children:"新旧树 diff，标记最小改动"}),e.jsx("td",{children:"可中断（属 render 工作）"}),e.jsx("td",{children:"无（仅标记）"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"Commit"}),e.jsx("td",{children:"一次性改真实 DOM + 跑 ref / Effect"}),e.jsx("td",{children:"不可中断（同步）"}),e.jsx("td",{children:"在此集中执行副作用"})]})]})]}),e.jsxs(d,{title:"把三相串起来：点一下按钮发生了什么",children:[e.jsxs("p",{children:["假设有 ",e.jsx("code",{children:"const [n, setN] = useState(0)"}),"，按钮点击调 ",e.jsx("code",{children:"setN(n + 1)"}),"："]}),e.jsxs("ol",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"触发"}),"：",e.jsx("code",{children:"setN"})," 把组件标记为需要更新，排进队列；此刻 DOM 还没变。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Render"}),"：React 重新调用该组件函数，算出一棵新的元素树（里面 ",e.jsx("code",{children:"n"})," 现在是 1）。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Reconcile"}),"：和上一棵树比对，发现只有那个显示数字的文本节点变了，标记「更新这一处」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Commit"}),"：把这一处文本同步改到真实 DOM，用户这才看到屏幕从 0 变成 1，随后跑 Effect。"]})]})]}),e.jsx("h2",{children:"四、Fiber 架构：为什么要重写渲染机制"}),e.jsxs("p",{children:["早期 React（Stack Reconciler）用",e.jsx("strong",{children:"递归"}),"遍历组件树来渲染：一旦开始，就得一口气递归到底， 中途",e.jsx("strong",{children:"停不下来"}),"。组件树一大，这次同步计算可能占用主线程几十毫秒，期间用户的输入、动画 全被卡住，体感就是「卡顿掉帧」。"]}),e.jsxs(s,{children:["Fiber 架构的核心动机，是把",e.jsx("strong",{children:"不可中断的递归遍历"}),"，改写成",e.jsx("strong",{children:"可中断的链表遍历"}),"。 每个组件对应一个 Fiber 节点，节点之间用 ",e.jsx("code",{children:"child"})," / ",e.jsx("code",{children:"sibling"})," / ",e.jsx("code",{children:"return"}),"指针连成可以「走走停停」的结构。React 于是能把一大坨渲染工作切成小片（",e.jsx("strong",{children:"时间切片"}),"）， 每做一小片就让出主线程；还能按",e.jsx("strong",{children:"优先级"}),"让紧急更新（如输入响应）插队。"]}),e.jsx(r,{lang:"jsx",title:"Fiber 节点的关键指针（直观示意）",code:j}),e.jsx("p",{children:"正因为遍历能随时停下、之后再从断点接着走，Render 阶段才有了「可中断 / 恢复 / 丢弃」的能力—— 这也回头解释了为什么第三节强调 render 必须纯：一段可能被反复重来、半途丢弃的计算， 绝不能掺杂会产生真实影响的副作用。"}),e.jsxs(n,{variant:"tip",title:"一句话理解并发渲染",children:["建立在 Fiber 之上的",e.jsx("strong",{children:"并发渲染（Concurrent Rendering）"}),"，让 React 能同时「准备」多个版本的 UI、 随时按优先级切换或丢弃其中一个，从而在不阻塞用户交互的前提下完成更新。",e.jsx("code",{children:"useTransition"}),"、",e.jsx("code",{children:"useDeferredValue"})," 这些 API 正是它的对外抓手——后面的章节会专门讲。"]}),e.jsx("h2",{children:"五、double buffering：current 树与 workInProgress 树"}),e.jsxs("p",{children:["Fiber 还有一个值得知道的设计：React 在内存里同时维护",e.jsx("strong",{children:"两棵 Fiber 树"}),"。 一棵是 ",e.jsx("code",{children:"current"})," 树，对应当前屏幕上正在显示的内容；另一棵是",e.jsx("code",{children:"workInProgress"})," 树，是本次更新正在内存里构建的新版本。两棵树通过 ",e.jsx("code",{children:"alternate"}),"指针互相引用，能尽量复用彼此的节点对象，避免每次更新都重新分配一大堆内存。"]}),e.jsxs("p",{children:["这套机制叫",e.jsx("strong",{children:"双缓冲（double buffering）"}),"，和图形渲染里「在后台画好下一帧再整帧切换」 是同一个思路。Render / Reconcile 阶段所有计算都发生在 ",e.jsx("code",{children:"workInProgress"})," 树上， 屏幕上的 ",e.jsx("code",{children:"current"})," 树岿然不动；直到 Commit 这一刻，React 才把",e.jsx("code",{children:"workInProgress"})," 整棵「转正」成新的 ",e.jsx("code",{children:"current"}),"，屏幕一次性切到新版本。 这也是为什么半途丢弃一次渲染几乎没有代价——被丢的只是后台那棵还没转正的树。"]}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Fiber 树"}),e.jsx("th",{children:"角色"}),e.jsx("th",{children:"何时切换"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"current"})}),e.jsx("td",{children:"当前屏幕上正显示的版本"}),e.jsx("td",{children:"Commit 完成的那一刻被替换"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"workInProgress"})}),e.jsx("td",{children:"本次更新在后台构建的新版本"}),e.jsx("td",{children:"构建完成且 Commit 后转正为 current"})]})]})]}),e.jsx("h2",{children:"六、常见误区澄清"}),e.jsxs("p",{children:[e.jsx("strong",{children:"误区一：「虚拟 DOM 一定比直接操作 DOM 快」。"})," 不准确。在内存里 diff 本身也要花时间， 极端手工优化的命令式代码可能更快。虚拟 DOM 真正的价值是",e.jsx("strong",{children:"用可控的代价，换来声明式编程的简单与可维护"}),"， 并避免大多数人手写 DOM 时那些低级又昂贵的错误。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"误区二：「render 就是更新屏幕」。"})," 不是。Render 只是在内存里",e.jsx("strong",{children:"算"}),"新树， 真正改屏幕发生在 Commit。组件「重新 render 了」不等于「DOM 真的改了」——很多次 render 比对后发现没差别， Commit 阶段几乎什么都不做。"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"误区三：「Fiber 让单次渲染更快」。"})," 它主要不是让总计算量变小，而是让计算",e.jsx("strong",{children:"可被打断"}),"， 从而把长任务拆开、避免长时间阻塞主线程，换来的是",e.jsx("strong",{children:"响应性"}),"而非纯吞吐。"]}),e.jsx(n,{variant:"tip",children:"下一章我们顺着「Reconcile 阶段的 diff」往下挖：组件到底在什么时候重渲染、diff 的三条启发式规则是什么、 以及 key 为什么如此关键——还会看一个用错 key 导致输入框「串值」的真实翻车现场。"}),e.jsx(c,{points:["真实 DOM 操作慢且易错，虚拟 DOM 用普通对象在内存里描述界面，把命令式脏活变成框架可自动最小化处理的声明式问题。","JSX 编译成不可变的 React 元素对象，type 为字符串表示原生标签、为函数表示组件；一次渲染产出一棵元素树。","一次更新分三相：Render（纯计算算新树，可中断/恢复/丢弃）、Reconcile（diff 比对标记最小改动）、Commit（同步一次性改真实 DOM 并跑 ref/useLayoutEffect/useEffect）。","render 阶段必须纯：绝不在渲染中改 DOM、发请求或写全局，副作用一律放进 Effect。","Fiber 把不可中断的递归遍历改写成可中断的链表遍历，支持时间切片与优先级调度，并发渲染据此而来。","别误以为虚拟 DOM 天生更快、render 等于更新屏幕、或 Fiber 减少了计算量——它们换来的分别是可维护性、正确的时机模型与响应性。"]})]})}export{M as default};
