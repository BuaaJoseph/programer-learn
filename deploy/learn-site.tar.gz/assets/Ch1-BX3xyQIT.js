import{j as e}from"./index-I8-WI4LI.js";import{L as i,S as o}from"./Summary-BMIdTn04.js";import{K as n}from"./KeyIdea-Xbvwo63C.js";import{C as t}from"./Callout-ZgrsOCpc.js";import{C as r}from"./CodeBlock-CK6ncc4Q.js";import{E as s}from"./Example-CPIFvVrE.js";const c=`# 用包管理器安装官方路由库（Vue 3 对应 Vue Router 4）
npm install vue-router@4
# 或
pnpm add vue-router@4`,d=`// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import Home from '@/views/Home.vue'
import About from '@/views/About.vue'

// 路由表：每条记录把一个 path 映射到一个组件
const routes = [
  { path: '/', name: 'home', component: Home },
  { path: '/about', name: 'about', component: About },
]

const router = createRouter({
  // history 模式：用 HTML5 History API，URL 干净没有 #
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

export default router`,h=`// src/main.js
import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

const app = createApp(App)
app.use(router)   // 把路由插件装到应用上，注入 router-link / router-view
app.mount('#app')`,l=`<!-- src/App.vue：整个应用的外壳 -->
<template>
  <header>
    <nav>
      <!-- router-link 渲染成 <a>，但点击不刷新整页，由路由接管 -->
      <router-link to="/">首页</router-link>
      <router-link to="/about">关于</router-link>
      <!-- :to 绑定对象写法，等价于 to="/user/42" -->
      <router-link :to="{ name: 'user', params: { id: 42 } }">用户 42</router-link>
    </nav>
  </header>

  <main>
    <!-- 当前 URL 匹配到的组件会被渲染进这里 -->
    <router-view />
  </main>
</template>`,u=`// 两种 history 创建函数

// 1) HTML5 History 模式：URL 形如 https://site.com/about
//    优点：干净、利于 SEO；代价：服务端要把所有路径回退到 index.html
import { createWebHistory } from 'vue-router'
createRouter({ history: createWebHistory(), routes })

// 2) Hash 模式：URL 形如 https://site.com/#/about
//    优点：纯前端、无需服务端配置；代价：带 # 不够美观、对 SEO 略不利
import { createWebHashHistory } from 'vue-router'
createRouter({ history: createWebHashHistory(), routes })`,a=`# history 模式下，刷新 /about 时浏览器会真的向服务端请求 /about，
# 服务端没有这个文件就会 404。解决办法：把所有未匹配的请求回退到 index.html，
# 由前端路由再去解析这个 path。

# Nginx 示例
location / {
  try_files $uri $uri/ /index.html;
}`,x=`// 嵌套路由：children 里的 path 是相对父级的
const routes = [
  {
    path: '/settings',
    component: SettingsLayout,   // 父级布局，里面有自己的 <router-view />
    children: [
      // 访问 /settings 时默认渲染的子路由（path 为空字符串）
      { path: '', name: 'settings-home', component: SettingsHome },
      // 访问 /settings/profile
      { path: 'profile', name: 'settings-profile', component: SettingsProfile },
      // 访问 /settings/security
      { path: 'security', name: 'settings-security', component: SettingsSecurity },
    ],
  },
]`,j=`<!-- SettingsLayout.vue：父级布局组件 -->
<template>
  <div class="settings">
    <aside>
      <router-link :to="{ name: 'settings-profile' }">资料</router-link>
      <router-link :to="{ name: 'settings-security' }">安全</router-link>
    </aside>
    <section>
      <!-- 子路由组件渲染进这个嵌套的出口 -->
      <router-view />
    </section>
  </div>
</template>`,p=`// 动态路由参数：用冒号声明占位段
const routes = [
  { path: '/user/:id', name: 'user', component: UserDetail },
]`,m=`<!-- UserDetail.vue：读取当前路由信息 -->
<script setup>
import { useRoute } from 'vue-router'
import { computed } from 'vue'

const route = useRoute()
// route 是响应式的：/user/42 时 route.params.id === '42'
const userId = computed(() => route.params.id)
// 查询参数 /user/42?tab=posts -> route.query.tab === 'posts'
const tab = computed(() => route.query.tab ?? 'overview')
<\/script>

<template>
  <h1>用户 {{ userId }}</h1>
  <p>当前标签页：{{ tab }}</p>
</template>`,g=`<!-- 编程式导航：在事件回调里跳转 -->
<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

function goUser() {
  // push：压入历史栈，可以「后退」回到当前页
  router.push({ name: 'user', params: { id: 7 }, query: { tab: 'posts' } })
}

function login() {
  // replace：替换当前历史记录，不留下「后退」入口（适合登录后跳转）
  router.replace({ name: 'home' })
}

function goBack() {
  router.back()   // 等价于浏览器后退
}
<\/script>`,v=`const routes = [
  // 重定向：访问 /home 会跳到 /，URL 也变成 /
  { path: '/home', redirect: '/' },

  // 用命名目标做重定向，更稳（path 改了也不怕）
  { path: '/start', redirect: { name: 'home' } },

  // 函数式重定向：根据来源动态决定去向
  { path: '/old/:id', redirect: (to) => ({ name: 'user', params: { id: to.params.id } }) },

  // 别名：URL 保持不变，但多个 path 命中同一组件
  { path: '/', name: 'home', component: Home, alias: ['/index', '/welcome'] },
]`,y=`const routes = [
  // ... 其它路由放前面

  // 404 通配：用正则参数捕获任意未匹配路径，放在最后兜底
  {
    path: '/:pathMatch(.*)*',
    name: 'not-found',
    component: NotFound,
  },
]`,R=`// src/router/index.js —— 一个多页 + 嵌套布局的完整路由表
import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  { path: '/', name: 'home', component: () => import('@/views/Home.vue') },
  { path: '/user/:id', name: 'user', component: () => import('@/views/UserDetail.vue') },
  {
    path: '/settings',
    component: () => import('@/views/SettingsLayout.vue'),
    children: [
      { path: '', name: 'settings-home', component: () => import('@/views/SettingsHome.vue') },
      { path: 'profile', name: 'settings-profile', component: () => import('@/views/SettingsProfile.vue') },
      { path: 'security', name: 'settings-security', component: () => import('@/views/SettingsSecurity.vue') },
    ],
  },
  { path: '/home', redirect: '/' },
  { path: '/:pathMatch(.*)*', name: 'not-found', component: () => import('@/views/NotFound.vue') },
]

export default createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})`;function w(){return e.jsxs("article",{children:[e.jsxs(i,{children:["在传统的多页网站里，每点一个链接，浏览器都向服务端要一个全新的 HTML 页面，整页白屏一闪再重绘。 而单页应用（SPA）只在首次加载一份外壳，之后切换「页面」全靠 JavaScript 在前端完成。 要让 SPA 也拥有「不同 URL 对应不同界面、支持前进后退、链接可分享」的体验，就需要一套",e.jsx("strong",{children:"前端路由"}),"。Vue 官方的方案就是 ",e.jsx("strong",{children:"Vue Router"}),"。 这一章我们讲透它的原理：URL 到底是怎么映射到组件的。"]}),e.jsx("h2",{children:"一、SPA 路由要解决什么问题"}),e.jsx("p",{children:"多页应用（MPA）的导航天然由浏览器和服务端负责：地址栏变了，浏览器发请求，服务端返回页面。 但 SPA 把渲染搬到了前端，导航这件事也就落到了前端头上。一套合格的前端路由，需要同时解决下面几件事："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"不刷新整页"}),"：切换视图时不能整页重载，否则就失去了 SPA「流畅、保持状态」的意义。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"URL 映射视图"}),"：地址栏里的路径要能稳定对应到某个组件，刷新后还能回到同一个界面。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"前进 / 后退"}),"：浏览器的前进后退按钮要正常工作，历史记录要符合用户直觉。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"可分享 / 可收藏"}),"：把 URL 发给别人或存成书签，对方打开能看到一样的界面。"]})]}),e.jsxs("p",{children:["Vue Router 借助浏览器的 ",e.jsx("strong",{children:"History API"}),"（或 hash）来改写地址栏、维护历史栈， 同时拦截站内跳转、根据当前路径动态渲染对应组件——这样既改了 URL、维护了历史，又没有真的去请求服务端整页。"]}),e.jsx(n,{children:"前端路由的本质是：在不向服务端请求新页面的前提下，监听 URL 的变化，并把当前 URL「翻译」成应该渲染的组件。 URL 是输入，组件树是输出，路由库就是中间那台映射机器。"}),e.jsx("h2",{children:"二、安装与最小骨架"}),e.jsx("p",{children:"Vue 3 配套的是 Vue Router 4。安装后，典型用法分三步：定义路由表、创建 router 实例、把它装到应用上。"}),e.jsx(r,{lang:"js",title:"安装 Vue Router 4",code:c}),e.jsx(r,{lang:"js",title:"创建 router 实例与路由表",code:d}),e.jsx(r,{lang:"js",title:"在 main.js 里挂载路由",code:h}),e.jsxs("p",{children:[e.jsx("code",{children:"app.use(router)"})," 这一步很关键：它把路由插件注册进应用，于是模板里就能用",e.jsx("code",{children:"<router-link>"})," 和 ",e.jsx("code",{children:"<router-view />"})," 这两个全局组件，组件内也能用",e.jsx("code",{children:"useRoute()"})," / ",e.jsx("code",{children:"useRouter()"})," 这两个组合式函数。"]}),e.jsx("h2",{children:"三、三个核心角色：router-link、router-view、routes"}),e.jsx("p",{children:"理解 Vue Router，先抓住三样东西的分工："}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"角色"}),e.jsx("th",{children:"职责"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"routes"})," 配置"]}),e.jsx("td",{children:"声明「哪个 path 对应哪个组件」的映射表，是路由的真相来源。"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"<router-link>"})}),e.jsxs("td",{children:["声明式导航。渲染成 ",e.jsx("code",{children:"<a>"}),"，但点击被路由接管，不刷新整页。"]})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"<router-view />"})}),e.jsx("td",{children:"占位出口。当前 URL 匹配到的组件就渲染在这里。"})]})]})]}),e.jsx(r,{lang:"vue",title:"应用外壳 App.vue",code:l}),e.jsxs("p",{children:[e.jsx("code",{children:"<router-link>"})," 的 ",e.jsx("code",{children:"to"})," 既可以是字符串路径，也可以绑定成对象 （",e.jsxs("code",{children:[':to="',(params,query),'"']}),"）。对象写法更稳：用命名路由后，即使 path 字符串后来改了， 链接也不会失效。"]}),e.jsxs(t,{variant:"note",title:"为什么不用普通的 <a> 标签",children:["普通 ",e.jsx("code",{children:'<a href="/about">'})," 会触发浏览器整页跳转，向服务端请求新页面——这正是 SPA 要避免的。",e.jsx("code",{children:"<router-link>"})," 在内部拦截了点击事件，改用 History API 更新 URL， 然后只重渲染 ",e.jsx("code",{children:"<router-view />"})," 里的那部分，体验上是「瞬切」。"]}),e.jsx("h2",{children:"四、history 模式 vs hash 模式"}),e.jsxs("p",{children:["创建 router 时必须传一个 ",e.jsx("code",{children:"history"})," 选项，它决定了 URL 长什么样、以及对服务端有什么要求。 两种主流选择："]}),e.jsx(r,{lang:"js",title:"两种 history 创建函数",code:u}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"对比项"}),e.jsx("th",{children:"createWebHistory（history 模式）"}),e.jsx("th",{children:"createWebHashHistory（hash 模式）"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:"URL 形态"}),e.jsx("td",{children:e.jsx("code",{children:"/about"})}),e.jsx("td",{children:e.jsx("code",{children:"/#/about"})})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"美观度 / SEO"}),e.jsx("td",{children:"干净，利于 SEO"}),e.jsx("td",{children:"带 #，对 SEO 略不友好"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"服务端配置"}),e.jsx("td",{children:"需要把所有路径回退到 index.html"}),e.jsx("td",{children:"无需任何服务端配置"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:"原理"}),e.jsx("td",{children:"HTML5 History API（pushState）"}),e.jsx("td",{children:"监听 URL 的 hash（# 后部分）变化"})]})]})]}),e.jsxs("p",{children:["关键差异在",e.jsx("strong",{children:"服务端配置含义"}),"上。hash 模式里，",e.jsx("code",{children:"#"})," 后面的内容浏览器",e.jsx("strong",{children:"不会"}),"发给服务端， 所以刷新 ",e.jsx("code",{children:"/#/about"})," 时服务端只看到 ",e.jsx("code",{children:"/"}),"，永远能返回 index.html，前端再解析 hash—— 因此纯静态托管也能用。而 history 模式下，刷新 ",e.jsx("code",{children:"/about"})," 时浏览器会真的请求",e.jsx("code",{children:"/about"}),"，服务端若没配置回退就会返回 404。"]}),e.jsx(r,{lang:"js",title:"history 模式所需的服务端回退（Nginx 示例）",code:a}),e.jsx(t,{variant:"tip",children:"能控制服务端（或用 Vercel / Netlify 这类自动配好回退的平台）就优先用 history 模式，URL 更专业； 如果只能丢到一个不可配置的静态空间（比如某些对象存储直链），hash 模式是省心的兜底选择。"}),e.jsx("h2",{children:"五、嵌套路由：children 与嵌套的 router-view"}),e.jsxs("p",{children:["真实应用常有「布局套布局」的结构：比如一个「设置」页面，左侧是固定的菜单，右侧才随子菜单切换内容。 这种「外层框架不变、内层局部切换」的需求，正是",e.jsx("strong",{children:"嵌套路由"}),"的用武之地。"]}),e.jsxs("p",{children:["做法是在父路由里写 ",e.jsx("code",{children:"children"})," 数组，并在父组件的模板里再放一个",e.jsx("code",{children:"<router-view />"})," 作为子路由的出口。注意 ",e.jsx("code",{children:"children"})," 里的",e.jsx("code",{children:"path"})," 是",e.jsx("strong",{children:"相对"}),"父级的，所以前面不要加斜杠。"]}),e.jsx(r,{lang:"js",title:"嵌套路由配置",code:x}),e.jsx(r,{lang:"vue",title:"父级布局里的嵌套出口",code:j}),e.jsxs("p",{children:["于是渲染就分了两层：最外层 ",e.jsx("code",{children:"App.vue"})," 的 ",e.jsx("code",{children:"<router-view />"})," 渲染出",e.jsx("code",{children:"SettingsLayout"}),"，而 ",e.jsx("code",{children:"SettingsLayout"})," 内部的 ",e.jsx("code",{children:"<router-view />"}),"再渲染出 ",e.jsx("code",{children:"SettingsProfile"})," 等子组件。切换右侧内容时，左侧菜单和外壳都纹丝不动。"]}),e.jsxs(s,{title:"嵌套路由的 URL 与渲染对应关系",children:[e.jsxs("p",{children:["访问 ",e.jsx("code",{children:"/settings/profile"})," 时，组件树是这样拼起来的："]}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"App.vue"})," 的出口 -> 渲染 ",e.jsx("code",{children:"SettingsLayout"})]}),e.jsxs("li",{children:[e.jsx("code",{children:"SettingsLayout"})," 的出口 -> 渲染 ",e.jsx("code",{children:"SettingsProfile"})]})]}),e.jsxs("p",{children:["而访问 ",e.jsx("code",{children:"/settings"}),"（无子段）时，命中 ",e.jsx("code",{children:"path: ''"})," 的默认子路由，渲染 ",e.jsx("code",{children:"SettingsHome"}),"。"]})]}),e.jsx("h2",{children:"六、动态参数与 useRoute"}),e.jsxs("p",{children:["很多页面是「同一个模板、不同数据」，比如用户详情页 ",e.jsx("code",{children:"/user/1"}),"、",e.jsx("code",{children:"/user/2"}),"…… 没必要为每个 id 写一条路由。用冒号声明",e.jsx("strong",{children:"动态参数"}),"即可，匹配到的具体值通过",e.jsx("code",{children:"useRoute().params"})," 读取。"]}),e.jsx(r,{lang:"js",title:"声明动态参数 :id",code:p}),e.jsx(r,{lang:"vue",title:"组件里用 useRoute 读取参数",code:m}),e.jsxs(t,{variant:"warn",title:"同路由切参数时组件会被复用",children:["从 ",e.jsx("code",{children:"/user/1"})," 跳到 ",e.jsx("code",{children:"/user/2"}),"，命中的是同一条路由、同一个组件，Vue 默认会",e.jsx("strong",{children:"复用组件实例而不重新创建"}),"，所以 ",e.jsx("code",{children:"onMounted"})," 不会再次触发。如果你在",e.jsx("code",{children:"onMounted"})," 里发了请求，换 id 时数据不会刷新。解决办法是 ",e.jsx("code",{children:"watch"})," 监听",e.jsx("code",{children:"() => route.params.id"}),"，或用组件内守卫 ",e.jsx("code",{children:"onBeforeRouteUpdate"}),"（下一章细讲）。"]}),e.jsx("h2",{children:"七、编程式导航：useRouter 的 push / replace"}),e.jsxs("p",{children:["除了点链接，常常需要在代码里主动跳转——比如表单提交成功后跳到详情页。用",e.jsx("code",{children:"useRouter()"})," 拿到 router 实例，调用它的方法即可。"]}),e.jsx(r,{lang:"vue",title:"编程式导航",code:g}),e.jsxs("table",{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"方法"}),e.jsx("th",{children:"行为"})]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"router.push(target)"})}),e.jsx("td",{children:"压入一条新历史记录，可后退回当前页。最常用。"})]}),e.jsxs("tr",{children:[e.jsx("td",{children:e.jsx("code",{children:"router.replace(target)"})}),e.jsx("td",{children:"替换当前记录，不留后退入口。适合登录跳转、重定向。"})]}),e.jsxs("tr",{children:[e.jsxs("td",{children:[e.jsx("code",{children:"router.back()"})," / ",e.jsx("code",{children:"forward()"})]}),e.jsx("td",{children:"等价于浏览器的后退 / 前进。"})]})]})]}),e.jsxs("p",{children:[e.jsx("strong",{children:"别混淆"}),"：",e.jsx("code",{children:"useRoute()"}),"（单数、含 route）返回",e.jsx("strong",{children:"当前路由信息"}),"（params、query、path）， 是只读的、响应式的；",e.jsx("code",{children:"useRouter()"}),"（含 router）返回",e.jsx("strong",{children:"路由器实例"}),"，用来执行跳转动作。"]}),e.jsx("h2",{children:"八、命名路由与查询参数"}),e.jsxs("p",{children:["给每条路由起个 ",e.jsx("code",{children:"name"}),"，跳转时就能用 ",e.jsx("code",{children:"{ name: 'user' }"})," 而不是手写 path 字符串。 好处是：path 改了不用全局搜替换，参数也写得更清楚。",e.jsx("strong",{children:"查询参数"}),"（",e.jsx("code",{children:"?key=value"}),"） 则通过 ",e.jsx("code",{children:"query"})," 传递，在目标组件里用 ",e.jsx("code",{children:"route.query"})," 读取。"]}),e.jsx(s,{title:"params 与 query 的区别",children:e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"params"}),"：是路径的一部分，由路由表的 ",e.jsx("code",{children:":id"})," 声明，如 ",e.jsx("code",{children:"/user/42"}),"。改了通常意味着「看的是另一个资源」。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"query"}),"：附在 ",e.jsx("code",{children:"?"})," 后面的可选参数，如 ",e.jsx("code",{children:"/user/42?tab=posts"}),"。常用于筛选、分页、标签等「同一资源的不同视图」。"]})]})}),e.jsx("h2",{children:"九、重定向、别名与 404 通配"}),e.jsx("p",{children:"最后是三个常见的收尾配置："}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"重定向 redirect"}),"：访问 A 自动跳到 B，URL 也变成 B。适合旧路径迁移。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"别名 alias"}),"：多个 path 命中同一组件，但 URL 保持你访问时的样子",e.jsx("strong",{children:"不变"}),"——这是它和 redirect 的核心区别。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"404 通配"}),"：用正则参数 ",e.jsx("code",{children:"/:pathMatch(.*)*"})," 兜住所有未匹配路径，放在路由表",e.jsx("strong",{children:"最后"}),"。"]})]}),e.jsx(r,{lang:"js",title:"重定向与别名",code:v}),e.jsx(r,{lang:"js",title:"404 通配兜底",code:y}),e.jsx("h2",{children:"十、把它们拼成一个完整路由表"}),e.jsx("p",{children:"下面这份路由表融合了本章所有要点：多页、嵌套布局、动态参数、重定向、404 兜底，可直接作为项目骨架。"}),e.jsx(r,{lang:"js",title:"一个多页 + 嵌套布局的完整路由表",code:R}),e.jsxs(t,{variant:"tip",children:["下一章我们给这份路由表加上「保安」：用导航守卫做登录鉴权、用 ",e.jsx("code",{children:"meta"})," 标记哪些页面需要登录， 并把组件改成路由级懒加载，让首屏只下载真正用到的代码。"]}),e.jsx(o,{points:["SPA 路由要解决四件事：不刷新整页、URL 映射视图、支持前进后退、URL 可分享可收藏。","Vue 3 用 Vue Router 4：定义 routes 路由表，createRouter 创建实例，app.use(router) 装载。","三个核心角色：routes（映射真相）、router-link（声明式导航、不整页刷新）、router-view（组件渲染出口）。","history 模式 URL 干净但需服务端把路径回退到 index.html；hash 模式带 # 但无需服务端配置。","嵌套路由用 children + 父组件里再放一个 router-view；children 的 path 相对父级，不加斜杠。","动态参数用 :id 声明，useRoute().params 读取（同路由切参数会复用组件，需 watch）；编程式导航用 useRouter().push / replace。","命名路由用 name 跳转更稳；params 是路径段、query 是 ? 后参数；redirect 会改 URL、alias 不改；404 用 /:pathMatch(.*)* 兜底放最后。"]})]})}export{w as default};
