import{j as e}from"./index-CBMe5udE.js";import{L as i,S as t}from"./Summary-CEfAQ4SZ.js";import{K as s}from"./KeyIdea-K3hFePn1.js";import{C as r}from"./Callout-3wJQ5WDp.js";import{C as n}from"./CodeBlock-D4LRiuTl.js";import{E as o}from"./Example-CFOi3F9j.js";const l=`# 安装 SDK 与底层 openai 库
pip install openai-agents openai

# 配置百炼(DashScope) 的 API Key（百炼控制台获取，形如 sk-xxxx）
export DASHSCOPE_API_KEY=sk-xxxxxxxx`,d=`import os
from openai import AsyncOpenAI
from agents import (
    set_default_openai_client, set_default_openai_api, set_tracing_disabled,
)

# ① 自定义客户端，base_url 指向百炼兼容端点
client = AsyncOpenAI(
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    api_key=os.environ["DASHSCOPE_API_KEY"],
)
# ② 设为全局默认客户端
set_default_openai_client(client, use_for_tracing=False)
# ③ 切到 Chat Completions（必须！第三方端点不支持 Responses API）
set_default_openai_api("chat_completions")
# ④ 关掉 tracing（上报需 OpenAI key，接第三方时关掉）
set_tracing_disabled(True)`,c=`import asyncio
import os

from agents import (
    Agent,
    GuardrailFunctionOutput,
    InputGuardrailTripwireTriggered,
    RunContextWrapper,
    Runner,
    function_tool,
    input_guardrail,
    set_default_openai_api,
    set_default_openai_client,
    set_tracing_disabled,
)
from openai import AsyncOpenAI

client = AsyncOpenAI(
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    api_key=os.environ["DASHSCOPE_API_KEY"],
)
set_default_openai_client(client, use_for_tracing=False)
set_default_openai_api("chat_completions")
set_tracing_disabled(True)

MODEL = "qwen-plus"


@function_tool
def lookup_order(order_id: str) -> str:
    """根据订单号查询订单状态（示例数据）。"""
    return f"订单 {order_id}：已支付，预计 3 天内发货。"


@input_guardrail
async def no_other_customer(ctx: RunContextWrapper, agent: Agent, user_input) -> GuardrailFunctionOutput:
    """护栏：拒绝查询「别人」账户/订单的越权请求。并行于主流程运行，命中即中断。"""
    text = user_input if isinstance(user_input, str) else str(user_input)
    tripwire = any(k in text for k in ["别人", "其他用户", "他的账户", "别人的订单"])
    return GuardrailFunctionOutput(
        output_info={"reason": "疑似越权访问他人信息"},
        tripwire_triggered=tripwire,
    )


billing_agent = Agent(
    name="账单专员",
    model=MODEL,
    instructions="你负责账单与支付问题，用中文简洁回答；需要时用工具查订单。",
    tools=[lookup_order],
)
refund_agent = Agent(
    name="退款专员",
    model=MODEL,
    instructions="你负责退款问题，用中文简洁说明退款政策与流程。",
)

triage_agent = Agent(
    name="分诊台",
    model=MODEL,
    instructions="你是客服分诊台。判断用户问题属于账单还是退款，交接(handoff)给对应专员处理。",
    handoffs=[billing_agent, refund_agent],
    input_guardrails=[no_other_customer],
)


async def main() -> None:
    questions = [
        "我的订单 A1001 到哪了？",
        "我要退款，怎么操作？",
        "帮我查下别人的订单 B2002",
    ]
    for q in questions:
        print(f"\\n用户：{q}")
        try:
            result = await Runner.run(triage_agent, q)
            print("客服：", result.final_output)
        except InputGuardrailTripwireTriggered:
            print("客服：抱歉，无法处理涉及他人账户的请求。")


if __name__ == "__main__":
    asyncio.run(main())`,a=`用户：我的订单 A1001 到哪了？
客服： 您的订单 A1001 已支付，预计 3 天内发货，请耐心等待～

用户：我要退款，怎么操作？
客服： 您可在「订单详情-申请退款」提交，审核通过后 1-3 个工作日原路退回。

用户：帮我查下别人的订单 B2002
客服：抱歉，无法处理涉及他人账户的请求。`,u=`from agents import output_guardrail, GuardrailFunctionOutput, OutputGuardrailTripwireTriggered

@output_guardrail
async def no_internal_leak(ctx, agent, output) -> GuardrailFunctionOutput:
    """输出护栏：拦截回答里泄露内部信息（进价/成本/密钥）的情况。"""
    text = str(output)
    leaked = any(k in text for k in ["内部成本", "进价", "API_KEY", "sk-"])
    return GuardrailFunctionOutput(
        output_info={"leaked": leaked},
        tripwire_triggered=leaked,
    )

# 挂到 Agent 上（与输入护栏并列）
billing_agent = Agent(
    name="账单专员",
    model=MODEL,
    instructions="...",
    tools=[lookup_order],
    output_guardrails=[no_internal_leak],
)
# 命中时 Runner.run 抛 OutputGuardrailTripwireTriggered，同样用 try/except 捕获`,h=`from agents import Runner, SQLiteSession

session = SQLiteSession("user-123")   # 同一 session_id 串起多轮
await Runner.run(triage_agent, "我叫小明，订单 A1001 到哪了？", session=session)
result = await Runner.run(triage_agent, "那我刚问的那个订单呢？", session=session)
print(result.final_output)   # 自动带历史，知道"那个订单"=A1001`,p=`from agents import Agent, ModelSettings

billing_agent = Agent(
    name="账单专员",
    model=MODEL,
    instructions="...",
    tools=[lookup_order],
    model_settings=ModelSettings(
        temperature=0.2,      # 客服场景要稳，降低随机性
        max_tokens=512,
        tool_choice="auto",   # 让模型自行决定是否调工具
    ),
)`;function A(){return e.jsxs("article",{children:[e.jsxs(i,{children:["光讲原理不够。本章用一个",e.jsx("strong",{children:"真实可跑"}),"的客服分诊系统把上一章的概念全部落地： 分诊台根据用户问题 handoff 给账单专员或退款专员，并加一道输入护栏拦截越权请求。同时， 我们用「关键四步」把这套 SDK 接到国内的",e.jsx("strong",{children:"百炼（DashScope）"}),"，用 qwen-plus 模型跑起来；最后给出输出护栏变体、常见报错排查与进阶玩法。"]}),e.jsx("h2",{children:"一、安装与环境"}),e.jsxs("p",{children:["先装好依赖，并配置百炼的 API Key（在百炼控制台获取，形如 ",e.jsx("code",{children:"sk-xxxx"}),"）。",e.jsx("code",{children:"openai-agents"})," 是 SDK 本体，",e.jsx("code",{children:"openai"})," 提供底层的 ",e.jsx("code",{children:"AsyncOpenAI"})," 客户端。"]}),e.jsx(n,{lang:"bash",title:"安装与环境变量",code:l}),e.jsx("h2",{children:"二、接百炼的关键四步"}),e.jsxs("p",{children:["Agents SDK 默认走 OpenAI 的 Responses API，而百炼只兼容 Chat Completions。要把它接到百炼， 核心就是下面这四行配置——务必在",e.jsx("strong",{children:"创建任何 Agent 之前"}),"执行（它们设置的是全局默认）。"]}),e.jsx(n,{lang:"python",title:"接百炼·关键四步",code:d}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"① 自定义 AsyncOpenAI 客户端"}),"：把 ",e.jsx("code",{children:"base_url"})," 指向百炼的兼容端点",e.jsx("code",{children:"https://dashscope.aliyuncs.com/compatible-mode/v1"}),"，",e.jsx("code",{children:"api_key"})," 用百炼的 Key。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"② 设为默认客户端"}),"：",e.jsx("code",{children:"set_default_openai_client(client, use_for_tracing=False)"}),"， 让全局所有 Agent 都走这个客户端；",e.jsx("code",{children:"use_for_tracing=False"})," 明确不拿它做 tracing 上报。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"③ 切到 chat_completions"}),"：",e.jsx("code",{children:'set_default_openai_api("chat_completions")'}),"。 这一步",e.jsx("strong",{children:"必须"}),"做，否则第三方端点因不支持 Responses API 而报错。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"④ 关掉 tracing"}),"：",e.jsx("code",{children:"set_tracing_disabled(True)"}),"。tracing 上报需要 OpenAI 的 Key，接百炼时关掉即可。"]})]}),e.jsxs("p",{children:["模型名直接用百炼的 ",e.jsx("code",{children:'"qwen-plus"'}),"。"]}),e.jsxs(s,{children:["接百炼的口诀就一句：",e.jsx("strong",{children:"自定义 client → 设为默认 client → 切 chat_completions → 关 tracing"}),"。 四步做完，handoff、guardrail、工具调用全都照常工作。"]}),e.jsx("h2",{children:"三、完整示例"}),e.jsx("p",{children:"下面是完整的客服分诊脚本，一字不改即可运行。它包含一个查单工具、一道输入护栏、 三个 Agent（分诊台 + 账单专员 + 退款专员），以及三条演示问题。"}),e.jsx(n,{lang:"python",title:"examples/agent-frameworks/02-openai-agents/triage_handoff.py",code:c}),e.jsx("h2",{children:"四、逐段讲解"}),e.jsx("h3",{children:"导入与四步配置（第 1-27 行）"}),e.jsxs("ul",{children:[e.jsxs("li",{children:["从 ",e.jsx("code",{children:"agents"})," 一次性导入要用到的原语与装饰器；从 ",e.jsx("code",{children:"openai"})," 导入 ",e.jsx("code",{children:"AsyncOpenAI"}),"。"]}),e.jsxs("li",{children:["紧接着就是「关键四步」：创建客户端、设默认、切 chat_completions、关 tracing。这几行",e.jsx("strong",{children:"在模块顶层先跑"}),"，确保后面所有 Agent 都用这套配置。"]}),e.jsxs("li",{children:[e.jsx("code",{children:'MODEL = "qwen-plus"'})," 抽成常量，三个 Agent 复用。"]})]}),e.jsx("h3",{children:"工具：function_tool（lookup_order）"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"@function_tool"})," 把普通 Python 函数变成 Agent 可调用的工具：函数名→工具名，docstring→工具描述，",e.jsx("code",{children:"order_id: str"})," 这个签名→参数 schema，全自动。"]}),e.jsx("li",{children:"这里返回的是写死的示例数据；真实项目里这里会去查数据库或调内部 API。"})]}),e.jsx("h3",{children:"输入护栏：no_other_customer"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"@input_guardrail"})," 装饰的函数与主流程",e.jsx("strong",{children:"并行"}),"运行，签名固定为 ",e.jsx("code",{children:"(ctx, agent, user_input)"}),"。"]}),e.jsxs("li",{children:["逻辑很朴素：把输入转成字符串，命中「别人 / 其他用户 / 他的账户 / 别人的订单」任一关键词，就把 ",e.jsx("code",{children:"tripwire_triggered"})," 置 ",e.jsx("code",{children:"True"}),"。"]}),e.jsxs("li",{children:[e.jsx("code",{children:"output_info"})," 是附带的诊断信息（命中原因），会进 trace / 日志，方便排查。"]}),e.jsx("li",{children:"真实项目里这里通常换成「比对当前登录用户身份」的鉴权逻辑，而非关键词匹配。"})]}),e.jsx("h3",{children:"三个 Agent 与 handoffs"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"账单专员"}),"带 ",e.jsx("code",{children:"tools=[lookup_order]"}),"，能查订单；",e.jsx("strong",{children:"退款专员"}),"不带工具，只讲政策流程，各司其职。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"分诊台"}),"通过 ",e.jsx("code",{children:"handoffs=[billing_agent, refund_agent]"})," 声明两个可交接目标，并挂上 ",e.jsx("code",{children:"input_guardrails=[no_other_customer]"}),"。"]}),e.jsx("li",{children:"注意分诊台的 instructions 明确告诉它「判断归属后交接给对应专员」——这是 handoff 能正确触发的前提。"})]}),e.jsx("h3",{children:"运行：Runner.run 与 final_output"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("code",{children:"await Runner.run(triage_agent, q)"})," 驱动整个循环，",e.jsx("strong",{children:"包括可能的 handoff"}),"，最终结果在 ",e.jsx("code",{children:"result.final_output"}),"。"]}),e.jsxs("li",{children:["因为护栏命中会抛 ",e.jsx("code",{children:"InputGuardrailTripwireTriggered"}),"，所以每次调用都包在 ",e.jsx("code",{children:"try/except"})," 里，命中时给出礼貌的拒绝答复。"]}),e.jsxs("li",{children:["整个脚本是异步的，最后用 ",e.jsx("code",{children:"asyncio.run(main())"})," 启动。"]})]}),e.jsx("h2",{children:"五、三条问题的预期输出"}),e.jsx("p",{children:"三条问题分别触发三种路径：handoff 到账单、handoff 到退款、被输入护栏拦截。"}),e.jsxs(o,{title:"逐条发生了什么",children:[e.jsx("strong",{children:"① 「我的订单 A1001 到哪了？」"}),"——分诊台判断属于账单，",e.jsx("strong",{children:"handoff 到账单专员"}),"，专员调用 ",e.jsx("code",{children:'lookup_order("A1001")'})," 拿到状态后作答。",e.jsx("br",{}),e.jsx("strong",{children:"② 「我要退款，怎么操作？」"}),"——分诊台判断属于退款，",e.jsx("strong",{children:"handoff 到退款专员"}),"，由它说明退款流程（不调工具）。",e.jsx("br",{}),e.jsx("strong",{children:"③ 「帮我查下别人的订单 B2002」"}),"——输入护栏并行检测到「别人」关键词，",e.jsx("strong",{children:"tripwire 命中"}),"，抛 ",e.jsx("code",{children:"InputGuardrailTripwireTriggered"}),"，被 except 捕获， 返回拒绝答复。分诊台",e.jsx("strong",{children:"根本没来得及处理"}),"这条请求。"]}),e.jsx("p",{children:"运行后控制台大致输出如下（模型措辞每次略有不同）："}),e.jsx(n,{lang:"text",title:"预期输出（示意）",code:a}),e.jsx("h2",{children:"六、新增：输出护栏变体"}),e.jsxs("p",{children:["上例只演示了输入护栏。生产里同样关键的是",e.jsx("strong",{children:"输出护栏"}),"——在 Agent 产出回答后做一道 校验，防止泄露内部信息。下面给一个最小变体：检查回答里是否出现「进价 / 内部成本 / 密钥」等 敏感词，命中就拦下。"]}),e.jsx(n,{lang:"python",title:"输出护栏：禁止泄露内部信息",code:u}),e.jsxs("ul",{children:[e.jsxs("li",{children:["用 ",e.jsx("code",{children:"@output_guardrail"})," 装饰，签名是 ",e.jsx("code",{children:"(ctx, agent, output)"}),"，最后一个参数是 Agent 的",e.jsx("strong",{children:"输出"}),"。"]}),e.jsxs("li",{children:["挂到 Agent 的 ",e.jsx("code",{children:"output_guardrails=[...]"})," 上，与输入护栏并列。"]}),e.jsxs("li",{children:["命中时抛 ",e.jsx("code",{children:"OutputGuardrailTripwireTriggered"}),"（注意是 Output 版异常），同样需要 ",e.jsx("code",{children:"try/except"})," 捕获。"]})]}),e.jsx("h2",{children:"七、常见报错与调试"}),e.jsxs("ul",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"没切 chat_completions"}),"：报类似「endpoint 不支持 Responses API / 404 / Unsupported」的错。 → 确认 ",e.jsx("code",{children:'set_default_openai_api("chat_completions")'})," 写了，且在创建 Agent 之前执行。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"tracing 未关导致报 key"}),"：报缺少 OpenAI API key / tracing 上报失败。 → 加 ",e.jsx("code",{children:"set_tracing_disabled(True)"}),"，并确认 ",e.jsx("code",{children:"set_default_openai_client(..., use_for_tracing=False)"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"handoff 未生效"}),"（分诊台自己硬答、不交接）：→ 检查分诊台 instructions 是否明确要求「交接给对应专员」；确认 ",e.jsx("code",{children:"handoffs=[...]"})," 里确实放了目标 Agent；过小的模型有时不会主动交接，可换更强模型或把指令写得更明确。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"护栏未触发"}),"：→ 确认护栏挂在了",e.jsx("strong",{children:"分诊台"}),"（入口 Agent）的 ",e.jsx("code",{children:"input_guardrails"})," 上，而不是只挂在下游专员上；检查关键词/判定逻辑；确认 ",e.jsx("code",{children:"tripwire_triggered"})," 真的算出了 ",e.jsx("code",{children:"True"}),"。"]}),e.jsxs("li",{children:[e.jsx("strong",{children:"KeyError: 'DASHSCOPE_API_KEY'"}),"：环境变量没设。→ 先 ",e.jsx("code",{children:"export DASHSCOPE_API_KEY=..."})," 再跑。"]})]}),e.jsx("h2",{children:"八、进阶"}),e.jsx("h3",{children:"Sessions：多轮对话自动带历史"}),e.jsxs("p",{children:["上例每个问题都是独立一轮。要做连续对话，用 ",e.jsx("code",{children:"Session"})," 把多轮串起来，SDK 自动维护历史， 无需手动拼接。"]}),e.jsx(n,{lang:"python",title:"多轮会话（Session）",code:h}),e.jsx("h3",{children:"ModelSettings：精调采样与工具行为"}),e.jsxs("p",{children:["给 Agent 传 ",e.jsx("code",{children:"model_settings=ModelSettings(...)"})," 可控制 temperature、max_tokens、 tool_choice 等。客服这类场景通常希望回答稳定，把 temperature 调低。"]}),e.jsx(n,{lang:"python",title:"ModelSettings",code:p}),e.jsx("h3",{children:"把 tracing 接到 OpenTelemetry"}),e.jsxs("p",{children:["接百炼时关掉了原生 tracing，但可观测性不能丢。可以自行接入 ",e.jsx("strong",{children:"OpenTelemetry"}),"： 对 ",e.jsx("code",{children:"Runner.run"})," 与每个工具调用用 OTel 的 span 做埋点，记录输入、输出、耗时、是否 handoff、护栏是否命中，再上报到 Jaeger / Langfuse / 自建 APM。这样既用了第三方模型，又保留 了完整链路追踪。"]}),e.jsxs(r,{variant:"note",children:["接第三方模型时，handoff、guardrail、工具调用都照常可用；代价是",e.jsx("strong",{children:"失去 Responses API 与原生 tracing"}),"。如果你仍需要可观测性，用 OpenTelemetry 自行采集链路即可。"]}),e.jsxs(r,{variant:"tip",children:["接百炼口诀再记一遍：",e.jsx("strong",{children:"自定义 client → 默认 client → 切 chat_completions → 关 tracing"}),"。 四步缺一不可，尤其第三步最容易漏。"]}),e.jsx(t,{points:["安装 openai-agents 与 openai，配好 DASHSCOPE_API_KEY 环境变量。",'接百炼关键四步：自定义 AsyncOpenAI 客户端 → set_default_openai_client(use_for_tracing=False) → set_default_openai_api("chat_completions") → set_tracing_disabled(True)，且必须在创建 Agent 之前执行。',"第三步切 chat_completions 是必须的，否则第三方端点不支持 Responses API 会报错。","function_tool 把函数变工具；input_guardrail 命中 tripwire 抛 InputGuardrailTripwireTriggered，output_guardrail 抛 OutputGuardrailTripwireTriggered，都需 try/except。","分诊台用 handoffs 路由到账单/退款专员，护栏挂在入口 Agent 上，Runner.run 驱动循环并返回 final_output。","三条问题分别演示：handoff 到账单、handoff 到退款、被输入护栏拦截。","常见坑：没切 chat_completions、tracing 没关、handoff 指令不明确、护栏挂错 Agent、环境变量没设。","进阶：Sessions 做多轮记忆、ModelSettings 精调采样、把 tracing 接 OpenTelemetry 补可观测。"]})]})}export{A as default};
